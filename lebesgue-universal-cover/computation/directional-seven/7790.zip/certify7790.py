from pathlib import Path
from fractions import Fraction as F
from bisect import bisect_left,bisect_right
from hashlib import sha256
import json,sys,platform
from flint import arb,ctx
ctx.prec=192; n=7790;M=10**16
w=[1000000]*n; params=[634599,971435,997893,999779,1096241,1007040,1000425];w[0]=w[1]=params[0]
for k in range(3):w[2+k]=w[n-1-k]=params[1+k];w[n//2-k]=w[n//2+1+k]=params[4+k]
W=sum(w);assert W==7789414824 and all(z>0 for z in w)
cum=0; B=[]
for z in w:B.append(2*cum+z);cum+=z
assert cum==W and all(x<y for x,y in zip(B,B[1:]))
R={z:1/(arb.pi()*z/W).cos() for z in set(w)};rmax=R[max(w)];H=F(153473498043733333587646484375,183251915605930917101794492416);T=F(67,80);ar=lambda z:arb(z.numerator)/z.denominator
limit=ar(4*H/T); tail=(rmax-1)**2+4*rmax*rmax*(arb.pi()/n).cos()**2;assert tail<limit
BB=B+[z+2*W for z in B];K=2*W//n; cache={};mx=arb(0);cnt=0;maxkey=None
for i in range(n):
 lo=bisect_left(BB,B[i]+W-K,i+1,i+n);hi=bisect_right(BB,B[i]+W+K,i+1,i+n)
 for j in range(lo,hi):
  jj=j%n;d=abs(BB[j]-B[i]-W);assert n*d<=2*W
  key=tuple(sorted((w[i],w[jj])))+(d,)
  if key not in cache:
   a,b=R[key[0]],R[key[1]];cache[key]=a*a+b*b+2*a*b*(arb.pi()*d/W).cos()
  v=cache[key];assert v<limit,(i,jj,key,v-limit)
  if float(v.mid())>float(mx.mid()):maxkey=(i,jj,key)
  mx=arb.max(mx,v)
  cnt+=1
upper=arb.max(mx,tail).sqrt().upper();den=(upper*M+2).ceil().unique_fmpz();assert den is not None;den=int(den)
points=[]
for wi,bi in zip(w,B):
 a=arb.pi()*bi/W;sn,co=a.sin_cos();x=R[wi]*co*M;y=R[wi]*sn*M;ix=(x+arb(1)/2).floor().unique_fmpz();iy=(y+arb(1)/2).floor().unique_fmpz();assert ix is not None and iy is not None
 assert abs(x-arb(ix))<=arb(1)/2 and abs(y-arb(iy))<=arb(1)/2
 points.append([int(ix),int(iy)])
beta=F(2*(M-1),den);margin=H*beta*beta-T;assert margin>0
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);(out/'points.json').write_text(json.dumps({'n':n,'coordinate_denominator':den,'points':points},separators=(',',':'))+'\n')
rec={'n':n,'inradius_tangent_weights':params,'weight_sum':W,'coordinate_rounding_M':M,'max_radius':str(rmax),'near_pair_comparisons_directed':cnt,'near_pair_types':len(cache),'max_near_pair':str(mx),'max_near_key':maxkey,'tail_bound_squared':str(tail),'diameter_upper':str(upper),'diameter_squared_target':str(limit),'rational_coordinate_denominator':den,'contained_disk_diameter_ratio':str(beta),'target_area_margin_exact':str(margin),'target_area_margin_arb':str(ar(margin)),'points_sha256':sha256((out/'points.json').read_bytes()).hexdigest(),'python':platform.python_version(),'arb_bits':ctx.prec,'complete':True};(out/'certificate.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))

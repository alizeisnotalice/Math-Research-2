"""Construct and check rational tangent witnesses for the same two seven-body families."""
from argparse import ArgumentParser
from fractions import Fraction
from gzip import compress, decompress
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import platform

import flint
from flint import arb, ctx

from diameter import axis_max


TARGET = Fraction(67, 80)
G = Fraction(120696470013529293, 2**57)
GRID = 10**21
BETA_DEN = 10**34
SHAPES = (0, 3, 5, 7, 9)
SAFE_AREA = Fraction(".83750016750002510964")
SOURCES = {
    "61": (
        Fraction(".999999939"),
        "21f983768ceca4e8f14c2eab9cf60929087848db9f4a45cab5a3059d5f9f8ca2",
    ),
    "100-safe": (
        Fraction(".99999990000000001"),
        "989b77b08578b0b4639320bb79c9f6528d9bfff02a1b8cc6aca0e12ac59d74b3",
    ),
}


def ball(x):
    q = Fraction(x)
    return arb(q.numerator) / q.denominator


def digest(raw):
    return sha256(raw).hexdigest()


def packed(obj):
    return (json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n").encode()


def decimal_floor(value, places=32):
    scale = 10**places
    z = value.numerator * scale // value.denominator
    magnitude = abs(z)
    sign = "-" if z < 0 else ""
    return f"{sign}{magnitude // scale}.{magnitude % scale:0{places}d}"


def integer_round(x):
    scaled = GRID * x
    z = int((scaled + ball(Fraction(1, 2))).floor().unique_fmpz())
    assert abs(scaled - z) < ball(Fraction(1, 2))
    return z


def integer_lower(x):
    return int(x.lower().floor().unique_fmpz())


def square_distance(p, q):
    return (p[0] - q[0])**2 + (p[1] - q[1])**2


def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def clockwise_edge_normal(a, b):
    return b[1]-a[1], a[0]-b[0]


def convex_hull(points):
    ordered = sorted(set(map(tuple, points)))

    def half(seq):
        stack = []
        for p in seq:
            while len(stack) > 1 and cross(stack[-2], stack[-1], p) <= 0:
                stack.pop()
            stack.append(p)
        return stack[:-1]

    return half(ordered) + half(reversed(ordered))


def rotating_diameter2(hull):
    """Second diameter algorithm, matching antipodal pairs of each hull edge."""
    n = len(hull)
    assert n >= 3
    result = 0
    j = 1
    for i in range(n):
        a, b = hull[i], hull[(i+1) % n]
        while cross(a, b, hull[(j+1) % n]) > cross(a, b, hull[j]):
            j = (j+1) % n
        for p in (hull[j], hull[(j+1) % n]):
            result = max(result, square_distance(a, p), square_distance(b, p))
    return result


class Curve:
    """Width-one disk, or the intersection of the defining unit disks."""

    def __init__(self, n):
        self.n = n
        if not n:
            return
        pi = arb.pi()
        radius = 1/(2*(pi/(2*n)).cos())
        assert 1-radius > ball(Fraction(2, 5))
        self.centers = []
        for j in range(n):
            sine, cosine = (2*pi*j/n).sin_cos()
            self.centers.append((radius*cosine, radius*sine))
        self.corners = []
        for (ax, ay), (bx, by) in combinations(self.centers, 2):
            dx, dy = bx-ax, by-ay
            sq = dx*dx + dy*dy
            assert 0 < sq < 4
            h = (1/sq - arb(1)/4).sqrt()
            for sign in [-1, 1]:
                p = ((ax+bx)/2-sign*h*dy, (ay+by)/2+sign*h*dx)
                if self.possibly_feasible(p):
                    self.corners.append(p)
        assert self.corners

    def possibly_feasible(self, p):
        return all(not square_distance(p, center) > 1 for center in self.centers)

    def upper_support(self, nx, ny):
        norm = arb(nx*nx+ny*ny).sqrt()
        assert norm > 0
        if not self.n:
            return (norm/2).upper()
        ux, uy = nx/norm, ny/norm
        candidates = self.corners + [
            (x+ux, y+uy) for x, y in self.centers if self.possibly_feasible((x+ux, y+uy))
        ]
        return max((nx*x+ny*y).upper() for x, y in candidates)


def tangent_points(body, k):
    pi = arb.pi()
    n = body.n
    if not n:
        assert k >= 3 and k % 2 == 1
        radius = 1/(2*(pi/k).cos())
        points = []
        for j in range(k):
            sine, cosine = (2*pi*j/k).sin_cos()
            points.append([integer_round(radius*cosine), integer_round(radius*sine)])
        return points

    points = []
    tangent_radius = 1/(pi/(2*n*k)).cos()
    for i, (x, y) in enumerate(body.centers):
        points.append([integer_round(x), integer_round(y)])
        for j in range(k):
            angle = pi*ball(Fraction(2*i, n)+1-Fraction(1, 2*n)+Fraction(2*j+1, 2*n*k))
            sine, cosine = angle.sin_cos()
            points.append([
                integer_round(x+tangent_radius*cosine),
                integer_round(y+tangent_radius*sine),
            ])
    return points


def inverse_normalization(points, sq, axis):
    a, b = axis
    assert a*a+b*b == sq
    raw = []
    for x, y in points:
        u, ru = divmod(a*x-b*y, sq)
        v, rv = divmod(b*x+a*y, sq)
        assert ru == rv == 0
        raw.append((u, v))
    return raw


def edge_ratios(hull, body, sq):
    normalization = arb(sq).sqrt()
    for index, (p, q) in enumerate(zip(hull, hull[1:]+hull[:1], strict=True)):
        nx, ny = clockwise_edge_normal(p, q)
        height = nx*p[0]+ny*p[1]
        support_upper = body.upper_support(nx, ny)
        assert height > 0 and support_upper > 0
        yield (arb(height)/(normalization*support_upper)).lower(), index


def cert_curve(cloud, body, axis, k):
    n = body.n
    sq = cloud["denominator"]
    pts = cloud["points"]
    raw = inverse_normalization(pts, sq, axis)
    hull = convex_hull(raw)
    expected_size = k if not n else n*(k+1)
    assert len(hull) == len(raw) == len(pts) == expected_size
    assert axis_max(raw)[0] == rotating_diameter2(hull) == sq
    assert axis_max(pts)[0] == sq*sq
    ratio_floor, edge = min(edge_ratios(hull, body, sq))
    beta = Fraction(integer_lower(BETA_DEN*ratio_floor), BETA_DEN)
    assert 0 < beta < 1 and ball(beta) < ratio_floor
    return dict(body=n, grid=k, count=len(pts), extreme=len(hull), axis=list(axis),
                unnormalized_diameter_squared=sq, exact_squared_diameter="1",
                included_scale=str(beta), weakest_edge_index=edge,
                support_ratio_lower=ratio_floor.str(57))


def build_curve(body, k):
    raw = tangent_points(body, k)
    sq, axis = axis_max(raw)
    a, b = axis
    cloud = dict(body=body.n, denominator=sq, points=[[a*x+b*y, a*y-b*x] for x, y in raw])
    return cloud, cert_curve(cloud, body, axis, k)


def disk_factor(n):
    pi = arb.pi()
    return (pi/n).cos()/(pi/(2*n)).cos()


def shorter_grid_ceiling(n, k, area):
    assert n and k >= 2
    # Radius of an ideal tangent vertex from its defining centre is sec(pi/(2nk)).
    # Each rounded vertex moves by less than 1/GRID. A tangent halfspace has
    # supporting distance at least 2/5. Together these give beta <= cos(alpha)+5/GRID.
    upper = ball(area)*((arb.pi()/(2*n*(k-1))).cos()+arb(5)/GRID)**2
    assert upper < ball(TARGET)
    return (upper-ball(TARGET)).str(56)


def disk_gate(H):
    lo, hi = 3, 2**14
    assert ball(H)*disk_factor(lo)**2 < ball(TARGET)
    assert ball(H)*disk_factor(hi)**2 > ball(TARGET)
    while hi-lo > 1:
        n = (lo+hi)//2
        bound = ball(H)*disk_factor(n)**2
        if bound > ball(TARGET):
            hi = n
        else:
            assert bound < ball(TARGET)
            lo = n
    # The universal disk ceiling uses all integers; the construction uses odd regular polygons.
    odd = hi if hi % 2 else hi+1
    return dict(positive_formula_first_integer=hi, first_odd=odd, impossible_cap=lo,
                impossible_cap_margin=(ball(H)*disk_factor(lo)**2-ball(TARGET)).str(56),
                first_integer_margin=(ball(H)*disk_factor(hi)**2-ball(TARGET)).str(56),
                max_6000_margin=(ball(H)*disk_factor(6000)**2-ball(TARGET)).str(56))


def fixed_clouds(source, label, s):
    raw = (source/f"points-{label.split('-')[0]}.json").read_bytes()
    assert digest(raw) == SOURCES[label][1]
    groups = json.loads(raw)
    assert set(groups) == {"P66", "physicalQ"}
    result = []
    receipts = []
    for name, count in [("P66", 66), ("physicalQ", 11)]:
        group = groups[name]
        den = group["denominator"]*s.numerator
        points = [[u*s.denominator, v*s.denominator] for u, v in group["points"]]
        assert len(set(map(tuple, points))) == count
        pairs = list(combinations(points, 2))
        d2 = max(square_distance(a, b) for a, b in pairs)
        assert d2 == axis_max(points)[0] < den*den
        receipts.append(dict(body=name, count=len(points), pairs_checked=len(pairs),
                             diameter_squared=str(Fraction(d2, den*den)), included_scale="1"))
        result.append(dict(body=name, denominator=den, points=points))
    return result, receipts


def run_one(source, out, label, verify):
    s, input_pin = SOURCES[label]
    H_exact = G/s**2
    if label == "100-safe":
        const = (source/"constants-100.json").read_bytes()
        assert digest(const) == "288f1c623a7a2c6e7be1dd80847760bcb9be75ff4776b55e670430269acba5ec"
        assert Fraction(json.loads(const)["previous_floor_valid_scale"]) == s
        assert SAFE_AREA < H_exact
    H = SAFE_AREA if label == "100-safe" else H_exact
    disk = disk_gate(H)
    seed = (arb.pi()/(2*(ball(TARGET/H).sqrt()).acos())).ceil()
    seed = int(seed.unique_fmpz())

    clouds = []
    rows = []
    report = out/f"receipt-{label}.json"
    result = out/f"clouds-{label}.json.gz"
    expected = json.loads(report.read_bytes()) if verify else None
    supplied = json.loads(decompress(result.read_bytes())) if verify else None
    for i, n in enumerate(SHAPES):
        body = Curve(n)
        if verify:
            old = expected["groups"][i]
            k, axis = old["grid"], old["axis"]
            cloud = supplied[i]
            assert cloud["body"] == n
            row = cert_curve(cloud, body, axis, k)
            row["tried_grids"] = old["tried_grids"]
            assert tangent_points(body, k) == [list(p) for p in inverse_normalization(
                cloud["points"], cloud["denominator"], axis)]
        else:
            k = disk["first_odd"] if not n else max(1, seed//n-1)
            tried = []
            while True:
                cloud, row = build_curve(body, k)
                trial = H*Fraction(row["included_scale"])**2-TARGET
                tried.append(dict(grid=k, certified_area_margin=decimal_floor(trial)))
                if trial > 0:
                    row["tried_grids"] = tried
                    break
                k += 2 if not n else 1
        if n:
            row["previous_grid_ceiling_margin"] = shorter_grid_ceiling(n, k, H)
        if verify:
            assert row == old
        clouds.append(cloud)
        rows.append(row)
    extra, extra_rows = fixed_clouds(source, label, s)
    if verify:
        assert supplied[5:] == extra
    clouds.extend(extra)
    rows.extend(extra_rows)
    beta = min(Fraction(r["included_scale"]) for r in rows)
    lower = H*beta**2
    assert lower > TARGET
    raw = packed(clouds)
    data = dict(input_coordinate_sha256=input_pin, scale=str(s), G=str(G), H_exact=str(H_exact),
                H_used=str(H), point_count=sum(r["count"] for r in rows),
                max_count=max(r["count"] for r in rows), groups=rows,
                certified_curve_edges=sum(r["extreme"] for r in rows[:5]),
                included_scale=str(beta), area_lower=str(lower),
                area_lower_decimal=decimal_floor(lower),
                strict_excess=str(lower-TARGET), target=str(TARGET), disk=disk,
                uncompressed_coordinate_sha256=digest(raw), python=platform.python_version(),
                python_flint=flint.__version__, precision_bits=ctx.prec)
    if verify:
        assert digest(decompress(result.read_bytes())) == digest(raw)
        for field in ("python", "python_flint"):
            data[field] = expected[field]
        assert data == expected
    else:
        result.write_bytes(compress(raw, compresslevel=8, mtime=0))
        report.write_text(json.dumps(data, indent=2, sort_keys=True)+"\n")
    print(label, [r["count"] for r in rows], data["point_count"], data["area_lower_decimal"],
          "disk impossible through", disk["impossible_cap"], flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent/"inputs")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent/"results")
    parser.add_argument("--verify", action="store_true")
    opts = parser.parse_args()
    assert __debug__
    ctx.prec = 256
    opts.out.mkdir(exist_ok=True)
    for label in SOURCES:
        run_one(opts.source, opts.out, label, opts.verify)


if __name__ == "__main__":
    main()

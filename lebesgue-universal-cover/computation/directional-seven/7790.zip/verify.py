from pathlib import Path
from fractions import Fraction as F
from gzip import decompress,compress
from hashlib import sha256
import json,sys,subprocess
from flint import arb,ctx
import legacy as L
D=Path(__file__).resolve().parent;I=D/'inputs'
if len(sys.argv)!=2:raise SystemExit('usage: verify.py NEW_OUTPUT')
O=Path(sys.argv[1]).resolve();O.mkdir(parents=True,exist_ok=False)
expected={'clouds-61.json.gz':'d2448f03bdc2e01d2fe39b2b3c5e973ab15043a27154f8f9a4c5ce8156075a1a','points-61.json':'21f983768ceca4e8f14c2eab9cf60929087848db9f4a45cab5a3059d5f9f8ca2','receipt-61.json':'4136566bf45b8af547443c63b33fc5db8a249d20c4f9699ad3ec0af7db9d1312'}
for name,hashval in expected.items():assert sha256((I/name).read_bytes()).hexdigest()==hashval
assert sha256((D/'legacy.py').read_bytes()).hexdigest()=='d97c3c41663167b8e1e8d4cdca024911677e32677784c68f9986c174b524a86d'
assert sha256((D/'diameter.py').read_bytes()).hexdigest()=='d116da53bdd01776ed98167e6f058e0f29ef1486f80d1d56e703f9e3301560da'
subprocess.run([sys.executable,'-E','-B',str(D/'certify7790.py'),str(O/'disk')],check=True)
disk=json.loads((O/'disk/certificate.json').read_text());pd=json.loads((O/'disk/points.json').read_text());beta=F(disk['contained_disk_diameter_ratio']); assert disk['complete'] and len(pd['points'])==7790
hull=L.convex_hull(pd['points']);assert len(hull)==7790
diameter_sq=L.rotating_diameter2(hull);assert diameter_sq==L.axis_max(pd['points'])[0] and diameter_sq<=pd['coordinate_denominator']**2
edge_margin=None
for p,q in zip(hull,hull[1:]+hull[:1]):
 cross=p[0]*q[1]-p[1]*q[0];assert cross>0
 dx=q[0]-p[0];dy=q[1]-p[1];gap=cross*cross-(10**16-1)**2*(dx*dx+dy*dy);assert gap>0
 edge_margin=gap if edge_margin is None else min(edge_margin,gap)
assert F(2*(10**16-1),pd['coordinate_denominator'])==beta
ctx.prec=256; H=L.G/L.SOURCES['61'][0]**2;assert H==F(153473498043733333587646484375,183251915605930917101794492416)
receipt=json.loads((I/'receipt-61.json').read_text());old=json.loads(decompress((I/'clouds-61.json.gz').read_bytes()));assert len(old)==7
outcloud=[{'body':0,'denominator':pd['coordinate_denominator'],'points':pd['points']}];rows=[{'body':0,'count':len(pd['points']),'included_scale':str(beta),'diameter_at_most_one':True}]
for i,n in enumerate((3,5,7,9),1):
 print('VERIFY_CURVE',n,flush=True);prior=receipt['groups'][i];cloud=old[i];assert cloud['body']==n
 body=L.Curve(n);row=L.cert_curve(cloud,body,prior['axis'],prior['grid']);row['tried_grids']=prior['tried_grids'];row['previous_grid_ceiling_margin']=L.shorter_grid_ceiling(n,prior['grid'],H);assert row==prior
 assert L.tangent_points(body,prior['grid'])==[list(p) for p in L.inverse_normalization(cloud['points'],cloud['denominator'],prior['axis'])]
 assert F(row['included_scale'])>beta;row['area_margin_at_own_scale']=str(H*F(row['included_scale'])**2-L.TARGET);outcloud.append(cloud);rows.append(row)
extra,extra_rows=L.fixed_clouds(I,'61',L.SOURCES['61'][0]);assert extra==old[5:]
for x,y in zip(extra,extra_rows):assert y['count']<=7790 and F(y['included_scale'])>beta;outcloud.append(x);rows.append(y)
assert len(outcloud)==7 and max(x['count'] for x in rows)==7790
GATE=L.disk_gate(H);assert GATE['impossible_cap']==7789 and GATE['positive_formula_first_integer']==7790
area=H*beta**2;excess=area-L.TARGET;assert excess>0
raw=L.packed(outcloud);(O/'seven-groups.json.gz').write_bytes(compress(raw,compresslevel=8,mtime=0));summary={'complete':True,'inherited_scope':'conditional on the R272/R265 seven-input lower bound G for the exact source families','H':str(H),'counts':[x['count'] for x in rows],'included_scales':[x['included_scale'] for x in rows],'disk_exact_squared_diameter':str(F(diameter_sq,pd['coordinate_denominator']**2)),'disk_exact_edge_minimum_integer_margin':str(edge_margin),'common_beta':str(beta),'area_lower_exact':str(area),'area_lower_decimal':L.decimal_floor(area,45),'excess_exact':str(excess),'excess_decimal':L.decimal_floor(excess,45),'disk_ceiling':GATE,'optimal_largest_group_size_in_common_disk_inclusion_model':7790,'groups':rows,'seven_groups_uncompressed_sha256':sha256(raw).hexdigest(),'seven_groups_gzip_sha256':sha256((O/'seven-groups.json.gz').read_bytes()).hexdigest()};(O/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='groups'},indent=2))

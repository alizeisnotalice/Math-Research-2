"""Exact diameter from the edge fans of the integer convex hull."""

def det(u, v):
    return u[0] * v[1] - u[1] * v[0]


def sub(p, q):
    return p[0] - q[0], p[1] - q[1]


def hull(P):
    S = sorted(set(map(tuple, P)))

    def half(seq):
        H = []
        for p in seq:
            while len(H) > 1 and det(sub(H[-1], H[-2]), sub(p, H[-1])) <= 0:
                H.pop()
            H.append(p)
        return H[:-1]

    return half(S) + half(reversed(S))


def edges(H):
    i = min(range(len(H)), key=lambda k: (H[k][1], H[k][0]))
    H = H[i:] + H[:i]
    return H[0], [sub(q, p) for p, q in zip(H, H[1:] + H[:1])]


def axis_max(P):
    # Merge the CCW edge fans of H and -H. At each vertex of H-H, update squared radius.
    H = hull(P)
    assert len(H) >= 3
    p, A = edges(H)
    q, B = edges([(-x, -y) for x, y in H])
    x, y = p[0] + q[0], p[1] + q[1]
    z = (x * x + y * y, (x, y))
    i = j = 0

    def side(u):
        return int(u[1] < 0 or (u[1] == 0 and u[0] < 0))

    while i < len(A) or j < len(B):
        if i == len(A):
            cmp = 1
        elif j == len(B):
            cmp = -1
        else:
            c = det(A[i], B[j])
            cmp = side(A[i]) - side(B[j]) or ((c < 0) - (c > 0))
        if cmp <= 0:
            x += A[i][0]
            y += A[i][1]
            i += 1
        if cmp >= 0:
            x += B[j][0]
            y += B[j][1]
            j += 1
        z = max(z, (x * x + y * y, (x, y)))
    assert (x, y) == (p[0] + q[0], p[1] + q[1])
    return z



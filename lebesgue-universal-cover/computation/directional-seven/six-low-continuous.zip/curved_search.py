import argparse,ctypes,json,os
for env in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[env]='1'
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.spatial import ConvexHull
D=Path(__file__).resolve().parent
data=json.loads((D/'../../lebesgue-main/lebesgue-universal-cover/computation/finite-point-leaf-input.json').read_bytes())
pts=np.array(data['points'],float)/data['denominator'];P=np.ascontiguousarray(pts[ConvexHull(pts).vertices]).ravel()
lib=ctypes.CDLL(str(D/'envelope.dylib'));f=lib.area_gradient
vec=np.ctypeslib.ndpointer(dtype='float64',flags='C_CONTIGUOUS');f.argtypes=[vec,vec,ctypes.c_int,vec];f.restype=ctypes.c_double
def value(z):
 g=np.zeros(14);v=f(np.ascontiguousarray(z,dtype=float),P,len(P)//2,g);return v,g
def solve(item):
 i,z=item
 r=minimize(value,z,jac=True,method='L-BFGS-B',options=dict(ftol=1e-16,gtol=1e-11,maxiter=420,maxls=45,maxcor=16))
 return [i,r.fun,r.x.tolist(),r.nit]
def run():
 p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--workers',type=int,default=4);a=p.parse_args();z=json.loads(a.input.read_bytes())
 with ProcessPoolExecutor(a.workers) as ex,a.output.open('w') as stream:
  for row in ex.map(solve,enumerate(z)):
   stream.write(json.dumps(row)+'\n');stream.flush()
if __name__=='__main__':run()

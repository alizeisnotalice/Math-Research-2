// Numerical curved convex hull for search. The certified reported area uses an independent Arb checker.
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>
namespace {
const double pi=std::acos(-1.), tau=2*pi;
struct V{double x=0,y=0;};
V operator+(V a,V b){return {a.x+b.x,a.y+b.y};}
V operator-(V a,V b){return {a.x-b.x,a.y-b.y};}
V operator*(V a,double b){return {a.x*b,a.y*b};}
double dot(V a,V b){return a.x*b.x+a.y*b.y;}
double det(V a,V b){return a.x*b.y-a.y*b.x;}
V unit(double t){return {std::cos(t),std::sin(t)};}
double normangle(double t){t=std::fmod(t,tau);return t<0?t+tau:t;}
struct Material{V p;double r;int i;};
struct Piece{double a,b;Material m;};
bool same(Material a,Material b){return a.i==b.i&&a.r==b.r&&a.p.x==b.p.x&&a.p.y==b.p.y;}
}
extern "C" double area_gradient(const double*z,const double*P,int points,double*g){
 std::fill(g,g+14,0.0);
 std::array<std::vector<V>,6> vertices;
 std::array<V,6> tr{};tr[1]={z[0],z[1]};
 std::array<double,6> angle{};std::array<int,6> n{0,3,5,7,9,0};
 std::vector<double> cuts{0,tau};
 for (int i=2;i<6;i++){int j=2+3*(i-2);angle[i]=z[j];tr[i]={z[j+1],z[j+2]};}
 for(int i=1;i<5;i++)for(int j=0;j<n[i];j++){
     double a=angle[i]+tau*j/n[i];vertices[i].push_back(tr[i]+unit(a)*(0.5/std::cos(pi/(2*n[i]))));
     for(double sign:{-1.,1.})cuts.push_back(normangle(a+pi+sign*pi/(2*n[i])));
 }
 double c=std::cos(angle[5]),s=std::sin(angle[5]);
 for(int j=0;j<points;j++){double x=P[2*j],y=P[2*j+1];vertices[5].push_back(tr[5]+V{c*x-s*y,s*x+c*y});}
 for(int j=0;j<points;j++){V v=vertices[5][(j+1)%points]-vertices[5][j];cuts.push_back(normangle(std::atan2(-v.x,v.y)));}
 std::sort(cuts.begin(),cuts.end());
 std::vector<Piece> pieces;
 for(std::size_t it=1;it<cuts.size();it++){
     double a=cuts[it-1],b=cuts[it];if(b-a<2e-15)continue;double h=(a+b)/2;V u=unit(h);
     std::array<Material,6> m;m[0]={{0,0},.5,0};
     for(int i=1;i<6;i++){
         int best=0;for(int k=1;k<(int)vertices[i].size();k++)if(dot(vertices[i][k],u)>dot(vertices[i][best],u))best=k;
         m[i]={vertices[i][best],0.,i};
         if(i<5){
             int idx=(int)std::floor((h-angle[i]-pi)*n[i]/tau+.5);
             double diff=h-(angle[i]+pi+idx*tau/n[i]);
             if(std::abs(diff)<pi/(2*n[i]))m[i]={vertices[i][(idx%n[i]+n[i])%n[i]],1.,i};
         }
     }
     std::vector<double> cross{a,b};
     for(int i=0;i<6;i++)for(int j=0;j<i;j++){
         V diff=m[i].p-m[j].p;double radius=std::hypot(diff.x,diff.y),C=m[j].r-m[i].r;
         if(std::abs(C)>=radius)continue;
         double v=std::atan2(diff.y,diff.x),delta=std::acos(C/radius);
         for(double t:{v+delta,v-delta}){t=normangle(t);if(t>a&&t<b)cross.push_back(t);}
     }
     std::sort(cross.begin(),cross.end());
     for(std::size_t k=1;k<cross.size();k++){
         double l=cross[k-1],r=cross[k];if(r-l<1e-15)continue;V normal=unit((l+r)/2);
         int best=0;double val=.5;for(int i=1;i<6;i++){double t=m[i].r+dot(m[i].p,normal);if(t>val){best=i;val=t;}}
         if(!pieces.empty()&&same(pieces.back().m,m[best]))pieces.back().b=r;
         else pieces.push_back({l,r,m[best]});
     }
 }
 auto grad=[&](Material m,V v){
   if(!m.i)return;
   if(m.i==1){g[0]+=v.x;g[1]+=v.y;return;}
   int j=2+3*(m.i-2);g[j]+=det(m.p-tr[m.i],v);g[j+1]+=v.x;g[j+2]+=v.y;
 };
 double twice=0;
 for(std::size_t i=0;i<pieces.size();i++){
     Piece p=pieces[i];Material m=p.m,next=pieces[(i+1)%pieces.size()].m;V a=unit(p.a),b=unit(p.b);
     V integral{b.y-a.y,a.x-b.x};
     twice+=m.r*m.r*(p.b-p.a)+m.r*dot(m.p,integral);grad(m,integral*m.r);
     V from=m.p+b*m.r,to=next.p+b*next.r;twice+=det(from,to);
     double len=det(b,to-from);grad(m,b*(len/2));grad(next,b*(len/2));
 }
 return twice/2;
}

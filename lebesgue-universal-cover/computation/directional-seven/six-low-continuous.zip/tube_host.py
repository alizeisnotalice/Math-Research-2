import sys,json
from pathlib import Path
from fractions import Fraction as F
from hinge_bank import host,write_poly,S
c,k=Path(sys.argv[1]),int(sys.argv[2]);z=json.load(open('true-best-pose.json'))['center']
qs=[F(0),F(1,4*10**6),F(1,10**6),F(3,10**6),F(8,10**6)]
boxes=[]
with open('tube-h.dat','w') as f:
 f.write(f'{S} {len(qs)}\n')
 for r in qs:
  v=[int((5 if j in [2,5,8] else 1)*r*2**44) for j in range(11)]
  b=[[x-y,x+y] for x,y in zip(z,v)]
  write_poly(f,host(c,b,k));boxes.append(b)
Path('tube-boxes.json').write_text(json.dumps(boxes)+'\n')

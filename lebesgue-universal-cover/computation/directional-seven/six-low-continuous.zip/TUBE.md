# 自由三十点与五曲体小邻域

围绕 true-best-pose.json 的五曲体姿态，在每一平移坐标的区间分别取半宽 r，在三个角坐标的区间取半宽 5r，所有坐标在分母 2⁴⁴ 的端点向内取整。tube_host.py 和 R237 的 hinge_bank.host 建立这个完整闭盒上每个实际五体凸包都包含的整数多边形 H。对历史原三十点的平移、旋转及反射不加限制。

angle_intersection.py 给出旋转角闭格的共同内多边形。将原三十点凸包的一条边写成 u·x≤h，h>0。选有理 t≥tan(π/4096)，在格中心取同时满足 (u±tJu)·x≤h 的全体有理交点之凸包。对任一格内角 δ，J 为直角转动，(u+tan(δ)Ju)·x≤h；乘以 cos(δ)>0 后得到旋转后该边的真实约束。每一格的整取坐标误差用其 2/5 内圆及相应向内同心缩放覆盖。该步骤对两种手性独立执行。原算法 R237 的 hinge.cpp 根据两多边形面面积的正部恒等式，严格排除每格的全部连续平移。实际校验中对各姿态盒均枚举了两个手性共 8,192 个闭角格。

在每个平移半宽 10⁻⁶、角半宽 5×10⁻⁶ 的闭盒内，所有第六体摆放均满足面积严格大于 .837505。在每个平移半宽 2.5×10⁻⁷、角半宽 1.25×10⁻⁶ 时，面积严格大于 .837509。tube-505.out、tube-509.out 按 tube-boxes.json 所给顺序记录每个箱的总角格数及最先未被排除角格，-1 表示全闭。

~~~sh
PYTHONPATH="$COMP/inclusion-minimal-eleven" python -B tube_host.py "$COMP" 512
python -B angle_intersection.py "$COMP/finite-point-leaf-input.json" 4096 cap4096.dat
c++ -O3 -std=c++17 "$COMP/inclusion-minimal-eleven/hinge.cpp" -o hinge
./hinge tube-h.dat cap4096.dat 837505
./hinge tube-h.dat cap4096.dat 837509
~~~

from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
ctx.prec=224
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
bank,out=map(Path,sys.argv[1:]);b=json.loads(bank.read_bytes());U=2**22;Q=2**28;r=F('.5');G=F(120696470013529293,2**57);B=F(120666927296517964,2**57);s=F('.9999998');ep=1-s
n2=min(x*x+y*y for x,y in b['directions']);assert n2==17592181706996
R=1/ar(3).sqrt();rho=ar(n2).sqrt()/U;assert rho*(ar(s)-R*ar(ep))>ar(F(U-2,U))
disk_padding=ar(F(3,Q))/rho;maxgrid=ar(ep)/2+disk_padding
assert ar(F(2,5*(U+1)))+(1-R)*ar(ep)>maxgrid
rad=ar(s*r);z=ar('.706');assert (arb.pi()-(rad/z).acos())*rad**2+rad*(z*z-rad**2).sqrt()>ar(G)
shift=max(maxgrid,ar(F('.6')*ep));assert ar('.706')+shift<ar('.707') and F('.707')**2<2*(s*r)**2
assert s*r/(U-2)>(F('.707')-F('.44'))*ep
assert ar(F(Q//5000,Q)*U/(U+2))>shift
floor=(120666927296517964*F('.99999977')**2).__floor__();assert F(floor,2**57)<B*s*s and 3*ep<F('.8373034')-B
z=dict(scale=str(s),area=str(G/s**2),area_decimal=ar(G/s**2).str(58),mesh_normal_square=n2,defining_disk_margin=(rho*(ar(s)-R*ar(ep))-ar(F(U-2,U))).str(40),min_mesh_physical_norm=rho.str(40),strong_wall_margin=(ar(F(2,5*(U+1)))+(1-R)*ar(ep)-maxgrid).str(40),global_dichotomy_floor=floor)
out.write_text(json.dumps(z,indent=2)+'\n')

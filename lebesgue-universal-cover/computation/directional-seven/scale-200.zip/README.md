# 同一原盒三方向支撑墙的七体下端

共同尺度 .9999998，一般下端 .8375003350001005014145793425931。显式七组有理点每组至多4305点，给出 .8375000004973845635534605934。

本包依赖第272轮首个七体包 physical-seven-flex50.zip（SHA256 d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666），以及第269轮七体选源和原五体公开计算目录。传入首包、主仓 computation、Tomar 原树 cert11d_08366、table64.npz、Clang共享缓存及一个新目录。

~~~sh
python -B replay.py "$FIRST_ZIP" "$COMP" "$TREE" "$TABLE64" "$CLANG_CACHE" "$NEW_OUTPUT" --workers 4
~~~

入口校验原树、普通与网格核的源接口，重新计算全5442个原盒及各逐行下界。随后逐对核查两个真实点云直径，以两种Q手性重算五类方向表并生成有限坐标，再重新编译、运行501个基准原根。若已实际运行本包120666871789737790地板，可另附 --reuse-roots 当次输出文件。未经缩放的原历史整树沿用第269轮的严格选源。

只要点表时可运行 python -B finite.py points.json NEW_FINITE_DIR。整个曲体结论和有限点结论分别写在 PROOF.md；points.json 属于缩后尺度，归一后的两个点组要除以 .9999998。完整的七组归一有理坐标生成在 finite-points.json.gz。

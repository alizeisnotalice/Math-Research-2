# 七输入逐向盘墙证书

第269轮的同一七体选源，新的共同尺度为 .9999999，一般下端为 .83750016750002512639112905875。两组新的有理点云均允许自由摆放。每组至多6085点时，严格有限下端为 .83750000007332125907806418。

输入依次给出首份七体包 physical-seven-flex50.zip、主仓 computation、Tomar 原树 cert11d_08366、table64.npz、Clang共享缓存、尚未创建的输出目录。两份证书共同使用第269轮的原5442叶，后者用精确有理乘积重算501基准。

~~~sh
python -B replay.py "$FIRST_ZIP" "$COMP" "$TREE" "$TABLE64" "$CLANG_CACHE" "$NEW_OUT" --workers 4
~~~

若已用本包 run_floor.py 生成修正底数120666903163133711的启动器并实际跑全501，可附加 --reuse-roots 路径读取当次 JSONL，与附件逐根输出摘要比对。独立验证各体必要界、强及普通整数核、五类角行、点云直径和有理样本仍执行。已经公开的原历史全树由第269轮七体选源引用。PROOF.md 说明非均匀补偿以及旧整数分母的作用。

解压后单独生成完整七组有理点表可运行 python -B finite.py points.json NEW_FINITE_DIR。输出的 finite-receipt.json 含每组直径平方、组点数、公共内含尺度与面积有理下端。

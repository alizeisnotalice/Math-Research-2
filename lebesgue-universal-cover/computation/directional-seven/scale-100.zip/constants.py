"""Directed arithmetic for the padded and ordinary projected walls."""
import json,sys
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=256
def ar(q):
    q=F(q);return arb(q.numerator)/q.denominator
s=F('.9999999');ep=1-s;U=2**22;Q=2**28;r=F(1,2);a=F('.468');G=F(120696470013529293,2**57);B=F(120666927296517964,2**57)
assert F(71379940282225,2**56)<(r-a)**2 and all(1-1/(2*(arb.pi()/(2*n)).cos())>ar(a) for n in (5,7,9))
xx=ar('.706');rad=ar(s*r);assert (arb.pi()-(rad/xx).acos())*rad**2+rad*(xx**2-rad**2).sqrt()>ar(G)
m0=F('.4464');amax=ep/2+F(U,Q*(U-1));assert F('.706')+amax<F('.707') and F('.707')**2<2*(s*r)**2
assert a>=F('.465') and F(2,5*(U+1))>amax
assert s*r/(U-2)>(F('.707')-m0)*ep
assert (U-1)*(s-F('.6')*ep)>U-2 and F(Q//5000,Q)*U/(U+1)>amax
floor=(120666927296517964*s*s).__floor__()
assert floor==120666903163133711 and F(floor,2**57)<s*s*B
old_floor=(F('.83729500622102524')*s*s*2**57).__floor__();assert old_floor==floor+1
safe=F('.99999990000000001');assert F(old_floor,2**57)<safe*safe*B
assert 3*ep<F('.8373034')-B
d=dict(corrected_floor=floor,previous_floor=old_floor,previous_floor_valid_scale=str(safe),previous_floor_area=ar(G/safe**2).str(58),scale=str(s),area=str(G/s**2),area_decimal=ar(G/s**2).str(58),max_strong_shift=str(amax),ordinary_lower=str(a-F('.465')),padded_denominator_spare=str(s*r/(U-2)-(F('.707')-m0)*ep))
Path(sys.argv[1]).write_text(json.dumps(d,indent=2)+'\n')

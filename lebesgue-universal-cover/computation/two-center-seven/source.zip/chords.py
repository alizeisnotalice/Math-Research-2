"""Audit all old long-chord discounts, dense-material generators and initial localizer."""
import io,zipfile,json,hashlib,sys
from fractions import Fraction as F
from pathlib import Path
c,interfaces,out=map(Path,sys.argv[1:]);chords={};dens={};sig=F('.999999006')
def sha(x):return hashlib.sha256(x).hexdigest()
def one(n,b):
    name=Path(n).name
    if n.endswith('.py'):
        assert b'import dense_material' not in b
        if b'from tomar_p30_scaled_material import scaled_material' in b:dens[sha(b)]=name
    elif name in ('long_edge_support.hpp','disk_chord_support.hpp','slice_support.hpp'):
        assert b'const W c=W(1023)*length, a=W(1024)*gap;' in b
        chords[sha(b)]=name
    elif name=='cap_tangent.hpp':
        assert b'W(weight)*ceildiv(W(1024)*(r0+height)*(r0+height)*Scale' in b and b'W(1023)*length*r0*den' in b;chords[sha(b)]=name
def walk(z):
    for n in z.namelist():
        if n.endswith('.zip'):walk(zipfile.ZipFile(io.BytesIO(z.read(n))))
        elif n.endswith(('.py','.hpp','.cpp')):one(n,z.read(n))
for n,h in json.loads(interfaces.read_bytes())['archives'].items():
    f=c/n;assert sha(f.read_bytes())==h;walk(zipfile.ZipFile(f))
for p in (c/'three-leaf-083750').glob('*.hpp'):one(p.name,p.read_bytes())
one('replay_angle_mesh.py',(c/'three-leaf-083750/replay_angle_mesh.py').read_bytes())
assert len(chords)==6 and dens
mat=c/'critical-material-scale/records';native=json.loads((c/'refined-material-contraction.json').read_bytes());rad=json.loads((mat/'radial.json').read_bytes())
assert F(native['curve_scale'])==sig
for m in ('32','64'):
    peaks=native['material_squared_maxima'][m];assert len(peaks)==5 and 4*peaks[0]<(sig*2**28)**2 and all(x<(sig*2**28)**2 for x in peaks[1:])
assert rad['zero_angle_and_counts_equal'] and sha((c/'five-body-radial-material.npz').read_bytes())==rad['radial_table_sha256']
base=c/'tomar_p30_scaled_material.py';gen=base.read_text();assert 'scale=arb(999999006)/1000000000' in gen and '(X-scale*vx)**2+(Y-scale*vy)**2<scale*scale' in gen and 'X*X+Y*Y<scale*scale/4' in gen
root=c/'global-083750/records/root50.json';assert len(json.loads(root.read_bytes()))==4
d=dict(discounted_chord_sources=sorted(chords.items()),dense_checked_sources=sorted(dens.items()),dense_material_sha=sha(base.read_bytes()),table_and_radial={p.name:sha(p.read_bytes()) for p in [c/'refined-material-contraction.json',mat/'radial.json',root]},scale=str(sig))
out.write_text(json.dumps(d,indent=2)+'\n')

"""Two uses of the scaled R234 exterior, strict material inclusion, and the scaled-chord comparison."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,numpy as np
from flint import arb,ctx
ctx.prec=256
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
core,bank,out=map(Path,sys.argv[1:]);X=np.load(core);assert X.shape==(5442,2,11)
d=json.loads(bank.read_bytes());U=2**22;Q=2**28;r=F('.5');G=F(120696470013529293,2**57);B=F(120666927296517964,2**57)
s=F('.99999909');sc=F('.999999083');sig=F('.999999006');ec=1-sc;ep=1-s;assert sig<sc<s
centers=[]
for i,n in enumerate((3,5,7,9)):
    R=1/(2*(arb.pi()/(2*n)).cos());rin=1-R
    C2=max(sum(max(abs(F(float(row[z,k]))) for z in (0,1))**2 for k in [3*i,3*i+1]) for row in X)
    spare=ar(sc-sig)*rin-ar(ec/sc)*ar(C2).sqrt();assert spare>0
    centers.append(dict(order=n,C2=str(C2),original_anchor_offset_upper=(ar(ec/sc)*ar(C2).sqrt()).str(40),inner_slack=spare.str(40)))
rad=ar(sc*r);z=ar('.706');assert (arb.pi()-(rad/z).acos())*rad**2+rad*(z*z-rad**2).sqrt()>ar(G)
assert F('.706')**2<2*(sc*r)**2 and F(2,5*(U+1))>F(3*U,Q*(U-1))
assert sc*r/(U-2)>ec*F(1,60) and F(1,60)**2>F(1,4000)
chord=sc*F(U,U+2)**2-F(1023,1024);assert chord>0 and F('.8373034')*sc**2>B
floor=(2**57*B*F('.999999005')**2).__floor__();assert F(floor,2**57)<sc**2*B
j=dict(curve_scale=str(sc),maximum_input_scale=str(s),former_localizer=str(sig),centers=centers,area_rational=str(G/s**2),area_decimal=ar(G/s**2).str(62),chord_spare=str(chord),disk_denominator_spare=str(sc*r/(U-2)-ec*F(1,60)),floor=floor)
out.write_text(json.dumps(j,indent=2)+'\n')

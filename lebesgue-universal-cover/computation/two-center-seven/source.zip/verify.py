"""Pay every lower score of the named physical model on the whole closed angular cells."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import lcm
import numpy as np,argparse,json
from flint import arb,ctx
def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator
def read(p):return json.loads(p.read_bytes())
pa=argparse.ArgumentParser()
for k in ['bank','src','fit','out']:pa.add_argument(k,type=Path)
pa.add_argument('--comp',type=Path,required=True);pa.add_argument('--wall-eps',required=True);pa.add_argument('--walls',type=Path);pa.add_argument('--kind',choices=['P','Q','legacy','Qlegacy']);pa.add_argument('--eps',default='.00000001');pa.add_argument('--m',default='.48');a=pa.parse_args();ctx.prec=160
aux=read(a.walls) if a.walls else None
ew=F(a.wall_eps);swall=1-ew
data=read(a.src);b=read(a.bank);fit=read(a.fit);p=data['points'];e=F(a.eps);s=1-e;m=F(a.m);unit=F(fit['epsilon'])/fit['den'];d=data['denominator']
Y=[(F(x,d)+unit*vx,F(y,d)+unit*vy) for (x,y),(vx,vy) in zip(p,fit['directions'],strict=True)]
d2=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(Y,2));print('diam excess',float(d2-s*s),flush=True)
if a.kind not in ['Q','Qlegacy']:assert {(x,-y) for x,y in Y}==set(Y)
intd=lcm(*(z.denominator for xy in Y for z in xy));Yint=[[int(z*intd) for z in xy] for xy in Y]
dirs=b['directions'];U=2**22;Z=2**28;assert all((U-1)**2<x*x+y*y<(U+2)**2 for x,y in dirs)
unit_slack=ar(m*e*F(U-2,U));
import sys
sys.path.insert(0,str(a.comp.resolve()))
from certify_finite_point_leaf import upper_q
from math import isqrt
integer_round=[]
for vx,vy in dirs:
 n2=(vx*vx+vy*vy)*(Z//(2*U))**2;root=isqrt(n2);up=upper_q(ar(F(vx*vx+vy*vy,U*U)).sqrt()/2)
 assert root<=up<=root+3 and ar(up)>ar(n2).sqrt()
 integer_round.append((up-ar(n2).sqrt())/Z)
wf=None;where=None;rows=0;X=np.array([[float(x),float(y)] for x,y in Y]);V=np.array(dirs); cb=arb.pi()
groups=[(0,384,1)] if a.kind!='Q' else [(384,384,1),(384,384,-1),(768,1536,1),(768,1536,-1)]
if a.kind=='Qlegacy':groups=[(0,384,1),(0,384,-1)]
for off,K,hand in groups:
 sw,cw=(cb/K).sin_cos()
 for j in range(K):
  sn,cs=((2*j+1)*cb/K).sin_cos();c,ss=np.cos((2*j+1)*np.pi/K),np.sin((2*j+1)*np.pi/K);px=np.array(p,dtype=float)/d;px[:,1]*=hand
  ids=(V@np.array([[c,-ss],[ss,c]])@px.T).argmax(axis=1);cache={}
  for nn,r in enumerate(b['cells'][off+j]):
   idx,w,ws=r[:3],r[3:6],r[6];assert min(w)>0 and sum(w)==ws and all(sum(wi*dirs[i][t] for wi,i in zip(w,idx))==0 for t in (0,1))
   for i in idx:
    if i in cache:continue
    x,y=Yint[ids[i]];y*=hand;vx,vy=dirs[i];u,v=vx*cs+vy*sn,-vx*sn+vy*cs;cache[i]=(u*x+v*y,v*x-u*y)
   A=sum(wi*cache[i][0] for wi,i in zip(w,idx))/(ws*U*intd);D=sum(wi*cache[i][1] for wi,i in zip(w,idx))/(ws*U*intd)
   ev=[A*cw-D*sw,A*cw+D*sw]
   if a.kind in ['legacy','Qlegacy']:
    oldmat=(data['cells'] if a.kind=='legacy' else b['proposals'])[j][nn][3:]
    if hand==-1:oldmat=[(-k)%11 for k in oldmat]
    zo=[(0,0) for k in idx]
    for k,(i,mat) in enumerate(zip(idx,oldmat)):
     x,y=Yint[mat];y*=hand;vx,vy=dirs[i];u,v=vx*cs+vy*sn,-vx*sn+vy*cs;zo[k]=(u*x+v*y,v*x-u*y)
    A0=sum(wi*t[0] for wi,t in zip(w,zo))/(ws*U*intd);D0=sum(wi*t[1] for wi,t in zip(w,zo))/(ws*U*intd)
    alt=[A0*cw-D0*sw,A0*cw+D0*sw]
    if min(alt)>min(ev):ev=alt
   slack=unit_slack+(sum(wi*integer_round[i] for wi,i in zip(w,idx))/ws if a.kind in ("Q","P") else 0)
   if aux is not None:
    assert aux['root_count']==(1638 if a.kind=='Qlegacy' else 5442) and aux['wall_model']=='entire homothety'
    slack=ar(ew*F(U-2,U)*F(aux['rows'][off+j][nn],aux['scale']))+(ar(swall)*sum(wi*integer_round[i] for wi,i in zip(w,idx))/ws if a.kind in ('Q','P') else 0)
   assert min(ev)>0
   for side,x in enumerate(ev):
    t=max(r[7],r[8+side]) if len(r)==10 else r[7];g=(x+slack-ar(F(t,Z))).lower()
    if wf is None or g<wf:wf=g;where=[off+j,nn,side,hand]
   # Stored curvature bow uses 18 and not 2*pi^2. This covers the constant virtual shift.
   if len(r)==10:assert all(2*cb**2*x>18*ar(F(min(r[8:10]),Z)) for x in ev)
   rows+=1
print(a.kind,'rows',rows,'margin',wf,'at',where,flush=True)
dx=max(((x-F(u,d))**2+(y-F(v,d))**2 for (x,y),(u,v) in zip(Y,p)))
a.out.write_text(json.dumps(dict(kind=a.kind,physical_points=Yint,denominator=intd,eps=str(e),curve_eps=str(ew),m=str(m),diameter2=str(d2),move2=str(dx),diameter_ok=d2<s*s,rows_ok=bool(wf>0),score=wf.str(35),where=where,rows=rows),indent=2)+'\n')

"""The endpoint theorem for the normalized third curvature amplitude."""
import json
from flint import arb, ctx

ctx.prec = 192
pi = arb.pi()
threshold = arb("0.62527")
budget = arb("0.844082046521218581802948589770767704354")
triangle = (pi-arb(3).sqrt())/2
r_limit = ((1+4*(budget-triangle)/pi).sqrt()-1)/2
critical = 2/pi-(4/pi)*(1-(pi*r_limit).cos())
radius = (1-pi*(2/pi-threshold)/4).acos()/pi
area = triangle+pi*radius+pi*radius**2
assert critical < threshold and area < budget
print(json.dumps({"radius_at_budget":str(r_limit),"critical_amplitude":str(critical),
                  "radius_at_0.62527":str(radius),"area_at_0.62527":str(area)},indent=2))

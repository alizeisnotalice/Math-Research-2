"""A global support envelope with a third-harmonic bound and unrestricted tail."""
from fractions import Fraction as F
from pathlib import Path
import json
from flint import arb,ctx
ctx.prec=192
root=Path(__file__).resolve().parent
pi=arb.pi();one=arb(1)
def A(q):q=F(q);return arb(q.numerator)/q.denominator
def load(k):return json.loads((root/k).read_bytes())
def avg_error(deg,poly,N):
 t=pi*A(F(deg,180));edges=sorted(set([0,deg%180,180]));total=arb(0)
 for aa,bb in zip(edges,edges[1:]):
  l,r=pi*A(F(aa,180)),pi*A(F(bb,180));m=(2*deg-aa-bb)//360;sign=(-1)**m
  n=max(1,(N*(bb-aa)+179)//180);step=(r-l)/n;mid=(l+r)/2
  assert t-mid-m*pi>0 and t-mid-m*pi<pi
  u=t-l-m*pi;su,cu=u.sin_cos();ds,dc=(-step).sin_cos()
  trig=[(k*l).sin_cos() for k,_,_ in poly];inc=[(k*step).sin_cos() for k,_,_ in poly]
  tmp=arb(0);M=(A('2.5')+pi/2)/pi+sum(k*k*(a*a+b*b).sqrt() for k,a,b in poly)
  for j in range(n+1):
   f=-sign*(-cu/2+(pi/2-u)*su)/pi-sum(a*c+b*s for (_,a,b),(s,c) in zip(poly,trig))
   tmp+=abs(f)*(one/2 if j in (0,n) else one)
   if j<n:
    u-=step;su,cu=su*dc+cu*ds,cu*dc-su*ds
    trig=[(s*cc+c*ss,c*cc-s*ss) for (s,c),(ss,cc) in zip(trig,inc)]
  total+=step*tmp+(r-l)*M*step**2/12
 return total
def area(faces,ids):
 assert ids==sorted(set(ids)) and min(ids)>=0 and max(ids)<len(faces)
 rr=[faces[i] for i in ids];v=[]
 for (a,b,e),(c,d,f) in zip(rr[-1:]+rr[:-1],rr):
  det=a*d-b*c;assert det>0
  v.append(((e*d-b*f)/det,(a*f-e*c)/det))
 for j,(x,y) in enumerate(v):
  for i,(a,b,f) in enumerate(rr):
   if i not in (j,(j-1)%len(rr)):assert a*x+b*y<f,(i,j)
 return sum(x[0]*y[1]-x[1]*y[0] for x,y in zip(v,v[1:]+v[:1]))/2
def verify(filename):
 D=load(filename);alpha=A(D['lower']);T=[[A(F(v,10**8)) for v in rr] for rr in D['T']];rows=D['rows'];assert [r[0] for r in rows]==list(range(0,360,D['step'])) and 0<alpha<2/pi
 assert len(T)==2 and len(T[0])==len(T[1])==20
 gaps=[];faces=[]
 for deg,cap,raw in rows:
  sy,cx=(pi*A(F(deg,180))).sin_cos();z=[cx*x+sy*y for x,y in zip(*T)];c,s,perp,plus,minus,w1,w2=[A(F(q,10**8)) for q in raw];assert min(plus,minus,w1,w2)>=0
  # -cos(5z) phase supports at +90 and -30 degrees.
  s1,c1=(pi/2).sin_cos();s2,c2=(-pi/6).sin_cos()
  base={1:(c,s),3:(plus-minus,perp),5:(w1*c1+w2*c2,w1*s1+w2*s2)}
  for i,k in enumerate(range(3,22,2)):
   aa,bb=base.get(k,(arb(0),arb(0)));base[k]=(aa+2*z[2*i]/pi,bb+2*z[2*i+1]/pi)
  poly=[(k,cc,ss) for k,(cc,ss) in base.items() if not (cc.is_zero() and ss.is_zero())]
  b=A(cap)
  for N in (480,1600,4096,8000):
   gap=(b-one/2+pi*alpha*plus/2-minus-avg_error(deg,poly,N)/2).lower()
   if gap>A('.0000001'):break
  assert gap>A('.0000001'),(filename,deg,str(gap));gaps.append(float(gap));faces.append((cx,sy,b))
 ar=area(faces,D['active']);assert ar<A('.844082046521218581802948589770767704354')
 return {'lower':D['lower'],'faces':len(D['active']),'area':str(ar),'min_gap':min(gaps)}
if __name__=='__main__':
 out=[verify(f) for f in load('cases.json')]
 if (root/'receipt.json').exists():assert out==load('receipt.json')
 print(json.dumps(out,indent=2))

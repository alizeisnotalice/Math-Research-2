"""Dyadic interval proof of the weighted distance from the null-moment interpolant."""
from flint import arb,ctx
from functools import lru_cache
import json
ctx.prec=160
pi=arb.pi()
# Use the exact rational in the bounds and in the endpoint calculation.
C=arb(3023)/5000
BASE=600
DEPTH=21
G=BASE*2**DEPTH
RAD=G//100
nodes=[G//6,G//2,5*G//6]
unit=pi/G
def domain(l,w):
    return arb(l+w/2,w/2)*unit
@lru_cache(None)
def segment(l,w,k=1):
    return (domain(l,w)*k).sin_cos()
@lru_cache(None)
def green(l,w):
    values=[];derivatives=[]
    for n in range(l//G,(l+w-1)//G+1):
        ll=max(l,n*G)-n*G
        rr=min(l+w,(n+1)*G)-n*G
        sign=1 if n%2==0 else -1
        s,c=segment(ll,rr-ll);z=domain(ll,rr-ll)
        values.append(sign*(-c/2+(pi/2-z)*s))
        derivatives.append(sign*(-s/2+(pi/2-z)*c))
    val=values[0]
    for v in values[1:]:val=val.union(v)
    return val,derivatives
@lru_cache(None)
def interpolant(t,w):
    y=[green(t-j,w)[0] for j in nodes]
    a=(y[0]-y[2])/arb(3).sqrt()
    b=(y[0]+y[2]+2*y[1])/3
    d=(y[0]-y[1]+y[2])/3
    return a,b,d
cutoff=C*(3*RAD*unit).sin()/(RAD*unit)
counts=[0]*(DEPTH+1)
minimum=arb(1)
def rectangle(t,z,w,depth):
    global minimum
    a,b,d=interpolant(t,w);s,c=segment(z,w);s3,c3=segment(z,w,3)
    S,ds=green(t-z-w,2*w)
    if min(abs(2*z+w-2*j) for j in nodes)<=2*RAD:
        pp=-a*s+b*c+3*d*c3
        gaps=[cutoff-abs(-dv-pp) for dv in ds]
    else:
        gaps=[C*abs(c3)-abs(S-a*c-b*s-d*s3)]
    if all(x>0 for x in gaps):
        counts[depth]+=1
        for x in gaps:minimum=minimum.min(x.lower())
        return
    assert depth<DEPTH,(t,z,w,depth)
    for x in (0,w//2):
        for y in (0,w//2):
            rectangle(t+x,z+y,w//2,depth+1)
w=2**DEPTH
for t in range(0,G//6,w):
    for z in range(0,G,w):
        rectangle(t,z,w,0)
assert sum(n*4**(DEPTH-i) for i,n in enumerate(counts))==(BASE**2//6)*4**DEPTH
B=arb('0.844082046521218581802948589770767704354')
area0=(pi-arb(3).sqrt())/2
rB=((1+4*(B-area0)/pi).sqrt()-1)/2
a=arb(49592)/100000
radius=C*(2/pi-a)/2
area=area0+pi*radius+pi*radius**2
assert area<B
print(json.dumps(dict(upper='0.6046',lower=str(pi/(3*arb(3).sqrt())),critical=str(2/pi-2*rB/C),
                      leaves_by_depth=counts,min_test_margin=str(minimum),test_amplitude='0.49592',
                      test_area=str(area)),indent=2))

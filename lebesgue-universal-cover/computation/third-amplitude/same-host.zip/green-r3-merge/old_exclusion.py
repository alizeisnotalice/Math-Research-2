"""Prove that the original sparse Green host cannot be repaired with the given area."""
import argparse
from fractions import Fraction as F
from pathlib import Path
from functools import cache
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C
from r3 import direction,material,J,sub
from flint import arb,ctx


class Check:
    def __init__(self,src,T,distance):
        self.data=json.loads(src.read_bytes());self.src=src
        self.n=self.data['directions'];self.N=C.normals(self.n);self.threshold=T;self.distance=distance
        self.b=list(map(C.A,self.data['supports']));self.v,_=C.exact_vertices(self.N,self.b)
        self.area,_=C.geometry(self.N,self.b)
        L=[]
        for j in range(self.n):
            a,b=sub(self.v[j],self.v[j-1]);L.append((a*a+b*b).sqrt())
        assert all(x>0 for x in L)
        cap=[C.A(distance)+C.A(2*T)/e for e in L]
        self.rhs=[b+x for b,x in zip(self.b,cap,strict=True)]
        self.indices=C.triples(self.n)
        self.w=[];self.const=[]
        for a,b,c in self.indices:
            u,v,w=[self.N[i] for i in (a,b,c)];pair=[C.det(v,w),C.det(w,u),C.det(u,v)]
            assert min(pair)>0
            s=sum(pair);pair=[x/s for x in pair]
            self.w.append(pair);self.const.append(sum(x*self.rhs[i] for x,i in zip(pair,(a,b,c),strict=True)))

    @cache
    def bound(self,lo,hi,j):
        points=[material(F(i,self.n)-(lo+hi)/2) for i in self.indices[j]]
        u,v=arb(0),arb(0)
        for i,x,p in zip(self.indices[j],self.w[j],points,strict=True):
            u+=x*C.dot(self.N[i],p);v+=x*C.dot(self.N[i],J(p))
        d=self.const[j];assert d>0
        out=[]
        for t in (lo,hi):
            s,c=C.sincos(2*t);h=u*c+v*s
            assert h>0
            out.append((h-d).lower())
        return min(out)

    def make(self):
        import numpy as np
        from r3 import float_support
        I=np.asarray(self.indices);W=np.array([[float(q.mid()) for q in x]for x in self.w]);rhs=np.array([float(x.mid()) for x in self.const]);theta=np.arange(self.n)*2*np.pi/self.n
        plan=[]
        def visit(l,r,k):
            a=float(l+r)*np.pi
            gap=np.sum(float_support(theta-a)[I]*W,axis=1)-rhs
            for j in np.argsort(-gap)[:7]:
                if self.bound(l,r,int(j))>0:
                    plan.append([str(l),str(r),int(j)]);return
            assert k<16,(l,r,gap.max())
            m=(l+r)/2;visit(l,m,k+1);visit(m,r,k+1)
        for i in range(24):visit(F(i,72),F(i+1,72),0)
        return plan

    def verify(self,plan):
        last=F(0);floor=None
        for l,h,j in plan:
            l,h=F(l),F(h);assert l==last and l<h<l+F(1,2)
            assert type(j) is int and 0<=j<len(self.indices)
            y=self.bound(l,h,j);assert y>0,(l,h,j,y)
            floor=y if floor is None else min(floor,y);last=h
        assert last==F(1,3) and floor>0
        return dict(complete=True,all_rigid_poses=True,area_budget_test=str(self.threshold),distance_test=str(self.distance),
                    closed_angle_cells=len(plan),weakest_normalized_remaining_gap=str(floor),B_remaining=str((C.A(C.B)-self.area).upper()),
                    area=str(self.area),host_sha256=C.sha(self.src),certified_to_exceed_B_if_retaining_old_host=bool(C.A(self.threshold)>C.A(C.B)-self.area))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('host',type=Path);p.add_argument('plan',type=Path)
    p.add_argument('out',type=Path);p.add_argument('--threshold',type=F,default=F('.002'));p.add_argument('--distance',type=F,default=F(0));p.add_argument('--make-plan',action='store_true');a=p.parse_args()
    assert __debug__ and min(a.threshold,a.distance)>=0 and not (a.threshold and a.distance);ctx.prec=160;C.P=arb.pi()
    x=Check(a.host,a.threshold,a.distance)
    if a.make_plan:
        plan=x.make();a.plan.write_text(json.dumps(plan,separators=(',',':'))+'\n')
    else:plan=json.loads(a.plan.read_bytes())
    r=x.verify(plan);r['plan_sha256']=C.sha(a.plan);r['verifier_sha256']=C.sha(Path(__file__))
    a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)

if __name__=='__main__':main()

"""Replay one host for the limited-curvature class, disk and true Reuleaux triangle."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import certify as C
import r3
from flint import arb, ctx, __version__ as flint_version

LINEAR_STABILITY = F(3023, 10000)


def run(data):
    n = data["directions"]
    supports = list(map(C.A, data["supports"]))
    normals = C.normals(n)
    pose = data["r3"]
    angle = F(pose["angle_degrees"]) / 360
    translation = tuple(map(C.A, pose["translation"]))
    disk_slack = min((b - C.H).lower() for b in supports)
    r3_slack = min(
        (b - r3.support(angle, F(i, n)) - C.dot(u, translation)).lower()
        for i, (b, u) in enumerate(zip(supports, normals, strict=True))
    )
    eta = F(data["r3_slack_claim"])
    eps = F(data["near_extremal_a3_deficit"])
    assert disk_slack > 0 and r3_slack > C.A(eta)
    assert 0 < eps < 1 and eta > 0 and LINEAR_STABILITY * eps < eta

    result = C.run(data)
    result.update(
        disk_slack=str(disk_slack),
        r3_slack=str(r3_slack),
        certified_r3_slack=str(eta),
        r3_pose=pose,
        high_third_floor=str(2 / C.P - C.A(eps)),
        near_extremal_a3_deficit=str(eps),
        linear_stability=str(LINEAR_STABILITY),
    )
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path)
    p.add_argument("receipt", type=Path)
    paths = p.parse_args()
    assert __debug__
    ctx.prec = 160
    C.P = arb.pi()
    data = json.loads(paths.input.read_bytes())
    result = run(data)
    result.update(
        precision=ctx.prec,
        python=platform.python_version(),
        flint=flint_version,
        input_sha256=C.sha(paths.input),
        source_sha256={x: C.sha(HERE / x) for x in ("certify.py", "r3.py", "verify_common.py")},
    )
    paths.receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()

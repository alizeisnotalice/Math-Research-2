"""True arc support and material points of the full Reuleaux triangle."""
from fractions import Fraction as F
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C
from flint import arb


def add(u,v):return u[0]+v[0],u[1]+v[1]


def sub(u,v):return u[0]-v[0],u[1]-v[1]


def mul(a,v):return a*v[0],a*v[1]


def J(v):return -v[1],v[0]


def direction(t):
    s,c=C.sincos(F(2)*t);return c,s


def vertex(j):return mul(1/arb(3).sqrt(),direction(F(j,3)))


def material(phi):
    phi%=1
    n=direction(phi)
    for j in range(3):
        t=(phi-F(j,3))%1
        if F(5,12)<=t<=F(7,12):return add(vertex(j),n)
    for j in range(3):
        t=(phi-F(j,3)+F(1,2))%1-F(1,2)
        if abs(t)<=F(1,12):return vertex(j)
    raise AssertionError(phi)


def support(theta,phi):
    n=direction(phi-theta)
    return C.dot(n,material(phi-theta))


def float_support(theta):
    import numpy as np
    a=(theta+np.pi/3)%(2*np.pi/3)-np.pi/3
    b=abs(a)
    # Closest corner for its 60-degree normal cone. On either adjacent arc,
    # the circle centre is the third corner opposite the outward normal.
    return np.where(b<=np.pi/6,np.cos(b)/np.sqrt(3),1+np.cos(b+2*np.pi/3)/np.sqrt(3))

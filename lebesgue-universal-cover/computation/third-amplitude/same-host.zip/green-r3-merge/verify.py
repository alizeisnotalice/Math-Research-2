"""Check the frozen inputs and replay all strict tests in the common-host package."""
import argparse
from fractions import Fraction as F
from flint import arb, ctx
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import certify as C
from old_exclusion import Check
from verify_common import LINEAR_STABILITY, run


def read(name):
    return json.loads((HERE / name).read_bytes())


def verify_input_hashes():
    for line in (HERE / "MANIFEST.sha256").read_text().splitlines():
        sha, name = line.split("  ", 1)
        assert C.sha(HERE / name) == sha, name


def common(name):
    src = HERE / f"common-{name}.json"
    receipt = read(f"common-{name}-receipt.json")
    assert C.sha(src) == receipt["input_sha256"]
    assert all(C.sha(HERE / f) == v for f, v in receipt["source_sha256"].items())
    actual = run(read(src.name))
    assert all(receipt[k] == v for k, v in actual.items())
    return actual


def old(name, stem, threshold, distance, cells):
    src = HERE / f"directed60{name}.json"
    plan = f"r3ex-{stem}-plan.json"
    reference = read(f"r3ex-{stem}.json")
    assert reference["plan_sha256"] == C.sha(HERE / plan)
    assert reference["verifier_sha256"] == C.sha(HERE / "old_exclusion.py")
    actual = Check(src, threshold, distance).verify(read(plan))
    assert all(reference[k] == v for k, v in actual.items())
    assert actual["closed_angle_cells"] == cells
    return actual


def stability():
    expected = read("stability-receipt.json")
    src = HERE / "stability.py"
    result = subprocess.run(
        [sys.executable, "-I", "-B", str(src)],
        capture_output=True,
        check=True,
        text=True,
    )
    actual = json.loads(result.stdout)
    assert actual == expected
    assert F(actual["upper"]) / 2 == LINEAR_STABILITY
    return actual


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("out", type=Path)
    args = p.parse_args()
    assert __debug__
    verify_input_hashes()
    ctx.prec = 160
    C.P = arb.pi()
    linear = stability()
    print("Weighted interval proof of the linear stability constant verified", flush=True)
    positive = {f: common(f) for f in ("amp", "near", "density", "thicker", "high")}
    negative = {
        "r70": old("r70", "strong-r70", F(".00275"), F(0), 24),
        "r7435": old("r7435", "strong-r7435", F(".0025"), F(0), 26),
        "r70-distance": old("r70", "r70-dist", F(0), F(".055"), 24),
    }
    assert negative["r70"]["certified_to_exceed_B_if_retaining_old_host"]
    assert negative["r7435"]["certified_to_exceed_B_if_retaining_old_host"]
    args.out.write_text(json.dumps(dict(status="PASS", stability=linear, common=positive, old=negative), indent=2) + "\n")
    print("PASS five common hosts, three all-angle old-host tests", flush=True)


if __name__ == "__main__":
    main()

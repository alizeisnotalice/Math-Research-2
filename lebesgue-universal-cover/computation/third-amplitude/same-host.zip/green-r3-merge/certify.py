"""Verify a common freely translated host with exact Green upper bounds on every extreme row."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from functools import cache
import json
from pathlib import Path
from flint import arb,ctx,__version__ as flint_version

B=F('0.844082046521218581802948589770767704354')
P=arb.pi()
H=arb(1)/2


def A(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def det(v,w):return v[0]*w[1]-v[1]*w[0]


def dot(v,w):return v[0]*w[0]+v[1]*w[1]


def sha(p):return sha256(p.read_bytes()).hexdigest()


def normals(n):
    out=[]
    for i in range(n):
        s,c=(P*A(F(2*i,n))).sin_cos();out.append((c,s))
    return out


def triples(N):
    return [t for t in combinations(range(N),3) if max(t[1]-t[0],t[2]-t[1],N+t[0]-t[2])*2<N]


def exact_vertices(n,b):
    v=[];small=None
    for i,(x,y) in enumerate(n):
        j=(i+1)%len(n);z,w=n[j];pivot=det((x,y),(z,w));assert pivot>0
        q=((b[i]*w-y*b[j])/pivot,(x*b[j]-b[i]*z)/pivot)
        v.append(q)
        for k,u in enumerate(n):
            if k not in (i,j):
                gap=(b[k]-dot(q,u)).lower()
                assert gap>0,(i,k,gap)
                small=gap if small is None else min(small,gap)
    return v,str(small)


def geometry(n,b):
    v,small=exact_vertices(n,b)
    return sum(det(a,b) for a,b in zip(v,v[1:]+v[:1],strict=True))/2,small


def steiner(n,b):
    v,_=exact_vertices(n,b)
    return tuple(sum(p[k] for p in v)/len(v) for k in range(2))


@cache
def sincos(x):return (P*A(x)).sin_cos()


@cache
def green(t):
    t%=2
    w=0 if t<1 else 1
    s,c=sincos(t-w)
    return ((-1)**w)*(H*c-(P/2-P*A(t-w))*s)/P


@cache
def table(N,M):
    assert M%(N//2)==0
    g=[[green(F(2*i,N)-F(j,M)) for j in range(M+1)] for i in range(N)]
    basis={k:[sincos(F(k*j,M)) for j in range(M+1)] for k in (1,3,5,7)}
    return g,basis


def param(src,D,region):
    assert len(src)==8 and all(type(a) is int for a in src)
    assert min(src[5:])>=0
    u,v,c,s,b5,a5,r,s2=[A(F(x,D)) for x in src]
    lo,hi=map(F,region)
    sn,cn=sincos(lo/180+F(1,2)); sr,cr=sincos(hi/180-F(1,2))
    z=[(u,v),(c,s),(a5,b5),(r*cn+s2*cr,r*sn+s2*sr)]
    return z


def norm(v):
    # Compute bound on the Euclidean magnitude even when a component spans zero.
    a,b=[abs(x).upper() for x in v]
    return (a*a+b*b).sqrt()


def error(N,M,idx,weights,p):
    g,d=table(N,M)
    con=(A('2.5')+P/2)/P+sum(k*k*norm(v) for k,v in zip((1,3,5,7),p,strict=True))
    a,b,c=g[idx[0]],g[idx[1]],g[idx[2]];w,v,z=weights
    pairs=list(zip(*(d[k] for k in (1,3,5,7)),strict=True))
    def gap(j):
        V=sum(c*sine+e*cosine for (e,c),(sine,cosine) in zip(p,pairs[j],strict=True))
        return abs(w*a[j]+v*b[j]+z*c[j]-V)
    D=gap(0)/2+gap(M)/2+sum(gap(j) for j in range(1,M))
    step=P/M
    return step*D+P*con*step**2/12


def run(data):
    n=data['directions'];assert type(n) is int and 12<=n<=120 and n%2==0
    radii=F(data['radius']);assert 0<=radii<=1
    density=F(data.get('density_factor','1'));assert 0<density<=1
    spectrum = [(radii, density)]
    for vertex in data.get('additional_parameter_vertices', []):
        r, d = [F(x) for x in vertex]
        assert 0 <= r <= 1 and 0 < d <= 1
        spectrum.append((r, d))
    coefficients = [(A(r), A(d)) for r, d in spectrum]
    angular=tuple(tuple(map(F,x)) for x in data['phase_regions'])
    assert angular and angular[0][0]==0 and angular[-1][1]==36
    assert all(h>l for l,h in angular) and all(a[1]==b[0] for a,b in zip(angular,angular[1:]))
    N=normals(n);b=list(map(A,data['supports']));assert len(b)==n and min(b)>0
    den=data['c_coeff_denom'];assert type(den) is int and den>0
    cls=triples(n)
    assert cls==list(map(tuple,data['triples']))
    opposite=min(((b[i]+b[i+n//2]-1)/2).lower() for i in range(n//2))
    assert opposite>0
    area,geomgap=geometry(N,b);assert area<A(B),(area,str(B))
    print('area verified',n,str(radii),area,'triples',len(cls),flush=True)
    least=None;groups=[None]*len(angular);checks=[0,0,0,0,0];margins=[]
    for k,(t,p0) in enumerate(zip(cls,data['coefficients'],strict=True)):
        assert len(p0)==len(angular)
        u,v,w=[N[i] for i in t];W=[det(v,w),det(w,u),det(u,v)];assert all(z>0 for z in W)
        constant=sum(W);T=[z/constant for z in W]
        rhs=sum(T[j]*b[t[j]] for j in range(3)); small=None
        for j,(y,reg) in enumerate(zip(p0,angular,strict=True)):
            p=param(y,den,reg)
            third=P*norm(p[1])/2
            for level,power in enumerate((8,16,32,64,128)):
                green_bound=error(n,power*n//2,t,T,p)/2
                val=min((rhs-H-r*third-d*green_bound).lower() for r,d in coefficients)
                if val>0:
                    checks[level]+=1
                    break
            assert val>0,(k,t,reg,str(val))
            groups[j]=val if groups[j] is None else min(groups[j],val)
            small=val if small is None else min(small,val)
        least=small if least is None else min(least,small)
        margins.append((float(small),list(t)))
    result=dict(complete=True,face_count=n,area=str(area),B_slack=str((A(B)-area).lower()),
                third_radius=str(radii),density_factor=str(density),phase_regions_degrees=data['phase_regions'],opposite_pairs=n//2,
                parameter_vertices=[[str(r),str(d)] for r,d in spectrum],
                complete_triples=len(cls),quadrature_resolution_histogram=checks,min_host_vertex_clearance=geomgap,
                min_joint_slack=str(least),minimum_opposite_slack=str(opposite),minimum_slack_by_phase=list(map(str,groups)),
                nearest_rows=[{'triple':t,'slack_float':v} for v,t in sorted(margins)[:10]])
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('receipt',type=Path);a=p.parse_args();assert __debug__;ctx.prec=160
    global P;P=arb.pi()
    t=run(json.loads(a.input.read_bytes()))
    t.update(input_sha256=sha(a.input),verifier_sha256=sha(Path(__file__)),precision=ctx.prec,flint=flint_version)
    a.receipt.write_text(json.dumps(t,indent=2)+'\n');print(json.dumps(t,indent=2),flush=True)

if __name__=='__main__':main()

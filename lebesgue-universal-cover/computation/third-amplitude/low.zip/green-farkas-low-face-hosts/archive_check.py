"""Stress test one host on the archived true curvature bodies, scaled only as needed."""
import argparse
from fractions import Fraction as F
import json,math,sys
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C
from profile_source import Profile,step


def mean(*x):return [t/2 for t in x]


def raw(h):
    data=Profile(h);P=C.P
    one1,one2=arb(0),arb(0)
    phase={k:[arb(0),arb(0)] for k in (3,5,7)}
    for j,(l,r,f) in enumerate(zip(data.knots,data.knots[1:],data.fs)):
        sl,cl=l.sin_cos();sr,cr=r.sin_cos();y,d=data.states[j]
        X=(y-f)*cl-d*sl;Y=(y-f)*sl+d*cl
        q=(r-l)/2;m=((2*r).sin()-(2*l).sin())/4
        k=(sr*sr-sl*sl)/2
        one1+=X*(q+m)+Y*k+f*(sr-sl)
        one2+=X*k+Y*(q-m)+f*(cl-cr)
        for n,item in phase.items():
            a,b=(n*l).sin_cos();u,v=(n*r).sin_cos()
            item[0]+=(u-a)*f*2/(n*P)
            item[1]+=(b-v)*f*2/(n*P)
    def h(phi):
        m=math.floor(float((phi/P).mid()));out=[]
        for j in range(m-1,m+2):
            th=phi-j*P
            if th<0 or th>P:continue
            for k,f in enumerate(data.fs):
                if th<data.knots[k] or th>data.knots[k+1]:continue
                h=step(data.states[k],f,th-data.knots[k])[0]
                out.append((-1)**j*h)
        assert out
        val=out[0]
        for k in out[1:]:val=val.union(k)
        s,c=phi.sin_cos()
        return val-2*(c*one1+s*one2)/P
    return phase,h


def spectral(d):
    vals={k:(C.A(a),C.A(b)) for k,a,b in d['curvature_modes']}
    def h(x):
        out=arb(0)
        for k,(a,b) in vals.items():
            s,c=(x*k).sin_cos();out+=(a*c+b*s)/(1-k*k)
        return out
    return {k:vals[k] for k in (3,5,7)},h


def one(name,source,N,b,radius,polynomial=False,preset=None):
    phase,h=spectral(source) if polynomial else raw(source)
    ar=lambda n:arb.atan2(-phase[n][1],phase[n][0])
    A3=C.norm(phase[3])
    s=F(preset['retained_share']) if preset else F(str(min(1.,.99*float(radius)/float(A3.mid())))).limit_denominator(10**9)
    assert 0<s<=1 and C.A(s)*A3<C.A(radius)
    if polynomial:
        f=[(k,C.A(a)*C.A(s),C.A(b)*C.A(s)) for k,a,b in source['curvature_modes']]
        count=4096
        high=max(abs(sum(a*C.sincos(F(j*k,count))[1]+q*C.sincos(F(j*k,count))[0] for k,a,q in f)).upper()
                 for j in range(count+1))
        error=sum(k*k*(abs(a)+abs(q)) for k,a,q in f)*(C.P/count)**2/8
        assert high+error<C.H
    picks=[(preset['hand'],preset['rotation_integer'])] if preset else [(h,k) for h in (1,-1) for k in range(5)]
    for hand,k in picks:
        assert hand in (1,-1) and type(k) is int and 0<=k<5
        angle=(hand*ar(5)+2*C.P*k)/5
        arg=7*angle-hand*ar(7)
        cycle=round(float((arg/(2*C.P)).mid())-.25)
        a=arg-2*C.P*cycle
        if not (0<a<C.P/5):continue
        H=[C.H+C.A(s)*h(hand*(C.P*C.A(F(2*j,N))-angle)) for j in range(N)]
        normal=C.normals(N)
        if preset:
            T=list(map(F,preset['translation']))
        else:
            import numpy as np
            from scipy.optimize import linprog
            q=np.asarray([[float(x.mid()) for x in u] for u in normal]);g=np.array([float((v-w).mid()) for v,w in zip(b,H,strict=True)])
            p=linprog([0,0,1],A_ub=np.c_[q,-np.ones(N)],b_ub=g,bounds=[(None,None)]*3,method='highs');assert p.success
            T=[F(format(v,'.15f'))for v in p.x[:2]]
        dt=[(v-w-C.dot(u,list(map(C.A,T)))).lower() for v,w,u in zip(b,H,normal,strict=True)]
        assert all(x>0 for x in dt)
        st=C.steiner(normal,b)
        dc=min((w-v-C.dot(st,u)).lower()for w,v,u in zip(b,H,normal,strict=True))
        return dict(body=name,retained_share=str(s),phase_degrees=str(180*a/C.P),hand=hand,rotation_integer=k,
                    A3_original=str(A3),centered_min_directed_gap=str(dc),free_min_directed_gap=str(min(dt)),translation=list(map(str,T)))
    raise ValueError(name+' no isolated five-seven phase')


def replay(host,recipes):
    N=host['directions'];b=list(map(C.A,host['supports']));r=F(host['radius'])
    sources=json.loads((HERE/'library.json').read_bytes());p={x['body']:x for x in recipes['bodies']}
    assert set(p)==set(sources)|{'archived-93'}
    out=[one(name,body,N,b,r,preset=p[name]) for name,body in sources.items()]
    out.append(one('archived-93',json.loads((HERE/'archived-93.json').read_bytes()),N,b,r,True,p['archived-93']))
    return dict(complete=True,checked=len(out),bodies=out,library_sha256=C.sha(HERE/'library.json'),
                archived_93_sha256=C.sha(HERE/'archived-93.json'))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('host',type=Path);p.add_argument('receipt',type=Path);a=p.parse_args()
    assert __debug__;ctx.prec=160;C.P=arb.pi()
    host=json.loads(a.host.read_bytes());N=host['directions'];b=list(map(C.A,host['supports']));r=F(host['radius'])
    sources=json.loads((HERE/'library.json').read_bytes());raw=[];errors=[]
    for name,body in sources.items():
        try:raw.append(one(name,body,N,b,r))
        except (AssertionError,ValueError) as e:errors.append([name,str(e)])
    raw.append(one('archived-93',json.loads((HERE/'archived-93.json').read_bytes()),N,b,r,True))
    data=dict(complete=True,host_sha256=C.sha(a.host),source_library_sha256=C.sha(HERE/'library.json'),
              checked=len(raw),not_certified=errors,bodies=raw)
    a.receipt.write_text(json.dumps(data,indent=2)+'\n');print('checked',len(raw),'not certified',errors,flush=True)

if __name__=='__main__':main()

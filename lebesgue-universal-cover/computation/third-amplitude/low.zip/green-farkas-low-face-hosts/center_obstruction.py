"""Necessary area for the specified centred canonical orientations on the 30-angle grid."""
import argparse
from fractions import Fraction as F
from pathlib import Path
import json,sys
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C


def run(bank,n,r):
    assert len(bank)==n
    norma=C.normals(n)
    goals=[C.H for _ in norma]
    slack=None
    Q=8192
    def value(k,ab,m):
        sn,cs=C.sincos(k*m)
        return ab[0]*cs+ab[1]*sn
    for data in bank:
        D=data['denominator'];vs=[(k,F(a,D),F(b,D))for k,a,b in data['spectrum']]
        assert [k for k,_,_ in vs]==list(range(3,data['degree']+1,2))
        a3,b3=vs[0][1:];assert a3*a3+b3*b3<=r*r
        assert vs[1][1]>0 and vs[1][2]==0
        assert vs[2][1]>=0 and 0<=vs[2][2]<=F(7,10)*vs[2][1]
        u,v=C.sincos(F(1,5));assert u/v>C.A(F(7,10))
        ss=[(k,(C.A(a),C.A(b)))for k,a,b in vs]
        H2=sum(k*k*(abs(a)+abs(b)) for k,(a,b) in ss)
        val=max(abs(sum(value(k,ab,F(j,Q))for k,ab in ss)).upper() for j in range(Q+1))
        m=(C.H-val-H2*(C.P/Q)**2/8).lower();assert m>0
        slack=m if slack is None else min(m,slack)
        for j in range(n):
            y=C.H+sum(value(k,ab,F(2*j,n))/(1-k*k) for k,ab in ss)
            goals[j]=max(goals[j],y.lower())
    # Round the necessary face requirements inwards, so the area is one-sided.
    denom=10**13
    offs=[F(int((y.lower()*denom).lower().floor().unique_fmpz()),denom)for y in goals]
    low,vg=C.geometry(norma,list(map(C.A,offs)))
    assert low>C.A(C.B),(low,str(C.B))
    return dict(complete=True,scope='all 30 canonical normal directions with each body in its supplied Steiner-centred orientation',
                true_bodies=len(bank),directions=n,third_radius=str(r),absolute_area_lower=str(low.lower()),
                out_of_budget=str((low-C.A(C.B)).lower()),minimum_radius_margin=str(slack),minimum_face_vertex_slack=vg,
                supports=list(map(str,offs)))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('bank',type=Path);p.add_argument('out',type=Path);a=p.parse_args();assert __debug__
    ctx.prec=160;C.P=arb.pi()
    data=run(json.loads(a.bank.read_bytes()),30,F('.06'));data.update(input_sha256=C.sha(a.bank),source_sha256=C.sha(Path(__file__)))
    a.out.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2),flush=True)

if __name__=='__main__':main()

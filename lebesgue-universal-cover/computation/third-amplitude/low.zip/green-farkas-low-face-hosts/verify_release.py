"""Replay continuous free-translation certificates and exact centred controls."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys
from flint import arb,ctx,__version__ as flint_version
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C
import regression
import center_obstruction
import archive_check


def read(p):return json.loads(p.read_bytes())


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('out',type=Path);a=p.parse_args();assert __debug__
    ctx.prec=160;C.P=arb.pi()
    cases=read(HERE/'cases.json');results={}
    for name in cases:
        f=HERE/name;r=C.run(read(f));r['input_sha256']=C.sha(f);results[name]=r
        print('continuous certificate',name,r['area'],r['min_joint_slack'],flush=True)
    host=read(HERE/'directed30r60.json')
    chart=regression.verify(host,read(HERE/'witness-30r60.json'))
    centered=center_obstruction.run(read(HERE/'centered-bank30.json'),30,F('.06'))
    inherited=archive_check.replay(host,read(HERE/'archived-check30r60.json'))
    print('centred necessary area',centered['absolute_area_lower'],'true archived bodies',inherited['checked'],flush=True)
    names=cases+['verify_release.py','certify.py','regression.py','center_obstruction.py','archive_check.py',
                'profile_source.py','library.json','archived-93.json','archived-check30r60.json','centered-bank30.json',
                'witness-30r60.json','cases.json']
    out=dict(complete=True,continuous_hosts=results,centered_control=chart,center_fixed_protocol=centered,archived_regressions=inherited,
        source_sha256={name:C.sha(HERE/name) for name in names},python=platform.python_version(),flint=flint_version,precision=ctx.prec)
    a.out.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

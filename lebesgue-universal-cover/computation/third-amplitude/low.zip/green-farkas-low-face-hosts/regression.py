"""Construct and check a true spectrum that uses the translation freedom of the low-face host."""
import argparse
from fractions import Fraction as F
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import certify as C
from flint import arb,ctx


def find(host,out,bank_file=None):
    import numpy as np
    from scipy.optimize import linprog
    n=host['directions'];r=float(F(host['radius']));b=np.array(list(map(lambda x:float(F(x)),host['supports'])))
    phase=np.arange(n)*2*np.pi/n;N=np.c_[np.cos(phase),np.sin(phase)]
    deg=31;K=np.arange(3,deg+1,2);d=len(K)
    z=np.pi*np.arange(1200)/1200
    Z=np.c_[np.cos(z[:,None]*K),np.sin(z[:,None]*K)]
    A0=np.zeros((64,2*d));angles=np.arange(64)*2*np.pi/64
    A0[:,0]=np.cos(angles);A0[:,d]=np.sin(angles)
    match=np.zeros(2*d);match[2]=-.7;match[d+2]=1
    R=np.r_[Z,-Z,A0,match[None,:]]
    bounds0=np.r_[np.ones(2*len(z))*.498,np.ones(64)*r*np.cos(np.pi/64)*.9999,0]
    bs=[(None,None)]*(2*d);bs[1]=(.000001,None);bs[d+1]=(0,0);bs[2]=(0,None);bs[d+2]=(0,None)
    S=np.c_[np.cos(phase[:,None]*K),np.sin(phase[:,None]*K)]/np.tile(1-K*K,2)
    best=None;bank=[]
    st=np.array([float(x.mid()) for x in C.steiner(C.normals(n),list(map(C.A,host['supports'])))])
    def round_body(x):
        q=np.rint(x*1e12).astype(np.int64)
        q[d+1]=0
        q[d+2]=max(0,min(int(q[d+2]),int(q[2])*7//10))
        return [[int(k),int(q[i]),int(q[d+i])] for i,k in enumerate(K)]
    for j in range(n):
        p=linprog(-S[j],A_ub=R,b_ub=bounds0,bounds=bs,method='highs')
        assert p.success
        x=p.x;val=.5+S@x+N@st-b;k=int(val.argmax())
        bank.append({'degree':deg,'denominator':10**12,'spectrum':round_body(x)})
        pair=(val[k],k,x)
        if best is None or pair[0]>best[0]:best=pair
    m,j,x=best
    t=linprog([0,0,1],A_ub=np.c_[N,-np.ones(n)],b_ub=b-.5-S@x,bounds=[(None,None)]*3,method='highs');assert t.success
    a=dict(degree=deg,denominator=10**12,spectrum=round_body(x),
            translation=[str(F(format(p,'.14f')))for p in t.x[:2]],blocked_face=int(j),
            approximation_center_violation=float(m),approximation_free_violation=float(t.fun))
    out.write_text(json.dumps(a,indent=2)+'\n');print(a['blocked_face'],m,t.fun,flush=True)
    if bank_file:bank_file.write_text(json.dumps(bank,separators=(',',':'))+'\n')


def verify(host,body):
    n=host['directions'];r=F(host['radius']);D=body['denominator'];a=body['spectrum'];t=list(map(C.A,body['translation']))
    vals=[(k,F(u,D),F(v,D))for k,u,v in a]
    assert [k for k,u,v in vals]==list(range(3,body['degree']+1,2))
    assert vals[0][1]**2+vals[0][2]**2<=r*r
    assert vals[1][1]>0 and vals[1][2]==0
    assert vals[2][1]>=0 and 0<=vals[2][2]<=F(7,10)*vals[2][1]
    sn,cs=C.sincos(F(1,5));assert sn/cs>C.A(F(7,10))
    f=[(k,C.A(x),C.A(y))for k,x,y in vals]
    N=8192
    def value(theta,coeff):
        out=arb(0)
        for k,a,b in coeff:
            sn,cs=C.sincos(theta*k)
            out+=a*cs+b*sn
        return out
    high=max(abs(value(F(j,N),f)).upper() for j in range(N+1))
    second=sum(k*k*(abs(a)+abs(b)) for k,a,b in f)
    rad=C.H-high-second*(C.P/N)**2/8;assert rad>0
    normal=C.normals(n);sup=list(map(C.A,host['supports']))
    h=[(k,a/(1-k*k),b/(1-k*k)) for k,a,b in f]
    slack=[];s=C.steiner(normal,sup)
    for i,u in enumerate(normal):
        val=C.H+value(F(2*i,n),h)
        if i==body['blocked_face']:
            miss=(val+C.dot(u,s)-sup[i]).lower();assert miss>0
        gap=(sup[i]-val-C.dot(t,u)).lower();assert gap>0,(i,gap)
        slack.append(gap)
    return dict(complete=True,degree=body['degree'],radius_margin=str(rad.lower()),support_excess_at_steiner_center=str(miss),
                blocked_face=body['blocked_face'],minimum_slack_after_common_translation=str(min(slack)),translation=body['translation'],
                third_amplitude_squared=str(vals[0][1]**2+vals[0][2]**2),
                translation_from_aligned_centers=[str(x-y) for x,y in zip(t,s,strict=True)])


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('host',type=Path);p.add_argument('spectrum',type=Path)
    p.add_argument('receipt',type=Path);p.add_argument('--find',action='store_true');p.add_argument('--bank',type=Path);a=p.parse_args();assert __debug__
    ctx.prec=160;C.P=arb.pi()
    config=json.loads(a.host.read_bytes())
    if a.find:find(config,a.spectrum,a.bank)
    data=verify(config,json.loads(a.spectrum.read_bytes()));data.update(host_sha256=C.sha(a.host),spectrum_sha256=C.sha(a.spectrum),source_sha256=C.sha(Path(__file__)))
    a.receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2),flush=True)

if __name__=='__main__':main()

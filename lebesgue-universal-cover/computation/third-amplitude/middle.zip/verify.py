"""Farkas certificate for a width-one translate in the specified common polygon."""
from pathlib import Path
from fractions import Fraction
import itertools, json, sys
import numpy as np
from flint import ctx, arb

ctx.prec=192
root=Path(__file__).resolve().parent
pi=arb.pi()
Q=10**8
M=60
N=960
alpha=arb(7435)/100000
beta=arb(16259)/100000
read=lambda name:json.loads((root/name).read_bytes())

def grid_integer(x):
    y=round(float(x)*Q)
    assert abs(x-arb(y)/Q)<arb(1)/Q
    return y

def support_table():
    f=[]; moments=[]
    for l in range(N+1):
        z=pi*l/N
        moments.append([grid_integer(v) for v in (z.cos(),z.sin(),(3*z).sin(),(3*z).cos(),
                           (5*z-pi/2).cos(),(5*z+pi/6).cos())])
    for i in range(M):
        row=[]
        for l in range(N+1):
            phase=2*i*N//M-l
            k,r=divmod(phase,N);v=pi*r/N
            S=-v.cos()/2+(pi/2-v)*v.sin()
            row.append(grid_integer((-1 if k%2==0 else 1)*S/pi))
        f.append(row)
    f=np.array(f,dtype=np.int64);moments=np.array(moments,dtype=np.int64)
    assert np.max(abs(f))<Q and np.max(abs(moments))<=Q
    return f,moments

def area(faces,active):
    p=[]
    assert active==sorted(set(active))
    for ii,jj in zip(active[-1:]+active[:-1],active):
        x,y,a=faces[ii]; u,v,b=faces[jj];det=x*v-y*u
        assert det>0
        p.append(((a*v-y*b)/det,(x*b-a*u)/det))
    for j,(x,y) in enumerate(p):
        for k,(a,b,c) in enumerate(faces):
            if k not in (active[j-1],active[j]):assert a*x+b*y<c
    return sum(x*v-y*u for (x,y),(u,v) in zip(p,p[1:]+p[:1]))/2

def main():
    d=read('middle-host.json');b=[arb(x)/10**10 for x in d['cap']]
    assert len(b)==M and all(b[i]+b[i+M//2]>1 for i in range(M//2))
    faces=[((2*pi*i/M).cos(),(2*pi*i/M).sin(),b[i]) for i in range(M)]
    ar=area(faces,d['active']);assert ar<arb('0.844082046521218581802948589770767704354')
    rows=read('dual-60-0.07435-0.16259.json');index=0;weak=arb(1);critical=arb(0);end=arb(1);f,moments=support_table()
    sins=[(2*pi*i/M).sin() for i in range(M)]
    for i,j,k in itertools.combinations(range(M),3):
        dif=(k-j,M+i-k,j-i)
        if max(dif)>=M//2:continue
        ii,jj,kk,*p=rows[index];assert (i,j,k)==(ii,jj,kk) and len(p)==6
        index+=1
        assert min(p[4:])>=0 and max(map(abs,p))<Q
        ww=[sins[n] for n in dif];total=sum(ww);ww=[w/total for w in ww];assert all(w>0 for w in ww)
        wi=np.array([grid_integer(w) for w in ww],dtype=np.int64);assert np.max(abs(wi))<=Q
        pvec=np.array(p,dtype=np.int64)
        # All nine products have magnitude at most Q^2. Their sum fits signed 64 bits.
        v=abs(wi@f[[i,j,k]]-moments@pvec)
        # Accumulate the trapezoid numerator in Python arbitrary-precision integers.
        tr=2*sum(map(int,v))-int(v[0])-int(v[-1])
        err=(4+arb(sum(map(abs,p)))/Q)/Q
        deriv=(arb(5)/2+pi/2)/pi+sum(n*n*arb(abs(c))/Q for n,c in zip([1,1,3,3,5,5],p))
        norm=pi*(arb(tr)/(2*N*Q**2)+err+deriv*(pi/N)**2/12)
        rhs=arb(1)/2+norm/2-pi*(alpha if p[3]>0 else beta)*p[3]/(2*Q)
        gap=sum(w*b[a] for w,a in zip(ww,(i,j,k)))-rhs
        assert gap>0,(i,j,k,str(gap));weak=weak.min(gap)
        if p[3]>0:critical=critical.max(alpha-2*Q*gap/(pi*p[3]))
        elif p[3]<0:end=end.min(beta-2*Q*gap/(pi*p[3]))
    assert index==len(rows)
    print(json.dumps(dict(faces=len(d['active']),pairs=M//2,triangles=index,area=str(ar),
                          lower='0.07435',upper='0.16259',lower_critical=str(critical),upper_critical=str(end),min_gap=str(weak),quadrature_intervals=N),indent=2))
if __name__=='__main__':main()

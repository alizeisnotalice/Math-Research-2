"""Inradius obstruction for the frozen 44-face high-amplitude host."""
from pathlib import Path
import json
from flint import arb,ctx
ctx.prec=192
pi=arb.pi()
source=json.loads((Path(__file__).parent/'high-cap-triple.json').read_bytes())
ids=[1,23,38]
assert source['indices']==ids and len(source['caps'])==3
weights=[(2*pi*j/60).sin() for j in [15,23,22]]
assert all(x>0 for x in weights)
rmax=sum(w*b for w,b in zip(weights,source['caps']))/(sum(weights)*10**10)
raw=[96388,-25103,8966,-2636,436]
coeff=[arb(x)/10**7 for x in raw]
m=[1,3,5,7,9]
N=1536
def maxabs(c):
    best=arb(0)
    for i in range(N+1):
        v=sum(v*(pi*i*n/N).cos() for n,v in zip(m,c))
        best=best.max(abs(v).upper())
    return best+sum(abs(v)*n*n for n,v in zip(m,c))*(pi/N)**2/8
sup=maxabs(coeff);curv=maxabs([v*(1-9*n*n) for v,n in zip(coeff,m)])
rmin=arb(1)/2-sup;A=8*coeff[0]
assert curv<arb(1)/2 and rmin>rmax and A>arb('.0771')
print(json.dumps(dict(A3=str(A),upper_support_perturbation=str(sup),curvature_deviation_bound=str(curv),
                      shape_inradius_lower=str(rmin),host_inradius_upper=str(rmax),difference=str(rmin-rmax)),indent=2))

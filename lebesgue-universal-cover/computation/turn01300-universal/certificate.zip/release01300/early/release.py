"""Freeze the finished partial theorem and validate the isolated archive."""
import json,subprocess,sys,zipfile
from pathlib import Path
from flint import arb
root=Path(__file__).resolve().parent
def call(argv,cwd=root):subprocess.run([sys.executable,'-I','-B',*map(str,argv)],cwd=cwd,check=True)
call(['audit_bins.py','audit.json'])
d=json.loads((root/'audit.json').read_bytes())['bins']
stats={n:sum(v[n] for v in d.values()) for n in ['rows','physical_cells','placed_leaves','root_free_leaves','empty_conditionals']}
print(stats)
for n in ['root_lower','placement_lower']:
 print(n,min((arb(v[n]).lower(),j) for j,v in d.items()),flush=True)
marker='\n## 全段复核结果\n'
readme=root/'README.md';t=readme.read_text().split(marker)[0]
stats_line=f"32 个参考格均已覆盖，共 {stats['physical_cells']} 个实际物理细格，选用 {stats['rows']} 个闭分支分类块。逐叶共有 {stats['placed_leaves']} 个共同摆放角叶、{stats['root_free_leaves']} 个严格排根角叶。{stats['empty_conditionals']} 个对象、分支和物理块的交集由严格比较判空。"
readme.write_text(t+marker+'\n'+stats_line+'\n')
call(['pack.py'])
z=root.parent/'nov19-ah01250-j0-31.zip'
stage=root/'isolated-release'
stage.mkdir(exist_ok=True)
with zipfile.ZipFile(z) as h:h.extractall(stage)
call(['replay.py',stage/'scratch'],stage/'kit')

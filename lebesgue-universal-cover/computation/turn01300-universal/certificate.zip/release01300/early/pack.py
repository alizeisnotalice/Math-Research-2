"""Assemble only the frozen calculation sources, their six parameters, and selected receipts."""
from pathlib import Path
import hashlib,json,sys,zipfile
root=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def put(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
whole=read(root/'audit.json')
assert whole['all_requested'] and len(whole['bins'])==32
jobs=read(root/'jobs.json')
registry=[dict(bin=x['j'],argv=x['argv'][:-1],output=x['argv'][-1]) for x in jobs]
for j in [26,31]:
    script='certify_refined31.py' if j==31 else 'certify_j31_sharp.py'
    registry.append(dict(bin=j,argv=[script,'comp012',f'config-0125-{j}.json'],output=f'output-{j}.json'))
for j in range(32):
    if whole['bins'][str(j)]['supplement_sha256']:
        registry.append(dict(bin=j,argv=['certify_supplement.py','comp012',f'config-supp-{j}.json'],output=f'supplement-{j}.json'))
registry.sort(key=lambda x:(x['bin'],x['output']))
put(root/'registry.json',registry)
files={root/x for x in ['audit_bins.py','replay.py','README.md','registry.json','audit.json','ordered_state.py','ordered_derivative.py','sharp_first_hit.py','first-hit-budget-proof.md','ah-two-budget-dihedral.md','physical-0125.json','geometry-area.json','geometry-gamma.json']}
for job in registry:
    files.add(root/job['output'])
    for argv in job['argv']:
        if (root/argv).is_file():files.add(root/argv)
files.update((root/'comp012').glob('*.py'));files.update((root/'comp012').glob('*.json'))
put(root/'manifest.json',{str(f.relative_to(root)):sha(f) for f in sorted(files)})
files.add(root/'manifest.json')
release=root.parent/'nov19-ah01250-j0-31.zip'
with zipfile.ZipFile(release,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(files):z.write(f,'kit/'+str(f.relative_to(root)))
print('files',len(files),'bytes',release.stat().st_size,'sha256',sha(release))

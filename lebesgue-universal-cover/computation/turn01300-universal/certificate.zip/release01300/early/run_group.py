from pathlib import Path
import json,sys,subprocess
D=Path(__file__).resolve().parent;jobs=json.loads((D/'jobs.json').read_bytes())
selected=[int(x) for x in sys.argv[1:]]
for j in selected:
 job=next(x for x in jobs if x['j']==j)
 with (D/f'run-{j}.log').open('w') as f:
  r=subprocess.run([sys.executable,'-I','-B',*job['argv']],cwd=D,stdout=f,stderr=subprocess.STDOUT)
 print(j,r.returncode,flush=True)

from pathlib import Path
import json
from flint import arb
root=Path(__file__).resolve().parent
for j in range(32):
    f=root/f'output-{j}.json'
    if not f.exists():continue
    x=json.loads(f.read_bytes())
    if not x.get('complete'):continue
    bad=[t for t in x['rows'] if not all(arb(t['row'][n])>0 for n in ['root_margin_lower','placement_margin_lower'])]
    s=root/f'supplement-{j}.json'
    print(j,len(x['rows']),len(bad),str(s.exists()), sorted({(t['orientation'],t.get('angle_class',t.get('initial_derivative_sign')),tuple(t['counts'])) for t in bad}))

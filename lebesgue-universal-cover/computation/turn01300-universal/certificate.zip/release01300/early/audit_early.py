"""Audit the 16 completed .01300 early bins; execute from any directory."""
import json
from pathlib import Path
from flint import ctx
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_bins_013 import audit
ctx.prec=128
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent/'audit-013-j0-15.json'
result={str(j):audit(j) for j in range(16)}
assert all(x is not None and not x['bad'] for x in result.values())
out.write_text(json.dumps(result,indent=2)+'\n')
print('PASS: 16 bins,',sum(x['physical_cells'] for x in result.values()),'cells,',sum(x['rows'] for x in result.values()),'classes')

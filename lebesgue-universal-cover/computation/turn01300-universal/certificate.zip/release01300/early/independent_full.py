"""Recompute each of the 33 raw receipts from a freshly extracted, hash-bound kit."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from datetime import datetime,timezone
from time import monotonic
import subprocess,sys,hashlib,json,traceback,zipfile
D=Path(__file__).resolve().parent
archive=D.parent/'nov19-ah01250-j0-31.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source_hash='168383b95bd4166cc88d6281b490345449bd0dc7d96c5f9348206a82336b59a5'
assert sha(archive)==source_hash
target=D/'independent33';target.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:z.extractall(target)
base=target/'kit';scratch=target/'computed';scratch.mkdir(exist_ok=True)
def timestamp():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(p.read_bytes())
def save(file,value):
    tmp=file.with_suffix('.pending')
    tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(file)
for name,h in read(base/'manifest.json').items():assert sha(base/name)==h
registry=read(base/'registry.json')
order=[24,25,27,28,29,30,26,31,23,22,21,20,0,1,2,3,19,18,17,16,4,5,6,7,8,9,10,11,12,13,14,15]
def key(t):return order.index(t['bin']),int(t['output'].startswith('supplement'))
def job(t):
    out=scratch/t['output'];log=out.with_suffix('.log')
    assert out.resolve()!= (base/t['output']).resolve()
    expected=sha(base/t['output']);start=timestamp();timer=monotonic()
    try:
        with log.open('w') as h:
            r=subprocess.run([sys.executable,'-I','-B',*t['argv'],str(out)],cwd=base,stdout=h,stderr=subprocess.STDOUT)
        raw=sha(out) if out.exists() else None
        return dict(bin=t['bin'],output=t['output'],started_utc=start,ended_utc=timestamp(),elapsed_seconds=round(monotonic()-timer,4),exit_code=r.returncode,expected_sha256=expected,recomputed_sha256=raw,byte_identical=raw==expected and r.returncode==0)
    except Exception as exc:
        return dict(bin=t['bin'],output=t['output'],started_utc=start,ended_utc=timestamp(),elapsed_seconds=round(monotonic()-timer,4),error=repr(exc),byte_identical=False)
def main():
    rows=[];watch=monotonic();start=timestamp();ordered=sorted(registry,key=key)
    def publish(complete):
        records=sorted(rows,key=lambda r:(r['bin'],r['output']))
        save(target/'ledger.json',dict(archive_sha256=source_hash,registry_sha256=sha(base/'registry.json'),audit_sha256=sha(base/'audit.json'),python=sys.version,started_utc=start,updated_utc=timestamp(),elapsed_seconds=round(monotonic()-watch,4),requested=len(registry),recomputed=len(rows),byte_identical=sum(r['byte_identical'] for r in rows),failed=[r['output'] for r in rows if not r['byte_identical']],all_complete=complete,rows=records))
    publish(False)
    with ThreadPoolExecutor(max_workers=int(sys.argv[1])) as pool:
        futures=[pool.submit(job,t) for t in ordered]
        for f in as_completed(futures):
            r=f.result();rows.append(r);publish(False);print(r['output'],r['byte_identical'],r['elapsed_seconds'],flush=True)
    assert all(r['byte_identical'] for r in rows) and len(rows)==33
    subprocess.run([sys.executable,'-I','-B','audit_bins.py',str(scratch/'audit.json')],cwd=base,check=True)
    assert sha(scratch/'audit.json')==sha(base/'audit.json')
    publish(True)
if __name__=='__main__':main()

"""Join the .01300 tail's exact closed physical ranges, true partners and EH transfer."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

from flint import arb,ctx

PARTITIONS=((40,46),(47,53),(54,61),(62,69))
GEOM='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7'
BRANCHES=('zero','all_e')
HOLDOUT={40:75,41:75,42:75,43:30}
MARGINS=('root_margin_lower','placement_margin_lower')
RETREAT=F('.00000009488')
POSES={f'{t},{s}' for t in range(0,360,60) for s in (-1,1)}


def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()


def compose(work,comp):
    ctx.prec=160
    ph=work/'physical-0130.json'
    area=work/'weighted-area-0130.json'
    params=read(ph);A=read(area)
    assert params==A['parameters']==dict(sigma_degrees='1.54',line=['.429','.01300'],physical_parameters=['.336','.383','.018'])
    chart=A['chart']
    assert chart['geometry_sha256']==GEOM and F(chart['physical_graph_endpoint'])==F('.62')
    assert chart['reference_subcells']==5184 and chart['reference_ranges']['69']==[[0,9]]
    elev,=[row for row in A['geometry']['cases'] if row['label']=='eleven']
    eh=comp/'sigma154-ah429-eh-chain997-composition.json'
    assert sha(eh)==A['geometry']['EH_first'][eh.name]=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
    cost=F(read(eh)['transfer_cost']['exact'][1])
    assert 0<cost==F(elev['transfer_cost_upper'])<RETREAT
    rp=work/'rescue'/'final.json'
    repair=read(rp)
    assert repair['complete'] and repair['geometry_sha256']==GEOM and repair['parameters']==params
    assert repair['closed_five_blocks']==51 and repair['physical_subcells']==255
    assert F(repair['EH_retreat'])==RETREAT and F(repair['EH_cost_upper'])==cost
    assert repair['necessary_for_actual_positive_mate']['first_deficit']=='>(3/4)Fsharp'
    assert repair['necessary_for_actual_positive_mate']['fourth_order_coordinate']=='>3/4'
    assert all(arb(v)>0 for v in repair['necessary_for_actual_positive_mate']['true_cut_margins'].values())
    assert all(arb(v)>0 for b in repair['actual_mate_branches'].values() for v in b['minima'].values())
    for f,h in repair['source_sha256'].items(): assert sha(work/f)==h
    holdouts={(j,i) for j,end in HOLDOUT.items() for i in range(end)}
    repairs={(r['bin'],*r['indices']):tuple(map(F,r['w'])) for r in repair['closed_bounds']}
    assert set(repairs)=={(j,k,k+5) for j,end in HOLDOUT.items() for k in range(0,end,5)}
    cells=blocks=cover_blocks=0
    margins={n:[] for n in BRANCHES}
    source={}
    per_bin=[]
    kernels=set()
    minimum_partner=arb(1)
    nominal_partner=arb(1)
    min_det={n:arb(1) for n in ('front_tube','partner_tube')}
    min_sep={n:arb(4) for n in min_det}
    max_sep={n:arb(0) for n in min_det}
    for first,last in PARTITIONS:
        partner=work/f'partner-{first}-{last}.json'
        raw=work/f'tail-{first}-{last}.json'
        p=read(partner);q=read(raw)
        assert p['complete'] and p['geometry_sha256']==GEOM and p['physical_parameters']==params
        assert p['orientation']==0 and p['verifier_sha256']==sha(work/'partner_retention.py')
        assert p['cut_rows']==[f'AH-line:{i}' for i in range(4)]
        expected=[(j,i) for j in range(first,last+1) for i in range(75)]
        assert [(r['j'],r['i']) for r in p['cases']]==expected
        raw_partner={}
        for r in p['cases']:
            i,j=r['i'],r['j']
            klimit=9 if j==69 else 75
            # Cases beyond reach are recorded for replay, and support no physical conclusion.
            if i>=klimit:continue
            actual=[arb(x) for x in r['all_AH_slacks']]
            nominal=[arb(x) for x in r['nominal_slacks']]
            assert len(actual)==len(nominal)==4 and min(nominal)>0
            assert r['positive']==(min(actual)>0)==((j,i) not in holdouts)
            w0,w1=map(F,r['w']);assert w0<w1
            raw_partner[j,i]=w0,w1
            if r['positive']:minimum_partner=min(minimum_partner,*[x.lower() for x in actual])
            nominal_partner=min(nominal_partner,*[x.lower() for x in nominal])
            for key in min_det:
                lo,hi,d=map(arb,r[key])
                assert 0<lo<hi<4 and d>0
                min_det[key]=min(min_det[key],d.lower())
                min_sep[key]=min(min_sep[key],lo.lower())
                max_sep[key]=max(max_sep[key],hi.upper())
        assert q['geometry_sha256']==GEOM and q['params']==params
        assert q['all_zero'] and q['all_depths']==(first>43)
        assert q['EH_source_sha256']==sha(eh) and F(q['EH_retreat'])==RETREAT and F(q['EH_cost_upper'])==cost
        assert q['source_sha256']=={p.name:sha(p) for p in (ph,area,partner,work/'ordered_state.py',work/'sharp_first_hit.py',
                                                            work/'partner_retention.py',work/'certify_tail.py')}
        kernels.add(q['zero_partner_kernel_sha256'])
        assert [row['j'] for row in q['coverage']]==list(range(first,last+1))
        source.update({p.name:sha(p) for p in (partner,raw)})
        for s in q['coverage']:
            j=s['j'];n=9 if j==69 else 75
            assert s['reach']==[[0,n]]==chart['reference_ranges'][str(j)]
            assert s['cells']==n and s['positive_orientation_1_empty']
            assert all(raw_partner[j,i][1]==raw_partner[j,i+1][0] for i in range(n-1))
            closure=[]
            ordinary=0
            for r in s['rows']:
                lo,hi=r['block']
                assert 0<=lo<hi<=n and r['zero_pass']
                closure.extend(range(lo,hi))
                assert all((j,i) in raw_partner for i in range(lo,hi))
                included={(j,i) for i in range(lo,hi)}
                common=included&holdouts
                if common:
                    assert included==common and hi-lo==1 and not r['partner_retained'] and not r['all_e_pass']
                    assert r['all_e'] is None
                    need=('zero',)
                else:
                    assert r['partner_retained'] and r['all_e_pass']
                    ordinary+=1
                    need=BRANCHES
                for k in need:
                    t=r[k]
                    assert t['physical_block']==[lo,hi] and t['subcells']==[lo,lo+1] and t['reference_bin']==j
                    assert all(arb(t[x])>0 for x in MARGINS)
                    assert set(t['verified_dihedral_pose_counts'])<=POSES
                    assert t['placed_leaves']>0 and t['placed_leaves']==sum(t['verified_dihedral_pose_counts'].values())
                    assert t['placed_leaves']+t['root_free_leaves']>=t['starting_angle_cells']==12
                    margins[k].append(t)
            assert closure==list(range(n))
            special=[(k,l) for (i,k,l) in repairs if i==j]
            assert all(repairs[j,k,l]==(raw_partner[j,k][0],raw_partner[j,l-1][1]) for k,l in special)
            blocks+=len(s['rows']);cells+=n
            cover_blocks+=ordinary+len(special)
            per_bin.append(dict(bin=j,physical_cells=n,closed_blocks=ordinary+len(special),
                                zero_first_closed_blocks=len(s['rows']),conditional_mate_blocks=len(special),
                                reach=s['reach'],source_sha256=sha(raw)))
    assert cells==2184 and kernels=={repair['zero_mate_kernel']} and [r['bin'] for r in per_bin]==list(range(40,70))
    assert len(holdouts)==255 and cover_blocks==437
    all_stats={k:dict(minima={n:str(min(arb(x[n]).lower() for x in rs)) for n in MARGINS},
                      placed_leaves=sum(r['placed_leaves'] for r in rs),
                      root_free_leaves=sum(r['root_free_leaves'] for r in rs)) for k,rs in margins.items()}
    circles={n:dict(separation_squared=[str(min_sep[n]),str(max_sep[n])],negative_cross_lower=str(min_det[n])) for n in min_det}
    source.update({p.name:sha(p) for p in (ph,area,eh,work/'certify_tail.py',work/'partner_retention.py',work/'ordered_state.py',
                                           work/'sharp_first_hit.py',Path(__file__))})
    source['rescue/final.json']=sha(rp)
    return dict(complete_tail=True,scope='j40-69 on the .62 graph; together with the eleven EH faces',
                parameters=params,geometry_sha256=GEOM,physical_subcells=cells,closed_physical_blocks=cover_blocks,
                independent_zero_first_closed_blocks=blocks,bins=per_bin,
                positive_first_orientation_1_is_empty=True,physical_subcells_with_unconditional_zero_mate=1929,
                conditional_mate_rescue_physical_subcells=255,conditional_mate_branches=repair['actual_mate_branches'],
                partner_minimum_margin_lower=str(minimum_partner),partner_at_zero_minimum_margin_lower=str(nominal_partner),
                circle_branches=circles,root_and_placement_branches=all_stats,EH_area_interval=elev['area'],
                EH_retreat=str(RETREAT),EH_transfer_upper=str(cost),sources=source)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for x in ('work','comp','out'):p.add_argument(x,type=Path)
    a=p.parse_args()
    result=compose(a.work.resolve(),a.comp.resolve())
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['physical_subcells'],result['closed_physical_blocks'],result['partner_minimum_margin_lower'],
          result['root_and_placement_branches'],flush=True)

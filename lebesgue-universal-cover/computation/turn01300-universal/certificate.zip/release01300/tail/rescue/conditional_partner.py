"""Eliminate positive partners at low first deficit, or at low third contact coordinate."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from inspect import getclosurevars
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
GRAPH='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7'
RANGE={40:75,41:75,42:75,43:30}


def run(comp):
    sys.path[:0]=[str(HERE),str(comp)]
    from certify_ah_local_physical_support import local_budgets
    from certify_ah_single_contact_chain import local_slope
    from certify_sigma_extended_graph import geometry
    from certify_sigma_pinned_fan import support_bound
    from sharp_first_hit import first_budget

    phys=HERE/'physical-0130.json'
    cfg=json.loads(phys.read_bytes())
    p,d=map(F,cfg['line'])
    far,negative,eps=map(F,cfg['physical_parameters'])
    ns,src,_=geometry(comp,[(p,d)],sigma=cfg['sigma_degrees'],far=far,negative=negative,eps=eps)
    assert sha256(src.encode()).hexdigest()==GRAPH
    ns.update(_sharpen_jets=True,_first_orientation=0)
    A,add,sub,mul,dot,cross=(ns[k] for k in ('A','add','sub','mul','dot','cross'))
    D,z=ns['D'],ns['z']
    zero=A(0);one=A(1)
    threshold=A('3/4')
    cuts=[q for q in ns['rows'] if q[0].startswith('AH-line:')]
    assert [row[0] for row in cuts]==[f'AH-line:{k}' for k in range(4)]
    assert all(x<p and y<d and x>0 and y>0 for x,y in ns['cuts'][:-1])

    def coords(w):return ns['chart'](add(z,mul(A(w),D)))

    def ideal(w):
        ell,t=coords(w)
        return ns['X'](ns['psi'](ell),-t)

    rows=[]
    for j,end in RANGE.items():
        raw=[]
        lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
        for i in range(0,end,5):
            a,b=lo+i*step,lo+(i+5)*step
            f,s=local_budgets(ns,a,b)[0]
            bf,bs=ns['two_hit_budgets'][j][0]
            first=min(f,bf);s=min(s,bs)
            f=first_budget(ns,a,b,first)
            assert s>f>0
            ell,t=[x.union(y) for x,y in zip(coords(a),coords(b),strict=True)]
            lp=ns['coord_hull'](ns['psi'],ell)
            m=local_slope(ns,lp,ns['deficit_by_bin'][j]);assert m>3
            _,_,_,hull_bound,_=support_bound(ns,j,a,b)
            variables=getclosurevars(getclosurevars(hull_bound).nonlocals['event']).nonlocals
            assert str(variables['local_m'][0])==str(m)
            kf,ks=variables['ns']['two_hit_budgets'][j][0]
            assert str(kf)==str(first) and str(ks)==str(s)
            assert str(first_budget(ns,a,b,kf))==str(f)
            mid=(a+b)/2
            qa,qb,qm=ideal(a),ideal(b),ideal(mid)
            x0,y0=ns['derivs'](*ns['chart_bounds'](lp,-t))
            _,g1,g2=ns['points'](ns['box'](a,b))
            wp=ns['psi_prime'](add(ns['l0'],mul(ell,ns['el'])))*dot(g1,D)
            qt=sub(mul(wp,x0),mul(dot(g2,D),y0))
            x,c,q=ns['chart_bounds'](lp+(-2*f/m).union(zero),-t+(-f).union(f))
            sep=dot(sub(q,c),sub(q,c));det=-cross(sub(x,c),sub(x,q))
            assert 0<sep<4 and det>0
            xl,xt=ns['derivs'](x,c,q)
            low_e=[];low_y4=[];details=[]
            for _,n,h in cuts:
                dw=-dot(n,qt)
                if dw>0:base=h-dot(n,qa)
                elif dw<0:base=h-dot(n,qb)
                else:base=h-dot(n,qm)+ns['box'](a-mid,b-mid)*dw
                L,Dv=dot(n,xl)/m,dot(n,xt)
                def minimum(upper,verts):
                    vals=[f*upper*(2*L*y3-Dv*(2*y4-1)) for y3,y4 in verts]
                    return (base+min([zero]+[v.lower() for v in vals])).lower()
                low_e.append(minimum(threshold,((zero,zero),(zero,one),(one,one))))
                low_y4.append(minimum(one,((zero,zero),(zero,threshold),(threshold,threshold))))
                details.append([str(x) for x in (base,L,Dv)])
            raw.append(dict(j=j,block=[i,i+5],reference=list(map(str,(a,b))),F=str(f),S=str(s),m=str(m),
                            transversality=[str(sep.lower()),str(sep.upper()),str(det.lower())],
                            source_shared_ordered_budget=True,
                            low_first_slacks=list(map(str,low_e)),all_first_low_y4_slacks=list(map(str,low_y4)),
                            proved_low_first=min(low_e)>0,proved_low_y4=min(low_y4)>0,side_coefficients=details))
        rows+=raw
        print(j,sum(x['proved_low_first'] for x in raw),sum(x['proved_low_y4'] for x in raw),len(raw),flush=True)
    return dict(complete=True,geometry_sha256=GRAPH,parameters=cfg,first_relative_upper='3/4',fourth_coordinate_upper='3/4',
                rows=rows,source_sha256={p.name:sha256(p.read_bytes()).hexdigest() for p in (phys,Path(__file__),HERE/'sharp_first_hit.py')})


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('out',type=Path)
    a=p.parse_args()
    a.out.write_text(json.dumps(run(a.comp.resolve()),indent=2)+'\n')

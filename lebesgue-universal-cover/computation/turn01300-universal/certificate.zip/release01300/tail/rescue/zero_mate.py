"""Check all first depths under the condition that the real partner deficit is zero."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json
import sys

from flint import arb

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from certify_tail import BRACKETS,GEOMETRY,MARGINS,RETREAT,build,digest,load

RANGES={40:75,41:75,42:75,43:30}


def run(a):
    ns,cfg,reach,validator,support,eh,cost=load(a)
    direct,ks=build(ns,validator,support)
    rows=[]
    ns['_e_class']=(F(0),F(1))
    for j,n in RANGES.items():
        assert reach(ns,j)==[(0,75)] and ns['labelled_deficits'][1][j].is_zero()
        for k in range(0,n,5):
            ns['_physical_block']=k,k+5
            for l,r in BRACKETS:
                t=direct(ns,j,F(l),F(r),0,1,-1,begin=k,end=k+1,angular=12,depth=4)
                if all(arb(t[key])>0 for key in MARGINS) and t['placed_leaves']>0:
                    assert sum(t['verified_dihedral_pose_counts'].values())==t['placed_leaves']
                    break
            else:
                raise ValueError(('unclosed five-block',j,k,t))
            rows.append(dict(bin=j,physical_block=[k,k+5],row=t))
        print(j,n//5,flush=True)
    return dict(complete=True,geometry_sha256=GEOMETRY,parameters=cfg,
                condition_on_actual_second_deficit='0',orientation=0,e_class=['0','1'],
                rows=rows,EH_retreat=str(RETREAT),EH_cost_upper=str(cost),EH_source_sha256=digest(eh),
                support_kernel_sha256=ks,source_sha256={p.name:digest(p) for p in (Path(__file__),ROOT/'certify_tail.py',
                                                    ROOT/'ordered_state.py',ROOT/'sharp_first_hit.py',ROOT/'physical-0130.json')})


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('comp','main_comp','out'):p.add_argument(n,type=Path)
    a=p.parse_args()
    a.out.write_text(json.dumps(run(a),indent=2)+'\n')

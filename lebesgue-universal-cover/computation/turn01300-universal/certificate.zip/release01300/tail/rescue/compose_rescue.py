"""Bind the two true-mate cases to a common physical partition for j40--43."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

from flint import arb,ctx

HOLDOUT={40:75,41:75,42:75,43:30}
GEOM='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7'
RETREAT=F('.00000009488')
SIGNS=('root_margin_lower','placement_margin_lower')


def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()


def compose(work,comp):
    ctx.prec=160
    rescue=work/'rescue';ranged=rescue/'ranged'
    physical=read(work/'physical-0130.json')
    assert physical==read(ranged/'physical-0130.json')==read(rescue/'physical-0130.json')
    assert sha(work/'sharp_first_hit.py')==sha(rescue/'sharp_first_hit.py')==sha(ranged/'sharp_first_hit.py')
    eh=comp/'sigma154-ah429-eh-chain997-composition.json'
    assert sha(eh)=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
    cost=F(read(eh)['transfer_cost']['exact'][1])
    assert 0<cost<RETREAT
    cls=rescue/'conditional-final.json';low=read(cls)
    assert low['complete'] and low['parameters']==physical and low['geometry_sha256']==GEOM
    assert F(low['first_relative_upper'])==F(low['fourth_coordinate_upper'])==F(3,4)
    assert low['source_sha256']=={p.name:sha(p) for p in (rescue/'physical-0130.json',
                                                               rescue/'sharp_first_hit.py',rescue/'conditional_partner.py')}
    all_blocks={(j,k,k+5) for j,n in HOLDOUT.items() for k in range(0,n,5)}
    closed={}
    minima={k:arb(1) for k in ('low_first_slacks','all_first_low_y4_slacks')}
    for r in low['rows']:
        j=r['j'];k,l=r['block'];key=(j,k,l)
        assert key in all_blocks and key not in closed
        assert r['source_shared_ordered_budget'] and r['proved_low_first'] and r['proved_low_y4']
        f,s,m=map(arb,(r['F'],r['S'],r['m']));assert 0<f<s and m>3
        for field in minima:
            values=[arb(v) for v in r[field]]
            assert len(values)==4 and min(values)>0
            minima[field]=min(minima[field],*[v.lower() for v in values])
        q,u,d=map(arb,r['transversality']);assert 0<q<u<4 and d>0
        closed[key]=r['reference']
    assert closed.keys()==all_blocks and len(closed)==51

    def pose_line(row,j,indices):
        assert row['subcells']==indices and row['reference_bin']==j
        assert all(arb(row[v])>0 for v in SIGNS)
        assert row['placed_leaves']>0 and row['placed_leaves']==sum(row['verified_dihedral_pose_counts'].values())
        assert row['placed_leaves']+row['root_free_leaves']>=row['starting_angle_cells']==12

    zp=rescue/'zero-mate.json';zz=read(zp)
    assert zz['complete'] and zz['geometry_sha256']==GEOM and zz['parameters']==physical
    assert zz['orientation']==0 and zz['condition_on_actual_second_deficit']=='0'
    assert list(map(F,zz['e_class']))==[0,1]
    assert F(zz['EH_retreat'])==RETREAT and F(zz['EH_cost_upper'])==cost and zz['EH_source_sha256']==sha(eh)
    for f,h in zz['source_sha256'].items():
        p=rescue/f
        if f!='zero_mate.py':p=work/f
        assert sha(p)==h
    zrows={}
    for r in zz['rows']:
        j=r['bin'];k,l=r['physical_block'];key=(j,k,l)
        assert key in all_blocks and key not in zrows
        pose_line(r['row'],j,[k,k+1])
        zrows[key]=r['row']
    assert zrows.keys()==all_blocks

    rows={};sources={}
    for j,n in HOLDOUT.items():
        native=ranged/f'positive-{j}-receipt.json'
        cfg=ranged/f'positive-{j}-parameters.json'
        d=read(native)
        assert d['complete'] and d['all_passed'] and d['geometry_sha256']==GEOM and d['physical_parameters']==physical
        assert d['parameters']==read(cfg) and d['reachable']=={str(j):[[0,n]]}
        assert d['EH_tightening']['label']=='U1-Te-0' and F(d['EH_tightening']['retreat'])==RETREAT
        assert d['parameters']['freeze_blocks'] and d['parameters']['block']==5
        for f,h in d['source_hashes'].items():
            p=ranged/f
            assert sha(p if p.is_file() else comp/f)==h
        sources.update({str(p.relative_to(work)):sha(p) for p in (native,cfg)})
        for r in d['rows']:
            t=r['row'];k,l=t['subcells'];tag=(j,k,l)
            a,b=r['counts'];key=(*tag,a)
            assert tag in all_blocks and 0<=a<=3 and a+b==5 and key not in rows
            assert r['bin']==j and r['orientation']==0 and r['positive'] and r['tighten_first']
            assert list(map(F,r['knots']))==[0,F(3,4),1] and list(map(F,r['e_class']))==[F(3,4),1]
            pose_line(t,j,[k,l])
            rows[key]=t
    assert rows.keys()=={(*tag,c) for tag in all_blocks for c in range(4)}
    all_stats={b:dict(count=len(rr),minima={t:str(min(arb(r[t]).lower() for r in rr.values())) for t in SIGNS},
                          placed_leaves=sum(r['placed_leaves'] for r in rr.values()),
                          root_free_leaves=sum(r['root_free_leaves'] for r in rr.values()))
               for b,rr in [('zero_mate_all_depths',zrows),('positive_mate_four_counts',rows)]}
    sources.update({str(p.relative_to(work)):sha(p) for p in (cls,zp,Path(__file__),rescue/'conditional_partner.py',
                                                       rescue/'zero_mate.py',ranged/'certify_ordered_direct_mixed.py',
                                                       ranged/'ordered_state.py')})
    return dict(complete=True,geometry_sha256=GEOM,parameters=physical,physical_subcells=255,closed_five_blocks=51,
                EH_retreat=str(RETREAT),EH_cost_upper=str(cost),zero_mate_kernel=zz['support_kernel_sha256'],
                necessary_for_actual_positive_mate=dict(first_deficit='>(3/4)Fsharp',fourth_order_coordinate='>3/4',
                    true_cut_margins={k:str(v) for k,v in minima.items()}),
                actual_mate_branches=all_stats,closed_bounds=[dict(bin=j,indices=[a,b],w=closed[j,a,b])
                      for (j,a,b) in sorted(all_blocks)],source_sha256=sources)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('work','comp','out'):p.add_argument(name,type=Path)
    a=p.parse_args()
    result=compose(a.work.resolve(),a.comp.resolve())
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['actual_mate_branches'],flush=True)

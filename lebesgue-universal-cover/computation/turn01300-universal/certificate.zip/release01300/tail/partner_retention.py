"""Retain both genuine partner tubes on the .01300 AH faces, with strict circle branches."""
from fractions import Fraction as F
import json
from pathlib import Path

from certify_ah_local_physical_support import local_budgets
from certify_ah_single_contact_chain import local_slope
from sharp_first_hit import first_budget

TRIANGLE=((0,0),(0,1),(1,1))


def partner_cases(ns,start,finish,reach,area):
    A,add,sub,mul,dot,cross=(ns[k] for k in ('A','add','sub','mul','dot','cross'))
    D,z=ns['D'],ns['z']
    zero=A(0)
    cuts=[r for r in ns['rows'] if r[0].startswith('AH-line:')]
    assert [r[0] for r in cuts]==[f'AH-line:{k}' for k in range(4)]
    for (_,n,h),p,v in zip(cuts,ns['pivot_set'],ns['cut_dirs'],strict=True):
        assert all(x.contains(0) for x in sub(n,mul(-1,ns['perp'](v))))
        assert (h-dot(n,p)).contains(0) and dot(n,n).contains(1)

    def coords(w):return ns['chart'](add(z,mul(A(w),D)))

    def ideal(w):
        ell,t=coords(w)
        return ns['X'](ns['psi'](ell),-t)

    def tube(ell,t):
        x,c,d=ns['chart_bounds'](ell,t)
        sep=dot(sub(d,c),sub(d,c))
        det=-cross(sub(x,c),sub(x,d))
        assert 0<sep<4 and det>0
        return (x,c,d),(str(sep.lower()),str(sep.upper()),str(det.lower()))

    rows=[]
    for j in range(start,finish+1):
        ranges=reach(ns,j)
        assert [list(p) for p in ranges]==area['chart']['reference_ranges'][str(j)]
        lo,hi=ns['knots'][j:j+2]
        step=(hi-lo)/75
        nfail=0
        margin_min=A(1)
        for i in range(75):
            a,b=lo+i*step,lo+(i+1)*step
            mid=(a+b)/2
            f,s=local_budgets(ns,a,b)[0]
            f0,s0=ns['two_hit_budgets'][j][0]
            f=first_budget(ns,a,b,min(f,f0))
            s=min(s,s0)
            v=f.min(s)
            ell,t=(x.union(y) for x,y in zip(coords(a),coords(b),strict=True))
            lp=ns['coord_hull'](ns['psi'],ell)
            m=local_slope(ns,lp,ns['deficit_by_bin'][j])
            assert m>3
            xi=(-(f+v)/m).union(zero)
            C=(-v).union(f)
            _,front=tube(ell,t+(-f).union(zero))
            mate_arg,mate=tube(lp+xi,-t+C)
            mate_l,mate_t=ns['derivs'](*mate_arg)
            # A true paired point has X(psi(ell(w)), -T(w)). Do not bound
            # its two coordinates independently when evaluating a single cut row.
            xa,xb,xm=ideal(a),ideal(b),ideal(mid)
            sl,st=ns['derivs'](*ns['chart_bounds'](lp,-t))
            _,gl,gt=ns['points'](ns['box'](a,b))
            p_w=ns['psi_prime'](add(ns['l0'],mul(ell,ns['el'])))*dot(gl,D)
            t_w=dot(gt,D)
            moves=sub(mul(p_w,sl),mul(t_w,st))
            old=ns['reflection'](ns['centered_points'](a,b)[2])
            assert all(x.overlaps(y) for x,y in zip(old,ns['X'](lp,-t),strict=True))
            margins=[]
            baselines=[]
            for _,n,h in cuts:
                change=-dot(n,moves)
                if change>0:
                    baseline=h-dot(n,xa)
                elif change<0:
                    baseline=h-dot(n,xb)
                else:
                    baseline=h-dot(n,xm)+ns['box'](a-mid,b-mid)*change
                along=dot(n,mate_l)/m
                vert=dot(n,mate_t)
                extrema=[along*(e+u)*y3-vert*((e+u)*y4-u)
                         for e,u in ((zero,zero),(v,v),(f,v)) for y3,y4 in TRIANGLE]
                margins.append((baseline+min(x.lower() for x in extrema)).lower())
                baselines.append(baseline.lower())
            good=all(x>0 for x in margins)
            nfail+=int(not good)
            margin_min=min(margin_min,*margins)
            rows.append(dict(j=j,i=i,w=[str(a),str(b)],first=str(f),second=str(s),m=str(m),
                             all_AH_slacks=list(map(str,margins)),nominal_slacks=list(map(str,baselines)),
                             front_tube=front,partner_tube=mate,positive=good))
        print('partner',j,'fail',nfail,'margin',margin_min,
              'label1',ns['labelled_deficits'][1][j].is_zero(),flush=True)
    return rows

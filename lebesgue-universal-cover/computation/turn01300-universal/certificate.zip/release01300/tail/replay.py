"""Rebuild every .01300 tail receipt independently from a portable package."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil
from subprocess import DEVNULL,run
import sys

HERE=Path(__file__).resolve().parent
PARTS=((40,46),(47,53),(54,61),(62,69))
LIMITS=(40,41,42,43)
ROOT_INPUTS=(
    'physical-0130.json','weighted-area-0130.json','certify_tail.py','partner_retention.py','ordered_state.py',
    'sharp_first_hit.py','compose_tail.py','rescue/conditional_partner.py','rescue/zero_mate.py',
    'rescue/compose_rescue.py','rescue/physical-0130.json','rescue/sharp_first_hit.py',
    'rescue/ranged/certify_ordered_direct_mixed.py','rescue/ranged/physical-0130.json',
    'rescue/ranged/ordered_state.py','rescue/ranged/sharp_first_hit.py',
)


def replay(out):
    out.mkdir(parents=True,exist_ok=True)
    assert not any(out.iterdir())
    inputs=[*ROOT_INPUTS,*(f'rescue/ranged/positive-{j}-parameters.json' for j in LIMITS)]
    for n in inputs:
        (out/n).parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(HERE/n,out/n)
    shutil.copytree(HERE/'comp012',out/'comp012')

    def task(exe,args,expected,stdout=None):
        command=[sys.executable,'-I','-B',exe,*map(str,args)]
        if stdout is None:
            run(command,cwd=out,check=True,stdout=DEVNULL)
        else:
            with (out/stdout).open('w') as f:
                run(command,cwd=out,check=True,stdout=f)
        for actual,frozen in expected:
            assert (out/actual).read_bytes()==(HERE/frozen).read_bytes(),(actual,frozen)
        print(exe,expected,flush=True)

    def tail(part):
        a,b=part
        p,t=f'partner-{a}-{b}.json',f'tail-{a}-{b}.json'
        task('certify_tail.py',('comp012','comp012',p,t,a,b),[(p,p),(t,t)])

    def positive(j):
        d='rescue/ranged'
        outname=f'{d}/positive-{j}-receipt.json'
        task(f'{d}/certify_ordered_direct_mixed.py',
             ('comp012',d,f'{d}/positive-{j}-parameters.json',outname),[(outname,outname)])

    def area():
        task('comp012/certify_sigma154_deeper_composition.py',
             ('comp012','physical-0130.json','--eh','comp012'),
             [('area-replayed.json','weighted-area-0130.json')],stdout='area-replayed.json')

    def conditional():
        n='rescue/conditional-final.json'
        task('rescue/conditional_partner.py',('comp012',n),[(n,n)])

    def zero():
        n='rescue/zero-mate.json'
        task('rescue/zero_mate.py',('comp012','comp012',n),[(n,n)])

    with ThreadPoolExecutor(4) as pool:
        jobs=[pool.submit(tail,p) for p in PARTS]
        jobs+= [pool.submit(f) for f in (area,conditional,zero)]
        jobs+= [pool.submit(positive,j) for j in LIMITS]
        for f in jobs:f.result()
    task('rescue/compose_rescue.py',('.','comp012','rescue/final.json'),[('rescue/final.json','rescue/final.json')])
    task('compose_tail.py',('.','comp012','tail-final.json'),[('tail-final.json','tail-final.json')])


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('out',type=Path)
    args=parser.parse_args()
    replay(args.out.resolve())

"""Rebuild the fixed EH first placement and .01300 physical gate/true area."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,subprocess,sys
W=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();O.mkdir(parents=True,exist_ok=True);P=sys.executable;E=W/'firststage/firstEH/comp';M=W/'firststage/main';T=W/'tail';C=T/'comp012';G='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7'
def run(out,script,*args):
 with out.open('wb') as f:subprocess.run([P,'-I','-B',str(script),*map(str,args)],cwd=W,stdout=f,check=True)
single=O/'single.json';chain=O/'chain.json';ew=O/'eh-work';ew.mkdir(exist_ok=True)
run(single,E/'certify_sigma154_eh_transfer.py',E,E/'eh-sigma-154-single550-weights.json',E/'sigma-154-ah-reachable-full-certificate.json',E/'sigma-154-ah-reachable-full-parameters.json',ew)
assert single.read_bytes()==(M/'sigma154-ah429-eh550-composition.json').read_bytes()
run(chain,E/'certify_sigma154_eh_chain.py',E,E/'eh-sigma-154-chain997-weights.json',single)
assert chain.read_bytes()==(M/'sigma154-ah429-eh-chain997-composition.json').read_bytes()
for name in ('sigma154-ah429-eh550-composition.json','sigma154-ah429-eh-chain997-composition.json'):
 assert sha256((M/name).read_bytes()).hexdigest()==sha256((C/name).read_bytes()).hexdigest()
area=O/'area.json';run(area,C/'certify_sigma154_deeper_composition.py',C,T/'physical-0130.json','--eh',C);assert area.read_bytes()==(T/'weighted-area-0130.json').read_bytes()
a=json.loads(area.read_bytes());chart=a['chart'];eh=next(x for x in a['geometry']['cases'] if x['label']=='eleven');p=a['parameters'];assert p=={'sigma_degrees':'1.54','line':['.429','.01300'],'physical_parameters':['.336','.383','.018']};assert chart['geometry_sha256']==G and F(chart['physical_graph_endpoint'])==F('.62') and F(chart['reference_endpoint'])==F('.43');assert chart['reference_subcells']==5184 and chart['reference_ranges']['69']==[[0,9]]
for k in ('first_hit_y_above_518','first_hit_squared_distance_to_C_above_1','reference_gap','negative_projection_room'):assert F(chart[k]['exact'][0])>0,k
assert F(eh['transfer_cost_upper'])<F(593,6250000000); assert F(eh['area']['exact'][1])<F('.844089289596730689697335172882506658495')
result={'complete':True,'geometry_sha256':G,'physical_parameters':p,'graph_end':'.62','physical_rows':chart['physical_rows'],'reference_subcells':chart['reference_subcells'],'actual_first_hit_y_above_518':chart['first_hit_y_above_518']['decimal'][0], 'first_hit_squared_distance_minus_one':chart['first_hit_squared_distance_to_C_above_1']['decimal'][0], 'area_interval':eh['area']['decimal'],'area_upper_exact':eh['area']['exact'][1],'eh_transfer_upper':eh['transfer_cost_upper'],'eh_retreat':'593/6250000000','scope':'Replayed fixed EH first placement and 01300 full physical gate; paired inputs and two-hit bins use the other segment certificates.'};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

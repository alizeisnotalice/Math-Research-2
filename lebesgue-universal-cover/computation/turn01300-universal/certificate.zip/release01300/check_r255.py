"""Check first-EH frozen inputs against the exact published R255 archive."""
from pathlib import Path
from hashlib import sha256
import sys,zipfile,json
D=Path(__file__).resolve().parent;archive=Path(sys.argv[1]);expected='59a75102899eeb98445be647af274176eda6f6d9728f25f572c1f88fc9854d66';assert sha256(archive.read_bytes()).hexdigest()==expected
count=0
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():
  if n.endswith('/') or not (n.startswith('release01250/firstEH/comp/') or n in ['release01250/main/sigma154-ah429-eh550-composition.json','release01250/main/sigma154-ah429-eh-chain997-composition.json']):continue
  local=D/'firststage'/n.removeprefix('release01250/');assert local.read_bytes()==z.read(n),n;count+=1
print(json.dumps({'source_archive_sha256':expected,'matching_members':count}))

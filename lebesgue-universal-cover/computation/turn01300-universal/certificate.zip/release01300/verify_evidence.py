"""Check independent numerical-replay ledgers against frozen segment receipts."""
from pathlib import Path
from hashlib import sha256
import json
P=Path(__file__).resolve().parent;E=P/'replay-evidence';D=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
a=read(E/'early0-15.json');assert a['all_exact'] and a['complete']==16 and a['rows']==2268 and {r['j'] for r in a['entries']}==set(range(16))
for r in a['entries']:
 f=P/'early'/f"output-{r['j']}.json";assert D(f)==r['sha256'] and len(f.read_bytes())==r['bytes']
m=read(E/'middle16-31.json');assert D(E/'middle16-31.json')=='5020cfd9761115fee3f6a605da79e84ea3cde4c701512cbe67e7c14ec0560030';assert m['all_byte_identical'] and m['completed']==17 and len(m['records'])==17
for r in m['records']:assert r['exit_code']==0 and r['match'] and r['expected']==r['actual']==D(P/'middle'/r['output'])
j=read(E/'j32-34.json');assert {r['bin'] for r in j['independent_replays']}=={32,33,34}
for r in j['independent_replays']:
 k=r['bin'];f=P/'j32_34'/f"result-j{k}-{'joined' if k==34 else '32nd'}.json";assert r['byte_identical'] and D(f)==r['sha256']
assert j['partner_source']['byte_identical'] and D(P/'j32_34/partner/result.json')==j['partner_source']['sha256']
r=read(E/'j35-39.json');assert r['all_five_byte_identical'] and {x['bin'] for x in r['rows']}==set(range(35,40))
for x in r['rows']:assert x['exit_code']==0 and x['original_sha256']==x['independent_replay_sha256']==D(P/'j35_39/middle'/f"join-j{x['bin']}.json")
assert r['partner_original_sha256']==r['partner_replay_sha256']==D(P/'j35_39/partner/result.json')
t=read(E/'j40-69.json');assert t['all_byte_identical'] and len(t['outputs'])==17
for r in t['outputs']:assert r['byte_identical'] and D(P/'tail'/r['output'])==r['sha256']
s=read(E/'status.json');assert all(s[f'bins_{k}']['complete'] for k in ('0_15','16_31','32_34','35_39','40_69'))
print(json.dumps({'all_independent_replay_ledgers_bound':True,'early_receipts':16,'middle_receipts':17,'j32_34':3,'j35_39':5,'tail_outputs':17}))

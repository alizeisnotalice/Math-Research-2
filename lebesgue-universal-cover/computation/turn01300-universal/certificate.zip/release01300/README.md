# AH .01300 universal-cover synthesis

This release fixes σ=1.54°, AH pivot .429 and turn .01300, physical parameters (.336,.383,.018), and paired graph endpoint .62. The physical input SHA-256 is `a30bd9d06c8d83200fbcbc725e7f5962d53f87b3cf9d8eb2a06c4652dabe7acd`; the rebuilt geometry SHA-256 is `6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7`. The verifier closes all 70 reference bins, covering 5,184 closed physical cells, with the last bin containing nine. The candidate's true area lies strictly in

    (.844089289596730689697335172872145479116,
     .844089289596730689697335172882506658495).

`PROOF.md` explains the same-input first and reflected placements, the ordered paired-hit reductions, each sector's scope, and the simultaneous placement and EH transfer. The first EH stage is the R255 fixed-source proof, rerun here; the .01300 full physical graph, first-hit trigger and real curved area are reconstructed independently. No .01250 graph hash or reference-cell count is substituted.

Use Python 3.13.18 and python-flint 0.9.0; from the extracted directory, with a fresh empty scratch directory outside this package:

    python3 -I -B verify01300.py "$WORK"
    cmp "$WORK/cover-result.json" cover-result.json

The default command reruns the complete fixed EH first-placement kernels, .01300 physical gate and true-area kernel, the j34 and j35–39 partner interfaces, and all segment source/closed-partition/positive-margin/actual-pose audits. It compares the tail synthesis with the frozen output. These checks establish coverage from the included original interval receipts; they do **not** independently rerun every original numerical interval leaf. With `--full`, the same command additionally reruns all raw early and middle interval kernels, the j32–34 numerical kernels and their partner source, the j35–39 original kernels and the entire tail. This is a long calculation; all outputs go to the provided scratch directory.

To verify the inherited first-EH source against the public predecessor, set `R255_ZIP` to the published R255 `sigma154-turn01250-universal.zip` and run

    python3 -I -B check_r255.py "$R255_ZIP"

The independently recomputed j16–31 ledger is in `replay-evidence/middle16-31.json`. The j32–34 original numerical kernels and partner kernel, j35–39 original kernels and partner source, and j40–69 original kernels were separately replayed by their producing workstations and matched their frozen receipts. The j0–15 original engines were also rerun independently and all 16 outputs matched byte-for-byte; the portable comparison ledger is in `replay-evidence/early0-15.json`. Do not interpret a successful structural audit as this independent second numerical replay.

All source components retain their own geometrical and provenance hashes. `MANIFEST.sha256` binds the combined package. The proof and area concern the explicitly described convex host and the universal-cover theorem obtained from the 70-bin placement proof; the numerical source replay status is a separate reproducibility statement.

"""Check the receipt registry, or re-evaluate all requested placement and refinement receipts."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
here=Path(__file__).resolve().parent
def run(argv,output):
    log=output.with_suffix('.log')
    with log.open('w') as h:subprocess.run([sys.executable,'-I','-B',*map(str,argv),str(output)],cwd=here,stdout=h,check=True)
def same(a,b):
    left=json.loads(a.read_bytes());right=json.loads(b.read_bytes())
    if 'python' in right:left['python']=right['python']
    assert left==right,b

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('scratch',type=Path)
    parser.add_argument('--full',action='store_true')
    parser.add_argument('--workers',default=1,type=int)
    parser.add_argument('--bins',nargs='+',type=int)
    args=parser.parse_args()
    for path,expected in json.loads((here/'manifest.json').read_bytes()).items():
        assert sha256((here/path).read_bytes()).hexdigest()==expected,path
    out=args.scratch.resolve()
    assert out!=here
    out.mkdir(parents=True,exist_ok=True)
    registry=json.loads((here/'registry.json').read_bytes())
    if args.full:
        jobs=[d for d in registry if args.bins is None or d['bin'] in args.bins]
        def evaluate(task):
            target=out/task['output']
            run(task['argv'],target)
            same(target,here/task['output'])
            print('recomputed',task['output'],flush=True)
        with ThreadPoolExecutor(max_workers=args.workers) as pool:list(pool.map(evaluate,jobs))
    run(['audit_bins.py'],out/'audit.json')
    same(out/'audit.json',here/'audit.json')
    print('Verified 16 synchronized bins at AH depth .01300.')
if __name__=='__main__':main()

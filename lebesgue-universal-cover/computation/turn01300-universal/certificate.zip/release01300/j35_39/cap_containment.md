# AH cap nesting at a fixed pivot

This is an analytic interface, not a proof that the parameter-box witness covers the whole physical domain. The source `certify_ah_two_line_cap.py` defines `direct = -D/|D|`, `normal = perp(direct)`, and `pivot = z+pD`. These vectors are orthonormal with `perp(normal)=-direct`. Write a point as `x=pivot+s direct+t normal`. The old AH retained halfplane is `t>=0`. For a rotation `0<theta<pi/2`, the added retained halfplane has normal

`n_theta=-perp(cos(theta) direct+sin(theta) normal)=sin(theta) direct-cos(theta) normal`.

A point in the new removed cap and the old retained halfplane therefore has

`sin(theta)s-cos(theta)t>0`, `t>=0`, hence `s>0` and `0<=t<tan(theta)s`.

The orthogonal baseline coordinate is `w=p-s/|D|<p`. For `0<theta1<=theta2<pi/2`, monotonicity of tan proves inclusion of the theta1 open cap in the theta2 open cap; replacing strict inequalities by non-strict ones gives inclusion of closed cap closures. Intersections with any fixed old convex host preserve inclusion. Thus no separate numerical lower bound on the s coordinate can establish the wrong sign or is needed to prove the pivot-side statement.

This argument alone does not show that the outer chart's bounded reference interval, negative endpoint floor, paired-graph domain or deficit budget cover every actual hit. Those require independent certified inequalities and a binding to the parameter-box interval normal. The interval first-hit code must also prove its derivative positive and retained-side threshold strictly positive uniformly over the full angle interval; when either test fails it must retain the original valid outer budget.

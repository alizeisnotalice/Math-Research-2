# .01300 / .62 chart: bins 35–39

This packet certifies only five conditional two-hit bins and cannot by itself establish a universal-cover bound. Physical data: sigma 1.54°, AH pivot .429, turn .01300 radians and (.336,.383,.018); graph extension .62, geometry SHA 6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7. Each bin contains 75 closed physical cells and both first-hit labels and derivative branches are covered. The actual EH row is retreated by 593/6250000000.

The highest deficit, deepest ordered quarter class uses the actual two-hit partner exclusion: its 75 single cells have strict clearance for all four added AH lines. The raw 375-cell interval proof and independent support-normalization/two-circle audit are in `partner/`. Every other class has a strict root bracket and common dihedral pose for all support rows. The parent-to-child transition requires the same K, real e>0 and v=e in both blocks, which is checked through the parent and child S/F bounds; then y4≤y5≤1/4<3/8. Full ordered sets, closed physical partitions, source hashes and per-pose counts are audited by `audit_join013.py`. The baseline EH placement and two-hit reduction must be supplied by the larger global proof.

Run with Python 3.13 and python-flint 0.9.0:

```
python -I -B verify_middle.py /path/to/scratch
python -I -B verify_middle.py /path/to/scratch --full
```

The first command recomputes nested budgets and all 375 support interfaces and checks source binding and all five partitions. The second also recomputes the raw partner and five raw interval receipts. The independent replay ledger records previous actual byte-identical runs, which are not replaced by a hash-only check. `cap_containment.md` states the analytic nesting of fixed-pivot AH caps; it does not establish parameter-box physical coverage.

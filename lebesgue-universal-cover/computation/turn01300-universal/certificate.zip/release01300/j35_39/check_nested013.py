"""Verify tight local budgets as exact Arb points, and the actual class inclusions."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json
from flint import arb
comp=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]);kit=Path(__file__).resolve().parent
sys.path.insert(0,str(comp))
from certify_sigma_extended_graph import geometry
from certify_ah_local_physical_support import local_budgets
from certify_sigma_reachable_roots import reach
q=json.loads((kit/'physical.json').read_bytes())
ns,src,_=geometry(comp,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']))))
summary=[]
for j in range(35,40):
    lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
    assert reach(ns,j)==[(0,75)] or reach(ns,j)==[[0,75]]
    saved={};exact=0;negative_gaps=0
    for width in (1,5,15):
        for a in range(0,75,width):
            b=a+width;real=local_budgets(ns,lo+a*step,lo+b*step)
            old=ns['two_hit_budgets'][j][0]
            f,s=(min(x,y) for x,y in zip(old,real[0],strict=True))
            assert f.rad().is_zero() and s.rad().is_zero(),(j,a,b,f.rad(),s.rad())
            assert f>0 and s>=0
            saved[a,b]=f,s;exact+=1
            negative_gaps+=int(s<f)
    transitions=[]
    for small,big in ((1,5),(5,15)):
        smallest_f=smallest_s=None;eq_f=eq_s=0
        for a in range(0,75,small):
            b=a+small;parent=a//big*big
            fc,sc=saved[a,b];fp,sp=saved[parent,parent+big]
            assert fc<=fp and sc<=sp,(j,small,a,fc,fp,sc,sp)
            eq_f+=int(fc==fp);eq_s+=int(sc==sp)
            df=(fp-fc).lower();ds=(sp-sc).lower()
            smallest_f=df if smallest_f is None else min(smallest_f,df)
            smallest_s=ds if smallest_s is None else min(smallest_s,ds)
        transitions.append(dict(child=small,parent=big,identical_F=eq_f,identical_S=eq_s,min_F_gap=str(smallest_f),min_S_gap=str(smallest_s)))
    summary.append(dict(bin=j,exact_budget_pairs=exact,S_less_than_F_blocks=negative_gaps,transitions=transitions))
output.write_text(json.dumps({'parameters':q,'geometry_sha256':sha256(src.encode()).hexdigest(),'bins':summary,'total_exact_budget_pairs':sum(r['exact_budget_pairs'] for r in summary)},indent=1)+'\n')

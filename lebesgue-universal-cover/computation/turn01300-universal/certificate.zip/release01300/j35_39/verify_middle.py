"""Audit five .01300 bins; optional full raw interval replay."""
from pathlib import Path
import json,subprocess,sys
D=Path(__file__).resolve().parent;W=Path(sys.argv[1]).resolve();W.mkdir(parents=True,exist_ok=True);assert len(sys.argv) in (2,3) and (len(sys.argv)==2 or sys.argv[2]=='--full');P=sys.executable;C=D/'comp012';M=D/'middle';S=D/'partner';G='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7'
def run(f,*args):subprocess.run([P,'-I','-B',str(f),*map(str,args)],check=True,cwd=D,stdout=subprocess.DEVNULL)
def load(p):return json.loads(p.read_bytes())
out=W/'nested.json';run(D/'check_nested013.py',C,out);assert out.read_bytes()==(D/'nested35-39.json').read_bytes()
out=W/'partner-audit.json';run(S/'audit_partner_013.py',C,D/'physical.json',S/'result.json',out);assert out.read_bytes()==(S/'audit.json').read_bytes()
for j in range(35,40):
 out=W/f'audit-{j}.json';run(D/'audit_join013.py',j,out);v=load(out);assert v['bin']==j and v['geometry_sha256']==G and v['physical_cells']==v['excluded_singletons']==75
if len(sys.argv)==3:
 raw=W/'partner-raw.json';run(S/'certify_partner_retention_levels.py',C,D/'physical.json',raw,35,36,37,38,39);assert raw.read_bytes()==(S/'result.json').read_bytes()
 for j in range(35,40):
  out=W/f'join-{j}.json';run(M/'certify_partner_join.py',C,M/f'config-j{j}.json',out);a=load(out);b=load(M/f'join-j{j}.json');a['python']=b['python'];assert a==b
x={'complete_five_bins':True,'bins':list(range(35,40)),'physical_cells':375,'geometry_sha256':G,'scope':'five conditional two-hit bins only; not global coverage','full_interval_replay':len(sys.argv)==3};(W/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))

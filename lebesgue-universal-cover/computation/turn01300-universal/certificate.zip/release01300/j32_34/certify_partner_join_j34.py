"""Split the real initial derivative, using synchronized contact-class partitions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys


def run(comp,config,output):
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from flint import arb, __version__ as flint_version
    from ordered_derivative import validate
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach
    from certify_ah_local_physical_support import local_budgets
    from sharp_first_hit import first_budget
    partner=Path(__file__).resolve().parent/'partner'; raw=json.loads((partner/'result.json').read_text()); audit=json.loads((partner/'audit-j34.json').read_text())
    sha=lambda p:sha256(p.read_bytes()).hexdigest()
    assert audit['complete'] and audit['physical_subcells']==75 and audit['raw_sha256']==sha(partner/'result.json') and audit['auditor_sha256']==sha(partner/'audit_partner_01300_j34.py')
    witnesses={(x['bin'],x['index']):x for x in raw['rows']}; assert set(witnesses)=={(j,i) for j in range(32,35) for i in range(75)}

    cfg=json.loads(config.read_bytes())
    phys_path=config.parent/cfg['physical']
    if not phys_path.exists():
        phys_path=comp/cfg['physical']
    phys=json.loads(phys_path.read_bytes())
    pivot,turn=map(F,phys['line'])
    pars=dict(zip(('far','negative','eps'),map(F,phys['physical_parameters']),strict=True))
    ns,source,_=geometry(comp,[(pivot,turn)],sigma=phys['sigma_degrees'],**pars)
    assert raw['physical_parameters']==audit['parameters']==phys and raw['geometry_sha256']==audit['geometry_sha256']==sha256(source.encode()).hexdigest()
    assert raw['only_positive_deficit'] and raw['orientation']==audit['orientation']==0
    ns['_sharpen_jets']=True
    ns['_tighten_first']=True
    index,=[i for i,(label,_,_) in enumerate(ns['rows']) if label.startswith('U1-Te')]
    label,normal,offset=ns['rows'][index];retreat=F(cfg['retreat'])
    assert retreat>=0 and F(ns['eh_depth'])==F('.000555')
    ns['rows'][index]=label,normal,offset-ns['A'](retreat)
    ranges={j:reach(ns,j) for j in cfg['bins']}
    cut=F(cfg['cut'])
    records=[]
    def visit(j,orientation,side,a,b):
        ns['_end_index']=b;ns['_first_orientation']=orientation
        result=[]
        plan=[([k,5-k],F(0),F(1)) for k in range(6)]
        if orientation==0 and side==-1:
            plan=plan[:5]+[([5,0],F(k,4),F(k+1,4)) for k in range(3)]
            plan.extend(([k,5-k,0,0],F(3,4),F(1)) for k in range(5))
            plan.extend(([k,5-k]+[0]*6,F(3,4),F(1)) for k in range(6))
        for counts,elo,ehi in plan:
            ns['_class_counts']=tuple(counts)
            ns['_e_class']=(elo,ehi)
            if orientation==0 and side==-1 and counts==[5,0,0,0,0,0,0,0] and elo==F(3,4) and ehi==1:
                lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75; w0,w1=lo+a*step,lo+b*step
                ff,ss=local_budgets(ns,w0,w1)[0]; f0,s0=ns['two_hit_budgets'][j][0]
                ff=first_budget(ns,w0,w1,min(ff,f0)); ss=min(ss,s0)
                assert ss>ff>0
                cells=[]
                for i in range(a,b):
                    z=witnesses[j,i]; assert list(map(F,z['closed_w']))==[lo+i*step,lo+(i+1)*step]
                    level,=[q for q in z['levels'] if F(q['y4_max'])==F(1,8) and F(q['e_over_sharp_F_min'])==0]
                    assert level['positive'] and all(arb(x)>0 for x in level['margins']) and arb(z['S_old'])>arb(z['F_sharp'])>0
                    cells.append(i)
                row=dict(subcells=[a,b],parent_first=str(ff),parent_second=str(ss),excluded_cells=cells,raw_sha256=sha(partner/'result.json'),audit_sha256=sha(partner/'audit-j34.json'),reason='positive e; y4<=y5<=1/8; parent and cell S>F imply v=e')
                result.append(dict(bin=j,orientation=orientation,counts=counts,e_class=[str(elo),str(ehi)],initial_derivative_sign=side,row=row,positive=True,excluded=True))
                continue
            options=cfg['low_brackets' if side==-1 else 'high_brackets']
            for l,r,k,s in options:
                row=validate(ns,j,F(l),F(r),k,s,side,cut=cut,side=side,begin=a,end=a+1,angular=12,depth=cfg['depth'])
                valid=all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
                if valid:
                    break
            if not valid and b-a>1:
                mid=(a+b)//2
                return visit(j,orientation,side,a,mid)+visit(j,orientation,side,mid,b)
            row['subcells']=[a,b]
            result.append(dict(bin=j,orientation=orientation,counts=counts,e_class=[str(elo),str(ehi)],initial_derivative_sign=side,row=row,positive=valid))
        return result
    partitions={}
    for j in cfg['bins']:
        for orientation in (0,1):
            for side in (-1,1):
                sub=[]
                for a,b in ranges[j]:
                    for l in range(a,b,cfg['block']):
                        chunk=visit(j,orientation,side,l,min(b,l+cfg['block']))
                        sub+=chunk
                        with output.with_suffix(".partial.jsonl").open("a") as f: f.write(json.dumps(dict(bin=j,orientation=orientation,side=side,block=[l,min(b,l+cfg["block"])],rows=chunk))+"\n")
                        print("block",j,orientation,side,l,len(chunk),sum(not t["positive"] for t in chunk),flush=True)
                grouped={}
                for t in sub:
                    key=tuple(t['counts']),tuple(t['e_class'])
                    grouped.setdefault(key,[]).append(t['row']['subcells'])
                common=grouped[((0,5),('0','1'))]
                assert [i for l,r in common for i in range(l,r)]==[i for l,r in ranges[j] for i in range(l,r)]
                assert all(v==common for v in grouped.values())
                partitions[f'{j},{orientation},{side}']=common
                records+=sub
                print(j,orientation,side,len(sub),sum(not t['positive'] for t in sub),flush=True)
    minimum={z:str(min(arb(t['row'][z]).lower() for t in records if not t.get('excluded'))) for z in ('root_margin_lower','placement_margin_lower')}
    here=Path(__file__).resolve()
    sources=(here,here.with_name('ordered_state.py'),here.with_name('sharp_first_hit.py'),here.with_name('ordered_derivative.py'),config,phys_path,
             *(comp/f for f in ('certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py',
                'certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py')))
    output.write_text(json.dumps(dict(complete=True,all_passed=all(r['positive'] for r in records),
        parameters=cfg,tighten_first=True,physical_parameters=phys,reachable=ranges,synchronized=True,partitions=partitions,
        EH_tightening={'label':label,'retreat':str(retreat)},geometry_sha256=sha256(source.encode()).hexdigest(),
        minima=minimum,source_hashes={p.name:sha256(p.read_bytes()).hexdigest() for p in sources},
        partner_raw_sha256=sha(partner/'result.json'),partner_audit_sha256=sha(partner/'audit-j34.json'),python=sys.version,flint=flint_version,rows=records),indent=2)+'\n')


if __name__=='__main__':
    assert __debug__
    p=ArgumentParser(description=__doc__)
    for name in ('comp','config','output'):
        p.add_argument(name,type=Path)
    args=p.parse_args()
    run(args.comp.resolve(),args.config.resolve(),args.output.resolve())

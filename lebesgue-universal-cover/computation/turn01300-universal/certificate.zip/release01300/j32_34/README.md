# 0.01300 物理图第 32–34 格

本包固定 sigma=1.54°、AH pivot .429 / turn .01300、(far,negative,eps)=(.336,.383,.018)、伙伴图终点 .62、老参考端 .43；geometry SHA256 `6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7`。每格四个 orientation/初始导数分支均覆盖其 75 个可达闭细格。

32/33 由同一原始物理支撑核，经四分、八分、十六分、三十二分的有序接触计数分割完成。34 将困难八分端点类以伙伴证书排除，其他类由同一摆放核处理。`partner/audit-j34.json` 中 `old_contact_pattern` 和 `old_deficit_class` 为历史标签；其实际认证仅适用于 `proven_y4_upper=1/8`，拼接仅在 orientation=0、导数负侧、counts=[5,0,0,0,0,0,0,0]、e/F∈[3/4,1] 使用该排除。严格正亏损及零亏损的分支接口仍须总拼接证明处理；此包不单独宣称普适覆盖。

结构核验（写出文件到独立可写目录 OUT），不能替代数值重放：

    PY=python3
    "$PY" -I -B audit_32nd.py 32 "$OUT/audit32.json"
    "$PY" -I -B audit_32nd.py 33 "$OUT/audit33.json"
    "$PY" -I -B audit_join_j34.py 34 "$OUT/audit34.json"
    cmp audit-32nd-j32.json "$OUT/audit32.json"
    cmp audit-32nd-j33.json "$OUT/audit33.json"
    cmp audit-joined-j34.json "$OUT/audit34.json"

逐原核数值重放：

    "$PY" -I -B certify_refined_32nd.py comp012 config-j32-32nd.json "$OUT/replay32.json"
    "$PY" -I -B certify_refined_32nd.py comp012 config-j33-32nd.json "$OUT/replay33.json"
    "$PY" -I -B certify_partner_join_j34.py comp012 config-j34-32nd.json "$OUT/replay34.json"
    cmp result-j32-32nd.json "$OUT/replay32.json"
    cmp result-j33-32nd.json "$OUT/replay33.json"
    cmp result-j34-joined.json "$OUT/replay34.json"

伙伴排除数值重放并审计：

    "$PY" -I -B partner/certify_partner_retention_levels.py comp012 physical-0130.json "$OUT/partner-result.json" 32 33 34
    cmp partner/result.json "$OUT/partner-result.json"
    "$PY" -I -B partner/audit_partner_01300_j34.py comp012 physical-0130.json "$OUT/partner-result.json" "$OUT/partner-audit.json"
    cmp partner/audit-j34.json "$OUT/partner-audit.json"

Python 3.13.18 与 python-flint 0.9.0；计算得到的各回执 SHA256 和最弱余量见三个 audit 文件。源目录搬迁后的三个结构审计已实际重跑并逐字节相同，逐原核数值重放的完成状态另行汇报。

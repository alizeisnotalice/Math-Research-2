"""One-entry verification of the .01300 two-hit cover; --partial reports absent bins."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json,subprocess,sys
P=Path(__file__).resolve().parent;PY=sys.executable;G='6eecedbffa3ab240994e404c1c63cb0cdb13c54706835cff842c8eb733dc5bd7';PH='a30bd9d06c8d83200fbcbc725e7f5962d53f87b3cf9d8eb2a06c4652dabe7acd'
def read(p):return json.loads(p.read_bytes())
def run(cwd,script,*args,log=None):
 command=[PY,'-I','-B',str(script),*map(str,args)]
 if log:
  with log.open('w') as out:subprocess.run(command,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,check=True)
 else:subprocess.run(command,cwd=cwd,stdout=subprocess.DEVNULL,check=True)
def same(a,b):
 x,y=read(a),read(b)
 if 'python' in y:x['python']=y['python']
 assert x==y,(a,b)
def full(out):
 E=P/'early';M=P/'middle';J=P/'j32_34';R=P/'j35_39';T=P/'tail'; f=out/'full';f.mkdir()
 for j in range(16):
  exe='certify_ordered_direct_mixed.py' if j==15 else 'certify_early_sharp.py';args=[E/'comp012']+([E] if j==15 else [])+[E/f'config-{j}.json',f/f'early-{j}.json'];run(E,E/exe,*args,log=f/f'early-{j}.log');same(args[-1],E/f'output-{j}.json')
 for task in read(M/'registry.json'):
  argv=task['argv'];outname=f/mapping_name('middle',task['output']);run(M,M/argv[0],*(M/x for x in argv[1:]),outname,log=f/f"middle-{task['output']}.log");same(outname,M/task['output'])
 for j in (32,33,34):
  exe='certify_partner_join_j34.py' if j==34 else 'certify_refined_32nd.py';suffix='joined' if j==34 else '32nd';target=f/f'j{j}.json';run(J,J/exe,J/'comp012',J/f'config-j{j}-32nd.json',target,log=f/f'j{j}.log');same(target,J/f'result-j{j}-{suffix}.json')
 raw=f/'partner-raw.json';run(J,J/'partner/certify_partner_retention_levels.py',J/'comp012',J/'physical-0130.json',raw,32,33,34,log=f/'partner-raw.log');same(raw,J/'partner/result.json')
 run(R,R/'verify_middle.py',f/'middle35','--full',log=f/'middle35.log');run(T,T/'replay.py',f/'tail',log=f/'tail.log')
def mapping_name(prefix,name):return prefix+'-'+Path(name).name
def main():
 a=argparse.ArgumentParser();a.add_argument('out',type=Path);a.add_argument('--partial',action='store_true');a.add_argument('--full',action='store_true');args=a.parse_args();O=args.out.resolve();assert not O.is_relative_to(P);O.mkdir(parents=True,exist_ok=True);assert not any(O.iterdir()),'output must be empty'
 manifest=P/'MANIFEST.sha256'
 if manifest.exists():
  for line in manifest.read_text().splitlines():
   digest,name=line.split(None,1);f=P/name.strip();assert f.is_file() and sha256(f.read_bytes()).hexdigest()==digest,name
 run(P,P/'verify_evidence.py',log=O/'replay-evidence.log')
 files=[P/'early/physical-0130.json',P/'middle/physical-0130.json',P/'j32_34/physical-0130.json',P/'j35_39/physical.json',P/'tail/physical-0130.json'];assert all(sha256(x.read_bytes()).hexdigest()==PH for x in files)
 run(P,P/'firststage.py',O/'firststage',log=O/'firststage.log');first=read(O/'firststage/result.json');assert first['complete'] and first['geometry_sha256']==G and first['reference_subcells']==5184
 area=read(O/'firststage/area.json');ranges=area['chart']['reference_ranges'];assert set(map(int,ranges))==set(range(70));assert all(ranges[str(j)]==[[0,75]] for j in range(69));assert ranges['69']==[[0,9]]
 E=P/'early';early=O/'early.json';run(E,E/'audit_early.py',early,log=O/'early.log');ed=read(early);assert set(map(int,ed))==set(range(16)) and all(not x['bad'] and x['physical_cells']==75 for x in ed.values())
 M=P/'middle';middle=O/'middle.json';run(M,M/'audit_bins.py',middle,'--partial',log=O/'middle.log');md=read(middle);assert md['geometry_sha256']==G;assert all(not x['bad'] and x['physical_cells']==75 for x in md['bins'].values())
 J=P/'j32_34';js={}
 pa=O/'partner-j34.json';run(J,J/'partner/audit_partner_01300_j34.py',J/'comp012',J/'physical-0130.json',J/'partner/result.json',pa,log=O/'partner-j34.log');assert pa.read_bytes()==(J/'partner/audit-j34.json').read_bytes()
 for j in (32,33,34):
  exe='audit_join_j34.py' if j==34 else 'audit_32nd.py';target=O/f'j{j}.json';run(J,J/exe,j,target,log=O/f'j{j}.log');x=read(target);assert x['j']==j and x['all_passed'] and not x['failed'];raw=read(J/(f'result-j{j}-'+('joined' if j==34 else '32nd')+'.json'));assert raw['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'} and F(raw['parameters']['retreat'])==F(593,6250000000);js[j]=x
 R=P/'j35_39';run(R,R/'verify_middle.py',O/'j35_39',log=O/'j35_39.log');mr=read(O/'j35_39/result.json');assert mr['complete_five_bins'] and mr['bins']==list(range(35,40)) and mr['geometry_sha256']==G
 T=P/'tail';target=O/'tail.json';run(T,T/'compose_tail.py',T,T/'comp012',target,log=O/'tail.log');assert target.read_bytes()==(T/'tail-final.json').read_bytes();tr=read(target);assert tr['complete_tail'] and tr['geometry_sha256']==G and tr['physical_subcells']==2184 and [r['bin'] for r in tr['bins']]==list(range(40,70))
 bins=set(range(16))|set(map(int,md['bins']))|set(js)|set(range(35,70));missing=sorted(set(range(70))-bins);complete=not missing
 result={'complete':complete,'geometry_sha256':G,'physical_sha256':PH,'graph_end':'.62','bins_verified':sorted(bins),'missing_bins':missing,'physical_cells':sum(sum(b-a for a,b in ranges[str(j)]) for j in bins),'firststage':first,'full_interval_replay':False,'independent_replay_ledgers_bound':True,'scope':'actual first EH and graph are recomputed; segment rows structurally audited and selected partner interfaces recomputed; numeric original interval engines require --full'}
 if args.full:
  assert complete,'cannot full-replay an incomplete package';full(O);result['full_interval_replay']=True
 (O/'cover-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert complete or args.partial,f'missing bins {missing}'
if __name__=='__main__':main()

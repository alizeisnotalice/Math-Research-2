# 固定 AH 铰点与 .43 真实配对弧端点的面积障碍

PROOF.md 包含连续角度及面积证明。定理只使用固定几何族的物理弧和十一面 EH，无须任何通用摆放证书。参数表、全段符号、原 Gibbs 真面积以及两个极近有理夹角的真实 AH/EH 面积给出在四份 JSON 中。

Python 3.13.18，python-flint 0.9.0。在包内运行

    python -I -B replay.py /path/to/scratch --full

完整重算会在提供的独立目录中从源码产生四份回执，逐字节核对。去掉 --full 可核对来源哈希、全部断点、严格夹逼和最终有理不等式。

第232轮的四支撑必要条件在 PROOF.md 末段单独引用。该轮证明文件 proofs/relaxed-gibbs-supports.md 的 SHA-256 为 3052cdcdd4d54bcf62c35ddc19ac341312eb91da3d7cb0717987cbd0d2e1fa17，回执 computation/relaxed-gibbs-supports/sharper-wall.json 为 13c43e0d34ec0f517f1ae2439791d1f1fda687260799fc7affc2b0e26f226714。本包从源码重算上文的新 .43 障碍。

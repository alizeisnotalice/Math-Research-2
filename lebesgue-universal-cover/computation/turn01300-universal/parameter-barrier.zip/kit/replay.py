"""Re-evaluate the fixed-pivot true-curve endpoint and its two areas."""
import argparse,hashlib,json,shutil,subprocess,sys
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx
ctx.prec=160
p=argparse.ArgumentParser();p.add_argument('scratch',type=Path);p.add_argument('--full',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
for n,h in read(root/'manifest.json').items():assert sha(root/n)==h,n
raw=root
if a.full:
    raw=a.scratch.resolve();assert raw!=root;raw.mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'comp',raw/'comp',dirs_exist_ok=True)
    for f in ['parameter_curve.py','arc_sides.py','reference_barrier.py']:
        shutil.copyfile(root/f,raw/f)
        subprocess.run([sys.executable,'-I','-B',str(raw/f)],cwd=raw,check=True)
    for name in ['parameter-curve.json','arc-sides.json','gibbs-raw.json','reference-barrier.json']:
        assert sha(raw/name)==sha(root/name),name
curve=read(raw/'parameter-curve.json');side=read(raw/'arc-sides.json');bar=read(raw/'reference-barrier.json')
assert curve['cell_count']==1610 and curve['domain']==['.300','.461'] and arb(curve['angle_derivative'][0])>0 and arb(curve['projection_derivative'][0])>0
assert side['pre_partition']==['0','.300',300] and side['post_partition']==['.461','1',539]
assert all(Q(side[k])>0 for k in ['within_cut_lower','retained_lower','tangent_projection_lower'])
threshold=arb(curve['pointwise']['43/100']['angle'])
def qarb(x):return arb(x.numerator)/x.denominator
t=list(map(Q,side['turns']));assert qarb(t[0])<threshold<qarb(t[1])
assert t==[Q(s['turn']) for s in bar['sides']]
assert Q(bar['sides'][0]['cross']['exact'][1])<Q('.43')<Q(bar['sides'][1]['cross']['exact'][0])
bounds=[Q(bar['sides'][1]['area']['exact'][0]),Q(bar['sides'][0]['area']['exact'][1])]
assert Q(bar['critical_area_lower'])<bounds[0]<bounds[1]<Q(bar['critical_area_upper'])
assert Q(bar['critical_area_lower'])>Q('.844082046521218581802948589770767704354')+Q('.0000040385257')
assert all(Q(r['AH_EH_clearance']['exact'][0])>0 for r in bar['sides'])
assert 'rebuilt_eleven_EH' in bar
print('Verified .43 fixed-family area lower bound',bar['critical_area_lower'])

"""Certify signs outside the inverse-angle strip for the two rational enclosing cuts."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
root=Path(__file__).resolve().parent;comp=root/'comp';sys.path.insert(0,str(comp))
p=comp/'certify_ah_combined_area.py'
s=p.read_text().split('start, finish =',1)[0].replace('sigma = "1.5497"','sigma = "1.54"').replace('F("0.38")','F(".429")').replace('order, cells = 14, 24','order, cells = 2, 24')
n={'__file__':str(p)};exec(compile(s,str(p),'exec'),n)
I,curve,jet,sub,add,mul,dot,cross,perp,b,W,trig=[n[k] for k in ('I','curve','curve_series','sub','add','mul','dot','cross','perp','b','W','trig')]
ds=[F('.01871413993999316874486'),F('.01871413993999316874487')]
directions=[add(mul(I(*trig.trig((d,d),'cos')),b),mul(I(*trig.trig((d,d),'sin')),perp(b))) for d in ds]
kept=lost=None;minimum_tangent=None
for k in list(range(300))+list(range(461,1000)):
    left,right=F(k,1000),F(k+1,1000);mid=(left+right)/2
    v=sub(curve(mid),W);q=jet(I(left,right));dv=tuple(t.c[1] for t in q);delta=I(left-mid,right-mid)
    along=dot(b,v)+delta*dot(b,dv)
    assert along.lo>0
    minimum_tangent=along.lo if minimum_tangent is None else min(minimum_tangent,along.lo)
    for direct in directions:
        val=cross(direct,v)+delta*cross(direct,dv)
        if k<300:
            assert val.hi<0,(k,float(val.hi))
            lost=-val.hi if lost is None else min(lost,-val.hi)
        else:
            assert val.lo>0,(k,float(val.lo))
            kept=val.lo if kept is None else min(kept,val.lo)
out=dict(turns=list(map(str,ds)),pre_partition=['0','.300',300],post_partition=['.461','1',539],within_cut_lower=str(lost),retained_lower=str(kept),tangent_projection_lower=str(minimum_tangent),sha256=sha256(Path(__file__).read_bytes()).hexdigest())
(root/'arc-sides.json').write_text(json.dumps(out,indent=2)+'\n')

"""Bound the exact first and second variation of true AH loss along the fixed hinge."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
ctx.prec=160
D=Path(sys.argv[1]).resolve();C=D/'comp';sys.path.insert(0,str(C))
source=C/'certify_ah_combined_area.py'
s=source.read_text().split('start, finish =',1)[0].replace('sigma = "1.5497"','sigma = "1.54"').replace('F("0.38")','F(".429")').replace('order, cells = 14, 24','order, cells = 2, 24')
n={'__file__':str(source)};exec(compile(s,str(source),'exec'),n)
I,curve,jet,dot,sub,cross,W,add,mul=[n[k] for k in ['I','curve','curve_series','dot','sub','cross','W','add','mul']]
def A(z):return arb(z.numerator)/z.denominator
def box(v):return [str(A(min(z.lo for z in v))),str(A(max(z.hi for z in v)))]
scope=json.loads((D/'parameter-curve.json').read_bytes())
left=F('.325');right=F('.430');rows=[]
for k in range(3250,4300):
 a,b=F(k,10000),F(k+1,10000);mid=(a+b)/2
 h=jet(I(a,b));qp=tuple(x.c[1] for x in h)
 v=add(sub(curve(mid),W),mul(I(a-mid,b-mid),qp));radius2=dot(v,v)
 slope=cross(v,qp)/radius2;radial=dot(v,qp)
 assert min(radius2.lo,slope.lo,radial.lo)>0
 rows.append((radius2/2,radial/slope))
points=scope['pointwise']
assert arb(points[str(left)]['angle'])<A(F('.01250'))
assert arb(points[str(right)]['angle'])>A(F('.01871'))
out=dict(physical_w=[str(left),str(right)],depth_interval=['.01250','.01871'],cells=len(rows),first_derivative=box([z[0] for z in rows]),second_derivative=box([z[1] for z in rows]),sha256=sha256(Path(__file__).read_bytes()).hexdigest(),curve_sha256=sha256((D/'parameter-curve.json').read_bytes()).hexdigest())
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(out)

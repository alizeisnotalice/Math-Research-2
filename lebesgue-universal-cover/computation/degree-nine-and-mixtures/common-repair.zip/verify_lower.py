"""Verify an area increment for any rotation, reflection and translation of the central profile."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from functools import lru_cache
import json
from verify import inputs, read, digest, A, F, arb, Profile, SCALE, ROOT
N=16384
def run(weight,plan_name,threshold):
 base=inputs();parents=[Profile(read(n)) for n in ('parent-a.json','parent-b.json')];plan=read(plan_name)
 normals=[(v[1]-u[1],u[0]-v[0]) for u,v in zip(base,base[1:]+base[:1])]
 @lru_cache(None)
 def point(j):
  assert isinstance(j,int) and 0<=j<N
  (ya,va),(yb,vb)=[p.at(j*2,N) for p in parents]
  y=A(weight)*ya+A(1-weight)*yb;v=A(weight)*va+A(1-weight)*vb
  sn,cs=(2*arb.pi()*j/N).sin_cos()
  return (y+A('0.5'))*cs-v*sn,(y+A('0.5'))*sn+v*cs
 @lru_cache(None)
 def sc(t):return (2*arb.pi()*A(t)).sin_cos()
 counts={};least=None
 assert set(plan)=={'-1','1'}
 for hand,boxes in plan.items():
  s=int(hand);previous=F(0)
  for l,h,ones,free in boxes:
   lo,hi=F(l),F(h);assert lo==previous and 0<hi-lo<F(1,2)
   previous=hi
   alpha=beta=arb(0);balance=[F(0),F(0)];constant=F(0);seen=set()
   for i,j,q in [(i,j,F(1)) for i,j in ones]+[(i,j,F(q)) for i,j,q in free]:
    assert 0<=i<len(base) and i not in seen and 0<=q<=1
    seen.add(i);nx,ny=normals[i];vx,vy=base[i];px,py=point(j)
    balance[0]+=nx*q;balance[1]+=ny*q;constant+=q*(vx*nx+vy*ny)
    alpha+=A(q)*(nx*px+s*ny*py);beta+=A(q)*(ny*px-s*nx*py)
   assert balance==[0,0]
   for v in (lo,hi):
    sn,cs=sc(v);raw=(alpha*cs+beta*sn)/(2*SCALE)
    diff=raw-A(constant/(2*SCALE**2))
    assert raw>0 and diff>A(threshold)
    least=diff.lower() if least is None else min(least,diff.lower())
  assert previous==1;counts[hand]=len(boxes)
 return dict(weight=str(weight),plan_sha256=digest(plan_name),angle_boxes=counts,material_points=point.cache_info().currsize,
             verified_lower_bound=threshold,weakest_directed_endpoint=str(least))
if __name__=='__main__':
 out=[run(F('0.3'),'area-lower-plan.json','0.00000012856'),
      run(F('0.766'),'family-plan.json','0.00000036428')]
 if (ROOT/'lower-receipt.json').exists():assert out==read('lower-receipt.json')
 print(json.dumps(out,indent=2))

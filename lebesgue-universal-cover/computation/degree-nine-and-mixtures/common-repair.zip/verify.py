"""Reconstruct a rational polygon enclosing two complete curvature profiles and a fixed base."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
from decimal import Decimal, getcontext

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from flint import arb,ctx
from profile_source import Profile

SCALE=10**12
N=65536
PAD=1160
B=F('.844082046521218581802948589770767704354')
sources={
 'parent-a.json':'1cbc3e46182f65f8e6da58a58f468b8ec88fabf8988c2756c6b7808e45b52dd7',
 'parent-b.json':'678e9b6ab849782d89f33cbaa36a060040c5f75a5fe9067107296813652187fd',
 'mix-0.json':'cd0b80653d0e1bfc879f22682a55b657371aaf39c6175fb31218438ff72df2f8'}
def digest(name):
 return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def read(name):return json.loads((ROOT/name).read_bytes())
def decimal(x):return str(Decimal(x.numerator)/Decimal(x.denominator))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def convex(points):
 def side(seq):
  chain=[]
  for p in seq:
   while len(chain)>=2 and cross(chain[-2],chain[-1],p)<=0:chain.pop()
   chain.append(p)
  return chain[:-1]
 ordered=sorted(set(points))
 return side(ordered)+side(reversed(ordered))
def area(points,den=SCALE):
 return F(sum(x*v-y*u for (x,y),(u,v) in zip(points,points[1:]+points[:1])),2*den**2)
def buffered(points,pad):
 return [(x+i*pad,y+j*pad) for x,y in points for i in (-1,1) for j in (-1,1)]
def A(x):x=F(x);return arb(x.numerator)/x.denominator
def rounded(z):
 t=z*SCALE;m,e=map(int,t.mid().man_exp())
 k=round(F(m)*F(2)**e)
 assert abs(t-k)<1
 return k
def material(name,pose):
 assert digest(name)==sources[name]
 w=Profile(read(name))
 c=A(pose['q']);sn=2*c/(1+c*c);cs=(1-c*c)/(1+c*c)
 if pose['halfturn']:sn,cs=-sn,-cs
 s=pose['hand'];assert s in (-1,1)
 tx,ty=map(A,[pose['tx'],pose['ty']])
 cloud=[]
 for i in range(N):
  y,d=w.at(2*i,N)
  si,co=(2*arb.pi()*i/N).sin_cos()
  x=(A('.5')+y)*co-d*si
  z=s*((A('.5')+y)*si+d*co)
  cloud.append((rounded(tx+cs*x-sn*z),rounded(ty+sn*x+cs*z)))
 return convex(cloud)
def check_host(poly):
 assert poly==convex(poly)
 assert all(max(map(abs,p))<SCALE for p in poly)
def save(name,poly):
 check_host(poly)
 raw=(json.dumps(dict(denominator=SCALE,vertices=poly),separators=(',',':'))+'\n').encode()
 dst=ROOT/name
 if dst.exists():assert dst.read_bytes()==raw,name
 else:dst.write_bytes(raw)
 return dict(vertices=len(poly),area=decimal(area(poly)),budget_slack=decimal(B-area(poly)),sha256=digest(name))
def inputs():
 assert __debug__
 ctx.prec=192;getcontext().prec=80
 assert digest('profile_source.py')=='2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'
 assert digest('host.json')=='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'
 assert all(digest(n)==h for n,h in sources.items())
 parent_a,parent_b,center=(read(n) for n in sources)
 assert parent_a['grid']==parent_b['grid']==center['grid']
 for a,b,c in zip(parent_a['pieces'],parent_b['pieces'],center['pieces'],strict=True):
  assert a[0]==b[0]==c[0] and (a[1] is None)==(b[1] is None)==(c[1] is None)
  if a[1] is not None:assert 3*F(a[1])+7*F(b[1])==10*F(c[1])
 src=read('host.json');base=list(map(tuple,src['vertices']))
 assert src['denominator']==SCALE and len(base)==1189
 k=base.index(min(base));assert base[k:]+base[:k]==convex(base)
 return base

def run():
 base=inputs()
 assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
 singleton,full=read('center-poses.json'),read('line-poses.json')
 assert len(singleton)==1 and F(singleton[0]['weight'])==F(3,10)
 assert [F(p['weight']) for p in full]==[0,1]
 assert all(full[0][k]==full[1][k] for k in ('q','halfturn','hand'))
 plain=dict(q='0',halfturn=True,hand=-1,tx='0',ty='0')
 result=dict(original_area=decimal(area(base)),original_budget=decimal(B-area(base)),samples=N,pad=PAD,results={})
 for label,parts in [('center',[('mix-0.json',singleton[0])]),('line',[('parent-b.json',full[0]),('parent-a.json',full[1])]),('simple',[('parent-a.json',plain),('parent-b.json',plain)])]:
  joined=convex(pt for name,pose in parts for pt in material(name,pose))
  poly=convex(base+buffered(joined,PAD));assert area(poly)<B
  row=save('host-'+label+'.json',poly)
  row['increase']=decimal(area(poly)-area(base))
  result['results'][label]=row
 return result
if __name__=='__main__':
 result=run()
 if (ROOT/'receipt.json').exists():assert result==read('receipt.json')
 print(json.dumps(result,indent=2))

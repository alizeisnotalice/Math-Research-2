"""Check two orientation intervals whose endpoint maps have affine translations."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import verify as v
from verify import A,F,arb,Profile,ROOT,SCALE,N,PAD,convex,save,rounded,inputs,area,decimal,B,buffered,read
from functools import lru_cache
@lru_cache(None)
def shaped(w):
 parents=[Profile(read(n)) for n in ('parent-a.json','parent-b.json')]
 p=[]
 for j in range(N):
  sa,sb=[shape.at(2*j,N) for shape in parents]
  y=A(w)*sa[0]+A(1-w)*sb[0]+A('.5');dy=A(w)*sa[1]+A(1-w)*sb[1]
  sn,cs=(2*arb.pi()*j/N).sin_cos()
  p.append((y*cs-dy*sn,y*sn+dy*cs))
 return p
def run():
 base=inputs();assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
 poses=read('two-poses.json')
 w=[F(p['weight']) for p in poses]
 assert len(w)==4 and w[0]==0 and w[3]==1 and 0<w[1]==w[2]<1
 for i in (0,2):
  assert all(poses[i][k]==poses[i+1][k] for k in ('q','halfturn','hand'))
 points=[]
 for p,t in zip(poses,w):
  q=A(p['q']);sn,cs=2*q/(1+q*q),(1-q*q)/(1+q*q)
  if p['halfturn']:cs,sn=-cs,-sn
  s=p['hand'];assert s in (-1,1)
  tx,ty=A(p['tx']),A(p['ty'])
  points.extend(convex((rounded(cs*x-s*sn*y+tx),rounded(sn*x+s*cs*y+ty)) for x,y in shaped(t)))
 out=convex(base+buffered(convex(points),PAD))
 assert area(out)<F('.844081416714403344449732')
 return dict(split=str(w[1]),host=save('host-two.json',out),increase=decimal(area(out)-area(base)))
if __name__=='__main__':
 result=run()
 if (ROOT/'two-receipt.json').exists():assert result==read('two-receipt.json')
 print(json.dumps(result,indent=2))

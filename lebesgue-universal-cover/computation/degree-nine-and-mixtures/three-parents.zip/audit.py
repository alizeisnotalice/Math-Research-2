from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,subprocess,sys
D={'host-two.json':'1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4','parent-a.json':'1cbc3e46182f65f8e6da58a58f468b8ec88fabf8988c2756c6b7808e45b52dd7','parent-b.json':'678e9b6ab849782d89f33cbaa36a060040c5f75a5fe9067107296813652187fd','parent-c.json':'9a610c360a0d47bb1af8b1c021e78858e9721b0f9ccffa41d765f5a0f2eb258b','profile_source.py':'2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'}
for name,digest in D.items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
host=json.loads(Path('host-two.json').read_text());v=host['vertices'];assert len(v)==2230 and int(host['denominator'])>0
for i,(x,y) in enumerate(v):
 xx,yy=v[(i+1)%len(v)];dx=xx-x;dy=yy-y;assert dx or dy
 assert all(dx*(Y-y)-dy*(X-x)>=0 for X,Y in v)
print('verified hashes and all 2230 integer host halfplanes',flush=True)
# barycentric plane coordinates (A,C); B=(0,0), C=(0,1), N=(.928,0), M=(.92969,.07031), A=(1,0).
B=(F(0),F(0));C=(F(0),F(1));N=(F('0.928'),F(0));M=(F('0.92969'),F('0.07031'));A=(F(1),F(0))
def double_area(poly):return abs(sum(p[0]*q[1]-p[1]*q[0] for p,q in zip(poly,poly[1:]+poly[:1])))
assert double_area([B,N,M,C])+double_area([N,A,M])==double_area([B,A,C])==1
assert 0<N[0]<M[0]<1 and M[0]+M[1]==1
print('verified exact partition into convex quadrilateral and triangle',flush=True)
for script in ['certify_first.py','certify_second.py']:subprocess.run([sys.executable,'-I','-B',script],check=True)
print('PASS full three-parent closed simplex')

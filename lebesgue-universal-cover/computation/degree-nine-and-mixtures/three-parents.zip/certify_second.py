from pathlib import Path
import json,math
from fractions import Fraction
from flint import arb,ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from profile_source import Profile
ctx.prec=192
F=lambda x:arb(Fraction(str(x)).numerator)/Fraction(str(x)).denominator
P=[Profile(json.loads(Path('parent-'+k+'.json').read_text())) for k in 'abc'];host=json.loads(Path('host-two.json').read_text());den=F(host['denominator']);V=[tuple(F(z)/den for z in x) for x in host['vertices']]
# Same orientation at all three vertices; halfturn rational tangent half angle.
q=F('1.7320245742323956');cs=(1-q*q)/(1+q*q);sn=2*q/(1+q*q);hand=-1
cases=[('A',['1','0','0'],['-0.000000830022470085','0.000002065741063854']),('N_AB',['0.928','0.072','0'],['-0.000000830011012138','0.000002065716602405']),('M_AC',['0.92969','0','0.07031'],['-0.000000833329464638','0.000002064623146199'])]
mins=[None]*len(cases)
for i,v in enumerate(V):
 w=V[(i+1)%len(V)];nx=w[1]-v[1];ny=v[0]-w[0];L=(nx*nx+ny*ny).sqrt();U=( (cs*nx+sn*ny)/L, hand*(-sn*nx+cs*ny)/L );vals=[p.support(U) for p in P];b=nx*v[0]+ny*v[1]
 for j,(_,weights,trans) in enumerate(cases):
  h=sum(F(k)*a for k,a in zip(weights,vals));margin=(b-nx*F(trans[0])-ny*F(trans[1]))/L-h
  if mins[j] is None or margin.lower()<mins[j].lower():mins[j]=margin
 if i%300==0:print(i,flush=True)
for c,m in zip(cases,mins):print(c[0],m,'positive',m>0,flush=True);assert m>0
Path('triangle-second-receipt.json').write_text(json.dumps({'host_sha256':'1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4','q':str(q),'halfturn':False,'hand':hand,'precision_bits':192,'cases':[{'name':c[0],'weights':c[1],'translation':c[2],'margin':str(m)} for c,m in zip(cases,mins)]},indent=2))

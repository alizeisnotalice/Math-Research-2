from flint import arb
def check(B):
 T=arb.pi()/3;L=T/2
 def area(r):
  R=arb(1)/2+r
  a=(1/(2*R)).acos()
  return 3*((L.tan()+a.tan())/4+R*R*(L-a))
 lo=arb(0);hi=arb('.07')
 for _ in range(110):
  m=(lo+hi)/2;x=area(m)
  if x<B:lo=m
  else:assert x>B;hi=m
 budget=lo.union(hi)
 assert budget>arb('.01722295')
 lo=arb(0);hi=L
 for _ in range(110):
  m=(lo+hi)/2
  a=3*(3*m).tan();b=2*(T-2*m).tan()
  if a<b:lo=m
  else:assert a>b;hi=m
 m=lo.union(hi);r=(3*m).cos()*(T-2*m).cos()/24;Ar=area(r)
 assert r>arb('.02764438001973656') and Ar>arb('.8515983302553623') and area(arb(1)/48)>B
 def corner(value):
  R=arb(1)/2+value
  a=(1/(2*R)).acos()
  return a.tan()/4+R*R*(L-a)
 def unequal(x,y,z):return 3*L.tan()/4+corner(x)+corner(y)+corner(z)
 lo=arb(0);hi=arb('.025')
 for _ in range(85):
  t=(lo+hi)/2;s=unequal(r,t,t)
  if s<B:lo=t
  else:assert s>B;hi=t
 small_limit=lo.union(hi)
 spread=r-small_limit
 assert spread>arb('.01474355120484')
 lo=T/4;hi=L
 for _ in range(90):
  t=(lo+hi)/2;x=3*(3*t).tan();y=2*(2*T-2*t).tan()
  if x<y:lo=t
  else:assert x>y;hi=t
 t=lo.union(hi);sm=(3*t).cos()*(2*T-2*t).cos()/24
 assert sm<arb('.0042')
 asym=unequal(arb(1)/24,arb('.0042'),arb('.0042'))
 assert asym<B
 return dict(unequal_small_radius_upper=str(small_limit),required_radius_spread=str(spread),
             small_radius_for_one_peak=str(sm),feasible_asymmetric_area=str(asym),budget_r=str(budget),threshold_body_r=str(r),extreme_degrees=str(m*180/arb.pi()),least_template_area=str(Ar))

import sys,time,json
from pathlib import Path
from itertools import combinations,product
from collections import defaultdict,Counter
from functools import lru_cache
from math import gcd
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from make_integer import build,Q
from flint import fmpz_mat
C,B,phys=build()
M=len(phys);N=len(B);dim=7
planes=[tuple(t)+(-Q//2-7,) for t in phys]
planes+=[(-1,0,0,0,0,0,0,0),(0,0,0,-578,1000,0,0,0),(0,0,0,-578,-1000,0,0,0)]
BOX=len(planes)
for i in range(dim):
 for sign in (-1,1):planes.append(tuple(sign if k==i else 0 for k in range(dim))+(-1,))
CUT=len(planes)
planes += [tuple(map(int,c))+(-int(b)+32,) for rs in C for c,b in zip(rs,B)]
def dot(a,b):
 return sum(i*j for i,j in zip(a,b))
def primitive(v):
 g=gcd(*v);g=g if v[-1]>0 else -g
 return tuple(x//g for x in v)
@lru_cache(maxsize=250000)
def independent(*labels):
 assert len(labels)==dim-1
 return fmpz_mat([list(planes[i][:-1]) for i in labels]).rank()==dim-1
def split(P,cut,j,both):
 nu=planes[cut];pos={};neg={};val={};zeros={}
 for v,ac in P.items():
  d=dot(nu,v);val[v]=d
  if d>0:pos[v]=ac
  elif d<0:neg[v]=ac
  else:zeros[v]=ac|{cut}
 if not pos:return dict(neg|zeros), dict(zeros) if both else {}
 if not neg:return dict(zeros),dict(pos|zeros) if both else {}
 # Enumerate all edges crossing this plane. Edge endpoints have five
 # independent common active normals, in addition to the root equality.
 groups=defaultdict(list)
 for v,ac in neg.items():
  for t in combinations(sorted(ac),dim-2):
   if independent(j,*t):groups[t].append(v)
 for w,ac in pos.items():
  touched=set()
  for t in combinations(sorted(ac),dim-2):touched.update(groups.get(t,()))
  for v in touched:
   a,b=val[w],-val[v];z=primitive(tuple(a*i+b*k for i,k in zip(v,w)))
   active=(neg[v]&ac)|{cut}
   if z in zeros:zeros[z]|=active
   else:zeros[z]=active
 return neg|zeros,(pos|zeros) if both else {}
def initial(j):
 a=planes[j];p=max(range(dim),key=lambda k:abs(a[k]));f=[k for k in range(dim) if k!=p];P={}
 for signs in product((-1,1),repeat=dim-1):
  v=[0]*dim
  for i,s in zip(f,signs):v[i]=s*a[p]
  v[p]=-a[-1]-sum(a[i]*s for i,s in zip(f,signs))
  ac=frozenset(BOX+2*i+(s>0) for i,s in zip(f,signs))
  P[primitive(tuple(v)+(a[p],))]=ac
 for n in [BOX+2*p,BOX+2*p+1,M,M+1,M+2]+[i for i in range(M) if i!=j]:
  if not P:break
  P=split(P,n,j,False)[0]
 return P
# A rational vertex has |x_i|<=1. Cache directed-integer lower tests for every
# pose, measured in Q^{-2} units, after flooring all seven coefficients.
@lru_cache(maxsize=130000)
def support(v):
 X=np.array([x*Q//v[-1] for x in v[:-1]],dtype=np.int64)
 assert np.max(abs(X))<=Q
 # Every dot is safely within 2^63: each |C_i|<=Q/8+1 and |X_i|<=Q.
 g=B*Q-C@X
 return g.min(axis=1)
def verify_node(P,j,tree,stats,counts):
 if not P:
  assert tree==-1
  return
 if isinstance(tree,int):
  assert 0<=tree<12
  smallest=min(int(support(v)[tree]) for v in P)
  assert smallest>=4*Q,(j,tree,smallest)
  stats["lowest_integer_margin"]=min(stats["lowest_integer_margin"],smallest)
  stats["closed_cells"]+=1;counts[tree]+=1
  return
 cut,left,right=tree
 assert isinstance(cut,int) and CUT<=cut<len(planes)
 P0,P1=split(P,cut,j,True)
 stats["exact_splits"]+=1
 verify_node(P0,j,left,stats,counts)
 verify_node(P1,j,right,stats,counts)
def verify():
 from flint import arb,ctx
 from fractions import Fraction as F
 from decimal import Decimal,getcontext
 assert __debug__
 ctx.prec=160;getcontext().prec=70
 cells=json.loads((ROOT/"cells.json").read_bytes());assert len(cells)==72
 assert C.shape==(12,1178,7) and np.max(abs(C))<=Q//8+1
 assert planes[M:M+3]==[(-1,0,0,0,0,0,0,0),(0,0,0,-578,1000,0,0,0),(0,0,0,-578,-1000,0,0,0)]
 counts=[0]*12
 stats={"closed_cells":0,"exact_splits":0,"lowest_integer_margin":10**30}
 facets=[]
 for j,tree in enumerate(cells):
  P=initial(j)
  pre=stats["closed_cells"]
  verify_node(P,j,tree,stats,counts)
  facets.append([len(P),stats["closed_cells"]-pre])
 source=json.loads((ROOT/'host.json').read_bytes())
 v=source['vertices'];D=source['denominator']
 area=F(sum(a*d-b*c for (a,b),(c,d) in zip(v,v[1:]+v[:1])),2*D**2)
 assert area==F('.844080666618632325284184')
 length=sum(arb((a-c)**2+(b-d)**2).sqrt() for (a,b),(c,d) in zip(v,v[1:]+v[:1]))/D
 r=arb(40966)/10**11
 thick=arb(area.numerator)/area.denominator+r*length+arb.pi()*r*r
 assert thick<arb('.844082046521218581802948589770767704354')
 Psign=arb(3).sqrt()+arb.pi()/2;Asign=Psign/4;budget=arb('.844082046521218581802948589770767704354')
 rsign=arb(553283)/10**8;As=Asign+Psign*rsign+arb.pi()*rsign**2
 rstar=2*(budget-Asign)/(Psign+(Psign**2+4*arb.pi()*(budget-Asign)).sqrt())
 assert rstar>rsign and As<budget
 from sector_check import check
 return {"circular_cuts":check(budget),"sign_sector_radius":"0.00553283","sign_sector_parallel_area":str(As),"sign_sector_threshold":str(rstar),"support_degree":9,"chosen_translation":["0",".00000019"],"coordinate_names":["8A","80F","80E","24C","24D","48G","48H"],"faces_kept":len(B),"stage_counts":stats,"curvature_facets":[list(x) for x in facets],
         "poses":counts,"source_area":str(Decimal(area.numerator)/Decimal(area.denominator)),
         "perimeter":str(length),"extra_radius":"0.00000040966","parallel_area":str(thick)}
if __name__=='__main__':
 result=verify()
 rec=ROOT/'receipt.json'
 if rec.exists():assert result==json.loads(rec.read_bytes())
 print(json.dumps(result,indent=2))

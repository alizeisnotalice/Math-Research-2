"""Verify a simultaneous lower area for two independently moved constant-width inputs."""
from pathlib import Path
from functools import lru_cache
import itertools,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT if (ROOT/'verify.py').exists() else ROOT.parent))
from verify import F,A,arb,Profile,read,inputs,SCALE
def run():
 base=inputs()
 data=json.loads((ROOT/'joint-plan.json').read_bytes())
 parents=[Profile(read(n)) for n in ['parent-a.json','parent-b.json']]
 W=list(map(F,data['weights']));assert W==[F(73,100),F(22,25)]
 target=F(data['target']);assert target>=F('0.00000042')
 N=16384
 normals=[(v[1]-u[1],u[0]-v[0]) for u,v in zip(base,base[1:]+base[:1])]
 @lru_cache(None)
 def point(w,j):
  assert 0<=j<N
  (a,b),(c,d)=[p.at(2*j,N) for p in parents];y=A('.5')+A(w)*a+A(1-w)*c;v=A(w)*b+A(1-w)*d
  sn,cs=(2*arb.pi()*j/N).sin_cos()
  return (y*cs-v*sn,y*sn+v*cs)
 @lru_cache(None)
 def sc(v):return (2*arb.pi()*A(v)).sin_cos()
 def evalrow(w,s,l,h,rows):
  assert 0<=l<h<=1 and h-l<F(1,2)
  if not rows:return arb(0),{}
  balx=baly=constant=F(0);alpha=beta=arb(0);qmap={}
  for i,j,q in rows:
   q=F(q);assert 0<=q<=1 and 0<=i<len(base) and i not in qmap
   qmap[i]=q;nx,ny=normals[i];vx,vy=base[i];px,py=point(w,j)
   balx+=q*nx;baly+=q*ny;constant+=q*(vx*nx+vy*ny)
   alpha+=A(q)*(nx*px+s*ny*py);beta+=A(q)*(ny*px-s*nx*py)
  assert balx==baly==0
  ends=[]
  for t in (l,h):
   sn,cs=sc(t);raw=(cs*alpha+sn*beta)/(2*SCALE);assert raw>0
   ends.append((raw-A(constant/(2*SCALE**2))).lower())
  return min(ends),qmap
 holes=[];solo_count=[];minsingle=None;least=None
 for w,table in zip(W,data['singles'],strict=True):
  hh={};nn={}
  assert set(table)=={'1','-1'}
  for s in (1,-1):
   prev=F(0);hh[s]=[];nn[str(s)]=0
   for row in table[str(s)]:
    l,h=map(F,row[:2]);assert prev==l and 0<h-l<F(1,2);prev=h
    if len(row)==2:hh[s].append((l,h));continue
    assert len(row)==4
    ones,free=row[2:]
    score,_=evalrow(w,s,l,h,[(i,j,1) for i,j in ones]+free)
    assert score>A(target);nn[str(s)]+=1
    minsingle=score if minsingle is None else min(minsingle,score)
   assert prev==1
  holes.append(hh);solo_count.append(nn)
 leaves=0
 def tree(b,ss,node):
  nonlocal leaves,least
  a=node[0]
  if a=='ok':
   assert len(node)==2 and len(node[1])==2
   (sa,qa),(sb,qb)=[evalrow(w,s,*br,raw) for w,s,br,raw in zip(W,ss,b,node[1],strict=True)]
   assert all(v+qb.get(i,0)<=1 for i,v in qa.items())
   score=(sa+sb).lower();assert score>A(target)
   leaves+=1;least=score if least is None else min(least,score);return
  assert a in (0,1) and len(node)==3
  l,h=b[a];m=(l+h)/2
  for bb,nxt in zip([(l,m),(m,h)],node[1:],strict=True):
   arr=list(b);arr[a]=bb;tree(arr,ss,nxt)
 for ss in itertools.product((1,-1),repeat=2):
  nodes=data['pairs'][','.join(map(str,ss))]
  for b,node in zip(itertools.product(*(hs[s] for hs,s in zip(holes,ss))),nodes,strict=True):tree(b,ss,node)
 return dict(weights=list(map(str,W)),area_increment_gt=str(target),single_boxes=solo_count,
             residual_product_leaves=leaves,min_single=str(minsingle),min_joint=str(least))
if __name__=='__main__':
 result=run()
 if (ROOT/'joint-receipt.json').exists():assert result==json.loads((ROOT/'joint-receipt.json').read_bytes())
 print(json.dumps(result,indent=2))

# A nonconvex embedding class on the fixed 1189-edge host

The frozen rational host has SHA-256 `a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f`. Let (A) be the earlier 16-piece profile from the fixed-C150 obstruction and let (D) be the 16-piece input 16601. They share the same normalized six face normals and the same curvature interval endpoints. The body of parameter (w) is the Minkowski combination (wA+(1-w)D) in these coordinates.

The host contains (A) and (D) individually. All 1189 face inequalities are checked with their specific rational rotations, reflections, and translations. At the pose of (D) the whole interval (0\le w\le519501/500000000) also fits. At the pose of (A) the entire interval (1-700831/500000000\le w\le1) fits. Thus the endpoint coverage has quantitative slack.

For every (w\in[1/10,4/5]) and every rigid placement, at least one point of the mixed body has Euclidean distance greater than (5.30702\times10^{-7}) from this fixed host. On (w\in[1/5,13/20]) the lower bound is greater than (1.10677\times10^{-6}). The example (w=3/10) has a separate stronger certificate with lower bound (1.85176\times10^{-6}). These comparisons include both hands, all rotation angles and arbitrary common translation.

Every selected row balances exact nonnegative weights on integer normals. Translation cancels. At every corner of an angle and weight rectangle the sum of projections of four actual material points exceeds the host support sum. With fixed normal parameters these points depend affinely on the mixing weight because the support and its first derivative do. Positive sine interpolation propagates the endpoint inequality to the whole closed angle cell. The rows are normalized by the directed weighted Euclidean lengths. The outer interval uses 110 closed angle cells per hand, while the inner interval uses 104 and 107. Each proof covers a single weight interval.

All conclusions concern the fixed host and the named normalized class. The separate endpoint fits and the missed middle interval exhibit nonconvexity in the support functions. They also show that the host cannot contain the two parents in one common pose.

Run with an existing Python supporting python-flint.

```sh
PY -I -B verify_all.py OUT
```

The entry point regenerates the four receipts from the exact fixture, checks their hashes, and compares the numerical fields byte for byte. It uses no numerical optimizer for the proof.

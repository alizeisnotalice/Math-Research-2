"""Replay the two endpoint fits and the closed coefficient noncontainment certificates."""

from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from certify_mix_band import mixture


def main(out):
    assert __debug__
    for line in (HERE/"SHA256SUMS").read_text().splitlines():
        h,p=line.split(maxsplit=1)
        assert sha256((HERE/p).read_bytes()).hexdigest()==h,p
    def read(name):
        return json.loads((HERE/name).read_bytes())
    assert mixture(read("parent-a.json"),read("parent-b.json"),F("3/10"))==read("mix-0.json")
    out.mkdir(parents=True,exist_ok=True)
    prefix=[sys.executable,"-I","-B"]
    jobs=[
        ("parents-receipt.json",["parent_containment.py"]),
        ("cert0.json",["certify.py","mix-0.json","plan0.json"]),
        ("band-receipt.json",["certify_mix_band.py","band-plan.json"]),
        ("extended-band-receipt.json",["certify_mix_band.py","extended-band-plan.json"]),
    ]
    flags=[[],["--gap","1.8e-6"],[],["--low","1/10","--high","4/5","--gap","5e-7"]]
    for (name,args),tail in zip(jobs,flags,strict=True):
        check=out/name
        subprocess.run(prefix+args+[str(check)]+tail,cwd=HERE,check=True)
        assert check.read_bytes()==(HERE/name).read_bytes(),name


if __name__=="__main__":
    assert len(sys.argv)==2
    main(Path(sys.argv[1]).resolve())

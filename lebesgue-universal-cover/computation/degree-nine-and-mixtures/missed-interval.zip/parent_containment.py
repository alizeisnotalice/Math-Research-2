"""Verify that each endpoint parent separately fits in the same fixed host."""

from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb, ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from profile_source import Profile

HOST_SHA="a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f"
SOURCE_SHA="2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646"


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return sha256(p.read_bytes()).hexdigest()


def A(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def turn(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def main(out):
    assert __debug__ and sha(HERE/"host.json")==HOST_SHA and sha(HERE/"profile_source.py")==SOURCE_SHA
    ctx.prec=192
    host=read(HERE/"host.json")
    den=host["denominator"]
    p=host["vertices"]
    assert len(p)==1189 and type(den) is int and den>0
    assert all(turn(a,b,c)>0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2],strict=True))
    edges=[]
    for (a,b),(x,y) in zip(p,p[1:]+p[:1],strict=True):
        q,r=y-b,a-x
        bound=q*a+r*b
        assert max(q*z+r*w for z,w in p)==bound
        L=arb(q*q+r*r).sqrt()
        edges.append((arb(q)/L,arb(r)/L,A(F(bound,den))/L))
    poses=read(HERE/"parent-poses.json")
    receipts=[]
    for name,spec in poses.items():
        W=Profile(read(HERE/name))
        other_name=next(n for n in poses if name!=n)
        O=Profile(read(HERE/other_name))
        hand=spec["hand"]
        assert hand in (1,-1)
        q=F(spec["q"])
        c,s=(1-q*q)/(1+q*q),2*q/(1+q*q)
        assert c*c+s*s==1
        if spec["halfturn"]:
            c,s=-c,-s
        c,s=A(c),A(s)
        tx,ty=A(spec["tx"]),A(spec["ty"])
        gaps=[]
        lines=[]
        for j,(x,y,h) in enumerate(edges):
            u=c*x+s*y,hand*(-s*x+c*y)
            support=W.support(u)
            e=h-tx*x-ty*y-support
            slope=O.support(u)-support
            balance=e
            lines.append((e,slope))
            if not balance>0:
                print("failed",name,j,balance,flush=True)
            gaps.append((balance.lower(),j))
        v,j=min(gaps)
        assert v>0,(name,str(v),j)
        limit=min((e.lower()/slope.upper()).lower() for e,slope in lines if slope.upper()>0)
        assert 0<limit<1
        q,ex=map(int,(limit.upper()).man_exp())
        safe=F(q)*F(2)**ex
        scale=10**9
        safe=F((safe*scale).numerator//(safe*scale).denominator-1,scale)
        assert 0<safe and all(e-A(safe)*slope>0 for e,slope in lines)
        receipts.append(dict(name=name,allowed_fraction_of_other_parent=str(safe),source_sha256=sha(HERE/name),minimum_gap=str(v),minimum_edge=j,
                             verified_faces=len(edges),exact_pose=spec))
        print(name,j,v,"fraction of other parent",safe,flush=True)
    out.write_text(json.dumps(dict(complete=True,host_sha256=HOST_SHA,profile_source_sha256=SOURCE_SHA,
                                   precision=ctx.prec,flint=flint_version,parents=receipts),indent=2)+"\n")


if __name__=="__main__":
    assert len(sys.argv)==2
    main(Path(sys.argv[1]))

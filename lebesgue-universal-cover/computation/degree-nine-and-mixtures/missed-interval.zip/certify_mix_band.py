"""Verify joint width and free noncontainment for a closed interval of Minkowski mixes."""

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import ctx

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from certify import A, data, find_plan, kernel, read, verify
from profile_source import Profile


def sha(z):
    return sha256(z.read_bytes()).hexdigest()


def mixture(a,b,w):
    assert a["grid"]==b["grid"] and [p[0] for p in a["pieces"]]==[p[0] for p in b["pieces"]]
    pieces=[]
    for (k,x),(_,y) in zip(a["pieces"],b["pieces"],strict=True):
        if x is None:
            assert y is None
            pieces.append([k,None])
        else:
            assert y is not None
            pieces.append([k,str(w*F(x)+(1-w)*F(y))])
    return dict(grid=a["grid"],pieces=pieces)


def run(plan_file, output, lo, hi, threshold, search):
    ctx.prec=192
    a,b=map(read,(HERE/"parent-a.json",HERE/"parent-b.json"))
    _,rows,caps=data(HERE/"parent-a.json")
    Profile(b)
    def kernels(lo,hi):
        p=Profile(mixture(a,b,lo))
        q=Profile(mixture(a,b,hi))
        bound0,bound1=kernel(p,caps),kernel(q,caps)
        def both(*args): return min(bound0(*args),bound1(*args))
        return both

    if search:
        parts=[]
        def explore(lo,hi,depth):
            bound=kernels(lo,hi)
            try:
                candidate=find_plan(Profile(mixture(a,b,(lo+hi)/2)),rows,caps,bound,threshold)
            except AssertionError:
                assert depth<10,(str(lo),str(hi))
                m=(lo+hi)/2
                explore(lo,m,depth+1)
                explore(m,hi,depth+1)
                return
            parts.append([str(lo),str(hi),candidate])
        explore(lo,hi,0)
        plan_file.write_text(json.dumps(parts,separators=(",",":"))+"\n")
    else:
        parts=read(plan_file)
    summary=[]
    right=lo
    for x,y,cover in parts:
        x,y=map(F,(x,y))
        assert right==x and x<y
        right=y
        h=verify(caps,kernels(x,y),cover,threshold)
        summary.append(dict(segment=[str(x),str(y)],hands=h))
    assert right==hi
    result=dict(complete=True,scope="all convex-width mixtures on the specified closed coefficient interval, both hands and all angles",
                parameter_interval=[str(lo),str(hi)],euclidean_gap_lower=str(threshold),
                summary=summary,plan_sha256=sha(plan_file),parent_a_sha256=sha(HERE/"parent-a.json"),
                parent_b_sha256=sha(HERE/"parent-b.json"),host_sha256=sha(HERE/"host.json"),
                rows_sha256=sha(HERE/"balanced-rows.json"),precision=ctx.prec)
    output.write_text(json.dumps(result,indent=2)+"\n")
    print([(r["segment"],r["hands"]["1"]["checked_closed_cells"],r["hands"]["-1"]["checked_closed_cells"])
           for r in summary],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for n in ("plan","output"): p.add_argument(n,type=Path)
    p.add_argument("--low",type=F,default=F("1/5"))
    p.add_argument("--high",type=F,default=F("13/20"))
    p.add_argument("--gap",type=F,default=F("1e-6"))
    p.add_argument("--search",action="store_true")
    a=p.parse_args()
    assert __debug__ and 0<=a.low<a.high<=1 and a.gap>0
    run(a.plan,a.output,a.low,a.high,a.gap,a.search)

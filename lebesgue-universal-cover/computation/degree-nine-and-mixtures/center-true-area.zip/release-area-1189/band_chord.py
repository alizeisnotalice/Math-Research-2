"""Turn free distance certificates on the band into true convex-hull area bounds."""
import argparse
from fractions import Fraction as F
from functools import cache
import json
from pathlib import Path
import sys
from flint import arb, ctx

sys.path.insert(0,str(Path(__file__).resolve().parent))
from true_fan import Check, HERE, a, dot, J, read, sha
from certify import data, kernel
from certify_mix_band import mixture
from profile_source import Profile


CHORD_DEPTHS=tuple(map(F,("0.0000001","0.00000025","0.0000005","0.000001","0.000002",
                        "0.000005","0.00001","0.00002","0.00005","0.0001","0.0002","0.0005","0.001","0.002")))


def run(threshold):
    check=Check(threshold)
    _,rows,caps=data(HERE/'parent-a.json')
    plan,=read(HERE/'extended-band-plan.json')
    w_lo,w_hi=map(F,plan[:2])
    assert (w_lo,w_hi)==(F(1,10),F(4,5))
    pa,pb=[read(HERE/f'parent-{x}.json') for x in ('a','b')]
    kernels=[kernel(Profile(mixture(pa,pb,w)),caps) for w in (w_lo,w_hi)]

    @cache
    def permitted(n):
        length=arb(dot(n,n)).sqrt()
        tangent=J(n)
        h0=[dot(n,p) for p in check.P]
        h1=h0[1:]+h0[:1]
        t0=[dot(tangent,p) for p in check.P]
        t1=t0[1:]+t0[:1]
        hmax=max(h0)
        best=[]
        for depth in CHORD_DEPTHS:
            scaled=depth*check.D*max(map(abs,n))
            num=hmax*scaled.denominator-scaled.numerator
            den=scaled.denominator
            ends=[]
            for h,k,p,q in zip(h0,h1,t0,t1,strict=True):
                above=h*den-num
                below=k*den-num
                if above==0:
                    ends.append(F(p))
                elif above*below<0:
                    ends.append(F(p*(above-below)+(q-p)*above,above-below))
            assert len(ends)>=2
            L=a((max(ends)-min(ends))/check.D)/length
            depth=a(scaled/check.D)/length
            assert L>0 and depth>0
            v=a(threshold)/L
            best.append((v+(v*v+2*v*depth).sqrt()).upper())
        return min(best)

    @cache
    def allowance(r):
        row=rows[r]
        dirs=[tuple(n) for n in row['normals']]
        coeff=map(F,row['weights'])
        tot=sum((a(q)*arb(dot(n,n)).sqrt()*permitted(n) for q,n in zip(coeff,dirs,strict=True) if q),arb(0))
        return (tot/caps[r][2]).upper()

    stats={}
    for hand in (1,-1):
        old=F(0)
        vals=[]
        for l,h,r,p in plan[2][str(hand)]:
            lo,hi=F(l),F(h)
            assert lo==old and lo<hi<lo+180
            old=hi
            f=min(k(lo,hi,hand,r,p) for k in kernels)
            assert f>allowance(r),(hand,str(lo),str(hi),r,f,allowance(r))
            vals.append((f-allowance(r)).lower())
        assert old==360
        stats[str(hand)]={'closed_cells':len(vals),'least_slack':str(min(vals))}
    return dict(complete=True,weight_interval=[str(w_lo),str(w_hi)],strict_threshold=str(threshold),hands=stats,
                chord_directions=permitted.cache_info().currsize,precision=ctx.prec,
                host_sha256=sha(HERE/'host.json'),source_sha256=sha(Path(__file__)),
                rows_sha256=sha(HERE/'balanced-rows.json'),plan_sha256=sha(HERE/'extended-band-plan.json'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('threshold',type=F)
    p.add_argument('receipt',type=Path)
    args=p.parse_args()
    assert __debug__ and args.threshold>0
    ctx.prec=192
    result=run(args.threshold)
    args.receipt.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()

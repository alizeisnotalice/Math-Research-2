"""Replay every exact certificate in the fixed-host area bundle."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys
from flint import ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from true_fan import Check, read, sha
from band_chord import run as verify_band
from upper_fan import verify as verify_upper


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    assert __debug__
    ctx.prec=192
    plan_file=HERE/'fan-plan.json'
    plan=read(plan_file)
    levels=read(HERE/'levels.json')
    assert F(plan['threshold'])==F(levels['single_lower'])
    proof=Check(plan['threshold'],plan['fan_samples'])
    lower=proof.verify(plan)
    print('single lower',levels['single_lower'],lower,flush=True)
    upper=verify_upper(levels['upper_samples'])
    assert F(upper['certified_threshold'])==F(levels['single_upper'])
    print('single upper',upper['certified_threshold'],flush=True)
    band=verify_band(F(levels['band_lower']))
    print('closed band lower',levels['band_lower'],band['hands'],flush=True)
    names=('verify_release.py','true_fan.py','upper_fan.py','band_chord.py','certify.py',
        'certify_mix_band.py','profile_source.py','host.json','parent-a.json','parent-b.json',
        'mix-0.json','center-poses.json','fan-plan.json','area-lower-plan.json',
        'extended-band-plan.json','balanced-rows.json','levels.json')
    receipt=dict(complete=True,levels=levels,lower=lower,upper=upper,band=band,
        source_sha256={name:sha(HERE/name) for name in names},python=platform.python_version(),flint=flint_version)
    args.output.write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
    main()

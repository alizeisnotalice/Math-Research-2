"""Verify a sharp area upper bound for the actual joint convex hull at one pose."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sys
from flint import arb, ctx, __version__ as flint_version

sys.path.insert(0,str(Path(__file__).resolve().parent))
from true_fan import Check, HERE, a, det, read, rot, sha, sub


def exact_hull(points):
    points=sorted(set(points))

    def half(points):
        out=[]
        for x in points:
            while len(out)>1 and det(sub(out[-1],out[-2]),sub(x,out[-1]))<=0:
                out.pop()
            out.append(x)
        return out[:-1]

    return half(points)+half(reversed(points))


def twice_area(points):
    return sum(det(u,v) for u,v in zip(points,points[1:]+points[:1],strict=True))


def verify(samples):
    assert type(samples) is int and samples>=4
    check=Check('.000000183')
    pose,=read(HERE/'center-poses.json')
    assert F(pose['weight'])==F(3,10) and pose['hand'] in (-1,1)
    q=F(pose['q'])
    b=(-1)**int(pose['halfturn'])
    c,s=a(b*(1-q*q)/(1+q*q)),a(2*b*q/(1+q*q))
    t=(a(pose['tx']),a(pose['ty']))
    scale=10**15
    grid=scale//check.D
    assert grid*check.D==scale
    material=[(grid*x,grid*y) for x,y in check.P]
    rounding=a(F(5,8*scale))
    for j in range(samples):
        y,d=check.W.at(2*j,samples)
        sn,cs=(2*arb.pi()*j/samples).sin_cos()
        p=((a('.5')+y)*cs-d*sn,pose['hand']*((a('.5')+y)*sn+d*cs))
        u=rot(p,c,s)
        x=(u[0]+t[0],u[1]+t[1])
        v=tuple(round(float(w.mid())*scale) for w in x)
        # Floating conversion merely suggests a grid point. The residual bounds certify it.
        assert all(abs(w-a(F(n,scale)))<rounding for w,n in zip(x,v,strict=True))
        material.append(v)
    hull=exact_hull(material)
    assert len(hull)>=3
    base=F(twice_area(check.P),2*check.D**2)
    poly=F(twice_area(hull),2*scale**2)
    chord_error=2*(arb.pi()/(2*samples)).sin()**2
    delta=chord_error+rounding*arb(2).sqrt()
    length=sum((arb((u[0]-v[0])**2+(u[1]-v[1])**2).sqrt() for u,v in zip(hull,hull[1:]+hull[:1],strict=True)),arb(0))/scale
    error=length*delta+arb.pi()*delta**2
    upper=a(poly-base)+error
    assert upper<a('0.000000184926'),(a(poly-base),error,upper)
    return dict(complete=True,samples=samples,grid=scale,boundary_vertices=len(hull),host_sha256=sha(HERE/'host.json'),
              profile_sha256=sha(HERE/'mix-0.json'),pose_sha256=sha(HERE/'center-poses.json'),precision=ctx.prec,
              verifier_sha256=sha(Path(__file__)),flint=flint_version,
              exact_sample_polygon_increment=str(poly-base),rounding_and_arc_error=str(error),strict_upper=str(upper.upper()),
              certified_threshold='0.000000184926')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('receipt',type=Path)
    p.add_argument('--samples',type=int,default=1048576)
    args=p.parse_args()
    assert __debug__
    ctx.prec=192
    print(json.dumps(result:=verify(args.samples),indent=2),flush=True)
    args.receipt.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    main()

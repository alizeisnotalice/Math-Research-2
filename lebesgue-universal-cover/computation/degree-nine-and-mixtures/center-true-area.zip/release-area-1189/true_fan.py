"""Certify true joint-hull area via disjoint radial fan replacements."""

import argparse
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys
from flint import arb, ctx

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from profile_source import Profile

HOST_SHA="a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f"
N=16384


def a(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def det(x,y):
    return x[0]*y[1]-x[1]*y[0]


def dot(x,y):
    return x[0]*y[0]+x[1]*y[1]


def sub(x,y):
    return x[0]-y[0],x[1]-y[1]


def J(x):
    return -x[1],x[0]


def rot(x,c,s):
    return c*x[0]-s*x[1],s*x[0]+c*x[1]


def dyadic_exact(x):
    m,e=map(int,x.man_exp())
    return F(m)*F(2)**e


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


class Check:
    def __init__(self, threshold, fan_samples=N):
        assert sha(HERE/"host.json")==HOST_SHA
        self.th=F(threshold)
        assert type(fan_samples) is int and fan_samples>=4
        self.fan_samples=fan_samples
        host=read(HERE/"host.json")
        self.P=[tuple(x) for x in host["vertices"]]
        self.m=len(self.P)
        self.D=host["denominator"]
        assert self.m==1189 and self.D==10**12
        self.V=[tuple(a(F(v,self.D)) for v in x) for x in self.P]
        assert all(det(x,y)>0 for x,y in zip(self.P,self.P[1:]+self.P[:1],strict=True))
        self.norm=[(v[1]-u[1],u[0]-v[0]) for u,v in zip(self.P,self.P[1:]+self.P[:1],strict=True)]
        assert all(dot(n,v)<=dot(n,self.P[i]) for i,n in enumerate(self.norm) for v in self.P)
        source=read(HERE/"mix-0.json")
        pa,pb=[read(HERE/f"parent-{which}.json") for which in ("a","b")]
        assert pa["grid"]==pb["grid"]==source["grid"]
        for (k,x),(l,y),(m,z) in zip(pa["pieces"],pb["pieces"],source["pieces"],strict=True):
            assert k==l==m
            if x is None:
                assert y is None and z is None
            else:
                assert F(z)==F(3,10)*F(x)+F(7,10)*F(y)
        Profile(pa)
        Profile(pb)
        self.W=Profile(source)
        self.base_plan=read(HERE/"area-lower-plan.json")

    @cache
    def point(self,j,samples):
        assert type(j) is int and 0<=j<samples
        y,d=self.W.at(2*j,samples)
        s,c=self.trig(F(j,samples))
        return ((a(".5")+y)*c-d*s,(a(".5")+y)*s+d*c)

    @cache
    def trig(self,t):
        return (2*arb.pi()*a(t)).sin_cos()

    def material(self,j,hand,samples=None):
        x,y=self.point(j,self.fan_samples if samples is None else samples)
        return (x,hand*y)

    @cache
    def old_wedge(self,i,j):
        L=[z%self.m for z in range(i,(j if j>i else j+self.m)+1)]
        assert len(L)>=2 and det(self.P[i],self.P[j])>0
        assert all(det(self.P[i],self.P[k])>0 and det(self.P[k],self.P[j])>0 for k in L[1:-1])
        area=F(sum(det(self.P[u],self.P[v]) for u,v in zip(L,L[1:])),self.D**2)
        return tuple(L[:-1]),a(area)

    def original_test(self,hand,row):
        lo,hi=map(F,row[:2])
        ones,free=row[2:]
        items=[(i,j,F(1)) for i,j in ones]+[(i,j,F(q)) for i,j,q in free]
        assert len({i for i,_,_ in items})==len(items)
        assert all(0<=i<self.m and 0<=r<=1 for i,_,r in items)
        assert all(sum(r*self.norm[i][k] for i,_,r in items)==0 for k in (0,1))
        x,y=arb(0),arb(0)
        k=F(0)
        for i,j,r in items:
            p=self.material(j,hand,N)
            normal=self.norm[i]
            x+=a(r)*dot(normal,p)
            y+=a(r)*dot(normal,J(p))
            k+=r*dot(normal,self.P[i])
        returns=[]
        for t in (lo,hi):
            s,c=self.trig(t)
            p=(x*c+y*s)/(2*self.D)
            if not p>0:
                return -a(1)
            returns.append((p-a(k/(2*self.D**2))).lower())
        return min(returns)

    def translation_domain(self,hand,lo,hi,pins):
        assert len(pins)==6 and len({i for i,_ in pins})==6
        normals=[self.norm[i] for i,_ in pins]
        assert all(det(x,y)>0 for x,y in zip(normals,normals[1:]+normals[:1],strict=True))
        assert all(det(normals[i],normals[(i+2)%6])>0 for i in (0,2,4))
        sides=[]
        for idx,j in pins:
            w=self.material(j,hand)
            n=self.norm[idx]
            b=min(dot(n,rot(w,c,s)).lower() for s,c in [self.trig(lo),self.trig(hi)])
            assert b>0
            h=a(F(dot(n,self.P[idx]),self.D))+a(2*self.D*self.th)-b
            sides.append((n,dyadic_exact(h.upper())))
        out=[]
        for (n,b),(m,c) in combinations(sides,2):
            d=det(n,m)
            if d==0:
                continue
            z=((m[1]*b-n[1]*c)/d,(n[0]*c-m[0]*b)/d)
            if all(dot(v,z)<=q for v,q in sides):
                out.append(z)
        assert len(out)>=3
        return sorted(set(out))

    def row(self,hand,lo,hi,domain,patches):
        deltax, deltay=[a(min(t[k] for t in domain)).union(a(max(t[k] for t in domain))) for k in (0,1)]
        tz=(deltax,deltay)
        s,c=(2*arb.pi()*a(lo).union(a(hi))).sin_cos()
        occupied=set()
        co=si=const=arb(0)
        delta=(arb(0),arb(0))
        old=(arb(0),arb(0))
        for i,j,path in patches:
            assert 0<=i<self.m and 0<=j<self.m and i!=j and path
            region,area=self.old_wedge(i,j)
            assert not occupied.intersection(region)
            occupied.update(region)
            left,right=self.V[i],self.V[j]
            z=[self.material(k,hand) for k in path]
            for p in z:
                x,y=rot(p,c,s)
                w=x+deltax,y+deltay
                assert det(left,w)>0 and det(w,right)>0,(i,j,str(lo),str(hi))
            for p,q in zip(z,z[1:]):
                assert det(p,q)+det(tz,rot(sub(q,p),c,s))>0,(i,j,str(lo),str(hi))
            const+=sum((det(p,q) for p,q in zip(z,z[1:])),arb(0))-area
            co+=det(left,z[0])+det(z[-1],right)
            si+=det(left,J(z[0]))+det(J(z[-1]),right)
            delta=tuple(r+d for r,d in zip(delta,sub(z[-1],z[0]),strict=True))
            old=tuple(r+d for r,d in zip(old,sub(right,left),strict=True))
        return (const,co,si,delta,old)

    def fan_test(self,hand,lo,hi,pins,groups):
        domain=self.translation_domain(hand,lo,hi,pins)
        assert sum(F(q) for q,_ in groups)==1 and all(F(q)>0 for q,_ in groups)
        const=co=si=arb(0)
        delta=old=(arb(0),arb(0))
        for q,patches in groups:
            r=a(q)
            k,x,y,d,e=self.row(hand,lo,hi,domain,patches)
            const+=r*k
            co+=r*x
            si+=r*y
            delta=tuple(t+r*v for t,v in zip(delta,d,strict=True))
            old=tuple(t+r*v for t,v in zip(old,e,strict=True))
        ranges=[]
        width=2*arb.pi()*a(hi-lo)
        for t0 in domain:
            t=tuple(map(a,t0))
            C=co+det(t,delta)
            S=si+det(t,J(delta))
            K=const+det(t,old)
            endpoints=[(K+C*c+S*s).lower() for s,c in [self.trig(lo),self.trig(hi)]]
            inner=(min(endpoints)-(abs(C)+abs(S))*width**2/8)/2
            ranges.append(inner.lower())
        return min(ranges)

    def verify(self,plan):
        stats={}
        assert F(plan["threshold"])==self.th
        for hand in (1,-1):
            floor=None
            covered=F(0)
            old=fan=0
            for kind,content in plan["hands"][str(hand)]:
                if kind=="original":
                    raw=self.base_plan[str(hand)][content]
                    lo,hi=map(F,raw[:2])
                    q=self.original_test(hand,raw)
                    old+=1
                else:
                    assert kind=="fan"
                    lo,hi=map(F,content[:2])
                    q=self.fan_test(hand,lo,hi,*content[2:])
                    fan+=1
                assert covered==lo and 0<hi-lo<F(1,2)
                assert q>a(self.th),(hand,kind,str(lo),str(hi),str(q))
                covered=hi
                floor=q if floor is None else min(floor,q)
            assert covered==1
            stats[str(hand)]=dict(original_cells=old,fan_cells=fan,strict_weakest=str(floor))
        return stats


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("plan",type=Path)
    p.add_argument("receipt",type=Path)
    args=p.parse_args()
    assert __debug__
    ctx.prec=192
    plan=read(args.plan)
    c=Check(plan["threshold"],plan.get("fan_samples",N))
    stats=c.verify(plan)
    result=dict(complete=True,host_sha256=HOST_SHA,profile_sha256=sha(HERE/"mix-0.json"),
        base_plan_sha256=sha(HERE/"area-lower-plan.json"),true_fan_plan_sha256=sha(args.plan),
        verifier_sha256=sha(Path(__file__)),threshold=plan["threshold"],fan_samples=c.fan_samples,hands=stats)
    args.receipt.write_text(json.dumps(result,indent=2)+"\n")
    print(stats,flush=True)


if __name__=="__main__":
    main()

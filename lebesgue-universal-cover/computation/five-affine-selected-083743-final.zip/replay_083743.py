"""Recompute the selected original five-body proof trees at threshold .83743 or higher."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify_five_selected_083740_traces import audit


def main():
    if not __debug__:
        raise SystemExit('Assertions must be enabled.')
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('checkout','cert','work','cache'):
        parser.add_argument(name,type=Path)
    parser.add_argument('--workers',type=int,default=1)
    args = parser.parse_args()
    assert 1 <= args.workers <= 12
    for line in (HERE/'SHA256SUMS').read_text().splitlines():
        h, name = line.split('  ',1)
        assert sha256((HERE/name).read_bytes()).hexdigest() == h
    exp = HERE/'expected'
    raw = (exp/'selection.json').read_bytes()
    rows = json.loads(raw)
    assert rows['threshold']=='0.83743' and rows['leaves']
    pairs = {(p,i) for p,i,_ in rows['leaves']}
    assert len(pairs)==len(rows['leaves'])
    scope = json.loads((exp/'outer-retained.json').read_bytes())
    assert sha256((exp/'outer-retained.json').read_bytes()).hexdigest()==rows['outer_retained_sha256']
    assert all(i in scope[str(p)] for p,i in pairs)

    def one(triple):
        part,pos,budget = triple
        stem=f'part{part}-pos{pos}'
        row=json.loads((exp/(stem+'.json')).read_bytes())
        target=row['threshold']
        assert F(target) >= F(rows['threshold'])
        assert [row['part'],row['pos'],row['budget']]==triple
        work=args.work/stem
        subprocess.run([sys.executable,'-I','-B',HERE/'replay_five_affine_selected.py',
                        args.checkout,args.cert,work,args.cache,'--target',target,'--part',str(part),
                        '--positions',str(pos),'--budget',str(budget)],check=True,stdout=subprocess.DEVNULL)
        assert (work/(stem+'.json')).read_bytes()==(exp/(stem+'.json')).read_bytes()
        trace=(work/(stem+'.bin')).read_bytes()
        assert row['result']['remaining']==[] and sha256(trace).hexdigest()==row['trace_sha256']
        assert trace==(exp/(stem+'.bin')).read_bytes()
        checked=audit(row['root'],trace)
        assert all(checked[k]==row['result'][k] for k in checked)
        return checked['vis'],sum(checked['closed'].values())
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results=list(pool.map(one,rows['leaves']))
    visits,terminals=map(sum,zip(*results))
    assert [visits,terminals]==[rows['visits'],rows['terminals']]
    result=dict(complete=True,threshold=rows['threshold'],remaining=0,leaves=sorted(pairs),visits=visits,
                terminals=terminals,selection_sha256=sha256(raw).hexdigest())
    (args.work/'replay-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':
    main()

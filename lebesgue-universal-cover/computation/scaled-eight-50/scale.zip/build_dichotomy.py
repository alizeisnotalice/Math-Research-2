"""Specialize the published eight-input disk/chord kernel to the baseline-or-goal disjunction."""
from pathlib import Path
import zipfile, json, gzip, sys
from hashlib import sha256
source, work=map(Path,sys.argv[1:])
work.mkdir(exist_ok=True)
with zipfile.ZipFile(source) as z:
    for name in ("nine.cpp","disk_chord_support.hpp","run_nine.py","support_grid.py","dual_bank.py","angular_rows.py"):
        raw=z.read(name)
        if name=='nine.cpp':
            src=raw.decode()
            mark='if(ret==1){++old;return true;}'
            assert src.count(mark)==1
            src=src.replace(mark,'if(ret==1 || t.last>=120666927296517964LL){++old;return true;}')
            assert src.count('for(int f=0;f<4;++f)')==1
            raw=src.replace('for(int f=0;f<4;++f)','for(int f=0;f<3;++f)').encode()
        if name=='run_nine.py':
            src=raw.decode()
            mark="M=F('.83729500622102524');floor=(M*2*Z*Z).__floor__()"
            assert src.count(mark)==1
            src=src.replace(mark,"M=F('.83729500622102524');floor=(M*F('.999999995')**2*2*Z*Z).__floor__()")
            start=src.index('    endpoints={}');end=src.index('    dll=',start)
            assert 'if a.mesh:' in src and 'endpoints[key]' in src[start:end]
            src=src[:start]+'    assert a.mesh and not a.precontract\n    endpoints={k:ints([0]) for k in roots}\n'+src[end:]
            raw=src.encode()
        (work/name).write_bytes(raw)
    (work/'bank.json').write_bytes(gzip.decompress(z.read('nine-bank.json.gz')))

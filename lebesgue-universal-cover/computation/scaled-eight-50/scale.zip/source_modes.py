"""Audit reported .83750 method counters and bind the exact R265 eight-input selection."""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from fractions import Fraction as F
from collections import Counter
from hashlib import sha256
import gzip,json,sys
c=Path(sys.argv[1]);dest=Path(sys.argv[2])
archives=[
    'global-083750/stage4-upgrade.zip','global-083750/terminal-dispatch-083750.zip',
    'whole-leaves-083750-second/wave2.zip','whole-leaves-083750-second/additional-eleven.zip',
    'lower-083750-refinement/wave3.zip','rosters-083750/wave4.zip','rosters-083750/physical-and-mac.zip',
    'physical-nine-47/r5.zip','physical-nine-47/r5-97.zip','physical-nine-47/r6.zip',
    'physical-nine-47/r6b.zip','physical-nine-47/r6c.zip','eight-083750/r6d.zip','eight-083750/r6e.zip']
def sha(b):
    return sha256(b).hexdigest()
def new():
    return dict(high_rows=0,values={})
def scan(data,stat):
    for line in data.splitlines():
        j=json.loads(line)
        if not isinstance(j,dict):continue
        t=j.get('target',j.get('goal'))
        if t is None:continue
        try:
            if F(t)!=F(67,80):continue
        except (ValueError,TypeError):continue
        stat['high_rows']+=1
        for k in ('guards','center_stops','center_calls','generated','anchors','cut_guards','inner_dynamic','q_trigger_divisor'):
            if k not in j:continue
            v=j[k];v=int(v) if isinstance(v,int) else int(bool(v))
            stat['values'].setdefault(k,Counter())[str(v)]+=1
            if k=='q_trigger_divisor':assert v>=4000
            else:assert v==0,k
def walk(z,stat):
    for name in z.namelist():
        if name.endswith('.zip'):
            with ZipFile(BytesIO(z.read(name))) as child:walk(child,stat)
        elif name.endswith('.jsonl'):scan(z.read(name),stat)
        elif name.endswith('.jsonl.gz'):scan(gzip.decompress(z.read(name)),stat)
out={}
for n in archives:
    p=c/n;stat=new()
    with ZipFile(p) as z:walk(z,stat)
    stat['sha256']=sha(p.read_bytes());out[n]=stat
for p in sorted((c/'three-leaf-083750/frozen').glob('*.jsonl')):
    stat=new();raw=p.read_bytes();scan(raw,stat);stat['sha256']=sha(raw);out[str(p.relative_to(c))]=stat
with ZipFile(c/'eight-083750/rational.zip') as z:
    raw=gzip.decompress(z.read('eight/physical-selection.json.gz'))
sel=json.loads(raw);assert len(sel)==5442
ord5={k for k,r in sel.items() if r[1]=='ordinary-Qavg'}
assert len(ord5)==8 and all(not sel[k][2] for k in ord5)
assert all(F(v[0])==F(67,80) for v in sel.values())
summary=dict(high_row_entries=sum(x['high_rows'] for x in out.values()),source_rows=out,selection_sha256=sha(raw),selection_uses=dict(Counter(v[1] for v in sel.values())),ordinary_pure_five=sorted(ord5))
dest.write_text(json.dumps(summary,indent=2)+'\n');print(summary['high_row_entries'])

"""Directed local transfer constants and conditional finite interpolation for the R6e input."""
from fractions import Fraction as F
from pathlib import Path
import json,sys
from math import isqrt
from flint import arb,ctx
ctx.prec=256
def v(x):
    x=F(x);return arb(x.numerator)/x.denominator
def show(x):
    return x.str(65)
G=F(120696470013529293,2**57);s=F('.999999999');eps=1-s;r=F('.5');m=F('.4464');a=F('.468')
z=v(s).sqrt();cap=v(F(1,4000)).sqrt()/(z*(1+z))+v((1+s)*r*r-2*m*r+m*m*eps)/(4*z*v(2*r))
assert cap<v(a-m)
assert F(71379940282225,72057594037927936)<(r-a)**2
assert all(1-1/(2*(arb.pi()/(2*n)).cos())>v(a) for n in [5,7,9])
assert all((arb.pi()-(v(s*r)/v(R)).acos())*v(s*r)**2+v(s*r)*(v(R)**2-v(s*r)**2).sqrt()>v(G) for R in map(F,['.706','.707']))
assert (F('.707')+m*eps)**2<2*(s*r)**2
U=2**22
assert s*(U-1)>U-2
norm_floor=s*(U-1)-U+2
def bound(n):
    x=arb.pi()/n
    return v(G/s**2)*(x.cos()/(x/2).cos())**2
rows={}
for t in map(F,['.83749','.83750','.837500001','.8375000015']):
    lo,hi=1,1
    def ok(i):
        v1=bound(2*i+1);assert v1>v(t) or v1<v(t)
        return v1>v(t)
    while not ok(hi):hi*=2
    while lo<hi:
        mid=(lo+hi)//2
        if ok(mid):hi=mid
        else:lo=mid+1
    n=2*lo+1;assert not ok(lo-1)
    rows[str(t)]=dict(N=n,lower=show(bound(n)))
out=dict(conditional_general=show(v(G/s**2)),first_odd_finite=rows,cap_spent=show(cap),cap_available=str(a-m),disk_chord_extra_normalized_numerator=str(norm_floor),baseline_lower_used=str((F('.83729500622102524')*F('.999999995')**2*2**57).__floor__()),expected_unshrunk_floor=120666927296517964)
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')

"""Recompute all locally new arithmetic; inputs are the published computation tree and certified table."""
import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def member(z,suffix):
    with zipfile.ZipFile(z) as ar:
        names=[n for n in ar.namelist() if n.endswith('/'+suffix) or n==suffix]
        assert len(names)==1,(z,suffix,names)
        return ar.read(names[0])
def run(cmd):
    subprocess.run(list(map(str,cmd)),check=True)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for s in ['comp','tree','table','cache','out']:parser.add_argument(s,type=Path)
    parser.add_argument('--workers',type=int,default=4)
    a=parser.parse_args();c=a.comp.resolve();w=a.out.resolve();w.mkdir(exist_ok=False)
    f=c/'eight-083750/r6e.zip';assert sha(f.read_bytes())=='c1aa76762fd2e765c4a283b3d972ee95e0e66377c6d54d541854476f35373c89'
    theorem=member(f,'theorem-eight-50.json');assert sha(theorem)=='bf51df7b771d866134a3a8b94f9daadbf591eb43158c3aac6c6217fc875e5506'
    t=json.loads(theorem);assert t['canonical_leaves']==6710314 and t['exterior_high_certified']==6704872
    assert F(t['lower_bound'])==F(120696470013529293,2**57)
    assert t['finite_inputs']==['augmented_P128','physical_old_Q11','new_Q11']
    r4=c/'rosters-083750/wave4.zip'
    p128=w/'augmented.json';p15=w/'p15.json';p128.write_bytes(member(r4,'p128/inputs/augmented.json'));p15.write_bytes(member(r4,'p152/points-greedy15.json'))
    py=[sys.executable,'-B']
    run(py+[HERE/'point_material.py',p128,c/'multi-host-points.json',c/'inclusion-minimal-eleven/new-points.json',p15,HERE/'q-move.json',w/'points-receipt.json',w/'points.json'])
    run(py+[HERE/'geometry.py',w/'geometry.json'])
    for n in ('points-receipt.json','points.json','geometry.json'):assert (w/n).read_bytes()==(HERE/n).read_bytes()
    p=w/'kit.zip';p.write_bytes(member(c/'physical-nine-47/r6.zip','nine-replay-kit.zip'));assert sha(p.read_bytes())=='19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467'
    d=w/'native';run(py+[HERE/'build_dichotomy.py',p,d])
    run([shutil.which('clang++'),'-O3','-std=c++17','-fsanitize=signed-integer-overflow','-fsanitize-undefined-trap-on-error','-fPIC','-shared',f'-fmodules-cache-path={a.cache.resolve()}','-I',c/'three-leaf-083750',d/'nine.cpp','-o',d/'kernel.so'])
    coverage={}
    frozen=read(HERE/'dichotomy-final.json')
    for row in frozen['rows']:
        k=tuple(row['leaf']);assert k not in coverage;coverage[k]=row
    old=c/'five-global-localization.json';assert sha(old.read_bytes())=='d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504'
    expected={(int(k),v) for k,vs in read(old)['retained'].items() for v in vs}
    assert len(expected)==501 and set(coverage)==expected
    stats={}
    for cap in sorted(set(v['budget'] for v in coverage.values())):
        rows={k:v for k,v in coverage.items() if v['budget']==cap}
        keys=defaultdict(list)
        for p,i in sorted(rows):keys[p].append(i)
        index=w/f'keys-{cap}.json';index.write_text(json.dumps(keys)+'\n')
        output=w/f'roots-{cap}.jsonl'
        run(py+[d/'run_nine.py',c,a.tree.resolve(),a.table.resolve(),d/'kernel.so',d/'bank.json',output,'--index',index,'--target','.83750','--caps','--mesh','--workers',a.workers,'--cap',cap])
        result=[json.loads(s) for s in output.read_text().splitlines()];assert [tuple(v['leaf']) for v in result]==sorted(rows)
        for r in result:
            key=tuple(r['leaf']);assert r=={n:v for n,v in rows[key].items() if n!='budget'}
            ok,n,f,g,_=r['out'];assert ok and n==2*(f+g)-1 and g==r['P128']+r['oldQ']+r['newQ'] and r['P15']==0
            stats[key]=(n,f,g,r['P128'],r['oldQ'],r['newQ'])
    assert set(stats)==expected
    total=list(map(sum,zip(*stats.values())));assert total==frozen['totals']
    run(py+[HERE/'source_modes.py',c,w/'source-modes.json'])
    assert (w/'source-modes.json').read_bytes()==(HERE/'source-modes.json').read_bytes()
    run(py+[HERE/'rational_finite.py',w/'points.json',w/'finite'])
    assert (w/'finite/finite-receipt.json').read_bytes()==(HERE/'finite-receipt.json').read_bytes()
    print('501 complete original roots; visits / baseline / high / P128 / physical Q / independent Q:',total,flush=True)
if __name__=='__main__':main()

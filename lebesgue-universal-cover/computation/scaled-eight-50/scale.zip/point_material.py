"""Exact diameter and point-displacement check for the R6e finite inputs."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import argparse, json
from math import lcm
parser=argparse.ArgumentParser(description=__doc__)
for name in ['p128','physical_q','new_q','p15','motion','output','points']:
    parser.add_argument(name,type=Path)
a=parser.parse_args()
pins=['13d9a52243efadcb2281aa60e41282349e3c4c64bc9925f9ad20ece8dab2ecb1','9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282','45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05','fd28a8fb8beb00f3b30daa4b62fedc30753fb153a4143867d792cab66cba21c4']
s=F('.999999999');e=1-s;m=F('.4464'); motion=json.loads(a.motion.read_bytes())
V=F(motion['epsilon'])/motion['unit']
def dist(a,b):
    return sum((x-y)**2 for x,y in zip(a,b))
def far(p):
    return max((dist(p[i],p[j]),i,j) for i,j in combinations(range(len(p)),2))
def write(p,x):
    p.write_text(json.dumps(x,indent=2)+'\n')
receipt={};points={}
for name,h in zip(['p128','physical_q','new_q','p15'],pins,strict=True):
    raw=getattr(a,name).read_bytes();assert sha256(raw).hexdigest()==h
    src=json.loads(raw);den=src.get('denominator',src.get('point_denominator'))
    p=[tuple(F(x,den) for x in u) for u in src['points']]
    q=p if name!='physical_q' else [tuple(x+V*w for x,w in zip(u,v)) for u,v in zip(p,motion['v'],strict=True)]
    old,i,j=far(p);new,k,l=far(q);move=max(dist(x,y) for x,y in zip(q,p,strict=True))
    assert old<1 and new<s*s and move<(m*e)**2
    d=lcm(*(x.denominator for u in q for x in u));points[name]=dict(denominator=d,points=[[int(d*x) for x in u] for u in q])
    receipt[name]=dict(n=len(q),source_sha256=h,old_diameter_sq=str(old),old_indices=[i,j],new_diameter_sq=str(new),new_indices=[k,l],movement_sq=str(move))
G=F(120696470013529293,2**57)
write(a.points,points)
write(a.output,dict(s=str(s),permitted_m=str(m),families=receipt,new_points_sha256=sha256(a.points.read_bytes()).hexdigest(),G=str(G),conditional_normalized_area=str(G/s**2)))

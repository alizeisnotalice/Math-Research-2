"""Strict inclusion of 117 historical pentagons and the two next failures in every new host."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from inner_grid import *
def read(p):
    return json.loads(p.read_bytes())
def sha(p):
    return sha256(p.read_bytes()).hexdigest()
sel=read(D/'legacy-choices.json');V,lab=grid();ids=sel['hull_indices']
assert len(ids)==len(set(ids)) and len(ids)>1600
vs=[V[i] for i in ids];lab=[lab[i] for i in ids]
assert lab==sel['labels']
# A complete turn about the origin with strictly left-turning vertices.
crossings=0
for i,p in enumerate(vs):
    q,r=vs[(i+1)%len(vs)],vs[(i+2)%len(vs)]
    assert cross(p,q)>0
    assert cross(sub(q,p),sub(r,q))>0,(i,lab[i],lab[(i+1)%len(vs)],lab[(i+2)%len(vs)])
    if p[1]<0 and q[1]>0 and p[0]>0 and q[0]>0:crossings+=1
assert crossings==1
H={('b1','q'):1,('p','f1'):2,('f1','h'):3,('e3','d1'):4,('d1','g'):5,('c3','b1'):0}
nonhex=[];hexhits=[]
for i,v in enumerate(vs):
    k=(i+1)%len(vs);w=vs[k];a=unit(mul(-1,J(sub(w,v))));h=dot(a,v)
    names=(lab[i],lab[k])
    if names in H:
        hnum=H[names];N0=av(dt['n'][hnum])
        assert all((p-q).contains(0) for p,q in zip(a,N0)) and (h-A(F(1,2))).contains(0)
        hexhits.append(hnum)
    else:
        nonhex.append((a,h,lab[i]+' to '+lab[k]))
assert sorted(hexhits)==list(range(6))
# Closed EH intervals cover every tilt, independent of the release amount or trim distance.
for i in range(64):
    rr=upperbox(F('-.002')+F(i,16000),F('-.002')+F(i+1,16000))
    nu=rad(N,rr)
    nonhex.append((nu,dot(nu,M)-A('.00094'),f'EH angle box {i}'))
old={}
source=(D/'shared.py').read_text().split('vxlist=[]')[0]
assert source.count("'1.54','2','1'")==1
old={'__file__':str(D/'shared.py'),'__name__':'historical_chart'}
exec(compile(source.replace("'1.54','2','1'","'1.5497','2','1'"),'historical_chart','exec'),old)
on=old['ns']
L=read(D/'legacy-150-poses.json')['poses']
specs=[(r['index'],F(r['w']),F(r['e'])) for r in L if 'w' in r]+[(150,F('.7982907'),F('.032688')),(151,F('1.2'),F('.08464386'))]
assert len(specs)==len(sel['poses'])==119
prepose={}
def rotated(ang,sg,U):
    return ns['rotate']((U[0],sg*U[1]),ns['trig'](A(-ang)))
for ang,sg in {tuple(p) for p in sel['poses']}:
    prepose[ang,sg]=[(rotated(ang,sg,u),h,name) for u,h,name in nonhex]
results=[]
for (ident,w,e),(ang,sg) in zip(specs,sel['poses'],strict=True):
    l,t=on['chart'](add(on['z'],mul(A(w),on['D'])));p=on['psi'](l);t-=A(e)
    vertices=[add(on['l0'],mul(l,on['el'])),refl(add(on['l0'],mul(p,on['el']))),refl(on['X'](p,-t)),add(on['mid'],mul(t,on['en'])),on['X'](l,t)]
    ed=[sub(vertices[i],vertices[j]) for i,j in on['orders']]
    assert all(dot(v,v).contains(1) for v in ed) and all(cross(ed[k],ed[(k+1)%10])>0 for k in range(10))
    assert all(dot(sub(vertices[i],vertices[j]),sub(vertices[i],vertices[j]))<1 for i in range(5) for j in range(i) if (i,j) not in on['orders'])
    def relevant(n):
        c=[cross(v,n) for v in ed]
        return [(v,r) for k,(v,r) in enumerate(on['sector']) if not c[k]<0 and not c[(k+1)%10]>0]
    # Source vertices 0,1,3 lie respectively on lines n5,n3,n4. Their antipodal fans pin the others.
    for n0,expected in zip(dt['n'],[(1,1),(3,1),(0,1),(1,0),(3,0),(0,0)],strict=True):
        n0=av(n0);assert relevant(n0)==[expected]
        v,r=expected;assert (dot(n0,vertices[v])+r-A(F(1,2))).contains(0)
    # Each dihedral map permutes the exact six hexagon normals and fixes the origin.
    minimum=A(1);name=None
    for n,h,lab0 in prepose[ang,sg]:
        act=relevant(n);assert act
        margin=(h-max((dot(vertices[v],n)+r).upper() for v,r in act)).lower()
        assert margin>0,(ident,ang,sg,lab0,margin)
        if margin<minimum:minimum=margin;name=lab0
    results.append(dict(index=ident,w=str(w),deformation=str(e),placement=[ang,sg],minimum_nonhex=str(minimum),weakest_constraint=name))
out=dict(source_file='R215 computation/finite-b-core/host-poses.json',source_sha256=sha(D/'legacy-150-poses.json'),added_exact=['P(.7982907,.032688)','P(1.2,.08464386)'],historical_sigma='1.5497',hull_vertices=len(vs),hexagonal_pins=6,EH_closed_angle_boxes=64,all_verified=len(results),undecided=[],rows=results)
(D/'legacy-cert.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(vs),len(results),min(arb(r['minimum_nonhex']).lower() for r in results),flush=True)

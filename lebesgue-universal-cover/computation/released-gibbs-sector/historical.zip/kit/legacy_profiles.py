from pathlib import Path
import sys,ast,json
from fractions import Fraction as F
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D));sys.path.insert(0,str(D/'profile-source'))
raw=(D/'legacy_exact.py').read_text().split('old={}')[0]
exec(compile(raw,str(D/'legacy_exact.py'),'exec'))
from certify_tapered_forced_support import Profile
src=D/'profile-source';m=src/'certify_ah_tapered_mirror_counterexample.py'
tree=ast.parse(m.read_text());tree.body=[n for n in tree.body if (isinstance(n,ast.ClassDef) and n.name in ('Support','Polygon')) or (isinstance(n,ast.FunctionDef) and n.name=='exact')]
env=dict(F=F,arb=arb);exec(compile(tree,str(m),'exec'),env)
mirror_source='ah-tapered-mirror-counterexample-input.json'
mir=env['Support'](read(src/mirror_source),arb.pi());pol=env['Polygon'](mir)
old=read(src/'old-pose-audit.json')
assert old['all_bodies_exactly_touch_all_six_hex_faces'] and old['body_count']==150 and old['poses_sha256']==sha(D/'legacy-150-poses.json')
rows=[r for r in read(D/'legacy-150-poses.json')['poses'] if 'w' not in r]
def preimage(turn,sg,n):return ns['rotate']((n[0],sg*n[1]),ns['trig'](A(-turn)))
pre={}
all12=[(t,s) for t in range(0,360,60) for s in (-1,1)]
# Prioritize necessary tilted EH faces and a sparse perimeter scan, then audit every remaining edge.
nn=len(nonhex)-64;is0=set(range(0,nn,24))
ordered=list(range(nn,len(nonhex)))+sorted(is0)+[k for k in range(nn) if k not in is0]
for turn,sg in all12:
    pre[turn,sg]=[(preimage(turn,sg,nonhex[k][0]),nonhex[k][1],nonhex[k][2]) for k in ordered]
out=[]
for r in rows:
    source=r['source']
    if source==mirror_source:
        obj=[mir,pol][r['body_index']]
        hfun=obj.support_direction
    else:
        obj=Profile(read(src/source)[r['body_index']]);hfun=obj.support
        assert all(obj.at(k,3)[0].contains(0) for k in range(6))
    att=[];ok=None
    oldpose=(r['turn'],r['reflection'])
    for t,s in [oldpose]+[p for p in all12 if p!=oldpose]:
        m=A(1);weak=None
        for n,h,name in pre[t,s]:
            g=(h-hfun(n)).lower()
            if g<m:m=g;weak=name
            if g<=0:break
        if m>0:
            ok=dict(pose=[t,s],margin=str(m),weakest_constraint=weak);break
        att.append(dict(pose=[t,s],insufficient_row=weak,margin=str(m)))
    out.append(dict(index=r['index'],source=source,body_index=r['body_index'],passed=ok,other_attempts=att))
    print(r['index'],ok if ok else 'NO INNER CERTIFICATE',flush=True)
ans=dict(total=len(rows),verified=sum(r['passed'] is not None for r in out),undecided=[r['index'] for r in out if r['passed'] is None],inner_polygon_vertices=len(vs),closed_EH_angle_boxes=64,rows=out)
(D/'profile-cert.json').write_text(json.dumps(ans,indent=2)+'\n')

from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json,shutil,subprocess,sys
D=Path(__file__).resolve().parent
base=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve()
work.mkdir(parents=True,exist_ok=True);assert not any(work.iterdir())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
for n,h in read(D/'manifest.json').items():assert sha(D/n)==h
assert sha(base)=='85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1'
with ZipFile(base) as z:z.extractall(work/'core')
core=work/'core'/'kit'
with ZipFile(core/'obstruction.zip') as z:z.extractall(work/'old')
shutil.copytree(work/'old'/'barrier'/'comp068',work/'comp068')
for n in ('candidate.py','shared.py'):shutil.copyfile(core/n,work/n)
for n in ('inner_grid.py','legacy_exact.py','legacy_profiles.py','mirror_refined.py','legacy-150-poses.json','legacy-choices.json'):shutil.copyfile(D/n,work/n)
src=work/'profile-source';shutil.copytree(D/'profile-source',src)
reg=read(work/'legacy-150-poses.json')['poses'];A=read(src/'nonideal-pentagon-library.json')['parameters'];assert A['sigma']=='1.5497'
ls1=A['points'];ls2=read(src/'nonmonotone-pentagon-inputs.json')
for row in reg:
    if 'w' in row:
        arr={'nonideal-pentagon-library.json':ls1,'nonmonotone-pentagon-inputs.json':ls2}[row['source']]
        assert tuple(map(Fraction,arr[row['body_index']]))==(Fraction(row['w']),Fraction(row['e']))
for exe,out in [('legacy_exact.py','legacy-cert.json'),('legacy_profiles.py','profile-cert.json'),('mirror_refined.py','mirror-cert.json')]:
    subprocess.run([sys.executable,'-I','-B',str(work/exe)],cwd=work,check=True,stdout=subprocess.DEVNULL)
    assert (work/out).read_bytes()==(D/out).read_bytes(),out
p,q,r=[read(work/n) for n in ('legacy-cert.json','profile-cert.json','mirror-cert.json')]
cert=[i['index'] for i in p['rows']]+[i['index'] for i in q['rows'] if i['passed']]+[i['index'] for i in r['rows']]
assert len(cert)==152 and sorted(cert)==list(range(152))
print('152/152 verified across the closed parameter box; no unresolved historical witness.')

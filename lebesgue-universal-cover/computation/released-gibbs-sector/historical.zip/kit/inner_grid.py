from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from candidate import *
def grid():
    G=[];labels=[]
    def put(s,v):
        labels.append(s);G.append(v)
    def knot(s):
        put(s,pt(s))
    def ar(a,b,c,n=128):
        center=pt(c);lo=sub(G[-1],center);hi=sub(pt(b),center)
        assert dot(lo,hi)>0 and cross(lo,hi)>0
        for k in range(1,n):put(f'{a}-{b}-{k}',add(center,unit(add(lo,mul(A(F(k,n)),sub(hi,lo))))))
        knot(b)
    knot('b1');knot('q');ar('q','y','e3');ar('y','t','c');knot('z')
    for k in range(1,1025):put(f'pair-{k}',refl(ns['points'](A(F(k,1024)))[0][2]))
    ar('tp','p','g');knot('f1');knot('h');ar('h','u','c3');knot('t_eh');ar('te','ip','b3');knot('e3');knot('d1');knot('g');ar('g','k','f3');knot('c3')
    put('new',peak(F('.005')))
    return G,labels

if __name__=='__main__':
    V,l=grid();p=[[float(x) for x in v] for v in V];(D/'inner-grid-scout.json').write_text(json.dumps(dict(points=p,labels=l))+'\n')

"""Refine the unique failing inner chord; all choices verified at every normal."""
from pathlib import Path
import sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
code=(D/'legacy_profiles.py').read_text().split('out=[]')[0]
exec(compile(code,'init','exec'))
sq=lab.index('q');assert lab[sq+1]=='q-y-1'
c=pt('e3');a=sub(vs[sq],c);b=sub(vs[sq+1],c)
inserted=[add(c,unit(add(a,mul(A(F(k,16)),sub(b,a))))) for k in range(1,16)]
extended=vs[:sq+1]+inserted+vs[sq+1:]
for i,p in enumerate(extended):
    q,r=extended[(i+1)%len(extended)],extended[(i+2)%len(extended)]
    assert cross(p,q)>0 and cross(sub(q,p),sub(r,q))>0
assert all(p[1]>0 for p in inserted)
baseline=[(n,h,k) for n,h,k in nonhex if k!='q to q-y-1']
assert len(baseline)==len(nonhex)-1
for k in range(16):
    p,q=extended[sq+k:sq+k+2];n=unit(mul(-1,J(sub(q,p))))
    baseline.append((n,dot(n,p),f'q first chord {k}/16'))
rows=[]
for ident,obj in enumerate([mir,pol],117):
    pose=(240,1);m=A(1);weak=None
    for n,h,label in baseline:
        margin=(h-obj.support_direction(preimage(*pose,n))).lower()
        assert margin>0,(ident,label,margin)
        if margin<m:m=margin;weak=label
    rows.append(dict(index=ident,pose=pose,minimum=str(m),weakest=weak))
result=dict(rows=rows,closed_EH_angle_boxes=64,inner_vertices=len(extended),old_undecided=[117,118],undecided=[])
(D/'mirror-cert.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)

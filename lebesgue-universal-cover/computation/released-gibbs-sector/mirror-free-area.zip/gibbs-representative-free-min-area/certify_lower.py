"""Use true face triangles and balanced normals to certify full-pose area lower bounds."""
import argparse
from functools import cache
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from core import *


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


class Check:
    def __init__(self,T):
        self.T=T; self.face=host()['faces'];self.normal=[n for a,b,n in self.face]
        self.H=[dot(n,a) for a,b,n in self.face]
        self.L=[dot(sub(b,a),sub(b,a)).sqrt() for a,b,n in self.face]
        assert all(h>A('.49') and L>0 for h,L in zip(self.H,self.L,strict=True))
        self.triples={}
        for t in combinations(range(len(self.face)),3):
            u,v,w=[self.normal[i] for i in t]
            weights=[cross(v,w),cross(w,u),cross(u,v)]
            if all(q<0 for q in weights):weights=[-q for q in weights]
            if not all(q>0 for q in weights):continue
            denom=2*sum(w/self.L[i] for w,i in zip(weights,t,strict=True))
            self.triples[t]=[w/denom for w in weights]

    @cache
    def sincos(self,a):
        return (A(a)*arb.pi()/180).sin_cos()

    def exact(self,hand,lo,hi,triple,points):
        assert hand in (-1,1)
        assert len(triple)==3 and len(points)==3 and lo<hi<lo+180
        w=self.triples[tuple(triple)]
        constant=sum(y*self.H[i] for y,i in zip(w,triple,strict=True))
        ax=ay=arb(0)
        for r,j,alpha in zip(w,triple,points,strict=True):
            x,z=material(F(alpha));v=x,hand*z
            ax+=r*dot(v,self.normal[j]);ay+=r*dot(J(v),self.normal[j])
        assert constant>0
        endpoints=[]
        for ang in (lo,hi):
            s,c=self.sincos(ang)
            raw=ax*c+ay*s
            assert raw>0
            endpoints.append((raw-constant).lower())
        return min(endpoints)

    def make(self):
        from scout import Scout
        import numpy as np
        scout=Scout();mapping={t:i for i,t in enumerate(scout.triples)}
        out={}
        for hand in (1,-1):
            cells=[]
            def visit(l,r,d):
                middle=(l+r)/2;a=float(middle)*np.pi/180
                vals=scout.value(hand*(scout.T-a))
                scores=(vals-scout.B)@scout.R.T
                for i in np.argsort(-scores)[:8]:
                    key=scout.triples[int(i)]
                    if key not in self.triples:continue
                    p=[str(F(format((hand*(scout.T[k]-a))*180/np.pi,'.13f'))) for k in key]
                    v=self.exact(hand,l,r,key,p)
                    if v>A(self.T):
                        cells.append([str(l),str(r),list(key),p]);return
                assert d<24,(hand,str(l),str(r),float(scores.max()))
                m=(l+r)/2;visit(l,m,d+1);visit(m,r,d+1)
            for j in range(72):visit(F(5*j),F(5*(j+1)),0)
            out[str(hand)]=cells
        return out

    def verify(self,plan):
        out={}
        for k in (1,-1):
            a=F(0); values=[]
            for l,r,t,p in plan[str(k)]:
                l,r=F(l),F(r)
                assert l==a
                a=r
                v=self.exact(k,l,r,t,p)
                assert v>A(self.T),(k,l,r,t,v)
                values.append(v)
            assert a==360 and values
            out[str(k)]=dict(closed_cells=len(values),least_directed=str(min(values)))
        return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan',type=Path);p.add_argument('receipt',type=Path)
    p.add_argument('--threshold',type=F,default=F('8.8e-6'));p.add_argument('--make-plan',action='store_true')
    a=p.parse_args();assert __debug__;ctx.prec=160
    ex=Check(a.threshold)
    if a.make_plan:
        plan=ex.make();a.plan.write_text(json.dumps(plan,separators=(',',':'))+'\n')
    else:
        plan=json.loads(a.plan.read_bytes())
    hands=ex.verify(plan)
    report=dict(complete=True,scope='all rigid poses, original true curved host fixed, true joint convex hull',
                threshold=str(a.threshold),parameters=list(map(str,(LAM,ALPHA,ETA))),
                hands=hands,curvature_source_sha256=sha(HERE/'certify.py'),
                host_geometry_sha256=sha(HERE/'candidate.py'),core_sha256=sha(HERE/'core.py'),
                plan_sha256=sha(a.plan),verifier_sha256=sha(Path(__file__)),precision=ctx.prec,triangles=len(ex.triples))
    a.receipt.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':main()

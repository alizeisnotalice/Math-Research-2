"""Close the low-area free-pose valley with disjoint true EH and hexagon fans."""
import argparse
from pathlib import Path
from hashlib import sha256
import json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from core import *
from certify_lower import Check as Triangle

T=F('9.76346e-6')
MID=F(120)
WIDTH=F('.002')
WID=tuple(range(1399,1411))+(1810,)
FACENORMAL={10:0,0:60,3:120,4:180,7:240,8:300}
PATTERNS=((0,4,8),(10,3,7))


def sha(p):return sha256(p.read_bytes()).hexdigest()


def bsum(x):
    return sum(p[0] for p in x),sum(p[1] for p in x)


def solve(p,q,b):
    delta=cross(p,q)
    assert abs(delta)>A('.001')
    return cross(b,q)/delta,cross(p,b)/delta


def rot(x,s,c):
    return x[0]*c-x[1]*s,x[0]*s+x[1]*c


def ninety(x):return x[1],-x[0]


class Verify:
    def __init__(self):
        self.tri=Triangle(T)
        self.f=self.tri.face
        self.B=self.tri.H
        self.length=self.tri.L
        self.n=self.tri.normal
        self.measure=[mul(L,n) for L,n in zip(self.length,self.n,strict=True)]
        self.breakpoints=(MID-WIDTH,MID+WIDTH)
        self.mixed=[]
        for f,i,j in PATTERNS:
            p,q=solve(self.measure[i],self.measure[j],mul(-1,add(self.measure[f],self.measure[5])))
            assert 0<p<1 and 0<q<1
            self.mixed.append(([f,i,j,5],[A(1),p,q,A(1)]))

    def normalized(self,x):return rot(x,A(3).sqrt()/2,A(F(-1,2)))

    def mixed_bound(self,l,r,i,p):
        ids,weights=self.mixed[i]
        assert len(p)==4 and 0<r-l<180
        w=[q*self.length[i]/2 for q,i in zip(weights,ids,strict=True)]
        x=[material(F(j)) for j in p]
        co=sum(v*dot(self.n[i],p) for v,i,p in zip(w,ids,x,strict=True))
        si=sum(v*dot(self.n[i],J(p)) for v,i,p in zip(w,ids,x,strict=True))
        k=sum(v*self.B[i] for v,i in zip(w,ids,strict=True))
        assert k>0
        out=[]
        for t in (l,r):
            s,c=self.tri.sincos(t)
            f=c*co+s*si
            assert f>0
            out.append((f-k).lower())
        return min(out)

    def local(self):
        l,r=self.f[5][:2]
        assert cross(l,r)>0
        W=[self.normalized(material(F(j*360,8192))) for j in WID]
        # Width-one normalization gives exactly .5 at all six hexagon normals.
        pins={i:self.normalized(material(F(a)-MID)) for i,a in FACENORMAL.items()}
        assert all((dot(self.n[i],p)-A(F(1,2))).contains(0) for i,p in pins.items())
        delta=upperbox(-WIDTH,WIDTH)*arb.pi()/180
        sn,cs=delta.sin_cos()
        rhs={i:(A(2*T)/self.length[i]-(A(F(1,2))*(cs-1)+dot(self.n[i],J(p))*sn)).upper()
            for i,p in pins.items()}
        x_l,x_r=-rhs[4],rhs[10]
        y_l=(-rhs[7]-x_r/2)/(A(3).sqrt()/2)
        y_r=(rhs[0]-x_l/2)/(A(3).sqrt()/2)
        tr=(x_l.union(x_r),y_l.union(y_r))
        q=[add(rot(w,sn,cs),tr) for w in W]
        assert all(cross(l,v)>0 and cross(v,r)>0 for v in q)
        assert all(cross(p,q)+cross(tr,rot(sub(q,p),sn,cs))>0 for p,q in zip(W,W[1:]))
        for i,p in pins.items():
            a,b,_=self.f[i];x=add(rot(p,sn,cs),tr)
            assert cross(a,b)>0 and cross(a,x)>0 and cross(x,b)>0
        ww=sub(W[-1],W[0])
        k=sum(cross(a,b) for a,b in zip(W,W[1:]))-cross(l,r)
        c=cross(l,W[0])+cross(W[-1],r)
        s=cross(l,J(W[0]))+cross(J(W[-1]),r)
        deriv=[]; weights=[]
        for idx,box in enumerate(((-WIDTH,F(0)),(F(0),WIDTH))):
            delta=upperbox(*box)*arb.pi()/180
            sn,cs=delta.sin_cos()
            w=rot(ww,sn,cs)
            move=ninety(add(sub(r,l),w));dm=ninety(J(w))
            f,i,j=PATTERNS[idx]
            a,b=solve(self.measure[i],self.measure[j],mul(-1,add(move,self.measure[f])))
            da,db=solve(self.measure[i],self.measure[j],mul(-1,dm))
            assert 0<a<1 and 0<b<1
            weights.append([str(a),str(b)])
            g=-c*sn+s*cs
            for ii,x,dx in ((f,A(1),A(0)),(i,a,da),(j,b,db)):
                v=dot(self.n[ii],J(pins[ii]))
                gap=A(F(1,2))*(cs-1)+v*sn
                slope=-A(F(1,2))*sn+v*cs
                g+=self.length[ii]*(dx*gap+x*slope)
            assert (g<0 if idx==0 else g>0),g
            deriv.append(str(g))
        f0=(k+c)/2
        assert f0>A(T),f0
        return dict(target=str(T),angles=[str(v) for v in self.breakpoints],translation_bounds=list(map(str,tr)),
            fan_samples=list(WID),area_at_120=str(f0),twice_area_derivatives=deriv,h_weight_bounds=weights)

    def make(self):
        from scout import Scout
        import numpy as np
        g=Scout();rows=[]
        def visit(l,r,d):
            a=float((l+r)/2)*np.pi/180
            vals=g.value(g.T-a)
            scores=(vals-g.B)@g.R.T
            for i in np.argsort(-scores)[:5]:
                key=g.triples[int(i)]
                if key not in self.tri.triples:continue
                p=[str(F(format((g.T[k]-a)*180/np.pi,'.13f'))) for k in key]
                v=self.tri.exact(1,l,r,key,p)
                if v>A(T):rows.append(['triangle',str(l),str(r),list(key),p]);return
            for i,(key,_) in enumerate(self.mixed):
                p=[str(F(format((g.T[k]-a)*180/np.pi,'.13f'))) for k in key]
                v=self.mixed_bound(l,r,i,p)
                if v>A(T):rows.append(['mixed',str(l),str(r),i,p]);return
            assert d<23,(float(l),float(r),float(scores.max()))
            m=(l+r)/2;visit(l,m,d+1);visit(m,r,d+1)
        l,r=self.breakpoints
        knots=sorted(set([F(5*j) for j in range(73) if F(5*j)!=MID]+[l,r]))
        for lo,hi in zip(knots,knots[1:]):
            if (lo,hi)==(l,r):rows.append(['fan',str(l),str(r),None,[]])
            else:visit(lo,hi,0)
        return rows

    def verify(self,plan):
        old=F(0); scores={};fan=None
        for name,a,b,i,p in plan:
            l,r=F(a),F(b)
            assert old==l and l<r;old=r
            if name=='fan':
                assert fan is None and (l,r)==self.breakpoints
                fan=self.local();continue
            if name=='triangle':v=self.tri.exact(1,l,r,i,p)
            else:
                assert name=='mixed'
                v=self.mixed_bound(l,r,i,p)
            assert v>A(T),(name,a,b,v)
            scores.setdefault(name,[]).append(v)
        assert old==360 and fan
        return dict(complete=True,threshold=str(T),hand_reduction='reflection across source axis 30 degrees equals a rotation by -60 degrees after horizontal reflection',
            angle_counts={k:len(v) for k,v in scores.items()},other_cells_lower={k:str(min(v)) for k,v in scores.items()},fan=fan)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan',type=Path);p.add_argument('out',type=Path);p.add_argument('--make-plan',action='store_true');args=p.parse_args()
    assert __debug__;ctx.prec=160
    ex=Verify()
    if args.make_plan:
        plan=ex.make();args.plan.write_text(json.dumps(plan,separators=(',',':'))+'\n')
    else:plan=json.loads(args.plan.read_bytes())
    r=ex.verify(plan)
    r['source_sha256']=sha(Path(__file__));r['plan_sha256']=sha(args.plan);r['core_sha256']=sha(HERE/'core.py')
    args.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)


if __name__=='__main__':main()

"""Replay the fixed true Gibbs host, the free-pose lower bounds and the fixed-pose upper bound."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import sys
from flint import ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from certify_lower import Check
from certify_joint_lower import Verify as Joint, T
from certify_upper import run as upper


def read(p):return json.loads(p.read_bytes())


def sha(p):return sha256(p.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('out_dir',type=Path);args=ap.parse_args();assert __debug__
    target=args.out_dir.resolve();target.mkdir(parents=True,exist_ok=True)
    ctx.prec=160
    settings=read(HERE/'settings.json')
    coarse=Check(F(settings['coarse_lower'])).verify(read(HERE/'plan-lower.json'))
    print('direct two-hand triangles',coarse,flush=True)
    assert F(settings['lower'])==T
    tight=Joint().verify(read(HERE/'plan-joint.json'))
    print('joint lower',tight,flush=True)
    original=HERE/'comp068'/'certify_gibbs_area_refined.py'
    data=subprocess.check_output([sys.executable,'-E','-B',str(original),'1.54','16','64'])
    gpath=target/'gibbs-true.json';gpath.write_bytes(data)
    a,b=read(gpath),read(HERE/'gibbs-raw.json')
    a.pop('python');b.pop('python');assert a==b
    result=upper(gpath,*settings['upper_grids'],F(settings['upper']))
    assert F(result['budget'][1])<F(settings['lower'])
    print('direct upper',result,flush=True)
    touched={
      str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and
       p.name in ('core.py','shared.py','candidate.py','certify.py','counterexample.json','candidate-areas.json','gibbs-raw.json',
                    'certify_lower.py','certify_joint_lower.py','certify_upper.py','plan-lower.json','plan-joint.json',
                    'verify_release.py','settings.json','certify_gibbs_area_refined.py','rational_trig.py',
                    'certify_ah_two_line_cap.py','ah_root_geometry_at_angle.py')}
    receipt=dict(complete=True,settings=settings,coarse_lower=coarse,strong_lower=tight,upper=result,source_sha256=touched,
                 precision=ctx.prec,python=platform.python_version(),flint=flint_version)
    (target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':main()

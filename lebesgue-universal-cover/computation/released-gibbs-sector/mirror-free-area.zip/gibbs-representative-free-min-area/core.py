"""Exact geometry of the representative Gibbs-cut host and seven-piece mirror test."""
from bisect import bisect_right
from functools import cache
from itertools import combinations
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from candidate import (A,F,arb,ctx,dt,av,ns,pt,rad,unit,add,sub,mul,dot,cross,J,M,N,peak,EH,release,curve_series,
    I,dec,upperbox)

LAM=F('.0065'); ALPHA=F('.001'); ETA=F('.000935')
B=F('.844082046521218581802948589770767704354')

@cache
def host():
    apex=peak(LAM)
    _,_,data=release(LAM)
    wi,wf=map(F,data['w']);left=pair(I(wi,wf))
    # Recover the exact right tangent from its unit-circle construction.
    ctr=pt('e3');v=sub(apex,ctr);d=dot(v,v)
    candidates=[add(ctr,mul(1/d,add(v,mul(k*(d-1).sqrt(),J(v))))) for k in (-1,1)]
    p,q=sub(pt('q'),ctr),sub(pt('y'),ctr)
    right,=[v for v in candidates if cross(p,sub(v,ctr))>0 and cross(sub(v,ctr),q)>0]
    inward=rad(N,A(ALPHA));_,eh,l_eh,r_eh=EH(A(ALPHA),A(ETA))
    tp=pair(F(1));pairs=[
      (pt('b1'),pt('q'),av(dt['n'][1])),
      (right,apex,unit(mul(-1,J(sub(apex,right))))),
      (apex,left,unit(mul(-1,J(sub(left,apex))))),
      (pt('p'),pt('f1'),av(dt['n'][2])),
      (pt('f1'),l_eh,av(dt['n'][3])),
      (l_eh,r_eh,inward),
      (pt('ip'),pt('e3'),av(dt['m'][3])),
      (pt('e3'),pt('d1'),av(dt['n'][4])),
      (pt('d1'),pt('g'),av(dt['n'][5])),
      (pt('k'),pt('c3'),av(dt['m'][5])),
      (pt('c3'),pt('b1'),av(dt['n'][0])),
    ]
    return dict(apex=apex,left=left,right=right,pair_root=(wi,wf),eh_l=l_eh,eh_r=r_eh,
        eh=eh,inward=inward,faces=pairs,arcs=[(pt('q'),right,pt('e3')),(tp,pt('p'),pt('g')),
        (r_eh,pt('ip'),pt('b3')),(pt('g'),pt('k'),pt('f3'))])


@cache
def pair(w):
    return tuple(A(c) for c in dt['pair'](dt['add'](dt['z'],dt['mul'](I(w),dt['direction']))))


@cache
def curves():
    U=arb.pi()/180
    bs=tuple(map(F,(0,8,10,30,32,60,62,90)))
    vals=[A(F(-1,2)),None,A(F(1,2)),A(F('0.4570771')),A(F(-1,2)),A(F('.1992443')),A(F(1,2))]
    trig=[(A(t)*U).sin_cos() for t in bs]
    mom=[b[0]-a[0] for a,b in zip(trig,trig[1:])]
    vals[1]=-sum(v*m for v,m in zip(vals,mom) if v is not None)/mom[1]
    assert all(v>=A(F(-1,2)) and v<=A(F(1,2)) for v in vals)
    u=v=A(0); rows=[]
    for (s,c),(sr,cr),e in zip(trig,trig[1:],vals):
        rows.append((u-e*c,v-e*s,e));u+=e*(cr-c);v+=e*(sr-s)
    s,c=(A(30)*U).sin_cos();x,y,e=rows[2]
    center=-(c*x+s*y+e)/c
    return bs,[(x+center,y,e) for x,y,e in rows]


@cache
def material(world_degrees):
    world=F(world_degrees);a=(world-30)%360
    if a>180:a-=360
    su=-1 if a<0 else 1
    sign=1; g=abs(a); phase=su
    if g>90:
        sign=-1;g=180-g;phase=-su
    n,r=curves();i=min(bisect_right(n,g)-1,len(r)-1)
    x,y,z=r[i];U=arb.pi()/180
    s,c=(A(g)*U).sin_cos();sn,cs=(A(world)*U).sin_cos()
    h=A(F(1,2))+sign*(x*c+y*s+z);d=sign*phase*(-x*s+y*c)
    return (h*cs-d*sn,h*sn+d*cs)


def arc_points(p,q,c,N):
    a,b=sub(p,c),sub(q,c)
    k=arb.atan2(cross(a,b),dot(a,b))
    assert 0<k<1
    return k,[add(c,rad(a,k*j/N)) for j in range(1,N)]


def boundary(N=1024,arc_grid=256):
    row=host();parts=row['arcs'];c0,c1,c2,c3=[arc_points(*a,arc_grid)for a in parts]
    wi,wf=row['pair_root']; ws=[wf+(1-wf)*F(j,N) for j in range(N+1)]
    vertices=[pt('b1'),pt('q'),*c0[1],row['right'],row['apex'],row['left'],*[pair(w)for w in ws[1:]],
        *c1[1],pt('p'),pt('f1'),row['eh_l'],row['eh_r'],*c2[1],pt('ip'),pt('e3'),pt('d1'),pt('g'),*c3[1],pt('k'),pt('c3')]
    return tuple(vertices),(c0[0],c1[0],c2[0],c3[0])

"""Directed upper bound for the true hull at the normalized 120-degree pose."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from core import *


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def monotone(points):
    points=sorted(set(points))
    def half(points):
        rim=[]
        for p in points:
            while len(rim)>1 and cross(sub(rim[-1],rim[-2]),sub(p,rim[-1]))<=0:
                rim.pop()
            rim.append(p)
        return rim[:-1]
    return half(points)+half(reversed(points))


def old_area(receipt):
    raw=json.loads(receipt.read_bytes()); assert raw['passed'] and F(raw['sigma_degrees'])==F('1.54')
    base=upperbox(*raw['area_interval'])
    gain,_,_=release(LAM)
    delete,_,_,_=EH(A(ALPHA),A(ETA))
    return base+gain-delete


def pair_two_bound():
    m=arb(0)
    for j in range(64):
        coeff=curve_series(I(F(j,64),F(j+1,64)))
        x,y=[2*A(k.c[2]) for k in coeff]
        v=(x*x+y*y).sqrt()
        m=max(m,v.upper())
    return m


def run(base_input,N,K,grid,target=F('9.768912e-6')):
    assert N>=32 and K>=32 and grid>=1000
    C,arcangles=boundary(N,K)
    scale=10**15
    tol=A(F(3,4*scale))
    def round_to_grid(p):
        q=[round(float(v.mid())*scale) for v in p]
        assert all(abs(v-A(F(r,scale)))<tol for v,r in zip(p,q,strict=True))
        return tuple(q)
    points=[round_to_grid(p) for p in C]
    sn,cs=A(3).sqrt()/2,A(F(-1,2))
    for j in range(grid):
        x,y=material(F(360*j,grid)); points.append(round_to_grid((cs*x-sn*y,sn*x+cs*y)))
    V=monotone(points)
    area=A(F(sum(cross(v,w) for v,w in zip(V,V[1:]+V[:1],strict=True)),2*scale**2))
    per=sum(A(dot(sub(w,v),sub(w,v))).sqrt() for v,w in zip(V,V[1:]+V[:1],strict=True))/scale
    wi,wf=host()['pair_root']; curve_error=pair_two_bound()*A((wf-wi+(1-wf)/N)**2)/8
    arc_error=(max(z.upper() for z in arcangles)/(K))**2/8
    host_error=max(curve_error.upper(),arc_error.upper())
    witness_error=2*(arb.pi()/(2*grid)).sin()**2
    delta=max(host_error,witness_error.upper())+tol*A(2).sqrt()
    error=delta*per+arb.pi()*delta**2
    base=old_area(base_input)
    upper=(area+error-base).upper()
    assert upper<A(target),(area,error,upper)
    return dict(complete=True,scope='true retained host plus one rotated true width-one witness',
        rotation_degrees=120,translation=[0,0],parameters=list(map(str,(LAM,ALPHA,ETA))),
        strict_upper=str(target),least_directed_upper=str(upper),base_area=dec(base,28),
        budget=dec(A(B)-base,28),polygon_vertices=len(V),perimeter=str(per),
        pair_interval_count=N,each_circle_interval_count=K,witness_interval_count=grid,
        directed_error_upper=str(error.upper()),pair_sagitta=str(curve_error),circle_sagitta=str(arc_error),
        width_one_sagitta=str(witness_error),base_sha256=sha(base_input),source_sha256=sha(Path(__file__)),core_sha256=sha(HERE/'core.py'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('base',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--pair',type=int,default=4096);p.add_argument('--circle',type=int,default=2048)
    p.add_argument('--witness',type=int,default=65536);p.add_argument('--target',type=F,default=F('9.768912e-6'))
    a=p.parse_args(); assert __debug__;ctx.prec=160
    result=run(a.base,a.pair,a.circle,a.witness,a.target)
    print(json.dumps(result,indent=2),flush=True)
    a.out.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()

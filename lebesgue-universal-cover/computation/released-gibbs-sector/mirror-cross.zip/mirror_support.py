from fractions import Fraction as F
from flint import arb

def A(q):
 q=F(q);return arb(q.numerator)/q.denominator

class Mirror:
 def __init__(self):
  self.unit=arb.pi()/180;self.breaks=list(map(F,[0,8,10,30,32,60,62,90]));self.dev=[A(F(-1,2)),None,A(F(1,2)),A(F('.4570771')),A(F(-1,2)),A(F('.1992443')),A(F(1,2))];mom=[(A(r)*self.unit).sin()-(A(l)*self.unit).sin() for l,r in zip(self.breaks,self.breaks[1:])];self.dev[1]=-sum(g*m for g,m in zip(self.dev,mom) if g is not None)/mom[1];assert all(x>=A(F(-1,2)) and x<=A(F(1,2)) for x in self.dev);a=b=A(0);self.rows=[]
  for l,r,c in zip(self.breaks,self.breaks[1:],self.dev):
   sl,cl=(A(l)*self.unit).sin_cos();sr,cr=(A(r)*self.unit).sin_cos();self.rows.append([a-c*cl,b-c*sl,c]);a+=c*(cr-cl);b+=c*(sr-sl)
  i=next(i for i in range(len(self.dev)) if self.breaks[i]<=30<=self.breaks[i+1]);center=-self.evalrow(self.rows[i],A(30))/(A(30)*self.unit).cos()
  for row in self.rows:row[0]+=center
 def evalrow(self,row,t):
  z,y,x=row;s,c=(t*self.unit).sin_cos();return z*c+y*s+x
 def support(self,u):
  th=arb.atan2(u[1],u[0])/self.unit-30
  while th>180:th-=360
  while th< -180:th+=360
  q=abs(th);sg=1
  if q>90:q=180-q;sg=-1
  assert q>0 and q<90
  values=[self.evalrow(row,q) for l,r,row in zip(self.breaks,self.breaks[1:],self.rows) if not(q<A(l) or q>A(r))];assert values;out=values[0]
  for x in values[1:]:out=out.union(x)
  return A(F(1,2))+sg*out

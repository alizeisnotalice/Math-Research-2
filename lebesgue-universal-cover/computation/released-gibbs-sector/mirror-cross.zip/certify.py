from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import json,sys
from flint import arb,ctx
ctx.prec=192
sys.path.insert(0,str(Path(__file__).resolve().parent))
from mirror_support import Mirror
hvec=Mirror().support
F=lambda x:arb(Fraction(str(x)).numerator)/Fraction(str(x)).denominator
cases=[('host1189','a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f','1.7320658799782152','-0.0000007779757453415','-0.0000007388733247274'),('host2162','51e8d5f9a3bd748bf1ddb5c08e1c18d115bfe9db5ccd2072a59403dd62d6555f','1.7320732404020651','-0.0000011157785399350','-0.0000014142325929790')];out=[]
for name,sha,qs,xs,ys in cases:
 p=Path(name+'.json');assert sha256(p.read_bytes()).hexdigest()==sha;host=json.loads(p.read_text());V=host['vertices'];d=F(host['denominator']);q=F(qs);cs=(1-q*q)/(1+q*q);sn=2*q/(1+q*q);x=F(xs);y=F(ys);low=None
 for i,(ax,ay) in enumerate(V):
  bx,by=V[(i+1)%len(V)];nx=F(by-ay)/d;ny=F(ax-bx)/d;L=(nx*nx+ny*ny).sqrt();u=((cs*nx+sn*ny)/L,(-sn*nx+cs*ny)/L);margin=(nx*(F(ax)/d-x)+ny*(F(ay)/d-y))/L-hvec(u)
  if low is None or margin.lower()<low.lower():low=margin
 assert low>0,(name,str(low));out.append({'host':name,'sha':sha,'q':qs,'translation':[xs,ys],'margin':str(low)});print(out[-1],flush=True)
Path('cross-cert.json').write_text(json.dumps(out,indent=2))

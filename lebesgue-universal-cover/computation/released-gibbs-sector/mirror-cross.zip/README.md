# Mirror seven-piece body in two fixed hosts

The seven-piece mirror-symmetric constant-width body of `nov19-new-B-mirror-counterexample.zip` is contained in both included frozen hosts. That source package SHA256 is e3139210aa68b9c57d027e3b4cf6b6a065f1b88d402bebea0dae3ecb05e8b68c. The source `source-certify.py`, SHA256 a6bce07c5689f5fb724102795fa8af6f8f8ab604be236c3f384e7b8728c4b219, proves curvature and normalization properties; `mirror_support.py` reproduces its support construction without external project dependencies.

`certify.py` uses 192-bit Arb, rational tangent-half-angle rotations and rational translations. It evaluates the true support function on every edge normal. For 1189-face host a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f, the minimum strict clearance is >2.2676958613e-7; for 2162-face host 51e8d5f9a3bd748bf1ddb5c08e1c18d115bfe9db5ccd2072a59403dd62d6555f it is >2.8194003961e-7. This is compatible with the body being a counterexample for the separate released AH/rotated EH family.

Run `python -I -B audit.py` with python-flint. It verifies file hashes, confirms each polygon by exact integer halfplanes, and reruns both support tests. `audit.log` is the actual isolated replay.

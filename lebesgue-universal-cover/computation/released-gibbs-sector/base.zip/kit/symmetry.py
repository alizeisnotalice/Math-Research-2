"""A single true Gibbs placement works both before and after the new EH cut."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from candidate import *

T=arb.pi()/3
anchor=arb.pi()*A('31.54')/180
x0=arb.atan2(-N[1],-N[0])
lam=A('.174');beta=A('-.05')
def interpolant(x):
    return ((T-x).sin()-x.sin())/T.sin()
def bound(x):
    assert 0<x<anchor<T
    X=[A(0),x,anchor,T]
    def green(s,k):
        return s.min(k).sin()*(T-s.max(k)).sin()/T.sin()
    vals=[green(s,x)-lam*green(s,anchor)-beta*(s-T/2).sin() for s in X]
    integral=A(0)
    for j in range(3):
        d=X[j+1]-X[j];u,v=vals[j],vals[j+1]
        if u*v<0:
            if u<0:u,v=-u,-v
            w=arb.atan2(u*d.sin(),u*d.cos()-v)
            assert w>0 and d-w>0
            integral+=u*(w/2).tan()-v*((d-w)/2).tan()
        else:
            integral+=(abs(u)+abs(v))*(d/2).tan()
    return integral/2
def actual_mode_margin(U,h):
    out=[]
    pre=refl(U)
    for VX,ed in vxlist:
        candidates=[dot(refl(VX[v]),U)+rr for i,(v,rr) in enumerate(ns['sector']) if not cross(ed[i],pre)<0 and not cross(pre,ed[(i+1)%10])<0]
        assert candidates
        out.append((h-max(e.upper() for e in candidates)).lower())
    return out
rows=[];delta=A('.000012')
for j in range(1024):
    a,b=[F('-.002')+F(k,256000) for k in (j,j+1)]
    xx=upperbox(a,b);U=rad(N,xx);H=dot(U,M)-A('.00094')
    x=x0+xx
    d=bound(x)
    penalty=A(F(7,3))+abs(interpolant(x))+lam*(abs(interpolant(anchor))+A(F(7,3)))+2*abs(beta)*(T/2).cos()
    gap=H-A(F(1,2))-d
    near=(gap-penalty*delta).lower()
    m=actual_mode_margin(U,H)
    assert min(m)>A('.015') and near>0,(j,min(m),near,gap,penalty)
    rows.append(dict(alpha=[str(a),str(b)],symmetry_gap=str(gap.lower()),penalty=str(penalty.upper()),neighborhood_gap=str(near),height=str(H.lower()),hard_points=list(map(str,m))))
minima={k:str(min(arb(r[k]).lower() for r in rows)) for k in ('symmetry_gap','neighborhood_gap','height')}
mmin=str(min(arb(z).lower() for r in rows for z in r['hard_points']))
disk_radius=A('.00295')
disk_margin=arb(minima['height'])-A(F(1,2))-(1+2/A(3).sqrt())*disk_radius
assert disk_margin>A('.00000205')
defect_budget=3*arb(minima['symmetry_gap'])
assert defect_budget>A('.00015852')
ans=dict(near_disk_radius='.00295',near_disk_EH_slack=str(disk_margin.lower()),six_direction_budget=str(defect_budget.lower()),source=sha256(Path(__file__).read_bytes()).hexdigest(),dual_coefficients=['.174','-.05'],halfspan_degrees='60',anchor_degrees='31.54',epsilon='.000012',threefold_rotation_defect='.000018',alpha_boxes=1024,domain=['-.002','.002'],minima=minima,min_explicit_QA_slack=mmin,rows=rows)
(D/'symmetry.json').write_text(json.dumps(ans,indent=2)+'\n')
print(minima,mmin)

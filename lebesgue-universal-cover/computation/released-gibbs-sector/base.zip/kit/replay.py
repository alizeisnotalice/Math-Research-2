from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,shutil,subprocess,sys
D=Path(__file__).resolve().parent;W=Path(sys.argv[1]).resolve();W.mkdir(parents=True,exist_ok=True);assert not any(W.iterdir())
def sha(p):return sha256(p.read_bytes()).hexdigest()
reg=json.loads((D/'manifest.json').read_bytes())
for n,h in reg.items():assert sha(D/n)==h
with ZipFile(D/'obstruction.zip') as z:z.extractall(W)
comp=W/'comp068';comp.mkdir()
for n in ('certify_gibbs_area_refined.py','rational_trig.py','certify_ah_two_line_cap.py','ah_root_geometry_at_angle.py'):
    p=W/'barrier'/'comp068'/n;shutil.copyfile(p,comp/n)
for n in ('shared.py','candidate.py','symmetry.py','test_g.py'):shutil.copyfile(D/n,W/n)
for s,outs in [('candidate.py',['candidate-areas.json','gibbs-raw.json']),('symmetry.py',['symmetry.json']),('test_g.py',['membership-G.json'])]:
    subprocess.run([sys.executable,'-I','-B',str(W/s)],cwd=W,check=True,stdout=subprocess.DEVNULL)
    for n in outs:assert (W/n).read_bytes()==(D/n).read_bytes()
subprocess.run([sys.executable,'-I','-B',str(W/'barrier'/'replay.py'),str(W/'original')],cwd=W,check=True)
print('Verified the new AH tangents, the true EH areas, all three complete bodies and all 1024 Green bounds.')

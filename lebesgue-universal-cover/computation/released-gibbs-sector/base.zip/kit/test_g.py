from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from shared import *
from fractions import Fraction as F
cross,inv=ns['cross'],ns['perp'];one=A(1);zero=A(0)
def norm(v):return dot(v,v).sqrt()
def unit(v):return mul(1/norm(v),v)
def get(k):
    if k=='tp':return refl(ns['points'](A(1))[0][2])
    return pt(k)
def modes(vx,ed,U):
    pre=refl(U)
    return [(i,v,c) for i,(v,c) in enumerate(ns['sector']) if not cross(ed[i],pre)<0 and not cross(pre,ed[(i+1)%10])<0]
def support(vx,ed,U):
    vals=[dot(refl(vx[v]),U)+c for i,v,c in modes(vx,ed,U)]
    assert vals
    return max(z.upper() for z in vals)
def mode_intervals(vx,ed,U):
    pre=refl(U)
    return [(i,v,c) for i,(v,c) in enumerate(ns['sector']) if not cross(ed[i],pre)<0 and not cross(pre,ed[(i+1)%10])<0]
def string(v):return str(v.lower())
arcs=[('q','y','e3'),('y','t','c'),('tp','p','g'),('h','u','c3'),('t_eh','ip','b3'),('g','k','f3')]
# Known endpoint support of a body in H equals 1/2 along every hexagon normal.
Ns=list(map(av,dt['n']))
def pin(endpoint):
    return [(k,u) for k,u in enumerate(Ns) if all((u[t]-endpoint[t]).contains(0) for t in (0,1))]
def harmonic_upper(z,l,r,u,center,rad,i,ia,ib):
    # r and l are unit vectors at the closed subdivision endpoints; u encloses every direction.
    # d/dtheta (z dot n)=z dot J n.
    dd=dot(z,inv(u))
    endpoint=None
    if dd>0: best=dot(z,r);endpoint=r;idx=ib
    elif dd<0:best=dot(z,l);endpoint=l;idx=ia
    else: best=norm(z)
    gap=one-rad-best
    if gap>=0:return gap.lower(),'strict'
    if gap.contains(0) and endpoint is not None and idx in (0,64):
        pp=pin(endpoint)
        if pp and len(modes(vx,ed,endpoint))==1 and i in [item[0] for item in modes(vx,ed,endpoint)] and (dot(center,pp[0][1])+one-A(F(1,2))).contains(0):
            allowed={('q','y',0):1,('tp','p',64):2,('h','u',0):3}
            assert allowed.get((start,end,idx))==pp[0][0]
            # The exact endpoint height of the body is half, irrespective of active fan.
            # Only apply to true fan at this exact endpoint, or when direct scalar already strictly positive.
            return zero,'hex_pin'
    return gap.lower(),'unproved'
allrows=[]
for j,(vx,ed) in enumerate(vxlist):
    drows=[]
    for start,end,center in arcs:
        c=get(center)
        a,b=sub(get(start),c),sub(get(end),c)
        assert cross(a,b)>0 and dot(a,b)>0
        minimum=one;op=[]
        for k in range(64):
            def vv(x):return unit(add(mul(one-x,a),mul(x,b)))
            l,r=vv(A(F(k,64))),vv(A(F(k+1,64)))
            # A normalised linear interpolation of the two endpoints sweeps each circular normal fan.
            x=ns['box'](F(k,64),F(k+1,64))
            # Use a+b*x expanded on the chord to keep the enclosure narrow.
            v=unit(add(a,mul(x,sub(b,a))))
            for i,z,rad in mode_intervals(vx,ed,v):
                gap,kind=harmonic_upper(sub(refl(vx[z]),c),l,r,v,c,rad,i,k,k+1)
                minimum=min(minimum,gap)
                if kind!='strict':op.append((k,i,kind,str(gap)))
        assert minimum>=0 and all(v[2]=='hex_pin' for v in op)
        print(j,(start,end),minimum,op[:5],flush=True)
        drows.append(dict(arc=[start,end,center],min=string(minimum),nonpositive=op))
    pairmin=one;pairidx=None
    def paired(w):return refl(ns['points'](A(w))[0][2])
    prev=paired(F(0));N=1024
    for k in range(1,N+1):
        after=paired(F(k,N));out=unit(mul(-1,inv(sub(after,prev))))
        gap=dot(out,prev)-support(vx,ed,out)
        if gap<pairmin:pairmin=gap;pairidx=k
        prev=after
    assert pairmin>0
    print(j,'pair chords',pairmin,pairidx,flush=True)
    drows.append(dict(pair_chords=N,min=string(pairmin),idx=pairidx))
    for a,b,kind in [('b1','q','H'),('t','z','n0'),('p','f1','H'),('f1','h','H'),('u','t_eh','EH'),('ip','e3','m3'),('e3','d1','H'),('d1','g','H'),('k','c3','m5'),('c3','b1','H')]:
        v=get(a);out=unit(mul(-1,inv(sub(get(b),v))));g=dot(out,v)-support(vx,ed,out)
        if kind=='H':
            assert pin(out) and (dot(out,v)-A(F(1,2))).contains(0),(a,b,pin(out),g)
            continue
        assert g>0
        print(j,a,b,g,flush=True)
        drows.append(dict(edge=[a,b,kind],min=string(g)))
    allrows.append(drows)
(D/'membership-G.json').write_text(json.dumps(allrows,indent=2)+'\n')

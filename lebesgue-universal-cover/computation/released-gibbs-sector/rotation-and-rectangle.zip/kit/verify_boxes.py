from pathlib import Path
import sys,json
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from parameter_fence import test,F
cert=json.loads((D/'continuous-results.json').read_bytes());rows=cert['rows']
assert cert['unresolved']==[] and len(rows)==3984
bounds=[F('.300'),F('.445'),F('-.0081'),F('.0002')]
boxes=[tuple(map(F,r['box'])) for r in rows]
for a,b,c,d in boxes:assert bounds[0]<=a<b<=bounds[1] and bounds[2]<=c<d<=bounds[3]
xx=sorted({a for x in boxes for a in x[:2]});assert xx[0]==bounds[0] and xx[-1]==bounds[1]
for l,r in zip(xx,xx[1:]):
    ss=sorted((c,d) for a,b,c,d in boxes if a<=l and r<=b)
    assert ss[0][0]==bounds[2] and ss[-1][1]==bounds[3] and all(y[1]==z[0] for y,z in zip(ss,ss[1:]))
for (a,b,c,d),row in zip(boxes,rows,strict=True):
    new,_=test(a,b,c,d,[tuple(row['pose'])])
    assert new==row
print('3984 closed support boxes and the full planar partition verified.',flush=True)

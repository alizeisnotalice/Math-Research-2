"""All exact fivefold and sevenfold width-one bodies fit every parameter in the box."""
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from candidate import *
T=arb.pi()/3;a=A(F('31.54'))*arb.pi()/180;x0=cross(n3,N).asin()
def profile_kernel(s,angle,p):
    diff=s-angle;ratio=diff/p
    lo=int(ratio.lower().floor().unique_fmpz());hi=int(ratio.upper().floor().unique_fmpz())
    vals=[]
    for j in range(lo,hi+1):
        u=diff-j*p
        val=(-1 if j%2==0 else 1)*(p/2-u).sin()/(2*(p/2).cos())
        vals.append(val)
    ret=vals[0]
    for el in vals[1:]:ret=ret.union(el)
    return ret
def prove(k,b3,b5,equal):
    p=arb.pi()/k
    def ck(t):return ((T-t).sin()/T.sin(),t.sin()/T.sin())
    constants=[a,2*T+a,2*T];terms=[A(F(v)) for v in [b3,b5,equal]];m=512
    assert terms[0]>=0 and terms[1]>=0
    grid=[]
    for j in range(m):
        s=p*upperbox(F(j,m),F(j+1,m));B0=profile_kernel(s,A(0),p);B1=profile_kernel(s,T,p);rest=A(0)
        for t,v in zip(constants,terms):
            c0,c1=ck(t);rest+=v*(profile_kernel(s,t,p)-c0*B0-c1*B1)
        grid.append((s,B0,B1,rest))
    out=[]
    for j in range(64):
        alpha=upperbox(F(-2,1000)+F(j,16000),F(-2,1000)+F(j+1,16000));x=x0+alpha
        cc0,cc1=ck(x);rhs=A(0);n=rad(N,alpha)
        for s,B0,B1,rest in grid:
            rhs+=abs(profile_kernel(s,x,p)-cc0*B0-cc1*B1-rest).upper()
        bound=rhs*p/(2*m);gap=dot(n,M)-A('.00094')-A(F(1,2))-bound
        assert gap>0,(k,j,gap)
        v0,v1=cc0,cc1
        for t,v in zip(constants,terms):
            c0,c1=ck(t);v0-=v*c0;v1-=v*c1
        fac=1+sum(abs(v) for v in terms)+abs(v0)+abs(v1)
        admissible=(gap/fac).lower();assert admissible>0
        out.append(dict(alpha_index=j,maximal_deviation=str(bound.upper()),EH_slack=str(gap.lower()),perturbation_factor=str(fac.upper()),tolerated_Hausdorff=str(admissible)))
    return dict(rotation_order=k,dual=[b3,b5,equal],source_intervals=m,tilt_intervals=64,minimum_Hausdorff=str(min(arb(z['tolerated_Hausdorff']).lower() for z in out)),minimum=str(min(arb(z['EH_slack']).lower() for z in out)),rows=out)
ans=[prove(5,'.197','.163','-.141'),prove(7,'0','0','-.717')]
(D/'odd57.json').write_text(json.dumps(ans,indent=2)+'\n')
print([(z['rotation_order'],z['minimum'],z['minimum_Hausdorff']) for z in ans],flush=True)

"""Verified fixed-pose cover of closed (w,e) parameter boxes of the five-anchor Reuleaux family."""
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
exec(compile((D/'legacy_exact.py').read_text().split('old={}')[0],str(D/'legacy_exact.py'),'exec'))
poses=[(0,1),(240,-1),(240,1),(0,-1)]+[(r,s) for r in (60,120,180,300) for s in (1,-1)]
def back(turn,sg,n):return ns['rotate']((n[0],sg*n[1]),ns['trig'](A(-turn)))
inds=list(range(len(nonhex)-64,len(nonhex)))+list(range(0,len(nonhex)-64,64))+[k for k in range(len(nonhex)-64) if k%64]
pre={po:[(back(*po,nonhex[k][0]),nonhex[k][1],nonhex[k][2]) for k in inds] for po in poses}
orders,sector=ns['orders'],ns['sector'];hexs=[av(v) for v in dt['n']]
def chart(w):return ns['chart'](add(ns['z'],mul(w,ns['D'])))
def vertices(l,t):
    p=ns['psi'](l)
    return [add(ns['l0'],mul(l,ns['el'])),refl(add(ns['l0'],mul(p,ns['el']))),refl(ns['X'](p,-t)),add(ns['mid'],mul(t,ns['en'])),ns['X'](l,t)]
def test(a,b,c,d,which=poses):
    wm,em=(a+b)/2,(c+d)/2;hw,he=A((b-a)/2),A((d-c)/2)
    W=upperbox(a,b);E=upperbox(c,d);l,t=chart(W);t-=E;p=ns['psi'](l)
    vm=vertices(chart(A(wm))[0],chart(A(wm))[1]-A(em));v=vertices(l,t)
    _,gl,gn=ns['points'](W);dl,dn=dot(gl,ns['D']),dot(gn,ns['D']);dp=ns['psi_prime'](v[0])*dl
    al,at=ns['derivs'](*ns['chart_bounds'](l,t));bl,bt=ns['derivs'](*ns['chart_bounds'](p,-t))
    Z=(A(0),A(0));gw=[mul(dl,ns['el']),refl(mul(dp,ns['el'])),refl(sub(mul(dp,bl),mul(dn,bt))),mul(dn,ns['en']),add(mul(dl,al),mul(dn,at))]
    ge=[Z,Z,refl(bt),mul(-1,ns['en']),mul(-1,at)]
    wd=upperbox(-(b-a)/2,(b-a)/2);ed=upperbox(-(d-c)/2,(d-c)/2)
    V=[add(v0,add(mul(wd,h),mul(ed,j))) for v0,h,j in zip(vm,gw,ge)]
    fan=[sub(V[i],V[j]) for i,j in orders]
    if not all(cross(fan[i],fan[(i+1)%10])>0 for i in range(10)):return None,'fan transition'
    if not all(dot(sub(V[i],V[j]),sub(V[i],V[j]))<1 for i in range(5) for j in range(i) if (i,j) not in orders):return None,'diameter'
    def modes(n):
        signs=[cross(f,n) for f in fan]
        return [sector[k] for k in range(10) if not signs[k]<0 and not signs[(k+1)%10]>0]
    for n,f in zip(hexs,[(1,1),(3,1),(0,1),(1,0),(3,0),(0,0)],strict=True):
        if modes(n)!=[f]:return None,'hexagonal pin mode'
    last=None
    for po in which:
        mg=A(1);weak=None
        for n,h,name in pre[po]:
            active=modes(n);assert active
            val=max((dot(vm[i],n)+r+hw*abs(dot(gw[i],n))+he*abs(dot(ge[i],n))).upper() for i,r in active)
            gap=(h-val).lower()
            if gap<mg:mg=gap;weak=name
            if gap<=0:
                last=(po,name,float(gap));break
        if mg>0:
            return dict(box=list(map(str,(a,b,c,d))),pose=list(po),margin=str(mg),weakest=weak),None
    return None,last

if __name__=='__main__':
    cases=[('.31','.33','-.009','-.007'),('.428','.431','-.00005','.00005'),('.31','.44','-.008','.008'),('.30','.45','-.01','.01'),('.31','.32','-.009','-.008'),('.3199','.3199','-.008','-.008'),('.429','.429','-.00003865','-.00003865'),('.43','.43','0','0')]
    for item in cases:
        q,e=test(*map(F,item))
        print(item,q,e,flush=True)

from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,shutil,subprocess,sys
D=Path(__file__).resolve().parent;core=Path(sys.argv[1]).resolve();w=Path(sys.argv[2]).resolve()
w.mkdir(parents=True,exist_ok=True);assert not any(w.iterdir())
def sha(p):return sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((D/'manifest.json').read_bytes()).items():assert sha(D/n)==h
assert sha(core)=='85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1'
with ZipFile(core) as z:z.extractall(w/'base')
k=w/'base'/'kit'
with ZipFile(k/'obstruction.zip') as z:z.extractall(w/'old')
shutil.copytree(w/'old'/'barrier'/'comp068',w/'comp068')
for n in ['candidate.py','shared.py']:shutil.copyfile(k/n,w/n)
for n in ['odd57.py','parameter_fence.py','inner_grid.py','legacy_exact.py','legacy-choices.json','continuous-results.json','verify_boxes.py']:shutil.copyfile(D/n,w/n)
subprocess.run([sys.executable,'-I','-B',str(w/'odd57.py')],cwd=w,check=True)
assert (D/'odd57.json').read_bytes()==(w/'odd57.json').read_bytes()
subprocess.run([sys.executable,'-I','-B',str(w/'verify_boxes.py')],cwd=w,check=True)

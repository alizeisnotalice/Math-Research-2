from pathlib import Path
import sys,json
D0=Path(__file__).resolve().parent;src=D0 if (D0/'candidate.py').is_file() else D0.parent
sys.path.insert(0,str(src))
from candidate import *
U=arb.pi()/180
# Piecewise constant curvature deviation on distance in degrees to the mirror line.
breaks=list(map(F,[0,8,10,30,32,60,62,90]))
dev=[A(F(-1,2)),None,A(F(1,2)),A(F('0.4570771')),A(F(-1,2)),A(F('.1992443')),A(F(1,2))]
mom=[(A(r)*U).sin()-(A(l)*U).sin() for l,r in zip(breaks,breaks[1:])]
dev[1]=-sum(g*m for g,m in zip(dev,mom) if g is not None)/mom[1]
assert all(x>=A(F(-1,2)) and x<=A(F(1,2)) for x in dev)
def harmonic(q):
    return (q*U).sin_cos()
def select(t):
    return next(i for i in range(len(dev)) if breaks[i]<=t<=breaks[i+1])
a=b=A(0);rows=[]
for l,r,c in zip(breaks,breaks[1:],dev):
    sl,cl=harmonic(A(l));sr,cr=harmonic(A(r))
    rows.append([a-c*cl,b-c*sl,c]);a+=c*(cr-cl);b+=c*(sr-sl)
def evalrow(row,t,d=False):
    z,y,x=row;s,c=harmonic(t)
    return -z*s+y*c if d else z*c+y*s+x
center=-evalrow(rows[select(F(30))],A(30))/(A(30)*U).cos()
for row in rows:row[0]+=center
def along(a,sg,q,d=False):
    i=select(a+sg*q);z,y,x=rows[i];s,c=harmonic(A(a))
    return (z*c+y*s,sg*(y*c-z*s),x)
knots=sorted(set([F(0),F(30)]+[x for v in breaks for x in [30-v,v-30,90-v] if 0<=x<=30]))
root=[]
for l,r in zip(knots,knots[1:]):
    mid=(l+r)/2
    trip=[along(30,-1,mid),along(30,1,mid),along(90,-1,mid)]
    co=tuple(x-y-z for x,y,z in zip(*trip));worst=A(-1);first=[]
    n=int((r-l)*100)
    for j in range(n):
        v=upperbox(l+(r-l)*F(j,n),l+(r-l)*F(j+1,n))
        # F(0)=0 exactly, from g(30)=g(90)=0.
        deriv=(l==0 and j<min(n,50))
        val=evalrow(co,v,deriv)
        if not val<0:first.append((j,float(val.mid()),float(val.rad())))
        worst=max(worst,val.upper())
    root.append(dict(interval=list(map(str,(l,r))),upper=str(worst),fail=first[:4],failed=len(first)))
print('root',[(x['interval'],x['failed'],x['fail']) for x in root],flush=True)
def hvec(u):
    th=arb.atan2(u[1],u[0])/U-30
    while th>180:th-=360
    while th< -180:th+=360
    q=abs(th)
    sg=1
    if q>90:q=180-q;sg=-1
    assert q>0 and q<90
    val=[evalrow(row,q) for l,r,row in zip(breaks,breaks[1:],rows) if not (q<A(l) or q>A(r))]
    assert val
    out=val[0]
    for x in val[1:]:out=out.union(x)
    return A(F(1,2))+sg*out
def back(j,n):return rad(n,-A(j)*arb.pi()/3)
# The whole hull, including the released apex, respects the six hexagon and both Gibbs caps.
for lam in [F('.005'),F('.008')]:
    apex=peak(lam)
    assert all(dot(av(u),apex)<A(F(1,2)) for u in list(dt['n'])+[dt['m'][3],dt['m'][5]])
angles=[]
for j,i in [(0,5),(1,5),(3,3),(4,3),(5,3)]:
    n=av(dt['m'][i]);val=hvec(back(j,n))-A('.5')
    assert val>A('.000755')
    angles.append(dict(turn=j*60,face='m'+str(i),excess=str(val.lower())))
ar=[]
for j in range(512):
    al=upperbox(F('-.002')+F(j,128000),F('-.002')+F(j+1,128000));n=rad(N,al)
    val=hvec(back(2,n))-(dot(n,M)-A('.00093'));ar.append(str(val.lower()))
print('angles',angles,'EH',min(arb(s).lower() for s in ar),flush=True)
assert all(not x['failed'] for x in root)
assert all(arb(s)>A('.0003') for s in ar)
out=dict(curvature_breakpoints=list(map(str,breaks)),curvature_deviation=[str(x) for x in dev],translation=str(center),F_root_half_chamber=root,dihedral_rotations=angles,EH_excess_minimum=str(min(arb(s).lower() for s in ar)),EH_full_closed_angles=ar)
(D0/'counterexample.json').write_text(json.dumps(out,indent=2)+'\n')

"""Sharp local Green lower bound from the actual curvature mass of the Gibbs window."""
import argparse
import json
from fractions import Fraction as Fr
from pathlib import Path
import sys
from flint import arb, ctx

parser = argparse.ArgumentParser()
parser.add_argument("geometry", type=Path, help="Directory prepared by the closed AH/EH baseline replay")
parser.add_argument("output", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.geometry.resolve()))
import candidate as g
ctx.prec = 192

def rational_upper(x):
    return Fr(int((x.upper()*10**12).ceil().unique_fmpz()), 10**12)

def rational_lower(x):
    return Fr(int((x.lower()*10**12).floor().unique_fmpz()), 10**12)

L = g.A(Fr(1577,50)) * arb.pi()/180
den = g.cross(g.n3, g.m3)
mass17 = arb.pi()/17
assert L > mass17 and min(L-arb.pi()/9, L-arb.pi()/11, arb.pi()/13, arb.pi()/15, (L-arb.pi()/19)/2) > mass17
def calc(n):
    u = g.cross(n, g.m3)/den
    v = g.cross(g.n3, n)/den
    dn = g.J(n)
    du = g.cross(dn, g.m3)/den
    dv = g.cross(g.n3, dn)/den
    S, Sp = u+v, du+dv
    offset = g.dot(n,g.M) - g.A(Fr(94,100000))
    H = S/2 - offset
    Hp = Sp/2 - g.dot(dn, g.M)
    num = H*(2*S-H)
    denom = 4*u*v
    derivative_num = (2*(S-H)*Hp+2*H*Sp)*denom - num*4*(du*v+u*dv)
    assert u>0 and v>0 and H>0 and denom>num>0
    def given_mass(m):
        b = denom*(m/2).sin()**2
        return b/(S+(S*S-b).sqrt())
    exact_mass = 2*(num/denom).sqrt().asin()
    eps = (given_mass(mass17)-H)/(S+1)
    return exact_mass, eps, derivative_num

count = 4096
lower_alpha, upper_alpha = Fr(-1,500), Fr(1,500)
derivs = []
radius = []
mass = []
for i in range(count):
    lo = lower_alpha + (upper_alpha-lower_alpha)*i/count
    hi = lower_alpha + (upper_alpha-lower_alpha)*(i+1)/count
    n = g.rad(g.N, g.upperbox(lo,hi))
    m,e,d = calc(n)
    radius.append(e.lower())
    mass.append(m.upper())
    derivs.append(d)
max_mass = max(mass)
if all(x>0 for x in derivs):
    maximizing = upper_alpha
elif all(x<0 for x in derivs):
    maximizing = lower_alpha
else:
    maximizing = None
if maximizing is not None:
    max_mass = calc(g.rad(g.N,g.A(maximizing)))[0]
eps = min(radius)
assert eps>0 and max_mass<g.A(Fr('0.16795433'))
out = dict(cells=count, maximizing_angle=str(maximizing), max_mass=str(max_mass), required_mass_upper=str(rational_upper(max_mass)), required_average_upper=str(rational_upper(max_mass/L)), radius_lower=str(rational_lower(eps)), radius_interval=str(eps), min_ratio_derivative_numerator=str(min(t.lower() for t in derivs)), max_ratio_derivative_numerator=str(max(t.upper() for t in derivs)), universal_odd_k9_mass_lower='pi/17')
args.output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

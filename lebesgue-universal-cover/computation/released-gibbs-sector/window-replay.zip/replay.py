"""Reconstruct the R276 window geometry and verify all directed constants."""
import argparse
import io
import json
import shutil
import subprocess
import sys
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path, help="base.zip from the same research round")
parser.add_argument("output", type=Path, help="new output directory")
args = parser.parse_args()
source = Path(__file__).resolve().parent
target = args.output.resolve()
target.mkdir(parents=True, exist_ok=False)
assert sha256(args.base.read_bytes()).hexdigest() == "85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1"
with ZipFile(args.base) as outer:
    for name in ["candidate.py", "shared.py"]:
        (target / name).write_bytes(outer.read("kit/" + name))
    with ZipFile(io.BytesIO(outer.read("kit/obstruction.zip"))) as archive:
        for member in archive.namelist():
            if member.startswith("barrier/comp068/") and not member.endswith("/"):
                dest = target / Path(member).relative_to("barrier")
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(archive.read(member))
for name in ["mass", "pair", "weighted"]:
    result = target / (name + ".json")
    subprocess.run([sys.executable, "-I", "-B", str(source/(name+".py")), str(target), str(result)], check=True)
    assert json.loads(result.read_bytes()) == json.loads((source/(name+".json")).read_bytes())
print("Verified all one- and two-window bounds.")

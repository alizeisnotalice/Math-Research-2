"""Sharp overlap bounds for two translated or reflected Gibbs curvature windows."""
import argparse
import json
import sys
from fractions import Fraction
from pathlib import Path
from flint import arb, ctx

parser = argparse.ArgumentParser()
parser.add_argument("geometry", type=Path)
parser.add_argument("output", type=Path)
arguments = parser.parse_args()
sys.path.insert(0, str(arguments.geometry.resolve()))
import candidate as g

ctx.prec = 192
angle = g.A(Fraction("31.54")) * arb.pi() / 180
sine = g.cross(g.n3, g.m3)
angle_boxes = 4096

def thresholds(lo, hi):
    n = g.rad(g.N, g.upperbox(lo, hi))
    a = g.cross(n, g.m3) / sine
    b = g.cross(g.n3, n) / sine
    h = (a + b) / 2 - g.dot(n, g.M) + g.A(Fraction(".00094"))
    assert a > b > h > 0
    x = (b * sine).asin()
    ra = (1 - h/a).acos()
    rb = (1 - h/b).acos()
    assert 0 < ra < x < angle/2 and rb < angle-x
    # At the two errors ra, rb, the weighted kernels meet.
    weight = (2*a-h).sqrt() / ((2*a-h).sqrt() + (2*b-h).sqrt())
    assert weight > g.A(Fraction(1,2))
    integral = a*(1-x.cos()) + b*(1-(angle-x).cos())
    assert (1-weight)*integral > h
    # At d=0 both opposite-handed orderings are feasible with equal weights.
    assert b*(1-(angle/2).cos()) > h
    return [(angle-z)*180/arb.pi() for z in (ra+rb, 2*rb, 2*ra)]

lower = [[], [], []]
for j in range(angle_boxes):
    lo = Fraction(-1,500) + Fraction(j,250*angle_boxes)
    hi = lo + Fraction(1,250*angle_boxes)
    for acc, value in zip(lower, thresholds(lo,hi)):
        acc.append(value.lower())
def down(x):
    return str(Fraction(int((x * 10**8).floor().unique_fmpz()), 10**8))
w = [min(vals) for vals in lower]
out = dict(cells=angle_boxes, cases=["same orientation", "opposite orientation, small slopes inside", "opposite orientation, large slopes inside"], radius_degrees=[down(t) for t in w], interval_lower=list(map(str,w)))
arguments.output.write_text(json.dumps(out, indent=2)+"\n")
print(out)

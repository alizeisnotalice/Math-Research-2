在含 python-flint 0.9.0 的 Python 3.13.18 中运行 `python -I -B replay.py BASE_ZIP NEW_OUTPUT`。BASE_ZIP 为同轮 base.zip。三个程序均在 192 位使用 4096 个闭参数区间。推导见本轮 gibbs-curvature-windows.md。

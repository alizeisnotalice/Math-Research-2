"""Two Gibbs placements whose curvature windows are nearly antipodal."""
import argparse, json, sys
from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
parser=argparse.ArgumentParser()
parser.add_argument("geometry",type=Path)
parser.add_argument("out",type=Path)
args=parser.parse_args()
sys.path.insert(0,str(args.geometry.resolve()))
import candidate as g
ctx.prec=192
L=g.A(F('31.54'))*arb.pi()/180
den=g.cross(g.n3,g.m3)
def bounds(alpha):
    n=g.rad(g.N,alpha)
    u=g.cross(n,g.m3)/den
    v=g.cross(g.n3,n)/den
    assert u>=v and v>0
    S=u+v
    H=S/2-g.dot(n,g.M)+g.A(F('0.00094'))
    same_required=2*(H*(S-H)/(u*v)).sqrt().asin()
    both_required=2*(1-H/v).acos()
    return ((L-same_required)*180/arb.pi(),(L-both_required)*180/arb.pi())
n_cell=4096
mins=[[],[]]
for j in range(n_cell):
    a=F(-1,500)+F(j,250*n_cell)
    b=a+F(1,250*n_cell)
    vals=bounds(g.upperbox(a,b))
    for k in range(2): mins[k].append(vals[k].lower())
def certified(t): return str(F(int((t.lower()*10**8).floor().unique_fmpz()),10**8))
o={"cells":n_cell,"degrees_lower_same_hand":certified(min(mins[0])),"degrees_lower_any_hands":certified(min(mins[1])),"minima":[str(min(z)) for z in mins]}
args.out.write_text(json.dumps(o,indent=2)+'\n');print(o)

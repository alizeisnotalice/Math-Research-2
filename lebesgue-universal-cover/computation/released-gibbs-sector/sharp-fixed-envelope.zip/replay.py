"""Endpoint-exact support of the old 1.54-degree convex G on the rotated EH cone."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json,sys
from flint import arb,ctx,__version__ as flint_version
ctx.prec=192
p=argparse.ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('out',type=Path);a=p.parse_args();comp=a.comp.resolve();sys.path.insert(0,str(comp))
for name,h in {'audit_optimized_eh_chord.py':'dd371b0545a1e1ceef3edefba692623b592a904d4c16d372b715f9ffa6ca9c64','certify_three_sigma_area_budget.py':'8b4713c11cb4ad5e22c5f8c85bbb5ee07191ef3cce7b1d120449ca737410562c'}.items():assert sha256((comp/name).read_bytes()).hexdigest()==h
import audit_optimized_eh_chord as g
import certify_three_sigma_area_budget as area
V=area.setup('1.54',g);U,T,C3,B3=[V[k] for k in ('U','T','C3','B3')];M=g.scale(arb(1)/2,g.plus(U,T));N=g.scale(-1/g.norm(g.minus(T,U)),g.rot(g.minus(T,U)));J=g.rot;dot=g.dot;cross=g.cross
ar=area.exact
rad=lambda v,x:g.plus(g.scale(x.cos(),v),g.scale(x.sin(),J(v)))
assert cross(N,g.minus(U,C3))<0 and cross(N,g.minus(T,B3))>0
min_der=None
for k in range(2048):
 lo=F(-2,1000)+F(k,512000);hi=F(-2,1000)+F(k+1,512000);theta=ar(lo).union(ar(hi));n=rad(N,theta);point,center=(U,C3) if hi<=0 else (T,B3);r=g.minus(point,center);v=cross(N,r)
 assert (v<0 if hi<=0 else v>0) and cross(n,r)/v>0
 H=dot(n,point)-ar(F(1,2));B=dot(n,M)-ar(F('.00094'))-ar(F(1,2));assert H>0 and B>0
 deriv=dot(J(n),M)*H-B*dot(J(n),point);assert deriv>0,(lo,hi,deriv)
 min_der=deriv.lower() if min_der is None else min(min_der,deriv.lower())
n=rad(N,ar(F('-.002')));ratio=(dot(n,M)-ar(F('.00094'))-ar(F(1,2)))/(dot(n,U)-ar(F(1,2)));target=F('.870266868900');assert ratio>ar(target)
out=dict(sigma_degrees='1.54',critical_alpha='-1/500',eta='47/50000',t=str(target),ratio=str(ratio),min_derivative_numerator=str(min_der),closed_intervals=2048,python=sys.version,flint=flint_version,scope='support-exact old G, uniform C(lambda,alpha,eta) box; no claim about intrinsic width-one ceiling')
a.out.write_text(json.dumps(out,indent=2)+'\n');print('PASS',out['ratio'])

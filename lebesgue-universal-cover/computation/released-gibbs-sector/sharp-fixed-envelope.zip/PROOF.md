# Exact old-EH normal-cone improvement

This is a strict improvement for the three-parameter family of `nov19-two-ear-global/PROOF.md` and `CURVATURE.md`. Let G be the old 1.54-degree convex universal Gibbs body in that source, and let U and T be the endpoints of its old EH boundary chord. Write M=(U+T)/2 and N=−J(T−U)/|T−U| for its outward normal. The two adjoining genuine circular arcs have centers C3 and B3 and unit outward radial normals r_U=U−C3 and r_T=T−B3. The old chord and the arcs are part of the convex boundary of G; therefore N, r_U, r_T are global outer supporting normals at the corresponding endpoints.

The exact coordinate reconstruction gives cross(N,r_U)<0<cross(N,r_T). For n(alpha)=R_alpha N, any alpha in [−.002,0] has n(alpha)=aN+b r_U with a,b≥0. The second coefficient has the sign of sin(alpha)/cross(N,r_U); the first is verified strictly positive on 1024 closed boxes. Consequently h_G(n)=n·U. For alpha in [0,.002], n(alpha) is similarly in cone(N,r_T), and h_G(n)=n·T. These are equal at alpha=0 because U,T lie on the chord. Unlike the previous bound obtained by intersecting the chord with n3 or m3, this is the actual support of G.

Let B(alpha)=n(alpha)·M−.00094−1/2 and H(alpha)=h_G(n(alpha))−1/2. Both are positive on the full domain. Every target in the three-parameter box retains the original G except its new EH halfplane and possibly expands its AH side; its EH allowance is at least n(alpha)·M−.00094. Thus `(1−t)D+tG` is inside the target if `t≤B(alpha)/H(alpha)`. `replay.py` checks, on 2048 rational closed alpha intervals in 192-bit Arb, positive normal-cone coefficients and the strict sign of `B' H−B H'`; the minimum is at alpha=−.002. At that endpoint

    B/H = [0.8702668689000610047556239386510473119401 +/- 4.33e−41]

so t=.870266868900 is strictly valid for the entire closed parameter box. The same rigid placement of an arbitrary width-one K within G then embeds `(1−t)D+tK`; translation is scaled by t, and the disk is invariant under orthogonal transformations. A width-one body with curvature density in [.064866565550,.935133434450] admits this decomposition by removing the disk part from its support function.

The ratio is sharp for **this outer model and this placement**: at the worst alpha and eta, U is an actual point of G, and above the displayed ratio the smoothed G itself crosses the EH halfplane. This is not a counterexample by a width-one K, and does not preclude a different placement or a better universal curvature theorem.

Reproduce with Python 3.13/python-flint 0.9:

    python -I -B replay.py /path/to/lebesgue-universal-cover/computation output.json

The program verifies the public geometry-source hashes and prints PASS. It assumes the cited published global convexity and universal placement of G and the target-family construction; it does not rerun those historical theorems.

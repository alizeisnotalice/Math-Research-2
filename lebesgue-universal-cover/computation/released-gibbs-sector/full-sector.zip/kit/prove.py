from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from vertices import *
entry=json.loads((D0/'polygon.json').read_bytes())
G,labels=grid();assert labels[-1]=='new';G.pop()
v=vectors()
# The two far points on the extremal supporting lines are dominated by the two disk support points.
assert dot(mul(A('.5'),n3),m3)>-3 and dot(mul(A('.5'),m3),n3)>-3
# As an upper closed region in direction inequalities, the transformed feasible region contains their negative orthants.
assert any(a>0 and b>0 for a,b in v)
zero=(A(0),A(0))
B=entry['denominator'];pp=entry['points'];ids=entry['G_triangles'];assert len(pp)==len(ids)
def intri(x,u,v):
    # True positive denominator and the three barycentric coefficients times this denominator.
    det=cross(u,v)
    if not det>0:return False
    a=cross(x,v);b=cross(u,x)
    return a>=0 and b>=0 and a+b<=det
nom=[]
for i,(p,(j,k)) in enumerate(zip(pp,ids,strict=True)):
    x=(A(F(p[0],B)),A(F(p[1],B)))
    if p[0]==0 and x[1]<0:
        # d1=(0,-1/sqrt(3)) is an exact named hex vertex.
        assert x[1]>-1/A(3).sqrt() and 'd1' in labels
    else:assert any(intri(x,G[jj%len(G)],G[kk%len(G)]) for jj in (j,j-1,k) for kk in (k,k+1,j)),('G',i,j,k)
    y=(dot(x,n3),dot(x,m3))
    assert any(intri(y,w,u) for w in v for u in v),('cone',i)
    nn=pp[(i+1)%len(pp)];nom.append(p[0]*nn[1]-p[1]*nn[0])
assert all(x>0 for x in nom)
# Exact ray order (the ray is y=0,x>0); hence the star-shaped polygon is traversed once.
assert not any(p[1]==0 for p in pp)
assert sum(p[1]<0<q[1] and p[0]>0 and q[0]>0 for p,q in zip(pp,pp[1:]+pp[:1]))==1
area=F(sum(nom),2*B*B);target=F('0.844082046521218581802948589770767704354')
assert area>target+F('.0000087')
registry={}
for i,sp in z['profiles'].items():
    body=bodies[i];registry[i]={'root':body.root_check(),'forced_pose_degrees':sp['turn'],'other_five_exclusions':body.exclude(sp['active'])}
out=dict(polygon_area=str(area),display=float(area),gap_above_B=str(area-target),vertices=len(pp),full_sector_normal_degrees=['180','211.54'],profiles=registry)
(D0/'sector-lower.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(pp),str(area),float(area),float(area-target),flush=True)

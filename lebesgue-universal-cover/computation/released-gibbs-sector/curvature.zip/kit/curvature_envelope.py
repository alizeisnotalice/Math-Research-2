"""Uniform Minkowski summand and absolute curvature band in every C(lambda,alpha,eta)."""
from pathlib import Path
import sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from candidate import *
def value(a,b):
    al=upperbox(a,b);n=rad(N,al)
    candidates=[u for u in [n3,m3] if (cross(N,u)>0 if a>=0 else cross(N,u)<0)]
    assert len(candidates)==1
    u=candidates[0];det=cross(N,u);gamma=al.sin()/det;ell=al.cos()-gamma*dot(N,u)
    assert ell>0 and (a>=0 or b<=0)
    # gamma is nonnegative by sign of sin(alpha) pointwise, including the closed endpoint 0.
    d=gamma*(A(F(1,2))-dot(u,M));old=dot(n,M)+d
    offset=dot(n,M)-A('.00094');base=A(F(1,2))
    assert old>offset>base and d.upper()>=0
    ratio=(offset-base)/(old-base)
    return ratio.lower(),[str(x) for x in [offset.lower(),old.upper(),ratio.lower()]]
rows=[]
for k in range(1024):
    a=F(-2,1000)+F(k,256000);b=F(-2,1000)+F(k+1,256000)
    r,vals=value(a,b);rows.append(dict(angle=[str(a),str(b)],values=vals))
r=min(arb(g['values'][2]).lower() for g in rows);s=(r*10**7).floor().unique_fmpz();t=F(int(s),10**7)
assert 0<t<1 and all(arb(i['values'][2])>A(t) for i in rows)
ans=dict(minkowski_original_fraction=str(t),disk_fraction=str(1-t),curvature_lower=str((1-t)/2),curvature_upper=str((1+t)/2),rational_lower_dec=str(float(t)),cells=1024,rows=rows)
(D/'curvature-band.json').write_text(json.dumps(ans,indent=2)+'\n')
print(t,float(t),float((1-t)/2),float((1+t)/2),flush=True)
def local(a,b):
    n=rad(N,upperbox(a,b));det=cross(n3,m3)
    c1=cross(n,m3)/det;c2=cross(n3,n)/det;assert c1>0 and c2>0
    L=c1+c2-A(1);assert L>0
    eta=A('.00094');offset=dot(n,M)-eta
    rhs=(A(F(1,2))*(c1+c2)-offset)/L
    return rhs.upper(),[str(v) for v in [L.lower(),offset.lower(),rhs.upper()]]
localrows=[]
for k in range(1024):
    a=F(-2,1000)+F(k,256000);b=F(-2,1000)+F(k+1,256000)
    _,v=local(a,b);localrows.append(dict(angle=[str(a),str(b)],values=v))
val=max(arb(o['values'][2]).upper() for o in localrows);m=F(int((val*10**7).ceil().unique_fmpz()),10**7)
assert 0<m<F(1,2) and all(arb(o['values'][2])<A(m) for o in localrows)
(D/'local-curvature.json').write_text(json.dumps(dict(local_threshold=str(m),cells=1024,rows=localrows),indent=2)+'\n')
print('local curvature lower',m,float(m),flush=True)
arc_length=A(F('31.54'))*arb.pi()/180
masses=[]
for k in range(1024):
    a=F(-2,1000)+F(k,256000);b=F(-2,1000)+F(k+1,256000);n=rad(N,upperbox(a,b))
    dg=cross(n3,m3);s1=cross(n3,n);s2=cross(n,m3);peak_=s1*s2/dg
    diff=A(F(1,2))*(s1+s2)/dg-dot(n,M)+A('.00094');assert diff>0
    demand=(2*diff/(peak_*arc_length)).sqrt()
    masses.append(str(demand.upper()))
q=F(int((max(arb(s).upper() for s in masses)*10**7).ceil().unique_fmpz()),10**7)
assert q<F(1,2) and all(arb(s)<A(q) for s in masses)
(D/'curvature-mass.json').write_text(json.dumps(dict(interval_degrees='31.54',average_radius_threshold=str(q),cells=1024,rows=masses),indent=2)+'\n')
print('local mean lower',float(q),'minimum curvature mass',float(A(q)*arc_length))

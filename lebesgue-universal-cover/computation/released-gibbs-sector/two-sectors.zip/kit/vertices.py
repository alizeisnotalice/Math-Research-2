from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0));sys.path.insert(0,str(D0.parent))
from strict_profiles import *
from inner_grid import grid
z=json.loads((D0/'strict-seeds.json').read_text())
bodies={i:Body(sp) for i,sp in z['profiles'].items()}
def vectors(k):
    norms=[(n3,m3),(av(dt["n"][5]),av(dt["m"][5]))][k]
    rows=[(A(-3),A(-3)),(A(F(1,2)),A(-3)),(A(-3),A(F(1,2)))]
    for i,ang in z['sectors'][k]:
        th=F(str(ang));s,c=sc(A(th))
        v=(c/2,s/2) if i<0 else bodies[str(i)].point(th)
        rows.append((dot(v,norms[0]),dot(v,norms[1])))
    return rows
if __name__=='__main__':
    points,labels=grid();assert labels[-1]=='new';points.pop()
    (D0/'point-scout.json').write_text(json.dumps(dict(transformed=[[[float(t) for t in p] for p in vectors(k)] for k in [0,1]],G=[[float(t) for t in v] for v in points],normals=[[[float(t) for t in n] for n in (n3,m3)],[[float(t) for t in n] for n in (av(dt['n'][5]),av(dt['m'][5]))]]))+'\n')

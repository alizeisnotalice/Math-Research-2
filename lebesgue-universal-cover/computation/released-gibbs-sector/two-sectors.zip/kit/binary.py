from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from strict_profiles import *
sr=json.loads((D0/'strict-seeds.json').read_bytes());reg=json.loads((D0/'sector-lower.json').read_bytes())
a=arb.pi()/1440;h_error=a*a/2;dh_error=a;report={}
for key,spec in sr['profiles'].items():
    b=Body(spec);row=reg['profiles'][key];small=min(arb(v).lower() for v in row['other_five_exclusions'])
    assert small>h_error and arb(row['root'][0])+3*dh_error<0 and arb(row['root'][1])+3*h_error<0
    status=[];fractional=0
    for f in b.q:
        rho=f+A('.5')
        if rho==0:status.append(0)
        elif rho==1:status.append(1)
        else:
            assert rho>0 and rho<1
            half=(rho*(a/2).sin()).asin()
            assert half>0 and half<a/2
            # The integral of exp(iq) over the centered binary arc and the original subcell agree exactly.
            for m in range(8):status.extend([0,1,0])
            fractional+=1
    right=list(reversed(status))
    ring=status+[1-t for t in right]+[1-t for t in status]+right
    arcs=sum(ring[j] and not ring[j-1] for j in range(len(ring)))
    assert arcs%2==1
    report[key]=dict(binary_unit_arcs=arcs,nonbinary_one_degree_cells=fractional,strict_exclusion_after_conversion=str((small-h_error).lower()))
for st in sr['sectors']:
    for i,t in st:
        if i<0:continue
        q=F(str(t))-F(sr['profiles'][str(i)]['turn'])-30
        assert (8*q).denominator==1
out=dict(subcell_degrees='1/8',uniform_support_error=str(h_error.upper()),uniform_derivative_error=str(dh_error.upper()),profiles=report)
(D0/'binary.json').write_text(json.dumps(out,indent=2)+'\n')
print([(i,r['binary_unit_arcs']) for i,r in report.items()])

"""Diameter needed to preserve two original material marks in a single pose."""
import hashlib,json,sys
from pathlib import Path
from itertools import combinations
from fractions import Fraction as F
import numpy as np
from flint import arb,ctx
ctx.prec=192
path,out=map(Path,sys.argv[1:]);assert hashlib.sha256(path.read_bytes()).hexdigest() in {'0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d','fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c'}
z=np.load(path,allow_pickle=False);Q=2**28;G=F(120696470013529293,2**57)
p=z['points'][0,:z['counts'][0],:];norm=lambda a,b:sum((int(x)-int(y))**2 for x,y in zip(a,b))
d,i,j=max((norm(a,b),i,j) for (i,a),(j,b) in combinations(enumerate(p),2));r=arb(d).sqrt()/Q
ch=dict(row=0,body='disk',labels=[i,j],points=p[[i,j]].tolist(),denominator=Q,diameter_squared=str(F(d,Q*Q)),diameter=r.str(60),maximum_G_divided_by_scale_squared=str(G/F(d,Q*Q)),area_ceiling=(arb(G.numerator)/G.denominator/(arb(d)/(Q*Q))).str(60))
out.write_text(json.dumps(ch,indent=2)+'\n');print(ch['points'],r,ch['area_ceiling'])

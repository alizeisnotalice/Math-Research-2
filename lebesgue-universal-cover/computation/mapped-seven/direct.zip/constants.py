"""Prove the origin-centered inner copy, cap denominators and the full auxiliary chord comparison."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import numpy as np
from flint import arb,ctx
ctx.prec=256
def ar(x):
    q=F(x)
    return arb(q.numerator)/q.denominator
core,bank,out=map(Path,sys.argv[1:])
boxes=np.load(core)
assert boxes.shape==(5442,2,11)
s=F('.999999051');sc=F('.999999006');j=F('.999998915');floor_scale=F('.99999891')
ec=1-sc;M=F('.033');r=F('.422');G=F(120696470013529293,2**57);B=F(120666927296517964,2**57)
centers=[]
for i,n in enumerate([3,5,7,9]):
    C2=max(sum(max(abs(F(float(box[z,k]))) for z in (0,1))**2 for k in [3*i,3*i+1]) for box in boxes)
    R=1/(2*(arb.pi()/(2*n)).cos())
    assert C2<M*M and 1-R>ar(r) and R+ar(M)<ar('.62')
    centers.append(dict(n=n,center_sq=str(C2),support_upper=(R+ar(C2).sqrt()).str(45)))
inner=(sc-j)*r-(1-j)*M
assert inner>0
U=2**22;Q=2**28
norm_max=F(U+2,U)
# A guaranteed original chord has lower depth f>=floor(Q/5000)/Q in raw (v/U) coordinates.
fmin=F(Q//5000,Q)
offset=((sc-j)*F('.62')+ec*M)*norm_max
length_factor=j/norm_max**2
chord=length_factor* fmin/(j*fmin+offset)-F(1023,1024)
assert length_factor>F(1023,1024) and chord>0
denom=sc*F(1,2*(U-2))-ec*(M+F(1,60))
assert denom>0 and F(1,4000)<F(1,60)**2
radius=ar(sc/2);z=ar('.706')
assert (arb.pi()-(radius/z).acos())*radius**2+radius*(z*z-radius**2).sqrt()>ar(G)
assert 2*(sc/2)**2>F('.706')**2 and F('.8373034')*j*j>B
floor=(2**57*B*floor_scale**2).__floor__()
assert F(floor,2**57)<j*j*B
assert F(2,5*(U+1))>F(3*U,Q*(U-1))
info=dict(sc=str(sc),s=str(s),j=str(j),center_nsq=centers,epsilon_c=str(ec),inner_slack=str(inner),offset_upper=str(offset),chord_spare=str(chord),cap_denominator_spare=str(denom),floor=floor,area_rational=str(G/s**2),area_decimal=ar(G/s**2).str(63))
out.write_text(json.dumps(info,indent=2)+'\n')

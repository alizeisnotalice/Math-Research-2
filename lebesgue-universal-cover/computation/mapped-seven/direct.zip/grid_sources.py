from pathlib import Path
import hashlib,io,zipfile,json,sys
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=160;c,interfaces,bank,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(c.resolve()))
from certify_finite_point_leaf import upper_q
U=2**22;Q=2**28;ds=json.loads(bank.read_bytes())['directions'];assert len(ds)==256
radii=[]
for x,y in ds:
    rho=(arb(x*x+y*y)/(U*U)).sqrt();D=upper_q(rho/2);assert 0<D-rho*Q/2<3;radii.append(D)
source={}
def walk(z):
    for n in z.namelist():
        if n.endswith('.zip'):walk(zipfile.ZipFile(io.BytesIO(z.read(n))))
        if not n.endswith('.py'):continue
        code=z.read(n)
        if b'from support_grid import' not in code or b'disk=' not in code:continue
        assert b'from certify_finite_point_leaf import upper_q' in code and b'disk=ints([upper_q(length/2) for _,_,length in vectors])' in code
        source[hashlib.sha256(code).hexdigest()]=Path(n).name
for n,zsha in json.loads(interfaces.read_bytes())['archives'].items():
    f=c/n;assert hashlib.sha256(f.read_bytes()).hexdigest()==zsha
    with zipfile.ZipFile(f) as z:walk(z)
assert {'run_nine.py','run_shared.py','run_native.py','run_slice.py','run_curved.py','run_fronts.py'}<=set(source.values())
out.write_text(json.dumps(dict(direction_count=len(ds),per_direction_disk_integers=radii,loaders=sorted(source.items())),indent=2)+'\n')

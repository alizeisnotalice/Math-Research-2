"""Fingerprint R269's predecessor kernels and reconstruct their real cap-denominator interface."""
from pathlib import Path
import ast,hashlib,io,json,sys,zipfile
c,d=map(Path,sys.argv[1:]);d.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
base=(c/'tomar_six_083730_guard.cpp').read_bytes()
assert sha(base)=='42a4ee583d22940b3cd0b05f04285ba7e3d351745de707476211dce4efba5f81'
B=b'B=up_signed(W(b)*U,(U-2)*(Q/C))'
def has_interface(b):
    assert b.count(B)==1 and b.count(b'up_signed(W(d)*(U+2),U)')==1
    assert b'W(4)*sum*sum-C2' in b and b'up_signed(e*C2,Scale)' in b
has_interface(base)
archives=['global-083750/stage4-upgrade.zip','global-083750/terminal-dispatch-083750.zip','whole-leaves-083750-second/wave2.zip','whole-leaves-083750-second/additional-eleven.zip','lower-083750-refinement/wave3.zip','rosters-083750/wave4.zip','rosters-083750/physical-and-mac.zip','physical-nine-47/r5.zip','physical-nine-47/r5-97.zip','physical-nine-47/r6.zip','physical-nine-47/r6b.zip','physical-nine-47/r6c.zip','eight-083750/r6d.zip','eight-083750/r6e.zip','scaled-eight-50/seven-mac45.zip','scaled-eight-50/seven66.zip']
all_kernels={};generators={};wrappers={};sources={}
def inspect(path,b):
    name=path.split('/')[-1]
    if name=='replay_angle_mesh.py':
        h=sha(b)
        if h in generators:return
        f=next(n for n in ast.parse(b).body if isinstance(n,ast.FunctionDef) and n.name=='generate_source')
        ns={};exec(compile(ast.Module(body=[f],type_ignores=[]),name,'exec'),ns)
        out=d/h;out.mkdir(exist_ok=True);ns['generate_source'](out,base)
        code=(out/'angle_mesh_dynamic.hpp').read_bytes();has_interface(code)
        generators[h]=[name,sha(code)];return
    if name.endswith(('.cpp','.hpp')):
        if b'W(4)*sum*sum-C2' in b or B in b:
            has_interface(b);all_kernels[sha(b)]=name
        elif b'#include "angle_mesh_dynamic.hpp"' in b:
            wrappers[sha(b)]=name
def walk(z):
    for n in z.namelist():
        if n.endswith('.zip'):walk(zipfile.ZipFile(io.BytesIO(z.read(n))))
        elif n.endswith(('.cpp','.hpp','replay_angle_mesh.py')):inspect(n,z.read(n))
for n in archives:
    p=c/n;sources[n]=sha(p.read_bytes())
    with zipfile.ZipFile(p) as z:walk(z)
for sub in ('three-leaf-083750/replay_angle_mesh.py','three-leaf-083750/angle_mesh_leaf_guard.cpp','finite_point_leaf_guard.cpp','tomar_six_high_guard.cpp'):
    inspect(sub,(c/sub).read_bytes())
assert set(all_kernels.values())=={'cap_joint.cpp','curved.cpp','ordinary-control.cpp','disk-chord-control.cpp','nine.cpp','shared.cpp','slice.cpp','finite_point_leaf_guard.cpp','tomar_six_high_guard.cpp'}
assert len(generators)>=4 and wrappers
out=dict(archives=sources,direct_kernel=sorted(all_kernels.items()),generated_from=sha(base),generated=sorted(generators.items()),wrappers=sorted(wrappers.items()))
(d/'source-interface.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(sources),'source archives,',len(all_kernels),'direct kernel versions,',len(generators),'regenerated drivers')

"""Materialize and directly check the finite physical rational witness above 67/80."""
import argparse, gzip, hashlib, json
from fractions import Fraction as F
from math import lcm
from pathlib import Path
from flint import arb,ctx
ctx.prec=176
def ar(q):
    q=F(q);return arb(q.numerator)/q.denominator
def sub(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(p):
    p=sorted(set(p))
    def half(ps):
        z=[]
        for a in ps:
            while len(z)>=2 and sub(z[-2],z[-1],a)<=0:z.pop()
            z.append(a)
        return z
    return half(p)[:-1]+half(reversed(p))[:-1]
def diam(p):
    h=hull(p);n=len(h);assert n>=3
    def dist(a,b):return (a[0]-b[0])**2+(a[1]-b[1])**2
    out=0;j=1
    for i in range(n):
        k=(i+1)%n
        def area(t):return sub(h[i],h[k],h[t%n])
        while area(j+1)>area(j):j=(j+1)%n
        for t in (j,(j+1)%n):
            out=max(out,dist(h[i],h[t]),dist(h[k],h[t]))
    return n,out
def read(p):return json.loads(p.read_bytes())
def main():
    pa=argparse.ArgumentParser();pa.add_argument('fixed',type=Path);pa.add_argument('output',type=Path);pa.add_argument('--N',type=int,default=1931);a=pa.parse_args()
    assert a.N%2==1 and a.N>=128
    a.output.mkdir(exist_ok=True)
    N=a.N;pi=arb.pi();M=10**20;S=1-F(1,10**16);delta=F(3,M)
    s=F('.999999051');sc=F('.999999006');G=F(120696470013529293,2**57)/sc**2
    alpha=F(int(((ar(S)*(pi/N).cos()/(pi/(2*N)).cos()-ar(2*delta))*10**36).lower().floor().unique_fmpz()),10**36)
    assert alpha*s < sc and G*alpha**2>F(67,80) and S+2*delta<1
    def point(x,y):
        coords=[]
        for q in (x,y):
            b=ar(S)*q*M;v=int(b.mid().floor().unique_fmpz());assert abs(b-v)<2
            coords.append(v)
        return tuple(coords)
    clouds=[];receipt=[]
    def add(label,d,ps):
        ps=list(dict.fromkeys(ps));nh,d2=diam(ps);assert d2<d*d and len(ps)<=N
        clouds.append(dict(body=label,denominator=d,points=ps))
        receipt.append(dict(body=label,n=len(ps),extreme=nh,diameter_sq=str(F(d2,d*d))))
    for n in [0,3,5,7,9]:
        p=[]
        if n==0:
            R=1/(2*(pi/(2*N)).cos())
            for k in range(N):
                si,co=(2*pi*k/N).sin_cos();p.append(point(R*co,R*si))
        else:
            m=(N-n)//n;R=1/(2*(pi/(2*n)).cos())
            assert n*(m+1)<=N and 1-R>ar(F(2,5))
            sag=F(22,7)**2/(8*n*n*m*m)
            assert S-(S*sag+delta)*F(5,2)>alpha
            for j in range(n):
                si,co=(2*pi*j/n).sin_cos()
                for k in range(m+1):
                    v,u=(pi*ar(F(2*j,n)+1-F(1,2*n)+F(k,n*m))).sin_cos()
                    p.append(point(R*co+u,R*si+v))
        add(n,M,p)
    for name,cloud in read(a.fixed).items():
        d=cloud['denominator']*s.numerator
        ps=[(x*s.denominator,y*s.denominator) for x,y in cloud['points']]
        add(name,d,ps)
    raw=(json.dumps(clouds,separators=(',',':'))+'\n').encode()
    (a.output/'finite-points.json.gz').write_bytes(gzip.compress(raw,compresslevel=7,mtime=0))
    out=dict(N=N,precision=ctx.prec,s=str(s),curve_scale=str(sc),normalized_common_factor=str(alpha*s/sc),curve_rounding_error=str(delta),curve_shrink=str(S),inner_factor=str(alpha),area_lower=str(G*alpha**2),area_interval=(ar(G*alpha**2)).str(55),groups=receipt,uncompressed_sha256=hashlib.sha256(raw).hexdigest())
    (a.output/'finite-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
    print([(x['body'],x['n']) for x in receipt],out['area_interval'],flush=True)
if __name__=='__main__':main()

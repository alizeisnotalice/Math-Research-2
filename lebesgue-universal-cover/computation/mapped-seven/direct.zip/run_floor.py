from pathlib import Path
import sys
src,dest=map(Path,sys.argv[1:]);old=src.read_text();needle="floor=(M*F('.9999999')**2*2*Z*Z).__floor__()"
assert old.count(needle)==1
dest.write_text(old.replace(needle,"floor=(120666927296517964*F('.99999891')**2).__floor__()"))

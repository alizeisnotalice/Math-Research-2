# 带圆周角重参数化的七输入与有限有理见证

一般下端 .83750161135232518242021341604593845。有限下端 \(\Lambda_{1931}>.83750000237479121099227199376697413\)。

输入为第272轮首七体包 physical-seven-flex50.zip（SHA256 d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666）、主仓 computation、Tomar 原树 cert11d_08366、table64.npz 和共享 Clang 缓存。指定一个尚不存在的输出目录。

~~~sh
python -B replay.py "$FIRST_ZIP" "$COMP" "$TREE" "$TABLE64" "$CLANG_CACHE" "$NEW_OUTPUT" --workers 4
~~~

默认重新生成第269轮物理七体的四张实际支撑表、重建5442个原叶、核准五种角行及两云所有点对和每种手性的分段角映射，编译内核并从零遍历501例外根。若已有本包地板120666664242759821的501行原生完整输出，可加 --reuse-roots 已完成的结果.jsonl。finite.py points.json 有限点输出目录 可单独重新生成七组归一后的有理坐标。证明见 PROOF.md。

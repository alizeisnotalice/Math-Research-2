"""Reproduce directed normalization of seven inputs at s=.999999038 on R269's seven66 selection."""
import argparse,gzip,hashlib,importlib.util,json,shutil,subprocess,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def run(xs):subprocess.run(list(map(str,xs)),check=True)
def main():
    ap=argparse.ArgumentParser()
    for k in ['first','comp','tree','table','cache','out']:ap.add_argument(k,type=Path)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--reuse-roots',type=Path,help='Already computed JSONL for the more conservative 501-root dichotomy at .99999891')
    a=ap.parse_args();c=a.comp.resolve();w=a.out.resolve();w.mkdir(exist_ok=False);p=[sys.executable,'-B']
    assert sha(a.first.read_bytes())=='d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666'
    base=w/'first'
    with zipfile.ZipFile(a.first) as z:z.extractall(base)
    spec=importlib.util.spec_from_file_location('seven_flex_replay',base/'replay.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    old=w/'old'
    old.mkdir()
    loc=c/'five-global-localization.json';assert sha(loc.read_bytes())=='d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504'
    keys={(int(g),z) for g,qs in read(loc)['retained'].items() for z in qs}
    assert len(keys)==501
    s7=c/'scaled-eight-50/seven66.zip';selected=gzip.decompress(mod.member(s7,'selection66.json.gz'));assert sha(selected)=='bd436b81be2391d4fbd75fba547e3f6076baa8dc2f2edb7513ba62f5de5e189f'
    ang=old/'angular-66.json';ang.write_bytes(gzip.decompress((base/'angular-66.json.gz').read_bytes()))
    assert sha(ang.read_bytes())=='b0d3e4d6b3dc065a59c3a2de48256399813d8cb599f1cb3393d631dbdbe38181'
    x=old/'expanded-input.json';x.write_bytes(mod.member(c/'seven-083746.zip','native/inputs/q11-expanded-angles.json'))
    run(p+[base/'legacy.py',c,c/'scaled-eight-50/p66.json',old/'pleg.json'])
    run(p+[base/'q_legacy.py',c,c/'q11-leaf-bank.json',x,old])
    v=read(c/'multi-host-points.json');(old/'q.json').write_text(json.dumps(dict(points=v['points'],denominator=v['point_denominator'])))

    j=json.loads(mod.member(s7,'join66.json'));assert j['complete'] and j['core']==5442 and j['perimeter']==6704872
    sel=json.loads(selected);assert len(sel)==5442 and all(not t[2] for t in sel.values() if t[1]=='ordinary-Qavg')
    oldr4=json.loads(gzip.decompress(mod.member(c/'rosters-083750/wave4.zip','physical-bank.json.gz')))
    full=read(ang);assert full['directions']==oldr4['directions'] and [[r[:8] for r in cell] for cell in full['cells'][384:768]]==oldr4['cells'][384:768]
    assert sha((c/'scaled-eight-50/p66.json').read_bytes())=='92aca7f3c93ab146de3b4cdd60565773eb11ca38ed272e7e101cd38868334ceb'
    run(p+[HERE/'source_interface.py',c,w/'kernels']);assert (w/'kernels/source-interface.json').read_bytes()==(HERE/'source-interface.json').read_bytes()
    run(p+[HERE/'grid_sources.py',c,w/'kernels/source-interface.json',ang,w/'grid-sources.json']);assert (w/'grid-sources.json').read_bytes()==(HERE/'grid-sources.json').read_bytes()
    core=w/'core.npy';run(p+[HERE/'core.py',c,a.tree.resolve(),s7,core])
    run(p+[HERE/'constants.py',core,ang,w/'constants.json']);assert (w/'constants.json').read_bytes()==(HERE/'constants.json').read_bytes()
    run(p+[HERE/'material_floor.py',a.table.resolve(),w/'material-floor.json']);assert (w/'material-floor.json').read_bytes()==(HERE/'material-floor.json').read_bytes()
    run(p+[HERE/'chords.py',c,w/'kernels/source-interface.json',w/'chords.json']);assert (w/'chords.json').read_bytes()==(HERE/'chords.json').read_bytes()
    for name,bname,skeep in [('P','pleg',False),('Q','q-standard',True),('Qexp','q-expanded',True),('grid','angular-66',False)]:
        dest=w/('walls-'+name+'.json');run(p+[HERE/'exact.py',core,old/(bname+'.json'),dest]+([s7] if skeep else []))
        expected=read(HERE/'wall-sums.json')[name];actual=read(dest);assert sha(dest.read_bytes())==expected and actual['min']>actual['scale']*.47
    yy={}
    for tag,kind,bank,group,wall in [('strongP962','P','angular-66','P','grid'),('nativeP962','legacy','pleg','P','P'),('strongQ962','Q','angular-66','Q','grid'),('nativeQ962','Qlegacy','q-standard','Q','Q'),('expandedQ962','Qlegacy','q-expanded','Q','Qexp')]:
        src=c/'scaled-eight-50/p66.json' if group=='P' else old/'q.json'
        dest=w/(tag+'.json');run(p+[HERE/'verify.py',old/(bank+'.json'),src,HERE/(group+'962.json'),dest,'--kind',kind,'--m','.5','--eps','.000000962','--wall-eps','.000000994','--comp',c]+(['--walls',w/('walls-'+wall+'.json')] if wall else []))
        v=read(dest);assert v['rows_ok'] and v['diameter_ok'] and dest.read_bytes()==(HERE/(tag+'.json')).read_bytes()
        label='P66' if group=='P' else 'physicalQ';cloud=dict(denominator=v['denominator'],points=v['physical_points']);assert yy.get(label,cloud)==cloud;yy[label]=cloud
    fixed=w/'points.json';fixed.write_text(json.dumps(yy,separators=(',',':'))+'\n');assert fixed.read_bytes()==(HERE/'points.json').read_bytes()
    run(p+[HERE/'finite.py',fixed,w/'finite']);assert (w/'finite/finite-receipt.json').read_bytes()==(HERE/'finite-receipt.json').read_bytes()
    if a.reuse_roots:
        roots=a.reuse_roots
    else:
        kit=w/'kit.zip';kit.write_bytes(mod.member(c/'physical-nine-47/r6.zip','nine-replay-kit.zip'));assert sha(kit.read_bytes())=='19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467'
        build=w/'build_dichotomy.py';build.write_bytes(mod.member(c/'scaled-eight-50/scale.zip','build_dichotomy.py'));assert sha(build.read_bytes())=='a5128c9116af0060385fdf60b8b9920524770885c3bd2ad9accad8f37c483ce4'
        ref=w/'ref';run(p+[build,kit,ref]);kernel=w/'native';run(p+[base/'baseline.py',ref,ang,kernel])
        driver=kernel/'run_floor995.py';run(p+[HERE/'run_floor.py',kernel/'run_nine.py',driver]);lib=kernel/'kernel.so'
        run([shutil.which('clang++'),'-O3','-std=c++17','-fsanitize=signed-integer-overflow','-fsanitize-undefined-trap-on-error','-fPIC','-shared',f'-fmodules-cache-path={a.cache.resolve()}','-I',c/'three-leaf-083750',kernel/'nine.cpp','-o',lib])
        keyfile=w/'keys.json';keyfile.write_text(json.dumps(read(loc)['retained'])+'\n')
        roots=w/'roots.jsonl';run(p+[driver,c,a.tree.resolve(),a.table.resolve(),lib,kernel/'bank.json',roots,'--index',keyfile,'--target','.83750','--caps','--mesh','--workers',a.workers,'--cap',2000000])
    assert mod.summarize(roots,keys)==read(HERE/'rootsj-receipt.json')
    print('s=.999999038; all five point tables, source interfaces, finite groups, and 501-root dichotomy verified')
if __name__=='__main__':main()

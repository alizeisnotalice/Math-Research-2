"""Certified lower bounds for the contraction of a balanced triple's three walls on the same root."""
from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
import sys,json,io,gzip,zipfile
import numpy as np
ctx.prec=160
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
def lo(x):return int(x.lower().floor().unique_fmpz())
def hi(x):return int(x.upper().ceil().unique_fmpz())
core,bank,out=map(Path,sys.argv[1:4]);bound=F('.000000994');X=np.load(core);B=np.transpose(X,(1,0,2));c=json.loads(bank.read_bytes());v=c['directions'];FINE=2**27;UNIT=2**25;N=len(v);J=len(X);PI=arb.pi()
def h(z,n,R,T):
    z=z- z.mid().floor().unique_fmpz();d=abs(z).min(abs(1-z)).min(abs(z+1))
    a=R*(T*d).cos();b=1-R*(T*(ar(F(1,2))-d)).cos()
    if d<ar(F(1,4)):return a
    if d>ar(F(1,4)):return b
    return a.union(b)
scope='all'
if len(sys.argv)==5:
    with zipfile.ZipFile(Path(sys.argv[4])) as zf: data=gzip.decompress(zf.read('seven66-joined/selection66.json.gz'))
    from hashlib import sha256
    assert sha256(data).hexdigest()=='bd436b81be2391d4fbd75fba547e3f6076baa8dc2f2edb7513ba62f5de5e189f'
    sel=json.loads(data);ordered=sorted(sel,key=lambda k:tuple(map(int,k.split('/'))))
    idx=np.array(['physical_old_Q11' in sel[k][2] for k in ordered]);assert idx.sum()==1638
    X=X[idx];B=np.transpose(X,(1,0,2));J=len(X);scope='R269 physical Q roots'
U=[];phi=[]
for x,y in v:
    leng=arb(x*x+y*y).sqrt();assert 2**22-1<leng<2**22+2
    U.append([lo(UNIT*x/leng),lo(UNIT*y/leng)])
    phi.append(arb.atan2(arb(y),arb(x)))
U=np.asarray(U,np.int64);upos=np.maximum(U,0);uneg=np.minimum(U,0)
H=np.full((J,N),FINE//2,np.int64);parts=[]
for i,n in enumerate((3,5,7,9)):
    T=2*PI/n;R=1/(2*(PI/(2*n)).cos());rn=FINE*R
    Ang=np.zeros((J,2)) if i==0 else X[:,:,3*i-1]
    pairs,idx=np.unique(Ang,axis=0,return_inverse=True)
    dirs0=[[None]*N for _ in pairs];dirs1=[[None]*N for _ in pairs]
    for j,f in enumerate(phi):
        ent={}
        for val in np.unique(pairs):
            z=(f-ar(F(float(val))))/T;val1=h(z,n,R,T)*FINE
            ent[val]=(z,lo(val1),hi(val1))
        for a,(left,right) in enumerate(pairs):
            zj,l1,h1=ent[left];zi,l2,h2=ent[right]
            has_min=int((zj+ar(F(1,2))).upper().floor().unique_fmpz())>=int((zi+ar(F(1,2))).lower().ceil().unique_fmpz())
            has_max=int(zj.upper().floor().unique_fmpz())>=int(zi.lower().ceil().unique_fmpz())
            dirs0[a][j]=min(l1,l2,lo(FINE-rn) if has_min else FINE)
            dirs1[a][j]=max(h1,h2,hi(rn) if has_max else 0)
    kmin=np.asarray(dirs0,dtype=np.int64)[idx,:];kmax=np.asarray(dirs1,dtype=np.int64)[idx,:]
    cen=B[:,:,3*i:3*i+2];assert np.max(np.abs(cen))<.2
    c0=np.floor(cen[0]*FINE).astype(np.int64);c1=np.ceil(cen[1]*FINE).astype(np.int64)
    # Rounding both direction coordinates down by <1/UNIT costs at most 2*.2/UNIT; use 3 ticks.
    cl=(c0@upos.T+c1@uneg.T)//UNIT-3;ch=-((-c1@upos.T-c0@uneg.T)//UNIT)+3
    H=np.maximum(H,cl+kmin);parts.append((kmin,kmax,ch))
def div_ep(lo):
    return lo*bound.denominator//bound.numerator
# h_new=max_i c_i.u + sc h_i. The candidate body can be eliminated or paid for with its own center and centered support.
# H is a lower bound for ideal h_C. Each abstract upper wall over h_C has the same improvement.
g=FINE//2+div_ep(H-FINE//2)
strong=any(len(row)==10 for cell in c['cells'] for row in cell)
# The polygon source pad (0.4/(U+1)) exceeds the largest mesh disk rounding (3/(Q rho)).
pad=((F(2,5*(2**22+1))-F(3*2**22,(2**28)*(2**22-1)))*FINE/bound).__floor__() if strong else 0
for kmin,kmax,ch in parts:
    loss0=H-ch
    # floor of (H-h_i^upper-c_i^upper)/epsilon may be negative.
    loss1=kmin+div_ep(H-ch-kmax)
    g=np.minimum(g,np.maximum.reduce([loss0,kmin+pad,loss1]))
assert 25*int(g.min())>11*FINE and g.max()<3*FINE
# Each unique triple has shared physical directions and positive integer weights.
# Index the at most three distinct direction slopes before large rational weights are multiplied.
memo={};rows=[]
for cell in c['cells']:
    vals=[]
    for r in cell:
        key=tuple(r[:7])
        if key not in memo:
            ids=np.array(r[:3]);wt=np.array(r[3:6])/r[6]
            # Floating argmins propose a lower integer; verify *all* roots by integer arithmetic.
            vv=g[:,ids];approx=int(np.min(vv@wt))-2
            threshold=(vv.astype(object)@np.array(r[3:6],dtype=object)).min()//r[6]
            assert approx<=threshold
            memo[key]=int(threshold)
        vals.append(memo[key])
    rows.append(vals)
out.write_text(json.dumps(dict(scale=FINE,wall_model='physical centers unchanged',root_count=J,rows=rows,scope=scope,min=min(memo.values())),separators=(',',':'))+'\n');print(len(memo),'unique rows; minimum',min(memo.values())/FINE)

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
from audit_bins import audit
D=Path(__file__).resolve().parent;ctx.prec=128
j=int(sys.argv[1]);base=audit(j);assert base is not None and base['bad'];raw=json.loads((D/f'j{j}.json').read_text());rec=json.loads((D/f'j{j}-repair.json').read_text());cfg=json.loads((D/f'j{j}-repair-config.json').read_text());assert rec['complete'] and rec['all_passed'] and rec['parameters']==cfg and rec['geometry_sha256']==raw['geometry_sha256'] and rec['physical_parameters']==raw['physical_parameters'] and rec['EH_tightening']==raw['EH_tightening']
for name,expected in rec['source_hashes'].items():
 p=D/name if (D/name).is_file() else D/'comp012'/name;assert sha256(p.read_bytes()).hexdigest()==expected,name
bad=[t for t in raw['rows'] if not all(arb(t['row'][z])>0 for z in ('root_margin_lower','placement_margin_lower'))];assert all(t['orientation']==0 and t['angle_class']==1 and t['counts']==[1,4] for t in bad)
parents=[t['row']['subcells'] for t in bad];children=[t['row']['subcells'] for t in rec['rows']];assert [i for l,r in parents for i in range(l,r)]==[i for l,r in children for i in range(l,r)];assert all(any(a<=l<r<=b for a,b in parents) for l,r in children)
assert all(t['bin']==j and t['orientation']==0 and t['angle_class']==1 and t['counts']==[1,4] and all(arb(t['row'][z])>0 for z in ('root_margin_lower','placement_margin_lower')) and t['row']['placed_leaves']==sum(t['row']['pose_counts'].values()) for t in rec['rows'])
mins={z:str(min([arb(t['row'][z]).lower() for t in raw['rows'] if t not in bad]+[arb(t['row'][z]).lower() for t in rec['rows']])) for z in ('root_margin_lower','placement_margin_lower')}
sha=lambda p:sha256(p.read_bytes()).hexdigest();out={'j':j,'complete_join':True,'base_sha256':sha(D/f'j{j}.json'),'replacement_sha256':sha(D/f'j{j}-repair.json'),'parent_blocks':parents,'child_blocks':children,'physical_cells':75,'minima':mins,'explanation':'each child lies inside one original failed count-class block; other original count classes and original synchronized pose bounds retained'};(D/f'j{j}-joined-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

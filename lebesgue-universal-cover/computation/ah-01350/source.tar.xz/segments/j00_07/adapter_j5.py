from pathlib import Path
from hashlib import sha256
from flint import arb
import json,sys,subprocess,tempfile,shutil
P=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();assert not O.is_relative_to(P)
with tempfile.TemporaryDirectory(prefix='j5-',dir=O.parent) as tmp:
 D=Path(tmp)/'source';shutil.copytree(P,D,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));subprocess.run([sys.executable,'-B',str(D/'audit_j5_join.py')],cwd=D,stdout=subprocess.DEVNULL,check=True);assert (D/'j5-joined-audit.json').read_bytes()==(P/'j5-joined-audit.json').read_bytes();a=json.loads((D/'j5-joined-audit.json').read_bytes())
assert a['complete_join'] and a['bin']==5 and a['physical_cells']==75 and a['tree_leaf_count']==140 and a['replacement_parent_blocks']==[[j,j+15] for j in range(0,75,15)] and all(arb(v)>0 for v in a['minima'].values());ph=sha256((P/'physical-0135.json').read_bytes()).hexdigest();assert ph=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8';out={'complete':True,'all_passed':True,'geometry_sha256':a['geometry_sha256'],'physical_sha256':ph,'bins':[5],'physical_cells':75,'base_sha256':a['base_sha256'],'tree_sha256':a['tree_sha256'],'scope':'only the five failed j5 (1,4) parent classes replaced by their exhaustive closed contact/deficit trees'};O.write_text(json.dumps(out,indent=2)+'\n')

from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,subprocess,sys
from flint import arb,ctx
from audit_bins import audit
ctx.prec=128;D=Path(__file__).resolve().parent;P=D/'j5-transfer/j5-scout';bn=int(sys.argv[1]);assert bn in (4,6,7);base=audit(bn);assert base and base['bad']
raw=json.loads((D/f'j{bn}.json').read_text());bad=[t for t in raw['rows'] if not all(arb(t['row'][z])>0 for z in ('root_margin_lower','placement_margin_lower'))];assert bad and all(t['orientation']==0 and t['angle_class']==1 and t['counts']==[1,4] for t in bad);starts=[t['row']['subcells'][0] for t in bad];assert len(set(starts))==len(starts) and all(j in range(0,75,15) for j in starts) and [t['row']['subcells'] for t in bad]==[[j,j+15] for j in starts]
reports=[]
for j in starts:
 receipt=P/f'j{bn}-tree-{j}.json';output=P/f'j{bn}-audit-tree-{j}.json';subprocess.run([sys.executable,'-I','-B',str(P/'audit_other_tree.py'),str(receipt),str(output),str(bn)],check=True,stdout=subprocess.DEVNULL);r=json.loads(output.read_text());assert r['complete'] and r['physical_block']==[j,j+15];reports.append(r)
mins={z:str(min([arb(t['row'][z]).lower() for t in raw['rows'] if t not in bad]+[arb(r['min_root' if z=='root_margin_lower' else 'min_pose']).lower() for r in reports])) for z in ('root_margin_lower','placement_margin_lower')};sha=lambda p:sha256(p.read_bytes()).hexdigest()
out={'complete_join':True,'bin':bn,'geometry_sha256':raw['geometry_sha256'],'base_sha256':sha(D/f'j{bn}.json'),'physical_cells':75,'retained_original_rows':len(raw['rows'])-len(bad),'replacement_parent_blocks':[r['physical_block'] for r in reports],'tree_sha256':[r['raw_sha256'] for r in reports],'tree_leaf_count':sum(r['leaf_count'] for r in reports),'empty_conditionals':sum(r['empty_conditions'] for r in reports),'minima':mins,'scope':'only original failed count (1,4), label0 high-side parents replaced; all other classes retained'};(D/f'j{bn}-joined-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

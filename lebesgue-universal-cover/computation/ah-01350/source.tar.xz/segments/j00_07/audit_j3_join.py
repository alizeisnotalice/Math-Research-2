from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
from flint import arb,ctx
from audit_bins import audit
D=Path(__file__).resolve().parent;P=D/'j5-transfer/j5-scout';ctx.prec=128
sha=lambda p:sha256(p.read_bytes()).hexdigest();base=audit(3);assert base and base['bad'];raw=json.loads((D/'j3.json').read_text());rec=json.loads((D/'j3-repair.json').read_text());cfg=json.loads((D/'j3-repair-config.json').read_text());assert rec['complete'] and rec['parameters']==cfg and rec['geometry_sha256']==raw['geometry_sha256'] and rec['physical_parameters']==raw['physical_parameters'] and rec['EH_tightening']==raw['EH_tightening']
for name,h in rec['source_hashes'].items():
 p=D/name if (D/name).is_file() else D/'comp012'/name;assert sha(p)==h,name
bad=[t for t in raw['rows'] if not all(arb(t['row'][z])>0 for z in ('root_margin_lower','placement_margin_lower'))];assert all(t['orientation']==0 and t['angle_class']==1 and t['counts']==[1,4] for t in bad);parents=[t['row']['subcells'] for t in bad];assert parents==[[j,j+5] for j in range(0,75,5)]
children=[t['row']['subcells'] for t in rec['rows']];assert [i for l,r in children for i in range(l,r)]==list(range(75));assert all(any(a<=l<r<=b for a,b in parents) for l,r in children)
assert all(t['bin']==3 and t['orientation']==0 and t['angle_class']==1 and t['counts']==[1,4] for t in rec['rows'])
retained=[t for t in rec['rows'] if t['row']['subcells'][1]<=50];assert [i for t in retained for i in range(*t['row']['subcells'])]==list(range(50));assert all(all(arb(t['row'][z])>0 for z in ('root_margin_lower','placement_margin_lower')) and t['row']['placed_leaves']==sum(t['row']['pose_counts'].values()) for t in retained)
reports=[]
for j in range(50,75,5):
 f=P/f'j3-tree-{j}.json';o=P/f'j3-audit-tree-{j}.json';subprocess.run([sys.executable,'-I','-B',str(P/'audit_j3_tree.py'),str(f),str(o),'3'],check=True,stdout=subprocess.DEVNULL);r=json.loads(o.read_text());assert r['physical_block']==[j,j+5];reports.append(r)
mins={z:str(min([arb(t['row'][z]).lower() for t in raw['rows'] if t not in bad]+[arb(t['row'][z]).lower() for t in retained]+[arb(r['min_root' if z=='root_margin_lower' else 'min_pose']).lower() for r in reports])) for z in ('root_margin_lower','placement_margin_lower')}
out={'complete_join':True,'bin':3,'geometry_sha256':raw['geometry_sha256'],'base_sha256':sha(D/'j3.json'),'replacement_sha256':sha(D/'j3-repair.json'),'parent_blocks':parents,'retained_child_blocks':[t['row']['subcells'] for t in retained],'replacement_parent_blocks':[r['physical_block'] for r in reports],'tree_sha256':[r['raw_sha256'] for r in reports],'tree_leaf_count':sum(r['leaf_count'] for r in reports),'empty_conditionals':sum(r['empty_conditions'] for r in reports),'physical_cells':75,'minima':mins};(D/'j3-joined-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

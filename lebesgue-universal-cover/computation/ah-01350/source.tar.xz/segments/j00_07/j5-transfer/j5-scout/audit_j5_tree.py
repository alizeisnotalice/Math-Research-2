"""Check the exact nested contact and deficit cover for a j5 parent patch."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from flint import arb,ctx
import sys,json
ctx.prec=128;P=Path(__file__).resolve().parent;C=P.parent/'comp';raw=Path(sys.argv[1]);d=json.loads(raw.read_bytes());assert d['complete'] and d['all_passed'] and d['bin']==5 and d['orientation']==0 and d['angle_class']==1 and d['parent_counts']==[1,4] and d['EH_retreat']=='593/6250000000' and d['geometry_sha256']=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189';assert d['physical']==json.loads((P/'physical-0135.json').read_bytes())
for name,h in d['sources'].items():
 f=P/name if (P/name).exists() else C/name;assert sha256(f.read_bytes()).hexdigest()==h,name
lo,hi=d['physical_block'];assert lo in (0,15,30,45,60) and hi==lo+15
leaves=[]
def key(t):return tuple(t['counts']),*map(F,t['e'])
def walk(t):
 counts,a,b=key(t);assert sum(counts)==5 and 0<=a<b<=1
 if 'children' in t:
  children=t['children'];split=t['split']
  if split=='contacts':wanted={(sum(parts,()),a,b) for parts in product(*[[(i,c-i) for i in range(c+1)] for c in counts])}
  elif split=='e4':wanted={(counts,a+(b-a)*F(i,4),a+(b-a)*F(i+1,4)) for i in range(4)}
  else:raise AssertionError(split)
  assert len(children)==len(wanted) and {key(x) for x in children}==wanted
  for child in children:walk(child)
 else:
  assert t.get('passed') and 'failed' not in t;r=t['row'];assert r['reference_bin']==5 and r['subcells']==[lo,hi] and F(r['anchor_degrees'])==23 and r['anchor_comparison_sign']==1 and F(r['anchor_threshold'])==-F(1,50000)
  assert arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0 and sum(r['pose_counts'].values())==r['placed_leaves']
  assert r['empty_conditional_subcells'] in (0,1) and (r['empty_conditional_subcells'] or r['placed_leaves']+r['root_free_leaves']>0);leaves.append(r)
parent=d['tree'];assert key(parent)==((1,4),F(0),F(1));walk(parent);assert len(leaves)==d['leaves_passed'] and d['leaves_failed']==0 and sum(r['empty_conditional_subcells'] for r in leaves)==d['empty_conditions']
out={'complete':True,'all_passed':True,'geometry_sha256':d['geometry_sha256'],'physical_block':[lo,hi],'leaf_count':len(leaves),'empty_conditions':d['empty_conditions'],'raw_sha256':sha256(raw.read_bytes()).hexdigest(),'min_root':str(min(arb(r['root_margin_lower']).lower() for r in leaves)),'min_pose':str(min(arb(r['placement_margin_lower']).lower() for r in leaves))};Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

"""Synchronized closed contact/deficit tree for one j5 high-side (1,4) parent."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import argparse,sys,json,inspect
from flint import arb
P=Path(__file__).resolve().parent;C=P.parent/'comp';sys.path[:0]=[str(P),str(C)]
from certify_sigma_extended_graph import geometry
from certify_ah_affine_root_class import validate
from ordered_state import support_bound
q=argparse.ArgumentParser();q.add_argument('bin',type=int);q.add_argument('begin',type=int);q.add_argument('out',type=Path);args=q.parse_args();j=args.bin;assert j in (4,6,7);a=args.begin;b=a+15;assert a in (0,15,30,45,60)
cfg=json.loads((P/'physical-0135.json').read_bytes());pivot,turn=map(F,cfg['line']);far,negative,eps=map(F,cfg['physical_parameters']);ns,src,_=geometry(C,[(pivot,turn)],sigma=cfg['sigma_degrees'],far=far,negative=negative,eps=eps);G=sha256(src.encode()).hexdigest();assert G=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189';ns['_sharpen_jets']=True;ns['_tighten_first']=True;ns['_first_orientation']=0;ns['_end_index']=b
idx,=[i for i,(lab,u,h) in enumerate(ns['rows']) if lab.startswith('U1-Te')];lab,u,h=ns['rows'][idx];ns['rows'][idx]=lab,u,h-ns['A'](F(593,6250000000));source=inspect.getsource(validate);needle='a=r0+i*step;b=a+step';assert source.count(needle)==1;source=source.replace(needle,'a=r0+i*step;b=r0+ns["_end_index"]*step');needle='        for k in range(angular):visit(';assert source.count(needle)==1;source=source.replace(needle,'        if rm<=0:continue\n'+needle);env={**validate.__globals__,'support_bound':support_bound};exec(compile(source,'closed_parent_fast_reject','exec'),env)
trials=[(F(l),F(r)) for l,r in [('36','46'),('33','46'),('30','46'),('27','46'),('23','46')]]
def visit(counts,lo,hi,stage):
 ns['_class_counts']=counts;ns['_e_class']=(lo,hi);node={'counts':list(counts),'e':[str(lo),str(hi)]};best=None
 for left,right in trials:
  row=env['validate'](ns,j,left,right,180,1,1,begin=a,end=a+1,angular=12,depth=4,anchor=F(23),threshold=F('.00002'),condition_sign=1);score=min(arb(row[k]) for k in ('root_margin_lower','placement_margin_lower'))
  if best is None or score>best[0]:best=(score,row)
  if score>0:
   row['subcells']=[a,b];node['row']=row;node['passed']=True;print(a,b,counts,str(lo),str(hi),'PASS',row['bracket'],flush=True);return node
 if stage==0:
  choices=[[(i,c-i) for i in range(c+1)] for c in counts];children=[(sum(v,()),lo,hi) for v in product(*choices)];node['split']='contacts'
 elif stage==1:
  children=[(counts,lo+(hi-lo)*F(i,4),lo+(hi-lo)*F(i+1,4)) for i in range(4)];node['split']='e4'
 elif stage==2:
  choices=[[(i,c-i) for i in range(c+1)] for c in counts];children=[(sum(v,()),lo,hi) for v in product(*choices)];node['split']='contacts'
 else:
  best[1]['subcells']=[a,b];node['failed']=best[1];print(a,b,counts,str(lo),str(hi),'UNRESOLVED',best[1]['root_margin_lower'],flush=True);return node
 node['children']=[visit(c,l,r,stage+1) for c,l,r in children];return node
# Build the complete parent by quartering the two halves. Children are disjoint in interiors, closed at boundaries.
parent={'counts':[1,4],'e':['0','1'],'split':'contacts','children':[visit((i,1-i,k,4-k),F(0),F(1),0) for i in (0,1) for k in range(5)]}
def stats(t):
 if 'children' in t:
  st=[stats(x) for x in t['children']];return tuple(map(sum,zip(*st)))
 return (int('row'in t),int('failed'in t),int(t.get('row',{}).get('empty_conditional_subcells',0)))
ok,bad,empty=stats(parent);files=[Path(__file__),P/'ordered_state.py',P/'sharp_first_hit.py',P/'physical-0135.json',C/'certify_sigma_extended_graph.py',C/'certify_sigma_pinned_fan.py',C/'certify_ah_affine_root_class.py']
result={'complete':True,'all_passed':bad==0,'physical':cfg,'geometry_sha256':G,'bin':j,'orientation':0,'angle_class':1,'parent_counts':[1,4],'physical_block':[a,b],'EH_retreat':'593/6250000000','levels':'quarter contact→eighth contact→e-quarter→sixteenth contact if needed','sources':{f.name:sha256(f.read_bytes()).hexdigest() for f in files},'leaves_passed':ok,'leaves_failed':bad,'empty_conditions':empty,'tree':parent};args.out.write_text(json.dumps(result,indent=1)+'\n');print('FINAL',a,b,ok,bad,empty,flush=True)

from pathlib import Path
from hashlib import sha256
from flint import arb
import json,sys,subprocess,tempfile,shutil
P=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();assert not O.is_relative_to(P)
with tempfile.TemporaryDirectory(prefix='j2-',dir=O.parent) as t:
 D=Path(t)/'source';shutil.copytree(P,D,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));subprocess.run([sys.executable,'-B',str(D/'audit_repair.py'),'2'],cwd=D,stdout=subprocess.DEVNULL,check=True);assert (D/'j2-joined-audit.json').read_bytes()==(P/'j2-joined-audit.json').read_bytes();a=json.loads((D/'j2-joined-audit.json').read_bytes())
assert a['complete_join'] and a['physical_cells']==75 and all(arb(x)>0 for x in a['minima'].values());ph=sha256((P/'physical-0135.json').read_bytes()).hexdigest();assert ph=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8';out={'complete':True,'all_passed':True,'geometry_sha256':'d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189','physical_sha256':ph,'bins':[2],'physical_cells':75,'base_sha256':a['base_sha256'],'patch_sha256':a['replacement_sha256'],'scope':'only j2; exact failed father blocks replaced by same-class closed children'};O.write_text(json.dumps(out,indent=2)+'\n')

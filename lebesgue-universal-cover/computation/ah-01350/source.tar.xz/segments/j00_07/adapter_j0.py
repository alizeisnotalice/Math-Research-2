from pathlib import Path
from hashlib import sha256
from flint import arb,ctx
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from audit_bins import audit
ctx.prec=128;aa=[audit(j) for j in (0,1)];assert all(a==json.loads((P/f'j{j}-audit.json').read_bytes()) and not a['bad'] and a['physical_cells']==75 and arb(a['root_lower'])>0 and arb(a['placement_lower'])>0 for j,a in enumerate(aa))
q=sha256((P/'physical-0135.json').read_bytes()).hexdigest();assert q=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8';out={'complete':True,'all_passed':True,'geometry_sha256':'d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189','physical_sha256':q,'bins':[0,1],'physical_cells':150,'raw_sha256':[a['sha256'] for a in aa],'scope':'only j0–1; no claim for j2–7'};Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')

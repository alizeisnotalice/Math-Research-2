from pathlib import Path
from hashlib import sha256
from flint import arb
import json,subprocess,sys,tempfile
P=Path(__file__).resolve().parent;S=P/'front10';O=Path(sys.argv[1]).resolve();assert not O.is_relative_to(S)
manifest=json.loads((S/'manifest.json').read_bytes())
for n,h in manifest.items():assert sha256((S/n).read_bytes()).hexdigest()==h,n
with tempfile.TemporaryDirectory(prefix='j16-25-',dir=O.parent) as d:
 target=Path(d)/'summary.json';subprocess.run([sys.executable,'-I','-B',str(S/'audit_front10.py'),str(target)],cwd=S,stdout=subprocess.DEVNULL,check=True);assert target.read_bytes()==(S/'summary.json').read_bytes();r=json.loads(target.read_bytes())
assert set(map(int,r))==set(range(16,26))
for x in r.values():assert x['physical_cells']==75 and arb(x['root_lower'])>0 and arb(x['pose_lower'])>0
ph=sha256((S/'physical-0135.json').read_bytes()).hexdigest();assert ph=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8'
graph=json.loads((S/'geometry-area.json').read_bytes())['chart']['geometry_sha256'];assert graph=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'
out={'complete':True,'all_passed':True,'geometry_sha256':graph,'physical_sha256':ph,'bins':list(range(16,26)),'physical_cells':750,'summary_sha256':sha256((S/'summary.json').read_bytes()).hexdigest(),'scope':'j16–25 only; all orientation, derivative and nested closed contact/deficit classes.'};O.write_text(json.dumps(out,indent=2)+'\n')

"""Certify both initial derivative branches on synchronized physical cells and closed contact trees."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
comp=D/'comp012';sys.path[:0]=[str(D),str(comp)]
from flint import arb
from ordered_fast import validate
from certify_sigma_extended_graph import geometry
from certify_sigma_reachable_roots import reach
p=ArgumentParser();p.add_argument('j',type=int);p.add_argument('output',type=Path);args=p.parse_args()
j=args.j;assert 16<=j<=25
cfg=json.loads((D/'physical-0135.json').read_bytes())
pars=dict(zip(('far','negative','eps'),map(Q,cfg['physical_parameters']),strict=True))
n,src,_=geometry(comp,[tuple(map(Q,cfg['line']))],sigma='1.54',**pars)
n['_sharpen_jets']=True;n['_tighten_first']=True
i,=[k for k,(label,_,_) in enumerate(n['rows']) if label.startswith('U1-Te')]
label,normal,offset=n['rows'][i];retreat=Q('.00000009488')
n['rows'][i]=label,normal,offset-n['A'](retreat);assert reach(n,j)==[(0,75)]
def contact_children(counts):
    options=[[(q,v-q) for q in range(v+1)] for v in counts]
    return [sum(parts,()) for parts in product(*options)]
def attempt(counts,lo,hi,ori,side,a,b,quick=False):
    n['_first_orientation']=ori;n['_end_index']=b
    n['_class_counts']=counts;n['_e_class']=lo,hi
    if j<24:
        if side<0:
            brackets=[('.72','8'),('.5','8'),('.5','7.2'),('.5','6.4')]
        else:
            brackets=[('8','21'),('8','18'),('7','21'),('6.25','18'),('7','18')]
    else:
        if side<0:
            brackets=[('.5','6.2'),('.5','6.4'),('.5','6.7'),('.5','7'),('.5','8'),('.72','8')]
        else:
            brackets=[('6.25','18'),('7','18'),('8','21'),('6.6','18'),('7.5','18'),('8','18')]
    pose=(0,1) if side<0 else (120,-1)
    if quick:brackets=brackets[:1]
    for l,h in brackets:
        r=validate(n,j,Q(l),Q(h),*pose,side,cut=Q('-.012'),side=side,begin=a,end=a+1,angular=12,depth=4)
        r['subcells']=[a,b]
        if all(arb(r[k])>0 for k in ('root_margin_lower','placement_margin_lower')):return True,r
    return False,r
def solve(counts,lo,hi,ori,side,a,b):
    ok,r=attempt(counts,lo,hi,ori,side,a,b)
    tree=dict(counts=list(counts),e=[str(lo),str(hi)])
    if ok:tree['row']=r;return tree
    if hi-lo==1:
        tree['split']='four-deficits'
        subs=[(counts,Q(k,4),Q(k+1,4)) for k in range(4)]
    elif len(counts)<64 and max(counts)==5:
        tree['split']='contacts'
        subs=[(child,lo,hi) for child in contact_children(counts)]
    elif hi-lo>Q(1,16):
        tree['split']='two-deficits';mid=(lo+hi)/2
        subs=[(counts,lo,mid),(counts,mid,hi)]
    elif len(counts)<8:
        tree['split']='contacts'
        subs=[(child,lo,hi) for child in contact_children(counts)]
    else:tree['failed']=r;return tree
    tree['children']=[solve(cs,l,h,ori,side,a,b) for cs,l,h in subs]
    return tree
def totals(tree):
    if 'children' in tree:
        siblings=[totals(c) for c in tree['children']]
        return tuple(map(sum,zip(*siblings,strict=True)))
    return (int('row' in tree),int('failed' in tree))
def physical(ori,side,a,b):
    if b-a>5:
        roots=[]
        for k in range(6):
            cs=(k,5-k)
            ok,row=attempt(cs,Q(0),Q(1),ori,side,a,b,True)
            if not ok:
                return [sub for u in range(a,b,5) for sub in physical(ori,side,u,u+5)]
            roots.append(dict(counts=list(cs),e=['0','1'],row=row))
    else:
        roots=[solve((k,5-k),Q(0),Q(1),ori,side,a,b) for k in range(6)]
    print(j,ori,side,a,b,tuple(map(sum,zip(*(totals(t) for t in roots),strict=True))),flush=True)
    return [dict(orientation=ori,side=side,block=[a,b],trees=roots)]
rows=[]
for ori in (0,1):
 for side in (-1,1):
  step=15 if j<24 else 5
  for a in range(0,75,step):
    rows.extend(physical(ori,side,a,a+step))
sources=[D/k for k in ['certify_front10.py','ordered_fast.py','ordered_derivative.py','ordered_state.py','sharp_first_hit.py','physical-0135.json']]
data=dict(bin=j,physical=cfg,geometry_sha256=sha256(src.encode()).hexdigest(),derivative_cut=str(Q('-.012')),EH_retreat=str(retreat),sources={f.name:sha256(f.read_bytes()).hexdigest() for f in sources},rows=rows)
args.output.write_text(json.dumps(data,indent=1)+'\n')

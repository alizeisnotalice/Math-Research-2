"""Verify the contact/deficit tree leaves form a full closed cover on each fixed physical block."""
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse,json
from flint import arb,ctx
ctx.prec=128
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def expected_children(t,counts,lo,hi):
    if t['split']=='contacts':
        children=product(*[[(r,c-r) for r in range(c+1)] for c in counts])
        return {(sum(c,()),lo,hi) for c in children}
    n={'two-deficits':2,'four-deficits':4}[t['split']]
    return {(counts,lo+(hi-lo)*k/n,lo+(hi-lo)*(k+1)/n) for k in range(n)}
def identity(t):return (tuple(t['counts']),*map(Q,t['e']))
def check(j,ori,side,a,b,tree):
    counts,lo,hi=identity(tree);assert sum(counts)==5 and 0<=lo<hi<=1
    if 'children' in tree:
        children=tree['children'];want=expected_children(tree,counts,lo,hi)
        assert len(children)==len(want) and {identity(c) for c in children}==want
        return [r for c in children for r in check(j,ori,side,a,b,c)]
    assert 'failed' not in tree and 'row' in tree,(j,ori,side,a,b,counts,lo,hi)
    r=tree['row'];assert r['reference_bin']==j and r['subcells']==[a,b]
    assert Q(r['anchor_degrees'])==0 and Q(r['anchor_threshold'])==Q(3,250) and r['anchor_comparison_sign']==side
    assert arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0
    assert r['placed_leaves']==sum(r['pose_counts'].values())
    if r['root_free_leaves']:assert arb(r['sign_separation_lower'])>0
    assert r['placed_leaves'] or r['root_free_leaves'] or r['empty_conditional_subcells']
    return [r]
def audit(j):
    p=D/f'result-{j}.json';q=read(p);assert q['bin']==j
    assert q['physical']==read(D/'physical-0135.json')
    assert q['geometry_sha256']=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'
    assert all(sha256((D/k).read_bytes()).hexdigest()==h for k,h in q['sources'].items())
    assert Q(q['derivative_cut'])==-Q(3,250) and Q(q['EH_retreat'])==Q(593,6250000000)
    branches=q['rows']
    for o in (0,1):
        for side in (-1,1):
            parts=[g['block'] for g in branches if g['orientation']==o and g['side']==side]
            assert all(b-a in (5,15) and a%5==0 for a,b in parts)
            assert [i for a,b in parts for i in range(a,b)]==list(range(75))
    assert all(g['orientation'] in (0,1) and g['side'] in (-1,1) for g in branches)
    rows=[]
    for g in branches:
        ori,side=g['orientation'],g['side'];a,b=g['block']
        trees=g['trees'];assert len(trees)==6 and {identity(t) for t in trees}=={((k,5-k),Q(0),Q(1)) for k in range(6)}
        rows.extend(r for t in trees for r in check(j,ori,side,a,b,t))
    return dict(physical_cells=75,rows=len(rows),placed=sum(r['placed_leaves'] for r in rows),root_free=sum(r['root_free_leaves'] for r in rows),empty=sum(r['empty_conditional_subcells'] for r in rows),root_lower=str(min(arb(r['root_margin_lower']).lower() for r in rows)),pose_lower=str(min(arb(r['placement_margin_lower']).lower() for r in rows)),sha256=sha256(p.read_bytes()).hexdigest())
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('bins',nargs='*',type=int,default=list(range(16,26)));args=p.parse_args()
summary={j:audit(j) for j in args.bins}
args.out.write_text(json.dumps(summary,indent=2)+'\n')

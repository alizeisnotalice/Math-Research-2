"""Check each closed physical partition, refined ordered-contact cover and common-pose leaf."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
ctx.prec=128
dp=Path(__file__).resolve().parent
def read(name):return json.loads((dp/name).read_bytes())
def digest(name):return hashlib.sha256((dp/name).read_bytes()).hexdigest()
physical=read('physical-0135.json')
graph='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'
def plan(j,orientation,side):
    classes={((k,5-k),F(0),F(1)) for k in range(6)}
    if (orientation,side)!=(0,-1):return classes
    classes.remove(((5,0),F(0),F(1)))
    if j==26:
        levels=[(4,5,0,1),(8,5,0,1),(16,5,0,1),(32,6,0,1)]
    else:
        classes.update(((5,0),F(k,4),F(k+1,4)) for k in range(3))
        classes.update(((5,0,0,0,0,0,0,0),F(k,16),F(k+1,16)) for k in range(12,15))
        levels=[(4,5,F(3,4),1),(8,5,F(3,4),1),(16,5,F(15,16),1),(32,6,F(15,16),1)]
    for size,num,lo,hi in levels:
        classes.update(((k,5-k)+(0,)*(size-2),F(lo),F(hi)) for k in range(num))
    return classes
def rowcheck(r):
    assert r['placed_leaves']==sum(r['pose_counts'].values())
    return all(arb(r[k])>0 for k in ('root_margin_lower','placement_margin_lower'))
def audit(j):
    name=f'whole-{j}.json';d=read(name)
    assert d['complete'] and d['tighten_first'] and d['synchronized']
    assert d['physical_parameters']==physical and d['geometry_sha256']==graph
    assert d['reachable']=={str(j):[[0,75]]}
    assert d['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'}
    assert d['parameters']==read(f'whole-{j}-config.json')
    assert F(d['parameters']['cut'])==-F(3,250)
    assert all(digest(k if (dp/k).exists() else 'comp012/'+k)==h for k,h in d['source_hashes'].items())
    checked=[];fail=[];allrows=d['rows']
    for ori in (0,1):
        for side in (-1,1):
            blocks=d['partitions'][f'{j},{ori},{side}']
            assert blocks==[[a,a+5] for a in range(0,75,5)]
            for a,b in blocks:
                rows=[q for q in allrows if q['orientation']==ori and q['initial_derivative_sign']==side and q['row']['subcells']==[a,b]]
                ids=[(tuple(q['counts']),*map(F,q['e_class'])) for q in rows]
                assert len(ids)==len(set(ids)) and set(ids)==plan(j,ori,side)
                for q in rows:
                    r=q['row'];assert r['reference_bin']==q['bin']==j
                    assert r['anchor_comparison_sign']==side and F(r['anchor_degrees'])==0 and F(r['anchor_threshold'])==F(3,250)
                    assert q['positive']==rowcheck(r)
                    if q['positive']:checked.append(r)
                    else:fail.append(q)
    if j==26 and fail:
        assert len(fail)==1
        q=fail[0]
        assert q['orientation']==0 and q['initial_derivative_sign']==-1 and q['counts']==[5]+[0]*31 and list(map(F,q['e_class']))==[0,1] and q['row']['subcells']==[70,75]
        extra=read('deep64-last-26.json')
        assert extra['geometry_sha256']==graph and extra['physical']==physical and extra['physical_indices']==[70,75]
        assert extra['orientation']==0 and extra['derivative_branch']==-1 and F(extra['derivative_cut'])==-F(3,250) and F(extra['EH_retreat'])==F(593,6250000000)
        assert extra['sha256']==digest('deep64_last.py')
        parent=extra['tree'];assert parent['counts']==q['counts'] and parent['e']==['0','1'] and parent['split']=='contacts'
        kids=parent['children'];assert len(kids)==6
        assert {tuple(u['counts']) for u in kids}=={(k,5-k)+(0,)*62 for k in range(6)}
        for u in kids:
            r=u['row'];assert u['positive'] and u['e']==['0','1'] and r['reference_bin']==26 and r['subcells']==[70,75] and rowcheck(r)
            assert r['anchor_comparison_sign']==-1 and F(r['anchor_degrees'])==0 and F(r['anchor_threshold'])==F(3,250)
            checked.append(r)
    else:assert not fail
    return dict(bin=j,physical_cells=75,source=digest(name),supplemental_rows=6 if fail else 0,rows=len(checked),placed_leaves=sum(r['placed_leaves'] for r in checked),root_free_leaves=sum(r['root_free_leaves'] for r in checked),empty=sum(r['empty_conditional_subcells'] for r in checked),root_lower=str(min(arb(r['root_margin_lower']).lower() for r in checked)),pose_lower=str(min(arb(r['placement_margin_lower']).lower() for r in checked)))
ap=argparse.ArgumentParser();ap.add_argument('out',type=Path);ap.add_argument('bins',type=int,nargs='*',default=[26,31]);args=ap.parse_args()
area=read('geometry-area.json');assert area['chart']['geometry_sha256']==graph and area['parameters']==physical
res={j:audit(j) for j in args.bins}
args.out.write_text(json.dumps(dict(geometry_sha256=graph,bins=res),indent=2)+'\n')

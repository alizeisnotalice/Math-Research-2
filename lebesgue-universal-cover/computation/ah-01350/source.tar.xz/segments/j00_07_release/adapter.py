from pathlib import Path
from hashlib import sha256
import json,subprocess,sys,tempfile
P=Path(__file__).resolve().parent; R=P/'upper-01350-j0-7'; O=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix='early-',dir=O.parent) as t:
 d=Path(t)/'check'; subprocess.run([sys.executable,'-I','-B',str(R/'verify_joined.py'),str(d)],check=True,stdout=subprocess.DEVNULL);a=json.loads((d/'audit.json').read_bytes());assert a['complete'] and set(a['bins'])==set(map(str,range(8)))
ph=sha256((R/'physical-0135.json').read_bytes()).hexdigest();assert ph=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8'
out={'complete':True,'all_passed':True,'geometry_sha256':a['geometry_sha256'],'physical_sha256':ph,'bins':list(range(8)),'physical_cells':600,'scope':'all eight early bins, all first labels and closed classified replacements'};O.write_text(json.dumps(out,indent=2)+'\n')

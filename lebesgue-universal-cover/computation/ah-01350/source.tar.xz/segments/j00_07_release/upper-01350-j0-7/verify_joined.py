"""Audit all j0--7 joins in a scratch copy; --full also recomputes every used interval receipt."""
from pathlib import Path
import argparse, json, os, shutil, subprocess, sys
p=argparse.ArgumentParser();p.add_argument('scratch',type=Path);p.add_argument('--full',action='store_true');p.add_argument('--bins',default='0,1,2,3,4,5,6,7');a=p.parse_args();bins=sorted({int(x) for x in a.bins.split(',')});assert bins and all(j in range(8) for j in bins)
D=Path(__file__).resolve().parent;S=a.scratch.resolve();assert not S.exists();S.mkdir(parents=True);W=S/'package';shutil.copytree(D,W,ignore=shutil.ignore_patterns('__pycache__','*.log'))
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def call(cmd,cwd=W):subprocess.run([sys.executable,'-E','-B',*map(str,cmd)],cwd=cwd,env=env,check=True,stdout=subprocess.DEVNULL)
sys.path.insert(0,str(W));from audit_bins import audit
for j in bins:
 if j in (0,1):
  r=audit(j);assert r and not r['bad']
 elif j==2:call([W/'audit_repair.py',j])
 elif j==3:call([W/'audit_j3_join.py'])
 elif j==5:call([W/'audit_j5_join.py'])
 else:call([W/'audit_other_join.py',j])
geom=json.loads((W/'geometry-area.json').read_text());assert geom['chart']['geometry_sha256']=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'
if a.full:
 def same(cmd,expected,out,cwd=W):
  call([*cmd,out],cwd);assert out.read_bytes()==expected.read_bytes(),(expected,out)
 for j in bins:same([W/'certify_early_sharp.py',W/'comp012',W/f'config-{j}.json'],W/f'j{j}.json',S/f'original-{j}.json')
 for j in (j for j in bins if j in (2,3)):same([W/'certify_early_retry.py',W/'comp012',W/f'j{j}-repair-config.json'],W/f'j{j}-repair.json',S/f'repair-{j}.json')
 P=W/'j5-transfer/j5-scout'
 for j in (j for j in bins if j in (3,4,5,6,7)):
  raw=json.loads((W/f'j{j}-joined-audit.json').read_text())
  for begin,end in raw['replacement_parent_blocks']:
   name=f'tree-{begin}.json' if j==5 else f'j{j}-tree-{begin}.json';src=P/name;data=json.loads(src.read_text());source=next(x for x in data['sources'] if x.startswith('certify_') and x.endswith('tree.py'))
   args=[P/source,begin] if j==5 else [P/source,j,begin]
   same(args,src,S/f'tree-{j}-{begin}.json',P)
out={'complete':True,'full_replay':a.full,'geometry_sha256':geom['chart']['geometry_sha256'],'bins':{str(j):json.loads((W/f'j{j}-joined-audit.json').read_text()) if j>1 else audit(j) for j in bins}}
(S/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print('Bins structurally audited:',bins,'full replay:',a.full)

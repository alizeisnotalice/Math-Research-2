# AH 0.01350: bins j0–7

This package covers 75 closed physical cells per bin, both labels, all original ordered-contact classes and the full permitted deficit, using the fixed physical graph SHA-256 `d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189`. In each replacement a strict root and one common feasible placement are proved, or the conditioned class is rigorously empty. The old original rows remain in the ledger; only the identified failed parent classes are replaced. In j3, the first 50 cells use passing children of the physical refinement; the last 25 cells use five 5-cell trees. The complete refinement receipt records failures in those last cells and is intentionally retained as the original calculation ledger. The retained EH retreat is `593/6250000000`.

Run with Python 3.13.18 and python-flint 0.9.0. A new scratch directory is required:

```
python -E -B verify_joined.py SCRATCH
python -E -B verify_joined.py SCRATCH_FULL --full
```

The first command copies the bundle into scratch, checks source hashes and re-audits all parent/child joins. The second additionally recomputes all eight original interval receipts, the j2 and j3 replacement receipts, and every replacement tree actually used by j4–j7; outputs must match byte for byte. Full replay is deliberately sequential and can take substantial CPU time. Pass e.g. `--bins 0,1,2` to replay or audit a subset; separate scratch directories allow separate processes. The underlying area/geometry and the remaining reference bins require separate project certificates; this bundle asserts only j0–7.

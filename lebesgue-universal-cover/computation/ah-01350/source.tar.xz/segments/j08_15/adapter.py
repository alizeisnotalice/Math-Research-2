"""Run j08–15 immutable structural audit on a scratch copy and translate its interface."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,sys,tempfile
from flint import arb
D=Path(__file__).resolve().parent;S=D/'upper-01350-j08-15';out=Path(sys.argv[1]).resolve();assert not out.is_relative_to(S)
for line in (S/'SHA256SUMS').read_text().splitlines():
 h,n=line.split(None,1);assert sha256((S/n.strip()).read_bytes()).hexdigest()==h,n
with tempfile.TemporaryDirectory(prefix='j08-15-',dir=out.parent) as td:
 C=Path(td)/'source';shutil.copytree(S,C,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));subprocess.run([sys.executable,'-B',str(C/'assemble_audit.py')],cwd=C,stdout=subprocess.DEVNULL,check=True);result=json.loads((C/'assembled-audit.json').read_bytes());assert (C/'assembled-audit.json').read_bytes()==(S/'assembled-audit.json').read_bytes()
assert result['all_passed'] and result['geometry_sha256']=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189' and result['physical_sha256']=='ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8' and result['EH_retreat']=='593/6250000000' and result['label']=='U1-Te-0';assert set(map(int,result['bins']))==set(range(8,16))
for j,row in result['bins'].items():
 assert row['closed_physical_cells']==75 and row['orientation_labels']==[0,1] and row['contact_classes_per_orientation_and_sign']==6 and arb(row['root_lower'])>0 and arb(row['common_placement_lower'])>0
 assert row['angle_classes']==([-1,1] if int(j)<15 else [0])
r={'complete':True,'all_passed':True,'geometry_sha256':result['geometry_sha256'],'physical_sha256':result['physical_sha256'],'bins':list(range(8,16)),'closed_cells':600,'input_audit_sha256':sha256((S/'assembled-audit.json').read_bytes()).hexdigest(),'scope':'same-input closed classes, precise j8 and j15 replacements; only bins 8-15'};out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

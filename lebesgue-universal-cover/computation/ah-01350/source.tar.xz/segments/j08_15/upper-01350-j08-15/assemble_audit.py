"""Check j8--15 structural cover, source integrity and closed-interval repairs."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import json
from flint import arb,ctx
from audit_bins_013 import audit,REFERENCE
ctx.prec=128
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def validate_patch(filename,j,orientation,side,counts,interval):
 f=P/filename;d=read(f);assert d['complete'] and d['all_passed'] and d['geometry_sha256']==REFERENCE
 assert d['physical_parameters']==read(P/'physical-0135.json') and d['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'}
 assert d['reachable']=={str(j):([[0,75]] if j==8 else [[60,75]])}
 for name,h in d['source_hashes'].items():
  p=P/name if (P/name).exists() else P/'comp012'/name;assert digest(p)==h,(filename,name)
 result=[]
 for item in d['rows']:
  r=item['row'];assert item['bin']==r['reference_bin']==j and item['orientation']==orientation and item['counts']==counts
  assert item.get('angle_class',0)==side and item.get('positive',True)
  assert all(arb(r[k])>0 for k in ('root_margin_lower','placement_margin_lower'))
  assert r['placed_leaves']==sum(r.get('pose_counts',r.get('verified_dihedral_pose_counts',{})).values())
  if side:assert F(r['anchor_degrees'])==23 and r['anchor_comparison_sign']==side and F(r['anchor_threshold'])==-F(1,50000)
  else:assert item['tighten_first']
  result.append(item)
 intervals=sorted(tuple(x['row']['subcells']) for x in result)
 assert [i for a,b in intervals for i in range(a,b)]==list(range(*interval))
 return result,digest(f)

patch8,h8=validate_patch('retry-8-output.json',8,0,1,[1,4],(0,25))
patch15,h15=validate_patch('retry-15-output.json',15,0,0,[5,0],(60,75))
summary={}
for j in range(8,16):
 base=audit(j);assert base is not None
 expected_bad={8:[(0,1,(1,4),(0,25))],15:[(0,0,(5,0),(60,65)),(0,0,(5,0),(65,70)),(0,0,(5,0),(70,75))]}.get(j,[])
 bad=[(a,b,tuple(c),tuple(e)) for a,b,c,_,e,*rest in base['bad']]
 assert sorted(bad)==sorted(expected_bad),(j,bad)
 d=read(P/f'output-{j}.json');rows=[]
 for t in d['rows']:
  r=t['row'];badrow=not (arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0)
  if not badrow:rows.append(t)
 if j==8:rows+=patch8
 if j==15:rows+=patch15
 groups=defaultdict(list)
 for t in rows:
  r=t['row'];ori=t['orientation'];side=t.get('angle_class',0);k=tuple(t['counts']);e=tuple(map(F,t.get('e_class',['0','1'])))
  assert e==(F(0),F(1));groups[ori,side,k].append(tuple(r['subcells']))
 sides=[-1,1] if j<15 else [0];keys={(o,s,(k,5-k)) for o in (0,1) for s in sides for k in range(6)};assert groups.keys()==keys
 for key,blocks in groups.items():
  blocks=sorted(blocks);assert [i for a,b in blocks for i in range(a,b)]==list(range(75)),(j,key,blocks)
 rm=min(arb(t['row']['root_margin_lower']).lower() for t in rows);pm=min(arb(t['row']['placement_margin_lower']).lower() for t in rows)
 assert rm>0 and pm>0
 summary[str(j)]={'closed_physical_cells':75,'orientation_labels':[0,1],'angle_classes':sides,'contact_classes_per_orientation_and_sign':6,'root_lower':str(rm),'common_placement_lower':str(pm),'rows':len(rows),'prior_sha256':base['sha256'],'patch_sha256':h8 if j==8 else h15 if j==15 else None,'root_free_leaves':sum(t['row']['root_free_leaves'] for t in rows),'placed_leaves':sum(t['row']['placed_leaves'] for t in rows),'empty_conditional_subcells':sum(t['row'].get('empty_conditional_subcells',0) for t in rows)}
out={'geometry_sha256':REFERENCE,'physical_sha256':digest(P/'physical-0135.json'),'EH_retreat':'593/6250000000','label':'U1-Te-0','bins':summary,'all_passed':True,'scope':'j8--15 only; physical first-hit transfer and global coverage not proven here'}
(P/'assembled-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({j:(v['rows'],v['root_lower'],v['common_placement_lower']) for j,v in summary.items()},indent=2))

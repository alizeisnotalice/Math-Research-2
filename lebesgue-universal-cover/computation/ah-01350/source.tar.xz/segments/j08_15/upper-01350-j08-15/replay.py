"""Replay j8--15 into a new external directory; original inputs stay intact."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,shutil,subprocess,sys,os,json,hashlib
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('--jobs',type=int,default=3);a=p.parse_args()
root=Path(__file__).resolve().parent;work=a.work.resolve();assert not work.exists() and not work.is_relative_to(root);assert 1<=a.jobs<=8
shutil.copytree(root,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
names=[f'output-{j}.json' for j in range(8,16)]+['retry-8-output.json','retry-15-output.json']
prior={name:hashlib.sha256((work/name).read_bytes()).hexdigest() for name in names}
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(item):
 j,patch=item;script=('certify_early_retry.py' if j==8 else 'certify_ordered_direct_mixed.py') if patch else ('certify_ordered_direct_mixed.py' if j==15 else 'certify_early_sharp.py')
 config=f'retry-{j}.json' if patch else f'config-{j}.json';output=f'retry-{j}-output.json' if patch else f'output-{j}.json'
 argv=[sys.executable,'-I','-B',str(work/script),str(work/'comp012')]
 if script=='certify_ordered_direct_mixed.py':argv.append(str(work))
 argv += [str(work/config),str(work/output)]
 log=work/f"replay-{'retry-' if patch else ''}{j}.log"
 with log.open('w') as stream:result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=work)
 if result.returncode:raise RuntimeError((j,patch,result.returncode,str(log)))
 print(json.dumps({'bin':j,'patch':patch,'returncode':result.returncode}),flush=True)
with ThreadPoolExecutor(max_workers=a.jobs) as ex:list(ex.map(run,[(j,False) for j in range(8,16)]+[(8,True),(15,True)]))
comparison={name:{'prior':prior[name],'replay':hashlib.sha256((work/name).read_bytes()).hexdigest()} for name in names}
for record in comparison.values():record['byte_equal']=record['prior']==record['replay']
(work/'replay-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
subprocess.run([sys.executable,'-I','-B',str(work/'assemble_audit.py')],cwd=work,env=env,check=True)
print('PASS j8--15:',work/'assembled-audit.json')

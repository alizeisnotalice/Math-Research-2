# 0.01350: bins j=8–15, both first-hit labels

This is a shard certificate, not a complete universal-cover proof. The fixed physical geometry is sigma=1.54 degrees, AH=(.429,.01350), chart=(.344,.393,.019), graph endpoint .62. Source geometry SHA-256 is `d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189`. For each j=8,…,15 all 75 closed physical subcells, both orientations, and six ordered contact classes are covered. For j8–14 both conditional sign classes are retained; j15 uses the direct-root classes. Every nonempty root and each accepted placement have positive interval margins. The placement validator checks all support rows for the same chosen rigid pose. The EH row U1-Te-0 is tightened by exactly 593/6250000000 before every test; this shard does not itself prove the separate first-hit transfer or the rest of the global bins.

j8's original orientation 0 / sign + / counts (1,4) / [0,25] failed. The only replacement is `retry-8-output.json`, using the same closed physical block and depth 6. j15's original orientation 0 / counts (5,0) blocks [60,65], [65,70], [70,75] failed. `retry-15-output.json` replaces exactly these with 15 closed unit-index cells. Original failed receipts remain included; they are never counted as passing. The structural auditor checks source hashes, identical physical chart, interval labels, six classes, exact index coverage per class, positive root and common-pose margins, and replacement scope. `assembled-audit.json` records the actual result; its smallest placement lower bound is about 1.0430e-9 at j8.

## Reproduce

Python 3.13, python-flint 0.9.0, Arb 128-bit or the source kernel's chosen precision. All source and inputs are relative to this directory; no external repository is required. To recompute every original and both replacement kernels, then rebuild the ledger:

```sh
/path/to/python -B replay.py /absolute/path/to/a/new-work-directory --jobs 3
```

The output directory must not exist. Runs are deterministic with no random seed; child logs and regenerated outputs are saved there. `assemble_audit.py` alone audits the included receipts and both replacements; from this directory execute `/path/to/python -B assemble_audit.py`. An exit code 0 from a kernel is not taken as proof: `all_passed`, every conditional branch and its containment are audited separately.

The copied initial configs originate from `lebesgue-terra-01300-early`, which in turn derived them from the .01250 early-bin release, with only the physical file changed. `provenance.json` records those parent config hashes, the new physical file hash and the fixed-chart source. The actual kernels and computation support modules are in this package and recorded in `SHA256SUMS`.

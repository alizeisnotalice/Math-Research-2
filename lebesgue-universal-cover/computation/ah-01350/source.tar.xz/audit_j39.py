"""Independently connect the .01350 j39 two-branch joint cone to the same physical chart."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from hashlib import sha256
import json,sys
from flint import arb,ctx
P=Path(__file__).resolve().parent;T=P/'segments/j40_69';C=T/'comp012';Q=P/'segments/j39';sys.path[:0]=[str(T),str(T/'joint'),str(C)]
from positive_cone import vertices
from certify_sigma_extended_graph import geometry
from certify_sigma_reachable_roots import reach
ctx.prec=160;load=lambda p:json.loads(p.read_bytes());sha=lambda p:sha256(p.read_bytes()).hexdigest();params=load(T/'physical-0135.json');assert params=={'sigma_degrees':'1.54','line':['.429','.01350'],'physical_parameters':['.344','.393','.019']};ns,source,_=geometry(C,[(F('.429'),F('.01350'))],sigma='1.54',far=F('.344'),negative=F('.393'),eps=F('.019'));G=sha256(source.encode()).hexdigest();assert G=='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189';assert F(ns['wmax'])==F('.62') and reach(ns,39)==[(0,75)] and ns['labelled_deficits'][1][39].is_zero()
d=load(Q/'joint-39.json');ledger=load(Q/'replay-j39.json');raw_hash=sha(Q/'joint-39.json');assert ledger['complete'] and ledger['native_sha256']==ledger['independent_replay_sha256']==raw_hash and raw_hash=='b9e6f85583201fa59f0d19622b648c45f5932e1a6be244fb93c2079400863a42';assert d['complete'] and d['all_passed'] and not d['scout'] and d['geometry_sha256']==G and d['physical_parameters']==params and d['ranges']=={'39':75}
eh=C/'sigma154-ah429-eh-chain997-composition.json';cost=F(load(eh)['transfer_cost']['exact'][1]);assert d['EH_source_sha256']==sha(eh) and F(d['EH_cost_upper'])==cost<F(d['EH_retreat'])==F(593,6250000000)
for n,v in d['source_sha256'].items():
 f=T/n if (T/n).exists() else T/'joint'/n;assert f.is_file() and sha(f)==v,n
poses={f'{i},{s}' for i in range(0,360,60) for s in (-1,1)};mins=[arb(1),arb(1)];empty=0;wprev=None
assert [r['block'] for r in d['rows']]==[[k,k+5] for k in range(0,75,5)]
for r in d['rows']:
 j=r['j'];k,l=r['block'];assert j==39 and not r['scout'] and r['zero_pass'] and r['positive_pass'];c=r['condition'];f=F(c['F']);gamma=F(c['M_over_m_upper']);assert f>0 and arb(c['S'])>arb(f.numerator)/f.denominator and arb(c['m'])>3 and gamma>0 and arb(c['mate_circle_clearance'])>0
 w0,w1=map(F,c['w']);assert w0<w1 and (wprev is None or wprev==w0);wprev=w1
 std=[((0,-1,0),0),((0,1,-1),0),((-1,0,1),0),((1,0,0),1),((-1,-2*gamma,2),0)];assert [(x['cut'],x['C_sign']) for x in c['cuts']]==list(product((f'AH-line:{i}' for i in range(4)),(1,-1)));extreme=set()
 for v in c['cuts']:
  n,h=v['necessary_halfplane'];sign=v['C_sign'];vv=vertices([*std,((sign,0,-2*sign),0),(tuple(map(F,n)),F(h))]);assert len(vv)==v['vertices'];extreme.update(vv)
 assert sorted(extreme)==[tuple(map(F,x)) for x in c['scaled_vertices']];assert r['actual_positive_mate_empty']==(not extreme)
 checks=[r['zero']]
 if r['actual_positive_mate_empty']:assert r['positive'] is None;empty+=1
 else:checks.append(r['positive'])
 for x in checks:
  assert x['reference_bin']==39 and x['subcells']==[k,k+1] and x['starting_angle_cells']==12
  assert set(x['verified_dihedral_pose_counts'])<=poses and sum(x['verified_dihedral_pose_counts'].values())==x['placed_leaves']>0 and x['placed_leaves']+x['root_free_leaves']>=12
  for i,n in enumerate(('root_margin_lower','placement_margin_lower')):
   v=arb(x[n]);assert v>0;mins[i]=min(mins[i],v.lower())
out={'complete':True,'bin':39,'physical_cells':75,'closed_blocks':15,'graph_sha256':G,'orientation1_positive_first_deficit_empty':True,'empty_positive_cones':empty,'root_lower':str(mins[0]),'placement_lower':str(mins[1]),'raw_sha256':raw_hash,'scope':'checks all joint-cone vertices and same-pose leaf summaries; raw source independent replay matched supplement ledger'};Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

"""Assemble two hash-locked companion archives into a scratch copy, then verify."""
from pathlib import Path
from hashlib import sha256
import argparse,shutil,subprocess,sys,zipfile
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('j32_archive',type=Path);ap.add_argument('j35_archive',type=Path);ap.add_argument('work',type=Path);ap.add_argument('--full',action='store_true');ap.add_argument('--partial',action='store_true');ap.add_argument('--assemble-only',action='store_true');args=ap.parse_args();assert not(args.full and args.partial);W=args.work.resolve();assert not W.exists() and not W.is_relative_to(P);W.mkdir(parents=True);K=W/'kit'
shutil.copytree(P,K,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
parts=[(args.j32_archive,'86c808ca80dd1a48c19fe2b49aa3aa56868568c67e7ae3c7ad1c07224db25929',K/'segments/j32_34'),(args.j35_archive,'5b28bc74155b422653928eb9b539af9694299b59a9abe79be170e3e6fc7d0c32',K/'segments/j35_38')]
for source,expected,target in parts:
 source=source.resolve();assert sha256(source.read_bytes()).hexdigest()==expected,source
 with zipfile.ZipFile(source) as z:
  assert z.testzip() is None
  for name in z.namelist():
   if name.endswith('/'):continue
   parts=Path(name).parts;assert not name.startswith('/') and '..' not in parts
   dest=target.joinpath(*parts);dest.parent.mkdir(parents=True,exist_ok=True);data=z.read(name)
   if dest.exists():assert dest.read_bytes()==data,name
   else:dest.write_bytes(data)
if args.assemble_only:
 print('PASS: companion SHA/CRC and path-safe reconstruction; no mathematical verification performed')
 sys.exit(0)
cmd=[sys.executable,'-I','-B',str(K/'verify01350.py'),str(W/'checked')]
if args.full:cmd.append('--full')
if args.partial:cmd.append('--partial')
subprocess.run(cmd,cwd=K,check=True)
if not(args.partial or args.full):assert (W/'checked/cover-result.json').read_bytes()==(K/'cover-result.json').read_bytes()
print('PASS: companion hashes, full source reconstruction, .01350 one-entry verifier')

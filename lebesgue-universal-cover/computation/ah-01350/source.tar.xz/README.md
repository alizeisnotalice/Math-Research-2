# AH .01350 universal-cover synthesis

The assembled one-entry verifier reports 70 complete bins and 5,184 fine reference cells after rebuilding the first EH stage and auditing all segment joins. Independent full raw replay is recorded separately and is incomplete for the early bins in this first release.

The fixed geometry is σ=1.54°, AH pivot .429 and turn .01350, physical parameters (.344,.393,.019), paired graph endpoint .62 and reference endpoint .43. The exact physical JSON SHA-256 is `ad10375d3aab15229faf546adcee0634fcd47d8f605e14cc0fac5f8067612cc8`; the rebuilt geometry source SHA-256 is `d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189`. Bins 0–68 each contain 75 closed reference fine cells; bin 69 contains nine, for 5,184 in all. The area-only and first-EH computation has been independently rerun and gives the actual curved host area in

    (.844089045844862807399594067178509514511,
     .844089045844862807399594067188870798290).

`PROOF.md` records the same K and Q_A K quantifiers, physical gates, segment interfaces and EH transfer, with the completed 70-bin certificate. It does not extrapolate a verified endpoint to any interval of AH angles.

The two large component archives remain separate and are bound by SHA-256, keeping each public artifact under the project's default 10 MiB limit. Place the j32–34 archive and j35–38 archive beside the main package; after extracting the main package, run with an empty/nonexistent work directory on the data volume:

    python3 -I -B bootstrap.py "$J32_ZIP" "$J35_ZIP" "$WORK"

The bootstrap checks both exact archive hashes and ZIP CRCs, rejects unsafe paths, rebuilds a scratch copy and invokes `verify01350.py` once. A missing segment causes failure. `--partial` writes an explicit incomplete-bin inventory; it is not a universal-cover proof. `--full` additionally executes the original numerical engines; it is a long calculation. `--assemble-only` tests only path-safe package reconstruction and does not verify mathematics. Environment: Python 3.13.18 and python-flint 0.9.0.

The fixed first EH construction comes from the published R255 archive; after the companion assembly it can be checked against the original public archive with `python3 -I -B check_r255.py "$R255_ZIP"`. Segment archives have independent source and physical hashes; exact source archive hashes are listed in `segment-sources.json` and the relevant component ledgers. Previous independent raw replays and their immutable hashes are kept separate from a structural audit.

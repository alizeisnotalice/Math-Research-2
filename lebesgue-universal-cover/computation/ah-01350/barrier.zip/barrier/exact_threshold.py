"""Evaluate the tight contact corner at two deeper true geometries with explicit deficits and placements."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json
D=Path(__file__).resolve().parent
tag,j=sys.argv[1],int(sys.argv[2]);assert tag in ('014','015') and j in (26,31)
comp=D/('comp062' if tag=='014' else 'comp068');sys.path[:0]=[str(D),str(comp)]
from flint import arb
from ordered_fast import validate
from certify_sigma_extended_graph import geometry
p=D/('physical-0140.json' if tag=='014' else 'physical-0150-tight.json')
cfg=json.loads(p.read_bytes())
args=dict(zip(('far','negative','eps'),map(F,cfg['physical_parameters']),strict=True))
n,src_text,_=geometry(comp,[tuple(map(F,cfg['line']))],sigma=cfg['sigma_degrees'],**args)
n['_first_orientation']=0;n['_sharpen_jets']=True;n['_tighten_first']=True
i,=[k for k,(name,_,_) in enumerate(n['rows']) if name.startswith('U1-Te')]
name,norm,h=n['rows'][i];n['rows'][i]=name,norm,h-n['A'](F('.00000009488'))
A=n['A'];w,off=map(F,sys.argv[3:5]);P=n['points'](A(w))[0]
ell,t=n['chart'](P[4]);t=t+A(off);p=n['psi'](ell)
vx=list(P);vx[4]=n['X'](ell,t);vx[2]=n['reflection'](n['X'](p,-t));vx[3]=n['add'](n['mid'],n['mul'](t,n['en']))
b=n['direct'];P=n['pivot_set'][-1];J=n['perp'];dot=n['dot'];ed=[n['sub'](vx[i],vx[k]) for i,k in n['orders']];nz=n['mul'](-1,J(b))
sn=n['trig'](A(-240))
def vals(turn):
 nu=n['add'](n['mul'](turn.cos(),nz),n['mul'](turn.sin(),b))
 U=n['rotate']((nu[0],-nu[1]),sn)
 modes=[(v,c) for i,(v,c) in enumerate(n['sector']) if not n['cross'](ed[i],U)<0 and not n['cross'](U,ed[(i+1)%10])<0]
 assert len(modes)==1
 i,c=modes[0];center=n['reflection'](vx[i]);r=n['sub'](center,P)
 a,d=dot(nz,r),dot(b,r)
 return a*turn.cos()+d*turn.sin()+A(c), d*turn.cos()-a*turn.sin(),(i,c)
for t in ['.015','.018','.018714','.019','.02','.021','.025']:
 print(t,vals(A(F(t))),flush=True)
a=F('.015');b_=F('.025');assert vals(A(a))[0]<0 and vals(A(b_))[0]>0
turns=[]
for i in range(100):
 left=a+(b_-a)*i/100;right=a+(b_-a)*(i+1)/100;xx,dd,mode=vals(n['box'](left,right));assert dd>0;turns.append(dd.lower())
for _ in range(80):
 m=(a+b_)/2;f=vals(A(m))[0]
 if f>0:b_=m
 elif f<0:a=m
 else:raise RuntimeError(m,f)
# At a fixed rational angle just above the sole crossing, an explicit point lies in the actual body.
q=F(int(b_*10**15)+1,10**15)
xq=A(q);v,d,(i,c)=vals(xq);assert v>0
nu=n['add'](n['mul'](xq.cos(),nz),n['mul'](xq.sin(),b))
point=n['add'](n['reflection'](vx[i]),n['mul'](A(c),nu))
pvec=n['sub'](point,P);tangent=dot(b,pvec);assert tangent>0
f0=dot(nz,pvec);assert f0<0
# The identity's actual X is in the positive tangent and positive normal quadrants.
idv=n['sub'](vx[4],P);a0=dot(nz,idv);a1=dot(b,idv);idq=a0*xq.cos()+a1*xq.sin();assert a0>0
out=dict(w=str(w),DE_offset=str(off),graph=sha256(src_text.encode()).hexdigest(),root=[str(a),str(b_)],first_uniform_failure=str(q),root_bracket_checks=[str(vals(A(a))[0]),str(vals(A(b_))[0])],derivative_lower=str(min(turns)),exposed_vertex=i,arc=c,QA_excess=str(v.lower()),QA_original_slope=[str(f0),str(tangent)],identity_c_minus_t=[str(a0),str(a1)],identity_excess_at_threshold=str(idq.lower()),identity_excluded_by_retained_original_AH_normal=bool(a0>0),source=sha256(Path(__file__).read_bytes()).hexdigest())
(D/sys.argv[5]).write_text(json.dumps(out,indent=2)+'\n');print('threshold',float(a),float(b_),q,flush=True)

"""Join two exact actual width-one obstructions without the old straight AH support."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from flint import arb,ctx
import json
ctx.prec=160
D=Path(__file__).resolve().parent
def val(n):return json.loads((D/n).read_bytes())
def A(q):return arb(q.numerator)/q.denominator
s=val('threshold-best1.json');p=val('actual-obstruction-015.json')
start=F(s['first_uniform_failure']);end=F(p['first_uniform_failure'])
a,b=map(arb,s['identity_c_minus_t']);assert a>0 and b<0
at_end=a*A(end).cos()+b*A(end).sin();assert at_end>0
assert 0<start<end<F('.02')
assert arb(s['QA_excess'])>0 and arb(s['QA_original_slope'][0])<0 and arb(s['QA_original_slope'][1])>0
assert all(arb(x)>0 for x in p['identity_quadrant']) and arb(p['QA_excess'])>0 and arb(p['QA_original_slope'][0])<0 and arb(p['QA_original_slope'][1])>0
slants={'m3':[],'m5':[]}
for rfile in ['witness-best1.json','pinned-singleton-015.json']:
 r=val(rfile)
 for x in r['twelve_dihedral_tests']:
  if tuple(x['pose']) not in ((0,1),(240,-1)):
   assert x['excluded'] and x['necessary_face'] in slants
   slants[x['necessary_face']].append(arb(x['excess_lower']).lower())
assert all(len(v)>0 for v in slants.values())
out=dict(start=str(start),switch=str(end),identity_margin_on_overlap=str(at_end.lower()),slant_allowance={k:str(min(v)) for k,v in slants.items()},assumed_faces=['H six normals','m3','m5','new AH at d'],original_AH_straight_used=False,any_EH_used=False,source_sha256={n:sha256((D/n).read_bytes()).hexdigest() for n in ['three_line_seam.py','pinned-singleton-015.json','witness-best1.json','actual-obstruction-015.json','threshold-best1.json']})
(D/'three-line-seam.json').write_text(json.dumps(out,indent=2)+'\n');print(out['identity_margin_on_overlap'],out['slant_allowance'],flush=True)

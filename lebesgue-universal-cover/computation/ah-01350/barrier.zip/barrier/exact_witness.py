"""Evaluate the tight contact corner at two deeper true geometries with explicit deficits and placements."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json
D=Path(__file__).resolve().parent
tag,j=sys.argv[1],int(sys.argv[2]);assert tag in ('014','015') and j in (26,31)
comp=D/('comp062' if tag=='014' else 'comp068');sys.path[:0]=[str(D),str(comp)]
from flint import arb
from ordered_fast import validate
from certify_sigma_extended_graph import geometry
p=D/('physical-0140.json' if tag=='014' else 'physical-0150-tight.json')
cfg=json.loads(p.read_bytes())
args=dict(zip(('far','negative','eps'),map(F,cfg['physical_parameters']),strict=True))
n,s,_=geometry(comp,[tuple(map(F,cfg['line']))],sigma=cfg['sigma_degrees'],**args)
n['_first_orientation']=0;n['_sharpen_jets']=True;n['_tighten_first']=True
i,=[k for k,(name,_,_) in enumerate(n['rows']) if name.startswith('U1-Te')]
name,norm,h=n['rows'][i];n['rows'][i]=name,norm,h-n['A'](F('.00000009488'))
A=n['A'];w,off=map(F,sys.argv[3:5]);P=n['points'](A(w))[0]
ell,t=n['chart'](P[4]);t=t+A(off);p=n['psi'](ell)
vx=list(P);vx[4]=n['X'](ell,t);vx[2]=n['reflection'](n['X'](p,-t));vx[3]=n['add'](n['mid'],n['mul'](t,n['en']))
normals=list(map(n['av'],n['d']['n']));ed=[n['sub'](vx[i],vx[k]) for i,k in n['orders']]
for i in range(5):
 dv=n['sub'](vx[i],vx[(i+1)%5]);assert n['dot'](dv,dv).contains(1)
other=[]
for i in range(5):
 dv=n['sub'](vx[i],vx[(i+2)%5]);d=n['dot'](dv,dv);assert d<1;other.append(d.upper())
allcross=[n['cross'](ed[k],ed[(k+1)%10]).lower() for k in range(10)]
assert min(allcross)>0
assert all(n['cross'](ed[0],ed[k])>0 for k in range(1,5))
assert all(tuple(n['orders'][i+5])==tuple(reversed(n['orders'][i])) for i in range(5))
for k,(vtx,arc) in enumerate(n['sector']):
 side=0 if arc==0 else 1
 assert n['orders'][k][side]==n['orders'][(k+1)%10][side]==vtx
pinned=[]
for i,u in enumerate(normals):
 act=[(v,q) for r,(v,q) in enumerate(n['sector']) if not n['cross'](ed[r],u)<0 and not n['cross'](u,ed[(r+1)%10])<0]
 assert len(act)==1
 v,c=act[0]
 assert v in (0,1,3) and n['dot'](vx[v],u)+c-A(F(1,2))==0 or (v in (0,1,3) and (n['dot'](vx[v],u)+c-A(F(1,2))).contains(0))
 pinned.append((i,v,c))
assert pinned==[(0,1,1),(1,3,1),(2,0,1),(3,1,0),(4,3,0),(5,0,0)]
from itertools import product
gaps=[];ends=[];deriv=n['angle_unit'];N=1200
def harmonic_upper(interval,left,right):
  groups=[]
  for k in range(3):
   u=n['rotate'](normals[0],n['trig'](interval+A(60*k)))
   uk=n['rotate'](normals[0],n['trig'](A(60*k)));jk=n['perp'](uk)
   choices=[]
   for i,(v,c) in enumerate(n['sector']):
    if n['cross'](ed[i],u)<0 or n['cross'](u,ed[(i+1)%10])<0:continue
    z=A((-1)**k);choices.append((z*n['dot'](uk,vx[v]),z*n['dot'](jk,vx[v]),z*c))
   assert choices;groups.append(choices)
  output=[]
  for triple in product(*groups):
   ca,sa,bb=map(sum,zip(*triple,strict=True));bb-=A(F(1,2))
   co,si=n['trig'](interval);der=-ca*si+sa*co
   if der>0:co,si=n['trig'](A(right));upper=ca*co+sa*si+bb
   elif der<0:co,si=n['trig'](A(left));upper=ca*co+sa*si+bb
   else:upper=(ca*ca+sa*sa).sqrt()+bb
   output.append(upper.upper())
  return max(output)
for z in range(N):
 a,b=F(z,20),F(z+1,20);m=(a+b)/2
 d=n['box'](a,b)
 fp=sum((-1)**t*n['supports'](vx,ed,n['trig'](d+A(60*t)),normals[0],True) for t in range(3))
 if b<=1:margin=-fp;ends.append(margin.lower())
 elif a>=59:margin=fp;ends.append(margin.lower())
 else:
  ft=n['F_at'](vx,ed,m)+n['box'](a-m,b-m)*deriv*fp;gaps.append(max((-ft).lower(),-harmonic_upper(d,a,b)) if not ft<0 else (-ft).lower())
assert min(ends)>0 and min(gaps)>0,(min(ends),min(gaps))
pm=[]
sn=n['trig'](A(-240))
for lab,u,h in n['rows']:
 hh=n['supports'](vx,ed,sn,(u[0],-u[1]));pm.append((h-hh).lower())
print('w',w,off,'fan',min(allcross),'interior',min(gaps),'end slopes',min(ends),'Q_A margin',min(pm),flush=True)
out=dict(w=str(w),DE_offset=str(off),geometry_sha256=sha256(s.encode()).hexdigest(),physical=cfg,nonadjacent_sqdistance_upper=str(max(other)),fan_cross_lower=str(min(allcross)),pins=pinned,angular_cells=N,near_endpoint_derivative_margin=str(min(ends)),interior_negative_margin=str(min(gaps)),fixed_QA_margin=str(min(pm)),host_edges=len(pm),source=sha256(Path(__file__).read_bytes()).hexdigest())
out['lowest_sufficient_inner_row']=n['rows'][min(range(len(pm)),key=lambda r:pm[r])][0]
needed=[(f'm{k}',n['av'](n['d']['m'][k]),A(F(1,2))) for k in (3,5)]+[(label,u,h) for label,u,h in n['rows'] if label.startswith('AH-line:')]
ex=[]
for turn in range(0,360,60):
 for side in (-1,1):
  sc=n['trig'](A(-turn))
  violations=[((n['supports'](vx,ed,sc,(u[0],side*u[1]))-h).lower(),label) for label,u,h in needed]
  val,label=max(violations,key=lambda item:item[0])
  ex.append(dict(pose=[turn,side],necessary_face=label,excess_lower=str(val),excluded=bool(val>0)))
out['twelve_dihedral_tests']=ex
print('excluded',sum(x['excluded'] for x in ex),[x for x in ex if not x['excluded']],flush=True)
(D/sys.argv[5]).write_text(json.dumps(out,indent=2)+'\n')

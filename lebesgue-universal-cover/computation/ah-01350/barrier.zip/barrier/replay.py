"""Recompute the three actual constant-width obstructions and the exact fixed-family area barrier."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,sys,subprocess,shutil
from flint import arb,ctx
ctx.prec=160
D=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve();S.mkdir(parents=True,exist_ok=True);assert not any(S.iterdir())
def data(n):return json.loads((S/n).read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def same(n):assert (S/n).read_bytes()==(D/n).read_bytes(),n
files=json.loads((D/'manifest.json').read_bytes())
for n,h in files.items():
 assert sha(D/n)==h,n
 if '/' not in n and (n.endswith('.py') or n.startswith('physical-')):shutil.copyfile(D/n,S/n)
shutil.copytree(D/'comp068',S/'comp068')
def run(c):
 script,args,n=c
 with (S/(n+'.log')).open('wb') as f:subprocess.run([sys.executable,'-I','-B',str(S/script),*args],cwd=S,stdout=f,check=True)
 same(n)
base=['015','31']
jobs=[('pinned_singleton.py',base,'pinned-singleton-015.json'),('direct_obstruction.py',base,'actual-obstruction-015.json'),('parameter_curve.py',[],'parameter-curve.json')]
for idx,(w,t) in enumerate([('.429','.00003865'),('.42952','.00000030')],1):
 for s,n in [('exact_witness.py','witness'),('exact_threshold.py','threshold')]:
  name=f'{n}-best{idx}.json';jobs.append((s,base+[w,t,name],name))
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))
for n in ['pinned-singleton-015.json','witness-best1.json','witness-best2.json']:
 q=data(n);ex={tuple(r['pose']):r for r in q['twelve_dihedral_tests']}
 assert q['geometry_sha256']=='5726407e8820a48adee03a8ac2efebe10225c48accf09893a36ee224c30fa82d' and len(ex)==12 and q['angular_cells']==1200
 for pose,r in ex.items():
  if pose not in ((0,1),(240,-1)):assert r['excluded'] and r['necessary_face'] in ('m3','m5') and arb(r['excess_lower'])>0
 assert arb(q['nonadjacent_sqdistance_upper'])<1 and arb(q['interior_negative_margin'])>0 and arb(q['near_endpoint_derivative_margin'])>0
for n in ['actual-obstruction-015.json','threshold-best1.json','threshold-best2.json']:
 q=data(n);lo,hi=map(F,q['root']);cut=F(q['first_uniform_failure']);assert lo<hi<cut and arb(q['QA_excess'])>0
 assert arb(q['QA_original_slope'][0])<0 and arb(q['QA_original_slope'][1])>0 and arb(q['derivative_lower'])>0
 if n.startswith('actual'):assert all(arb(v)>0 for v in q['identity_quadrant'])
 else:assert arb(q['identity_c_minus_t'][0])>0
 if n=='threshold-best1.json':assert arb(q['identity_excess_at_threshold'])>0
assert F(data('threshold-best2.json')['first_uniform_failure'])==F('.018685125126173')
run(('three_line_seam.py',[],'three-line-seam.json'))
run(('actual_sides.py',['threshold-best2.json','best-sides.json'],'best-sides.json'))
run(('actual_area.py',['threshold-best2.json','best-area.json'],'best-area.json'));same('gibbs-raw.json')
q=data('best-area.json');a,b=map(F,q['sides'][1]['cross']['exact']);assert F('.42952')<a<b<F('.43')
assert F(q['sides'][1]['area']['exact'][0])>F('.844086103763274181650658277813391834799')
assert F(q['sides'][1]['AH_EH_clearance']['exact'][0])>0 and not q['reference_window_assumed']
for k in ('angle_derivative','projection_derivative'):assert arb(data('parameter-curve.json')[k][0])>0
print('Verified twelve-pose exclusions for actual width-one bodies, the full true arc and the reference-independent area barrier.')

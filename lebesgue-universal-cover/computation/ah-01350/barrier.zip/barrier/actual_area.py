"""Area at the largest AH turn compatible with keeping the paired cap endpoint before w=.43."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import sys,json,subprocess,inspect,ast
from flint import arb,ctx
ctx.prec=160
D=Path(__file__).resolve().parent;C=D/'comp068';sys.path.insert(0,str(C))
from certify_three_sigma_area_budget import fixed_ah,setup,ah_clearance,exact,pack,subtract,geometries
SIGMA='1.54'
ELEVEN='sigma154-ah429-eh-chain997-composition.json'
ELEVEN_SHA='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
import audit_optimized_eh_chord as g
def sha(p):return sha256(p.read_bytes()).hexdigest()
obstruction=json.loads((D/sys.argv[1]).read_bytes())
lo,hi=map(Q,obstruction['root'])
hi=Q(obstruction['first_uniform_failure'])
raw=subprocess.check_output([sys.executable,'-E','-B',str(C/'certify_gibbs_area_refined.py'),'1.54','16','64'])
base=json.loads(raw)
assert base['passed'] and Q(base['sigma_degrees'])==Q(SIGMA)
b=list(map(Q,base['area_interval']))
(D/'gibbs-raw.json').write_bytes(raw)
assert sha(C/ELEVEN)==ELEVEN_SHA
eleven=json.loads((C/ELEVEN).read_bytes());e=list(map(Q,eleven['EH_cut']['exact']))
hinge_source=D/'structural_eh_inputs.py'
relax,=[ast.literal_eval(node.value) for node in ast.parse(hinge_source.read_text()).body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RELAX' for t in node.targets)]
source=inspect.getsource(geometries);token='    from certify_eh_dual_hinge import RELAX';assert source.count(token)==1
ns={**geometries.__globals__,'RELAX':relax};exec(compile(source.replace(token,'    assert len(RELAX)==2'),'independent_eleven_area','exec'),ns)
with ctx.workprec(256):
    rebuilt=ns['geometries'](SIGMA,eleven['old_parameters'],eleven['EH_chain_params'],g)
    assert sorted(rebuilt['facets'])==list(range(11))
    gain=rebuilt['new_eh']-rebuilt['old_eh']
    assert exact(e[0])<gain<exact(e[1])
    rebuilt_eh=pack(gain,48)

G=setup(SIGMA,g);U,C3,T=[G[k] for k in ['U','C3','T']]
rad=g.minus(U,C3);co,si=g.unit(exact(eleven['EH_deepest']))
V=g.plus(C3,g.minus(g.scale(co,rad),g.scale(si,g.rot(rad))))
sides=[]
for t in (lo,hi):
    cap,cross,slope=fixed_ah(C,SIGMA,Q('.429'),t,Q('.46'))
    assert slope>0 and cross[0]>Q('.300') and cross[1]<Q('.46')
    clearance=ah_clearance(G,V,T,g,Q('.429'),t)
    area=subtract(subtract(b,cap),e)
    sides.append(dict(turn=str(t),AH_cut=pack(cap,36),cross=pack(cross,35),area=pack(area,39),AH_EH_clearance=pack(clearance),crossing_slope=str(slope)))
out=dict(critical_turn=obstruction['root'],rebuilt_eleven_EH=rebuilt_eh,critical_area_lower=sides[1]['area']['decimal'][0],critical_area_upper=sides[0]['area']['decimal'][1],sides=sides,reference_window_assumed=False,scope='fixed pivot .429, fixed Gibbs 1.54 degrees, eleven EH with unchanged charts',input_sha256={x.name:sha(x) for x in [D/sys.argv[1],D/'gibbs-raw.json',C/ELEVEN,hinge_source,Path(__file__)]})
(D/sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n')
print(out['critical_area_lower'],out['critical_area_upper'])

"""The true cut/arc angle and paired projection as functions of the common reference w."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
ctx.prec=160
here=Path(__file__).resolve().parent;comp=here/'comp068'
sys.path.insert(0,str(comp))
p=comp/'certify_ah_combined_area.py'
s=p.read_text().split('start, finish =',1)[0].replace('sigma = "1.5497"','sigma = "1.54"').replace('F("0.38")','F(".429")').replace('order, cells = 14, 24','order, cells = 2, 24')
n={'__file__':str(p)};exec(compile(s,str(p),'exec'),n)
I,curve,jet,sub,dot,cross,b,W,z,length=[n[k] for k in ('I','curve','curve_series','sub','dot','cross','b','W','z','length')]
def A(f):return arb(f.numerator)/f.denominator
def B(v):return A(v.lo).union(A(v.hi))
def data(w):
    q=curve(w);v=sub(q,W);along=dot(b,v);perp=cross(b,v)
    assert along.lo>0 and perp.lo>0
    delta=B(perp/along).atan()
    projection=dot(b,sub(q,z))/length
    return dict(angle=str(delta),negative_projection=str(B(projection)),positive_dot=str(B(along)),positive_cross=str(B(perp)))
margins=[]
for k in range(3000,4610):
    x=jet(I(F(k,10000),F(k+1,10000)))
    v=sub(tuple(t.c[0] for t in x),W);qp=tuple(t.c[1] for t in x)
    coef=cross(v,qp)/dot(v,v);pp=dot(b,qp)/length
    assert coef.lo>0 and pp.lo>0,(k,float(coef.lo),float(coef.hi),float(pp.lo),float(pp.hi))
    margins.append((coef.lo,coef.hi,pp.lo,pp.hi))
points={str(v):data(v) for v in map(F,['.3','.325','.336','.352','.369','.374','.4','.425','.429','.43','.45','.46'])}
out=dict(sigma='1.54',pivot='.429',domain=['.300','.461'],cell_count=len(margins),angle_derivative=[str(A(min(v[0] for v in margins))),str(A(max(v[1] for v in margins)))],projection_derivative=[str(A(min(v[2] for v in margins))),str(A(max(v[3] for v in margins)))],pointwise=points,sources={x.name:sha256(x.read_bytes()).hexdigest() for x in [p,comp/'certify_gibbs_area_refined.py',comp/'rational_trig.py',Path(__file__)]})
(here/'parameter-curve.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['angle_derivative'],points[str(F('.43'))],flush=True)

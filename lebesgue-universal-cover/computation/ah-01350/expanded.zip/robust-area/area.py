"""Certified area at a robust obstruction depth, including the full paired arc."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from zipfile import ZipFile
import json
import sys

here = Path(__file__).resolve().parent
archive = Path(sys.argv[1]).resolve()
assert sha256(archive.read_bytes()).hexdigest()=='7b713982e9bc422046687a82cd2408eaf94e2098430db5442b8b28aeda01568f'
scratch = Path(sys.argv[2]).resolve()
scratch.mkdir(parents=True,exist_ok=True)
assert not any(scratch.iterdir())
with ZipFile(archive) as z:
    z.extractall(scratch)
base=scratch/'barrier'
comp=base/'comp068'
sys.path.insert(0,str(comp))
from certify_three_sigma_area_budget import fixed_ah, setup, exact, ah_clearance, subtract, pack
import audit_optimized_eh_chord as g
from flint import ctx
ctx.prec=160
def read(path):
    return json.loads(path.read_bytes())
G=setup('1.54',g)
ch=read(comp/'sigma154-ah429-eh-chain997-composition.json')
raw=read(base/'gibbs-raw.json')
B=list(map(F,raw['area_interval']))
eh=list(map(F,ch['EH_cut']['exact']))
u,c3,T=[G[k] for k in ('U','C3','T')]
co,si=g.unit(exact(ch['EH_deepest']))
rad=g.minus(u,c3)
V=g.plus(c3,g.minus(g.scale(co,rad),g.scale(si,g.rot(rad))))
src=comp/'certify_ah_combined_area.py'
code=src.read_text().split('start, finish =',1)[0]
code=code.replace('sigma = "1.5497"','sigma = "1.54"').replace('F("0.38")','F(".429")').replace('order, cells = 14, 24','order, cells = 2, 24')
n={'__file__':str(src)}
exec(compile(code,str(src),'exec'),n)
I,curve,jet,sub,add,mul,cross,perp,b,W,trig=[n[k] for k in ('I','curve','curve_series','sub','add','mul','cross','perp','b','W','trig')]
ds=list(map(F,sys.argv[3:]))
dirs=[add(mul(I(*trig.trig((d,d),'cos')),b),mul(I(*trig.trig((d,d),'sin')),perp(b))) for d in ds]
sides=[[] for d in ds]
for k in range(1000):
    l,r=F(k,1000),F(k+1,1000)
    m=(l+r)/2
    v=sub(curve(m),W)
    slope=tuple(x.c[1] for x in jet(I(l,r)))
    for direct,acc in zip(dirs,sides,strict=True):
        fp=cross(direct,slope)
        val=cross(direct,v)+I(l-m,r-m)*fp
        if val.hi<0:
            acc.append(-1)
        elif val.lo>0:
            acc.append(1)
        else:
            assert fp.lo>0
            acc.append(0)
out=[]
for d,modes in zip(ds,sides,strict=True):
    assert modes==sorted(modes) and set(modes)=={-1,0,1}
    a=F(modes.index(0),1000)
    z=F(modes.index(1),1000)
    cap,root,sp = fixed_ah(comp,'1.54',F('.429'),d,F('.8'))
    assert a<root[0]<=root[1]<z and sp>0
    gap=ah_clearance(G,V,T,g,F('.429'),d)
    assert gap>0
    area=subtract(subtract(B,cap),eh)
    out.append(dict(d=str(d),modes=[modes.count(i) for i in (-1,0,1)],root=pack(root,35),AH_EH_clearance=pack(gap),area=pack(area,38)))
    print(float(d),out[-1]['area']['decimal'],flush=True)
Path(scratch/'robust-area.json').write_text(json.dumps(out,indent=2)+'\n')

"""Relax every enclosing strip and every exclusion face simultaneously."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import sys
from flint import arb, ctx

ctx.prec = 192
source = Path(sys.argv[1])
assert sha256(source.read_bytes()).hexdigest() == '7b713982e9bc422046687a82cd2408eaf94e2098430db5442b8b28aeda01568f'

def A(s):
    r = Fraction(s)
    return arb(r.numerator) / r.denominator

def read(z, name):
    return json.loads(z.read('barrier/' + name + '.json'))

def projection(pair, d):
    return pair[0] * d.cos() + pair[1] * d.sin()

def cov(witness, threshold, start, end, old):
    """Prove that the same real body fails throughout [start,end]."""
    x = A(start)
    qa = tuple(map(arb, threshold['QA_original_slope']))
    assert qa[0] < 0 and qa[1] > 0
    qa_min = projection(qa, x)
    if 'identity_quadrant' in threshold:
        ident = tuple(map(arb, threshold['identity_quadrant']))
        assert min(ident) > 0 and end is None
        identity_min = min(projection(ident, x), ident[1])
    else:
        ident = tuple(map(arb, threshold['identity_c_minus_t']))
        assert ident[0] > 0 and ident[1] < 0
        if old:
            identity_min = ident[0]
        else:
            y = A(end)
            assert x <= y and y < arb.pi()/2
            identity_min = projection(ident, y)
    slants = [arb(t['excess_lower']) for t in witness['twelve_dihedral_tests'] if t['necessary_face'] in ('m3','m5')]
    assert len(slants) == 10
    gap = min(identity_min, qa_min, *slants)
    end_derivative = arb(witness['near_endpoint_derivative_margin'])
    inner_gap = arb(witness['interior_negative_margin'])
    # Circumradius R=1/sqrt(3) and inverse six-direction cosine factor c=2/sqrt(3).
    R = 1 / arb(3).sqrt()
    c = 2*R
    pose_and_retreat_factor = 1 + c + (1 + c)*R*3/end_derivative
    limit = min(inner_gap/3, gap/pose_and_retreat_factor)
    assert limit > 0
    return limit.lower(), dict(w=witness['w'],start=start,end=end,retained_old_AH=old,anchor_gap=str(gap.lower()),inner_gap=str(inner_gap.lower()),speed=str(end_derivative.lower()),all_face_cost_per_eta=str(pose_and_retreat_factor.upper()))

def select_lower(q):
    # Float selects a printable candidate only. The assertions use directed arithmetic.
    from math import floor, log10
    scale = 10 ** (3 - floor(log10(float(q))))
    r = Fraction(floor(float(q)*scale), scale)
    if not q>A(r):
        r -= Fraction(1,scale)
    assert q>A(r)>0
    return str(r)

with ZipFile(source) as z:
    hard, middle, deep = [read(z,n) for n in ['witness-best2','witness-best1','pinned-singleton-015']]
    ht, mt, dt = [read(z,n) for n in ['threshold-best2','threshold-best1','actual-obstruction-015']]
    specs = [('.0186852','old'),('.01869','free'),('.019','free'),('.0198','free'),('.020','free'),('.021','free'),('.022','free'),('.024','free'),('.02419','free'),('.0242','free'),('.025','free'),('.030','free'),('.1','free')]
    output = []
    for left, rule in specs:
        if rule=='old':
            stages=[cov(hard,ht,left,None,True)]
        elif Fraction(left)<Fraction('.0198'):
            stages=[cov(middle,mt,left,'.0198',False),cov(deep,dt,'.0198',None,False)]
        else:
            stages=[cov(deep,dt,left,None,False)]
        eta=select_lower(min(row[0] for row in stages))
        output.append(dict(d_from=left,d_to='pi/2',all_faces_outshift=eta,stages=[v for _,v in stages]))

report=dict(source=sha256(source.read_bytes()).hexdigest(),rows=output)
digest=(json.dumps(report,indent=2)+'\n').encode()
Path(sys.argv[2]).write_bytes(digest)
print([(r['d_from'],float(Fraction(r['all_faces_outshift']))) for r in output],sha256(digest).hexdigest())

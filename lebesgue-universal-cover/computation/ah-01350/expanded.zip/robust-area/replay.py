from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
D=Path(__file__).resolve().parent
source,scratch=map(lambda s:Path(s).resolve(),sys.argv[1:3])
scratch.mkdir(parents=True,exist_ok=True)
assert not any(scratch.iterdir())
q=scratch/'raw'
subprocess.run([sys.executable,'-I','-B',str(D/'area.py'),str(source),str(q),'.022','.024','.025','.02419','.02420'],check=True)
p=scratch/'relax.json'
subprocess.run([sys.executable,'-I','-B',str(D/'relax.py'),str(source),str(p)],check=True)
assert (q/'robust-area.json').read_bytes()==(D/'areas.json').read_bytes()
assert p.read_bytes()==(D/'robust-relax.json').read_bytes()
B=F('.844082046521218581802948589770767704354')
A={F(r['d']):list(map(F,r['area']['exact'])) for r in json.loads((D/'areas.json').read_bytes())}
H={F(r['d_from']):F(r['all_faces_outshift']) for r in json.loads(p.read_bytes())['rows']}
for d,gap,tolerance in [('.022','.00000174159','.0000003064'),('.024','.000000161112','.0000004184'),('.02419','.000000003347','.0000004188')]:
    assert A[F(d)][0]>B+F(gap) and H[F(d)]>=F(tolerance)
assert A[F('.0242')][1]<B and A[F('.025')][1]<B
print('Verified true areas, robust exclusions and the two-sided B crossing.',flush=True)

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from lens_geometry import init
def run(comp):
 defs,_=init(comp);ctx.prec=160
 Q=10**12;poly=json.loads((HERE/'host.json').read_bytes());d=json.loads((HERE/'miss-QY.json').read_bytes())
 assert d['scale']==Q
 x,y=d['point'];p,q=R(x)/Q,R(y)/Q
 margin=min((1-(p-a)**2-(q-b)**2).lower() for a,b in defs['QY']);assert margin>0
 j=d['edge'];a,b=poly[j],poly[(j+1)%len(poly)];nx,ny=b[1]-a[1],a[0]-b[0]
 slack=R(nx*(x-a[0])+ny*(y-a[1]))/(Q*R(nx*nx+ny*ny).sqrt())
 assert slack>R('.00026117')
 rd=comp/'finite-b-core';cur=json.loads((rd/'curves.json').read_bytes());pent=json.loads((rd/'pentagons.json').read_bytes())
 points=pent['vertices_ccw_integer']+cur['combined_hull'];unit=cur['scale'];assert pent['grid']==unit
 caps={}
 for degree in ['0','60','120','180','240','300','211.54','331.54']:
  t=R(degree)*R.pi()/180;c,s=t.cos(),t.sin()
  u=max(((x*c+y*s)/Q-R('.5')).upper() for x,y in poly)
  l=max(((x*c+y*s)/Q-R('.5')).lower() for x,y in poly)
  physical=max(((x*c+y*s)/unit-R('.5')-R('3e-11')).lower() for x,y in points)
  caps[degree]=[str(l),str(u),str(physical)]
 assert R(caps['331.54'][2])>R('.0000214')
 return dict(QY_original_rational_point=d['point'],QY_disk_slack=str(margin),failed_host_edge=j,original_QY_support_gap=str(slack),
             host_support_bounds_and_material_lower=caps)
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]).resolve()),indent=2))

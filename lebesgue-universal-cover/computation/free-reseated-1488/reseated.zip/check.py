from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import sys,json,gzip
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from lens_geometry import init
Q=10**12
def a(x):return R(x.numerator)/x.denominator
def main(comp):
 sys.path.insert(0,str(comp));from deformed_reuleaux_support import body,environment
 defs,_=init(comp)
 import audit_optimized_eh_chord as gg
 ns=environment(str(comp),'1.5497');ctx.prec=160;dot=ns['dot'];cross=ns['cross']
 sq=R(3).sqrt();ref=lambda u:((-u[0]+sq*u[1])/2,(sq*u[0]+u[1])/2)
 turn60=lambda u:((u[0]-sq*u[1])/2,(sq*u[0]+u[1])/2)
 # These candidate circle-circle intersections only enlarge each exact support bound.
 def possible(p,cs):return all(not dot(d:=ns['sub'](p,c),d)>1 for c in cs)
 def intersections(cs):
  pts=[]
  for c,d in combinations(cs,2):
   for s in (-1,1):
    p=gg.circle_pair(c,d,s);assert all(x.is_finite() for x in p)
    if possible(p,cs):pts.append(p)
  return pts
 def support(u,cs,vertices):
  vals=[dot(u,p).upper() for p in vertices]
  for c in cs:
   if possible(ns['add'](c,u),cs):vals.append((1+dot(c,u)).upper())
  assert vals
  return max(vals)
 from legal import check_indices,geometric_margins
 check_indices(ns)
 vertices={k:intersections(cs) for k,cs in defs.items()}
 poly=json.loads((HERE/'host.json').read_bytes());c0=R(116)*R.pi()/180;c1=R(150)*R.pi()/180
 u0=c0.cos(),c0.sin();u1=c1.cos(),c1.sin();z=((sq-1)/2,(1-sq)/2)
 def sharp(u):
  if cross(u0,u)<0 or cross(u,u1)<0:cap=max(dot(u,u0).upper(),dot(u,u1).upper())
  else:cap=R(1)
  return dot(z,u)+cap
 rdir=(comp/'finite-b-core');pc=json.loads((rdir/'pentagons.json').read_bytes());cv=json.loads((rdir/'curves.json').read_bytes());receipt=json.loads((rdir/'host-area.json').read_bytes())
 checked={}
 for f in ['pentagons.json','curves.json','host-poses.json']:
  z0=sha256((rdir/f).read_bytes()).hexdigest();assert z0 in receipt['input_sha256'].values()
  checked[f]=z0
 assert pc['directions']==cv['N']==32768 and pc['grid']==cv['scale']==10**11
 data0=json.loads((rdir/'host-poses.json').read_bytes())['poses']
 assert len(data0)==150 and all((k['turn'],k['reflection'])==(240,-1) for k in data0[:117])
 error=2*(R.pi()/(2*32768)).sin()**2+R('0.00000000003')
 src=pc['vertices_ccw_integer']+cv['combined_hull']
 raw=json.loads(gzip.decompress((HERE/'dense.json.gz').read_bytes()))
 assert raw['scale']==Q and sha256(json.dumps(raw['small'],sort_keys=True,separators=(',',':')).encode()).hexdigest()=='986972d0f12c164e464126a6c8bc87fd12688158bd8a466eedbd6f25c61fe8f3'
 assert all(set(map(tuple,v))<=set(map(tuple,raw['points'][k])) for k,v in raw['small'].items())
 # Enclose all reflected dense witnesses by rounding to the 10^-12 grid once.
 dense=[];xescape=R(0)
 for key,pts in raw['points'].items():
  for x,y in pts:
   xx,yy=ref((R(x)/Q,R(y)/Q));xx+=R('0.0000005') if key=='32' else 0
   xx0,yy0=round(float(xx*Q)),round(float(yy*Q))
   assert abs(xx*Q-xx0)<R('.51') and abs(yy*Q-yy0)<R('.51')
   dense.append((xx0,yy0));xescape=max(xescape,xx.lower())
 assert xescape>R('.50000049')
 def hull(pts):
  pts=sorted(set(map(tuple,pts)))
  def half(seq):
   h=[]
   for p in seq:
    while len(h)>=2 and (h[-1][0]-h[-2][0])*(p[1]-h[-2][1])<=(h[-1][1]-h[-2][1])*(p[0]-h[-2][0]):h.pop()
    h.append(p)
   return h[:-1]
  return half(pts)+half(pts[::-1])
 assert list(map(tuple,poly))==hull(poly)
 dense=hull(dense);src=hull(src)
 rr=json.loads((HERE/'extra.json').read_bytes());assert all(s==1 for s in rr[1])
 bodies=[]
 for w,e in rr[0]:
  V,h=body(ns,a(F(w)),a(F(e)));geometric_margins(ns,a(F(w)),a(F(e)),V);bodies.append(h)
 slack={k:R(1) for k in list(defs)+['disk','sharp_arc','sharp_mirror','150','dense','8-bones']}
 planes=[]
 for (x,y),(p,q) in zip(poly,poly[1:]+poly[:1]):
  nx,ny=q-y,x-p;h=nx*x+ny*y;norm=R(nx*nx+ny*ny).sqrt();u=R(nx)/norm,R(ny)/norm;lim=R(h)/(Q*norm)
  deltas={'disk':lim-R('.5'),'sharp_arc':lim-sharp(u),'sharp_mirror':lim-sharp(ref(u))}
  for k,cs in defs.items():deltas[k]=lim-support(turn60(u) if k=='QY' else u,cs,vertices[k])
  deltas['150']=(R(h-10*max(nx*a+ny*b for a,b in src))/(Q*norm))-error
  deltas['dense']=R(h-max(nx*a+ny*b for a,b in dense)-abs(nx)-abs(ny))/(Q*norm)
  deltas['8-bones']=lim-max(hfun(ref(u)).upper() for hfun in bodies)
  for k,gap in deltas.items():
   assert gap>0,(k,str(gap),u);slack[k]=min(slack[k],gap.lower())
  planes.append((ref(u),lim))
 # Interpolation between the two complete w=1.2 endpoint bodies. Fixed pose along the entire interval.
 w=a(F('1.2'));e0=a(F('.08464386'));e1=a(F('.08464629'));es=e0.union(e1)
 V,_=body(ns,w,es);family_legal=geometric_margins(ns,w,es,V)
 from flint import arb_series
 ee=arb_series([es,1]);add,mul=ns['add'],ns['mul']
 ll,tt=ns['chart'](add(ns['z'],mul(w,ns['D'])));pp=ns['psi'](ll);t=tt-ee
 P=[add(ns['l0'],mul(ll,ns['el'])),ns['reflection'](add(ns['l0'],mul(pp,ns['el']))),ns['reflection'](ns['X'](pp,-t)),add(ns['mid'],mul(t,ns['en'])),ns['X'](ll,t)]
 curvature=max((4*(u[2]**2+v[2]**2)).sqrt().upper() if isinstance(u,arb_series) else R(0) for u,v in P)
 # h and its parameter derivative match at a normal-fan switch since the switching unit edge has velocity orthogonal to itself.
 eps=curvature*(e1-e0)**2/8;assert eps<slack['8-bones']
 A=F(sum(x*b-y*a for (x,y),(a,b) in zip(poly,poly[1:]+poly[:1])),2*Q**2)
 B=F('.844082046521218581802948589770767704354')
 assert A<B
 return dict(vertices=len(poly),scale=Q,area=str(A),exact_decimal_area=str(a(A)),B_minus=str(a(B-A)),escape_x=str(xescape),
  slack={k:str(v) for k,v in slack.items()},family_interpolation_error=str(eps),family_legal_geometry=list(map(str,family_legal)),R215_hashes=checked)
if __name__=='__main__':print(json.dumps(main(Path(sys.argv[1]).resolve()),indent=2))

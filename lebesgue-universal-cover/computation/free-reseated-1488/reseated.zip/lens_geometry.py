from fractions import Fraction as F
from pathlib import Path
import sys
from flint import arb as R,ctx
def init(comp):
    sys.path[:0]=[str(comp),str(comp/'gibbs-compulsory')]
    import audit_optimized_eh_chord as g
    from certify_sigma_mandatory_arcs import degree,anchors
    from certify_three_sigma_area_budget import exact
    from certify_compulsory_C3 import EXTRA
    from certify_low_sigma_ah_budget import b,model
    ctx.prec=160
    g.PI=R.pi();g.SIGMA=degree(F('1.54'))
    n,m,*_=g.setup()
    cc=g.line_pair(n[0],m[5]);ll=g.minus(cc,m[5])
    v=g.plus(g.scale(g.HALF,n[1]),g.scale(exact('-.04'),g.rot(n[1])))
    w=g.minus(v,n[1]);j=lambda p:(-p[0],p[1])
    pp=[cc,ll,v,w]+[tuple(exact(c) for c in p) for p in EXTRA]
    defs={k:list(anchors(k)[0].values()) for k in ('TI','GK','QY')}
    defs['C3']=pp+list(map(j,pp))+[(R(0),exact('.501'))]
    defs['Reuleaux']=[g.line_pair(n[i],n[j]) for i,j in ((0,1),(2,3),(4,5))]
    return defs,{str(x):list(b.anchors(model.D_of(g.SIGMA),exact(F(str(x))))) for x in ['0.435','1.0']}

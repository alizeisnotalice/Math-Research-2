from pathlib import Path
from hashlib import sha256
import json,sys,flint
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from check import main as positive
from separation import run as separate
from verify_slim import run as negative
from check_mixtures import run as mixtures
def main():
 for name,digest in json.loads((ROOT/'MANIFEST.json').read_bytes()).items():
  assert sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 comp=ROOT/'upstream';results={}
 jobs=[('check',lambda:positive(comp)),('separation',lambda:separate(comp)),
       ('slim',lambda:negative(comp,ROOT/'cut195-base.json',ROOT/'slimdata.json')),
       ('mixtures',lambda:mixtures(ROOT/'host.json',ROOT/'clouds.json.gz',ROOT/'fits.json'))]
 for name,method in jobs:
  actual=method();raw=(ROOT/(name+'.json')).read_bytes();assert actual==json.loads(raw),name
  results[name]=sha256(raw).hexdigest()
 print(json.dumps(dict(python=sys.version.split()[0],flint=flint.__version__,verified=results),indent=2))
if __name__=='__main__':main()

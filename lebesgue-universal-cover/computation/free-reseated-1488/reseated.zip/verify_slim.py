from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json,sys
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent;Q=10**12;DEN=10**12
def ar(x):return R(x.numerator)/x.denominator
def run(comp,poly,data):
 sys.path.insert(0,str(comp))
 from deformed_reuleaux_support import environment,body
 ns=environment(str(comp),'1.5497');ctx.prec=160
 d=json.loads(data.read_bytes());p=d['input'];pts=p['points'];assert p['scale']==Q and p['j']==11
 c=json.loads((comp/'finite-b-core/host-poses.json').read_bytes())['poses'][11]
 V,_=body(ns,F(c['w']),F(c['e']));m=min((1-(R(x)/Q-a)**2-(R(y)/Q-b)**2).lower() for x,y in pts for a,b in V)
 assert m>0
 d2=max((x-X)**2+(y-Y)**2 for (x,y),(X,Y) in combinations(pts,2));assert d2<Q*Q
 assert sha256(poly.read_bytes()).hexdigest()=='404124c87509655dcbb58119a2d31b41f16d4c138e5c6976b513c7df18f61271'
 assert all(x*x+y*y<Q*Q for x,y in pts)
 k=F('1.0000008');S=Q*k.denominator
 W=[(x*k.numerator,y*k.numerator) for x,y in json.loads(poly.read_bytes())]
 N=[(v-y,x-u) for (x,y),(u,v) in zip(W,W[1:]+W[:1])]
 H=[nx*x+ny*y for (nx,ny),(x,y) in zip(N,W)]
 assert all(h>0 and 4*h*h>=S*S*(nx*nx+ny*ny) for h,(nx,ny) in zip(H,N))
 A0=F(sum(x*v-y*u for (x,y),(u,v) in zip(W,W[1:]+W[:1])),2*S*S)
 intervals={s:[] for s in (-1,1)};floor=R(1)
 for s,l,r,rows in d['boxes']:
  assert s in intervals;l,r=F(l),F(r);assert 0<=l<r<=360
  coeff1=coeff2=off=rx=ry=0;seen=set()
  for edge,w,j in rows:
   assert 0<=edge<len(N) and edge not in seen and 0<w<=DEN and 0<=j<len(pts)
   seen.add(edge);x,y=pts[j];nx,ny=N[edge]
   coeff1+=w*(nx*x+s*ny*y);coeff2+=w*(-nx*y+s*ny*x)
   off+=w*H[edge];rx+=w*nx;ry+=w*ny
  def trig(t):return coeff1*t.cos()+coeff2*t.sin()
  u,v=ar(l)*R.pi()/180,ar(r)*R.pi()/180
  assert trig(u.union(v))>0
  gap=min(trig(u).lower(),trig(v).lower())/(2*S*Q*DEN)-R(off)/(2*S*S*DEN)-R(4*(abs(rx)+abs(ry)))/(2*S*DEN)
  assert gap>R('0.00000183013')
  floor=min(floor,gap.lower());intervals[s].append((l,r))
 for s,pieces in intervals.items():
  end=F(0)
  for l,r in sorted(pieces):assert l==end;end=r
  assert end==360
 return dict(j=11,parameters=[c['w'],c['e']],rational_points=len(pts),diameter_sq=str(F(d2,Q**2)),inside_margin=str(m),
  leaves=[len(intervals[s]) for s in (-1,1)],gain_beyond_D=str(floor),absolute_lower=str(ar(A0+F('.00000183013'))))
if __name__=='__main__':print(json.dumps(run(*[Path(x).resolve() for x in sys.argv[1:]]),indent=2))

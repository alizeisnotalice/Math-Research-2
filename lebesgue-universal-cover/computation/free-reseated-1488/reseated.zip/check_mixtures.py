from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
import math,json,gzip,sys
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent
def A(x):
 q=F(str(x));return R(q.numerator)/q.denominator
def rot(u,c,s):return c*u[0]-s*u[1],s*u[0]+c*u[1]
def dot(p,q):return p[0]*q[0]+p[1]*q[1]
def hull(z):
 q=sorted(set(map(tuple,z)))
 def half(x):
  v=[]
  for p in x:
   while len(v)>=2 and (v[-1][0]-v[-2][0])*(p[1]-v[-2][1])<=(v[-1][1]-v[-2][1])*(p[0]-v[-2][0]):v.pop()
   v.append(p)
  return v[:-1]
 return half(q)+half(q[::-1])
def regular(n,phase):
 radius=1/(2*(R.pi()/(2*n)).cos())
 vertices=[(radius*(phase+2*R.pi()*j/n).cos(),radius*(phase+2*R.pi()*j/n).sin()) for j in range(n)]
 def calc(u):
  vals=[dot(v,u).upper() for v in vertices]
  for v in vertices:
   t=v[0]+u[0],v[1]+u[1]
   if all(not (t[0]-a)**2+(t[1]-b)**2>1 for a,b in vertices):vals.append((1+dot(v,u)).upper())
  return max(vals)
 return calc
def cloud(points,scale):
 p=hull(points)
 assert p==list(map(tuple,p))
 diameter=max((x-a)**2+(y-b)**2 for (x,y),(a,b) in combinations(p,2));assert diameter<scale**2
 edges=[math.atan2(x-u,v-y) for (x,y),(u,v) in zip(p,p[1:]+p[:1])]
 start=edges[0];alpha=[(t-start)%(2*math.pi) for t in edges]
 assert all(x<y for x,y in zip(alpha,alpha[1:]))
 from bisect import bisect_right
 def support(u):
  i=bisect_right(alpha,(math.atan2(float(u[1]),float(u[0]))-start)%(2*math.pi))%len(p)
  a=p[i];b=p[i-1];c=p[(i+1)%len(p)]
  if dot((a[0]-b[0],a[1]-b[1]),u)>0 and dot((a[0]-c[0],a[1]-c[1]),u)>0:return dot(a,u)/scale
  return max(dot(v,u).upper() for v in p)/scale
 return support,diameter
def run(host,pointdata,proposals):
 ctx.prec=160
 poly=json.loads(host.read_bytes());assert sha256(host.read_bytes()).hexdigest()=='781e9521a22be3543d2ca4776a04108c7dea9af85a5952de35401bf21630e97e'
 rows=json.loads(proposals.read_bytes())
 data=json.loads(gzip.decompress(pointdata.read_bytes()));unit=data['scale']
 specs={int(k):cloud(v,unit) for k,v in data['points'].items()};diam=max(x[1] for x in specs.values())
 placed=[]
 for row in rows:
  _,hand,t,tx,ty=row['proposal'];t=A(t);tx=A(tx);ty=A(ty);sc,ss=t.cos(),-t.sin();assert hand in (-1,1)
  v=row['values']
  if row['kind']=='regular':
   co=list(map(lambda x:F(str(x)),v[:5]));z=sum(co);co=[A(str(c/z)) for c in co];assert all(c>=0 for c in co)
   terms=[regular(3+2*k,A(p)) for k,p in enumerate(v[5:])]
   def fn(u):return co[0]/2+sum(c*f(u) for c,f in zip(co[1:],terms))
  else:
   aa,bb,one,two,pa,pb=v;aa,bb=F(str(aa)),F(str(bb));z=aa+bb;aa,bb=A(str(aa/z)),A(str(bb/z));assert aa>=0 and bb>=0
   one,two=specs[int(one)][0],specs[int(two)][0];pa,pb=A(pa),A(pb)
   ac,ac2=pa.cos(),pb.cos();si,si2=-pa.sin(),-pb.sin()
   def fn(u):return aa*one(rot(u,ac,si))+bb*two(rot(u,ac2,si2))
  slack=R(1)
  for (x,y),(u,v) in zip(poly,poly[1:]+poly[:1]):
   nx,ny=v-y,x-u;length=R(nx*nx+ny*ny).sqrt();normal=R(nx)/length,R(ny)/length
   wx,wy=rot(normal,sc,ss)
   h=fn((wx,hand*wy))+dot((tx,ty),normal)
   b=R(nx*x+ny*y)/(10**12*length)
   margin=(b-h).lower();assert margin>0,(row['kind'],row['index'],str(margin))
   slack=min(slack,margin)
  placed.append(dict(kind=row['kind'],index=row['index'],minimum_margin=str(slack)))
 return dict(boundary_sides=len(poly),all_14_placements=placed,maximum_cloud_diameter_squared=str(F(diam,unit**2)),
             minimum_overall=str(min(R(z['minimum_margin']).lower() for z in placed)))
if __name__=='__main__':print(json.dumps(run(*[Path(v).resolve() for v in sys.argv[1:]]),indent=2))

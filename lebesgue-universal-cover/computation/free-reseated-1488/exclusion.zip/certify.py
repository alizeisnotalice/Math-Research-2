import json, math, itertools
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import numpy as np
from scipy.optimize import linprog
import sympy as sp
V=json.loads(Path('host.json').read_text());m=len(V);assert m==1488
assert all(abs(x)<=10**12 and abs(y)<=10**12 for x,y in V)
D=[(V[(i+1)%m][0]-V[i][0],V[(i+1)%m][1]-V[i][1]) for i in range(m)]
N=[(dy,-dx) for dx,dy in D];H=[F(nx*x+ny*y,10**12) for (nx,ny),(x,y) in zip(N,V)]
assert all(D[i][0]*D[(i+1)%m][1]-D[i][1]*D[(i+1)%m][0]>0 for i in range(m))
def clip(poly,q,h):
 out=[]
 for p,r in zip(poly,poly[1:]+poly[:1]):
  a=q[0]*p[0]+q[1]*p[1]-h;b=q[0]*r[0]+q[1]*r[1]-h
  if a<=0:out.append(p)
  if (a<0 and b>0) or (a>0 and b<0):out.append(((p[0]*b-r[0]*a)/(b-a),(p[1]*b-r[1]*a)/(b-a)))
 return out

def run(name,hand):
 data=json.loads(Path(name+'.json').read_text());Q=data['denominator'];X=[(F(x,Q),F(hand*y,Q)) for x,y in data['points']]; assert max((x-x1)**2+(y-y1)**2 for x,y in X for x1,y1 in X)>F(1,4)
 norms=np.array(N,float);norms/=np.linalg.norm(norms,axis=1)[:,None]; xf=np.array([(float(x),float(y)) for x,y in X]);bn=np.array([float(h)/math.hypot(*n) for h,n in zip(H,N)])
 rows=[]
 for x,y in xf:
  rows.append(np.column_stack((norms,norms[:,0]*x+norms[:,1]*y,-norms[:,0]*y+norms[:,1]*x)))
 A=np.vstack(rows);B=np.tile(bn,len(X));
 def exact_row(idx):
  p,f=divmod(idx,m);x,y=X[p];a,b=N[f];return (F(a),F(b),a*x+b*y,-a*y+b*x),H[f]
 def support(q):
  scale=math.hypot(*q);qf=[float(q[0])/scale,float(q[1])/scale];
  r=linprog([0,0,-qf[0],-qf[1]],A_ub=A,b_ub=B,bounds=[(None,None)]*4,method='highs',options={'dual_feasibility_tolerance':1e-10,'primal_feasibility_tolerance':1e-10})
  if not r.success:raise RuntimeError(r.message)
  ids=np.flatnonzero(r.ineqlin.marginals < -1e-11).tolist()
  if len(ids)!=4:raise RuntimeError(('nonstandard basis',q,ids))
  rr=[exact_row(i) for i in ids]; M=sp.Matrix([[sp.Rational(z.numerator,z.denominator) for z in row] for row,_ in rr]);qv=sp.Matrix([0,0,int(q[0]),int(q[1])]);
  try: lam=M.T.inv()*qv
  except Exception as e:raise RuntimeError(('singular',ids)) from e
  if any(x<0 for x in lam):raise RuntimeError(('negative exact dual',q,ids,list(map(str,lam))))
  lam=[F(int(x.p),int(x.q)) for x in lam];h=sum(w*bb for w,(_,bb) in zip(lam,rr));return h,dict(q=list(q),ids=ids,weights=list(map(str,lam)),bound=str(h))
 poly=[(F(-10),F(-10)),(F(10),F(-10)),(F(10),F(10)),(F(-10),F(10))]; cert=[]
 for i in range(500):
  p=max(poly,key=lambda v:v[0]**2+v[1]**2); r2=p[0]**2+p[1]**2
  if r2<1:break
  norm=math.hypot(float(p[0]),float(p[1]));q=(round(float(p[0])/norm*10**8),round(float(p[1])/norm*10**8));h,c=support(q);new=clip(poly,q,h)
  if len(new)<3 or new==poly:raise RuntimeError(('bad clip',i))
  poly=new;cert.append(c)
  print(name,hand,i+1,'faces',len(poly),'r2',float(r2),'bound',float(h)/math.hypot(*q),flush=True)
 else:raise RuntimeError('max iterations')
 Path(f'{name}-hand{hand}-cert.json').write_text(json.dumps(dict(input=name,hand=hand,host_sha=sha256(Path('host.json').read_bytes()).hexdigest(),input_sha=sha256(Path(name+'.json').read_bytes()).hexdigest(),cuts=cert,vertices=[[str(x),str(y)] for x,y in poly],max_r2=str(max(x*x+y*y for x,y in poly)),complete=True),indent=2)+'\n')
 print('PASS',name,hand,len(cert),'radius',math.sqrt(float(max(x*x+y*y for x,y in poly))),flush=True)
for name in ('input14','input10'):
 for hand in (1,-1):run(name,hand)

#!/usr/bin/env python3
"""Verify rational LP-dual outer projections for both hands and both inputs."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,sys
V=json.loads(Path('host.json').read_bytes()); n=len(V); assert n==1488 and len(set(map(tuple,V)))==n
assert all(abs(x)<=10**12 and abs(y)<=10**12 for x,y in V)
D=[(V[(i+1)%n][0]-V[i][0],V[(i+1)%n][1]-V[i][1]) for i in range(n)];assert all(dx or dy for dx,dy in D)
# Each oriented edge must contain every listed host vertex in its left half-plane.
for i,(dx,dy) in enumerate(D):
 x,y=V[i]; assert all(dx*(v-y)-dy*(u-x)>=0 for u,v in V),i
N=[(dy,-dx) for dx,dy in D]; H=[F(nx*x+ny*y,10**12) for (nx,ny),(x,y) in zip(N,V)]
def digest(p):return sha256(Path(p).read_bytes()).hexdigest()
def clip(poly,q,h):
 out=[]
 for p,r in zip(poly,poly[1:]+poly[:1]):
  a=q[0]*p[0]+q[1]*p[1]-h;b=q[0]*r[0]+q[1]*r[1]-h
  if a<=0:out.append(p)
  if (a<0 and b>0) or (a>0 and b<0):out.append(((p[0]*b-r[0]*a)/(b-a),(p[1]*b-r[1]*a)/(b-a)))
 return out
out=[]; comparisons=[]
for name in ('input10','input14'):
 path=Path(name+'.json');data=json.loads(path.read_bytes());Q=data['denominator']; pts=data['points'];assert len(pts)==(10 if name=='input10' else 14)
 ds=max((a-c)**2+(b-d)**2 for (a,b),(c,d) in combinations(pts,2));assert Q*Q>ds>Q*Q//4
 frozen=Path('frozen'+name[5:]+'.json'); fd=json.loads(frozen.read_bytes());assert fd['denominator']==Q and fd['points']==pts
 comparisons.append(dict(input=name,frozen_sha256=digest(frozen),count=len(pts),common_denominator=Q,all_coordinates_equal=True))
 unionfaces=set()
 for hand in (1,-1):
  cert=json.loads(Path(f'{name}-hand{hand}-cert.json').read_bytes()); assert cert['complete'] and cert['hand']==hand and cert['input']==name
  assert cert['host_sha']==digest('host.json') and cert['input_sha']==digest(path)
  X=[(F(x,Q),F(hand*y,Q)) for x,y in pts]
  def row(idx):
   p,f=divmod(idx,n);assert p<len(X);x,y=X[p];a,b=N[f];return (F(a),F(b),a*x+b*y,-a*y+b*x),H[f]
  poly=[(F(-10),F(-10)),(F(10),F(-10)),(F(10),F(10)),(F(-10),F(10))]
  allfacets=set();allpoints=set()
  for cut in cert['cuts']:
   q=cut['q'];idx=cut['ids'];w=list(map(F,cut['weights'])); assert len(q)==2 and len(idx)==len(w)==4 and all(x>=0 for x in w) and (q[0] or q[1])
   pairs=[row(i) for i in idx]; actual=[sum(lam*vec[j] for lam,(vec,_) in zip(w,pairs)) for j in range(4)]; assert actual==[0,0,*q]
   h=sum(lam*bh for lam,(_,bh) in zip(w,pairs));assert h==F(cut['bound'])
   poly=clip(poly,q,h);assert len(poly)>=3
   for i in idx:p,f=divmod(i,n);allpoints.add(p);allfacets.add(f);unionfaces.add(f)
  vertices=[[str(x),str(y)] for x,y in poly];assert vertices==cert['vertices']
  r2=max(x*x+y*y for x,y in poly);assert r2==F(cert['max_r2']) and r2<1
  bound=F('0.999996443') if name=='input14' else (F('0.999999906') if hand==1 else F('0.999999901'));assert r2<bound*bound
  out.append(dict(input=name,hand=hand,cut_count=len(cert['cuts']),active_input_points=len(allpoints),active_host_faces=len(allfacets),diameter_squared=str(F(ds,Q*Q)),max_radius_squared=str(r2),one_minus_radius_squared=str(1-r2),certified_radius_upper=str(bound),upper_radius_decimal=round(float(r2)**.5,12),certificate_sha256=digest(f'{name}-hand{hand}-cert.json')))
 # The selected sparse outer host is itself inside (-1,1)^2.
 sparse=[(F(-10),F(-10)),(F(10),F(-10)),(F(10),F(10)),(F(-10),F(10))]
 for f in sorted(unionfaces):sparse=clip(sparse,N[f],H[f]);assert len(sparse)>=3
 sparse_max=max(max(abs(x),abs(y)) for x,y in sparse);assert sparse_max<1
 comparisons[-1].update(sparse_face_indices=sorted(unionfaces),sparse_face_count=len(unionfaces),sparse_max_coordinate=str(sparse_max),sparse_vertices=len(sparse))
print(json.dumps(dict(complete=True,method='exact rational dual and convex polygon clipping; both hands; all rotations/translations',host_sha256=digest('host.json'),host_vertices=n,comparisons=comparisons,rows=out,python=sys.version),indent=2))

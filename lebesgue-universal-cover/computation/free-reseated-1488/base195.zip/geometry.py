from fractions import Fraction as F
from pathlib import Path
from flint import arb as R,ctx
import json,sys
S=10**14
def signcross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(ps):
 p=sorted(set(ps))
 def half(x):
  v=[]
  for z in x:
   while len(v)>=2 and signcross(v[-2],v[-1],z)<=0:v.pop()
   v.append(z)
  return v[:-1]
 return half(p)+half(p[::-1])
def area(p):return F(sum(x*v-y*u for (x,y),(u,v) in zip(p,p[1:]+p[:1])),2*S*S)
def clip(p,n,b):
 q=[];level=lambda a:n[0]*a[0]+n[1]*a[1]-b
 for x,y in zip(p,p[1:]+p[:1]):
  a,c=level(x),level(y)
  if a<=0:q.append(x)
  if a*c<0:q.append(tuple((a*w-c*v)/(a-c) for v,w in zip(x,y)))
 return q
def unit(t):return t.cos(),t.sin()
def host(path):
 ctx.prec=160
 z=json.loads(path.read_bytes());V=[(F(x,z['full_W_polygon_scale']),F(y,z['full_W_polygon_scale'])) for x,y in z['full_W_outer_vertices']]
 assert all(x*x+y*y<1 for x,y in V)
 inn=V[:];out=V[:]
 for s in [R(j*60) for j in range(6)]+[R('211.54'),R('331.54')]:
  v=unit(s*R.pi()/180)
  n=tuple(round(float(a*S)) for a in v)
  assert all(abs(a*S-b)<R('.51') for a,b in zip(v,n))
  inn=clip(inn,n,S//2-2);out=clip(out,n,S//2+2)
 def bins(p,outer):
  if outer:return hull([(round(x*S)+a,round(y*S)+b) for x,y in p for a in [-1,1] for b in [-1,1]])
  return hull([(round(x*(S-4)),round(y*(S-4))) for x,y in p])
 # The inset polygon contains the radius .49 disk; radial shrink leaves > 1.9/S clearance.
 for p,q in zip(inn,inn[1:]+inn[:1]):
  if p==q:continue
  cr=p[0]*q[1]-p[1]*q[0]
  assert cr>0 and cr*cr>F(49,100)**2*((p[0]-q[0])**2+(p[1]-q[1])**2)
 return bins(inn,False),bins(out,True)
def source(comp,index):
 sys.path.insert(0,str(comp))
 from deformed_reuleaux_support import body,environment
 from certify_nonideal_pentagon_pose_library import verify
 cfg=json.loads((comp/'finite-b-core/host-poses.json').read_bytes())['poses'][index]
 assert cfg['index']==index
 w,e=map(F,[cfg['w'],cfg['e']])
 ns=environment(str(comp),'1.5497');ctx.prec=160
 v,f=body(ns,w,e)
 return ns,v,f,cfg,lambda:verify(ns,w,e,F(0),F(0))
def tran(p,t,sg):
 c,s=unit(t);x,y=p
 return c*x-s*y,sg*(s*x+c*y)
def true_samples(ns,v,count):
 # All 10 adjacent edge-normal sectors are shorter than pi.
 E=[ns['sub'](v[i],v[j]) for i,j in ns['orders']]
 p=list(v);gaps=[]
 for k,(i,mode) in enumerate(ns['sector']):
  if mode==0:continue
  a=E[k];b=E[(k+1)%10]
  assert mode==1 and ns['cross'](a,b)>0
  ang=R.atan2(ns['cross'](a,b),ns['dot'](a,b));gaps.append(ang)
  for j in range(count+1):
   t=ang*j/count;c,s=unit(t)
   p.append((v[i][0]+a[0]*c-a[1]*s,v[i][1]+a[0]*s+a[1]*c))
 return p,max(x.upper() for x in gaps)
def outer_inner(p,step=None):
 mids=[tuple(round(float(z*S)) for z in a) for a in p]
 assert all(abs(z*S-k)<R('.52') for a,b in zip(p,mids) for z,k in zip(a,b))
 # For true input support samples, convex hull with host contains centered .49 disk in outer-space coordinates.
 inn=hull([(round(F(x)*(1-F(4,S))),round(F(y)*(1-F(4,S)))) for x,y in mids])
 pad=1 if step is None else 2+int((S*(1-(step/2).cos())).upper().ceil().unique_fmpz())
 out=hull([(x+a,y+b) for x,y in mids for a in [-pad,pad] for b in [-pad,pad]])
 return inn,out

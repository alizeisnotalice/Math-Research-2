from pathlib import Path
from hashlib import sha256
import json,sys,flint
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from foundation import run as geometry_check
from rectangle import run as family_check
def main():
 root=ROOT
 data=json.loads((root/'MANIFEST.json').read_bytes())
 for name,digest in data.items():
  assert sha256((root/name).read_bytes()).hexdigest()==digest,name
 comp=root/'upstream'
 result={}
 for name,method in [('foundation',geometry_check),('rectangle',family_check)]:
  actual=method(comp);record=(root/(name+'.json')).read_bytes()
  assert actual==json.loads(record),name
  result[name]=sha256(record).hexdigest()
 print(json.dumps(dict(python=sys.version.split()[0],flint=flint.__version__,area=actual['area'],
      geometry_and_family_verified=result,geometry_margins=actual['valid_geometry_margins'],angle_parameter_cells=actual['counts']),indent=2))
if __name__=='__main__':main()

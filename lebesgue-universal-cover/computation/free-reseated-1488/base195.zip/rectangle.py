from pathlib import Path
from fractions import Fraction as F
import sys,json,time
from flint import arb as R,arb_series,ctx
from functools import lru_cache
from collections import Counter
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from legal import check_indices,geometric_margins
def run(comp):
 sys.path.insert(0,str(comp))
 from deformed_reuleaux_support import environment,body
 ns=environment(str(comp),'1.5497');ctx.prec=160
 check_indices(ns);legal_bounds=[R(10)]*4
 def arb(x):return R(x.numerator)/x.denominator
 Q=10**12;factor=F('1.0000008');pc=json.loads((HERE/'outer-polygon.json').read_bytes())
 assert len(pc)==195
 normals=[];offset=[]
 for p,q in zip(pc,pc[1:]+pc[:1]):
  nx,ny=q[1]-p[1],p[0]-q[0];length=R(nx*nx+ny*ny).sqrt()
  normals.append((R(nx)/length,R(ny)/length));offset.append(arb(F(nx*p[0]+ny*p[1],Q)*factor)/length)
 U=[ns['av'](x) for x in ns['d']['n']]
 pin={1:U[0],3:U[1],0:U[2]};dot=ns['dot'];cross=ns['cross'];sub=ns['sub'];J=lambda p:(-p[1],p[0])
 nrot={j:[(dot(q,u),dot(q,J(u))) for q in normals] for j,u in pin.items()}
 base={0:ns['l0'],1:ns['reflection'](ns['l0']),3:ns['mid']}
 axis={0:ns['el'],1:sub(ns['reflection'](ns['add'](ns['l0'],ns['el'])),base[1]),3:ns['en']}
 fixed={j:(dot(base[j],u),dot(axis[j],u)) for j,u in pin.items()}
 @lru_cache(maxsize=10000)
 def corner(w,e):
  return body(ns,arb(w),arb(e))[0]
 def jets(w,e,var):
  ww=arb_series([w,int(var==0)]);ee=arb_series([e,int(var==1)])
  add,mul,ref=ns['add'],ns['mul'],ns['reflection']
  l,t=ns['chart'](add(ns['z'],mul(ww,ns['D'])));pp=ns['psi'](l);t=t-ee
  vv=[add(ns['l0'],mul(l,ns['el'])),ref(add(ns['l0'],mul(pp,ns['el']))),ref(ns['X'](pp,-t)),add(ns['mid'],mul(t,ns['en'])),ns['X'](l,t)]
  return [(2*x[2],2*y[2]) for x,y in vv]
 counts=Counter();records=[];gap=R(1)
 def visit(w0,w1,e0,e1,cand,depth):
  nonlocal gap
  counts['nodes']+=1
  if counts['nodes']%10000==0:print(dict(counts),flush=True,file=sys.stderr)
  wi=arb(w0).union(arb(w1));ei=arb(e0).union(arb(e1))
  try:
   v,_=body(ns,wi,ei);valid=geometric_margins(ns,wi,ei,v)
  except (AssertionError,ArithmeticError):v=None
  local=cand
  if v is not None:
   E=[sub(v[i],v[j]) for i,j in ns['orders']]
   ll,tt=ns['chart'](ns['add'](ns['z'],ns['mul'](wi,ns['D'])))
   pars={0:ll,1:ns['psi'](ll),3:tt-ei}
   fixedproj={j:x+y*pars[j] for j,(x,y) in fixed.items()}
   ppos={j:dot(v[j],J(u)) for j,u in pin.items()}
   local=[]
   for k in cand:
    normal=normals[k];height=offset[k];possible=[]
    for z,(j,arc) in enumerate(ns['sector']):
     if cross(E[z],normal)<0 or cross(normal,E[(z+1)%10])<0:continue
     if j in pin:
      dotnu,detnu=nrot[j][k];proj=fixedproj[j]*dotnu+ppos[j]*detnu
     else:proj=dot(v[j],normal)
     possible.append((proj+arc).upper())
    assert possible
    slack=(height-max(possible)).lower()
    if slack>0:gap=min(gap,slack)
    else:local.append(k)
   if local:
    try:j2=[jets(wi,ei,k) for k in (0,1)]
    except (ValueError,ArithmeticError):j2=None
   if local and j2 is not None:
    corners=[corner(w,e) for w in [w0,w1] for e in [e0,e1]]
    sizes=[arb((w1-w0)**2/8),arb((e1-e0)**2/8)]
    remain=[]
    for k in local:
     u=normals[k];vals=[]
     for z,(j,arc) in enumerate(ns['sector']):
      if cross(E[z],u)<0 or cross(u,E[(z+1)%10])<0:continue
      interp=sum(r*abs(dot(vec[j],u)).upper() for r,vec in zip(sizes,j2))
      cv=max(dot(a[j],u).upper() for a in corners)
      vals.append((cv+arc+interp).upper())
     assert vals
     slack=(offset[k]-max(vals)).lower()
     if slack>0:gap=min(slack,gap)
     else:remain.append(k)
    local=remain
   if not local:
    for j,z in enumerate(valid):legal_bounds[j]=min(legal_bounds[j],z)
    counts['leaves']+=1;counts['depth']=max(counts['depth'],depth)
    records.append([str(w0),str(w1),str(e0),str(e1)]);return
  if depth>=28:
   raise RuntimeError((str(w0),str(w1),str(e0),str(e1),local))
  if (w1-w0)/5>=e1-e0:
   m=(w0+w1)/2;visit(w0,m,e0,e1,local,depth+1);visit(m,w1,e0,e1,local,depth+1)
  else:
   m=(e0+e1)/2;visit(w0,w1,e0,m,local,depth+1);visit(w0,w1,m,e1,local,depth+1)
 args=sys.argv[2:] or ['.17','1.08','-.020','.14']
 visit(*map(F,args),list(range(len(normals))),0)
 area=F(sum(x*b-y*a for (x,y),(a,b) in zip(pc,pc[1:]+pc[:1])),2*Q*Q)*factor**2
 target=F('.844082046521218581802948589770767704354');assert area<target
 return dict(w=[args[0],args[1]],e=[args[2],args[3]],placement='identity, zero translation',area=str(area),
             decimal=str(arb(area)),B_minus_area=str(arb(target-area)),counts=counts,valid_geometry_margins=list(map(str,legal_bounds)),least_proved_normal_slack=str(gap))
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]).resolve()),indent=2))

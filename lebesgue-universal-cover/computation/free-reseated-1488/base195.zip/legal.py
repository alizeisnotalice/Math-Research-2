"""Certify the genuine single-turn normal fan of the marked unit-width pentagon."""
from flint import arb as R
ORD=((2,1),(2,3),(4,3),(4,0),(1,0),(1,2),(3,2),(3,4),(0,4),(0,1))
SEC=((2,0),(3,1),(4,0),(0,1),(1,0),(2,1),(3,0),(4,1),(0,0),(1,1))
def check_indices(ns):
 assert tuple(map(tuple,ns['orders']))==ORD and tuple(map(tuple,ns['sector']))==SEC
 for j,((a,b),(v,m)) in enumerate(zip(ORD,SEC)):
  assert ORD[(j+5)%10]==(b,a) and SEC[(j+5)%10]==(v,1-m)
  k,l=SEC[j-1]
  assert all(int(q==v)-int(q==k)+(m-l)*(int(q==a)-int(q==b))==0 for q in range(5))
def geometric_margins(ns,w,e,V):
 dot,sub,add,mul,cross=(ns[k] for k in ('dot','sub','add','mul','cross'))
 x=add(ns['z'],mul(w,ns['D']))
 margins=[1-(dot(n,x)-R('.5'))**2 for n in (ns['nl'],ns['nn'])]
 ll,tt=ns['chart'](x);tt-=e
 L=add(ns['l0'],mul(ll,ns['el']))
 margins.append(1-(L[0]+R('.5'))**2)
 pp=ns['psi'](ll)
 for ab,tt0 in ((ll,tt),(pp,-tt)):
  y=sub(add(ns['l0'],mul(ab,ns['el'])),add(ns['mid'],mul(tt0,ns['en'])))
  y2=dot(y,y);margins.extend([y2,4-y2])
 edge=[sub(V[i],V[j]) for i,j in ORD]
 assert all(dot(a,a).contains(1) for a in edge)
 turns=[cross(a,edge[(i+1)%10]) for i,a in enumerate(edge)]
 half=[cross(edge[0],v) for v in edge[1:5]]
 nonstar=[1-dot(delta,delta) for i in range(5) for j in range(i) if (i,j) not in ORD for delta in [sub(V[i],V[j])]]
 vals=[min(k.lower() for k in group) for group in (margins,turns,half,nonstar)]
 assert all(z>0 for z in vals)
 return vals

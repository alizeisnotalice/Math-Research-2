"""Verify one rational polygon and its placements by testing its actual sides."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
from hashlib import sha256
import sys,json,gzip
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import host,S,clip,hull
from legal import check_indices,geometric_margins
Q=10**12
NX,NY=-406736643076,913545457643
BETA=516144500000
def ball(x):return R(x.numerator)/x.denominator
def run(comp):
 sys.path.insert(0,str(comp))
 from deformed_reuleaux_support import body,environment
 ns=environment(str(comp),'1.5497');ctx.prec=160
 check_indices(ns);legal_bounds=[R(10)]*4
 d=json.loads(gzip.decompress((HERE/'material.json.gz').read_bytes()));assert d['scale']==Q
 hashfield=lambda key:sha256(json.dumps(d[key],sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert hashfield('small')=='986972d0f12c164e464126a6c8bc87fd12688158bd8a466eedbd6f25c61fe8f3'
 assert hashfield('core')=='db12e807909185ab3d2ef587e0f8a1ac248013d929faab84c1caf2bef80cc9a8'
 oldrows=json.loads((comp/'finite-b-core/host-poses.json').read_bytes())['poses']
 assert all(i==oldrows[i]['index'] and F(w)==F(oldrows[i]['w']) and F(e)==F(oldrows[i]['e']) for i,w,e,s in d['pentagons'])
 wp=HERE/'W-source.json';assert sha256(wp.read_bytes()).hexdigest()=='4b129d3aa5a199400ee426f1e4bd12396dddc657e5f355a7e601a152a1cd2add'
 p=[tuple(a) for a in json.loads((HERE/'outer-polygon.json').read_bytes())]
 assert p==hull(p)
 area=F(sum(x*b-y*a for (x,y),(a,b) in zip(p,p[1:]+p[:1])),2*Q*Q)
 sides=[(q[1]-a[1],a[0]-q[0],a) for a,q in zip(p,p[1:]+p[:1])]
 planes=[(nx,ny,nx*x+ny*y) for nx,ny,(x,y) in sides]
 assert all(c>0 and 4*c*c>=(nx*nx+ny*ny)*Q*Q for nx,ny,c in planes)
 assert all(10**6*(x*x+y*y)<581**2*Q**2 for x,y in p)
 _,wo=host(wp);wc=clip([(F(x*Q,S),F(y*Q,S)) for x,y in wo],(NX,NY),Q*BETA)
 assert all(nx*x+ny*y<=c for x,y in wc for nx,ny,c in planes)
 old=json.loads(wp.read_bytes())
 extra=old['core_homothety_extra_over_scale']
 corehi=F(max(NX*x+NY*y for tag,x,y in d['core'])*(Q+extra),Q**3)+F(2*(abs(NX)+abs(NY)),Q**2)
 assert corehi<F(BETA,Q)
 sq=R(3).sqrt();ref=lambda p:((-p[0]+sq*p[1])/2,(sq*p[0]+p[1])/2)
 n=(R(NX)/Q,R(NY)/Q);dot=ns['dot']
 assert dot(n,n)<R('1.000000000002')**2
 z=(sq-1)/2,(1-sq)/2;amax=R(-1)
 for t in range(340):
  a=(R(116)+R(2*t+1)/20)*R.pi()/180;delta=R.pi()/3600
  p0=(z[0]+a.cos(),z[1]+a.sin());v=(-a.sin(),a.cos())
  for f in [ref,lambda p:p]:
   h=dot(f(p0),n)+abs(dot(f(v),n))*delta+R('1.000000000002')*delta**2/2
   amax=max(amax,h.upper())
 assert amax<R(BETA)/Q
 maxdiam=0;total=0
 for j,pts in d['points'].items():
  small=d['small'][j];assert set(map(tuple,small))<=set(map(tuple,pts))
  maxdiam=max(maxdiam,max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(pts,2)))
  dx=500000 if j=='32' else 0
  assert all(nx*(x+dx)+ny*y<=c for x,y in pts for nx,ny,c in planes)
  total+=len(pts)
 assert maxdiam<Q*Q
 xescape=F(max(x for x,y in d['small']['32'])+500000,Q);assert xescape>F('.50000049')
 dirs=[]
 for nx,ny,c in planes:
  ell=R(nx*nx+ny*ny).sqrt()
  u=R(nx)/ell,R(ny)/ell;dirs.append((u,ref(u),R(c)/(Q*ell)))
 delta=R(0);margin=R(1)
 for j,w,e,s in d['pentagons']:
  w,e=ball(F(w)),ball(F(e))
  V,h=body(ns,w,e)
  for a,b,c in dirs:
   gap=c-h(b if s else a);assert gap>0,(j,a,b,gap);margin=min(margin,gap.lower())
  t=R('1e-8');Vb,_=body(ns,(w-t).union(w+t),(e-t).union(e+t))
  for k,z0 in enumerate(geometric_margins(ns,(w-t).union(w+t),(e-t).union(e+t),Vb)):legal_bounds[k]=min(legal_bounds[k],z0)
  assert all(dot(v,v)<R('.6')**2 for v in V+Vb)
  delta=max(delta,max((sum(abs(x-y).upper()**2 for x,y in zip(v,vb))).sqrt().upper() for v,vb in zip(V,Vb)))
 scale=F('1.0000008');assert 4*delta<ball((scale-1)/2)
 upper=area*scale**2;target=F('.844082046521218581802948589770767704354')
 assert upper<target
 return dict(vertices=len(p),trim_direction=[NX,NY],trim_height=BETA,denominator=Q,retained_core_support_upper=str(corehi),
   retained_twin_arc_support_upper=str(amax),true_x_coordinate=str(xescape),dense_points=total,
   max_diameter_squared=str(F(maxdiam,Q*Q)),five_arc_count=len(d['pentagons']),minimum_support_slack=str(margin),legal_geometry_margins=list(map(str,legal_bounds)),
   xy_parameter_halfwidth='1e-8',maximum_vertex_displacement=str(delta),base_area=str(area),host_homothety=str(scale),
   expanded_area=str(upper),decimal_expanded_area=str(ball(upper)),gap_below_B=str(ball(target-upper)),polygon_sha256=sha256((HERE/'outer-polygon.json').read_bytes()).hexdigest())
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]).resolve()),indent=2))

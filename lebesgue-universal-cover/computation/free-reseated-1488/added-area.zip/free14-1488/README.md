# Free convex expansion of the fixed 1488-face host by fourteen points

For the rational polygon in host.json and the rational 14-point set in frozen14.json, every compact convex C containing the polygon and an arbitrary rigid (translation, rotation, reflection) copy of the points has

    area(C) - area(host) > 87/100000000.

This is a lower bound, not the exact minimum. A body containing an additional independently placed point set still satisfies this same lower bound; it does not follow that separate single-input bounds add.

Run with Python 3.13.18 and python-flint 0.9.0 (Arb 192-bit precision):

    python -I -B verify.py OUTPUT.json

The fixed input SHA is checked against frozen14.json and every coordinate is matched. The host SHA is fixed; exact integer checks verify 1488 distinct vertices and that every vertex lies in every oriented edge half-plane. The point-set diameter is strictly below 1 by integer squared distances. The verification requires no scipy and does not use the search code.

For each edge define N=(dy,-dx) and h=N·v. Area mixed-volume monotonicity yields twice the increase at least sum_i (N_i·t + max_p N_i·R p − h_i)_+. Every certificate row fixes nonnegative rational weights at most 1, exact sum_i a_i N_i=0, and a chosen point for each nonzero weight. Thus the sum of these chosen deficits divided by two is a lower bound independent of translation. On each closed angular interval the weights and chosen material points are fixed. Its value is c cos θ+s sin θ−H, where H>0 because the origin lies strictly inside each polygon edge. If endpoints exceed L, sine interpolation on intervals of length <π implies the entire interval exceeds L. Both hands have 77 rational-degree intervals whose consecutive endpoints cover [0,360]. Every endpoint inequality is computed with directed Arb intervals.

The certificate was obtained using floating-point linear programming only as a proposal; all bounds, balance, data, and end-to-end cover are checked by the independent exact/interval verifier. The lowest certified endpoint is >8.70236116894e-7 for both hands. Root provenance: host SHA-256 781e9521a22be3543d2ca4776a04108c7dea9af85a5952de35401bf21630e97e, frozen input SHA-256 094f82ef1aadcc677dd4e547f15c1a1fb43a84f8a7a11c3d161c7221a79ace4b.

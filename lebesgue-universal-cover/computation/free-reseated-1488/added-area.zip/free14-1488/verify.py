"""Exact dual plus directed trigonometry: free rigid placements in polygon."""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=192
ROOT=Path(__file__).resolve().parent
H='781e9521a22be3543d2ca4776a04108c7dea9af85a5952de35401bf21630e97e'
I='094f82ef1aadcc677dd4e547f15c1a1fb43a84f8a7a11c3d161c7221a79ace4b'
assert hashlib.sha256((ROOT/'host.json').read_bytes()).hexdigest()==H
# input14.json from helly has extra metadata; exact values tied to frozen source.
source=json.loads((ROOT/'input14.json').read_bytes()); assert source['count']==14 and source['denominator']==10**16
frozen=(ROOT/'frozen14.json').read_bytes();assert hashlib.sha256(frozen).hexdigest()==I
frozen_data=json.loads(frozen);assert frozen_data['points']==source['points'] and frozen_data['denominator']==source['denominator']
vertices=json.loads((ROOT/'host.json').read_bytes());P=source['points'];D=10**12;E=10**16
assert len(vertices)==1488 and len(P)==14 and len(set(map(tuple,vertices)))==1488
assert all(type(z) is int for p in vertices+P for z in p)
assert max((x-u)**2+(y-v)**2 for x,y in P for u,v in P)<E**2
norm=[];hs=[]
for i,(x,y) in enumerate(vertices):
 a,b=vertices[(i+1)%len(vertices)];nx,ny=b-y,x-a;h=nx*x+ny*y
 assert (nx,ny)!=(0,0) and h>0
 assert all(nx*u+ny*v<=h for u,v in vertices)
 norm.append((nx,ny));hs.append(h)
def A(q):return arb(q.numerator)/q.denominator
summary={}
for hand in (1,-1):
 leaves=json.loads((ROOT/f'cert14-{hand}.json').read_bytes()); end=F(0);worst=None;where=None
 for leaf in leaves:
  l,r=map(F,leaf['degrees']);assert l==end and 0<r-l<180;end=r
  sx=sy=F(0);cc=ss=hh=F(0); seen=set()
  for i,a,k in leaf['rows']:
   assert type(i) is int and 0<=i<len(vertices) and i not in seen and type(k) is int and 0<=k<14
   seen.add(i);a=F(a);assert 0<a<=1
   nx,ny=norm[i];x,y=P[k];y*=hand
   sx+=a*nx;sy+=a*ny
   cc+=a*(nx*x+ny*y);ss+=a*(-nx*y+ny*x);hh+=a*hs[i]
  assert sx==0 and sy==0 and hh>0
  c=A(cc/F(2*D*E));s=A(ss/F(2*D*E));h=A(hh/F(2*D*D))
  vals=[]
  for t in (l,r):
   sn,co=(A(t)*arb.pi()/180).sin_cos();vals.append((c*co+s*sn-h).lower())
  low=min(vals);assert low>A(F(87,100000000)),(hand,str(l),str(r),str(low))
  if worst is None or low<worst:worst=low;where=[str(l),str(r)]
 assert end==360
 summary[str(hand)]={'leaves':len(leaves),'endpoint_lower':str(worst),'interval':where}
out={'host_sha256':H,'input_sha256':hashlib.sha256((ROOT/'input14.json').read_bytes()).hexdigest(),'target_added_area_strictly_above':'87/100000000','precision':ctx.prec,'hands':summary,'method':'exact rational face dual and Arb endpoint sine interpolation','scope':'fourteen-point single rigid copy; arbitrary translations, rotations, reflections'}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

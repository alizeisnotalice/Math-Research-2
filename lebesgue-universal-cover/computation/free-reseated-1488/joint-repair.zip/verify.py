"""Verify an exact rational convex enlargement containing two fixed finite inputs."""

import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from math import lcm
from pathlib import Path


HOST_SHA = "781e9521a22be3543d2ca4776a04108c7dea9af85a5952de35401bf21630e97e"
INPUT_SHA = {
    "input10.json": "a97d2d9850aaf23f86aeb1530ec2c380c755e4ceecab7675a75a63b9d6b15f7f",
    "input14.json": "094f82ef1aadcc677dd4e547f15c1a1fb43a84f8a7a11c3d161c7221a79ace4b",
}
HOST_GRID = 10**12
B = F(".844082046521218581802948589770767704354")


def turn(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def hull(points):
    def chain(rows):
        out = []
        for p in rows:
            while len(out) > 1 and turn(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
        return out

    ordered = sorted(set(points))
    return chain(ordered)[:-1] + chain(reversed(ordered))[:-1]


def doubled_area(p):
    return sum(x * v - y * u for (x, y), (u, v) in zip(p, p[1:] + p[:1], strict=True))


def read(path, digest):
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == digest, path
    return json.loads(raw)


def verify(root, recipe, output):
    host = [tuple(p) for p in read(root / "host.json", HOST_SHA)]
    assert len(host) == 1488 and all(len(p) == 2 and all(type(t) is int for t in p) for p in host)
    assert set(hull(host)) == set(host)
    assert all(turn(a, b, c) > 0 for a, b, c in zip(host, host[1:] + host[:1], host[2:] + host[:2]))
    old_area = F(doubled_area(host), 2 * HOST_GRID**2)
    conf = json.loads(recipe.read_bytes())
    assert set(conf["poses"]) == set(INPUT_SHA)

    all_moved = []
    records = []
    for name, digest in INPUT_SHA.items():
        cloud = read(root / name, digest)
        p = cloud["points"]
        scale = cloud["denominator"]
        assert type(scale) is int and scale > 0
        assert len(p) == (10 if name == "input10.json" else 14)
        assert all(len(v) == 2 and all(type(t) is int for t in v) for v in p)
        dsq = max((a - c) ** 2 + (b - d) ** 2 for (a, b), (c, d) in combinations(p, 2))
        assert dsq <= scale**2
        spec = conf["poses"][name]
        hand = spec["hand"]
        assert type(hand) is int and hand in (-1, 1)
        q = F(spec["half_tangent"])
        tx, ty = map(F, spec["translation"])
        c, s = (1 - q*q) / (1 + q*q), 2*q / (1 + q*q)
        assert c*c + s*s == 1
        moved = [(tx + (c*x - s*hand*y)/scale, ty + (s*x + c*hand*y)/scale) for x, y in p]
        all_moved.extend(moved)
        records.append(dict(input=name, sha256=digest, point_count=len(p), hand=hand,
                            half_tangent=str(q), cosine=str(c), sine=str(s),
                            translation=list(map(str, (tx, ty))), diameter_squared=str(F(dsq, scale**2))))
    joint_grid = lcm(HOST_GRID, *(x.denominator for p in all_moved for x in p))
    lifted_host = [(x*(joint_grid // HOST_GRID), y*(joint_grid // HOST_GRID)) for x,y in host]
    lifted_move = [(int(x*joint_grid), int(y*joint_grid)) for x,y in all_moved]
    points = lifted_host + lifted_move
    out = hull(points)
    # Independent signed-side checks certify containment of all original vertices
    # and every point of both rigid copies from the same integer grid.
    assert all(turn(a, b, p) >= 0 for a, b in zip(out, out[1:] + out[:1], strict=True) for p in points)
    area = F(doubled_area(out), 2*joint_grid**2)
    assert old_area < area < B
    assert area < F(conf["strict_area_ceiling"])
    exact_hull = dict(denominator=joint_grid, vertices=[list(p) for p in out])
    raw = (json.dumps(exact_hull, separators=(",", ":")) + "\n").encode()
    output.mkdir(parents=True, exist_ok=True)
    (output / "joint-hull.json").write_bytes(raw)
    result = dict(complete=True, source_host_sha256=HOST_SHA, source_host_vertices=len(host),
                  source_area=str(old_area), joint_hull_sha256=sha256(raw).hexdigest(),
                  joint_vertices=len(out), joint_area=str(area), increment=str(area-old_area),
                  budget=str(B), budget_slack=str(B-area), inputs=records,
                  recipe_sha256=sha256(recipe.read_bytes()).hexdigest(),
                  verifier_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
    (output / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print("vertices", len(out), "area", float(area), "increase", float(area-old_area),
          "budget slack", float(B-area), flush=True)
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    for arg in ("inputs", "recipe", "output"):
        p.add_argument(arg, type=Path)
    a = p.parse_args()
    if not __debug__:
        raise SystemExit("Assertions must be enabled.")
    verify(a.inputs, a.recipe, a.output)

# One rational repair of the 1488-edge host

The frozen host `host.json` has 1488 vertices on the grid (10^{-12}). Its SHA-256 is `781e9521a22be3543d2ca4776a04108c7dea9af85a5952de35401bf21630e97e`. Its exact area has decimal display (0.8440763676839481), and the available area before B is about (5.67884\times10^{-6}).

The two finite inputs are the frozen groups of 10 and 14 rational points. The recipe `optimized.json` gives their individual exact rigid placements. For `hand = -1`, first change the sign of the second coordinate. Then rotate with cosine ((1-q^2)/(1+q^2)) and sine (2q/(1+q^2)), where (q) is the stored half tangent. Finally apply the stored translation. Each input uses its own common transformation.

The exact convex hull of the old host and the two placed finite inputs has area strictly less than **0.844077286830073**. Its area increase is about (9.19146124714\times10^{-7}), and it has 1477 vertices. It was selected after continuous joint area optimization from 12 starts and 48,393 floating-point evaluations of the single joint hull. The directed verification uses the final rational recipe and integer determinants. Every old vertex and every transformed point is checked against the same output polygon. The numerical search does not assert optimality.

The same two poses can also place the complete 24-piece and 16-piece curvature bodies, respectively. One rational polygon enclosing the old host, both point groups, and both full curves has area strictly less than **0.844077308502221**, an increase less than (9.408183\times10^{-7}) with a remaining B margin greater than (4.7380189\times10^{-6}). The exact common convex hull of the four inputs and the old host has area greater than (0.8440772868300727), since it contains the point hull.

The curve enclosure checks 16,384 support points per body. The profiles have continuous support and first derivative, and their curvature radius lies between zero and one. The material point at the nearest sampled normal therefore loses at most (1-\cos(\pi/N)\le\pi^2/(2N^2)) in support in any direction. After enclosing the directed rounding error, square padding of half-side (1.9\times10^{-8}) covers all missed directions. Padding applies only to the new curved samples. The output hull is again rational and its area is computed by integer determinants.

Recompute the exact point receipt with any Python supporting these standard-library operations. The second command adds both complete curves and requires python-flint.

```sh
sha256sum -c SHA256SUMS
PY -I -B verify.py . optimized.json OUT/points
PY -I -B verify_curves.py . optimized.json OUT/curves
```

Both hull files use an explicit common denominator and integer vertices. The curve hull and point hull are separate certified enlargements.

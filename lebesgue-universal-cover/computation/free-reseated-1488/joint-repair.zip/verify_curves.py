"""Enclose the full 24- and 16-piece constant-width bodies in a rational repair."""

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from math import lcm
from pathlib import Path
import sys

from flint import arb, ctx, __version__ as flint_version

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify import B, HOST_GRID, doubled_area, hull, read, turn, verify
from profile_source import Profile

PROFILE_SOURCE_SHA = "2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646"
PROFILES = (
    ("profile24.json", "a06d487f7ae9c4e07c541231fdbd503b077fb09f0e50764bb52567d3bb429208", "input10.json"),
    ("profile16.json", "cf2d0cbef03f99b1c8b731aa4f533c171a2bfe78c3af487ff3f943abb16fe64e", "input14.json"),
)
SAMPLES = 16384
PAD = 19000


def A(x):
    x = F(x)
    return arb(x.numerator)/x.denominator


def dyadic(x):
    m, e = map(int, x.man_exp())
    return F(m) * F(2)**e


def sample(spec, transform):
    """Return outward-certified integer samples before the common square padding."""
    w = Profile(spec)
    q = F(transform["half_tangent"])
    co = A((1 - q*q)/(1 + q*q))
    si = A(2*q/(1 + q*q))
    tx, ty = map(A, transform["translation"])
    hand = transform["hand"]
    out = set()
    for j in range(SAMPLES):
        y,d = w.at(2*j,SAMPLES)
        sn,cs = (2*j*arb.pi()/SAMPLES).sin_cos()
        x = (A(".5")+y)*cs-d*sn
        z = hand*((A(".5")+y)*sn+d*cs)
        xp,yp = tx+co*x-si*z, ty+si*x+co*z
        values = [v*HOST_GRID for v in (xp,yp)]
        p = tuple(round(dyadic(v.mid())) for v in values)
        assert all(abs(v-i)<1 for v,i in zip(values,p,strict=True))
        out.add(p)
    return out


def inside(hull_vertices, p):
    """Closed side check using the fan based at the first hull vertex."""
    origin = hull_vertices[0]
    l, r = 1, len(hull_vertices)-1
    if turn(origin,hull_vertices[l],p)<0 or turn(origin,hull_vertices[r],p)>0:
        return False
    while l+1<r:
        m=(l+r)//2
        if turn(origin,hull_vertices[m],p)>=0:
            l=m
        else:
            r=m
    return turn(hull_vertices[l],hull_vertices[r],p)>=0


def main(inputs, recipe, out):
    assert sha256((HERE/"profile_source.py").read_bytes()).hexdigest()==PROFILE_SOURCE_SHA
    ctx.prec=192
    finite=verify(inputs,recipe,out/"points")
    f=json.loads((out/"points"/"joint-hull.json").read_bytes())
    D=lcm(HOST_GRID,f["denominator"])
    lift=D//HOST_GRID
    base=[tuple(x*(D//f["denominator"]) for x in p) for p in f["vertices"]]
    conf=json.loads(recipe.read_bytes())["poses"]
    clouds=[]
    callbacks=[]
    for name, digest, pose in PROFILES:
        src=read(inputs/name,digest)["profile"]
        cloud=sample(src,conf[pose])
        clouds.append(cloud)
        callbacks.append(dict(input=name,sha256=digest,pose_reused_from=pose,
                              pieces=len(src["pieces"]),distinct_rounded_samples=len(cloud)))

    # For a 2pi-periodic h, the actual material curve p=h*u+h'*J*u
    # satisfies p'(theta)=rho(theta)*J*u between the joins.  Here h,h'
    # are continuous and 0 <= rho <= 1.  The scalar support deficit of
    # the nearest-angle sample is at most the integrated sine, which is
    # 1-cos(pi/SAMPLES) <= pi^2/(2*SAMPLES^2).  Rounding adds less than
    # sqrt(2)/HOST_GRID.  The Euclidean error lies in the chosen square.
    sagitta=(arb.pi()**2/(2*SAMPLES**2)).upper()
    error=(arb(2).sqrt()/HOST_GRID).upper()
    assert sagitta+error<A(F(PAD,HOST_GRID))
    unpadded=base+[(x*lift,y*lift) for cloud in clouds for x,y in cloud]
    padded=base+[((x+i*PAD)*lift,(y+j*PAD)*lift) for cloud in clouds for x,y in cloud
                 for i in (-1,1) for j in (-1,1)]
    ordered=hull(padded)
    assert all(inside(ordered,p) for p in padded)
    outer=F(doubled_area(ordered),2*D**2)
    assert outer<B
    raw=(json.dumps(dict(denominator=D,vertices=ordered),separators=(",",":"))+"\n").encode()
    (out/"joint-curve-hull.json").write_bytes(raw)

    # The hull of unpadded rounded samples lies within error of the true
    # joint hull.  Both true profiles lie in the original width-one
    # hexagon before rotation by their six normalized exact supports.
    # The actual joint hull lies in [-1,1]^2, hence perimeter <= 8.
    assert all(abs(v)<=D for p in base for v in p)
    for name,_,pose in PROFILES:
        t=list(map(A,conf[pose]["translation"]))
        assert 1/arb(3).sqrt()+arb(2).sqrt()*max(map(abs,t))<1
    lower_correction=A(F("1.2e-11"))
    assert 8*error+arb.pi()*error**2<lower_correction
    raw_inner=F(doubled_area(hull(unpadded)),2*D**2)
    lower=max(F(finite["joint_area"]),raw_inner-F("1.2e-11"))
    actual_base=F(finite["source_area"])
    assert actual_base<lower<outer
    result=dict(complete=True, source_host_sha256=finite["source_host_sha256"],
                source_area=str(actual_base), curve_profiles=callbacks, samples_per_profile=SAMPLES,
                support_deficit_upper=str(sagitta), rounding_radius_upper=str(error),
                square_half_side=str(F(PAD,HOST_GRID)), true_joint_lower=str(lower),
                rational_joint_upper=str(outer), increment_upper=str(outer-actual_base),
                budget=str(B), budget_slack=str(B-outer), repaired_vertices=len(ordered),
                rational_hull_sha256=sha256(raw).hexdigest(),
                finite_receipt_sha256=sha256((out/"points"/"receipt.json").read_bytes()).hexdigest(),
                profile_source_sha256=PROFILE_SOURCE_SHA,flint=flint_version,precision_bits=ctx.prec,
                verifier_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
    (out/"curves-receipt.json").write_text(json.dumps(result,indent=2)+"\n")
    print("true joint interval",float(lower),float(outer),"increment >",float(lower-actual_base),
          "<",float(outer-actual_base),"budget slack",float(B-outer),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("inputs","recipe","output"):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    if not __debug__:
        raise SystemExit("Assertions must be enabled.")
    main(args.inputs,args.recipe,args.output)

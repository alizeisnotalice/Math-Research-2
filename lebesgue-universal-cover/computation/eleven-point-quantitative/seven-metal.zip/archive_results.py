"""Verify the recorded Metal runs and the original Arb seven-body area checks."""
from argparse import ArgumentParser
from decimal import Decimal
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import re

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def endpoint(q,side,digits=18):
    unit=10**digits
    n=(q*unit).__floor__()+(1 if side=='upper' else int(q*unit==(q*unit).__floor__())*-1)
    return f'{n//unit}.{n%unit:0{digits}d}'

def main():
    a=ArgumentParser(description=__doc__)
    for k in ('comp','work','output'):a.add_argument(k,type=Path)
    args=a.parse_args()
    r=args.work
    c=args.comp
    assert __debug__
    def read(p):return json.loads(p.read_bytes())
    q=c/'inclusion-minimal-eleven'
    exact_old=read(q/'seven-audit.json')
    assert exact_old['pose_sha256']==sha(q/'seven-pose.json')
    assert sha(q/'new-points.json')=='45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05'
    runs=[]
    for i in range(1,5):
        log=r/f'gpu-wave{i}.log'
        table=r/f'gpu-wave{i}.tsv'
        s=log.read_text()
        m=re.search(r'device=([^\n]+) maxThreads=(\d+) unified=(\d+) epochs=(\d+) candidates=(\d+) seed=(\d+) sigma_multiplier=(\S+)',s)
        n=re.search(r'GPU command buffer seconds=(\S+) compared=(\d+)',s)
        assert m is not None and n is not None
        gpu,max_threads,unified,epochs,count,seed,mul=m.groups()
        seconds,real_count=n.groups()
        assert gpu=='Apple M6' and int(count)==int(real_count)==8192*int(epochs)
        assert Decimal(seconds)>0 and int(epochs)%16==0
        qrows=[line.split() for line in table.read_text().splitlines()]
        assert all(len(row)==22 for row in qrows)
        assert {int(row[1])for row in qrows[-16:]}==set(range(16))
        assert all(int(row[0])==int(epochs) and Decimal(row[2])==Decimal(seconds)for row in qrows[-16:])
        shader=('seven.metal','seven-analytic.metal','seven-analytic.metal','seven-residual.metal')[i-1]
        seeds=('starts.txt','starts-analytic.txt','wave3-starts.txt','wave4-starts.txt')[i-1]
        runs.append(dict(wave=i,hardware=gpu,seed=int(seed),epochs=int(epochs),candidates=int(count),
            gpu_seconds=seconds,shader=shader,seed_file=seeds,shader_sha256=sha(r/shader),seed_sha256=sha(r/seeds),
            device_max_threads=int(max_threads),unified_memory=unified=='1',retained_pose_rows=len(qrows),
            log_sha256=sha(log),tsv_sha256=sha(table)))
    final=read(r/'final-audit.json')
    raw=read(r/'wave2-raw-audit.json')
    backup=read(r/'wave3-gradient-audit.json')
    p=read(r/'wave4-gradient.json')['results'][0]
    assert final['pose_sha256']==sha(r/'final-pose.json')==sha(r/'wave4-gradient-pose.json')
    assert raw['pose_sha256']==sha(r/'wave2-raw-pose.json')
    assert final['k']==32768 and raw['k']==8192
    assert F(final['lower'])<F(str(p['area']))<F(final['upper'])
    assert F(final['upper'])<F(backup['lower'])<F(backup['upper'])<F(raw['lower'])<F(raw['upper'])<F(exact_old['lower'])
    start=read(r/'starts.json')
    for name,expect in start['input_sha256'].items():
        assert sha(c/name)==expect
    output=dict(complete=True,scope='one feasible seven-body placement; all candidates use the same R237 Q and P30',
       gpu='Apple M6',platform=platform.platform(),runs=runs,
       total_gpu_comparisons=sum(x['candidates']for x in runs),
       gpu_command_buffer_seconds=str(sum(Decimal(x['gpu_seconds'])for x in runs)),
       total_elapsed_gpu_seconds_scope='kernel mutation, evaluation and selection; excludes CPU and shader compilation',
       best_pose='final-pose.json',strict_area_interval=[endpoint(F(final['lower']),'lower'),endpoint(F(final['upper']),'upper')],
       strict_gpu_only_wave2_upper=endpoint(F(raw['upper']),'upper'),
       guaranteed_reduction_over_old_placement=endpoint(F(exact_old['lower'])-F(final['upper']),'lower'),
       exact_lower=final['lower'],exact_upper=final['upper'],proof_check='unmodified R237 check6.py and template.py, k=32768',
       final_numerical_refinement=dict(value=p['area'],original_reflection_sign=p['pose'][-1],status=p['numerical_status']),
       public_sources={name:sha(c/name)for name in ('inclusion-minimal-eleven/check6.py','inclusion-minimal-eleven/template.py',
             'inclusion-minimal-eleven/seven-pose.json','inclusion-minimal-eleven/seven-audit.json',
             'inclusion-minimal-eleven/new-points.json','finite-point-leaf-input.json','certify_nine.py',
             'metal-seven-search/seven.metal','metal-seven-search/resident.mm')},
       package_sha256={u.name:sha(u)for u in r.iterdir() if u.is_file() and u.suffix in ('.md','.json','.tsv','.log','.py','.cpp','.mm','.metal','.txt') and u.name!=args.output.name})
    args.output.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
    print(output['strict_area_interval'],output['total_gpu_comparisons'],output['gpu_command_buffer_seconds'])

if __name__=='__main__':
    main()

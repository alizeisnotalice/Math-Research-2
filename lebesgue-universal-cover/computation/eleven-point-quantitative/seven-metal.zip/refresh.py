"""Restart independent Metal islands from candidates scored by the support envelope."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

def main():
    p=ArgumentParser(description=__doc__)
    for k in ('seedfile','prior','output','receipt'):p.add_argument(k,type=Path)
    p.add_argument('--sigma',type=float,default=1.)
    a=p.parse_args()
    source=json.loads(a.prior.read_bytes())
    r=source['refined'][0]['pose']
    rr=source['gpu_sampled_best']['pose']
    def flip(p):
        x=list(p)
        for k in (1,2,4,5,7,8,10,11,13,14,16,17):x[k]=-x[k]
        return x
    picks=[]
    for name,pose in (('envelope-best',r),('gpu-best',rr)):
        for sg in (True,False):
            for magnitude in (2.5e-5,8e-5,2.5e-4):
                picks.append(dict(label=name,pose=pose if sg else flip(pose),sigma=magnitude*a.sigma))
    selected=[]
    keys=set()
    for p in source['top_gpu']:
        k=p['island']
        if k in keys:continue
        keys.add(k)
        selected.append(p['pose'])
    for q in source['refined'][1:]:
        if q['pose'] not in selected:selected.append(q['pose'])
    for q in selected[:4]:
        picks.append(dict(label='other-island',pose=q,sigma=1.5e-4*a.sigma))
    assert len(picks)==16
    base=a.seedfile.read_text().splitlines()
    lines=['16']
    lines.extend(' '.join(format(x,'.17g') for x in q['pose']+[q['sigma']])for q in picks)
    lines.append(base[-1])
    a.output.write_text('\n'.join(lines)+'\n')
    a.receipt.write_text(json.dumps(dict(starts=picks,prior_sha256=sha256(a.prior.read_bytes()).hexdigest(),
        seed_data_sha256=sha256(a.output.read_bytes()).hexdigest()),indent=2)+'\n')

if __name__=='__main__':
    main()

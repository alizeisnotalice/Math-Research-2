#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <array>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

using Pose=std::array<float,18>;

int main(int argc,char **argv) {@autoreleasepool {
    if(argc!=6) return 2;
    const int epochs=std::stoi(argv[3]);
    const uint32_t seed=std::stoul(argv[4]);
    const float multiplier=std::stof(argv[5]);
    if(epochs<=0 || epochs%16 || multiplier<=0) return 2;
    id<MTLDevice> device=MTLCreateSystemDefaultDevice();
    if(!device){std::cerr<<"No Metal device\n";return 3;}
    NSError *error=nil;
    NSString *source=[NSString stringWithContentsOfFile:[NSString stringWithUTF8String:argv[1]]
                            encoding:NSUTF8StringEncoding error:&error];
    if(!source){NSLog(@"%@",error);return 3;}
    MTLCompileOptions *options=[MTLCompileOptions new];
    options.fastMathEnabled=NO;
    auto lib=[device newLibraryWithSource:source options:options error:&error];
    if(!lib){NSLog(@"%@",error);return 3;}
    const auto pipeline=[&](NSString *name) {
        return [device newComputePipelineStateWithFunction:[lib newFunctionWithName:name] error:&error];
    };
    auto search=pipeline(@"seven"), mutate=pipeline(@"mutate"), select=pipeline(@"select_best");
    if(!search||!mutate||!select){NSLog(@"%@",error);return 3;}
    const int islands=16,children=512,count=islands*children;
    const auto buffer=[&](NSUInteger bytes) {
        return [device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
    };
    auto poses=buffer(count*sizeof(Pose)),clouds=buffer(82*sizeof(float)),out=buffer(count*sizeof(float));
    auto centers=buffer(islands*sizeof(Pose)),scores=buffer(islands*sizeof(float)),sigmas=buffer(islands*sizeof(float));
    auto queue=[device newCommandQueue];
    if(!queue||!poses||!clouds||!out||!centers||!scores||!sigmas) return 4;
    auto cp=(Pose *)centers.contents;
    auto sp=(float *)sigmas.contents;
    auto sc=(float *)scores.contents;
    std::ifstream input(argv[2]);
    int n;input>>n;if(n!=islands) return 4;
    for(int j=0;j<islands;j++){for(float &x:cp[j])input>>x;input>>sp[j];sp[j]*=multiplier;}
    for(int i=0;i<82;i++) input>>((float *)clouds.contents)[i];
    if(!input)return 4;
    std::cerr<<"device="<<device.name.UTF8String<<" maxThreads="<<search.maxTotalThreadsPerThreadgroup
      <<" unified="<<device.hasUnifiedMemory<<" epochs="<<epochs<<" candidates="<<uint64_t(count)*epochs
      <<" seed="<<seed<<" sigma_multiplier="<<multiplier<<"\n";
    double gpuSeconds=0;
    std::cout<<std::setprecision(17);
    for(int epoch=0;epoch<epochs;epoch+=16){@autoreleasepool {
        auto command=[queue commandBuffer];
        for(int j=0;j<16;j++){
            auto enc=[command computeCommandEncoder];[enc setComputePipelineState:mutate];
            [enc setBuffer:centers offset:0 atIndex:0];[enc setBuffer:poses offset:0 atIndex:1];
            uint32_t data[4]={uint32_t(epoch+j),seed,uint32_t(epochs),0};
            [enc setBytes:data length:sizeof(data) atIndex:2];
            [enc setBuffer:sigmas offset:0 atIndex:3];
            [enc dispatchThreads:MTLSizeMake(count*18,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
            [enc endEncoding];
            enc=[command computeCommandEncoder];[enc setComputePipelineState:search];
            [enc setBuffer:poses offset:0 atIndex:0];[enc setBuffer:clouds offset:0 atIndex:1];
            [enc setBuffer:out offset:0 atIndex:2];
            [enc dispatchThreadgroups:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
            [enc endEncoding];
            enc=[command computeCommandEncoder];[enc setComputePipelineState:select];
            [enc setBuffer:poses offset:0 atIndex:0];[enc setBuffer:out offset:0 atIndex:1];
            [enc setBuffer:centers offset:0 atIndex:2];[enc setBuffer:scores offset:0 atIndex:3];
            [enc dispatchThreadgroups:MTLSizeMake(islands,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
            [enc endEncoding];
        }
        [command commit];[command waitUntilCompleted];
        if(command.status!=MTLCommandBufferStatusCompleted){NSLog(@"%@",command.error);return 5;}
        const double duration=command.GPUEndTime-command.GPUStartTime;
        if(!(duration>0))return 6;
        gpuSeconds+=duration;
        if(epoch%32==0||epoch+16==epochs){
            for(int j=0;j<islands;j++) {
                std::cout<<epoch+16<<" "<<j<<" "<<gpuSeconds<<" "<<sc[j];
                for(float x:cp[j])std::cout<<" "<<x;
                std::cout<<"\n";
            }
            std::cout<<std::flush;
        }
    }}
    std::cerr<<std::setprecision(17)<<"GPU command buffer seconds="<<gpuSeconds<<" compared="<<uint64_t(count)*epochs<<"\n";
    return 0;
}}

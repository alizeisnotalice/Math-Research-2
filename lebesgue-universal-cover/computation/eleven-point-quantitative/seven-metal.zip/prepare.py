"""Freeze R237's exact clouds and oriented starts for the resident GPU search."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from math import pi
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('receipt',type=Path)
    a=p.parse_args()
    c=a.comp
    src=c/'inclusion-minimal-eleven'
    files={}
    def read(k):
        raw=k.read_bytes();files[str(k.relative_to(c))]=sha256(raw).hexdigest();return json.loads(raw)
    def new(row,p30=True):
        c0=[float(F(x,2**44))for x in row['center']]
        tx,ty,angle=map(float,row['point_pose'])
        return c0+[angle,tx,ty] if p30 else (c0,[angle,tx,ty])
    base_pose=read(src/'seven-pose.json')
    p0=new(base_pose)
    qx,qy,qa=map(float,base_pose['second_point_pose'])
    qs=[qa,qx,qy]
    a0=read(c/'free-p30-reoptimized-pose.json')
    orig=read(c/'seven-point-families-pose.json')['pose']
    six_new,qnew=new(read(src/'new-six-pose.json'),False)
    p30pose=list(map(float,p0[11:14]))
    lows=[('R237-seven',p0,qs),('R155-six',list(map(float,a0[:14])),qs),
          ('R237-other-six',new(read(src/'other-pose.json')),qs),
          ('R237-bundle-six',new(read(src/'bundle-pose.json')),qs),
          ('R175-first-fourteen',list(map(float,orig[:14])),qs),
          ('R237-new-Q-six',six_new+p30pose,qnew),
          ('R237-P30-midpoint',[.5*(p+q) for p,q in zip(p0,map(float,a0[:14]))],qs),
          ('R237-Q-alternative',p0,qnew)]
    def wrap(a,k):
        r=2*pi/k
        return (a+r/2)%r-r/2
    island=[]
    for idx,(label,piece,qpose) in enumerate(lows):
        pose=piece+qpose
        for j,n in ((2,5),(5,7),(8,9),(11,1),(14,1)): pose[j]=wrap(pose[j],n)
        for s in (1,-1):
            island.append(dict(name=label,pose=pose+[s],sigma=(.00012 if idx==0 and s==1 else .0032 if idx in (1,4,5,7) else .0017)))
    P=read(c/'finite-point-leaf-input.json')
    Q=read(src/'new-points.json')
    assert files['finite-point-leaf-input.json']=='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
    assert files['inclusion-minimal-eleven/new-points.json']=='45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05'
    assert len(P['points'])==30 and len(Q['points'])==11
    assert all(max((x-z)**2+(y-u)**2 for x,y in p['points']for z,u in p['points'])<=p['denominator']**2 for p in (P,Q))
    assert {(x,-y)for x,y in P['points']}==set(map(tuple,P['points']))
    lines=[str(len(island))]
    lines.extend(' '.join(format(x,'.17g')for x in row['pose']+[row['sigma']])for row in island)
    xy=[float(F(x,p['denominator']))for p in (P,Q)for tr in p['points']for x in tr]
    lines.append(' '.join(format(x,'.17g')for x in xy))
    a.output.write_text('\n'.join(lines)+'\n')
    rs=dict(input_sha256=files,seed_file_sha256=sha256(a.output.read_bytes()).hexdigest(),starts=island,
            convention='R237 pose integers / 2^44; [t3x,t3y,a5,t5x,t5y,a7,t7x,t7y,a9,t9x,t9y,aP,tPx,tPy,aQ,tQx,tQy,sQ]; angles in radians; reflect local Q across x axis before rotation; no recentering')
    a.receipt.write_text(json.dumps(rs,indent=2)+'\n')

if __name__=='__main__':
    main()

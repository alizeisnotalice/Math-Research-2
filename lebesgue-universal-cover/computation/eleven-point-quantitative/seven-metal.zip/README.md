# R237 七输入的本机 Metal 搜索

固定原三十点、R237 的新十一点 $Q$ 和五个曲体。新 $Q$ 的源 SHA-256 为 **45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05**。归档的最终摆放经 R237 的 **check6.py** 原算术核按每弧 32,768 段复算，真实面积严格满足
$$
0.837761800093736973 < A < 0.837761800534230504 .
$$
新摆放相对 R237 旧摆放的真实面积严格降低超过 $7.71085060761\times10^{-7}$。第二波未经 CPU 优化的 Metal 直选姿态也经同一真边界核证明面积小于 $0.837762037519341639$。

## 搜索

起点含 R237 七体、R155 低六体、R237 的两组其他低六体、R175 锚、由新 Q 六体摆放加三十点构成的锚、两个混合起点。16 个初始岛覆盖两种 Q 手性。原姿态中心表除以 $2^{44}$。两点集按原坐标使用。负手性表示先关于局部横轴反射 Q，再转动和平移。若提交负手候选，验证前对完整构形作同一个全局横轴反射，使之回到 **check6.py** 的正手格式。三十点关于横轴的精确整数对称性在生成起点时复核。

| 波次 | GPU 评分次数 | GPU 命令缓冲区秒 | 方法 |
| --- | ---: | ---: | --- |
| 1 | 3,145,728 | 1.3514553749973857 | 旧型有限角支撑多边形，16 岛独立演化 |
| 2 | 786,432 | 2.9553142083341299 | 支撑分段积分，使用同一组多锚起点 |
| 3 | 2,097,152 | 7.7540520833344999 | 由通过双精度面积筛选的 Metal 候选重启 |
| 4 | 1,310,720 | 5.3432695000001331 | 改善小角格处理的残差评分，按第三波优种重启 |

总计 7,340,032 次评分与 17.4040911666661486 GPU 秒。计数包括每岛保留的父姿态。计时取每个已完成 Metal 命令缓冲区的 **GPUEndTime − GPUStartTime** 之和，包含变异、评分和选择。设备为本机 Apple M6 12 核 GPU，macOS 27.2，命令缓冲区均完成。MacBook 未参与本轮计算。所有本轮启动的搜索与验证进程均已退出。

首波的有限角近似在长边附近产生足以改变排序的误差，双精度复核未改善初始上端。后续核对每次支撑扇的局部弧或顶点单独处理。支撑片形如 $h=c+v\cdot u(\theta)$。在相邻扇区边界与交点之间用
$$
\frac12\int (h^2-(h')^2)\,d\theta
$$
计算所选支撑片的面积贡献。第二波产生了严格改进的 GPU 原始候选。双精度分段包络、Powell 和按圆弧长度及平边跳跃求出的梯度用于之后的候选精化。梯度只作数值搜索。最终严格区间直接来自原 Arb 核对选定姿态的真边界弧段。

## 复算与定位

**manifest.json** 保存设备日志、确切候选计数、最终有理面积端点和依赖 SHA-256。**final-pose.json** 是同一个整体坐标系下的五体整数位置及两点集的十进位置。**final-audit.json** 是对该姿态的实际严格回执。**wave2-raw-pose.json** 和 **wave2-raw-audit.json** 则保留纯 Metal 优选及其真面积回执。

使用包含 **inclusion-minimal-eleven** 及原三十点的项目计算目录作为 **COMP**。编译产物放在 data 盘临时目录 **TMP**，使用共享的 Clang 模块缓存 **CACHE**。此处命令从本目录运行，GPU 定期记录各岛优胜者，并在日志中写入设备、总评分次数和累计命令时间。**PYFLINT** 指 Python 3.12.14 配 python-flint 0.9.0 的实际验证环境。

~~~sh
clang++ -O3 -std=c++17 -fobjc-arc -fmodules-cache-path="$CACHE" resident.mm -framework Foundation -framework Metal -o "$TMP/r237-resident"
clang++ -O3 -std=c++17 -fobjc-arc -fmodules-cache-path="$CACHE" resident-analytic.mm -framework Foundation -framework Metal -o "$TMP/r237-resident-analytic"
"$TMP/r237-resident" seven.metal starts.txt 384 20261119 1
"$TMP/r237-resident-analytic" seven-analytic.metal starts-analytic.txt 96 20261121 1
"$TMP/r237-resident-analytic" seven-analytic.metal wave3-starts.txt 256 20261123 1
"$TMP/r237-resident-analytic" seven-residual.metal wave4-starts.txt 160 20261125 1
PYFLINT -I -B "$COMP/inclusion-minimal-eleven/check6.py" "$COMP" final-pose.json new-final-audit.json --k 32768
PYFLINT -I -B "$COMP/inclusion-minimal-eleven/check6.py" "$COMP" wave2-raw-pose.json new-raw-audit.json --k 8192
python -I -B archive_results.py "$COMP" . manifest.json
~~~

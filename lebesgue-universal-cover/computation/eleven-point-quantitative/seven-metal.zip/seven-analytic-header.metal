#include <metal_stdlib>
using namespace metal;
constant float pi=3.14159265358979323846f;
constant float tau=6.28318530717958647692f;

struct Piece { float2 c; float r, end; };
float mod_tau(float a) { return a-floor(a/tau)*tau; }
float2 unit(float a) { return float2(cos(a),sin(a)); }

Piece regular(float angle,float phi,float2 t,int n) {
    float per=tau/float(n),k=rint((angle-phi)/per);
    float mid=phi+k*per,offset=angle-mid;
    float rvertex=.5f/cos(per/4.f);
    bool arc=abs(offset)>per/4.f;
    float j=k;
    if(arc) {
        float s=offset>0.f ? 1.f : -1.f;
        j+=(s-float(n))/2.f;
        mid+=s*per/2.f;
    }
    return Piece{t+rvertex*unit(phi+j*per),arc?1.f:0.f,mid+per/4.f};
}
Piece polygon(float angle,const device float *p,constant float4 *cloud,int begin,int end) {
    bool P=begin==0;
    int index=P?11:14;
    float s=P?1.f:p[17],turn=p[index],pre=angle-turn;
    float2 u=unit(pre);u.y*=s;
    int best=begin;
    float h=-2.f;
    for(int i=begin;i<end;i++){
        float score=dot(cloud[i].xy,u);
        if(score>h){h=score;best=i;}
    }
    float4 v=cloud[best];v.y*=s;
    auto cs=unit(turn);
    float2 center=float2(p[index+1]+dot(v.xy,float2(cs.x,-cs.y)),
                         p[index+2]+dot(v.xy,float2(cs.y,cs.x)));
    float edge=turn+(s>0.f?v.w:-v.z);
    return Piece{center,0.f,angle+mod_tau(edge-angle)};
}

float stable_diff(float a,float b,float c,float x) {
    float half_sin=sin(x*.5f);
    return fma(a,-2.f*half_sin*half_sin,fma(b,sin(x),c));
}
void find_crossing(float a,float b,float c,float lo,float hi,
                   thread float* events,thread int& count) {
    float f=stable_diff(a,b,c,lo),g=stable_diff(a,b,c,hi);
    if((f>0.f)==(g>0.f)||abs(f)+abs(g)<1.e-13f)return;
    float a0=lo,b0=hi;
    for(int i=0;i<13;i++){
        float mid=(a0+b0)*.5f, z=stable_diff(a,b,c,mid);
        if((z>0.f)==(f>0.f))a0=mid;else b0=mid;
    }
    events[count++]=.5f*(a0+b0);
}
void roots(Piece x,Piece y,float2 u,float w,thread float* events,thread int& count) {
    float2 v=x.c-y.c;
    float a=dot(v,u),b=dot(v,float2(-u.y,u.x));
    float c=fma(v.x,u.x,fma(v.y,u.y,x.r-y.r));
    // On this short angular interval there is at most one stationary point.
    float sl=b*cos(w)+a*sin(w),sr=b*cos(w)-a*sin(w);
    if((sl>0.f)!=(sr>0.f)) {
        float q=atan2(b,a);
        if(q>pi/2.f)q-=pi;
        if(q<-pi/2.f)q+=pi;
        if(q>-w&&q<w) {
            find_crossing(a,b,c,-w,q,events,count);
            find_crossing(a,b,c,q,w,events,count);
            return;
        }
    }
    find_crossing(a,b,c,-w,w,events,count);
}
float integral(Piece p,float a,float b,float origin) {
    float width=b-a,m=origin+(b+a)*.5f;
    float c=cos(m),s=sin(m),x=p.c.x,y=p.c.y;
    return p.r*p.r*width+4.f*p.r*sin(width*.5f)*dot(p.c,float2(c,s))
            +sin(width)*((x*x-y*y)*(c*c-s*s)+4.f*x*y*c*s);
}

kernel void seven(device const float *poses [[buffer(0)]],constant float4 *cloud [[buffer(1)]],
                  device float *areas [[buffer(2)]],uint t [[thread_index_in_threadgroup]],
                  uint3 group [[threadgroup_position_in_grid]]) {
    const device float *p=poses+18*group.x;
    threadgroup float sum[128];
    float total=0.f;
    constexpr int CELLS=256;
    for(uint j=t;j<CELLS;j+=128) {
        float lo=tau*float(j)/float(CELLS),end=tau*float(j+1)/float(CELLS);
        for(int step=0;step<22&&end-lo>3.e-7f;step++) {
            const float probe=min(lo+1.3e-6f,(lo+end)*.5f);
            Piece ps[7]={Piece{float2(0),.5f,end},regular(probe,0.f,float2(p[0],p[1]),3),
                regular(probe,p[2],float2(p[3],p[4]),5),regular(probe,p[5],float2(p[6],p[7]),7),
                regular(probe,p[8],float2(p[9],p[10]),9),polygon(probe,p,cloud,0,30),polygon(probe,p,cloud,30,41)};
            float hi=end;
            for(int b=1;b<7;b++)if(ps[b].end>lo)hi=min(hi,ps[b].end);
            if(hi-lo<1.35e-6f)hi=min(end,lo+1.35e-6f);
            const float mid=(lo+hi)*.5f,w=(hi-lo)*.5f;
            float events[44];int count=0;
            events[count++]=-w;events[count++]=w;
            float2 u=unit(mid);
            for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)roots(ps[a],ps[b],u,w,events,count);
            for(int i=1;i<count;i++) {
                float cursor=events[i];int k=i-1;
                while(k>=0&&events[k]>cursor){events[k+1]=events[k];--k;}
                events[k+1]=cursor;
            }
            for(int i=0;i+1<count;i++){
                float l=events[i],r=events[i+1];
                if(r-l<1.e-8f)continue;
                const float theta=mid+(l+r)*.5f;
                const auto direct=unit(theta);
                int j0=0;float largest=.5f;
                for(int k=1;k<7;k++){
                    float score=ps[k].r+dot(ps[k].c,direct);
                    if(score>largest){largest=score;j0=k;}
                }
                total+=integral(ps[j0],l,r,mid)*.5f;
            }
            lo=hi;
        }
        if(end-lo>3.e-6f) total+=.01f;
    }
    sum[t]=total;
    for(uint k=64;k;k/=2){
        threadgroup_barrier(mem_flags::mem_threadgroup);
        if(t<k)sum[t]+=sum[t+k];
    }
    if(t==0)areas[group.x]=sum[0];
}

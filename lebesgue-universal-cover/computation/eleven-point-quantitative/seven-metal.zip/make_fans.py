"""Use the exact polygon vertex order to annotate support fan corners."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import atan2
import json
from pathlib import Path

def annotate(pts,den):
    p=sorted(tuple(q)for q in pts)
    def cross(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    def half(x):
        a=[]
        for q in x:
            while len(a)>1 and cross(a[-2],a[-1],q)<=0:a.pop()
            a.append(q)
        return a[:-1]
    v=half(p)+half(reversed(p))
    assert len(v)==len(p)
    ang=[atan2(a[0]-b[0],b[1]-a[1])for a,b in zip(v,v[1:]+v[:1])]
    return [value for i,(x,y) in enumerate(v) for value in (float(F(x,den)),float(F(y,den)),ang[i-1],ang[i])]

def main():
    p=ArgumentParser(description=__doc__)
    for name in ('comp','ordinary','out'):p.add_argument(name,type=Path)
    a=p.parse_args()
    paths=('finite-point-leaf-input.json','inclusion-minimal-eleven/new-points.json')
    raw=[json.loads((a.comp/n).read_bytes())for n in paths]
    seq=[x for r in raw for x in annotate(r['points'],r['denominator'])]
    old=a.ordinary.read_text().splitlines()
    assert len(seq)==164 and len(old)==18
    a.out.write_text('\n'.join(old[:-1]+[' '.join(format(v,'.17g')for v in seq)])+'\n')

if __name__=='__main__':
    main()

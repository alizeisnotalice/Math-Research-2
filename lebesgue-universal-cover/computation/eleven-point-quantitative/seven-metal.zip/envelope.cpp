// Numerically integrate the exact pieces of the support envelope for the seven inputs.
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <utility>
#include <vector>

constexpr double pi=3.141592653589793238462643383279502884;
constexpr double tau=2*pi;
struct Point { double x,y; };
struct Piece { double x,y,r; };
struct Patch { double left,right; Piece piece; };
using Fan=std::vector<Patch>;
using Cloud=std::vector<Point>;
Cloud cloudP,cloudQ;

double normalize(double a) {
    a=std::fmod(a,tau);
    return a<0?a+tau:a;
}
Point rotate(Point p,double c,double s) { return {c*p.x-s*p.y,s*p.x+c*p.y}; }
void add(Fan& fan,double start,double width,Piece p) {
    auto l=normalize(start);
    const double r=l+width;
    if(r<tau) fan.push_back({l,r,p});
    else {
        fan.push_back({l,tau,p});
        fan.push_back({0,r-tau,p});
    }
}
void sort_fan(Fan& f) {
    std::sort(f.begin(),f.end(),[](const Patch& a,const Patch& b){return a.left<b.left;});
}
Fan regular(int n,double a,double x,double y) {
    Fan fan;
    fan.reserve(2*n+1);
    const double width=pi/n,R=.5/std::cos(width/2);
    for(int j=0;j<n;j++) {
        auto t=a+tau*j/n;
        double cx=x+R*std::cos(t),cy=y+R*std::sin(t);
        add(fan,t-width/2,width,{cx,cy,0.});
        add(fan,t+pi-width/2,width,{cx,cy,1.});
    }
    sort_fan(fan);return fan;
}
double cross(Point p,Point q,Point r) {
    return (q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
}
Cloud hull(Cloud p) {
    std::sort(p.begin(),p.end(),[](Point a,Point b){return a.x<b.x||(a.x==b.x&&a.y<b.y);});
    Cloud q;
    for(Point v:p) {
        while(q.size()>1&&cross(q[q.size()-2],q.back(),v)<=0) q.pop_back();
        q.push_back(v);
    }
    size_t low=q.size();
    for(auto k=p.rbegin()+1;k!=p.rend();++k) {
        while(q.size()>low&&cross(q[q.size()-2],q.back(),*k)<=0) q.pop_back();
        q.push_back(*k);
    }
    q.pop_back();
    return q;
}
Fan polygon(const Cloud& cloud,double a,double tx,double ty,int s) {
    Cloud p;
    p.reserve(cloud.size());
    const auto C=std::cos(a),S=std::sin(a);
    for(size_t j=0;j<cloud.size();j++) {
        auto v=cloud[s==1?j:cloud.size()-1-j];
        v=rotate({v.x,s*v.y},C,S);
        p.push_back({tx+v.x,ty+v.y});
    }
    Fan fan;
    fan.reserve(p.size()+1);
    for(size_t j=0;j<p.size();j++) {
        auto x=p[j],l=p[(j+p.size()-1)%p.size()],r=p[(j+1)%p.size()];
        auto end=std::atan2(x.x-r.x,r.y-x.y),begin=std::atan2(l.x-x.x,x.y-l.y);
        add(fan,begin,normalize(end-begin),{x.x,x.y,0.});
    }
    sort_fan(fan);return fan;
}
double eval(Piece p,double c,double s) { return p.r+p.x*c+p.y*s; }
double integrate(Piece p,double a,double b) {
    const double dt=b-a,m=(b+a)/2,c=std::cos(m),s=std::sin(m);
    return p.r*p.r*dt+4*p.r*std::sin(dt/2)*(p.x*c+p.y*s)
        +std::sin(dt)*((p.x*p.x-p.y*p.y)*(c*c-s*s)+4*p.x*p.y*c*s);
}
void intercept(Piece p,Piece q,double l,double r,std::vector<double>& angles) {
    const auto x=p.x-q.x,y=p.y-q.y,c=p.r-q.r;
    const auto radius=std::hypot(x,y);
    if(radius<=std::abs(c))return;
    const auto phase=std::atan2(y,x),shift=std::acos(-c/radius);
    const auto b=normalize(phase-shift),a=normalize(phase+shift);
    if(l<a&&a<r) angles.push_back(a);
    if(l<b&&b<r) angles.push_back(b);
}
double area(const std::array<Fan,7>& families) {
    std::vector<double> all;
    all.reserve(170);
    all.push_back(0);all.push_back(tau);
    for(const Fan& f:families) for(auto v:f)all.push_back(v.left);
    std::sort(all.begin(),all.end());
    std::array<size_t,7> at{};
    std::array<Piece,7> ls{};
    double total=0.;
    std::vector<double> internal;
    internal.reserve(44);
    for(size_t j=0;j+1<all.size();j++) {
        const auto l=all[j],r=all[j+1];
        if(r-l<5e-15)continue;
        const auto mid=(l+r)/2;
        for(size_t i=0;i<families.size();i++) {
            const auto& f=families[i];
            while(at[i]+1<f.size()&&f[at[i]+1].left<=mid)at[i]++;
            ls[i]=f[at[i]].piece;
        }
        internal.clear();
        internal.push_back(l);internal.push_back(r);
        for(int i=0;i<7;i++)for(int k=i+1;k<7;k++) intercept(ls[i],ls[k],l,r,internal);
        std::sort(internal.begin(),internal.end());
        for(size_t k=0;k+1<internal.size();k++) {
            double a=internal[k],b=internal[k+1];
            if(b-a<5e-15)continue;
            const auto angle=(a+b)/2,c=std::cos(angle),s=std::sin(angle);
            const auto p=*std::max_element(ls.begin(),ls.end(),[&](Piece u,Piece v){return eval(u,c,s)<eval(v,c,s);});
            total+=integrate(p,a,b);
        }
    }
    return total/2;
}
extern "C" void set_cloud(const double* p,const double* q) {
    cloudP.clear(); cloudQ.clear();
    for(size_t i=0;i<30;i++)cloudP.push_back({p[2*i],p[2*i+1]});
    for(size_t i=0;i<11;i++)cloudQ.push_back({q[2*i],q[2*i+1]});
    cloudP=hull(std::move(cloudP));cloudQ=hull(std::move(cloudQ));
}
extern "C" double measure(const double* a,int sign) {
    return area({Fan{{0,tau,{0.,0.,.5}}},regular(3,0.,a[0],a[1]),regular(5,a[2],a[3],a[4]),
        regular(7,a[5],a[6],a[7]),regular(9,a[8],a[9],a[10]),
        polygon(cloudP,a[11],a[12],a[13],1),polygon(cloudQ,a[14],a[15],a[16],sign)});
}

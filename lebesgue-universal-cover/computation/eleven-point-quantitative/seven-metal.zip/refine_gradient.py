"""Refine selected Metal candidates with boundary length and facet derivatives."""
from argparse import ArgumentParser
import ctypes
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import minimize
from search_report import envelope, pose_json

def main():
    a=ArgumentParser(description=__doc__)
    for k in ('comp','library','rank','output','pose'):a.add_argument(k,type=Path)
    a.add_argument('--max-seeds',type=int,default=8)
    args=a.parse_args()
    lib=envelope(args.comp,args.library)
    v=np.ctypeslib.ndpointer(np.float64,1,flags='C_CONTIGUOUS')
    lib.measure_gradient.argtypes=[v,ctypes.c_int,v]
    lib.measure_gradient.restype=ctypes.c_double
    record=json.loads(args.rank.read_bytes())
    seeds=[r['pose'] for r in record['refined']]+[r['pose'] for r in record['top_gpu']]
    todo=[]
    for p in seeds:
        if any(np.linalg.norm(np.array(p)-x)<2.e-7 for x in todo):continue
        todo.append(np.array(p))
        if len(todo)>=args.max_seeds:break
    x=todo[0][:-1].copy()+np.random.default_rng(2).normal(0.,1.e-4,17)
    base=np.zeros(17)
    lib.measure_gradient(np.ascontiguousarray(x),int(todo[0][-1]),base)
    hg=np.eye(17)*1.e-7
    fd=np.array([(lib.measure(x+k,int(todo[0][-1]))-lib.measure(x-k,int(todo[0][-1])))/2e-7 for k in hg])
    gap=np.max(np.abs(fd-base))
    assert gap<2.e-7, gap
    scale=np.ones(17);scale[[2,5,8,11,14]]=3
    start=time.monotonic();picks=[]
    for i,p in enumerate(todo):
        p0=p[:-1].copy();f0=lib.measure(p0,int(p[-1]))
        best=[float(f0),p0]
        def fun(v):
            x=np.ascontiguousarray(p0+v*scale)
            grad=np.zeros(17)
            f=lib.measure_gradient(x,int(p[-1]),grad)
            if f<best[0]:best[:]=f,x
            return f-.8377,grad*scale
        x0=np.zeros(17)
        r=minimize(fun,x0,jac=True,method='BFGS',options=dict(maxiter=1400,gtol=2e-11,xrtol=1e-13))
        picks.append(dict(start=float(f0),area=best[0],pose=list(best[1])+[p[-1]],seed_index=i,
            iterations=r.nit,nfev=r.nfev,numerical_status=str(r.message)))
        print('grad',i,f0,best[0],r.nfev,r.message,flush=True)
    picks.sort(key=lambda k:k['area'])
    args.pose.write_text(json.dumps(pose_json(picks[0]['pose']),indent=2)+'\n')
    args.output.write_text(json.dumps(dict(complete=True,results=picks,off_contact_gradient_fd_residual=float(gap),diagnostic_rng_seed=2,
             elapsed=time.monotonic()-start,inputs={p.name:sha256(p.read_bytes()).hexdigest()for p in
                 (args.library,args.rank,Path(__file__))}),indent=2)+'\n')
if __name__=='__main__':
    main()

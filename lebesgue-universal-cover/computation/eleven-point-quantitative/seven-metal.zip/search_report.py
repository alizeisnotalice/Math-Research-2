"""Rank and optionally refine GPU output in the analytic double-precision support envelope."""
import argparse,ctypes
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import time

import numpy as np
import scipy
from scipy.optimize import minimize

def sec(artifact):
    return sha256(artifact.read_bytes()).hexdigest()

def envelope(comp,library):
    P=comp/'finite-point-leaf-input.json'
    Q=comp/'inclusion-minimal-eleven'/'new-points.json'
    assert sec(P)=='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
    assert sec(Q)=='45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05'
    lib=ctypes.CDLL(str(library.resolve()))
    vec=np.ctypeslib.ndpointer(np.float64,1,flags='C_CONTIGUOUS')
    lib.set_cloud.argtypes=[vec,vec]
    lib.measure.argtypes=[vec,ctypes.c_int];lib.measure.restype=ctypes.c_double
    def read(file):
        r=json.loads(file.read_bytes());return np.array(r['points'],dtype=float).ravel()/r['denominator']
    lib.set_cloud(read(P),read(Q))
    return lib

def pose_json(p):
    p=list(p)
    if p[-1]==-1:
        for j in (1,2,4,5,7,8,10,11,13,14,16):p[j]=-p[j]
    return dict(center=[int(round(x*2**44))for x in p[:11]],
        point_pose=list(map(str,(p[12],p[13],p[11]))),
        second_point_pose=list(map(str,(p[15],p[16],p[14]))))

def run(a):
    c=a.comp;lib=envelope(c,a.library);t=time.monotonic()
    scale=np.ones(17);scale[[2,5,8,11,14]]=15
    n=0
    def area(p,s):
        nonlocal n
        n+=1
        return lib.measure(np.ascontiguousarray(p,dtype=np.float64),int(s))
    starts=json.loads(a.starts.read_bytes())['starts']
    base=area(starts[0]['pose'][:-1],1)
    prior=json.loads((c/'inclusion-minimal-eleven'/'seven-audit.json').read_bytes())
    assert float(F(prior['lower']))<base<float(F(prior['upper'])),(base,prior)
    W=[]
    for w in a.waves:
        data=np.loadtxt(w,ndmin=2,dtype=np.float64)
        assert data.shape[1]==22 and np.all(np.isfinite(data))
        for step,island,gpu,score,*p in data:
            W.append((area(p[:-1],p[-1]),w.name,int(step),int(island),float(score),list(p),float(gpu)))
    assert W
    W.sort()
    uniq={}
    for r in W:
        key=(r[1],r[3]);uniq.setdefault(key,r)
    selected=[]
    for row in sorted(uniq.values()):
        if any(np.linalg.norm((np.array(old[5][:-1])-np.array(row[5][:-1]))/scale)<a.threshold
               and old[5][-1]==row[5][-1] for old in selected):continue
        selected.append(row)
        if len(selected)>=a.refine:break
    if not a.refine:selected=[]
    def record(r):
        return dict(area=r[0],wave=r[1],epoch=r[2],island=r[3],screen_area=r[4],pose=r[5],gpu_seconds=r[6])
    picks=[]
    for k,r in enumerate(selected):
        p=np.array(r[5][:-1]);sg=int(r[5][-1]);step=.00015
        def f(x):return area(p+x*scale,sg)
        opts={'maxiter':35,'maxfev':10000,'xtol':3e-12,'ftol':4e-14,'direc':np.eye(17)*step}
        sr=minimize(f,np.zeros(17),method='Powell',options=opts)
        x=p+sr.x*scale
        d=dict(start=record(r),area=float(sr.fun),pose=list(x)+[sg],nfev=sr.nfev,optimizer_stop=str(sr.message))
        picks.append(d)
        print('refine',k,'island',r[3],'start',r[0],'final',sr.fun,'calls',sr.nfev,flush=True)
    sorted_picks=sorted(picks + [dict(area=W[0][0],pose=W[0][5],start=record(W[0]),nfev=0,optimizer_stop='raw Metal')],key=lambda r:r['area'])
    best=sorted_picks[0]
    a.pose.write_text(json.dumps(pose_json(best['pose']),indent=2)+'\n')
    result=dict(complete=True,scope='floating double support envelope; consult separate Arb bound for proof',
        baseline=base,gpu_sampled_best=record(W[0]),saved_gpu_candidates=len(W),top_gpu=[record(r)for r in W[:28]],
        refined=sorted_picks,area_evaluations=n,elapsed=time.monotonic()-t,
        sources={p.name:sec(p)for p in (a.starts,a.library,Path(__file__),*a.waves)},
        scipy=scipy.__version__,numpy=np.__version__,python=platform.python_version())
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print('BASE',base,'METAL true area',W[0][0],'best',best['area'],flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    for t in ('comp','library','starts','out','pose'):ap.add_argument(t,type=Path)
    ap.add_argument('waves',type=Path,nargs='+')
    ap.add_argument('--refine',type=int,default=6);ap.add_argument('--threshold',type=float,default=.0003)
    run(ap.parse_args())

"""Normalize the certified full-dimensional eleven-point family to diameter exactly one."""
from fractions import Fraction as F
from pathlib import Path
import json,sys
raw=json.loads(Path(sys.argv[1]).read_bytes());old=json.loads(Path(sys.argv[2]).read_bytes())
P=[(F(x,raw['denominator']),F(y,raw['denominator'])) for x,y in raw['points']]
diam2=max((a-u)**2+(b-v)**2 for a,b in P for u,v in P)
assert diam2==F(19999999890783901,20000000000000000)
diam_floor=F(999999997,10**9);assert diam_floor**2<diam2<1
rad=F(51,100);assert max(a*a+b*b for a,b in P)<rad**2
clear=F(old['clearance_floor']);out=[]
for row in old['examples']:
    eps=F(row['ball_radius']);s=F(row['center_scale']);d=F(row['maximum_motion'])
    assert s==1-2*eps and d==(1-s)*rad+eps
    min_diam=s*diam_floor-2*eps;assert 0<min_diam<1
    R=s*rad+eps
    moved=d+R*(1/min_diam-1);moved_hi=F((moved*10**12).__ceil__(),10**12)
    assert moved_hi<clear
    out.append(dict(ball_radius=str(eps),pre_normalization_diameter_lower=str(min_diam),normalized_maximum_motion_upper=str(moved_hi),strict_global_area_floor=row['strict_area_floor']))
print(json.dumps(out,indent=2))

"""Rational centers of nine independent planar balls with a common fixed unit diameter."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json,sys
raw=json.loads(Path(sys.argv[1]).read_bytes());proof=json.loads(Path(sys.argv[2]).read_bytes())
p=raw['points'];D=raw['denominator'];P=[(F(x,D),F(y,D)) for x,y in p]
dist=lambda p,q:sum((a-b)**2 for a,b in zip(p,q))
n2,i,j=max((dist(p[a],p[b]),a,b) for a,b in combinations(range(11),2))
assert (i,j)==(4,10) and n2==999999994539195050
vx,vy=p[j][0]-p[i][0],p[j][1]-p[i][1]
def canonical(z):
    x,y=z[0]-p[i][0],z[1]-p[i][1]
    return F(vx*x+vy*y,n2),F(vx*y-vy*x,n2)
z0=list(map(canonical,p));assert z0[i]==(0,0) and z0[j]==(1,0)
assert max(dist(a,b) for a,b in combinations(z0,2))==1
M=(F(1,2),F(0));rad=F(571,1000);assert all(dist(x,M)<rad*rad for k,x in enumerate(z0) if k not in [i,j])
delta=F(27,10**7);eta=2*delta
centers=[list(map(str,x if k in (i,j) else tuple((1-eta)*v+eta*m for v,m in zip(x,M)))) for k,x in enumerate(z0)]
motion=rad*eta+delta;min_raw=F(999999997,10**9);assert min_raw**2<F(n2,D**2)<1
max_norm_motion=(1/min_raw-1)*F(51,100)
assert all(x*x+y*y<F(51,100)**2 for x,y in P)
clear=F(proof['clearance_floor']);assert motion+max_norm_motion<clear
floor=F((F('.83732')/(1+2*motion)**2*10**12).__floor__(),10**12);assert floor>F('.83730')
z=dict(diameter_endpoints=[i,j],fixed_locations=[[0,0],[1,0]],free_indices=[k for k in range(11) if k not in [i,j]],centers=centers,free_ball_radius=str(delta),diameter=1,displacement_from_normalized=str(motion),maximum_displacement_from_aligned_original=str(F(((motion+max_norm_motion)*10**12).__ceil__(),10**12)),strict_global_lower=str(floor),deletion_clearance=str(clear))
print(json.dumps(z,indent=2))

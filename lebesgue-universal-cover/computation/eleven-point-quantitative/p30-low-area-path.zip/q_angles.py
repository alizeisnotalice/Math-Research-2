"""Recompute the exact complete angular padding obstruction for either named Q11."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from flint import arb,ctx
from scipy.optimize import linprog

from trial_support import angle_poses,data,material_normals,norm
from exact_area import placed

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def setup(comp):
    sys.path.insert(0,str(comp.resolve()))
    from certify_multi_host_points import SupportHull
    from certify_q11_structural_anchor import NORMAL_DEN,weights
    from certify_mixed_support_budget import ar,det,dot,rotate
    return SupportHull,NORMAL_DEN,weights,ar,det,dot,rotate

def selected_cases(args):
    six=json.loads(args.six.read_bytes())
    r=json.loads(args.fixed.read_bytes())
    hosts={'R155':r['original-R155-five']['host'],'R237':r['original-R237-seven']['host'],'new-six':six}
    return [(key,h,q) for key,h in hosts.items() for q in ('oldQ11','newQ11') if q not in h['add']]

def certificate(args):
    S,DEN,weights,ar,det,dot,rotate=setup(args.comp)
    ctx.prec=160
    pi=arb.pi()
    D=data(args.comp,args.new)
    if args.make:
        cert=[]
        run=selected_cases(args)
    else:
        cert=json.loads(args.witness.read_bytes())
        run=[(r['name'],r['host'],r['cloud']) for r in cert]
        assert run==selected_cases(args)
    out={}
    for j,(name,host,cloud) in enumerate(run):
        hcur=S(list(map(ar,host['five'])))
        hpts=[pt for label,pose in host['add'].items() for pt in placed(D[label],pose,ar)]
        exact=[(x-D[cloud]['center'][0],y-D[cloud]['center'][1]) for x,y in D[cloud]['points']]
        memo={}
        def direction(seed):
            seed=tuple(seed)
            if seed not in memo:
                n,u,H=hcur.direction(seed)
                if hpts:
                    H=max(H,max(dot(u,p).upper()for p in hpts))
                memo[seed]=(n,u,H)
            return memo[seed]
        def estimate(i,k,s,rows):
            assert all(type(r) is int for r in (i,k,s)) and 2<=k<=40 and 0<=i<2**k and s in (1,-1)
            assert 2<=len(rows)<=3 and all(len(row)==3 for row in rows)
            a=ar(F(2*i+1,2**k))*pi
            width=pi/2**k
            sn,cs=a.sin_cos()
            ns=[direction(r[:2]) for r in rows]
            ws=weights([r[0] for r in ns])
            A=B=H=arb(0)
            for (_,_,p),(_,u,h),lam in zip(rows,ns,ws,strict=True):
                assert type(p) is int and 0<=p<len(exact)
                x,y=exact[p]
                z=rotate((ar(x),ar(s*y)),cs,sn)
                t=ar(lam)
                A+=t*dot(z,u)
                B+=t*det(z,u)
                H+=t*h
            assert A>0
            return (A*width.cos()-abs(B)*width.sin()-H).lower()
        if args.make:
            cand=angle_poses(host,D,cloud,768,144)
            target=F(int(cand[0][0]*1e6)-8,10**6)
            def seed(x,y):
                s=1 if x>=0 else -1
                return s,round(DEN*s*y/(1+s*x))
            theta=np.r_[np.arange(720)*2*np.pi/720,material_normals(host,D)]
            seeds=sorted(set(seed(x,y)for x,y in norm(theta) for x,y in [(x,y),(-x,-y)]))
            ns=[direction(s) for s in seeds]
            U=np.asarray([r[0]for r in ns],dtype=float)
            H=np.asarray([float(r[2])for r in ns],dtype=float)
            mesh=np.c_[U,-np.ones(len(U))]
            hands={}
            for s in (1,-1):
                P=np.asarray(exact,dtype=float)*[1,s]
                def cover(i,k):
                    angle=(2*i+1)*np.pi/2**k
                    cs,sn=np.cos(angle),np.sin(angle)
                    M=U@(P@np.array([[cs,sn],[-sn,cs]])).T
                    index=M.argmax(axis=1)
                    R=H-M[np.arange(len(index)),index]
                    lp=linprog([0,0,1],A_ub=mesh,b_ub=R,bounds=[(None,None)]*3,
                               options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9},method='highs')
                    assert lp.success
                    inds=np.where(-lp.ineqlin.marginals>1e-9)[0]
                    if len(inds) in (2,3):
                        rows=[[*seeds[m],int(index[m])] for m in inds]
                        try:
                            lb=estimate(i,k,s,rows)
                            if lb>ar(target):
                                yield [i,k,rows]
                                return
                        except AssertionError:
                            pass
                    assert k<22,(name,cloud,s,i,k,lp.fun,target)
                    yield from cover(2*i,k+1)
                    yield from cover(2*i+1,k+1)
                hands[str(s)]=[r for i in range(64)for r in cover(i,6)]
            r=dict(name=name,host=host,cloud=cloud,target=str(target),recipe=hands,numerical_poses=cand[:4])
            cert.append(r)
        else:
            r=cert[j]
            target=F(r['target'])
        summary={}
        for s in (1,-1):
            rows=r['recipe'][str(s)]
            end=F(0)
            lower=arb(1)
            for i,k,cols in rows:
                a,b=F(i,2**k),F(i+1,2**k)
                assert a==end<b<=1
                val=estimate(i,k,s,cols)
                assert val>ar(target)
                lower=min(val,lower)
                end=b
            assert end==1
            summary[str(s)]={'closed_cells':len(rows),'max_depth':max(row[1]for row in rows),'padding_lower':str(lower)}
        out[f'{name}/{cloud}']={'host':host,'threshold':str(target),'hands':summary,'numerical_poses':r['numerical_poses']}
        print(name,cloud,'>',target,'hands',[(s,x['closed_cells'])for s,x in summary.items()],r['numerical_poses'][0],flush=True)
    if args.make:
        args.witness.write_text(json.dumps(cert,separators=(',',':'))+'\n')
    args.out.write_text(json.dumps(dict(witness_sha256=digest(args.witness),code_sha256=digest(Path(__file__)),
        dependencies={k:digest(args.comp/k) for k in ('certify_multi_host_points.py','certify_q11_structural_anchor.py',
            'certify_four_body_contact_stationary.py','certify_b9_padding_four_minimizer.py','certify_mixed_support_budget.py')},
        input_sha256={k:v['sha256']for k,v in D.items()},precision=ctx.prec,cases=out),indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('comp','new','witness','out'):p.add_argument(k,type=Path)
    p.add_argument('--make',action='store_true')
    p.add_argument('--fixed',type=Path,default=Path('fixed-better-recipe.json'))
    p.add_argument('--six',type=Path,default=Path('six-best.json'))
    certificate(p.parse_args())

"""Propose distinct low-area six and seven placements using Metal and analytic refinement."""
from argparse import ArgumentParser
import ctypes
from fractions import Fraction as F
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.optimize import minimize
from trial_support import angle_poses, data, qhost

def fan(P, slots):
    def cross(o,a,b):
        return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    def half(points):
        result=[]
        for p in points:
            while len(result)>1 and cross(result[-2],result[-1],p)<=0:
                result.pop()
            result.append(p)
        return result[:-1]
    xy=sorted(set(map(tuple,P)))
    hull=half(xy)+half(reversed(xy))
    angle=[math.atan2(a[0]-b[0],b[1]-a[1]) for a,b in zip(hull,hull[1:]+hull[:1],strict=True)]
    records=[(float(x),float(y),angle[i-1],angle[i])for i,(x,y)in enumerate(hull)]
    records.extend([records[0]]*(slots-len(records)))
    assert len(records)==slots
    return np.ravel(records)

def clouds(c, qkind):
    D=data(c,Path('new30.json'))
    if qkind=='six':
        Q=[(math.cos(2*math.pi*k/11)/20,math.sin(2*math.pi*k/11)/20)for k in range(11)]
        assert all(x*x+y*y<.003 for x,y in Q)
    else:
        r=D[qkind]
        Q=[(x-r['center'][0],y-r['center'][1])for x,y in r['points']]
    return D,Q

def values(five, p, q=(0,0,0,1)):
    return [float(F(x)) for x in [*five,*p[:3],*q]]

def host(x,kind):
    assert len(x)==18
    g={'new30':[*map(repr,map(float,x[11:14])),'1']}
    if kind!='six':
        g[kind]=[*map(repr,map(float,x[14:17])),str(int(x[17]))]
    return {'five':list(map(repr,map(float,x[:11]))),'add':g}

def prepare(c,D,Q,kind,path,use=None):
    original=json.loads((c/'free-p30-reoptimized-pose.json').read_bytes())
    rb=json.loads((c/'structural-six-escape-input.json').read_bytes())['pose']
    a=json.loads(Path('fixed-numeric.json').read_bytes())
    x=a['r155-five']['padding_poses'][0]
    base=values(original[:11],x[1:4])
    assert a['r155-five']['padding_poses'][0][0]<0
    x=a['r237-seven']['padding_poses'][0]
    h=a['r237-seven']['host']
    qs=h['add']['newQ11'] if kind=='newQ11' else (0,0,0,1)
    anchors=[base,values(h['five'],x[1:4],qs),values(rb[:11],base[11:14]),values(original[:11],original[11:14])]
    for n in ('bundle-pose.json','other-pose.json','new-six-pose.json'):
        v=json.loads((c/'inclusion-minimal-eleven'/n).read_bytes())
        px,py,pa=v['point_pose']
        anchors.append(values([F(x,2**44)for x in v['center']],base[11:14],(pa,px,py,1) if kind!='six' else (0,0,0,1)))
    if use:
        prior=json.loads(use.read_bytes())
        anchors[:0]=[r['pose'] for r in prior['refined'][:6]]
    if kind!='six':
        for i in range(min(8,len(anchors))):
            v=anchors[i]
            g=host(v,'six')
            x=angle_poses(g,D,kind,normals=360,turn=108)
            best=x[0]
            anchors[i]=v[:14]+list(best[1:])
            if len(x)>1:
                anchors.append(v[:14]+list(x[1][1:]))
    else:
        for i in range(2,len(anchors)):
            q=angle_poses({'five':host(anchors[i],kind)['five'],'add':{}},D,'new30',normals=360,turn=96)[0]
            if q[0]<0:
                anchors[i][11:14]=q[1:4]
    # Repeat with separate step scales and opposite Q hand starts.
    starts=[]
    for i in range(16):
        p=anchors[i%len(anchors)].copy()
        if kind!='six' and i>=12:
            p[17]*=-1
        sigma=(.00011,.00033,.0009,.0018)[(i//4)%4]
        starts.append({'pose':p,'sigma':sigma})
    path.with_suffix('.json').write_text(json.dumps(dict(anchors=anchors,starts=starts),indent=2)+'\n')
    path.write_text('\n'.join(['16',*[' '.join(map(str,[*r['pose'],r['sigma']]))for r in starts],
                              ' '.join(map(str,np.r_[fan(D['new30']['points'],30),fan(Q,11)]))])+'\n')

def rank(D,Q,kind,libpath,startsfile,tsv,out,pose):
    lib=ctypes.CDLL(str(libpath.resolve()))
    vec=np.ctypeslib.ndpointer(np.float64,1,flags='C_CONTIGUOUS')
    lib.set_cloud.argtypes=[vec,vec]
    lib.set_cloud(D['new30']['xy'].ravel(), np.asarray(Q,dtype=np.float64).ravel())
    lib.measure_gradient.argtypes=[vec,ctypes.c_int,vec]
    lib.measure_gradient.restype=ctypes.c_double
    lib.measure.argtypes=[vec,ctypes.c_int]
    lib.measure.restype=ctypes.c_double
    arr=np.loadtxt(tsv,ndmin=2) if tsv else np.empty((0,22))
    starts=json.loads(startsfile.read_bytes())['anchors']
    num=14 if kind=='six' else 17
    numcalls=0
    def area(p,s):
        nonlocal numcalls
        numcalls+=1
        return lib.measure(np.ascontiguousarray(p,dtype=np.float64),int(s))
    gpu=[(area(row[4:-1],row[-1]),list(row[4:]),'Metal',int(row[0]),int(row[1])) for row in arr]
    input_seeds=gpu+[(area(x[:-1],x[-1]),x,'anchor',0,i)for i,x in enumerate(starts)]
    scale=np.ones(num)
    scale[[i for i in (2,5,8,11,14) if i<num]]=5
    picks=[]
    for candidate in sorted(input_seeds):
        _,z,_,_,_=candidate
        if any(np.linalg.norm((np.array(z[:num])-np.array(row[1][:num]))/scale)<.00012 and z[-1]==row[1][-1] for row in picks):
            continue
        picks.append(candidate)
        if len(picks)>=15:
            break
    result=[]
    start=time.monotonic()
    for f,z,source,epoch,island in picks:
        p=np.array(z,dtype=np.float64)
        sg=int(p[-1])
        best=[f,p[:-1]]
        def fun(v):
            x=p[:-1].copy()
            x[:num]+=v*scale
            grad=np.empty(17)
            n=lib.measure_gradient(x,sg,grad)
            if n<best[0]:
                best[:]=n,x
            return n-.8375,grad[:num]*scale
        r=minimize(fun,np.zeros(num),jac=True,method='BFGS',options={'maxiter':1000,'gtol':2e-11,'xrtol':1e-12})
        result.append(dict(area=best[0],pose=list(best[1])+[sg],start=f,source=source,epoch=epoch,island=island,calls=r.nfev,status=str(r.message)))
        print(kind,source, f,best[0],r.nfev,flush=True)
    result.sort(key=lambda r:r['area'])
    out.write_text(json.dumps(dict(scope='floating true envelope only',refined=result,elapsed=time.monotonic()-start,
                              objective_calls=numcalls,tsv_rows=len(arr),metal_best=min(gpu,default=None)),indent=2)+'\n')
    pose.write_text(json.dumps(host(result[0]['pose'],kind),indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('kind',choices=['six','oldQ11','newQ11'])
    p.add_argument('starts',type=Path)
    p.add_argument('--use',type=Path)
    p.add_argument('--lib',type=Path)
    p.add_argument('--tsv',type=Path)
    p.add_argument('--out',type=Path)
    p.add_argument('--pose',type=Path)
    a=p.parse_args()
    D,Q=clouds(a.comp,a.kind)
    if a.lib:
        rank(D,Q,a.kind,a.lib,a.starts,a.tsv,a.out,a.pose)
    else:
        prepare(a.comp,D,Q,a.kind,a.starts,a.use)

"""Certify both old and new P30 throughout the original R155--R183 pose segment."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb,ctx
from exact_area import placed
from trial_support import data

def sha(path):
    return sha256(path.read_bytes()).hexdigest()

def main(a):
    sys.path.insert(0,str(a.comp.resolve()))
    from certify_mixed_support_budget import Host,ar
    from certify_six_anchor_path import FIVE_SPEED,data_files,motion,p30_clearance,pose_at,midpoint
    c=data_files(a.comp)
    ctx.prec=160
    pi=arb.pi()
    A=list(map(F,c['free-p30-reoptimized-pose.json']))
    B=list(map(F,c['structural-six-escape-input.json']['pose']))
    D=data(a.comp,a.cloud)
    raw=json.loads(a.recipe.read_bytes())
    fived,old_speed=motion(A,B,c['finite-point-leaf-input.json'],pi)
    w=[list(map(F,raw[e]))for e in ('r155','r183')]
    assert len(w[0])==len(w[1])==4 and w[0][3]==w[1][3]==1
    dt,dx,dy=[y-x for x,y in zip(*w,strict=True)][:3]
    rad=F('.6')
    assert all(x*x+y*y<rad*rad for x,y in D['new30']['points'])
    new_speed=F('.005') # checked strict upper, pointwise rotation derivative at most radius
    assert ar(dx*dx+dy*dy).sqrt()+ar(rad*abs(dt))<ar(new_speed)
    n=32
    floor={'old30':arb(1),'new30':arb(1)}
    cert=[]
    for i in range(n):
        t=midpoint(i,n)
        center=pose_at(A,B,t)
        host=Host(center[:11],pi)
        r={'i':i,'t':str(t)}
        for k,p,speed in [('old30',center[11:]+[1],F('.003675')),('new30',pose_at(*w,t),new_speed)]:
            ph=p30_clearance(host,placed(D[k],p,ar))
            val=ph-ar((speed+FIVE_SPEED)/(2*n))
            assert val>0,(i,k,val)
            floor[k]=min(floor[k],val.lower())
            r[k]={'center_clearance':str(ph),'closed_cell_clearance':str(val)}
        cert.append(r)
    margin={k:str(v)for k,v in floor.items()}
    print('closed R188 common path',n,margin,flush=True)
    a.out.write_text(json.dumps(dict(source_poses={k:sha(a.comp/k)for k in
        ('free-p30-reoptimized-pose.json','structural-six-escape-input.json','six-anchor-path-audit.json','certify_six_anchor_path.py','certify_mixed_support_budget.py')},
        replay_code_sha256=sha(Path(__file__)),recipe_sha256=sha(a.recipe),cloud_sha256={k:v['sha256']for k,v in D.items()},
        fixed_five_derivative_arb=fived,old30_motion_arb=old_speed,new30_speed_bound=str(new_speed),
        full_closed_path_common_containment=margin,centers=cert),indent=2)+'\n')
if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('comp','cloud','recipe','out'):
        p.add_argument(k,type=Path)
    main(p.parse_args())

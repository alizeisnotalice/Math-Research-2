"""Harmonic support of exact body inputs, for floating LP proposals."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog, minimize_scalar

def data(comp,new30):
    group={
        'old30':comp/'finite-point-leaf-input.json',
        'new30':new30,
        'oldQ11':comp/'multi-host-points.json',
        'newQ11':comp/'inclusion-minimal-eleven/new-points.json',
    }
    H={
        'old30':'b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc',
        'new30':'1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58',
        'oldQ11':'9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282',
        'newQ11':'45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05',
    }
    out={}
    for name,path in group.items():
        raw=path.read_bytes()
        assert sha256(raw).hexdigest()==H[name]
        r=json.loads(raw);den=r.get('denominator',r.get('point_denominator'))
        vertices=r['points']
        diam=max(sum((x-y)**2 for x,y in zip(a,b))for a in vertices for b in vertices)
        assert diam<=den*den
        P=[[F(x,den)for x in a]for a in vertices]
        center=[sum(p[j]for p in P)/len(P)for j in range(2)]if name=='oldQ11' else [F(0)]*2
        out[name]=dict(path=path,points=P,xy=np.array(P,dtype=float)-np.array(center,dtype=float),
                       center=center,symmetric={tuple(p)for p in P}=={(x,-y)for x,y in P},sha256=H[name],diameter_square=F(diam,den**2))
    return out

def norm(t):
    return np.stack((np.cos(t),np.sin(t)),axis=-1)

def curved_support(t,pose):
    h=np.full_like(t,.5)
    for i,n in enumerate((3,5,7,9)):
        angle,dx,dy=(0.,*pose[:2]) if i==0 else pose[3*i-1:3*i+2]
        phase=2*np.pi/n
        u=t-angle;k=abs(u-np.rint(u/phase)*phase)
        R=.5/np.cos(phase/4)
        h=np.maximum(h,np.where(k<=phase/4,R*np.cos(k),1-R*np.cos(phase/2-k))+norm(t)@np.array([dx,dy]))
    return h

def cloud_support(t,P,pose):
    a,x,y,s=pose
    return (norm(t-a)@(P*np.array([1.,s])).T).max(axis=1)+norm(t)@np.array([x,y])

def host_support(theta,host,clouds):
    ans=curved_support(theta,np.array(list(map(F,host["five"])),dtype=float))
    for k,p in host.get('add',{}).items():
        ans=np.maximum(ans,cloud_support(theta,clouds[k]['xy'],[float(F(x)) for x in p]))
    return ans

def material_normals(host,clouds):
    from scipy.spatial import ConvexHull
    pi=np.pi
    samples=[norm(np.arange(4096)*2*pi/4096)/2]
    p=list(map(F,host['five']))
    for n,k in ((3,0),(5,2),(7,5),(9,8)):
        angle,tx,ty=(0.,*map(float,p[:2])) if n==3 else map(float,p[k:k+3])
        phase=angle+2*pi*np.arange(n)/n
        center=norm(phase)/ (2*np.cos(pi/(2*n)))+np.array([tx,ty])
        samples.append((center[:,None,:]+norm(phase[:,None] + pi - pi/(2*n) + np.arange(257)*pi/(n*256))).reshape(-1,2))
    for key,where in host.get('add',{}).items():
        angle,tx,ty,sign=map(float,map(F,where))
        c,s=np.cos(angle),np.sin(angle)
        samples.append(clouds[key]['xy']*[1,sign]@np.array([[c,s],[-s,c]])+[tx,ty])
    P=np.concatenate(samples)
    vertices=P[ConvexHull(P).vertices]
    edges=np.roll(vertices,-1,axis=0)-vertices
    edges=edges[np.linalg.norm(edges,axis=1) > .003]
    return np.arctan2(-edges[:,0],edges[:,1])%(2*pi)

def angle_poses(host,clouds,target,normals=480,turn=180,extra=(), material=True):
    theta=2*np.pi*np.arange(normals)/normals
    if material:
        theta=np.unique(np.r_[theta,material_normals(host,clouds)])
    u=norm(theta)
    matrix=np.c_[u,-np.ones(len(theta))]
    H=host_support(theta,host,clouds)
    def run(a,sign):
        q=norm(theta-a)@(clouds[target]['xy']*np.array([1,sign])).T
        r=linprog([0.,0.,1.],A_ub=matrix,b_ub=H-q.max(axis=1),bounds=[(None,None)]*3,method='highs')
        assert r.success
        return float(r.x[-1]),float(a%(2*np.pi)),float(r.x[0]),float(r.x[1]),sign
    results=[]
    k=2*np.pi/turn
    for s in ((1,)if clouds[target]['symmetric']else (1,-1)):
        samples=[run(i*k,s)for i in range(turn)]
        intervals=[x[1]for i,x in enumerate(samples)if x[0]<=samples[(i-1)%turn][0] and x[0]<=samples[(i+1)%turn][0]]
        intervals+=list(extra)
        for a in intervals:
            r=minimize_scalar(lambda x:run(x,s)[0],bounds=(a-k,a+k),method='bounded',
                              options={'xatol':2e-12})
            results.append(run(r.x,s))
    results.sort()
    return results

def qhost(r,clouds,extra):
    raw=r['center'];p=[str(F(x,2**44)) for x in raw]
    x,y,a=r['point_pose']
    d={'old30':[a,x,y,'1']}
    if extra:
        x,y,a=r['second_point_pose']
        d['newQ11']=[a,x,y,'1']
    return dict(five=p,add=d)

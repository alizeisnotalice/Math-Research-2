"""Replay frozen rational poses, both-hand Q11 angles, and the complete R188 path."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
CAP_RECEIPT='cap-transfer-audit.json'
CAP_SOURCES={
    'fixed':'fixed-better-audit.json',
    'optimized':'optimized-audit.json',
    'angles':'q-angle-replay.json',
}

def comparable_receipts(directory,names):
    raw={name:(directory/name).read_bytes() for name in names}
    receipts={name:json.loads(content) for name,content in raw.items()}
    # Bind each cap transfer to its own raw input receipts before comparing
    # mathematical fields across Python versions.
    source_hashes={label:sha256(raw[name]).hexdigest() for label,name in CAP_SOURCES.items()}
    checked_sources=receipts[CAP_RECEIPT].pop('checked_sources')
    assert checked_sources==source_hashes,(directory,CAP_RECEIPT,'checked_sources')
    for receipt in receipts.values():
        for key in ('python','flint'):
            receipt.pop(key,None)
    return receipts

def main(a):
    if not a.out.is_dir():
        a.out.mkdir()
    out=a.out.resolve()
    comp=a.comp.resolve()
    new=HERE/'new30.json'
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1')
    def run(file,*args):
        # Isolated execution omits the script directory from sys.path.
        # Insert just this package, never the caller's working directory.
        code='import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); f=sys.argv[1]; sys.argv=sys.argv[1:]; runpy.run_path(f,run_name="__main__")'
        subprocess.run([sys.executable,'-I','-B','-c',code,str(HERE),str(HERE/file),*map(str,args)],
                       cwd=HERE,env=env,check=True)
    fixed=out/'fixed-better-audit.json'
    opt=out/'optimized-audit.json'
    angles=out/'q-angle-replay.json'
    path=out/'path-audit.json'
    cap=out/'cap-transfer-audit.json'
    run('exact_area.py',comp,new,HERE/'fixed-better-recipe.json',fixed)
    run('exact_area.py',comp,new,HERE/'optimized-recipe.json',opt)
    run('q_angles.py',comp,new,HERE/'q-angle-rows.json',angles,
        '--fixed',HERE/'fixed-better-recipe.json','--six',HERE/'six-best.json')
    run('common_path.py',comp,new,HERE/'path-recipe.json',path)
    run('cap_transfer.py',comp,fixed,opt,angles,cap,'--workers',a.workers)
    names=[receipt.name for receipt in (fixed,opt,angles,path,cap)]
    result=comparable_receipts(out,names)
    expected=comparable_receipts(HERE,names)
    for name in names:
        assert result[name]==expected[name],name
    ok={name:'fresh computation matches frozen receipt' for name in names}
    from flint import arb,ctx
    ctx.prec=160
    def ball(q):
        x=F(q)
        return arb(x.numerator)/x.denominator
    A=json.loads(fixed.read_bytes())['cases']
    B=json.loads(opt.read_bytes())['cases']
    C=json.loads((out/'path-audit.json').read_bytes())['full_closed_path_common_containment']
    assert F('.83750')<F(B['six']['area_lower'])<F(B['six']['area_upper'])<F(A['original-R155-five']['area_lower'])
    assert F(B['newQ11']['area_upper'])<F('.837761801603')
    assert F(B['oldQ11']['area_upper'])<F('.837880535817')
    assert arb(A['original-R155-five']['fit']['old30']['arb_lowest'])>ball('.00033713')
    assert arb(A['original-R155-five']['fit']['new30']['arb_lowest'])>ball('.00022132')
    assert arb(A['original-R237-seven']['fit']['new30']['arb_lowest'])>ball('.00025117')
    assert arb(A['original-R183-six']['fit']['new30']['arb_lowest'])>ball('.00023780')
    assert arb(C['old30'])>ball('.00027655') and arb(C['new30'])>ball('.00013309')
    print(json.dumps(ok,indent=2))

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('out',type=Path)
    p.add_argument('--workers',type=int,default=4)
    main(p.parse_args())

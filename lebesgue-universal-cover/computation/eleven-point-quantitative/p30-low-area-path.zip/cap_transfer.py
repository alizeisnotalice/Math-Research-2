"""Transfer each closed-angle support padding to an area lower endpoint."""
from argparse import ArgumentParser
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb,ctx

def load(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def bound(area,radius,gap,ar):
    assert F(1,2)<=radius and gap>0
    r=F(1,2)
    denominator=(radius+gap)**2-r*r
    gain=ar(r*gap**2) / ar(denominator).sqrt()
    z=ar(area)+gain
    scale=10**12
    result=F(int(float(z.mid())*scale)-1,scale)
    assert z>ar(result)
    return dict(area_lower=str(area),radius_upper=str(radius),padding_lower=str(gap),cap_lower_arb=str(gain),
                augmented_area_strict_lower=str(result),display=float(result))

def main(a):
    sys.path.insert(0,str(a.comp.resolve()))
    from certify_six_anchor_path import AREA_PIECES,FIVE_SPEED,area_job,data_files,motion
    from certify_mixed_support_budget import ar
    ctx.prec=160
    ps=load(a.fixed)['cases']
    opt=load(a.optimized)['cases']
    angles=load(a.angles)['cases']
    aout={}
    certfiles={'fixed':digest(a.fixed),'optimized':digest(a.optimized),'angles':digest(a.angles)}
    for p,row in angles.items():
        h,q=p.split('/')
        case={'R155':ps['original-R155-five'],'R237':ps['original-R237-seven'],'new-six':opt['six']}[h]
        assert case['host']==row['host']
        assert set(row['hands'])=={'1','-1'}
        assert all(arb(t['padding_lower'])>ar(F(row['threshold']))for t in row['hands'].values())
        aout[p]=bound(F(case['area_lower']),F(case['radius_upper']),F(row['threshold']),ar)
    c=data_files(a.comp)
    start=list(map(F,c['free-p30-reoptimized-pose.json']))
    end=list(map(F,c['structural-six-escape-input.json']['pose']))
    motion(start,end,c['finite-point-leaf-input.json'],arb.pi())
    jobs=[(i,AREA_PIECES,start,end)for i in range(AREA_PIECES)]
    if a.workers==1:
        area_rows=list(map(area_job,jobs))
    else:
        with ProcessPoolExecutor(max_workers=a.workers) as pool:
            area_rows=list(pool.map(area_job,jobs,chunksize=4))
    old=load(a.comp/'six-anchor-path-audit.json')
    assert area_rows==old['area_cells']
    low=min(F(d['whole_area_lower'])for d in area_rows)
    up=max(F(d['whole_area_upper'])for d in area_rows)
    assert low>F('.83750332922646') and up<F('.83752270510714')
    for cloud in ('oldQ11','newQ11'):
        pad=F(angles[f'R155/{cloud}']['threshold'])-FIVE_SPEED
        radius=F(ps['original-R155-five']['radius_upper'])+FIVE_SPEED
        aout[f'R188-closed-path/{cloud}']=bound(low,radius,pad,ar)
    for k,x in aout.items(): print(k,x['display'],flush=True)
    a.out.write_text(json.dumps(dict(recomputed_closed_path_area_cells=AREA_PIECES,
        closed_path_area_bracket=[str(low),str(up)],checked_sources=certfiles,
        main_R188_area_audit_sha256=digest(a.comp/'six-anchor-path-audit.json'),
        caps=aout),indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('comp','fixed','optimized','angles','out'):
        p.add_argument(k,type=Path)
    p.add_argument('--workers',type=int,default=1)
    main(p.parse_args())

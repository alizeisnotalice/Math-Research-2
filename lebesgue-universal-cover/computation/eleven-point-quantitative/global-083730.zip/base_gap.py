"""Combine the published global five-body stability theorem with the fixed H* obstruction."""
import argparse,json
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256

def run(comp,tube):
    stable=comp/'five-host-stability.json'
    assert sha256(stable.read_bytes()).hexdigest()=='335ba916015f2096e553761946be364b4c76761b8151bc6d1a017535ba7fb710'
    data=json.loads(stable.read_bytes());U=F(data['threshold_decimal']);d=F(data['rounded_threshold_bound'])
    m_upper=F('0.837295006221025243456393253909267018678')
    fixed=F(json.loads((tube/'hinge-audit.json').read_bytes())['star-fine-837680']['strict_target'])
    assert m_upper<U and m_upper*(1+2*d)**2<fixed
    return dict(strict_global_lower=str(U),strict_improvement_over_M=str(U-m_upper),upper_if_joint_feasible=str(m_upper*(1+2*d)**2),fixed_obstruction=str(fixed))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('tube',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();assert __debug__;v=run(a.comp,a.tube);a.out.write_text(json.dumps(v,indent=2)+'\n');print(v)

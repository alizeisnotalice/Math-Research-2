"""Replay every original leaf of the five-body 0.83730 exterior against the new rational eleven-point set."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse,ctypes,gzip,json,sys
from flint import arb,ctx
import numpy as np
from dual_bank import grid,q,U
from support_grid import make
from verify_bank import verify
S=2**44;Z=2**28
def dig(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def ints(rows):return np.ascontiguousarray(rows,dtype=np.int64).ravel()

def run(c,tree,table,kernel,work,workers):
    proof=Path(__file__).resolve().parent
    sys.path.insert(0,str(c.resolve()))
    from verify_tomar_fan_table import verified_table,PINNED_MANIFEST
    from certify_finite_point_leaf import upper_q
    from tomar_leaf_box import leaf_box
    ctx.prec=160
    lower=c/'five-global-minimum-single-worker-replay.json'
    assert dig(lower)=='9e585a5a5ef9c69f7394a1ab61e2393652cedfca64ab351091344f21cbbc55cf'
    m=F('.83729500622102524');assert q(m)<arb(read(lower)['minimum_interval'])
    base=(2*Z**2*m).__floor__();target=F('.83730');threshold=(2*Z**2*target).__floor__()+1
    rad=q('.706');assert (arb.pi()-(q('.5')/rad).acos())/4+q('.5')*(rad*rad-q('.25')).sqrt()>q(target)
    old=c/'five-global-localization.json';ext=c/'tomar-outer-083730-retained.json';receipt=c/'tomar-outer-083730-main-replay.json'
    assert dig(old)=='d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504'
    assert dig(ext)=='901f258d9a4ff75fa3cf3d788d487c2890b179e3c256ec813bb0c0845c7c7969'
    assert dig(receipt)=='5aa33871b014cf77fac4cd3db1109a2eb05bcfe9f8ec5a7a210f870126e7762d'
    checked=read(receipt);assert checked['complete'] and F(checked['target'])==target and checked['retained']==read(ext)['retained']
    keys=sorted((int(p),k) for arr in [read(old)['retained'],read(ext)['retained']] for p,ids in arr.items() for k in ids)
    assert len(keys)==len(set(keys))==541
    bank=proof/'balanced384.json.gz';assert verify(proof/'new-points.json',bank)>0
    b=json.loads(gzip.decompress(bank.read_bytes()));g=grid()
    assert b['directions']==list(map(list,g)) and len(b['cells'])==2*b['knots']
    ptr=ints([0]+list(np.cumsum([len(c) for c in b['cells']])));rows=ints([r for v in b['cells'] for r in v]);assert len(rows)==8*ptr[-1]
    mesh=make();disk=ints([upper_q(q(F(x*x+y*y,U*U)).sqrt()/2) for x,y in g]);dirs=ints(g)
    manifest=tree/'SHA256SUMS';assert dig(manifest)==PINNED_MANIFEST
    pin={name.removeprefix('./'):h for h,name in (l.split() for l in manifest.read_text().splitlines())}
    hf=tree/'part0000.json';assert dig(hf)==pin[hf.name];head=read(hf)
    assert dig(table)=='0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d'
    pts,counts=verified_table(table,tree,head);pts=pts.ravel()
    orig=ints([(F(v)*S).__floor__() for v in head['hi']]);assert all(F(v)*S==k for v,k in zip(head['hi'],orig))
    boxes={}
    for p in sorted(set(k[0] for k in keys)):
        hf=tree/f'part{p:04}.json';tf=hf.with_suffix('.npy');assert dig(hf)==pin[hf.name] and dig(tf)==pin[tf.name]
        meta=read(hf);codes=np.load(tf,allow_pickle=False);pre=np.r_[1,1+np.cumsum(np.where(codes<11,1,-1))]
        for _,i in (key for key in keys if key[0]==p):
            center,width=leaf_box(pre,codes,p,i,meta);bounds=[(F(x)+sg*F(y))*S for sg in (-1,1) for x,y in zip(center,width)]
            assert all(x.denominator==1 for x in bounds);boxes[p,i]=(ints(bounds[:11]),ints(bounds[11:]))
    fn=ctypes.CDLL(str(kernel.resolve())).dynamic_guard_run;i64=np.ctypeslib.ndpointer(np.int64,ndim=1,flags='C_CONTIGUOUS');i32=np.ctypeslib.ndpointer(np.int32,ndim=1,flags='C_CONTIGUOUS')
    fn.argtypes=[i64]*3+[i32]*2+[ctypes.c_int64,ctypes.c_int,ctypes.c_int]+[i64]*5+[ctypes.c_int]*2+[i64,ctypes.c_int64,i64]
    def job(key):
        lo,hi=boxes[key];ret=np.zeros(30,np.int64);unused=ints([0])
        assert fn(lo,hi,orig,pts,counts,threshold,110,4194303,dirs,disk,unused,ptr,rows,len(g),len(b['cells']),ret,base,mesh)==0
        assert ret[0]==1 and ret[1]==2*(ret[2]+ret[3])-1,(key,ret.tolist())
        return dict(leaf=list(key),target=str(target),out=ret[:5].tolist(),front=None)
    with ThreadPoolExecutor(workers) as ex:
        got=list(ex.map(job,keys))
    raw=''.join(json.dumps(row,separators=(',',':'))+'\n' for row in got).encode()
    assert gzip.decompress((proof/'terminal541.jsonl.gz').read_bytes())==raw
    work.write_bytes(raw);return [sum(r['out'][i] for r in got) for i in (1,2,3)]

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('comp','tree','table64','kernel','output'):p.add_argument(k,type=Path)
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args();assert __debug__;print(run(a.comp,a.tree,a.table64,a.kernel,a.output,a.workers))

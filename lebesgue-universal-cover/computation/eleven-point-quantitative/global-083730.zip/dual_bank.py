from fractions import Fraction as F
from flint import arb
import math
U=2**22;W=2**30;AUX=2**28;N=256
def q(x):x=F(x);return arb(x.numerator)/x.denominator
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def cross(a,b,c):return det((b[0]-a[0],b[1]-a[1]),(c[0]-a[0],c[1]-a[1]))
def hull(x):
    def half(v):
        seq=[]
        for z in v:
            while len(seq)>=2 and cross(seq[-2],seq[-1],z)<=0:seq.pop()
            seq.append(z)
        return seq[:-1]
    x=sorted(x);return half(x)+half(x[::-1])
def grid():
    dirs=[(round(U*math.cos(2*math.pi*j/N)),round(U*math.sin(2*math.pi*j/N))) for j in range(N)]
    assert all((U-2)**2<x*x+y*y<(U+2)**2 for x,y in dirs)
    return dirs


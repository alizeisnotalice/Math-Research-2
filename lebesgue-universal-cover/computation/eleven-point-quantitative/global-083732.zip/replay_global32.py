"""Replay every original leaf of the five-body 0.83732 exterior against the new rational eleven-point set."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse,ctypes,gzip,json,sys
from flint import arb,ctx
import numpy as np
from dual_bank import grid,q,U
from support_grid import make
from verify_bank import verify
S=2**44;Z=2**28
def dig(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def ints(rows):return np.ascontiguousarray(rows,dtype=np.int64).ravel()

def run(c,tree,table,kernel,work,workers):
    proof=Path(__file__).resolve().parent
    sys.path.insert(0,str(c.resolve()))
    from verify_tomar_fan_table import verified_table,PINNED_MANIFEST
    from certify_finite_point_leaf import upper_q
    from tomar_leaf_box import leaf_box
    ctx.prec=160
    lower=c/'five-global-minimum-single-worker-replay.json'
    assert dig(lower)=='9e585a5a5ef9c69f7394a1ab61e2393652cedfca64ab351091344f21cbbc55cf'
    m=F('.83729500622102524');assert q(m)<arb(read(lower)['minimum_interval'])
    base=(2*Z**2*m).__floor__();target=F('.83732');threshold=(2*Z**2*target).__floor__()+1
    rad=q('.706');assert (arb.pi()-(q('.5')/rad).acos())/4+q('.5')*(rad*rad-q('.25')).sqrt()>q(target)
    exterior=c/'tomar-083732-retained.json';audit=c/'tomar-083732-score-layers-audit.json'
    assert dig(exterior)=='605e3b3b2d6268a41faba14300c61dcebfd27c726d549e13916c08261bc855a9'
    assert dig(audit)=='a86a2bdad0a1a8e04ff6c4fdfb327075fadad6044c798a71c9f102c10905078c'
    ext=read(exterior);r=read(audit);assert F(r['target'])==target and r['retained']==ext
    keys=sorted((int(p),i) for p,ids in ext.items() for i in ids);assert len(keys)==len(set(keys))==705
    bank=proof/'balanced384.json.gz';sub=proof/'balanced1536.json.gz'
    assert verify(proof/'new-points.json',bank)==4634 and verify(proof/'new-points.json',sub)==43904
    b=json.loads(gzip.decompress(bank.read_bytes()));f=json.loads(gzip.decompress(sub.read_bytes()));g=grid()
    assert b['directions']==f['directions']==list(map(list,g))
    assert len(b['cells'])==2*b['knots']==768 and len(f['cells'])==2*f['knots']==3072
    coarse=len(b['cells']);b['cells']+=f['cells'];use_fine={tuple(k) for k in read(proof/'fine-roots.json')};assert use_fine<=set(keys)
    ptr=ints([0]+list(np.cumsum([len(c) for c in b['cells']])));rows=ints([r for v in b['cells'] for r in v]);assert len(rows)==8*ptr[-1]
    mesh=make();disk=ints([upper_q(q(F(x*x+y*y,U*U)).sqrt()/2) for x,y in g]);dirs=ints(g)
    manifest=tree/'SHA256SUMS';assert dig(manifest)==PINNED_MANIFEST
    pin={name.removeprefix('./'):h for h,name in (l.split() for l in manifest.read_text().splitlines())}
    hf=tree/'part0000.json';assert dig(hf)==pin[hf.name];head=read(hf)
    assert dig(table)=='0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d'
    pts,counts=verified_table(table,tree,head);pts=pts.ravel()
    orig=ints([(F(v)*S).__floor__() for v in head['hi']]);assert all(F(v)*S==k for v,k in zip(head['hi'],orig))
    boxes={}
    for p in sorted(set(k[0] for k in keys)):
        hf=tree/f'part{p:04}.json';tf=hf.with_suffix('.npy');assert dig(hf)==pin[hf.name] and dig(tf)==pin[tf.name]
        meta=read(hf);codes=np.load(tf,allow_pickle=False);pre=np.r_[1,1+np.cumsum(np.where(codes<11,1,-1))]
        for _,i in (key for key in keys if key[0]==p):
            center,width=leaf_box(pre,codes,p,i,meta);bounds=[(F(x)+sg*F(y))*S for sg in (-1,1) for x,y in zip(center,width)]
            assert all(x.denominator==1 for x in bounds);boxes[p,i]=(ints(bounds[:11]),ints(bounds[11:]))
    fn=ctypes.CDLL(str(kernel.resolve())).dynamic_guard_run;i64=np.ctypeslib.ndpointer(np.int64,ndim=1,flags='C_CONTIGUOUS');i32=np.ctypeslib.ndpointer(np.int32,ndim=1,flags='C_CONTIGUOUS')
    fn.argtypes=[i64]*3+[i32]*2+[ctypes.c_int64,ctypes.c_int,ctypes.c_int]+[i64]*5+[ctypes.c_int]*2+[i64,ctypes.c_int64,i64]
    def job(key):
        lo,hi=boxes[key];ret=np.zeros(30,np.int64);unused=ints([0])
        assert fn(lo,hi,orig,pts,counts,threshold,110,4194303,dirs,disk,unused,ptr,rows,len(g),(-coarse if key in use_fine else coarse),ret,base,mesh)==0
        assert ret[0]==1 and ret[1]==2*(ret[2]+ret[3])-1,(key,ret.tolist())
        return dict(leaf=list(key),target=str(target),out=ret[:5].tolist(),front=None)
    with ThreadPoolExecutor(workers) as ex:
        got=list(ex.map(job,keys))
    raw=''.join(json.dumps(row,separators=(',',':'))+'\n' for row in got).encode()
    assert gzip.decompress((proof/'terminal705.jsonl.gz').read_bytes())==raw
    work.write_bytes(raw);return [sum(r['out'][i] for r in got) for i in (1,2,3)]

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('comp','tree','table64','kernel','output'):p.add_argument(k,type=Path)
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args();assert __debug__;print(run(a.comp,a.tree,a.table64,a.kernel,a.output,a.workers))

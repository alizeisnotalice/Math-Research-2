"""Certify an open product neighborhood of critical diameter-one eleven-point inputs."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse,json,sys
from flint import arb,ctx
def q(x):x=F(x);return arb(x.numerator)/x.denominator
def bound(c,source):
    ctx.prec=192;sys.path.insert(0,str(c.resolve()));sys.path.insert(0,str(source.resolve()))
    from template import build
    import certify_five_body_contact_stationary as stationary
    _,actual,_,_=stationary.model(*(stationary.interval(*s) for s in stationary.BOX))
    lohi=[[int((x.lower()*2**44).floor().unique_fmpz()),int((x.upper()*2**44).ceil().unique_fmpz())] for x in actual]
    inner,D=build(c,False,192,True,box=lohi)
    raw=(source/'new-points.json').read_bytes();assert sha256(raw).hexdigest()=='45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05'
    p=json.loads(raw);P=[(F(x,p['denominator']),F(y,p['denominator'])) for x,y in p['points']]
    assert max(x*x+y*y for x,y in P)<F(51,100)**2
    assert max((x-a)**2+(y-b)**2 for x,y in P for a,b in P)<1
    placements=json.loads((source/'deletions.json').read_bytes())
    assert sorted(row['deleted'] for row in placements)==list(range(11))
    per=[]
    for row in placements:
        sn,cs=(arb.pi()*row['angle_numerator']/row['angle_denominator']).sin_cos()
        hand=row['hand'];assert hand in (1,-1)
        tx=q(F(row['tx'],row['translation_grid']));ty=q(F(row['ty'],row['translation_grid']))
        cloud=[(tx+cs*q(x)-hand*sn*q(y),ty+sn*q(x)+hand*cs*q(y)) for j,(x,y) in enumerate(P) if j!=row['deleted']]
        d=None
        for (x,y),(X,Y) in zip(inner,inner[1:]+inner[:1]):
            a,b=X-x,Y-y;L=q(a*a+b*b).sqrt()
            for vx,vy in cloud:
                dist=(a*(vy-y/q(D))-b*(vx-x/q(D)))/L
                z=int((dist.lower()*10**12).floor().unique_fmpz())
                d=z if d is None else min(d,z)
        per.append((row['deleted'],d))
    minimum=F(min(x for _,x in per),10**12);examples=[]
    for low,d0,goal in [(F('.83730'),F('.0000007'),F('.837295')), (F('.83732'),F('.0000029'),F('.83730'))]:
        scale=1-2*d0;error=(1-scale)*F(51,100)+d0
        assert error<minimum and scale+2*d0==1
        floor=F((low/(1+2*error)**2*10**12).__floor__(),10**12)
        assert floor>goal
        examples.append(dict(original_area_floor=str(low),ball_radius=str(d0),center_scale=str(scale),maximum_motion=str(error),strict_area_floor=str(floor)))
    return dict(clearance_floor=str(minimum),deletion_clearance_in_units_1e_12=dict(sorted(per)),examples=examples)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args();z=bound(a.comp,a.source);print(z);a.output.write_text(json.dumps(z,indent=2)+'\n')

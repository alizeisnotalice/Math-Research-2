from flint import arb,ctx
import json,sys,platform
ctx.prec=256;rows=[]
for m in range(5,102,2):
 a=arb.pi()/m;assert 3*a/2<arb.pi()/3
 first=(a/2).sin()*(1-(3*a/2).cos())/(2*a).sin()
 second=((3*a/2).sin()*(a/2).cos()+(a/2).sin())/(2*a).sin()
 v=first+second;D=(1+1/(a/2).cos())/(2*a.cos());assert abs(v-D)<arb(1)/10**65
 rows.append({'m':m,'width':str(v),'D':str(D),'absolute_discrepancy':str(abs(v-D))})
open(sys.argv[1],'w').write(json.dumps({'precision_bits':ctx.prec,'python':platform.python_version(),'status':'cross-check; identity holds algebraically for all odd m >=5','rows':rows},indent=2)+'\n')

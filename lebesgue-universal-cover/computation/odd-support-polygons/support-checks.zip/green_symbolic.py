import sympy as s
a,x,u=s.symbols('a x u',real=True)
D=s.sin(2*a)
G1L=s.sin(u+a)*s.sin(a-x)/D; G1R=s.sin(x+a)*s.sin(a-u)/D
G2L=s.sin(u)*s.sin(2*a-x)/D; G2R=s.sin(x)*s.sin(2*a-u)/D
rhs=s.sin(a)*s.sin(a-x-u)/D
for f,g in ((G1L,G2L),(G1R,G2R)):
 assert s.trigsimp(s.expand_trig(f-g-rhs))==0
# 0 <= x <= a/2: crossing a-x >= x; G1 maximal before crossing.
I=s.integrate(G1L,(u,-a,x))+s.integrate(G1R,(u,x,a-x))+s.integrate(G2R,(u,a-x,2*a))
target=(1+1/s.cos(a/2)*s.cos(x-a/2))/(2*s.cos(a))-1
err=s.trigsimp(I-target)
assert s.trigsimp(err.subs(s.sin(a/2)**2,(1-s.cos(a))/2))==0
print('exact: overlap difference sin(a)*sin(a-x-u)/sin(2a)')
print('exact: 1+integral max G = (1+sec(a/2) cos(x-a/2))/(2 cos(a))')
print('symmetric x -> a-x, maximized at x=a/2')

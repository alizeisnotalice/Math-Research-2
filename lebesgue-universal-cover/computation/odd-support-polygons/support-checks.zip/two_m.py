from flint import arb,ctx
import json,platform,sys
ctx.prec=256;rows=[]
for m in (5,7,9,11,13,15,17,19,21,23,25,35,101,1001):
 a=arb.pi()/m;N=2*m+1;h=a/N;mu=1/(2*a.cos());eta=3*h/8;gamma=2*mu*(1-(h/4).cos());D=(1+1/(a/2).cos())/(2*a.cos());old=(arb.pi()/(m-1)).cos()**2;new=1/(D-gamma)**2
 # worst circular gap s = pi/N, lower spacing h
 A=a/2-arb.pi()/N; assert abs(A-h/2)<arb(1)/10**65 and eta<h/2 and A-eta>0 and a/2+eta<arb.pi()/2
 assert (1-eta.cos())-2*(1-(h/4).cos())>0
 rows.append({'m':m,'N':N,'h':str(h),'gamma':str(gamma),'A_minus_h_over_two':str(A-h/2),'localization_margin':str((1-eta.cos())-2*(1-(h/4).cos())),'new_coefficient':str(new),'old_coefficient':str(old),'difference':str(new-old),'improved':bool(new>old)})
open(sys.argv[1],'w').write(json.dumps({'python':platform.python_version(),'precision_bits':ctx.prec,'rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))

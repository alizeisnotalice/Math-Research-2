import json,sys,platform
from flint import arb,ctx
ctx.prec=192;pi=arb.pi();r=1/arb(3).sqrt();basis=[]
for k in range(3):
 sn,co=(2*pi*k/3).sin_cos();basis.append((co,sn))
P=[(factor*co,factor*sn) for factor in (r,r-1) for co,sn in basis]
out=[]
for m in (5,7,11):
 target=1/(pi/m).cos()**2;N=512;mins=[];pairs={};start=0
 for i in range(N):
  phi=(pi/(3*m)*i/N).union(pi/(3*m)*(i+1)/N);norm=[];h=[]
  for j in range(m):
   sy,cx=(phi+2*pi*j/m).sin_cos();norm.append((cx,sy));vals=[x*cx+y*sy for x,y in P]; v=vals[0]
   for w in vals[1:]:v=arb.max(v,w)
   h.append(v)
  vertices=[]
  for j in range(m):
   k=(j+1)%m;x1,y1=norm[j];x2,y2=norm[k];det=x1*y2-x2*y1;assert det>0
   vertices.append(((h[j]*y2-h[k]*y1)/det,(x1*h[k]-x2*h[j])/det))
  choices=[]
  for j in range(m):
   for k in range(j):
    X=vertices[j][0]-vertices[k][0];Y=vertices[j][1]-vertices[k][1];g=X*X+Y*Y-target
    if g>0:choices.append((float(g.mid()),g.lower(),j,k))
  assert choices,(m,i)
  choice=max(choices,key=lambda p:p[0]);mins.append(choice[1]);key=f'{choice[2]},{choice[3]}';pairs[key]=pairs.get(key,0)+1
 out.append({'m':m,'phase_range':f'[0,pi/{3*m}]','cells':N,'diameter_sq_margin_lower':str(min(mins)),'witness_pair_cells':pairs})
res={'method':'R3 3 vertices and antipodes; exact Arb interval support maxima, all phases by D3 and grid symmetry','python':platform.python_version(),'precision_bits':ctx.prec,'results':out};open(sys.argv[1],'w').write(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))

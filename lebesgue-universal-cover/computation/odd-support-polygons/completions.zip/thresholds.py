from flint import arb,ctx,__version__
from fractions import Fraction as F
import json,sys
ctx.prec=256
A=lambda f:arb(f.numerator)/f.denominator if isinstance(f,F) else arb(f)
G=A(F(120696470013529293,2**57));s=A(F('.999999939'));L=G/s**2
out=[]
for target in map(F,['.83750','.83750001','.83750005','.8375001','.837500101','.837500102','.8375001021','.83750010217','.837500102175']):
 def val(m):return (2-1/(arb.pi()/(2*m)).cos())**2*L
 assert L>A(target)
 lo,hi=14,10**11
 while lo<hi:
  mid=(lo+hi)//2
  if val(2*mid+1)>A(target):hi=mid
  else:lo=mid+1
 n=2*lo+1;assert val(n)>A(target) and val(n-2)<A(target)
 out.append(dict(target=str(target),minimal_odd=n,strict_above=str((val(n)-A(target)).lower()),prior_below=str((A(target)-val(n-2)).lower())))
print(json.dumps(dict(precision=ctx.prec,python=sys.version,flint=__version__,G=str(G),scale=str(s),L=str(L),rows=out),indent=2))

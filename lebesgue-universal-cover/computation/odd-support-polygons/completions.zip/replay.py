"""Reconstruct the two scaled point groups and certify their Reuleaux completions."""
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess
import sys

here = Path(__file__).resolve().parent
source, work = (Path(arg).resolve() for arg in sys.argv[1:3])
assert sha256(source.read_bytes()).hexdigest() == "d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666"
work.mkdir(exist_ok=False)
with ZipFile(source) as archive:
    groups = json.loads(archive.read("points.json"))
scale = Fraction(999999939, 10**9)
for name, arc_count in (("P66",29), ("physicalQ",11)):
    group = groups[name]
    points = group["points"]
    scaled_denominator = group["denominator"] * scale
    assert scaled_denominator.denominator == 1
    denominator = int(scaled_denominator)
    diameter_sq = max((x-u)**2 + (y-v)**2 for (x,y),(u,v) in combinations(points,2))
    assert diameter_sq < denominator**2
    (work / (name+".json")).write_text(json.dumps({"denominator":denominator,"points":points},indent=2)+"\n")
    (work / (name+"-recipe.json")).write_bytes((here / (name+"-recipe.json")).read_bytes())
    subprocess.run([sys.executable, "-B", str(here/"verify_completion.py"), name], cwd=work, check=True)
    actual = json.loads((work/(name+"-completion.json")).read_bytes())["completions"][0]
    expected = json.loads((here/(name+"-completion.json")).read_bytes())["completions"][0]
    assert actual["unit_width_arcs"] == arc_count
    for key in actual:
        if key != "input_sha256":
            assert actual[key] == expected[key], key
print("Both completions passed.")

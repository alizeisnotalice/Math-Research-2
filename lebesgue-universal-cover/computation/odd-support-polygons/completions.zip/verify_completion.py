"""Exact-rational + Arb certificate for R261 finite-set unit-width completions."""
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from pathlib import Path
from flint import arb,ctx,__version__ as fv
import json,sys
ctx.prec=320
A=lambda f:arb(f.numerator)/f.denominator if isinstance(f,F) else arb(f)
def plus(x,y):return (x[0]+y[0],x[1]+y[1])
def sub(x,y):return (x[0]-y[0],x[1]-y[1])
def dot(x,y):return x[0]*y[0]+x[1]*y[1]
def cross(x,y):return x[0]*y[1]-x[1]*y[0]
def area2(x,y):return dot(sub(x,y),sub(x,y))
def pretty(x):return x.str(45)
def run(n,axis,side,centers,pairs):
 path=Path(sys.argv[1]+'.json');d=json.loads(path.read_bytes()); P=d['points'];Q=d['denominator']; assert len(P)==n
 aa,bb=axis;D2=(P[aa][0]-P[bb][0])**2+(P[aa][1]-P[bb][1])**2
 assert 0<D2<Q*Q and all((x[0]-y[0])**2+(x[1]-y[1])**2<=D2 for x,y in combinations(P,2))
 vx=P[bb][0]-P[aa][0];vy=P[bb][1]-P[aa][1];a0=P[aa]
 q=[]
 for x,y in P:
  dx=x-a0[0];dy=y-a0[1];q.append((F(dx*vx+dy*vy,D2),side*F(vx*dy-vy*dx,D2)))
 assert q[aa]==(0,0) and q[bb]==(1,0) and len(centers)==len(pairs)+1
 lower=[i for i,(_,y) in enumerate(q) if y<0]
 assert set(centers).issubset(set(lower+[aa,bb]))
 qa=[(A(x),A(y)) for x,y in q]
 def intersection(i,j,sgn):
  x,y=q[i];u,v=q[j];dx=u-x;dy=v-y;r2=dx*dx+dy*dy;assert 0<r2<=1
  f=((A(1)-A(r2)/4)/A(r2)).sqrt()
  return (A((x+u)/2)-sgn*A(dy)*f,A((y+v)/2)+sgn*A(dx)*f)
 crosses=[intersection(*args) for args in pairs]
 for k,(pt,(i,j,s)) in enumerate(zip(crosses,pairs)):
  assert set((i,j))==set((centers[k],centers[k+1])) and pt[1]>0
  assert area2(pt,qa[i]).contains(1) and area2(pt,qa[j]).contains(1)
  if k:assert pt[0]>crosses[k-1][0]
  for a in lower+[aa,bb]:
   if a not in (i,j):assert 1-area2(pt,qa[a])>0,(n,k,a,pretty(1-area2(pt,qa[a])))
 # diameter cycle [c0,p0,c1,p1,...,c_last]
 V=[]
 for i,c in enumerate(centers):
  V.append(qa[c])
  if i<len(crosses):V.append(crosses[i])
 nv=len(V);assert nv==2*len(centers)-1 and nv%2==1
 min_other=arb(1)
 for i,j in combinations(range(nv),2):
  delta=1-area2(V[i],V[j]);adj=(j==i+1 or (i==0 and j==nv-1))
  if adj:assert delta.contains(0),(n,i,j,pretty(delta))
  else:
   assert delta>0,(n,i,j,pretty(delta));min_other=min(min_other,delta.lower())
 # Original input points are d*q in the completed (unit-width) coordinate system.
 ratio=A(F(D2,Q*Q)).sqrt(); assert ratio<1
 min_input=arb(1);equal=[]
 for h in range(n):
  x=(ratio*qa[h][0],ratio*qa[h][1])
  for j,v in enumerate(V):
   delta=1-area2(x,v)
   if h==aa and j in (0,nv-2): assert delta.contains(0);equal.append((h,j))
   else:
    assert delta>0,(n,h,j,pretty(delta));min_input=min(min_input,delta.lower())
 assert len(equal)==2
 # Original world coordinates: A0 + rotated normalized coordinates.
 den=A(D2).sqrt(); A0=(A(F(a0[0],Q)),A(F(a0[1],Q)))
 def world(q):
  return (A0[0]+(A(vx)*q[0]-A(side*vy)*q[1])/den,A0[1]+(A(vy)*q[0]+A(side*vx)*q[1])/den)
 W=list(map(world,V));arcs=[];mapping={}
 for i,c in enumerate(W):
  prev=(i-1)%nv;nxt=(i+1)%nv;u=sub(W[prev],c);v=sub(W[nxt],c);det=cross(u,v);assert det>0 or det<0,(n,i,pretty(det))
  start,end=(prev,nxt) if det>0 else (nxt,prev);u=sub(W[start],c);v=sub(W[end],c);det=cross(u,v);prod=dot(u,v)
  assert det>0 and prod>0,(n,i,pretty(det),pretty(prod))
  sweep=arb.atan2(det,prod);assert 0<sweep<arb.pi()/3+arb('1e-60')
  angle=arb.atan2(u[1],u[0]);assert angle.is_finite()
  assert start not in mapping;mapping[start]=(end,i)
  arcs.append(dict(center=i,start_vertex=start,end_vertex=end,start_angle=pretty(angle),ccw_sweep=pretty(sweep),end_angle_unwrapped=pretty(angle+sweep),orientation='ccw'))
 pathorder=[];key=0
 for k in range(nv):
  assert key in mapping and key not in pathorder;pathorder.append(key);key=mapping[key][0]
 assert key==pathorder[0] and len(pathorder)==nv
 return dict(input_sha256=sha256(path.read_bytes()).hexdigest(),point_count=n,diameter_squared=f'{D2}/{Q*Q}',axis=axis,smaller_side=side,source_center_indices=centers,intersection_formulas=[dict(pair=list(z[:2]),branch=z[2]) for z in pairs],unit_width_arcs=nv,vertices_world=[[pretty(x),pretty(y)] for x,y in W],arcs=arcs,ccw_vertex_order=pathorder,min_noncycle_squared_slack=pretty(min_other),min_original_input_squared_slack_except_anchor=pretty(min_input),anchor_exact_contacts=equal,arc_angle_units='radians',method='rational source; exact circle intersection formulas; 320-bit Arb signs')
scout=json.loads(Path(sys.argv[1]+'-recipe.json').read_bytes()); pairs=[(*a['pair'],a['sign']) for a in scout['breakpoints']];centers=[scout['axis'][1]]
for i,j,sgn in pairs:
 assert centers[-1] in (i,j);centers.append(j if centers[-1]==i else i)
assert centers[-1]==scout['axis'][0]
out=[run(len(json.loads(Path(sys.argv[1]+'.json').read_bytes())['points']),tuple(scout['axis']),scout['side'],centers,pairs)]
Path(sys.argv[1]+'-completion.json').write_text(json.dumps(dict(complete=True,precision_bits=ctx.prec,flint=fv,python=sys.version,completions=out),indent=2)+'\n')
for o in out:print(o['point_count'],'arcs',o['unit_width_arcs'],'min point slack',o['min_original_input_squared_slack_except_anchor'],'min other vertex slack',o['min_noncycle_squared_slack'])

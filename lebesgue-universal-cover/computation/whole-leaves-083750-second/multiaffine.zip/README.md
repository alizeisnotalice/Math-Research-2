# .83750 余叶的整体移动比较与多仿射面积剪枝

冻结的第四层整叶清单有 3,279 枚未闭根，分属 67 个分片。本工位从该快照提取原叶，并保留精确谱系及有理证书。带 scaled 字段的结果已支付统一曲体缩放 \(499999503/500000000\) 的精确面积损失。几何公式见 PROOF.md。

## 平移规范与新十一点

对原叶 1205/152529 中另一组六体的真实低面积代表姿态构造有理内多边形 \(P\)。已有十一点见证的直径平方为 \(19999999890783901/20000000000000000\)。独立重跑角区间及精确平移排除，共 8,192 个闭角格全部通过，证明 \(P\) 与此十一点任意同构副本的增广凸包面积严格大于 .837750。

同一个 \(P\) 用于该原叶的九个指定盒。由联合体心平移选择，一次验证给七个正体积子盒各自的区域面积下端严格高于 .83750。五个盒的同一保守包络在固定圆盘规范下有相反的尺度认证结果，已用正平衡法向给出尺度上端。其中保留原九盒尺寸时有四盒缩后仍可通过。将单轴独宽的半宽从 .000125 改为 .000122 后，七个缩体盒全部通过，其中五个盒仍由移动规范推进。原尺度七盒并集占原叶体积约 \(1.46677\cdot10^{-23}\)。

## 单调链的平移剪枝

三枚预选原叶 136/24814、1205/137645、181/129770 的两个坐标方向均实际核验。每个方向保留四个同轴平移坐标的完整原范围。先固定另外四个平移量和三个角，再导出相应的正体积闭区域。六个轴向剖面都严格越过面积门槛，只用原五个曲体。

固定角度后，同时保留整轴 \(X\) 及四个垂轴 \(Y\) 的预定闭盒。原叶 1205/137645 的最佳已核区域中，\(X\) 用全宽，\(Y\) 采用与原叶相交的半宽 \(1/625\) 闭盒，三个角也可变化。其体积占原叶约 \(2.1251134\cdot10^{-4}\)，约为同轴摆放后只经统一 Hausdorff 转移区域的 15,381 倍。纳入统一曲体缩放时，该方法的最佳盒体积占比仍超过 \(2.05110\cdot10^{-4}\)。pilot-bilinear.json 保存六个方向、每档垂轴半宽及所有精确证书。

另取两种固定步幅相结合的 31 叶样本，分属 22 个分片。62 个四坐标全宽剖面均产生严格五体闭区域，包括对应缩体区域。19 个剖面的中心单切面不能通过而有理组合可以通过。针对此样本的统计覆盖指定中心、轴和对应转移盒。整枚原叶及其余原域待排除。

## 同时处理三个真实转角

在原叶 181/129770 上，将转角保留在整盒鞋带的一阶项，精确控制聚合的二阶与三阶余量。28 个候选有 15 个严格排除缩五体面积至多 .83750。删除被包含的候选后剩五盒。以有理容斥计算，五盒并集严格覆盖原叶体积的 1.1057555% 以上。最大的单盒保留四个水平平移坐标整宽，另四个垂向半宽取 .0022，三个转角半宽取 .0064，其缩五体面积严格大于 .83751572089687。单盒占原叶体积的 0.5167356% 以上。

每个有理证书逐一检查 2,048 个角点。链的纵向单调性也在整个转角盒上验证。独立 Arb 抽查 96 个角点，逐边重转同一链并比较多仿射下端。完整角盒结论来自聚合余量及多仿射极点论证。局部区域的和并未关闭整枚 181/129770。

## 复算

指定已有 Python 解释器、Tomar v9 原树目录、主线 computation 目录及 3,279 叶快照。Python 3.13.18、python-flint 0.9.0、160 位 Arb 已实际运行。提议切面和移动规范使用 SciPy 1.18.1。读取冻结证书复算时只用 Arb 和精确整数、有理数。

~~~sh
python -I -B stratified_roots.py "$COMP" "$TREE" "$RESIDUAL" replay-pilot-boxes.json --pilot
cmp pilot-raw-boxes.json replay-pilot-boxes.json
python -E -B shadow_lp.py pilot-raw-boxes.json replay-pilot-shadow.json --replay pilot-shadow.json
python -E -B bilinear_shadow.py pilot-raw-boxes.json pilot-shadow.json replay-pilot-bilinear.json --replay pilot-bilinear.json
python -E -B angular_shadow.py pilot-raw-boxes.json pilot-shadow.json replay-angular-certificate.json --replay angular-certificate.json
python -I -B angular_summary.py pilot-raw-boxes.json replay-angular-certificate.json replay-angular-footprint.json
python -I -B stratified_roots.py "$COMP" "$TREE" "$RESIDUAL" replay-sample-boxes.json
cmp sample-raw-boxes.json replay-sample-boxes.json
python -E -B shadow_lp.py sample-raw-boxes.json replay-sample-shadow.json --replay sample-shadow.json
~~~

HINGE 指另一工位已有的十一点几何证书源码目录，其中应有 new-points.json、hinge.cpp、hinge_bank.py、template.py 和可选的解释文档。POSE 使用该包的 other-pose.json。将可再生数据放外置盘指定 SCRATCH。脚本支持从任意绝对路径读取这些依赖。

~~~sh
python -I -B anchor_cases.py "$COMP" "$TREE" "$RESIDUAL" "$POSE" anchored-replay-cases.json > anchored-replay-leaf.json
cmp anchored-cases.json anchored-replay-cases.json
cmp anchored-leaf.json anchored-replay-leaf.json
clang++ -O3 -std=c++17 -ftrapv -fmodules-cache-path="$CACHE" "$HINGE/hinge.cpp" -o "$SCRATCH/hinge"
python -E -B anchor_hinge.py anchored-cases.json "$HINGE" "$SCRATCH/hinge" "$SCRATCH" anchored-replay-hinge.json
python -E -B verify_transfer.py anchored-cases.json anchored-leaf.json anchored-replay-hinge.json transfer-certificate.json replay-transfer-audit.json
python -I -B anchor_cases.py "$COMP" "$TREE" "$RESIDUAL" "$POSE" anchored-replay-small.json --radius .000122 > anchored-replay-small-leaf.json
cmp anchored-small-cases.json anchored-replay-small.json
python -E -B verify_transfer.py anchored-small-cases.json anchored-leaf.json anchored-replay-hinge.json transfer-small-certificate.json replay-transfer-small-audit.json
~~~

Apple Clang 21.0.0 实际重跑固定锚的整数铰链证明。anchor_hinge.py 在实际调用核后记录全角格覆盖与输入散列，verify_transfer.py 再逐方向重验整盒规范和精确尺度转移。

"""Exact area comparison to the fixed common contraction about each body center."""
from fractions import Fraction as F

SCALED=F(".999999006")
RADIAL=F(3,5)


def dilatation(displacement, scale):
    assert 0<scale<=1 and displacement>=0
    return 1+2*(displacement+RADIAL*(1-scale))/scale


def area_floor(area, displacement, scale):
    return area/dilatation(displacement,scale)**2


def allowance(area, scale, target, grid):
    if area_floor(area,0,scale)<=target:
        return F(0)
    lo,hi=0,grid//100
    assert hi>0
    while hi-lo>1:
        k=(lo+hi)//2
        if area_floor(area,F(k,grid),scale)>target:
            lo=k
        else:
            hi=k
    return F(lo,grid)

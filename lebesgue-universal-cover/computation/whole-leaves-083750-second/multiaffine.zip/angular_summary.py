"""Measure the exact union of the successful angle-and-translation certificates."""
from fractions import Fraction as F
from itertools import combinations
from math import prod
from pathlib import Path
import argparse
import json

GOAL=F(".83750")


def contained(a,b):
    return all(l<=u<=v<=r for (u,v),(l,r) in zip(a,b,strict=True))


def volume(box):
    return prod(max(0,hi-lo) for lo,hi in box)


def intersection(boxes):
    return [(max(a for a,_ in dim),min(b for _,b in dim)) for dim in zip(*boxes,strict=True)]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("source",type=Path)
    p.add_argument("records",type=Path)
    p.add_argument("output",type=Path)
    a=p.parse_args()
    box=json.loads(a.source.read_bytes())["original-181-129770"]["box"]
    raw=json.loads(a.records.read_bytes())
    assert len(raw)==28
    positive={}
    for k,row in raw.items():
        assert (F(row["scaled_area_lower"])>GOAL)==row["strictly_excludes"]
        assert contained(row["box"],box)
        assert F(volume(row["box"]),volume(box))==F(row["fraction_of_leaf"])
        if row["strictly_excludes"]:
            positive[k]=row["box"]
    maximal={k:b for k,b in positive.items() if not any(
        contained(b,c) and (b!=c or l<k) for l,c in positive.items() if l!=k)}
    union=sum((-1)**(n+1)*sum(volume(intersection(t)) for t in combinations(maximal.values(),n))
              for n in range(1,len(maximal)+1))
    large=max(maximal,key=lambda k:volume(maximal[k]))
    val={
        "source_leaf":[181,129770],
        "tested_boxes":len(raw),"positive_boxes":len(positive),
        "maximal_ids":list(maximal),"largest_region":large,
        "largest_area_lower":raw[large]["scaled_area_lower"],
        "largest_region_relative":str(F(volume(maximal[large]),volume(box))),
        "entire_proven_union_relative":str(F(union,volume(box))),
        "union_lower_from_maximal":str(min(F(raw[k]["scaled_area_lower"]) for k in maximal)),
    }
    a.output.write_text(json.dumps(val,indent=2)+"\n")
    print("relative union",float(F(val["entire_proven_union_relative"])),list(maximal))
    print("largest region",large,float(F(val["largest_region_relative"])),float(F(val["largest_area_lower"])))


if __name__=="__main__":
    assert __debug__
    main()

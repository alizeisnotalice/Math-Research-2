"""Direct multiaffine lower cuts with rotation uncertainties in the chain test."""
from fractions import Fraction as F
from itertools import product
from math import lcm, prod
from pathlib import Path
import argparse
import json

from flint import ctx
from bilinear_shadow import crossing_box
from common_support import BODIES, FINE, add, cross, dot, pairs, poly_hull, sub
from scale_transfer import SCALED, area_floor
from shadow_lp import GEOM, GRID, GOAL, geometry


def robust_path(points, ybox, error, widths, direction):
    parents=[None]*len(points)
    scores=[None]*len(points)
    scores[0]=0
    def good(a,b):
        dy=b[1]-a[1]
        i,j=a[2],b[2]
        if i==j:
            return dy>=error(sub(b[3],a[3]),widths[i])
        return dy>=ybox[i][1]-ybox[j][0]+a[4]+b[4]
    for j,b in enumerate(points[1:],1):
        for i,a in enumerate(points[:j]):
            if scores[i] is None or not good(a,b):
                continue
            value=scores[i]+direction*(a[0]+b[0])*(b[1]-a[1])
            if scores[j] is None or scores[j]<value:
                parents[j]=i
                scores[j]=value
    if scores[-1] is None:
        return None
    ids=[len(points)-1]
    while ids[-1]:
        ids.append(parents[ids[-1]])
    answer=[points[i] for i in ids[::-1]]
    assert all(good(x,y) for x,y in zip(answer,answer[1:]))
    return answer


def cycle_at(points,trial,ty,widths,centers):
    # In integer geometry units, rotation of a local vector changes y
    # by at most |x| omega + |y| omega^2/2.
    def error(local,r):
        w=r*GRID
        assert int(w)==w
        w=int(w)
        num=2*abs(local[0])*w*GRID+abs(local[1])*w*w
        return (num+2*GRID**2-1)//(2*GRID**2)
    def grid(q):
        n=q*GEOM
        assert n==int(n)
        return int(n)
    up=[0]+[grid(x) for x in trial]
    ybox=[(0,0)]+[tuple(grid(x) for x in row) for row in ty]
    label={}
    for i,v in enumerate(points):
        for x,y in v:
            p=(x+up[i],y)
            local=sub((x,y),centers[i])
            label.setdefault(p,(*p,i,local,error(local,widths[i])))
    polygon=[label[v] for v in poly_hull(label)]
    start=min(range(len(polygon)),key=lambda j:(polygon[j][1],polygon[j][0]))
    poly=polygon[start:]+polygon[:start]
    end=max(range(len(poly)),key=lambda j:(poly[j][1],poly[j][0]))
    right=robust_path(poly[:end+1],ybox,error,widths,1)
    left=robust_path([poly[0],*poly[:end-1:-1]],ybox,error,widths,-1)
    if right is None or left is None:
        return None
    assert right[0]==left[0] and right[-1]==left[-1]
    return right+left[-2:0:-1]


def ground(value):
    return {():value}


def append(out, variables, coeff):
    variables=tuple(sorted(variables))
    assert len(set(variables))==len(variables)
    if coeff:
        out[variables]=out.get(variables,F(0))+coeff


def combine(out, lhs, rhs, coeff=1):
    for u,a in lhs.items():
        for v,b in rhs.items():
            append(out,u+v,coeff*a*b)


def polynomial(cycle,center,bounds,widths):
    dets={}
    inner={}
    centers={}
    mixed={}
    zero=(0,0)
    spin=[None,None,8,9,10]
    trans=[tuple(ground(F(x,GEOM)) for x in center[0])]
    for i,(x,y) in enumerate(center[1:]):
        trans.append(({():F(x,GEOM),(i,):F(1)},{():F(y,GEOM),(i+4,):F(1)}))
    for a,b in pairs(cycle):
        i,j=a[2],b[2]
        p,q=a[3],b[3]
        lo,hi=min(i,j),max(i,j)
        dets[lo,hi]=dets.get((lo,hi),0)+cross(p,q)
        if i!=j:
            inner[lo,hi]=inner.get((lo,hi),0)+(1 if i<j else -1)*dot(p,q)
            centers[i,j]=centers.get((i,j),0)+1
        mixed[i,j]=add(mixed.get((i,j),zero),q)
        mixed[j,i]=sub(mixed.get((j,i),zero),p)
    out={}
    error=F(0)
    for (i,j),coef in dets.items():
        d=F(coef,GEOM**2)
        m=F(inner.get((i,j),0),GEOM**2)
        append(out,(),d)
        if i==j:
            continue
        if spin[i] is not None:
            append(out,(spin[i],),-m)
        if spin[j] is not None:
            append(out,(spin[j],),m)
        r=widths[i]+widths[j]
        error+=abs(d)*r*r/2+abs(m)*r**3/6
    for (i,j),k in centers.items():
        combine(out,trans[i][0],trans[j][1],k)
        combine(out,trans[i][1],trans[j][0],-k)
    for (i,j),(x,y) in mixed.items():
        x,y=F(x,GEOM),F(y,GEOM)
        combine(out,trans[i][0],ground(y))
        combine(out,trans[i][1],ground(-x))
        if spin[j] is None:
            continue
        combine(out,trans[i][0],{(spin[j],):x})
        combine(out,trans[i][1],{(spin[j],):y})
        r=widths[j]
        tx,ty=tuple(max(abs(t.get((),0)+v) for v in (
                 (F(0),) if not i else bounds[i-1+4*k])) for k,t in enumerate(trans[i]))
        error+=(tx*abs(y)+ty*abs(x))*r*r/2+(tx*abs(x)+ty*abs(y))*r**3/6
    append(out,(),-error)
    return {k:v/2 for k,v in out.items() if v}


def integer_scores(polys,corners):
    rows=[[(k,v/GRID**len(k)) for k,v in poly.items()] for poly in polys]
    scale=lcm(*(v.denominator for row in rows for _,v in row))
    icoeff=[[(k,int(scale*v)) for k,v in row] for row in rows]
    grid=[tuple(int(x*GRID) for x in corner) for corner in corners]
    assert all(tuple(F(a,GRID) for a in x)==y for x,y in zip(grid,corners,strict=True))
    return scale,[[sum(c*prod(z[i] for i in k) for k,c in row) for row in icoeff] for z in grid]


def sample_case(box,axis,samples,sites,y_radius,ang_radius,old=None):
    ctr,points,xb=geometry(box,axis,samples)
    tested,yb=crossing_box(box,ctr,axis,y_radius)
    widths=[F(0)]*2
    for _,turn,_ in BODIES[2:]:
        c=F(ctr[turn],2)
        r=min(c-box[turn][0],box[turn][1]-c,FINE*ang_radius)
        ends=[(c-r).__ceil__(),(c+r).__floor__()]
        widths.append(max(abs(F(2*x-ctr[turn],GRID)) for x in ends))
        tested[turn]=ends
    assert len(widths)==5 and all(a<=l<r<=b for (a,b),(l,r) in zip(box,tested,strict=True))
    center=[(0,0) if p is None else tuple(ctr[p+j]*(GEOM//GRID) for j in (axis,1-axis))
            for _,_,p in BODIES]
    bounds=[*xb,*yb,*[(-r,r) for r in widths[2:]]]
    atoms=[cycle_at(points,site,yb,widths,center) for site in sites]
    active=[i for i,v in enumerate(atoms) if v is not None]
    assert active
    polys=[polynomial(atoms[i],center,bounds,widths) for i in active]
    corners=list(product(*bounds))
    assert len(corners)==2048
    scale,evals=integer_scores(polys,corners)
    if old:
        assert active==old["active"]
        w=tuple(map(F,old["weights"]))
    else:
        from scipy.optimize import linprog
        n=len(active)
        hinge=[[*(float(GOAL-F(x,scale)) for x in row),1] for row in evals]
        fit=linprog([0]*n+[-1],A_ub=hinge,b_ub=[0]*len(hinge),
                    A_eq=[[1]*n+[0]],b_eq=[1],bounds=[(0,None)]*n+[(None,None)])
        assert fit.success
        raw=[round(max(0,x)*GRID) for x in fit.x[:n]]
        w=tuple(F(x,sum(raw)) for x in raw)
    assert min(w)>=0 and sum(w)==1 and len(w)==len(active)
    low=min(sum(x*a for x,a in zip(row,w,strict=True)) for row in evals)/scale
    fraction=F(prod(b-a for a,b in tested),prod(b-a for a,b in box))
    scaled=area_floor(low,0,SCALED)
    return {"active":active,"weights":list(map(str,w)),"box":tested,
            "unscaled_area_lower":str(low),"scaled_area_lower":str(scaled),
            "strictly_excludes":scaled>GOAL,"fraction_of_leaf":str(fraction)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for z in ("boxes","shadow","output"):
        p.add_argument(z,type=Path)
    p.add_argument("--replay",type=Path)
    a=p.parse_args()
    assert __debug__
    ctx.prec=160
    key="original-181-129770"
    box=json.loads(a.boxes.read_bytes())[key]["box"]
    base=json.loads(a.shadow.read_bytes())
    old=json.loads(a.replay.read_bytes()) if a.replay else None
    checked={}
    for axis in (0,1):
        seeds=base["cases"][f"{key}/{axis}"]["cuts"]
        sites=tuple(dict.fromkeys(tuple(map(F,x["shifts"])) for x in [*seeds,{"shifts":["0"]*4}]))
        trials=list(product((".0008",".0016",".0032"),(".0016",".0032",".0064")))
        extras=((".0016",".0080"),(".0016",".0096"),(".0018",".0080"),
                (".0018",".0096"),(".0020",".0064"),(".0020",".0080"),
                (".0022",".0064"),(".0022",".0080")) if axis==0 else (
                (".0009",".0080"),(".0009",".0096"))
        for y,ang in trials+list(extras):
            case=f"{axis}/{y}/{ang}"
            row=sample_case(box,axis,base["samples"],sites,F(y),F(ang),old[case] if old else None)
            checked[case]=row
            print(case,row["strictly_excludes"],float(F(row["scaled_area_lower"])),
                  float(F(row["fraction_of_leaf"])),flush=True)
    if old:
        assert checked==old
    a.output.write_text(json.dumps(checked,indent=2)+"\n")


if __name__=="__main__":
    main()

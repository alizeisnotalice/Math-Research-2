"""Use stable monotone hull chains and joint affine-bilinear area cuts."""
from fractions import Fraction as F
from itertools import product
from math import prod
from hashlib import sha256
from pathlib import Path
import argparse
import json

from flint import arb, ctx
from scale_transfer import SCALED, allowance, area_floor
from common_support import BODIES, FINE, ar, cross, pairs, poly_hull
from shadow_lp import GEOM, GOAL, GRID, SPEED, geometry

RADII=tuple(F(x) for x in (".00005",".00010",".00020",".00040",".00080",".00160",".00320"))


def crossing_box(box,ctr,axis,radius):
    proposed=[list(v) for v in box]
    offsets=[]
    for _,_,pos in BODIES[1:]:
        j=pos+1-axis
        c=F(ctr[j],2)
        r=min(c-box[j][0],box[j][1]-c,radius*FINE)
        proposed[j]=[(c-r).__ceil__(),(c+r).__floor__()]
        offsets.append(tuple(F(2*a-ctr[j],GRID) for a in proposed[j]))
    assert all(b>a for a,b in offsets)
    return proposed,offsets


def stable_chain(points,cost_sign,vertical):
    # The exact maximizing dynamic program is only a selector. Any returned
    # stable chain yields the claimed lower bound.
    scores=[None]*len(points)
    parents=[None]*len(points)
    scores[0]=0
    for j,(_,_,body,x,y) in enumerate(points[1:],1):
        for i,(_,_,family,a,b) in enumerate(points[:j]):
            if scores[i] is None:
                continue
            h=y-b
            if family!=body and h<vertical[family][1]-vertical[body][0]:
                continue
            assert h>=0
            z=scores[i]+cost_sign*(a+x)*h
            if scores[j] is None or z>scores[j]:
                scores[j],parents[j]=z,i
    if scores[-1] is None:
        return None
    trail=[len(points)-1]
    while trail[-1]:
        trail.append(parents[trail[-1]])
    trail.reverse()
    path=[points[j] for j in trail]
    for u,v in zip(path,path[1:]):
        i,j=u[2],v[2]
        assert v[4]>=u[4]
        assert i==j or v[4]-u[4]>=vertical[i][1]-vertical[j][0]
    return path


def cuts(vertices,trial,vert):
    offset=[0]+[z*GEOM for z in trial]
    raise_y=[(0,0)]+[tuple(x*GEOM for x in b) for b in vert]
    assert all(x==int(x) for x in offset+[v for p in raise_y for v in p])
    offset=list(map(int,offset))
    raise_y=[tuple(map(int,v)) for v in raise_y]
    labels={}
    for body,points in enumerate(vertices):
        for x,y in points:
            p=(x+offset[body],y)
            labels.setdefault(p,(x,y,body,*p))
    hull=poly_hull(labels)
    ordered=[labels[p] for p in hull]
    j=min(range(len(ordered)),key=lambda j:(ordered[j][4],ordered[j][3]))
    ordered=ordered[j:]+ordered[:j]
    j=max(range(len(ordered)),key=lambda j:(ordered[j][4],ordered[j][3]))
    right=stable_chain(ordered[:j+1],1,raise_y)
    left=stable_chain([ordered[0],*ordered[:j-1:-1]],-1,raise_y)
    if right is None or left is None:
        return None
    assert right[0]==left[0] and right[-1]==left[-1]
    canonical=right+left[-2:0:-1]
    assert len(canonical)>=3
    cycle=[p[:3] for p in canonical]
    u,v=[0]*5,[0]*5
    interactions=[[0]*5 for _ in range(5)]
    for j,(_,_,body) in enumerate(cycle):
        nxt,prev=cycle[(j+1)%len(cycle)],cycle[j-1]
        u[body]+=nxt[1]-prev[1]
        v[body]+=prev[0]-nxt[0]
        neighbor=nxt[2]
        interactions[body][neighbor]+=1
        interactions[neighbor][body]-=1
    const=F(sum(cross(p,q) for p,q in pairs(cycle)),2*GEOM**2)
    grad=tuple(F(z,2*GEOM) for z in u[1:]+v[1:])
    mixed=tuple(F(interactions[i][j],2) for i in range(1,5) for j in range(1,5))
    return const,grad,mixed


def evaluate(corner,cut):
    a,g,m=cut
    x,y=corner[:4],corner[4:]
    return a+sum(h*z for h,z in zip(g,corner,strict=True))+sum(
        m[4*i+j]*x[i]*y[j] for i in range(4) for j in range(4))


def validate_a_lp(rectangle,cuts,weights):
    assert min(weights)>=0 and sum(weights)==1 and len(cuts)==len(weights)
    mixed=tuple(sum(w*cut[2][j] for w,cut in zip(weights,cuts,strict=True)) for j in range(16))
    linear=tuple(sum(w*cut[1][j] for w,cut in zip(weights,cuts,strict=True)) for j in range(8))
    scalar=sum(w*cut[0] for w,cut in zip(weights,cuts,strict=True))
    return min(evaluate(z,(scalar,linear,mixed)) for z in rectangle)


def propose_weights(rectangle,cuts):
    from scipy.optimize import linprog
    n=len(cuts)
    # Shift by the target to keep the scale of the constraints modest.
    matrix=[[*(float(GOAL-evaluate(z,cut)) for cut in cuts),1] for z in rectangle]
    sol=linprog([0]*n+[-1],A_ub=matrix,b_ub=[0]*len(matrix),
                A_eq=[[1]*n+[0]],b_eq=[1],bounds=[(0,None)]*n+[(None,None)])
    assert sol.success
    raw=[round(max(0,x)*GRID) for x in sol.x[:n]]
    assert sum(raw)>0
    return tuple(F(x,sum(raw)) for x in raw)


def build_region(box,ctr,rectangle,area,scale):
    changed=[list(v) for v in rectangle]
    error=allowance(area,scale,GOAL,GRID)
    if error<=0:
        return None
    for order,spin,_ in BODIES:
        if spin is None:
            continue
        c=F(ctr[spin],2)
        r=min(c-box[spin][0],box[spin][1]-c,error*FINE/SPEED[order])
        changed[spin]=[(c-r).__ceil__(),(c+r).__floor__()]
        assert SPEED[order]*max(abs(F(2*x-ctr[spin],GRID)) for x in changed[spin])<=error
    assert all(a<=u<v<=b for (a,b),(u,v) in zip(box,changed,strict=True))
    lower=area_floor(area,error,scale)
    assert lower>GOAL
    return {"box":changed,"angle_hausdorff_allowance":str(error),
            "body_scale":str(scale),"strict_area_lower":str(lower),
            "fraction_of_leaf":str(F(prod(b-a for a,b in changed),prod(b-a for a,b in box)))}


def run_case(box,axis,samples,seeds,frozen=None):
    ctr,points,bounds=geometry(box,axis,samples)
    sample=tuple(dict.fromkeys([tuple(map(F,row["shifts"])) for row in seeds]+[(F(0),)*4]))
    records=[]
    for radius in RADII:
        rect,vertical=crossing_box(box,ctr,axis,radius)
        corner=list(product(*bounds,*vertical))
        trial_cuts=[(t,cuts(points,t,vertical)) for t in sample]
        valid=[(t,c) for t,c in trial_cuts if c is not None]
        if not valid:
            continue
        cut_list=[c for _,c in valid]
        if frozen:
            saved=frozen[str(radius)]
            assert saved["sites"]==[list(map(str,t)) for t,_ in valid]
            weights=list(map(F,saved["weights"]))
        else:
            weights=propose_weights(corner,cut_list)
        proof=validate_a_lp(corner,cut_list,weights)
        regional=build_region(box,ctr,rect,proof,F(1))
        data={"pre_angle_lower":str(proof),"sites":[list(map(str,t)) for t,_ in valid],
              "weights":list(map(str,weights)),"region":regional,
              "scaled_region":build_region(box,ctr,rect,proof,SCALED)}
        records.append((str(radius),data))
    return dict(records)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ("boxes","shadow","output"):
        p.add_argument(k,type=Path)
    p.add_argument("--replay",type=Path)
    a=p.parse_args()
    assert __debug__
    ctx.prec=160
    assert all((arb.pi()/(2*n)).tan()/2<ar(v) for n,v in SPEED.items())
    raw=a.boxes.read_bytes()
    source=a.shadow.read_bytes()
    boxes=json.loads(raw)
    prior=json.loads(source)
    frozen=json.loads(a.replay.read_bytes()) if a.replay else None
    assert sha256(raw).hexdigest()==prior["boxes_sha256"]
    result={}
    for k,v in prior["cases"].items():
        label,axis=k.split("/")
        result[k]=run_case(boxes[label]["box"],int(axis),prior["samples"],v["cuts"],
                           frozen["cases"][k] if frozen else None)
        if frozen:
            assert result[k]==frozen["cases"][k]
        widths=[(F(z["region"]["fraction_of_leaf"]),r) for r,z in result[k].items() if z["region"]]
        print(k, len(widths), [(float(x),r) for x,r in sorted(widths,reverse=True)[:2]],flush=True)
    out={"shadow_sha256":sha256(source).hexdigest(),"cases":result}
    if frozen:
        assert out==frozen
    a.output.write_text(json.dumps(out,indent=2)+"\n")


if __name__=="__main__":
    main()

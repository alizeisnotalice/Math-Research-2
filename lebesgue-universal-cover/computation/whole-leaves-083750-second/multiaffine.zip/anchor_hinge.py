"""Certify one moved-anchor P+Q construction with the existing exact hinge engine."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from common_support import area, cross, dot, pairs, poly_hull, reference_polygon, sub


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ("cases","hinge_package","kernel","scratch","output"):
        p.add_argument(arg,type=Path)
    p.add_argument("--samples",default=32,type=int)
    p.add_argument("--angular",default=4096,type=int)
    p.add_argument("--target",default=837750,type=int)
    args=p.parse_args()
    assert __debug__
    sys.path.insert(0,str(args.hinge_package.resolve()))
    from hinge_bank import S, bank, write_poly
    from flint import ctx
    ctx.prec=160
    cases=json.loads(args.cases.read_bytes())
    centers={tuple(v["anchor_twice_fine"]) for v in cases.values()}
    assert len(centers)==1
    ref,denom=reference_polygon(next(iter(centers)),args.samples)
    inner=poly_hull([tuple(round(F((S-4)*x,denom)) for x in p) for p in ref])
    assert all(cross(sub(b,a),sub(tuple(x*denom for x in q),tuple(x*S for x in a)))>=0
               for a,b in pairs(ref) for q in inner)
    assert all(cross(a,b)>0 and cross(a,b)**2 > 4800000**2*dot(sub(b,a),sub(b,a))
               for a,b in pairs(inner))
    src=args.hinge_package/"new-points.json"
    raw=src.read_bytes()
    assert sha256(raw).hexdigest()=="45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05"
    pts=json.loads(raw)
    diameter=max((x-u)**2+(y-v)**2 for x,y in pts["points"] for u,v in pts["points"])
    assert len(pts["points"])==11 and diameter<=pts["denominator"]**2
    shape=F(diameter,pts["denominator"]**2)
    args.scratch.mkdir(exist_ok=True)
    host=args.scratch/"anchor.dat"
    with host.open("w") as f:
        f.write(f"{S} 1\n")
        write_poly(f,inner)
    cloud=args.scratch/"angles.dat"
    bank(src,args.angular,cloud)
    result=subprocess.check_output([args.kernel,host,cloud,str(args.target)],text=True).strip()
    actual=list(map(int,result.split()))
    assert len(actual)==4 and actual[0]==0 and actual[2]==2*args.angular
    checked={
        "strict_lower_pass":actual==[0,2*args.angular,2*args.angular,-1],
        "goal":str(F(args.target,1_000_000)),
        "anchor_twice_fine":list(next(iter(centers))),
        "geometric_samples":args.samples,
        "proof_cells_closed":actual[1],
        "total_cells":actual[2],
        "first_failed_cell":actual[3],
        "diameter_squared":str(shape),
        "anchor_inner_area":str(area(inner,S)),
        "geometry_inputs_sha256":{x.name:sha256(x.read_bytes()).hexdigest() for x in (src,host,cloud)},
    }
    args.output.write_text(json.dumps(checked,indent=2)+"\n")
    print(json.dumps(checked,indent=2))


if __name__=="__main__":
    main()

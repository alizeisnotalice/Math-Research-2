"""Certified common core after pose-dependent translation of the whole host."""
from functools import cmp_to_key
from itertools import combinations
from math import gcd, hypot
from pathlib import Path
from fractions import Fraction as F
import argparse
import json
import sys

from flint import arb, ctx

FINE = 2**44
GRID = 2**32
SCALE = GRID + 5
SUPPORT_SCALE = SCALE * 8 * FINE**2
BODIES = ((0, None, None), (3, None, 0), (5, 2, 3), (7, 5, 6), (9, 8, 9))


def dot(p, q):
    return p[0] * q[0] + p[1] * q[1]


def cross(p, q):
    return p[0] * q[1] - p[1] * q[0]


def add(p, q):
    return p[0] + q[0], p[1] + q[1]


def sub(p, q):
    return p[0] - q[0], p[1] - q[1]


def mul(k, p):
    return k*p[0], k*p[1]


def norm_ray(p):
    g = gcd(*p)
    assert g > 0
    return p[0]//g, p[1]//g


def upper_half(p):
    return p[1] > 0 or (p[1] == 0 and p[0] > 0)


def ccw_first(u, v):
    if upper_half(u) != upper_half(v):
        return -1 if upper_half(u) else 1
    d = cross(u, v)
    return (d < 0) - (d > 0)


ORDER = cmp_to_key(ccw_first)


def pairs(poly):
    return zip(poly, poly[1:] + poly[:1])


def area(poly, grid):
    return F(sum(cross(a, b) for a, b in pairs(poly)), 2*grid*grid)


def poly_hull(points):
    points = sorted(set(points))
    if len(points) < 3:
        raise ValueError("Fewer than three distinct proposed vertices")
    hulls = []
    for perm in (points, reversed(points)):
        half = []
        for p in perm:
            while len(half) >= 2 and cross(sub(half[-1], half[-2]), sub(p, half[-1])) <= 0:
                half.pop()
            half.append(p)
        hulls.extend(half[:-1])
    assert len(hulls) >= 3
    return hulls


def normals(poly):
    for a, b in pairs(poly):
        yield norm_ray((b[1] - a[1], a[0] - b[0]))


def ar(fraction):
    fraction = F(fraction)
    return arb(fraction.numerator) / fraction.denominator


def dyadic(value):
    target = int(round(float(value.mid()) * GRID))
    assert abs(ar(target) - value*GRID) < 1
    return target


def body_polygon(order, angle, samples):
    pi = arb.pi()
    p = []
    if not order:
        for i in range(8*samples):
            sn, cs = (pi*i/(4*samples)).sin_cos()
            p.append((dyadic(cs/2), dyadic(sn/2)))
    else:
        radius = 1/(2*(pi/(2*order)).cos())
        assert 1-radius > ar(F(2,5))
        for i in range(order):
            phi = ar(angle) + 2*pi*i/order
            sn, cs = phi.sin_cos()
            x, y = radius*cs, radius*sn
            for j in range(samples+1):
                theta = phi + pi*(1-ar(F(1,2*order))+ar(F(j,order*samples)))
                sn, cs = theta.sin_cos()
                p.append((dyadic(x+cs), dyadic(y+sn)))
    return poly_hull(p)


def split_cone(u, v, changes):
    # Positive multiples and sums of u,v stay in the counterclockwise cone.
    assert cross(u, v) > 0
    interior = set()
    for p in changes:
        a, b = dot(u,p), dot(v,p)
        if a*b < 0:
            interior.add(norm_ray(add(mul(abs(b),u),mul(abs(a),v))))
    return [u, *sorted(interior, key=cmp_to_key(
        lambda a,b: (cross(a,b)<0) - (cross(a,b)>0))), v]


def segments(u, v, changes):
    rays = split_cone(u, v, changes)
    return zip(rays, rays[1:])


def normal_rows(box, samples):
    all_polys, widths, translations = [], [], []
    for order, spin, position in BODIES:
        ends = (0,) if spin is None else box[spin]
        all_polys.append([body_polygon(order, F(q,FINE), samples) for q in sorted(set(ends))])
        widths.append(0 if spin is None else box[spin][1]-box[spin][0])
        translations.append(((0,0),(0,0)) if position is None
                            else (box[position], box[position+1]))
    rays = {(1,0), (0,1), (-1,0), (0,-1)}
    for group in all_polys:
        for poly in group:
            rays.update(normals(poly))
    rays = sorted(rays, key=ORDER)
    out = {}
    for u,v in pairs(rays):
        interior = add(u,v)
        sign = tuple(1 if c > 0 else -1 for c in interior)
        angles = [[mul(8*FINE**2, max(poly,key=lambda p: dot(p,interior))) for poly in group]
                  for group in all_polys]
        low = [mul(8*FINE*SCALE, (xx[int(sign[0]<0)], yy[int(sign[1]<0)]))
               for xx,yy in translations]
        high = [mul(8*FINE*SCALE, (xx[int(sign[0]>0)], yy[int(sign[1]>0)]))
                for xx,yy in translations]
        avg = [( (a[0]+b[0])//2, (a[1]+b[1])//2) for a,b in zip(low,high,strict=True)]
        switches = [sub(p[0],p[1]) for p in angles if len(p)==2]
        for u2,v2 in segments(u,v,switches):
            w = add(u2,v2)
            support = [sub(min(options,key=lambda p: dot(p,w)), mul(width*width*SCALE,sign))
                       for options,width in zip(angles,widths,strict=True)]
            low_sup = [add(a,b) for a,b in zip(support,low,strict=True)]
            high_sup = [add(a,b) for a,b in zip(support,high,strict=True)]
            pivots = [sub(a,b) for j,a in enumerate(low_sup) for b in low_sup[j+1:]]
            pivots.extend(sub(a,b) for a in low_sup for b in high_sup)
            for ray in split_cone(u2,v2,pivots):
                bound = max(dot(ray,p) for p in low_sup)
                coeff = tuple(dot(ray,c)-min(dot(ray,h),bound-dot(ray,a))
                              for c,h,a in zip(avg,high,support,strict=True))[1:]
                row = (bound, coeff)
                assert ray not in out or out[ray] == row
                out[ray] = row
    return sorted(out.items(), key=lambda row: ORDER(row[0]))


def reference_polygon(center, samples):
    pts = []
    # Move each already contracted rational sample to the chosen pose.
    # The final coordinate grid is exact; the next rounding is paid by contraction.
    denom = SCALE * 2 * FINE
    for order, spin, position in BODIES:
        angle = F(0) if spin is None else F(center[spin],2*FINE)
        translation = (0,0) if position is None else tuple(center[position:position+2])
        pts.extend(add(mul(2*FINE,p),mul(SCALE,translation))
                   for p in body_polygon(order,angle,samples))
    return poly_hull(pts), denom


def static_upper(exact, denom, selector):
    # The LP just selects near-active rows. The upper certificate uses exact
    # positive balancing weights for two or three directions.
    find = sorted(range(len(exact)),key=lambda i: abs(float(selector.residual[i])))[:16]
    proofs=[]
    for count in (2,3):
        for choices in combinations(find,count):
            rays=[exact[i][0] for i in choices]
            if count==2:
                p,q=rays
                if cross(p,q) or dot(p,q)>=0:
                    continue
                j=0 if p[0] else 1
                w=(abs(q[j]),abs(p[j]))
            else:
                w=tuple(cross(p,q) for p,q in pairs(rays[1:]+rays[:1]))
                if max(w)<0:
                    w=tuple(-a for a in w)
                if min(w)<=0:
                    continue
            bound=dual_upper(exact,denom,choices,w)
            proofs.append((bound,choices,w))
    assert proofs
    bound,choices,w=min(proofs)
    return {"s_upper":str(bound),"normal_row_indices":list(choices),"weights":list(w)}


def dual_upper(exact,denom,choices,w):
    chosen=[exact[i] for i in choices]
    assert min(w)>0 and len(set(choices))==len(choices)==len(w)
    assert all(sum(k*row[0][j] for k,row in zip(w,chosen,strict=True))==0 for j in (0,1))
    return F(denom*sum(k*row[1] for k,row in zip(w,chosen,strict=True)),
             SUPPORT_SCALE*sum(k*row[3] for k,row in zip(w,chosen,strict=True)))


def reference_cut(rows, reference, denom):
    from scipy.optimize import linprog
    mat, rhs, exact = [], [], []
    for ray,(base,coeff) in rows:
        div = hypot(*ray)
        h = max(dot(p,ray) for p in reference)
        assert h > 0
        exact.append((ray,base,coeff,h))
        mat.append([h/(denom*div), ray[0]/div, ray[1]/div,
                    *[-k/(SUPPORT_SCALE*div) for k in coeff]])
        rhs.append(base/(SUPPORT_SCALE*div))
    ordinary = linprog([-1,0,0], A_ub=[p[:3] for p in mat], b_ub=rhs,
                       bounds=((0,None),(None,None),(None,None)))
    dynamic = linprog([-1,0,0,0,0,0,0], A_ub=mat+[[0,0,0,1,1,1,1]],
                      b_ub=rhs+[1], bounds=((0,None),(None,None),(None,None),*((0,None),)*4))
    assert ordinary.success and dynamic.success
    output = []
    for r in (ordinary,dynamic):
        translation = tuple(F(int(round(x*GRID)),GRID) for x in r.x[1:3])
        weights = tuple(F(int(max(0,x)*GRID),GRID) for x in r.x[3:]) or (F(0),)*4
        # The LP only proposes common moves. Every finite normal is then checked by integers.
        assert sum(weights) <= 1
        attainable = min( (F(base,SUPPORT_SCALE) + sum(F(k,SUPPORT_SCALE)*a
                    for k,a in zip(coeff,weights,strict=True))-dot(ray,translation))*denom/h
                    for ray,base,coeff,h in exact )
        s = F((attainable*GRID).__floor__(),GRID)
        assert 0 < s <= attainable
        output.append({"s":str(s),"t":list(map(str,translation)),"lambda":list(map(str,weights))})
    output[0]["upper"]=static_upper(exact,denom,ordinary.ineqlin)
    assert F(output[0]["s"])<=F(output[0]["upper"]["s_upper"])
    return output


def inner_core(rows, weights):
    import numpy as np
    from scipy.spatial import HalfspaceIntersection
    if not all(base+dot_ext(weights,coeff)>0 for _,(base,coeff) in rows):
        raise ValueError("The origin must lie strictly inside the approximate core")
    exact = [(ray,F(base+dot_ext(weights,coeff),SUPPORT_SCALE)) for ray,(base,coeff) in rows]
    matrix = []
    for ray, bound in exact:
        size = hypot(*ray)
        matrix.append((ray[0]/size, ray[1]/size, -float(bound)/size))
    proposals = HalfspaceIntersection(np.asarray(matrix),np.zeros(2)).intersections
    points = [(round(float(x)*(GRID-20)),round(float(y)*(GRID-20))) for x,y in proposals]
    poly = poly_hull(points)
    assert all(dot(ray,p)*bound.denominator <= GRID*bound.numerator
               for p in poly for ray,bound in exact)
    return poly


def dot_ext(weights,coeff):
    return sum(a*k for a,k in zip(weights,coeff,strict=True))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("cases",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--samples",type=int,default=32)
    a=p.parse_args()
    assert __debug__ and a.samples>=8
    ctx.prec=160
    cases=json.loads(a.cases.read_bytes())
    result={}
    for name,data in cases.items():
        box=data["box"]
        assert len(box)==11 and all(type(a) is int and type(b) is int and a<=b for a,b in box)
        center=data.get("anchor_twice_fine", [sum(v) for v in box])
        rows=normal_rows(box,a.samples)
        reference,denom=reference_polygon(center,a.samples)
        fits=reference_cut(rows,reference,denom)
        for r in fits:
            r["core"] = inner_core(rows,list(map(F,r["lambda"])))
            r["core_area"] = str(area(r["core"],GRID))
        result[name]={"normals":len(rows),"fits":fits,"reference_area":str(area(reference,denom))}
        print(name,len(rows),[float(F(r["s"])) for r in fits],
              [float(F(r["core_area"])) for r in fits],flush=True)
    a.output.write_text(json.dumps({"core_grid":GRID,"samples":a.samples,"cases":result},
                                  separators=(",",":"))+"\n")


if __name__=="__main__":
    main()

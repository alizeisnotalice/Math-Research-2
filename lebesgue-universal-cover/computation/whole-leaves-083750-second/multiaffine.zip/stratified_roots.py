"""Extract fixed probes from both leaf-weighted and part-weighted residual samples."""
from hashlib import sha256
import argparse
import json
from pathlib import Path
import sys


def evenly(values,n):
    assert len(values)>=n>=2
    return [values[j*(len(values)-1)//(n-1)] for j in range(n)]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("comp","tree","residual","output"):
        p.add_argument(name,type=Path)
    p.add_argument("--pilot",action="store_true")
    a=p.parse_args()
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import FINE, SourceTree
    raw=a.residual.read_bytes()
    parts=sorted((int(p),sorted(row["remaining"]))
                 for p,row in json.loads(raw)["parts"].items() if row["remaining"])
    assert len(parts)==67 and sum(len(row) for _,row in parts)==3279
    keys=[(p,k) for p,row in parts for k in row]
    if a.pilot:
        active=[(136,24814),(1205,137645),(181,129770)]
    else:
        active=sorted(set(evenly(keys,16)) | {(p,row[len(row)//2]) for p,row in evenly(parts,16)})
    assert len(active)==len(set(active)) and set(active)<=set(keys)
    src=SourceTree(a.tree)
    saved={}
    for part,pos in active:
        box=src.leaf(part,pos)
        assert all((v*FINE).denominator==1 for row in box for v in row)
        box=[[int(v*FINE) for v in row] for row in box]
        saved[f"original-{part}-{pos}"]={"box":box,"residual_sha256":sha256(raw).hexdigest()}
    a.output.write_text(json.dumps(saved,indent=2)+"\n")
    print(len(active),len(set(p for p,_ in active)))


if __name__=="__main__":
    main()

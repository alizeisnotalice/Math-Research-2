"""Eliminate all four parallel translations with global affine area minorants."""
from fractions import Fraction as F
from hashlib import sha256
from math import prod
from pathlib import Path
import argparse
import json

from flint import arb, ctx
from scale_transfer import SCALED, allowance, area_floor
from common_support import BODIES, FINE, SCALE, ar, body_polygon, cross, pairs, poly_hull

GOAL=F(".83750")
GRID=2*FINE
GEOM=GRID*SCALE
SPEED={5:F(".163"),7:F(".115"),9:F(".089")}


def geometry(box, axis, samples):
    ctr=[sum(v) for v in box]
    points=[]
    bounds=[]
    for order,spin,pos in BODIES:
        theta=0 if spin is None else F(ctr[spin],GRID)
        t=(0,0) if pos is None else tuple(ctr[pos:pos+2])
        p=[tuple(t[j]*SCALE+v[j]*GRID for j in (axis,1-axis))
           for v in body_polygon(order,theta,samples)]
        points.append(p)
        if pos is not None:
            idx=pos+axis
            bounds.append(tuple(F(2*y-ctr[idx],GRID) for y in box[idx]))
    return ctr,points,bounds


def affine(vertices, shifts):
    unit=[0]+[x*GEOM for x in shifts]
    assert all(v==int(v) for v in unit)
    unit=list(map(int,unit))
    selected={}
    for family,points in enumerate(vertices):
        for x,y in points:
            selected.setdefault((x+unit[family],y),(x,y,family))
    cycle=poly_hull(selected.keys())
    base=[selected[v] for v in cycle]
    g=[0]*5
    for i,(_,y,body) in enumerate(base):
        g[body]+=base[(i+1)%len(base)][1]-base[i-1][1]
    z=F(sum(cross(a,b) for a,b in pairs(base)),2*GEOM**2)
    slope=tuple(F(coef,2*GEOM) for coef in g[1:])
    assert z+sum(a*b for a,b in zip(shifts,slope,strict=True))==F(
        sum(cross(a,b) for a,b in pairs(cycle)),2*GEOM**2)
    return z,slope


def methods(vertices,bounds):
    from scipy.optimize import linprog
    cuts=[]
    args=[]
    shift=(F(0),)*4
    for _ in range(40):
        args.append(shift)
        cuts.append(affine(vertices,shift))
        optimum=linprog([0,0,0,0,1],A_ub=[[*map(float,v),-1] for _,v in cuts],
                        b_ub=[-float(c) for c,_ in cuts],
                        bounds=[*[tuple(map(float,b)) for b in bounds], (None,None)])
        assert optimum.success
        proposed=tuple(max(lo,min(hi,F(round(float(x)*GRID),GRID))) for x,(lo,hi)
                       in zip(optimum.x[:4],bounds,strict=True))
        if proposed==shift or proposed in args:
            break
        shift=proposed
        c,v=affine(vertices,shift)
        if float(c+sum(x*y for x,y in zip(v,shift,strict=True)))-optimum.fun<1.e-10:
            break
    raw=[round(max(0,-float(x))*GRID) for x in optimum.ineqlin.marginals]
    assert sum(raw)>0
    return [{"shifts":list(map(str,t)),"weight":str(F(w,sum(raw)))}
            for t,w in zip(args,raw,strict=True) if w]


def exact_lower(vertices,bounds,sites):
    w=[F(x["weight"]) for x in sites]
    assert min(w)>0 and sum(w)==1
    cuts=[]
    for site in sites:
        x=tuple(map(F,site["shifts"]))
        assert all(a<=z<=b for z,(a,b) in zip(x,bounds,strict=True))
        cuts.append(affine(vertices,x))
    slope=[sum(z*v[k] for z,(_,v) in zip(w,cuts,strict=True)) for k in range(4)]
    return sum(z*a for z,(a,_) in zip(w,cuts,strict=True)) + sum(
        min(s*a,s*b) for s,(a,b) in zip(slope,bounds,strict=True))


def slab(box, ctr, axis, floor, scale):
    enlargement=allowance(floor,scale,GOAL,GRID)
    if enlargement<=0:
        return None
    inner=[list(v) for v in box]
    for order,spin,pos in BODIES[1:]:
        cross_axis=pos+1-axis
        for k,budget in [(cross_axis,enlargement if spin is None else enlargement/2)]+(
                [] if spin is None else [(spin,enlargement/(2*SPEED[order]))]):
            center=F(ctr[k],2)
            radius=min(center-box[k][0],box[k][1]-center,budget*FINE)
            inner[k]=[(center-radius).__ceil__(),(center+radius).__floor__()]
    assert all(a<=l<r<=b for (a,b),(l,r) in zip(box,inner,strict=True))
    def displacement(j):
        return max(abs(F(2*x-ctr[j],GRID)) for x in inner[j])
    direct=max(displacement(pos+1-axis)+(0 if spin is None else SPEED[order]*displacement(spin))
               for order,spin,pos in BODIES[1:])
    lower=area_floor(floor,enlargement,scale)
    assert direct<=enlargement and lower>GOAL
    return {"box":inner,"hausdorff_allowance":str(enlargement),
            "body_scale":str(scale),"strict_area_lower":str(lower),
            "fraction_of_leaf":str(F(prod(r-l for l,r in inner),prod(b-a for a,b in box)))}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("boxes",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--samples",type=int,default=48)
    p.add_argument("--replay",type=Path)
    a=p.parse_args()
    assert __debug__
    ctx.prec=160
    assert all((arb.pi()/(2*n)).tan()/2<ar(v) for n,v in SPEED.items())
    raw=a.boxes.read_bytes()
    boxes=json.loads(raw)
    old=json.loads(a.replay.read_bytes()) if a.replay else None
    result={}
    for case,row in boxes.items():
        if not case.startswith("original-"):
            continue
        box=row["box"]
        for axis in (0,1):
            name=f"{case}/{axis}"
            ctr,points,bounds=geometry(box,axis,a.samples)
            certificate=old["cases"][name]["cuts"] if old else methods(points,bounds)
            area_lower=exact_lower(points,bounds,certificate)
            center_cut=exact_lower(points,bounds,[{"weight":"1","shifts":["0"]*4}])
            result[name]={"parallel_lower":str(area_lower),"center_cut_lower":str(center_cut),
                          "cuts":certificate,
                          "slab":slab(box,ctr,axis,area_lower,F(1)),
                          "scaled_slab":slab(box,ctr,axis,area_lower,SCALED)}
            if old:
                assert result[name]==old["cases"][name]
            print(name,float(area_lower),result[name]["slab"] and float(F(
                result[name]["slab"]["fraction_of_leaf"])),flush=True)
    out={"boxes_sha256":sha256(raw).hexdigest(),"samples":a.samples,"cases":result}
    if old:
        assert out==old
    a.output.write_text(json.dumps(out,indent=2)+"\n")


if __name__=="__main__":
    main()

"""Choose fully specified dyadic cubes about a frozen low six-body representative."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("comp","tree","residual","anchor","output"):
        p.add_argument(name,type=Path)
    p.add_argument("--radius", type=F, default=F(1,8000))
    a=p.parse_args()
    assert 0<a.radius<=F(1,8000)
    sys.path.insert(0,str(a.comp))
    from audit_five_harmonic_tree import split
    from certify_tomar_six_high import SourceTree
    scale=2**44
    src=SourceTree(a.tree)
    pose=json.loads(a.anchor.read_bytes())["center"]
    q=[F(v,scale) for v in pose]
    root=list(zip(map(F,src.root["lo"]),map(F,src.root["hi"]),strict=True))
    assert all(l<x<h for (l,h),x in zip(root,q,strict=True))
    part=sum((x>(l+h)/2) << (10-i)
             for i,((l,h),x) in enumerate(zip(root,q,strict=True)))
    box,codes,prefix=src.load(part)
    pos=0
    while codes[pos]<11:
        k=codes[pos]
        assert box[k][0] < q[k] < box[k][1]
        r=prefix.index(prefix[pos],pos+2)
        side=int(q[k]>(box[k][0]+box[k][1])/2)
        box=split(box,k)[side]
        pos=r if side else pos+1
    assert box==src.leaf(part,pos) and all(l<x<h for (l,h),x in zip(box,q,strict=True))
    data=json.loads(a.residual.read_bytes())
    assert pos in data["parts"][str(part)]["remaining"],(part,pos)
    candidates={}
    for k in (-1,0,1,3,4,6,7,9,10):
        widths=[F(1,50000)]*11
        if k>=0:
            widths[k]=a.radius
        else:
            widths=[F(1,8000) if j not in (2,5,8) else F(1,1600) for j in range(11)]
        h=[int(min(w*scale,(x-l*scale)*F(9,10),(r*scale-x)*F(9,10)))
           for w,(l,r),x in zip(widths,box,pose,strict=True)]
        sub=[[x-d,x+d] for x,d in zip(pose,h,strict=True)]
        assert all(l*scale<=lo<hi<=r*scale for (l,r),(lo,hi) in zip(box,sub,strict=True)), (part,pos,k,box,sub)
        candidates[f"dominant-coordinate-{k}"]={"box":sub,"anchor_twice_fine":[2*x for x in pose]}
    a.output.write_text(json.dumps(candidates,indent=2)+"\n")
    print(json.dumps({"source_leaf":[part,pos],"original_bounds":[[str(x) for x in v] for v in box],
                      "representative_sha256":sha256(a.anchor.read_bytes()).hexdigest(),
                      "residual_sha256":sha256(a.residual.read_bytes()).hexdigest()},indent=2))


if __name__=="__main__":
    main()

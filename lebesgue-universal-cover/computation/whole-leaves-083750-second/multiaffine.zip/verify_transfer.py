"""Verify saved moved-support certificates with Arb and rational arithmetic."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from math import prod
from pathlib import Path

from flint import ctx
from scale_transfer import SCALED, area_floor
from common_support import FINE, SUPPORT_SCALE, dot, dual_upper, normal_rows, reference_polygon

TARGET=F(".83750")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("boxes","bounds","hinge","certificate","output"):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    assert __debug__
    ctx.prec=160
    cases=json.loads(a.boxes.read_bytes())
    parent=json.loads(a.bounds.read_bytes())
    hinge=json.loads(a.hinge.read_bytes())
    certificate=json.loads(a.certificate.read_bytes())
    assert hinge["strict_lower_pass"] and hinge["proof_cells_closed"]==hinge["total_cells"]==8192
    k=certificate["samples"]
    assert k==hinge["geometric_samples"]==32
    assert set(cases)==set(certificate["cases"])
    L=F(hinge["goal"])
    assert L==F(".837750")
    orig=[[F(u)*FINE for u in line] for line in parent["original_bounds"]]
    ref,denom=reference_polygon(hinge["anchor_twice_fine"],k)
    result={}
    covered=[]
    scaled_covered=[]
    for name,case in cases.items():
        proof=certificate["cases"][name]
        assert case["anchor_twice_fine"]==hinge["anchor_twice_fine"]
        box=case["box"]
        assert len(box)==11 and all(type(l) is int and type(r) is int and a<=l<r<=b
                                    for (a,b),(l,r) in zip(orig,box,strict=True))
        rows=normal_rows(box,k)
        exact=[(ray,base,coef,max(dot(v,ray) for v in ref)) for ray,(base,coef) in rows]
        assert len(rows)==proof["normals"] and all(row[3]>0 for row in exact)
        bounds=[]
        assert len(proof["fits"])==2
        for gauge,fit in enumerate(proof["fits"]):
            s=F(fit["s"])
            t=list(map(F,fit["t"]))
            weights=list(map(F,fit["lambda"]))
            assert len(t)==2 and len(weights)==4
            assert 0<s<=1 and min(weights)>=0 and sum(weights)<=1
            assert gauge or all(v==0 for v in weights)
            assert all(s*F(h,denom)+dot(ray,t) <=
                       F(base+sum(w*v for w,v in zip(weights,coef,strict=True)),SUPPORT_SCALE)
                       for ray,base,coef,h in exact)
            bounds.append(s*s*L)
        dual=proof["fits"][0]["upper"]
        upper=dual_upper(exact,denom,dual["normal_row_indices"],dual["weights"])
        assert upper==F(dual["s_upper"]) and F(proof["fits"][0]["s"])<=upper
        transfer_pass=max(bounds)>TARGET
        if transfer_pass:
            covered.append(box)
        scaled_bounds=[area_floor(value,0,SCALED) for value in bounds]
        if max(scaled_bounds)>TARGET:
            scaled_covered.append(box)
        scaled_dual=area_floor(upper*upper*L,0,SCALED)
        result[name]={"disk_fixed_lower":str(bounds[0]),"moving_lower":str(bounds[1]),
                      "scaled_disk_fixed_lower":str(scaled_bounds[0]),"scaled_moving_lower":str(scaled_bounds[1]),
                      "scaled_disk_fixed_template_test_upper":str(scaled_dual),
                      "scaled_moving_strictly_excludes":scaled_bounds[1]>TARGET,
                      "scaled_moving_improves_decision_of_envelope":scaled_bounds[1]>TARGET>=scaled_dual,
                      "disk_fixed_template_test_upper":str(upper*upper*L),
                      "moving_strictly_excludes":bounds[1]>TARGET,
                      "moving_improves_decision_of_envelope":bounds[1]>TARGET>=upper*upper*L,
                      "normals":len(rows)}
    # The accepted, differently extended boxes have a common pairwise
    # intersection. This gives their exact union volume, by removing overlap.
    def meet(x,y):
        return [[max(a,c),min(b,d)] for (a,b),(c,d) in zip(x,y,strict=True)]
    def relative(accepted):
        assert len(accepted)>=2
        base=meet(*accepted[:2])
        assert all(meet(x,y)==base for i,x in enumerate(accepted) for y in accepted[i+1:])
        def volume(b):
            return prod(r-l for l,r in b)
        fraction=(sum(volume(b) for b in accepted)-(len(accepted)-1)*volume(base))/volume(orig)
        assert 0<fraction<1
        return fraction
    out={
        "goal":str(TARGET),"anchor_lower":str(L),"source_leaf":parent["source_leaf"],
        "cases":result,"excluded_case_count":len(covered),
        "improved_decision_case_count":sum(x["moving_improves_decision_of_envelope"] for x in result.values()),
        "excluded_union_fraction_of_original_leaf":str(relative(covered)),
        "body_scale":str(SCALED),"scaled_excluded_case_count":len(scaled_covered),
        "scaled_improved_decision_case_count":sum(x["scaled_moving_improves_decision_of_envelope"] for x in result.values()),
        "scaled_union_fraction_of_original_leaf":str(relative(scaled_covered)),
        "input_sha256":{v.name:sha256(v.read_bytes()).hexdigest()
                        for v in (a.boxes,a.bounds,a.hinge,a.certificate)}
    }
    a.output.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps({k:v for k,v in out.items() if k not in ("cases","input_sha256")},indent=2))


if __name__=="__main__":
    main()

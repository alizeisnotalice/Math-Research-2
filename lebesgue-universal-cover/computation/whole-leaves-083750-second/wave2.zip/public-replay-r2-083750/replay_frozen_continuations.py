"""Replay the original and replacement finite-input frontier continuations."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor,as_completed
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT=Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def proof_schema(row):
    fields=('leaf','label','lo','hi','mode','budget','panels','pads','stats','goal',
            'pending','threshold_integer','p_edge_stops','q_edge_stops','p_coupled_stops',
            'q_coupled_stops','p_tangent_stops','q_tangent_stops')
    return tuple(row.get(key) for key in fields)


def run(a,name,group):
    source=ROOT/group['inputs']
    packet=a.work/name/'packet'
    packet.mkdir(parents=True,exist_ok=False)
    for fname in ('cases.json','subboxes.json'):
        shutil.copyfile(source/fname,packet/fname)
    command=[sys.executable,'-I','-B',str(ROOT/'run_frontier_priority.py'),
             str(a.comp),str(a.tree),str(a.table),str(a.work/name/'compute'),str(a.cache),
             str(packet),'--mode',str(group['mode']),'--budget',str(group['budget'])]
    if group.get('replacement'):
        command+=['--points',str(ROOT/'new-p30/points.json')]
    subprocess.run(command,check=True)
    actual=rows(packet/'children.jsonl')
    frozen=rows(source/'children.jsonl')
    assert [proof_schema(row) for row in actual]==[proof_schema(row) for row in frozen],name
    print(name,len(actual),sum(r['stats'][0] for r in actual),flush=True)


def main(a):
    manifest=read(ROOT/'continuation-replay.json')
    groups=a.groups or tuple(manifest)
    assert len(set(groups))==len(groups) and set(groups)<=set(manifest)
    with ThreadPoolExecutor(a.workers) as executor:
        for job in as_completed([executor.submit(run,a,g,manifest[g]) for g in groups]):
            job.result()


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for field in ('comp','tree','table','work','cache'):
        p.add_argument(field,type=Path)
    p.add_argument('--workers',default=4,type=int)
    p.add_argument('--groups',nargs='+')
    main(p.parse_args())

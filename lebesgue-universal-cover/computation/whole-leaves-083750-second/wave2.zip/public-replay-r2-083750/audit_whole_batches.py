"""Audit disjoint whole-leaf scope and count only the weakest proved input family."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

THRESHOLD=120696470013529293
PACKAGE=Path(__file__).resolve().parent


def logical_name(path):
    resolved=path.resolve()
    if resolved.is_relative_to(PACKAGE):
        return resolved.relative_to(PACKAGE).as_posix()
    checksum=sha256(resolved.read_bytes()).hexdigest()
    return f'external/{checksum}/{resolved.name}'


def audit_extensions(path, runs, generations, accepted, attempts, hashes, transfer=None):
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    from audit_refined_scope import audit_paths, digest, read
    hashes[logical_name(path)]=digest(path)
    assert isinstance(generations,list)
    seen=set()
    for task in generations:
        key=task['leaf']
        assert key not in seen
        seen.add(key)
        files={kind:(path.parent/task[kind]).resolve() for kind in ('parent','frontier','child')}
        assert files['parent'] in runs
        for kind,source in files.items():
            value=digest(source)
            assert value==task['sha256'][kind]
            hashes[logical_name(source)]=value
        rows=files['parent'].read_bytes().splitlines()
        line=task['parent_line']
        assert type(line) is int and 1<=line<=len(rows)
        parent=json.loads(rows[line-1])
        assert parent['leaf']==parent['label']==key and not parent['stats'][0]
        if transfer:
            point_cert,source,fine=transfer
            endpoints=source.leaf(*map(int,key.split('/')))
            assert all(
                lo*fine==a and hi*fine==b for (lo,hi),(a,b) in zip(
                    endpoints,zip(parent['lo'],parent['hi'],strict=True),strict=True))
            s=parent['stats']
            assert parent['goal']=='67/80' and parent['threshold_integer']==THRESHOLD
            assert parent.get('p30_family','original_p30')=='original_p30'
            assert s[4]==s[5]==0 and not parent['guards'] and not parent['center_stops']
            assert s[1]==2*sum(s[2:6])+parent['pending']-1+parent['pending_visited']
        frontier=read(files['frontier'])
        assert frontier and audit_paths(parent,frontier)>0
        children=[json.loads(r) for r in files['child'].read_bytes().splitlines()]
        terminals=parent['stats'][2:6]
        additive={key:parent.get(key,0) for key in (
            'p_edge_stops','q_edge_stops','p_coupled_stops','q_coupled_stops',
            'p_tangent_stops','q_tangent_stops')}
        for box,child in zip(frontier,children,strict=True):
            stats=child['stats']
            assert child['leaf']==key and child['label']==box['label']
            if transfer:
                assert child['p30_family']=='new_p30' and child['mode'] in (0,4)
                assert child['p30_sha256']==point_cert['points_sha256']
                assert child['p30_minimum_row_floor_gain']==point_cert['minimum_integer_gain']
            else:
                family=child.get('p30_family','original_p30')
                assert family=='original_p30' or (family=='new_p30' and not (stats[3] or stats[4]))
            assert child['goal']=='67/80' and child['threshold_integer']==THRESHOLD
            assert box['bounds']==[list(pair) for pair in zip(child['lo'],child['hi'],strict=True)]
            assert not child['pending'] and not child['guards'] and not child['center_stops']
            assert len(stats)==35 and stats[0]==1 and stats[5]==stats[7]==0
            assert stats[1]==2*sum(stats[2:6])-1 and 0<stats[1]<=child['budget']
            assert all(type(s) is int and s>=0 for s in stats[:8])
            assert child['mode'] in (0,1,4) and (child['mode']&1 or not stats[4])
            assert child['mode']!=4 or not stats[3]
            assert 0<=child['p_edge_stops']<=stats[3] and 0<=child['q_edge_stops']<=stats[4]
            terminals=[a+b for a,b in zip(terminals,stats[2:6],strict=True)]
            for field in additive:
                additive[field]+=child.get(field,0)
        extra=sum(r['stats'][1] for r in children)
        attempts['attempts']+=len(children)
        attempts['nodes']+=extra
        nodes=parent['stats'][1]+extra-parent['pending_visited']
        assert nodes==2*sum(terminals)-1
        family=7 if terminals[2] else 6 if terminals[1] else 5
        candidate=dict(leaf=key,inputs=family,source_file=files['parent'].name,source_line=line,
                       nodes=nodes,five_terminals=terminals[0],P30_terminals=terminals[1],
                       Q11_terminals=terminals[2],P30_long_edge=additive['p_edge_stops'],
                       Q11_long_edge=additive['q_edge_stops'],P30_coupled=additive['p_coupled_stops'],
                       Q11_coupled=additive['q_coupled_stops'],P30_tangent=additive['p_tangent_stops'],
                       Q11_tangent=additive['q_tangent_stops'],
                       extended_frontier={'boxes':len(frontier),'child_sha256':digest(files['child']),
                                          'additional_nodes':extra})
        if transfer:
            candidate['p30_family']='new_p30'
            candidate['p30_transferred_terminals']=parent['stats'][3]
            candidate['p30_native_terminals']=terminals[1]-parent['stats'][3]
        earlier=accepted.get(key)
        if earlier is None or (family,nodes)<(earlier['inputs'],earlier['nodes']):
            accepted[key]=candidate


def main(a):
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import FINE,SourceTree
    source=SourceTree(a.tree)
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    p30=None
    if a.new_p30_receipt:
        p30=json.loads(a.new_p30_receipt.read_bytes())
        assert p30['point_family']=='new_p30' and p30['angle_cells']==384 and p30['rows']==2493
        assert p30['minimum_integer_gain']>=0 and not a.extensions
    scopes={}
    hashes={}
    for path in a.scopes:
        value=json.loads(path.read_bytes())
        hashes[logical_name(path)]=digest(path)
        assert value['threshold_integer']==THRESHOLD and value['goal']=='67/80' and value['whole_leaves']
        chosen=[f"{x['part']}/{x['pos']}" for x in value['tasks']]
        assert value['selected']==len(chosen)==len(set(chosen))
        assigned=[]
        for name,desc in value['task_sha256'].items():
            packet=path.parent/name
            assert digest(packet)==desc['sha256']
            chunk=json.loads(packet.read_bytes())
            assert len(chunk)==desc['count']
            assigned.extend(chunk)
        assert len(assigned)==len(set(assigned)) and set(assigned)==set(chosen)
        for x in chosen:
            assert x not in scopes
            scopes[x]=path.name
    oldest={}
    visited=set()
    accepted={}
    attempts=Counter()
    failed=Counter()
    for path in a.runs:
        hashes[logical_name(path)]=digest(path)
        with path.open() as stream:
            for line_number,line in enumerate(stream,1):
                row=json.loads(line)
                key=row['leaf']
                assert key in scopes and row['label']==key
                assert row['goal']=='67/80' and row['threshold_integer']==THRESHOLD
                if key not in oldest:
                    bounds=source.leaf(*map(int,key.split('/')))
                    scaled=[[x*FINE for x in pair] for pair in bounds]
                    assert all(x.denominator==1 for pair in scaled for x in pair)
                    oldest[key]=[list(map(int,x)) for x in zip(*scaled,strict=True)]
                assert oldest[key]==[row['lo'],row['hi']]
                mode=row['mode']
                if p30:
                    assert row['p30_family']=='new_p30' and mode in (0,4)
                    assert row['p30_sha256']==p30['points_sha256']
                    assert row['p30_minimum_row_floor_gain']==p30['minimum_integer_gain']
                    if 'subset_points_sha256' in p30:
                        assert row['p30_angle_rows_sha256']==p30['geometric_rows_sha256']
                else:
                    assert row.get('p30_family','original_p30')=='original_p30'
                assert mode in (0,1,4) and not row['guards'] and not row['center_stops']
                stats=row['stats']
                assert len(stats)==35 and stats[5]==0 and all(type(s) is int for s in stats)
                assert stats[0] in (0,1) and 0<stats[1]<=row['budget']
                assert all(s>=0 for s in stats[2:6])
                assert 0<=row['p_edge_stops']<=stats[3] and 0<=row['q_edge_stops']<=stats[4]
                assert not mode&4 or not (stats[3] or stats[4])
                assert mode&1 or stats[4]==0
                attempted=(key,mode,row['budget'],row['panels'],row['shared_angles'],
                           row['edge_caps'],row.get('fan_integral',False),
                           row.get('coupled_support',False),row.get('cap_tangent',False),
                           row.get('q_trigger_divisor',25000))
                assert attempted not in visited
                visited.add(attempted)
                attempts['attempts']+=1
                attempts['nodes']+=stats[1]
                if not stats[0]:
                    assert stats[7] in (1,2,3) and row['pending']>0
                    checked=row.get('pending_visited',int(stats[7]!=1))
                    assert stats[1]==2*sum(stats[2:6])+row['pending']-1+checked
                    failed[str(stats[7])]+=1
                    continue
                assert row['pending']==stats[7]==0 and stats[1]==2*sum(stats[2:6])-1
                family=7 if stats[4] else 6 if stats[3] else 5
                candidate=dict(leaf=key,inputs=family,source_file=path.name,source_line=line_number,
                               nodes=stats[1],five_terminals=stats[2],P30_terminals=stats[3],
                               Q11_terminals=stats[4],P30_long_edge=row['p_edge_stops'],
                               Q11_long_edge=row['q_edge_stops'],
                               P30_coupled=row.get('p_coupled_stops',0),
                               Q11_coupled=row.get('q_coupled_stops',0),
                               P30_tangent=row.get('p_tangent_stops',0),
                               Q11_tangent=row.get('q_tangent_stops',0),
                               q_trigger_divisor=row.get('q_trigger_divisor',25000))
                if p30:
                    candidate['source_path']=logical_name(path)
                earlier=accepted.get(key)
                if earlier is None or (family,stats[1])<(earlier['inputs'],earlier['nodes']):
                    accepted[key]=candidate
    if a.extensions:
        audit_extensions(a.extensions,{p.resolve() for p in a.runs},
                         json.loads(a.extensions.read_bytes()),accepted,attempts,hashes)
    checked={x[0] for x in visited}
    counts=Counter(str(x['inputs']) for x in accepted.values())
    remaining=sorted(set(scopes)-set(accepted))
    result=dict(goal='67/80',selected=len(scopes),checked_leaves=len(checked),
                complete_batch=(set(scopes)==checked),all_closed=not remaining,
                closed=len(accepted),by_family={str(j):counts.get(str(j),0) for j in (5,6,7)},
                Q11_without_P30=sum(x['inputs']==7 and x['P30_terminals']==0 for x in accepted.values()),
                visited_attempts=attempts['attempts'],visited_nodes=attempts['nodes'],
                failure_attempts=dict(failed),remaining=len(remaining),
                original_bounds_checked_for=len(oldest),proof_records=[accepted[k] for k in sorted(accepted)],
                unresolved=remaining,input_files_sha256=hashes)
    if p30:
        result.update(point_family='new_p30',point_set_sha256=p30['points_sha256'])
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'proof_records','unresolved','input_files_sha256'}}),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','output'):
        p.add_argument(key,type=Path)
    p.add_argument('--scopes',nargs='+',type=Path,required=True)
    p.add_argument('--runs',nargs='+',type=Path,required=True)
    p.add_argument('--extensions',type=Path,
                   help='Manifest of complete exact frontiers extending an audited failed run.')
    p.add_argument('--new-p30-receipt',type=Path,
                   help='Audit only native runs with this separately verified replacement point set.')
    main(p.parse_args())

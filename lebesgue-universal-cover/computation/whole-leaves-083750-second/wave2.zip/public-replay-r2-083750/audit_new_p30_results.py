"""Join the original-six transferred proofs with native replacement proofs."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys


HERE=Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main(a):
    sys.path.insert(0,str(HERE))
    sys.path.insert(0,str(HERE/'kernels-new-p30'))
    from audit_whole_batches import audit_extensions
    from verify_new_p30 import check_table
    _, certificate=check_table(a.comp,a.points)
    from certify_tomar_six_high import FINE,SourceTree
    assert certificate==read(a.certificate)
    joined=read(a.old)
    audits=[a.native,*a.native_more]
    native=[read(p) for p in audits]
    assert joined['strict'] and joined['target']=='67/80'
    for wave in native:
        assert wave['goal']=='67/80' and wave['point_family']=='new_p30' and wave['complete_batch']
        assert wave['point_set_sha256']==certificate['points_sha256']
    proved={}
    all_leaves=set()
    old_remaining=set()
    old_q=set()
    for part,state in joined['parts'].items():
        labels=[f'{part}/{pos}' for name in ('five','P30','Q11','remaining') for pos in state[name]]
        assert len(set(labels))==len(labels) and all_leaves.isdisjoint(labels)
        all_leaves.update(labels)
        old_remaining.update(f'{part}/{pos}' for pos in state['remaining'])
        old_q.update(f'{part}/{pos}' for pos in state['Q11'])
        for family,name in (('five','five'),('P30','transferred_original_P30')):
            for pos in state[family]:
                proved[f'{part}/{pos}']=name
    assert len(all_leaves)==joined['stage4_retained']
    native_fixed={}
    for wave in native:
        for row in wave['proof_records']:
            key=row['leaf']
            assert key in all_leaves and key not in native_fixed
            assert row['inputs'] in (5,6) and row['Q11_terminals']==0
            native_fixed[key]='native_five' if row['inputs']==5 else 'native_new_P30'
    transferred={}
    extras=Counter()
    hashes={}
    if a.extensions:
        generations=read(a.extensions)
        assert all(entry['leaf'] in all_leaves for entry in generations)
        audit_extensions(a.extensions,{p.resolve() for p in a.old_runs},generations,
                         transferred,extras,hashes,(certificate,SourceTree(a.tree),FINE))
    for key, name in native_fixed.items():
        proved.setdefault(key,name)
    for key,row in transferred.items():
        assert row['inputs'] in (5,6) and row['Q11_terminals']==0
        proved.setdefault(key,'continued_five' if row['inputs']==5 else 'continued_new_P30')
    counts=Counter(proved.values())
    residual=all_leaves-set(proved)
    assert sum(counts.values())+len(residual)==len(all_leaves)
    proof_leaves=sorted(set(proved)&old_remaining)
    misses_q=sorted(residual&old_q)
    without_proof=sorted(residual&old_remaining)
    assert len(residual)==len(misses_q)+len(without_proof)
    result=dict(target='67/80',strict=True,model='five_curves_and_new_p30',
                point_set_sha256=certificate['points_sha256'],scope=len(all_leaves),
                closed=len(proved),by_input_provenance=counts,remaining=len(residual),
                certified_in_originally_unclosed=proof_leaves,
                remaining_with_only_old_Q11_proof=misses_q,
                remaining_with_neither_proof=without_proof,
                original_and_replacement_counts_distinct=True,
                new_native_checked_leaves=sum(wave['checked_leaves'] for wave in native),
                new_native_nodes=sum(wave['visited_nodes'] for wave in native),
                continuation_selected_node_totals=extras,
                continuation_proofs=sorted(transferred.values(),key=lambda x:x['leaf']),
                proof_by_leaf=proved,remaining_leaves=sorted(residual),
                inputs_sha256={p.name:digest(p) for p in (a.old,*audits,a.points,a.certificate)},
                extension_sha256=hashes)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items()
                      if not isinstance(value,list) and key not in {'proof_by_leaf','extension_sha256'}}),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','points','certificate','old','native','output'):
        p.add_argument(key,type=Path)
    p.add_argument('--extensions',type=Path)
    p.add_argument('--native-more',type=Path,nargs='+',default=[])
    p.add_argument('--old-runs',type=Path,nargs='+',default=[])
    main(p.parse_args())

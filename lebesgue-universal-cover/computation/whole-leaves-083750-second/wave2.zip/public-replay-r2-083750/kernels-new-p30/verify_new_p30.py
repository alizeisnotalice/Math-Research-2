"""Revalidate the proposed rational P30 on every inherited closed angle row."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys

from flint import ctx
import numpy as np


def check_table(comp, point_file, subset_file=None, subset_cells_file=None):
    ctx.prec = 160
    sys.path.insert(0, str(comp))
    from certify_tomar_six_high import Q, U
    from replay_q11_with_p30 import PointProof

    def load(path):
        return json.loads(path.read_bytes())

    old_point_file = comp / 'finite-point-leaf-input.json'
    cell_file = comp / 'finite-point-global-input.json'
    p = load(old_point_file)
    cells = load(cell_file)['cells']
    new = load(point_file)
    dots, denom = new['points'], new['denominator']
    assert new['directions'] == p['directions'] and new['direction_scale'] == p['direction_scale'] == U
    assert type(denom) is int and denom > 0
    assert len(dots) == len(p['points']) == 30
    assert all(len(z)==2 and all(type(x) is int for x in z) for z in dots)
    assert len({tuple(x) for x in dots}) == 30
    assert {tuple(x) for x in dots} == {(x, -y) for x, y in dots}
    diameter2 = max((a-x)**2+(b-y)**2 for (a,b),(x,y) in combinations(dots,2))
    assert diameter2 <= denom**2
    original = PointProof({**p, 'cells': cells})
    candidate = PointProof({**new, 'cells': cells})
    assert np.array_equal(original.pointers, candidate.pointers) and len(cells) == 384
    assert np.array_equal(original.directions, candidate.directions)
    assert np.array_equal(original.disk, candidate.disk)
    a, b = (s.triples.reshape(-1, 8) for s in (original, candidate))
    assert len(a) == len(b) == 2493 and np.array_equal(a[:, :7], b[:, :7])
    more={}
    dig = lambda path: sha256(path.read_bytes()).hexdigest()
    assert bool(subset_file)==bool(subset_cells_file)
    if subset_file:
        subset=load(subset_file)
        assert subset['denominator']==denom and subset['directions']==new['directions']
        assert {tuple(z) for z in subset['points']} <= {tuple(z) for z in dots}
        subset_cells=load(subset_cells_file)['cells']
        additional=PointProof({**subset,'cells':subset_cells})
        assert np.array_equal(additional.pointers,candidate.pointers)
        extra=additional.triples.reshape(-1,8)
        assert np.array_equal(b[:, :7],extra[:, :7])
        more.update(subset_points_sha256=dig(subset_file),subset_cells_sha256=dig(subset_cells_file),
                    subset_count=len(subset['points']),subset_floor_minimum_gain=int(np.min(extra[:,7]-a[:,7])),
                    improved_over_candidate_rows=int(np.sum(extra[:,7]>b[:,7])))
        b[:,7]=np.maximum(b[:,7],extra[:,7])
    delta = (b[:, 7] - a[:, 7]).tolist()
    assert min(delta) >= 0
    return candidate, dict(points_sha256=dig(point_file), old_points_sha256=dig(old_point_file),
                           cells_sha256=dig(cell_file), points=30, denominator=denom,
                           diameter_squared_numerator=diameter2, angle_cells=len(cells), rows=len(a),
                           point_family='new_p30', min_first_row=delta.index(min(delta)),
                           minimum_integer_gain=min(delta), maximum_integer_gain=max(delta),
                           minimum_exact_lower_gain=str(Fraction(min(delta),Q)),
                           geometric_rows_sha256=sha256(b.astype('<i8').tobytes()).hexdigest(),**more)


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('comp', type=Path)
    p.add_argument('points', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--subset-points',type=Path)
    p.add_argument('--subset-cells',type=Path)
    args = p.parse_args()
    _, answer = check_table(args.comp, args.points,args.subset_points,args.subset_cells)
    args.output.write_text(json.dumps(answer, indent=2) + '\n')
    print(json.dumps(answer), flush=True)

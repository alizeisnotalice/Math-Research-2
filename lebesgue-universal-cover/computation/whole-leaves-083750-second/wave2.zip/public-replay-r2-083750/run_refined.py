"""Execute frozen whole-leaf packets with the optional exact area refinements."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor,as_completed
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def main(a):
    scope=json.loads(a.scope.read_bytes())
    records=scope['jobs']
    assert scope['goal']=='67/80'
    seen=set()
    names=set()
    for j in records:
        assert j['path']==Path(j['path']).name and j['path'] not in names
        names.add(j['path'])
        path=a.scope.parent/j['path']
        packet=json.loads(path.read_bytes())
        assert len(packet)==len(set(packet))==j['count'] and seen.isdisjoint(packet)
        assert sha256(path.read_bytes()).hexdigest()==j['sha256']
        seen.update(packet)
    assert len(seen)==scope['selected']
    if a.packets:
        wanted=set(a.packets)
        assert len(wanted)==len(a.packets) and wanted<=names
        records=[j for j in records if j['path'] in wanted]
    a.work.mkdir(parents=True,exist_ok=True)
    a.output.mkdir(parents=True,exist_ok=True)

    def run(job):
        packet=a.scope.parent/job['path']
        job_name=Path(job['path']).stem
        mode,budget=job['mode'],job['budget']
        label=f'refined-{job_name}'
        completed=a.output/(label+'.jsonl')
        assert not completed.exists()
        pending=completed.with_name(completed.name+'.partial')
        frontier=a.output/'frontiers'/label
        cmd=[sys.executable,'-I','-B',str(HERE/'kernels-tangent/replay_angle_mesh.py'),
             str(a.comp),str(a.tree),str(a.table),str(a.work/label),str(a.cache),
             '--target','.83750','--cases-from',str(packet),'--modes',str(mode),
             '--budget',str(budget),'--depth','116','--dense','--share-dense','--panels','256',
             '--share-angles','--edge-caps','--fan-integral','--coupled-support','--cap-tangent',
             '--frontier-out',str(frontier)]
        if mode&1:
            cmd+=['--q-mesh','--q-trigger-divisor','12000']
        with pending.open('x') as dst,(a.work/(label+'.log')).open('w') as err:
            subprocess.run(cmd,stdout=dst,stderr=err,check=True)
        rows=[json.loads(line) for line in pending.read_bytes().splitlines()]
        assert [r['leaf'] for r in rows]==json.loads(packet.read_bytes())
        assert all(r['mode']==mode and r['budget']==budget and r['fan_integral']
                   and r['coupled_support'] and r['cap_tangent'] for r in rows)
        pending.rename(completed)
        raw=dict(complete=True,mode=mode,budget=budget,checked=len(rows),
                 closed=sum(r['stats'][0] for r in rows),nodes=sum(r['stats'][1] for r in rows),
                 input_sha256=job['sha256'],result_sha256=sha256(completed.read_bytes()).hexdigest())
        completed.with_name(completed.stem+'-receipt.json').write_text(json.dumps(raw)+'\n')
        return label,raw

    with ThreadPoolExecutor(a.workers) as pool:
        for ready in as_completed([pool.submit(run,j) for j in records]):
            print(*ready.result(),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','table','work','cache','scope','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--workers',type=int,default=8)
    p.add_argument('--packets',nargs='+',help='Run only these packet filenames from the frozen scope.')
    a=p.parse_args()
    assert a.workers>0
    main(a)

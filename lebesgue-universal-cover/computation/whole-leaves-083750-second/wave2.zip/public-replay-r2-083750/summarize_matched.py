"""Compare actual runs on fixed 24-leaf control cohorts."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def load(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def main(directory, output):
    groups = {}
    for mode in (0, 1):
        prefix = f'm{mode}'
        packet = json.loads((directory / f'mode{mode}.json').read_bytes())
        assert len(packet) == len(set(packet)) == 24
        control = load(directory / f'{prefix}-control.jsonl')
        rows = []
        for path in sorted(directory.glob(f'{prefix}-*.jsonl')):
            if path.name not in {f'{prefix}-{s}.jsonl' for s in
                                 ('control', 'integrals', 'both', 'tangent', 'wider-q', 'localmesh')}:
                continue
            data = load(path)
            assert [x['leaf'] for x in data] == packet
            for row, base in zip(data, control, strict=True):
                assert all(row[k] == base[k] for k in
                           ('leaf', 'lo', 'hi', 'goal', 'threshold_integer', 'mode', 'budget',
                            'panels', 'q_mesh', 'edge_caps', 'shared_dense'))
                assert (row['mode'], row['panels'], row['budget']) == (mode, 256, 32767)
                assert row['shared_dense'] and row['edge_caps']
            assert all(r['shared_prep_cpu'] == data[0]['shared_prep_cpu'] for r in data)
            tally = {
                'result': path.name,
                'sha256': sha256(path.read_bytes()).hexdigest(),
                'shared_angle_mesh': data[0]['shared_angles'],
                'fan_integral': data[0].get('fan_integral', False),
                'coupled_support': data[0].get('coupled_support', False),
                'cap_tangent': data[0].get('cap_tangent', False),
                'q_trigger_divisor': data[0].get('q_trigger_divisor', 25000),
                'closed': [r['leaf'] for r in data if r['stats'][0]],
                'nodes': sum(r['stats'][1] for r in data),
                'prep_cpu': data[0]['shared_prep_cpu'] + sum(r['prep_cpu'] for r in data),
                'search_cpu': sum(r['search_cpu'] for r in data),
                'P30_coupled': sum(r.get('p_coupled_stops', 0) for r in data),
                'Q11_coupled': sum(r.get('q_coupled_stops', 0) for r in data),
                'P30_tangent': sum(r.get('p_tangent_stops', 0) for r in data),
                'Q11_tangent': sum(r.get('q_tangent_stops', 0) for r in data),
            }
            rows.append(tally)
        assert len(rows) == (5 if mode == 0 else 6)
        groups[str(mode)] = rows
    record = dict(selected=48, threshold='67/80', cohorts=groups,
                  selection='Previously failed full roots with an active finite-point guard.')
    output.write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('directory', type=Path)
    cli.add_argument('output', type=Path)
    args = cli.parse_args()
    main(args.directory, args.output)

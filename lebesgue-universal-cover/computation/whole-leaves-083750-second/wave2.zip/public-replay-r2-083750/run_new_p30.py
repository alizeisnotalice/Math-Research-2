"""Run the replacement point set on frozen complete original-box requests."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main(a):
    scope=read(a.scope)
    cert=read(a.receipt)
    assert scope['goal']=='67/80' and scope['whole_leaves']
    assert scope['points_sha256']==cert['points_sha256']==digest(a.points)
    assigned=[f"{j['part']}/{j['pos']}" for j in scope['tasks']]
    assert len(assigned)==len(set(assigned))==scope['selected']
    known=set()
    jobs={}
    for name,info in scope['task_sha256'].items():
        path=a.scope.parent/name
        assert path.parent==a.scope.parent
        packet=read(path)
        assert digest(path)==info['sha256']
        assert len(packet)==len(set(packet))==info['count'] and known.isdisjoint(packet)
        known.update(packet)
        jobs[name]=info
    assert known==set(assigned)
    assert not a.packets or set(a.packets)<=set(jobs)
    a.output.mkdir(parents=True,exist_ok=True)
    a.work.mkdir(parents=True,exist_ok=True)

    def run(name):
        path=a.scope.parent/name
        label=path.stem
        out=a.output/(label+'.jsonl')
        assert not out.exists()
        temporary=out.with_name(out.name+'.partial')
        cmd=[sys.executable,'-I','-B',str(HERE/'kernels-new-p30/replay_angle_mesh.py'),
             str(a.comp),str(a.tree),str(a.table),str(a.work/label),str(a.cache),
             '--p30-points',str(a.points),'--target','.83750','--cases-from',str(path),
             '--modes','0','--budget',str(a.budget),'--depth','116','--panels','256',
             '--share-angles','--dense','--share-dense','--edge-caps','--fan-integral',
             '--coupled-support','--cap-tangent','--frontier-out',str(a.output/'frontiers'/label)]
        if a.subset:
            subset_cloud,subset_rows=a.subset
            assert digest(subset_cloud)==cert['subset_points_sha256']
            assert digest(subset_rows)==cert['subset_cells_sha256']
            cmd+=['--subset-points',str(subset_cloud),'--subset-cells',str(subset_rows)]
        with temporary.open('x') as stream,(a.work/(label+'.log')).open('w') as log:
            subprocess.run(cmd,stdout=stream,stderr=log,check=True)
        rows=[json.loads(line) for line in temporary.read_bytes().splitlines()]
        assert [r['leaf'] for r in rows]==read(path)
        assert all(r['mode']==0 and r['budget']==a.budget and r['p30_family']=='new_p30'
                   and r['p30_sha256']==cert['points_sha256']
                   and r['p30_minimum_row_floor_gain']==cert['minimum_integer_gain'] for r in rows)
        temporary.rename(out)
        ret=dict(complete=True,scope=len(rows),nodes=sum(r['stats'][1] for r in rows),
                 closed=sum(r['stats'][0] for r in rows),points_sha256=cert['points_sha256'],
                 packet_sha256=jobs[name]['sha256'],result_sha256=digest(out))
        out.with_name(label+'-receipt.json').write_text(json.dumps(ret)+'\n')
        return name,ret

    with ThreadPoolExecutor(a.workers) as pool:
        for job in as_completed([pool.submit(run,name) for name in (a.packets or jobs)]):
            print(*job.result(),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for field in ('comp','tree','table','work','cache','scope','output','points','receipt'):
        p.add_argument(field,type=Path)
    p.add_argument('--packets',nargs='+')
    p.add_argument('--subset',nargs=2,type=Path,metavar=('POINTS','ROWS'))
    p.add_argument('--workers',type=int,default=7)
    p.add_argument('--budget',type=int,default=16383)
    args=p.parse_args()
    assert args.workers>0 and args.budget>0
    main(args)

# $0.83750$ 的第二阶段整叶复算

输入范围为首波逐号审计留下的全部 1,552 枚原始闭叶，清单和来源哈希在 scope-refined/selection.json。每个包内依据原树分片及三角中心排序，保持毫无交叠的叶号分配。1,524 枚预算 65,535 节点，此前已经用完 65,535 节点的 28 枚升为 131,071。除 1/12000 的旧 $Q_{11}$ 启动门槛外，核同时开启弧积分增项、相同曲体耦合支撑及逆函数切线。原 $P_{30}$、旧 $Q_{11}$、五体的形状与刚体运动均锁定。 [严格面积证明](ALGEBRAIC-PRUNING.md)

COMP、TREE、TABLE64、CACHE 采用上次公开复算包中的既定输入。SCRATCH 是本机临时目录，RESULT 是整叶记录及前沿保存目录。可并行启动两台机器各自的 `--packets` 子集并归并其结果文件和相应 frontiers 子目录。未使用 `--packets` 时重放全范围。每次运行将记录写入 `.partial`，全部核对后改名并写对应回执。

~~~sh
python -I -B run_refined.py "$COMP" "$TREE" "$TABLE64" "$SCRATCH" "$CACHE" \
    scope-refined/selection.json "$RESULT" --workers 8
~~~

如需独立复算某一包，在命令末尾加 `--packets m0-b131071-00.json` 等 scope 中的输入文件名。

## 严格覆盖与累积合成

以 $2^{-44}$ 表示原叶的 11 个参数区间端点。一次闭二分的地址位 $2k+s$ 代表沿坐标 $k$ 选第 $s$ 个半盒，每步共享精确中分面。核从完整原叶根启动。预算或深度耗尽时，记录首个未闭子树及广度补集内实际尚未访问的右兄弟。已返回成功的子树保留原判据，其证书按严格叶终端复算。任何有未决前沿的原叶仍进入后续清单。若随后有全部前沿的完整排除，可按原地址接上证书以覆盖整叶。

以下命令从本工作目录运行，需首波原始回执仍在当前目录。如果从首波 ZIP 重放，改为用其 frozen/ 中对应的 10 个主包和 m1-wider-q.jsonl。每一轮的全根取自同一公开原树。一枚原叶的多次成功保留使用输入最少的证书，再按节点数取小。选择的证书出现旧 $Q_{11}$ 终端时记在独立组；同时单列其中未用 $P_{30}$ 的证书数。

~~~sh
python -I -B audit_whole_batches.py "$COMP" "$TREE" audit-final-r2.json \
    --scopes scope3279/selection.json \
    --runs m?-b*-??.jsonl matched-algebraic/m1-wider-q.jsonl "$RESULT"/refined-*.jsonl

python -I -B audit_refined_scope.py previous-index.json "$STAGE4_RETAINED" \
    audit-final-r2.json joined-r2-index.json \
    --frontiers scope-refined/selection.json audit-upgrade-and-wider.json \
    "$RESULT" checked-frontier-index.json
~~~

第二个入口另外重建每个未闭参数盒的全部端点，检验同一父节点采用相同分割轴、前沿地址互不包含、叶号分配和每份回执的哈希。这一步将所有已闭原叶和余下原叶按第四层登记逐号核对。

## 匹配对照

以此前达到预算且确实触发过各自有限点判据的 48 枚选样，取原六和允许旧 $Q_{11}$ 各 24 枚。固定原闭盒、256 段网格、密材料和 32,767 节点上限，分别运行原长弦帽、弧积分增项、弧积分与耦合支撑、仅逆函数切线。在该选样的这一预算下，这些四组均无新增完整原叶。耦合支撑共参与 90,553 次成功局部帽核，逆函数切线共参与 92,381 次；这些局部计数属于不同试验，整叶增量以合成回执为准。旧 $Q_{11}$ 启动范围扩大单独关闭 1205/151488、1205/151777、1205/151801，全部登记在首波。

共享角度格和逐叶角度格同为 256 段，固定密材料共用。原六在共享格与逐叶格的预处理 CPU 时间分别为 2.487、6.039 秒，旧 $Q_{11}$ 两者为 4.110、9.733 秒。相应各 24 枚使用相同的 786,408 节点，均留有未决盒。按分片和中心聚类的第二阶段同时改用更深预算和新核，不由跨阶段比较单独归因。 [实际对照数据](measured-matched-comparison.json)

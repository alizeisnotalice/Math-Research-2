# 新三十点输入的闭角支配

同一直径至多 1 的连续曲体与点集模型。新输入为 points.json 指定的 30 个整数点除以 $10^9$。全部 435 个点对的距离平方分子最大值为 $999999800367158817<10^{18}$。关于横轴的反射置换整个点集，故任意刚体姿态可以覆盖于完整的 384 个闭角格。与原点集使用相同的材料号、整数法向、三正权和权和。程序用 Arb 160 位独立重新计算了全部 2,493 行，每行均严格提升。以面积核的支撑倍率 $Q=2^{28}$ 表示，最小整数提升为 68,447，最大为 850,716。 [完整精确表验收](validated-angle-rows.json)

## 原三十点证书的传递条件

固定同一闭参数盒、曲体材料、法向网格及五曲体面积下端。每个角格中的一条平衡约束写为 $\sum_i w_i v_i\cdot p_i$ 的同一整数单位下端。原点和平移无关，因为 $\sum_i w_iv_i=0$。几何核的独立支撑、共用平移和共用角的支撑上端均只来自五个曲体。圆盘、长弦、联合平方预算以及有理切线所用的面积和深度上端也只来自已固定的曲体参数盒。替换有限输入修改的是平衡约束的整数下端，帽判据的净余量只会增大。所有检测正余量的比较均对正余量单调。原证书中每个角格中成功的行仍为充分见证，原闭盒仍可严格排除。

五体区域证书直接适用。原 $P_{30}$ 证书中每个符合上述条件的闭终端可传递，原二分树和共享中分面保持，故完整原根也传递。整区间证书、点相对姿态优化或新旧输入混用需要核对实际依赖。在登记的整叶波次中，无另一个按原点定义的中心证书、局部点集证书或换形体终端。旧 $Q_{11}$ 终端单独保留，其面积条件须用新三十点另行建立，方可列入新六体全域。

## 复算

COMP、TREE、TABLE64、CACHE 与首波公开包一致。下列命令从当前独立工位运行。原旧输入账本和新点任务分别审计。

~~~sh
python -I -B kernels-new-p30/verify_new_p30.py "$COMP" new-p30/points.json \
    new-p30/rechecked-angle-rows.json

python -I -B run_new_p30.py "$COMP" "$TREE" "$TABLE64" "$WORK" "$CACHE" \
    new-p30/scope-a/selection.json "$RUNS" new-p30/points.json \
    new-p30/validated-angle-rows.json --workers 7 --budget 16383

python -I -B audit_whole_batches.py "$COMP" "$TREE" "$AUDIT" \
    --scopes new-p30/scope-a/selection.json --runs "$RUNS"/new30-*.jsonl \
    --new-p30-receipt new-p30/validated-angle-rows.json
~~~

几何入口只允许纯五或五体加新三十点；全量复验精确点云、角格和整行支配，记录点集 SHA。旧十一点、旧点云的独立中心和外部点集证书均不参与新输入的原生运行。

## 同一个新输入的十五点见证

fifteen/points.json 的十五点逐一属于同一新三十点集。fifteen/rows.json 更换了各闭角格的材料点号，保留方向、三正权和权和。以两份分别严格核验的整数下端的最大值供同一几何核使用。该选择只要求同一个输入含有这些点，每条行的姿态区间仍为原闭角格。全部 2,493 行重算后，最小整数增益 74,526，较新三十点原材料号再提高 2,062 行。 [精确合成角表验收](validated-best-of-two.json)

在以上复算命令中，独立角表验证另加 `--subset-points new-p30/fifteen/points.json --subset-cells new-p30/fifteen/rows.json`；批运行传入相应验收文件，并添加 `--subset new-p30/fifteen/points.json new-p30/fifteen/rows.json`。两个口径使用同一个三十点刚体，因此按原叶地址并账。每批的实际支撑整数表哈希单列。

四枚已经用原 $P_{30}$ 闭合的原叶采用原样共享表、材料和节点预算重算，新表全部闭合，节点数 25,141→11,111、28,087→19,829、28,159→16,457、28,223→10,961。四枚只是实现回归，已按原输入证书在合账中计数。 [四叶复算](transfer-test/comparison.json)

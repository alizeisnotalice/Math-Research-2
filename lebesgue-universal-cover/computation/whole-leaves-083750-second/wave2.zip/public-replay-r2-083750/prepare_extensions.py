"""Freeze full successful frontier continuations for the whole-leaf audit."""
from argparse import ArgumentParser
from collections import defaultdict
from hashlib import sha256
import json
import os
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def main(a):
    entries = []
    root = a.output.parent.resolve()
    root.mkdir(parents=True, exist_ok=True)

    def freeze(parent, key, source):
        matching = [(i, r) for i, r in enumerate(rows(parent), 1) if r['leaf'] == key]
        (line, r), = matching
        assert not r['stats'][0]
        frontier = parent.parent / 'frontiers' / parent.stem / (
            key.replace('/', '-') + f"-mode{r['mode']}-frontier.json")
        leaf_labels = [box['label'] for box in read(frontier)]
        assert [row['label'] for row in source] == leaf_labels
        if not all(row['stats'][0] for row in source):
            return
        child = root / (key.replace('/', '-') + '.jsonl')
        with child.open('w') as f:
            for row in source:
                f.write(json.dumps(row, separators=(',', ':')) + '\n')
        material = [('parent', parent), ('frontier', frontier), ('child', child)]
        entry = {label: os.path.relpath(path.resolve(), root) for label, path in material}
        entry.update(leaf=key, parent_line=line,
                     sha256={label: sha256(path.read_bytes()).hexdigest() for label, path in material})
        entries.append(entry)

    external=list(a.external)
    if a.part160:
        external.append(('160/11840','refined-m0-b65535-00.jsonl',*a.part160))
    for key,name,result,replay in external:
        path = a.results / name
        x, y = [rows(Path(source)) for source in (result,replay)]
        for left, right in zip(x, y, strict=True):
            assert all(left[k] == right[k] for k in
                       ('leaf', 'label', 'lo', 'hi', 'stats', 'p_edge_stops',
                        'p_coupled_stops', 'p_tangent_stops', 'goal'))
        freeze(path, key, x)
    for batch in a.volume:
        data = defaultdict(list)
        packet = read(batch / 'partition.json')
        for row in rows(batch / 'children.jsonl'):
            data[row['leaf']].append(row)
        assert set(data) == {x['leaf'] for x in packet}
        for req in packet:
            key = req['leaf']
            parent = a.results / Path(req['parent']).name
            assert len(data[key]) == req['boxes']
            freeze(parent, key, data[key])
    assert len(entries) == len({e['leaf'] for e in entries})
    a.output.write_text(json.dumps(entries, indent=2) + '\n')
    print(json.dumps({'selected_extensions': [e['leaf'] for e in entries]}), flush=True)


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('results', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--part160', type=Path, nargs=2, metavar=('ARITHMETIC_RESULT', 'REPLAY'))
    p.add_argument('--external', nargs=4, action='append', default=[],
                   metavar=('LEAF', 'PARENT_PACKET', 'ARITHMETIC_RESULT', 'REPLAY'))
    p.add_argument('--volume', type=Path, nargs='+', default=[])
    main(p.parse_args())

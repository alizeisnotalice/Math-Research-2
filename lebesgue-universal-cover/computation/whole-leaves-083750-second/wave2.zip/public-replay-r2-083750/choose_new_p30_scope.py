"""Freeze unresolved old-input leaves from completed disjoint packets."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from math import ceil
from pathlib import Path


def read(p):
    return json.loads(p.read_bytes())


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def collect(a):
    bound=read(a.audit)
    wanted=set(bound['unresolved'])
    for scope in a.prior:
        wanted-={f"{x['part']}/{x['pos']}" for x in read(scope)['tasks']}
    wanted-=set(a.exclude)
    values={}
    for p in a.runs:
        receipt=read(p.with_name(p.stem+'-receipt.json'))
        assert receipt['complete'] and receipt['result_sha256']==digest(p)
        for line in p.read_bytes().splitlines():
            row=json.loads(line)
            key=row['leaf']
            if key not in wanted:
                continue
            assert not row['stats'][0] and key not in values
            part,pos=map(int,key.split('/'))
            angles=tuple(row['lo'][i]+row['hi'][i] for i in (2,5,8))
            values[key]=(part,angles,pos)
    keys=sorted(values,key=values.__getitem__)
    assert keys
    a.output.mkdir(parents=True,exist_ok=False)
    size=ceil(len(keys)/a.packets)
    jobs={}
    for k,i in enumerate(range(0,len(keys),size)):
        p=a.output/f'new30-{k:02}.json'
        part=keys[i:i+size]
        p.write_text(json.dumps(part,separators=(',',':'))+'\n')
        jobs[p.name]={'sha256':digest(p),'count':len(part)}
    data=dict(goal='67/80',threshold_integer=120696470013529293,whole_leaves=True,
              selected=len(keys),tasks=[dict(part=values[k][0],pos=values[k][2]) for k in keys],
              task_sha256=jobs,points_sha256=read(a.receipt)['points_sha256'],
              old_audit_sha256=digest(a.audit),old_run_sha256={p.name:digest(p) for p in a.runs})
    (a.output/'selection.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(dict(leaves=len(keys),packets=len(jobs))),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for field in ('audit','receipt','output'):
        p.add_argument(field,type=Path)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    p.add_argument('--prior',type=Path,nargs='*',default=[])
    p.add_argument('--exclude',nargs='*',default=[])
    p.add_argument('--packets',type=int,default=7)
    collect(p.parse_args())

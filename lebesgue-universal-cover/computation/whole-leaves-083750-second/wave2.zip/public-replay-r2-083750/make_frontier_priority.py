"""Select exact low-volume unresolved frontiers of completed root packets."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
import json
from math import prod
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def records(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def ratio(row, frontier):
    box_volume = prod(hi-lo for lo,hi in zip(row['lo'],row['hi'],strict=True))
    rest = sum(prod(hi-lo for lo,hi in z['bounds']) for z in frontier)
    assert 0 < rest <= box_volume
    return Fraction(rest,box_volume)


def main(a):
    excluded=set(a.exclude)
    for prior in a.prior:
        excluded.update(x['leaf'] for x in read(prior))
    if a.audit:
        excluded.update(r['leaf'] for r in read(a.audit)['proof_records'])
    scored=[]
    for result in a.results:
        receipt=read(result.with_name(result.stem+'-receipt.json'))
        assert receipt['complete'] and receipt['result_sha256']==sha256(result.read_bytes()).hexdigest()
        found=records(result)
        assert receipt['checked']==len(found)
        assert receipt['mode']==a.mode or a.without_q
        for number,row in enumerate(found,1):
            key=row['leaf']
            if key in excluded or row['stats'][0]:
                continue
            if a.without_q and row['stats'][4]:
                continue
            assert row['mode']==a.mode or a.without_q
            frontier=result.parent/'frontiers'/result.stem/(
                key.replace('/','-') + f"-mode{row['mode']}-frontier.json")
            child=read(frontier)
            assert len(child)==row['pending'] and all(x['leaf']==key for x in child)
            volume=ratio(row,child)
            if volume<=a.max_volume:
                scored.append((volume,key,number,result,frontier,child))
    scored.sort()
    selected=scored[:a.limit]
    assert len(selected)==len({key for _,key,*_ in selected})
    a.output.mkdir(parents=True,exist_ok=False)
    items=[dict(leaf=key,parent=str(result),parent_line=number,frontier=str(frontier),
                pending_ratio=str(volume),boxes=len(child))
           for volume,key,number,result,frontier,child in selected]
    (a.output/'partition.json').write_text(json.dumps(items,indent=2)+'\n')
    (a.output/'cases.json').write_text(json.dumps([x['leaf'] for x in items])+'\n')
    (a.output/'subboxes.json').write_text(
        json.dumps([row for *_,child in selected for row in child],separators=(',',':'))+'\n')
    print(json.dumps(dict(count=len(items),boxes=sum(x['boxes'] for x in items))),flush=True)


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('mode',type=int,choices=(0,1))
    cli.add_argument('output',type=Path)
    cli.add_argument('results',type=Path,nargs='+')
    cli.add_argument('--limit',type=int,default=12)
    cli.add_argument('--max-volume',type=Fraction,default=Fraction(1,4))
    cli.add_argument('--prior',type=Path,nargs='*',default=[])
    cli.add_argument('--exclude',nargs='*',default=[])
    cli.add_argument('--audit',type=Path,help='Exclude all leaves already proved in this old-input audit.')
    cli.add_argument('--without-q',action='store_true',help='Select only prefixes with zero old Q11 stops.')
    main(cli.parse_args())

# $0.83750$ 整叶第二波和新三十点

Tomar v9 的第四层待证集合共有 5,442 枚原叶。每次计算使用原叶完整闭参数盒或以精确地址挂接的前沿闭盒。面积门槛为严格大于 $67/80$ 的整数 $120696470013529293/2^{57}$。

| 实际需要的证书 | 原叶数 |
|---|---:|
| 五个曲体 | 1,080 |
| 五个曲体与原 $P_{30}$ | 2,567 |
| 旧 $Q_{11}$ 终端参与的旧模型 | 922 |
| 上述旧模型均未闭合 | 873 |

旧 $Q_{11}$ 中 921 枚没有使用原 $P_{30}$，另 1 枚使用两套有限点。五体和原 $P_{30}$ 的原六体累计关闭 3,647，余 1,795。所有旧证书合并关闭 4,569，余 873。

第二波从 1,552 枚原根直接闭合 619 枚，序列化 14,250 个前沿闭盒，独立重建 234,337 个地址步。加算前沿又关闭 57 枚旧输入原叶。新三十点续算中另有 3 枚全树只有五体终端，计入纯五。60 枚均以精确原根、完整前沿地址和全部子盒终端拼接。 [累积索引](joined-r2-plus-five-index.json)

新三十点的原生实验以 16,383 节点遍历 791 枚旧模型余叶，均留有前沿；另 85 枚用同一新输入的两支撑行最大值和 32,767 节点预算，均留有前沿。选 16 枚无旧 $Q_{11}$ 终端的闭前沿继续，排除 13 枚完整原叶，其中 3 枚是前表中的纯五，10 枚确有新三十点终端。2,567 枚原 $P_{30}$ 证书按逐行支配传递。因此固定新三十点的六体模型累计关闭 3,657，余 1,785，其中 922 枚有旧 $Q_{11}$ 证书。 [新六码账本](new-p30/joined-ab.json) [新点证书传递](new-p30/PROOF-AND-REPLAY.md)

## 输入

COMP 是 Math-Research-2 的 lebesgue-universal-cover/computation。公开仓库的必要代码、原树分片和 64 级材料哈希在 source-dependencies.json，本包文件哈希见 manifest.json。TREE 为 Tomar v9 的 cert11d_08366.tar.xz 解压目录，源压缩包 SHA-256 为 6b5d28bc488edcfde9c6a49f3cb364f9086f445a58f85f166da23727036cf122。CACHE 为 Clang 模块缓存目录。实算使用 Python 3.13.18、NumPy 2.5.5、python-flint 0.9.0、Arb 128/160 位及 Apple Clang 21.0.0。 [Tomar v9 数据](https://doi.org/10.5281/zenodo.23717912)

~~~sh
python -I -B "$COMP/tomar_fan_table.py" "$TREE" "$TABLE64" --subdiv 64
~~~

## 从公开树重新核对冻结整叶

以下命令从本目录执行。WORK 为单独审计目录。核对完整原根、所有 60 次成功挂接、包回执、所有前沿地址和第四层逐号合并。第三命令重新校验新点的全部整数角行及其模型清单。

~~~sh
mkdir -p "$WORK"
python -I -B audit_whole_batches.py "$COMP" "$TREE" "$WORK/old-audit.json" \
    --scopes scope3279/selection.json \
    --runs m?-b*-??.jsonl matched-algebraic/m1-wider-q.jsonl refined/refined-*.jsonl \
    --extensions extensions/final-old-plus-five.json

python -I -B audit_refined_scope.py previous-index.json stage4-retained.json \
    "$WORK/old-audit.json" "$WORK/old-ledger.json" \
    --frontiers scope-refined/selection.json audit-upgrade-and-wider.json \
    refined "$WORK/checked-frontiers.json"

python -I -B audit_new_p30_results.py "$COMP" "$TREE" new-p30/points.json \
    new-p30/validated-angle-rows.json "$WORK/old-ledger.json" new-p30/audit-a.json \
    "$WORK/new-ledger.json" --extensions new-p30/continued-a-manifest.json \
    --old-runs refined/refined-*.jsonl --native-more new-p30/audit-b.json
~~~

## 重新执行几何核

~~~sh
python -I -B run_refined.py "$COMP" "$TREE" "$TABLE64" "$WORK/compile" "$CACHE" \
    scope-refined/selection.json "$WORK/root-runs" --workers 8

python -I -B replay_frozen_continuations.py "$COMP" "$TREE" "$TABLE64" \
    "$WORK/frontier-rerun" "$CACHE" --workers 4

python -I -B run_new_p30.py "$COMP" "$TREE" "$TABLE64" "$WORK/new-compile" "$CACHE" \
    new-p30/scope-a/selection.json "$WORK/new-runs" new-p30/points.json \
    new-p30/validated-angle-rows.json --workers 7 --budget 16383
~~~

在整根、前沿及新点命令上分别用 --packets、--groups、--packets 派发子包。continuation-replay.json 有九组，四个主要旧输入续算包、三个独立原六叶的四份前沿包及一个新点续算包。181/90526 的两个前沿用 1,048,575 预算。前沿复算逐行比较输入盒、终端、帽数和节点数。若归档新复算，按其新回执和前沿哈希另建挂接清单。首波从头复算沿用 public-replay-upgrade-083750 的单独入口。 [整盒代数和割线证明](ALGEBRAIC-PRUNING.md)

复算新点的后 85 枚使用以下命令。第一节的新点合账中，audit-a.json 对应原材料号，audit-b.json 对应两套材料号的逐行最大值。

~~~sh
python -I -B run_new_p30.py "$COMP" "$TREE" "$TABLE64" "$WORK/new-b-compile" "$CACHE" \
    new-p30/scope-b/selection.json "$WORK/new-b-runs" new-p30/points.json \
    new-p30/validated-best-of-two.json --workers 3 --budget 32767 \
    --subset new-p30/fifteen/points.json new-p30/fifteen/rows.json
~~~

## 发布版路径与冻结索引

回执中的文件绑定采用包内相对路径。为让依赖该原叶索引的后续证书直接复放，joined-r2-plus-five-index.json 按原字节保存。其内部整叶审计摘要记录历史原件，manifest.json 的 portable_provenance 同时给出历史摘要与本包同一审计记录的发布摘要。逐根复核重新计算发布版摘要，并按原叶编号与冻结索引逐项核对。

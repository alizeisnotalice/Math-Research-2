"""Continue a frozen packet of exact unresolved subboxes."""
from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess
import sys


HERE=Path(__file__).resolve().parent


def main(a):
    packet=a.packet
    raw=json.loads((packet/'subboxes.json').read_bytes())
    assert raw and len({x['label'] for x in raw})==len(raw)
    output=packet/'children.jsonl'
    assert not output.exists()
    pending=output.with_name(output.name+'.partial')
    kernel='kernels-new-p30' if a.points else 'kernels-tangent'
    cmd=[sys.executable,'-I','-B',str(HERE/kernel/'replay_angle_mesh.py'),
         str(a.comp),str(a.tree),str(a.table),str(a.work),str(a.cache),'--target','.83750',
         '--cases-from',str(packet/'cases.json'),'--subboxes',str(packet/'subboxes.json'),
         '--modes',str(a.mode),'--budget',str(a.budget),'--depth','116','--dense',
         '--share-dense','--panels','256','--share-angles','--edge-caps',
         '--fan-integral','--coupled-support','--cap-tangent']
    if a.mode:
        cmd+=['--q-mesh','--q-trigger-divisor','12000']
    if a.points:
        assert a.mode==0
        cmd+=['--p30-points',str(a.points)]
    with pending.open('x') as f:
        subprocess.run(cmd,stdout=f,check=True)
    rows=[json.loads(line) for line in pending.read_bytes().splitlines()]
    for box,row in zip(raw,rows,strict=True):
        assert row['leaf']==box['leaf'] and row['label']==box['label']
        assert box['bounds']==[list(q) for q in zip(row['lo'],row['hi'],strict=True)]
        assert row['mode']==a.mode and row['budget']==a.budget
        assert (row.get('p30_family')=='new_p30')==bool(a.points)
    pending.rename(output)
    print(json.dumps(dict(mode=a.mode,boxes=len(rows),closed=sum(r['stats'][0] for r in rows),
                          nodes=sum(r['stats'][1] for r in rows))),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','table','work','cache','packet'):
        p.add_argument(name,type=Path)
    p.add_argument('--mode',type=int,choices=(0,1),required=True)
    p.add_argument('--points',type=Path)
    p.add_argument('--budget',type=int,default=65535)
    main(p.parse_args())

"""Certified angular upper supports for the regular width-one bodies."""
from fractions import Fraction as F
from flint import arb,ctx
import numpy as np
from dual_bank import grid,U,q
K=32768;Z=2**28
def make():
    ctx.prec=160;pi=arb.pi()
    assert q(F(628318530717958647,10**17))<2*pi<q(F(628318530717958648,10**17))
    g=grid();N=len(g)
    for i,(x,y) in enumerate(g):
        s,c=(2*pi*i/N).sin_cos()
        assert (q(F(x,U))-c)**2+(q(F(y,U))-s)**2<q(F(1,U))**2
    bank=[]
    for n in [3,5,7,9]:
        R=1/(2*(pi/(2*n)).cos());assert R<q('.6')
        cache={}
        for j in range(K):
            t=(n*j)%K;t=min(t,K-t)
            if t not in cache:
                angle=2*pi*t/(K*n)
                value=R*angle.cos() if 4*t<=K else 1-R*(pi/n-angle).cos()
                cache[t]=int(((value+q(F(1,U)))*Z).upper().ceil().unique_fmpz())
            bank.append(cache[t])
    return np.array(bank,dtype=np.int64)

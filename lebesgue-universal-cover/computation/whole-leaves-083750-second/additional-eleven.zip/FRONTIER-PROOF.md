# Complete original boxes above 0.83750

The original boxes and historical five-body motions are those of the Tomar 11-dimensional cover. The older point inputs are P30 and the earlier Q11. The new rational eleven-point set is specified in `new-points.json`. Each input can translate, rotate and reflect independently. Each record in `joint-manifest.json` gives the additional inputs actually used on that original box.

The frozen parent index has 873 unresolved leaves at the strict target 67/80. For each included leaf the old second-wave search certifies a collection of terminals and a complete prefix-free gap frontier. Its JSONL file, line and SHA-256, and the separate frontier filename and SHA-256, are given in the manifest. This package covers every listed dyadic gap by a new whole-box search, using just the five original curves and the new eleven-point set. The final count checks twice the number of all terminals minus one against the sum of visits across the original parent search and its appended complete subtrees. The new verifier reconstructs every closed gap endpoint from its exact canonical root, bisection coordinate and side. It checks the frontier against the second-wave file and replays the entire new search.

The new geometry uses the certified integer fan, a radius-half disk, 256 support directions and 384 closed angle intervals in each hand, described in the global 0.83730 package for the same five curves and new input. The balanced bank has 4634 certified triples. This version also combines separated exterior caps. If the augmented area is at most 67/80, all its points have radius less than 0.706. The upper support planes for two directions with nonpositive scalar product each cut beyond radius 1/2. Their exterior half-planes are disjoint inside that disk since a point in both would have squared radius at least 1/2. Rounding the normals does not change this argument: divide each by its actual Euclidean norm, and the support upper bound contains the true disk support in that direction.

Write e for the admissible added area. For each direction the disk and chord proofs give a sufficient projected excess d such that any point with positive excess x at most d incurs outside area at least e(x/d)². This follows because the respective cap lower bounds divided by x² have decreasing denominators after inversion, namely a positive constant divided by sqrt((b+x)²-1/4) for the disk and by x+band for a whole-box chord. The larger excess x>d already contradicts the assumed target in that direction. All thresholds are rounded outwards.

Fix a balanced triple. For an exactly orthogonal or obtuse pair, separate exterior contributions add. If one pair is acute, put its two weighted cap thresholds into a single sum. The larger normalized excess in that pair and the remaining single excess then belong to disjoint caps. Cauchy–Schwarz bounds the weighted sum of positive excesses by the square root of the sum of squared grouped, weighted thresholds. The code skips higher acute-pair counts. A strictly larger certified support margin excludes the whole closed angular cell. The integer comparisons retain the angular and radius errors and use signed 128-bit arithmetic. The geometric kernel falls back to splitting whenever the inequalities fail.

## Reproduction

Use the public `public-replay-r2-083750` package as R2. Its `run_refined.py`, `audit_whole_batches.py` and `audit_refined_scope.py` replay the parent witnesses. COMP denotes the Math-Research-2 `lebesgue-universal-cover/computation` directory. TREE and TABLE64 are the authenticated Tomar v9 `cert11d_08366` tree and certified 64-level table of the associated global new-Q proof. NumPy, python-flint and a C++17 compiler with signed 128-bit integers are required.

```sh
clang++ -O3 -std=c++17 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error -shared -fPIC -I "$COMP/three-leaf-083750" cap_joint.cpp -o "$SCRATCH/joint.so"
python -B replay_joined.py "$COMP" "$TREE" "$TABLE64" "$SCRATCH/joint.so" "$R2" "$SCRATCH" --workers 4
```

A closure using the new points and an older point input applies to the enlarged family with both inputs. The manifest separately identifies whole original leaves that use only the five curves, or only the five curves and the new set.

"""Replay every new subbox and bind prefix witnesses to the exact public 873-leaf index."""
import argparse,gzip,hashlib,json
from pathlib import Path
from argparse import Namespace
from run_fronts import run
from audit_combine import audit_packets,read,digest
from verify_bank import verify
def replay(comp,tree,table,lib,r2,scratch,workers):
    root=Path(__file__).resolve().parent;scratch.mkdir(parents=True,exist_ok=True)
    for rec in (root/'SHA256SUMS').read_text().splitlines():
        checksum,n=rec.split('  ');assert digest(root/n)==checksum
    files={}
    for f in ('regions.json','children.jsonl','balanced384.json'):
        files[f]=scratch/f;files[f].write_bytes(gzip.decompress((root/(f+'.gz')).read_bytes()))
    base=r2/'joined-r2-plus-five-index.json'
    assert digest(base)=='65b4ab38358276aed105897686075377468b4443bd6d74556b272d28df973966'
    index=read(base);res={f'{p}/{i}' for p,v in index['parts'].items() for i in v['remaining']};assert len(res)==873
    prior=read(r2/'extensions/final-old-plus-five.json');old={x['leaf'] for x in prior};assert len(old)==len(prior)==60
    raw=read(files['regions.json']);assert all(v['leaf'] in res for v in raw)
    assert verify(root/'new-points.json',root/'balanced384.json.gz')==4634
    output=scratch/'replicated-children.jsonl'
    run(Namespace(comp=comp,tree=tree,table=table,lib=lib,bank=files['balanced384.json'],output=output,caps=True,mesh=True,target='0.83750',cap=65535,workers=workers,index=None,only=','.join(v['leaf'] for v in raw),resume=None,precontract=0,frontiers=files['regions.json']))
    assert output.read_bytes()==files['children.jsonl'].read_bytes()
    report=audit_packets([files['regions.json']],[output],r2/'refined',old)
    assert report==read(root/'joint-manifest.json');print(report['incremental'],report['by_actual_extra_inputs'])
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ['comp','tree','table','lib','r2','scratch']:p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=4);a=p.parse_args();assert __debug__
    replay(**vars(a))

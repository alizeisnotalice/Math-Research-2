"""Reconstruct full-tree counts and identify every old and new input used by a successful original box."""
import argparse,gzip,hashlib,json,sys
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
def read(f):return json.loads(f.read_bytes())
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def source(row,pack,result):
    # The validated second wave stops before visiting any of its enumerated gaps.
    name=pack['source'].split('/')[0]
    file=result/(name+'.jsonl');receipt=result/(name+'-receipt.json')
    expected=read(receipt)
    assert expected['complete'] and expected['result_sha256']==digest(file)
    index,text=parents(file)[pack['leaf']];fid=result/'frontiers'/pack['source']
    assert read(fid)==pack['regions'] and digest(fid)==pack['digest']
    row.clear();row.update(text)
    assert row['pending']==len(pack['regions']) and row['stats'][0]==0 and row['stats'][7]==1 and row['stats'][5]==0
    assert not row['guards'] and not row['guard_uses'] and F(row['goal'])==F(67,80)
    return dict(file=name+'.jsonl',line=index,sha256=expected['result_sha256'],frontier=pack['source'],frontier_sha256=pack['digest'])
@lru_cache(None)
def parents(f):
    r=list(map(json.loads,f.read_text().splitlines()))
    rows={v['leaf']:(i+1,v) for i,v in enumerate(r)};assert len(rows)==len(r);return rows
def audit_packets(packets,children,result,old):
    allout={};seen=set(); classes=Counter()
    for packet_file,child_file in zip(packets,children,strict=True):
        bykey=defaultdict(dict)
        for row in map(json.loads,child_file.read_text().splitlines()):
            p,i,k=row['leaf'];key=f'{p}/{i}'
            assert int(k)==k and 0<=k and k not in bykey[key] and F(row['target'])==F(67,80)
            bykey[key][k]=row
        packs=read(packet_file)
        for v in packs:
            key=v['leaf'];assert key not in seen;seen.add(key)
            rows=bykey.pop(key,{})
            assert all(j<len(v['regions']) for j in rows)
            if key in old or len(rows)!=len(v['regions']) or not all(x['out'][0] for x in rows.values()):continue
            parent={};links=source(parent,v,result);V,T,P,O=parent['stats'][1:5];count=len(rows)
            assert V==2*(T+P+O)+count-1
            for i,b in enumerate(v['regions']):
                sub=rows[i];s=sub['out']
                assert s[0]==1 and sub['front'] is None and s[1]==2*(s[2]+s[3])-1
                reg=list(map(list,zip(parent['lo'],parent['hi'],strict=True)))
                for step in b['steps']:
                    j,t=divmod(step,2);a,c=reg[j];assert t in (0,1) and 0<=j<11 and a<c and (a+c)%2==0
                    reg[j][1-t]=(a+c)//2
                assert reg==b['bounds']
            addresses=[tuple(z['steps']) for z in v['regions']]
            for i,u in enumerate(addresses):
                for w in addresses[i+1:]:
                    z=next(k for k in range(min(len(u),len(w))) if u[k]!=w[k]);assert u[z]//2==w[z]//2
            vc,tc,nc=[sum(r['out'][j] for r in rows.values()) for j in (1,2,3)]
            assert V+vc==2*(T+P+O+tc+nc)-1
            ids=[x for yes,x in [(P,'P30'),(O,'oldQ11'),(nc,'newQ11')] if yes]
            classes['+'.join(ids) or 'five']+=1
            allout[key]=dict(parent=links,frontier_boxes=count,prefix=dict(visited=V,five=T,P30=P,oldQ11=O),suffix=dict(visited=vc,five=tc,newQ11=nc),whole=dict(visited=V+vc,terminals=T+P+O+tc+nc,extra_inputs=ids))
        assert not bykey
    return dict(target='67/80',strict=True,baseline_remaining=873,incremental=len(allout),by_actual_extra_inputs=dict(sorted(classes.items())),leaves=allout)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('refined_dir',type=Path);p.add_argument('old60',type=Path);p.add_argument('output',type=Path);p.add_argument('--packets',type=Path,nargs='+',required=True);p.add_argument('--children',type=Path,nargs='+',required=True);a=p.parse_args()
    prior=read(a.old60);old={x['leaf'] for x in prior};assert len(prior)==len(old)==60
    obj=audit_packets(a.packets,a.children,a.refined_dir,old)
    a.output.write_text(json.dumps(obj,indent=2)+'\n');print(obj['incremental'],obj['by_actual_extra_inputs'])

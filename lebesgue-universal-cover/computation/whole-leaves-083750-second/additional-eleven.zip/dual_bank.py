"""Certified edge-supported positive triples for an asymmetric polygon rotating in both directions."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse,functools,json,math,sys
import numpy as np
from flint import arb,ctx
U=2**22;W=2**30;AUX=2**28;N=256
def q(x):x=F(x);return arb(x.numerator)/x.denominator
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def cross(a,b,c):return det((b[0]-a[0],b[1]-a[1]),(c[0]-a[0],c[1]-a[1]))
def hull(x):
    def half(v):
        seq=[]
        for z in v:
            while len(seq)>=2 and cross(seq[-2],seq[-1],z)<=0:seq.pop()
            seq.append(z)
        return seq[:-1]
    x=sorted(x);return half(x)+half(x[::-1])
def grid():
    dirs=[(round(U*math.cos(2*math.pi*j/N)),round(U*math.sin(2*math.pi*j/N))) for j in range(N)]
    assert all((U-2)**2<x*x+y*y<(U+2)**2 for x,y in dirs)
    return dirs

def produce(source,hosts,k):
    ctx.prec=160;cloud=json.loads(source.read_bytes());den=cloud['denominator'];dirs=grid()
    points=cloud['points']
    assert max((x-u)**2+(y-v)**2 for x,y in points for u,v in points)<=den**2
    training=[]
    axes=np.array(dirs)/U
    for h in hosts:
        training.append((axes@h.T).max(axis=1))
    training=np.array(training)
    allrows=[];counts=[]
    for sign in (1,-1):
        pp=hull([(x,sign*y) for x,y in points]);edges=[(pp[(j+1)%len(pp)][1]-y,x-pp[(j+1)%len(pp)][0]) for j,(x,y) in enumerate(pp)]
        supports=[F(e[0]*p[0]+e[1]*p[1],den**2) for e,p in zip(edges,pp)]
        nr=[];lam=[];limit=[]
        for ids in combinations(range(len(edges)),3):
            a,b,c=[edges[i] for i in ids];w=[det(b,c),det(c,a),det(a,b)]
            if max(w)<0:w=[-v for v in w]
            if min(w)<=0:continue
            assert all(sum(wt*edges[i][axis] for wt,i in zip(w,ids))==0 for axis in (0,1))
            ws=[F(v,max(w)) for v in w];nr.append(ids);lam.append(ws)
            limit.append(sum(z*supports[i] for z,i in zip(ws,ids)))
        @functools.lru_cache(None)
        def knot(j):
            a=arb.pi()*2*(j%k)/k;s,c=a.sin_cos();out=[]
            for x,y in edges:
                u,v=c*x-s*y,s*x+c*y
                theta=math.atan2(float(v.mid()),float(u.mid()));near=int(math.floor(theta*N/(2*math.pi)))%N
                for i,ii in ((near,(near+1)%N),((near-1)%N,(near+1)%N),((near-1)%N,(near+2)%N)):
                    a0,b0=dirs[i];a1,b1=dirs[ii];D=det(dirs[i],dirs[ii]);assert D>0
                    g=(u*b1-v*a1)*U/(den*D);h=(v*a0-u*b0)*U/(den*D)
                    if g>=0 and h>=0:break
                else:raise ValueError((j,x,y))
                out.append((i,ii,g,h))
            return out
        for j in range(k):
            interp=[];values=[]
            for end in (j,j+1):
                tbl=knot(end);per=[]
                for i,ii,c,s in tbl:per.append(float(c.mid())*training[:,i]+float(s.mid())*training[:,ii])
                values.append(np.array(per))
                interp.append(tbl)
            cand=[]
            for ids,ws,cap in zip(nr,lam,limit):
                val=np.maximum(*[sum(float(wt)*v[idx] for wt,idx in zip(ws,ids)) for v in values])
                cand.append(float(cap)-val)
            cand=np.array(cand)
            select=set()
            for ix in range(training.shape[0]):
                # Several different planes guard a box when its active edges change.
                select.update(np.argsort(-cand[:,ix])[:4])
            select=sorted(select,key=lambda i:-np.mean(cand[i]))
            records=[]
            for ii in select:
                ids,ws,cap=nr[ii],lam[ii],limit[ii]
                # The presumed joint area <.838 bounds all old body support by
                # .706 on the unit circle via the half-radius disk and one point.
                # A support function satisfies h''+h>=0, also at switches.
                mag=sum(q(z)*q(F(x*x+y*y,den**2)).sqrt() for z,(x,y) in zip(ws,[edges[i] for i in ids]))
                error=q('.706')*mag*(2*arb.pi()/k)**2/8
                rhs=int(((q(cap)-error)*W*AUX).lower().floor().unique_fmpz())
                r=[rhs]
                for table in interp:
                    for z,i in zip(ws,ids):
                        n,n2,g,h=table[i]
                        r.extend([n,n2,int((q(z)*g*W).upper().ceil().unique_fmpz()),int((q(z)*h*W).upper().ceil().unique_fmpz())])
                records.append(r)
            allrows.append(records);counts.append(len(records))
    assert len(allrows)==2*k
    return dict(directions=dirs,cells=allrows,knots=k,records=sum(counts))
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for s in ('source','hosts','out'):p.add_argument(s,type=Path)
    p.add_argument('--knots',type=int,default=384);a=p.parse_args();assert __debug__
    rows=a.hosts.read_text().splitlines();S,m=map(int,rows[0].split())
    hosts=[np.array(list(map(int,l.split()[1:]))).reshape(-1,2)/S for l in rows[1:]];assert len(hosts)==m
    out=produce(a.source,hosts,a.knots);a.out.write_text(json.dumps(out,separators=(',',':')));print(out['records'])

"""Independently validate every frozen two-hand closed-angle support certificate."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from flint import arb,ctx
from itertools import product
import argparse,json,gzip
from dual_bank import grid,q,det,U
Z=2**28
def verify(source,bank):
    raw=source.read_bytes()
    assert sha256(raw).hexdigest()=='45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05'
    obj=json.loads(raw);p=obj['points'];den=obj['denominator'];ctx.prec=160
    assert len(p)==11 and max((x-u)**2+(y-v)**2 for x,y in p for u,v in p)<=den**2
    b=json.loads(gzip.decompress(bank.read_bytes()) if bank.suffix=='.gz' else bank.read_bytes());k=b['knots'];g=grid()
    assert list(map(list,g))==b['directions'] and len(b['cells'])==2*k
    sn,cs=(arb.pi()/k).sin_cos();checked=0
    for j,records in enumerate(b['cells']):
        sj,cj=(arb.pi()*(2*(j%k)+1)/k).sin_cos()
        hand=1 if j<k else -1
        support={}
        def source_terms(i):
            if i not in support:
                a,b=g[i];u,v=a*cj+b*sj,-a*sj+b*cj
                vals=[(u*x+v*hand*y,v*x-u*hand*y) for x,y in p];support[i]=sorted(vals,key=lambda pair:float(pair[0].mid()),reverse=True)
            return support[i]
        assert records
        for rec in records:
            ids=rec[:3];ws=rec[3:6];total,low=rec[6:]
            assert all(type(z) is int for z in rec) and min(ws)>0 and sum(ws)==total
            assert all(sum(w*g[i][a] for w,i in zip(ws,ids))==0 for a in (0,1))
            terms=[source_terms(i) for i in ids]
            def confirms(pairs):
                A=sum(w*x for w,(x,y) in zip(ws,pairs));B=sum(w*y for w,(x,y) in zip(ws,pairs))
                return A>0 and (A*cs-abs(B)*sn)*Z>=low*total*den*U
            assert confirms([t[0] for t in terms]) or any(confirms(t) for t in product(*terms))
            checked+=1
    return checked
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('points',type=Path);p.add_argument('bank',type=Path);a=p.parse_args()
    assert __debug__;print(verify(a.points,a.bank))

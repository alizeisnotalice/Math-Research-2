"""Materialize the four homothetic rational clouds and bind the P66 alternate route."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from math import lcm
from pathlib import Path
from itertools import combinations
import json

p=ArgumentParser(description=__doc__)
for name in ("comp","ordinary","constants","out"):
    p.add_argument(name,type=Path)
a=p.parse_args()
v=json.loads(a.constants.read_bytes())
t=F(v["scale"])
names=dict(P128="p128",oldQ="physical-q",newQ="distinct-q",P15="p15")
groups={}
p128=None
for model,name in names.items():
    source=a.ordinary/"kit"/(name+".json")
    raw=source.read_bytes()
    r=v["radii_and_points"][model]
    assert sha256(raw).hexdigest()==r["input_sha256"]
    p=json.loads(raw)
    a0=tuple(map(F,r["center"]))
    before=[tuple(F(x,p["denominator"]) for x in row)for row in p["points"]]
    samples=[tuple(c+t*(x-c) for c,x in zip(a0,row,strict=True))for row in before]
    den=lcm(*(x.denominator for row in samples for x in row))
    points=[[int(den*x)for x in row]for row in samples]
    assert max(sum((x-u)**2 for x,u in zip(p,q,strict=True)) for p,q in combinations(points,2))<=den**2*t**2
    assert all(tuple(x/t-(1/t-1)*c for x,c in zip(q,a0,strict=True))==b
               for q,b in zip(samples,before,strict=True))
    groups[model]=dict(point_denominator=den,points=points,raw_cloud_sha256=r["input_sha256"],center=r["center"])
    if model=="P128":
        p128=set(before)
        center128=a0
        s128=set(samples)
p66=a.comp/"scaled-eight-50/p66.json"
old_raw=p66.read_bytes()
p=json.loads(old_raw)
old={tuple(F(x,p["denominator"])for x in row)for row in p["points"]}
assert len(old)==66 and old<p128
scaled={tuple(c+t*(x-c)for c,x in zip(center128,row,strict=True))for row in old}
assert scaled<s128
a.out.write_text(json.dumps(dict(scale=str(t),subset_P66=dict(old_sha256=sha256(old_raw).hexdigest(),
              proved_66_of_128_before_and_after=True),groups=groups),sort_keys=True,separators=(",",":"))+"\n")
print("exact centers, diameters, and subset (66 of 128)",sha256(a.out.read_bytes()).hexdigest())

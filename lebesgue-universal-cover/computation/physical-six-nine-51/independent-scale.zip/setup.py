"""Create the full fine-nine 501 disjunction at a true homothetic five-body floor."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

p=ArgumentParser(description=__doc__)
for k in ("comp","ordinary","fine","output"):
    p.add_argument(k,type=Path)
a=p.parse_args()
a.output.mkdir(exist_ok=True)
src=a.fine/"slice-nine-fine-p128.cpp"
bank=a.fine/"angular-nine-fine-p128.json"
driver=a.ordinary/"slice/run_slice.py"
def sha(p):return sha256(p.read_bytes()).hexdigest()
assert sha(bank)=="e849b308e0f32cfeef8423e5e23866e7e83b681807fb808d4c0b062bcf6d91d5"
mark="if(ret==1){++old;return true;}"
s=src.read_text()
assert s.count(mark)==1 and "refined[4]={18*CIRCLE,2*CIRCLE,8*CIRCLE,-1}" in s
s=s.replace(mark,"if(ret==1 || t.last>=120666927296517964LL){++old;return true;}")
(a.output/"scaled-nine.cpp").write_text(s)
mark="M=F('.83729500622102524');floor=(M*2*Z*Z).__floor__()"
s=driver.read_text()
assert s.count(mark)==1
baseline=int(120666927296517964*F(".999999006")**2)
s=s.replace(mark,f"floor={baseline}")
# Mesh gives all support walls; rerunning old endpoint nominals buys nothing.
l=s.index("    endpoints={}")
u=s.index("    dll=",l)
s=s[:l]+"    assert a.caps and a.mesh and not a.precontract\n    endpoints={k:ints([0]) for k in roots}\n"+s[u:]
(a.output/"scaled_driver.py").write_text(s)
loc=a.comp/"five-global-localization.json"
assert sha(loc)=="d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504"
keys=json.loads(loc.read_bytes())["retained"]
assert sum(map(len,keys.values()))==501
(a.output/"keys501.json").write_text(json.dumps(keys,separators=(",",":"))+"\n")
manifest=dict(original_cpp=sha(src),original_driver=sha(driver),source_bank=sha(bank),
              derived_cpp=sha(a.output/"scaled-nine.cpp"),derived_driver=sha(a.output/"scaled_driver.py"),
              keys_sha256=sha(a.output/"keys501.json"),baseline=baseline,
              goal=int(F(".83751")*2**57)+1,effect="add B0 material-or-goal stopping rule",
              point_groups=["P128","physical old Q","physical new Q","P15"])
(a.output/"native-inputs.json").write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
print(manifest)

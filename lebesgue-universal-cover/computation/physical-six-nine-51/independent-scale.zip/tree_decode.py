"""Decode archived Tomar closed roots by integer bisection."""
from fractions import Fraction as F
from hashlib import sha256
import json

import numpy as np

FINE=2**44

def sha(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def decode(tree, retained):
    manifest = (tree/"SHA256SUMS").read_bytes()
    assert sha(manifest) == "56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410"
    pins = dict((name.removeprefix("./"), digest)
                for digest, name in (row.split() for row in manifest.decode().splitlines()))
    refmeta = read(tree/"part0000.json")
    angles = [2,5,8]
    assert all(refmeta["lo"][j] == 0 for j in angles)
    for part, leaves in sorted((int(j), v) for j,v in retained.items()):
        h = tree/f"part{part:04}.json"
        t = h.with_suffix(".npy")
        assert sha(h.read_bytes()) == pins[h.name]
        assert sha(t.read_bytes()) == pins[t.name]
        meta = read(h)
        assert meta["part"] == part and meta["split0"] == [2]*11 and meta["ns"] == [3,5,7,9]
        assert meta["hi"] == refmeta["hi"] and meta["lo"] == refmeta["lo"]
        codes = np.load(t, allow_pickle=False)
        pre = np.r_[0, np.cumsum(np.where(codes<11, 1, -1))]
        assert len(codes) == meta["boxes"] and pre[-1] == -1
        root = [[F(lo)*FINE, F(hi)*FINE] for lo,hi in zip(meta["lo"],meta["hi"],strict=True)]
        assert all(z.denominator == 1 for axis in root for z in axis)
        root = [[int(l),int(h)] for l,h in root]
        for j in range(11):
            a,b = root[j]
            assert (a+b)%2 == 0
            root[j][1-((part>>(10-j))&1)] = (a+b)//2
        for leaf in sorted(leaves):
            ends = [v.copy() for v in root]
            i = 0
            while i!=leaf:
                axis = int(codes[i])
                a,b = ends[axis]
                assert 0<=axis<11 and (a+b)%2==0
                candidates = np.flatnonzero(pre[i+2:leaf+1]==pre[i])
                right = bool(len(candidates))
                ends[axis][1-right] = (a+b)//2
                i = i+2+int(candidates[0]) if right else i+1
            assert codes[i] >= 253
            yield (part,leaf), ends


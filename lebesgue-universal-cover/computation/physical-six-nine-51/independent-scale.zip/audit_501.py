"""Check original exceptional-root IDs, terminal conservation, and actual point use."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

p=ArgumentParser(description=__doc__)
for k in ("keys","calibration","fine_nine","output"):
    p.add_argument(k,type=Path)
a=p.parse_args()
KEYS=sorted((int(t),v)for t,vs in json.loads(a.keys.read_bytes()).items()for v in vs)
assert len(KEYS)==len(set(KEYS))==501
POINTS=("P128","oldQ","newQ","P15")

def audit(source,complete,point_limit,floor):
    raw=source.read_bytes()
    data=raw.splitlines()
    if raw and raw[-1]!=10:
        data=data[:-1]
    data=[json.loads(q) for q in data]
    assert 0<len(data)<=501
    assert [tuple(x["leaf"]) for x in data]==KEYS[:len(data)]
    totals=[0]*7
    failures=[]
    for row in data:
        assert F(row["target"])==F(".83751")
        ok,n,p,m,d=row["out"]
        actual=[row[x]for x in POINTS]
        assert m==sum(actual) and all(x==0 for x in actual[point_limit:])
        assert 0<=d<=110
        if ok:
            assert 2*(p+m)-1==n and row["front"] is None
        else:
            assert row["front"] is not None
            failures.append(row["leaf"])
        totals=[x+y for x,y in zip(totals,[n,p,m,*actual],strict=True)]
    if complete:
        assert len(data)==501 and not failures
    normalized=(json.dumps(data,sort_keys=True,separators=(",",":"))+"\n").encode()
    return dict(number_of_roots=len(data),failures=failures,visits=totals[0],
                material=totals[1],terminal_by_bank={k:v for k,v in zip(POINTS,totals[3:],strict=True)},
                underlying_baseline_integer=floor,
                raw_sha256=sha256(raw).hexdigest(),normalized_sha256=sha256(normalized).hexdigest())

x=dict(calibration_p66_old_q=audit(a.calibration,True,2,120666664242759821))
if a.fine_nine.is_file():
    x["independent_full_fine_nine"]=audit(a.fine_nine,False,4,120666687410785721)
a.output.write_text(json.dumps(x,sort_keys=True,indent=2)+"\n")
print(json.dumps(x))

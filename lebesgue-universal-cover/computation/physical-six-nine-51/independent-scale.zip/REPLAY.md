# .83751 一般九体缩率的复算

令 COMP 为主课题 computation 目录，TREE 为 Tomar cert11d_08366 原树，ORD 为独立 .83751 原九证书的工作目录，CAL 为校准工作目录。TABLE64、CACHE 取公开 64 级材料和 data 上的 Clang 缓存。PY 使用 Python 3.13.18、python-flint 0.9.0、NumPy 2.5.5。原九选择文件 theorem-083751-nine.json 的 SHA 为 6b99f08c697ac1ce944a896e78a0fa439c7bfc7ffdba9babe716693f6309c759。

~~~
"$PY" -I -B scale_constants.py "$COMP" "$TREE" "$ORD" \
  "$CAL/scale51/cloud-radii.json" scale-constants.json
"$PY" -I -B material_subset.py "$COMP" "$ORD" scale-constants.json scaled-nine-points.json
"$PY" -I -B bridge_sources.py "$ORD" "$CAL" source-bridge.json
~~~

主证书 501 原根用实际 .83751、P66 与物理旧 Q 两个点组，基准 120666664242759821。其 C++、driver、角库绑定规则见 source-bridge.json。BASE 指 CAL/seven-flex/direct-gauge/default-full，编出 BASE/native/nine.cpp 后用其 native/run_floor995.py：

~~~
"$PY" -B "$BASE/native/run_floor995.py" "$COMP" "$TREE" "$TABLE64" "$LIB_P66_Q" \
  "$BASE/native/bank.json" p66-oldq-501.jsonl \
  --index "$BASE/keys.json" --target .83751 --caps --mesh --workers 6 --cap 3000000
~~~

独立对照可按以下入口重生成全九原生组合。FINE 为实际 .83751 细 P128 的旧源及角库目录，旧角库 SHA e849b308e0f32cfeef8423e5e23866e7e83b681807fb808d4c0b062bcf6d91d5。需要时由 ORD/refine_p128.py 的 keep-nine 选项再现。TEMP_DIR 指用户指定的 data 编译临时目录。

~~~
"$PY" -I -B setup.py "$COMP" "$ORD" "$FINE" native
TMPDIR="$TEMP_DIR" clang++ -O3 -std=c++17 -ftrapv -fPIC -shared \
  -fmodules-cache-path="$CACHE" -I "$COMP/three-leaf-083750" \
  -I "$ORD/slice" -I "$ORD/kit" native/scaled-nine.cpp -o "$LIB_NINE"
PYTHONPATH="$ORD/slice:$ORD/kit" "$PY" -B native/scaled_driver.py "$COMP" "$TREE" \
  "$TABLE64" "$LIB_NINE" "$FINE/angular-nine-fine-p128.json" native/fine-nine-501.jsonl \
  --index native/keys501.json --target .83751 --caps --mesh --workers 3 --cap 2000000
~~~

两路线的冻结输出核对如下。P66 路线程序仍将第一个点槽命名为 P128，槽实际读取的是 P66 支撑银行。精确点包含由 material_subset.py 验证。

~~~
"$PY" -I -B audit_501.py native/keys501.json "$CAL/scale51/roots51.jsonl" \
  native/fine-nine-501.jsonl audit-501.json
~~~

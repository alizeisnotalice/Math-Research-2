"""Rational inward representatives for regular Reuleaux defining centers."""
from pathlib import Path
from flint import arb,ctx
from fractions import Fraction as F
import json
ctx.prec=192
base=Path(__file__).resolve().parent
Q=10**16;out={}
for n in (3,5,7,9):
 R=1/(2*(arb.pi()/(2*n)).cos());v=[]
 for j in range(n):
  y,x=(2*arb.pi()*j/n).sin_cos();v.append((R*x,R*y))
 S=arb(999999)/10**6; contracted=arb(99999900600)/99999912422
 ps=[tuple(int((t*S*Q).mid().floor().unique_fmpz()) for t in u) for u in v]
 for x,y in ps:
  assert all((arb(x)/Q-contracted*cx)**2+(arb(y)/Q-contracted*cy)**2<contracted**2 for cx,cy in v)
 out['R'+str(n)]=dict(denominator=Q,points=ps)
(base/'regular-vertex-subsets.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

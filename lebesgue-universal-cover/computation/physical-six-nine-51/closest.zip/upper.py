"""An exact rational independent placement of the two 11-point clouds and finite transfer."""
from pathlib import Path
from math import isqrt
from fractions import Fraction as F
from itertools import combinations
import json
base=Path(__file__).resolve().parent
def pts(f):
 d=json.loads((base/'inputs'/f).read_bytes());return [(F(x,d['denominator']),F(y,d['denominator'])) for x,y in d['points']]
a=pts('distinct-q.json');b=pts('physical-q.json');M=10**13
t=F(1446856208390,M);c=(t*t-1)/(t*t+1);s=-2*t/(t*t+1);tx=F(-4838462670692,M);ty=F(-1426986555732,M)
assert c*c+s*s==1
cloud=a+[(tx+c*x-s*y,ty+s*x+c*y) for x,y in b]
D2=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(cloud,2))
assert D2<F('1.000673064')**2
finite={}
for name in ['730','788','1931','1991']:
 d=json.loads((base/('factor-'+name+'.json')).read_bytes());beta2=F(d['alpha_squared'])*(F(d.get('s','1'))/F(d.get('curve_scale','1')))**2
 assert beta2*F('1.00067')**2>F('1.00066')**2 and beta2<1 and beta2*F('1.001')**2>F('1.000673064')**2
 finite[name]=str(beta2)
out={'relative_cos':str(c),'relative_sin':str(s),'relative_translation':[str(tx),str(ty)],'squared_union_diameter':str(D2),'upper':'1.000673064','finite_common_factor_squared':finite}
(base/'upper-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('old-Q/new-Q union diameter < 1.000673064; four finite families have pairwise union diameter > 1.00066')

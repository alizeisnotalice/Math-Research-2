from pathlib import Path
import json,shutil,subprocess,sys
a=Path(__file__).resolve().parent;o=Path(sys.argv[1]).resolve();o.mkdir(exist_ok=False);py=[sys.executable,'-B']
shutil.copytree(a/'inputs',o/'inputs')
for f in ['pairs.py','regular_vertices.py','disk_pairs.py','upper.py','cloud-radii.json','all-pair-cells.json.gz','finite51.py','finite_scaled.py']:shutil.copyfile(a/f,o/f)
for f in ['regular_vertices.py','disk_pairs.py','pairs.py']:subprocess.run(py+[str(o/f)],check=True)
for n,target in [(730,'.83750'),(788,'.83750'),(1931,'.83751'),(1991,'.8375101')]:
 d=o/('finite'+str(n));cmd=py+[str(o/('finite51.py' if n==788 else 'finite_scaled.py')),str(o/'inputs'),str(d)]
 if n!=788:cmd+=['--N',str(n),'--target',target]
 subprocess.run(cmd,check=True);rep=d/('finite788.json' if n==788 else 'finite-report.json')
 shutil.copyfile(rep,o/f'factor-{n}.json')
 x=json.loads(rep.read_bytes());y=json.loads((a/f'factor-{n}.json').read_bytes())
 for k in ['python','flint']:x.pop(k);y.pop(k)
 assert x==y
subprocess.run(py+[str(o/'upper.py')],check=True)
for f in ['regular-vertex-subsets.json','disk-pairs.json','roster-receipt.json','upper-receipt.json']:assert (o/f).read_bytes()==(a/f).read_bytes()
print('36 PAIRS; SAME UNIQUE CLOSEST CLOUD PAIR IN SIX ROSTERS; VERIFIED')

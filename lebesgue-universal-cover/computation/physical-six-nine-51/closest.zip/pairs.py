"""Exact covering of every relative angle by three-point circumradius obstructions."""
from pathlib import Path
from itertools import combinations
from math import isqrt
from fractions import Fraction as F
import json,gzip,sys
BASE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def norm2(p):return p[0]*p[0]+p[1]*p[1]
def sub(p,q):return (p[0]-q[0],p[1]-q[1])
def rot(c,s,q):
 for _ in range(q):c,s=-s,c
 return c,s
def prepare(d,e,q,j,K,h):
 # t in [j/K,(j+1)/K] in one quarter turn, t_mid=(2j+1)/(2K).
 mid=2*j+1;den=2*K
 c,s=rot(den*den-mid*mid,2*mid*den,q);z=den*den+mid*mid
 A=d['denominator'];B=e['denominator'];D=A*B*z
 def point(i,k):
  x,y=d['points'][i];u,v=e['points'][k];v*=h
  return (x*B*z-A*(c*u-s*v),y*B*z-A*(s*u+c*v))
 return point,D
def certify(d,e,q,j,K,h,triple):
 f,D=prepare(d,e,q,j,K,h);a,b,c=[f(i,k) for i,k in triple]
 x=sub(b,a);y=sub(c,a);w=sub(b,c);A,B,C=norm2(x),norm2(y),norm2(w)
 if min(A+B-C,A+C-B,B+C-A)<=0:return False
 det=x[0]*y[1]-x[1]*y[0]
 # A known rational enclosing radius for all four centers is <.54, so rotation changes
 # the aligned difference configuration by at most .54/K in Hausdorff distance.
 den=4*det*det*D*D;num=A*B*C
 if num*(50*K)**2<=den*(50*K+27)**2:return False
 return F(isqrt(num*10**24//den),10**12)-F(27,50*K)-1
def point_data():
 ds={n:read(BASE/'inputs'/p) for n,p in [('oldQ','physical-q.json'),('newQ','distinct-q.json'),('P15','p15.json'),('P128','p128.json')]}
 rr=read(BASE/'cloud-radii.json')
 for name,d in ds.items():
  cx,cy=map(F,rr[name]['center']);D=d['denominator']
  assert all((F(x,D)-cx)**2+(F(y,D)-cy)**2<F(27,50)**2 for x,y in d['points'])
 assert set(map(tuple,ds['P128']['points']))=={(x,-y) for x,y in ds['P128']['points']}
 rr=read(BASE/'regular-vertex-subsets.json')
 for label,reg in rr.items():
  if label!='R3':
   assert all(F(x*x+y*y,reg['denominator']**2)<F(27,50)**2 for x,y in reg['points'])
 return {**rr,**ds}
def verify(path):
 ds=point_data();ledger=json.loads(gzip.decompress(path.read_bytes()))
 wanted={a+'+'+b for a,b in combinations(ds,2)};assert set(ledger)==wanted
 summary={}
 for k,rows in ledger.items():
  a,b=k.split('+');buckets={};margins=[]
  for q,j,K,h,ids in rows:
   assert h in ([-1,1] if 'P128' not in (a,b) else [1]) and q in range(4) and K>0 and K&(K-1)==0 and 0<=j<K 
   gap=certify(ds[a],ds[b],q,j,K,h,ids);assert gap and gap>(F('0.00067') if (a,b)==('oldQ','newQ') else F('0.001'));margins.append(gap)
   buckets.setdefault((q,h),[]).append((F(j,K),F(j+1,K)))
  assert len(buckets)==(4 if 'P128' in (a,b) else 8)
  for vv in buckets.values():
   end=0
   for l,r in sorted(vv):assert l==end;end=r
   assert end==1
  summary[k]=dict(closed_angular_cells=len(rows),maximum_quarter_denominator=max(r[2] for r in rows),uniform_cross_diameter_excess_lower=str(min(margins)))
 assert min(F(r['uniform_cross_diameter_excess_lower']) for r in summary.values())>F('0.00067')
 (BASE/'roster-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(len(summary),sum(r['closed_angular_cells'] for r in summary.values()),float(min(F(r['uniform_cross_diameter_excess_lower']) for r in summary.values())))
if __name__=='__main__':verify(BASE/'all-pair-cells.json.gz')

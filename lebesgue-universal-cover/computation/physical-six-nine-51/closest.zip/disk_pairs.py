"""Three material points refute containment in any unit-diameter disk."""
import json
from itertools import combinations
from fractions import Fraction as F
from pathlib import Path
base=Path(__file__).resolve().parent
rr=json.loads((base/'cloud-radii.json').read_bytes());actual={}
ds=json.loads((base/'regular-vertex-subsets.json').read_bytes())
for k,v in [('P128','p128.json'),('oldQ','physical-q.json'),('newQ','distinct-q.json'),('P15','p15.json')]:ds[k]=json.loads((base/'inputs'/v).read_bytes())
for name,d in ds.items():
 p=d['points'];D=d['denominator'];cx,cy=map(F,rr.get(name,{'center':[0,0]})['center']);K=sorted(range(len(p)),key=lambda i:(F(p[i][0],D)-cx)**2+(F(p[i][1],D)-cy)**2,reverse=True)[:12]
 best=F(0);labels=None
 for a,b,c in combinations(K,3):
  x,y=p[b][0]-p[a][0],p[b][1]-p[a][1];u,v=p[c][0]-p[a][0],p[c][1]-p[a][1];A=x*x+y*y;B=u*u+v*v;C=(x-u)**2+(y-v)**2
  if min(A+B-C,A+C-B,B+C-A)<=0 or x*v-y*u==0:continue
  z=F(A*B*C,4*(x*v-y*u)**2*D*D)
  if z>best:labels=[a,b,c];best=z
 assert best>F('.50514')**2 and F('.50514')+F('.999999006')/(2*F('.99999912422'))>F('1.001')
 actual[name]=dict(indices=labels,circumradius_squared=str(best));print(name,labels,float(best)**.5)
(base/'disk-pairs.json').write_text(json.dumps(actual,indent=2)+'\n')

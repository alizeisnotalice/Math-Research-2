"""Audit the high pure-five localization and uniform pointwise support payments."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys

from flint import arb,ctx

sys.path.insert(0,str(Path(__file__).resolve().parent))
from tree_decode import decode

SIGMA=F(".999999006")
J=F(".999998915")
G=F(120697911165410052,2**57)
B=F(120666927296517964,2**57)
U=2**22
Q=2**28
FINE=2**44


def ar(v):
    r=F(v)
    return arb(r.numerator)/r.denominator


def sha(p):return sha256(p.read_bytes()).hexdigest()

def read(p):return json.loads(p.read_bytes())

def floorup_to(x,d):
    return F(int((x*d).upper().ceil().unique_fmpz()),d)

def floordown_to(x,d):
    return F(int((x*d).lower().floor().unique_fmpz()),d)


def centers(comp,tree,high):
    names=read(high)
    maxima=[(-1,None)]*4
    addresses=set()
    for w,box in decode(tree,names):
        addresses.add(f"{w[0]}/{w[1]}")
        for i in range(4):
            sq=sum(max(l*l,r*r) for l,r in box[i*3:i*3+2])
            if sq>maxima[i][0]:
                maxima[i]=sq,w
    assert len(addresses)==5954
    src=comp/"global-083750/records/retained.json"
    core={f"{p}/{q}" for p,rows in read(src).items() for q in rows}
    assert core<=addresses and len(core)==5442 and len(addresses-core)==512
    out=[]
    for n,(sq,w) in zip((3,5,7,9),maxima,strict=True):
        sq=F(sq,FINE**2)
        C=ar(sq).sqrt()
        r=1-1/(2*(arb.pi()/(2*n)).cos())
        best=max(floordown_to(r,10**15),floordown_to(arb(1)/2-C,10**15))
        assert C<arb(".033") and r>arb(".422")
        out.append(dict(n=n,root=list(w),center_radius_squared=str(sq),
                        center_radius_upper=str(floorup_to(C,10**15)),
                        old_support_retreat_rate=str(best)))
    rate=min(F(".5"),*(F(r["old_support_retreat_rate"]) for r in out))
    return out,rate,addresses,core


def clouds(ordinary,paid):
    c=read(paid)
    names={"P128":"p128","oldQ":"physical-q","newQ":"distinct-q","P15":"p15"}
    receipts={}
    points={}
    for typ,key in names.items():
        p=ordinary/"kit"/(key+".json")
        data=read(p)
        d=data["denominator"]
        actual=[(F(x,d),F(y,d))for x,y in data["points"]]
        px,py=map(F,c[typ]["center"])
        sq=max((x-px)**2+(y-py)**2 for x,y in actual)
        rsup=F(c[typ]["upper"])
        assert sq==F(c[typ]["radius2"])<rsup**2
        assert max((a-u)**2+(b-v)**2 for (a,b),(u,v) in combinations(actual,2))<=1
        receipts[typ]=dict(input_sha256=sha(p),count=len(actual),center=list(c[typ]["center"]),
                            actual_radius_squared=str(sq),radius=str(rsup))
        points[typ]=actual
    return receipts,points


def main():
    p=ArgumentParser(description=__doc__)
    for k in ("comp","tree","ordinary","calibration_radii","output"):
        p.add_argument(k,type=Path)
    a=p.parse_args()
    ctx.prec=256
    rank=a.ordinary/"stage4-audit51/retained.json"
    assert sha(rank)=="2b9bbb532b2aecb30c0f86fec1c2c0ac6a7b6c43c3ec94f80bd51bac393da8e9"
    out,rate,domain,core=centers(a.comp,a.tree,rank)
    theorem=a.ordinary/"theorem-083751-nine.json"
    th=read(theorem)
    assert th["complete_global"] and F(th["integer_area_numerator"],th["integer_area_denominator"])==G
    assert set(th["known_originals"])==core
    outside=read(a.ordinary/"exterior-083751-complete.json")
    oldQ=set(outside["those_requiring_physical_old_Q"])
    assert len(oldQ)==5 and oldQ <= domain-core and outside["reopened_new_outside_closed"]=={"pure-five":507,"physical-old-Q":5}
    loc=read(a.comp/"five-global-localization.json")
    exc={f"{a0}/{b0}" for a0,v in loc["retained"].items() for b0 in v}
    assert len(exc)==501 and exc<=core
    group_rec,pts=clouds(a.ordinary,a.calibration_radii)
    rmax=max(F(d["radius"])for d in group_rec.values())
    e=1-SIGMA
    on=1-e*rate/rmax
    s=F((on*10**11).__ceil__(),10**11)
    assert SIGMA<s<1 and (1-s)*rmax<e*rate
    for key,rec in group_rec.items():
        center=tuple(F(x)for x in rec["center"])
        compressed=[[c+s*(v-c)for c,v in zip(center,row,strict=True)]for row in pts[key]]
        rec["max_compressed_squared_diameter"]=str(max(sum((x-y)**2 for x,y in zip(u,v,strict=True))
                            for u,v in combinations(compressed,2)))
        assert F(rec["max_compressed_squared_diameter"])<=s**2
    eps=F(1)-SIGMA
    M=F(".033")
    f0=F(Q//5000,Q)
    b=F(U+2,U)*((SIGMA-J)*F(".62")+eps*M)
    corner=J*F(U,U+2)**2*f0/(J*f0+b)-F(1023,1024)
    r=ar(SIGMA/2); radius=F(".705"); R=ar(radius)
    radial_margin=(arb.pi()-(r/R).acos())*r*r+r*(R*R-r*r).sqrt()-ar(G)
    assert radial_margin>arb(0)
    assert radius+(1-s)*rmax<F(".706")
    assert arb(".706")<arb(2).sqrt()*r
    assert corner>0 and J*F(U,U+2)**2>F(1023,1024)
    assert SIGMA/(2*(U-2))>eps*(M+F(1,60))
    assert (SIGMA-J)*F(".422")>(1-J)*M
    assert J*J*F(".8373034")>B
    fb=int(SIGMA**2*B*2**57)
    prior=int(F(".99999891")**2*B*2**57)
    assert fb>prior and G-F(fb,2**57)<F(1,4000)
    below_previous_floor=B-SIGMA**2*F(".83729500622102525")
    assert below_previous_floor>0
    cert=dict(oriented_root_count=len(domain),high_root_file_sha256=sha(rank),target_nine_theorem_sha256=sha(theorem),
              ordinary_core_count=5442,outer_overlaps_q=len(oldQ),exceptional_roots=501,
              bounds=out,radii_and_points=group_rec,rate=str(rate),radius_max=str(rmax),
              sigma=str(SIGMA),j=str(J),scale=str(s),real_support_margin=str(e*rate-(1-s)*rmax),
              lower_diameter_scale_formula=str(on),use_501_floor=fb,older_floor=prior,
              floor_at_sigma_minus_older_ticks=fb-prior,chord_coefficient_margin=str(corner),
              reference_point_radius_upper=str(radius+(1-s)*rmax),
              radial_margin_at_705=radial_margin.str(60),
              true_five_minimum_is_below_B0_by_at_least=str(below_previous_floor),
              area_upper_budget_from_new_floor=str(G-F(fb,2**57)),
              conditional_area_lower=str(G/s**2),conditional_area_interval=ar(G/s**2).str(60))
    a.output.write_text(json.dumps(cert,sort_keys=True,indent=2)+"\n")
    print("rate",float(rate),"radius",float(rmax),"scale",float(s),"new floor",fb,flush=True)
    print("conditional",cert["conditional_area_interval"],flush=True)

if __name__=="__main__":
    main()

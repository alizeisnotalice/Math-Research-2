"""Replay the exact five-body exterior and resolve a selectable list of entire residual leaves."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from hashlib import sha256
import argparse,ctypes,json,sys,os
import numpy as np
from flint import arb,ctx
from dual_bank import grid,q,U
S=2**44;Z=2**28
def dig(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def ints(rows):return np.ascontiguousarray(rows,dtype=np.int64).ravel()
def run(a):
    sys.path.insert(0,str(a.comp.resolve()));ctx.prec=160
    from verify_tomar_fan_table import verified_table,PINNED_MANIFEST
    from certify_finite_point_leaf import upper_q
    from tomar_leaf_box import leaf_box
    c=a.comp;old=c/'five-global-localization.json';ext=c/'tomar-outer-083730-retained.json'
    assert dig(old)=='d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504'
    assert dig(ext)=='901f258d9a4ff75fa3cf3d788d487c2890b179e3c256ec813bb0c0845c7c7969'
    keys=sorted([(int(p),n) for p,ids in read(old)['retained'].items() for n in ids]+[(int(p),n) for p,ids in read(ext)['retained'].items() for n in ids])
    assert len(set(keys))==len(keys)==541
    A=F(a.target)
    if a.index:
        idx=read(a.index);keys=sorted((int(k),i) for k,vs in idx.items() for i in vs)
        assert len(keys)==len(set(keys))
    elif not a.only:assert A<=F('.83730')
    assert A<F('.838')
    if a.only:keys=[tuple(map(int,v.split('/'))) for v in a.only.split(',') if v]
    if a.resume:
        prev=[json.loads(line) for line in a.resume.read_text().splitlines()]
        assert [tuple(row['leaf']) for row in prev]==keys and all(F(row['target'])==A for row in prev)
        keys=[tuple(row['leaf']) for row in prev if not row['out'][0]]
    bank=read(a.bank);dirs=grid();assert bank['directions']==list(map(list,dirs))
    nc=len(bank['cells']);assert nc==2*bank['knots']
    ptr=ints([0]+list(np.cumsum([len(c) for c in bank['cells']])));rows=ints([r for v in bank['cells'] for r in v]);assert len(rows)==(10 if a.caps else 25)*ptr[-1]
    rad=q('.706');assert (arb.pi()-(q('.5')/rad).acos())/4+q('.5')*(rad*rad-q('.25')).sqrt()>q(A)
    floor=120666687410785721;goal=(A*2*Z*Z).__floor__()+1
    manifest=a.tree/'SHA256SUMS';assert dig(manifest)==PINNED_MANIFEST
    pin={name.removeprefix('./'):h for h,name in [l.split() for l in manifest.read_text().splitlines()]}
    h0=a.tree/'part0000.json';assert dig(h0)==pin[h0.name];head=read(h0)
    assert dig(a.table) in ('fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c','0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d')
    pts,cnt=verified_table(a.table,a.tree,head);pts=pts.ravel()
    orig=ints([(F(v)*S).__floor__() for v in head['hi']]);assert all(F(v)*S==k for v,k in zip(head['hi'],orig))
    roots={}
    for p in sorted(set(k[0] for k in keys)):
        hf=a.tree/f'part{p:04}.json';tf=hf.with_suffix('.npy');assert dig(hf)==pin[hf.name] and dig(tf)==pin[tf.name]
        meta=read(hf);co=np.load(tf,allow_pickle=False);pre=np.r_[1,1+np.cumsum(np.where(co<11,1,-1))]
        for _,pos in (k for k in keys if k[0]==p):
            cen,half=leaf_box(pre,co,p,pos,meta)
            ends=[(F(x)+sg*F(y))*S for sg in (-1,1) for x,y in zip(cen,half)]
            assert all(x.denominator==1 for x in ends)
            roots[p,pos]=(ints(ends[:11]),ints(ends[11:]))
    if a.frontiers:
        packets=read(a.frontiers)
        assert [tuple(map(int,x['leaf'].split('/'))) for x in packets]==keys
        actual={}
        for key,entry in zip(keys,packets):
            L,H=roots[key]
            addresses=[]
            for i,region in enumerate(entry['regions']):
                assert region['leaf']==entry['leaf']
                l=L.copy();h=H.copy()
                for step in region['steps']:
                    axis,side=divmod(step,2);assert 0<=axis<11
                    mid=(int(l[axis])+int(h[axis]))//2
                    assert (l[axis]+h[axis])%2==0 and l[axis]<mid<h[axis]
                    if side:l[axis]=mid
                    else:h[axis]=mid
                assert region['bounds']==np.column_stack((l,h)).tolist()
                actual[(*key,i)]=(l,h);addresses.append(tuple(region['steps']))
            for i,first in enumerate(entry['regions']):
                for second in entry['regions'][i+1:]:
                    assert any(h<=a or b<=l for (l,h),(a,b) in zip(first['bounds'],second['bounds'],strict=True))
        roots=actual;keys=list(roots)
    vectors=[(q(F(x,U)),q(F(y,U)),q(F(x*x+y*y,U*U)).sqrt()) for x,y in dirs];disk=ints([upper_q(length/2) for _,_,length in vectors]);ns=ints(dirs)
    @lru_cache(None)
    def nominal(n,v):
        halfcos=(arb.pi()/(2*n)).cos();r=1/(2*halfcos);assert r<q('.6')
        cs=[(q(F(v,S))+2*arb.pi()*i/n).sin_cos() for i in range(n)];out=[]
        for x,y,length in vectors:
            vals=[]
            for ss,cc in cs:
                pr=cc*x+ss*y;vals.append(r*pr)
                if not pr>-length*halfcos:vals.append(length+r*pr)
            out.append(max(upper_q(z) for z in vals))
        return out
    @lru_cache(None)
    def ends(n,l,h):
        err=(Z*F('.6')*F(h-l,S)**2*F(U+2,U)/8).__ceil__()
        return [v+err for t in (l,h) for v in nominal(n,t)]
    if a.precontract:
        assert a.caps and a.upstream and a.dynamic
        import subprocess
        assert subprocess.check_output(['git','-C',a.upstream,'rev-parse','HEAD'],text=True).strip()=='10af98606c98ca9ffd0d9f402cae1e2efe74b792'
        sys.path.insert(0,str(a.upstream.resolve()/'independent'))
        import gen11
        import tomar_dynamic_five as dyn
        dyn.configure(a.upstream,a.tree,a.dynamic,str(A));assert dyn.gen8.placements is gen11.placements
    assert a.caps and a.mesh and not a.precontract
    endpoints={k:ints([0]) for k in roots}
    dll=ctypes.CDLL(str(a.lib.resolve()));fn=dll.dynamic_guard_run if a.caps else dll.new_guard
    i64=np.ctypeslib.ndpointer(np.int64,ndim=1,flags='C_CONTIGUOUS');i32=np.ctypeslib.ndpointer(np.int32,ndim=1,flags='C_CONTIGUOUS')
    fn.argtypes=[i64]*3+[i32]*2+[ctypes.c_int64]*2+[i64]*5+[ctypes.c_int]*3+[i64]
    if a.caps:fn.argtypes=[i64]*3+[i32]*2+[ctypes.c_int64,ctypes.c_int,ctypes.c_int]+[i64]*5+[ctypes.c_int]*2+[i64,ctypes.c_int64]
    if a.mesh:
        from support_grid import make
        mesh=make()
        fn.argtypes=fn.argtypes+[i64]
    from disk_centers import rounded_centers
    assert a.caps and a.mesh
    fn.argtypes=fn.argtypes+[i64]
    tail=[floor,mesh,rounded_centers(orig)]
    def dry(key):
        lo,hi=roots[key];stack=[(lo,hi,0)];hits=[];done=[0,0,0,0,0];unclosed=[]
        while stack:
            l,h,depth=stack.pop()
            ok,axis,L,H,changed=dyn.contract(l,h,65)
            if ok:
                hits.append([depth,int(ok)]);continue
            if depth<a.precontract:
                weights=np.array([1,1,.163,1,1,.115,1,1,.089,1,1])
                eff=(H-L)*weights
                if ((h-l)*weights-eff).max()>max(1,.15*eff.max()):
                    stack.append((L,H,depth+1));hits.append([depth,4]);continue
                j=int(np.argmax(eff));m=(int(L[j])+int(H[j]))//2
                if (L[j]+H[j])%2==0 and L[j]<m<H[j]:
                    B=H.copy();B[j]=m;C=L.copy();C[j]=m
                    stack.extend([(C,H,depth+1),(L,B,depth+1)]);hits.append([depth,5]);continue
            # A conservative larger root with even angular coordinates at this
            # subbox is needed by the historical integer midpoint splitting loop.
            v=[]
            for n,j in ((3,None),(5,2),(7,5),(9,8)):
                x,y=(0,0) if j is None else (int(L[j]),int(H[j]))
                if j is not None and x==y:y=x+1
                v+=ends(n,x,y)
            # Root contraction coordinates may be odd. Expand to integer multiples
            # of 2^13 so that deep native closed-box bisection remains available.
            bn=2**13
            X=(L//bn)*bn;Y=((H+bn-1)//bn)*bn
            Y=np.maximum(Y,X+bn)
            v=[]
            for n,j in ((3,None),(5,2),(7,5),(9,8)):
                x,y=(0,0) if j is None else (int(X[j]),int(Y[j]));v+=ends(n,x,y)
            ret=np.zeros(33,np.int64)
            assert fn(X,Y,orig,pts,cnt,goal,110,a.cap,ns,disk,ints(v),ptr,rows,len(dirs),nc,ret,*tail)==0
            hits.append([depth,6,int(ret[0]),int(ret[1]),int(ret[2]),int(ret[3])])
            if not ret[0]:unclosed.append([L.tolist(),H.tolist()])
            else:assert ret[1]==2*(ret[2]+ret[3])-1
            done[1]+=int(ret[1]);done[2]+=int(ret[2]);done[3]+=int(ret[3]);done[4]=max(done[4],int(ret[4]))
        done[0]=int(not unclosed)
        return dict(leaf=key,target=str(A),out=done,front=unclosed,inner_dynamic=hits)
    def job(key):
        if a.precontract:return dry(key)
        lo,hi=roots[key];ret=np.zeros(33,np.int64)
        if a.caps:assert fn(lo,hi,orig,pts,cnt,goal,110,a.cap,ns,disk,endpoints[key],ptr,rows,len(dirs),nc,ret,*tail)==0
        else:assert fn(lo,hi,orig,pts,cnt,goal,floor,ns,disk,endpoints[key],ptr,rows,len(dirs),nc,a.cap,ret)==0
        assert not ret[0] or ret[1]==2*(ret[2]+ret[3])-1
        assert ret[3]==ret[5]+ret[6]+ret[29]+ret[30]
        return dict(leaf=key,target=str(A),out=ret[:5].tolist(),P128=int(ret[5]),oldQ=int(ret[6]),newQ=int(ret[29]),P15=int(ret[30]),shared=int(ret[31]),curved=int(ret[32]),front=None if ret[0] else ret[7:29].tolist())
    with ThreadPoolExecutor(a.workers) as ex,a.output.open('w') as f:
        for i,v in enumerate(ex.map(job,keys)):
            f.write(json.dumps(v,separators=(',',':'))+'\n');f.flush()
            if i%50==0:print(i,len(keys),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for x in ('comp','tree','table','lib','bank','output'):p.add_argument(x,type=Path)
    p.add_argument('--frontiers',type=Path);p.add_argument('--precontract',type=int,default=0);p.add_argument('--upstream',type=Path);p.add_argument('--dynamic',type=Path);p.add_argument('--mesh',action='store_true');p.add_argument('--caps',action='store_true');p.add_argument('--target',default='.83730');p.add_argument('--only');p.add_argument('--index',type=Path);p.add_argument('--resume',type=Path);p.add_argument('--workers',type=int,default=4);p.add_argument('--cap',type=int,default=32767)
    a=p.parse_args();assert __debug__;run(a)

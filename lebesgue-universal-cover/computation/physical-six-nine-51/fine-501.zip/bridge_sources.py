"""Bind source memberships and reusable cap interfaces for the .83751 original nine."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json

p=ArgumentParser(description=__doc__)
for k in ("ordinary","calibration","out"):
    p.add_argument(k,type=Path)
a=p.parse_args()

def sha(b):return sha256(b).hexdigest()


root=a.ordinary
claim=json.loads((root/"theorem-083751-nine.json").read_bytes())
pool={
 "2348":"mac-core51/final-2348-audit.json",
 "742":"local01-prefix-transfer/prefix-final742-audit.json",
 "951":"local01-prefix-transfer/other951-final-audit.json",
 "1401":"local01-prefix-transfer/south-final1401-audit.json",
}
known=set(claim["known_originals"])
joined=set()
family=Counter()
for count,filename in pool.items():
    f=root/filename
    digest=sha(f.read_bytes())
    assert any(q["sha256"]==digest and q["closed"]==int(count) for q in claim["core_sources"])
    leaves={q for q,v in claim["known_originals"].items() if v["source_sha256"]==digest}
    assert len(leaves)==int(count) and not (joined&leaves)
    joined|=leaves
    for leaf in leaves:
        tags=claim["known_originals"][leaf]["families"]
        assert set(tags)<={"P128","oldQ","newQ","P15"}
        family.update(tags)
assert joined==known and len(joined)==5442

arc="affine-nine-083751-kernels-benchmark.zip"
with ZipFile(root/arc) as z:
    copies={k:z.read(k) for k in ("anchor-nine.cpp","affine-nine.cpp")}
copies["slice.cpp"]=(root/"slice/slice.cpp").read_bytes()
with ZipFile(root/"mac-core51/core2348-complete-083751.zip") as z:
    copies["ordinary-control.cpp"]=z.read("ordinary-control.cpp")
for name,b in copies.items():
    assert b'e>W(Scale)/4000' in b
    assert b'B=up_signed(W(b)*U,(U-2)*(Q/C))' in b
    assert b'up_signed(W(d)*(U+2),U)' in b
    assert b'W(4)*sum*sum-C2' in b
    if name=="ordinary-control.cpp":
        assert b'const int families=2;' in b
        assert b'(arc<=23)' in b and b'for(int offset: {7,8,9})' in b
        assert b'up_signed(W(707107)*r,1000000)' in b
    else:
        assert b'for(int f=0;f<4;++f)' in b
    assert any(k in b for k in (b'disk_chord_support.hpp',b'slice_support.hpp',b'long_edge_support.hpp'))

cal=a.calibration/"seven-flex/direct-gauge/default-full"
rec={}
for name,pinned in [
    ("run_floor995.py","920ec3fb4ecd3070675411d926603cea973d183a052bc5edfe1b997e21c9881b"),
    ("nine.cpp","4cdc9342725b105bf63d29b8dcdd4a6e600c65ea37fb8b7585d259dabd4b7df9"),
    ("bank.json","ead43afb275a93d7ae8de12ef61beb976f8de24b449b1885b883481b0ad8deb9")
]:
    raw=(cal/"native"/name).read_bytes()
    assert sha(raw)==pinned
    rec[name]=pinned
code=(cal/"native/run_floor995.py").read_bytes()
native=(cal/"native/nine.cpp").read_bytes()
assert b"floor=(120666927296517964*F('.99999891')**2).__floor__()" in code
assert b"goal=(A*2*Z*Z).__floor__()+1" in code
assert b"if(ret==1 || t.last>=120666927296517964LL)" in native
assert b"for(int f=0;f<2;++f)" in native
directions=json.loads((cal/"native/bank.json").read_bytes())["directions"]
assert len(directions)==256
u=2**22
norms=[x*x+y*y for x,y in directions]
norm_margin_lower=min(norms)-(u-1)**2
norm_margin_upper=(u+2)**2-max(norms)
assert norm_margin_lower>0 and norm_margin_upper>0
sector=[[directions[(16*j+k)%256] for k in range(-23,24)] for j in range(16)]
dots=[sum(x*y for x,y in zip(u,v,strict=True))
      for i in range(16) for j in (7,8,9)
      for u in sector[i] for v in sector[(i+j)%16]]
assert max(dots)<0
assert F(707107,1000000)**2>F(1,2)
summary=dict(joint_plan_sha256=sha((root/"theorem-083751-nine.json").read_bytes()),old_core=len(joined),
             optional_terminal_families=family,active_caps_source_sha256={k:sha(v)for k,v in copies.items()},
             alternative_native_inputs=rec,alternative_501_floor=120666664242759821,
             direction_sq_lower_margin=norm_margin_lower,direction_sq_upper_margin=norm_margin_upper,
             disjoint_half_budget_normal_pairs=len(dots),max_raw_pair_dot=max(dots))
a.out.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
print(summary)

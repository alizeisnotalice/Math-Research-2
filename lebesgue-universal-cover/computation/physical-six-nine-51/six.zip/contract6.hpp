// A feasible placement of doubled area <G must satisfy every valid ancestral affine wall <G.
// Shrink its rectangular enclosure with outward integer rounding. The discarded slabs already have area >=G.
bool cut_interval(const AreaLine& wall,Box& lo,Box& hi,W goal,bool& changed){
    if(!wall.valid)return true;
    W slack=goal-wall.minimum(lo,hi);
    if(slack<=0)return false;
    for(int j=0;j<11;j++){
        W g=wall.slope[j],d=g>=0?g:-g;
        if(!d||slack>=d*(hi[j]-lo[j]))continue;
        L steps=L(slack/d+(slack%d!=0));
        if(g>0){
            L h=lo[j]+steps;
            if(h<hi[j]){hi[j]=h;changed=true;}
        }else{
            L l=hi[j]-steps;
            if(l>lo[j]){lo[j]=l;changed=true;}
        }
    }
    return true;
}

// Numerical small simplex proposes dual weights and another nominal pose. Only the exact
// integral weighted area plane and recomputed material can terminate a closed node.
bool primal_dual_cut(AreaLine& point,const AreaLine* const* pool,int count,
                     const Box& lo,const Box& hi,W& best,Box& trial_anchor) {
    constexpr int active=36, rows=12, width=active+11+rows+1;
    if(!point.valid||count<6)return false;
    Box corner;
    for(int j=0;j<11;j++)corner[j]=point.slope[j]>=0?lo[j]:hi[j];
    std::array<std::pair<W,int>,384> ranking;
    if(count>383)std::abort();
    for(int k=0;k<count;k++)ranking[k]={line_at(*pool[k],corner),k};
    int m=std::min(count,active-1);
    std::partial_sort(ranking.begin(),ranking.begin()+m,ranking.begin()+count,
                      [](const auto& x,const auto& y){return x.first>y.first;});
    const AreaLine* selected[active];selected[0]=&point;
    for(int k=0;k<m;k++)selected[k+1]=pool[ranking[k].second];
    ++m;const int sl=m+11,end=sl+rows;
    double tab[rows+1][width]{};int basis[rows];
    // max sum lambda (1+normalized plane at lower corner)-sum s[j],
    // subject to sum lambda<=1 and -sum B[j]*lambda-s[j]<=0.
    W scale=W(2)*Q*Q*line_den/10000;
    for(int k=0;k<m;k++){
        const auto& a=*selected[k];W lower=line_at(a,lo);
        tab[0][k]=1;tab[rows][k]=1+double(lower-best)/double(scale);
        for(int j=0;j<11;j++)tab[j+1][k]=-double(a.slope[j]*(hi[j]-lo[j]))/double(scale);
    }
    tab[0][end]=1;
    for(int i=0;i<rows;i++){basis[i]=sl+i;tab[i][sl+i]=1;}
    for(int j=0;j<11;j++){tab[j+1][m+j]=-1;tab[rows][m+j]=-1;}
    for(int iter=0;iter<80;iter++){
        int enter=-1;double cost=1e-8;
        for(int j=0;j<end;j++)if(tab[rows][j]>cost){cost=tab[rows][j];enter=j;}
        if(enter<0)break;
        int leave=-1;double ratio=1e200;
        for(int i=0;i<rows;i++)if(tab[i][enter]>1e-10){
            double candidate=std::max(0.,tab[i][end])/tab[i][enter];
            if(candidate<ratio-1e-12||(std::abs(candidate-ratio)<1e-12&&(leave<0||basis[i]<basis[leave]))){
                ratio=candidate;leave=i;
            }
        }
        if(leave<0)break;
        double pivot=tab[leave][enter];for(int j=0;j<=end;j++)tab[leave][j]/=pivot;
        for(int i=0;i<=rows;i++)if(i!=leave){
            double coef=tab[i][enter];if(coef==0)continue;
            for(int j=0;j<=end;j++)tab[i][j]-=coef*tab[leave][j];
        }
        basis[leave]=enter;
    }
    for(int j=0;j<11;j++){
        double y=-tab[rows][sl+j+1];
        if(!std::isfinite(y))return false;
        y=std::clamp(y,0.,1.);
        L ticks=L(std::round(y*1024));
        trial_anchor[j]=lo[j]+L(W(hi[j]-lo[j])*ticks/1024);
    }
    AreaLine mix{};L total=0;
    for(int i=0;i<rows;i++)if(basis[i]<m){
        double y=tab[i][end];
        if(!std::isfinite(y))return false;
        int w=int(std::round(std::clamp(y,0.,1.)*4096));if(!w)continue;
        const auto& a=*selected[basis[i]];total+=w;mix.offset+=w*a.offset;
        for(int j=0;j<11;j++)mix.slope[j]+=w*a.slope[j];
    }
    if(!total)return false;
    mix.offset=mix.offset/total-1;
    for(int j=0;j<11;j++){
        mix.slope[j]/=total;mix.offset-=std::max(std::abs(lo[j]),std::abs(hi[j]));
    }
    mix.valid=true;W lower=mix.minimum(lo,hi);
    if(lower>best){point=mix;best=lower;}
    return true;
}

// Affine lower supports to twice the five-body hull area throughout an ancestral closed box.
// Fine*1024 also clears the exact denominator of the tabulated nominal rotation.
constexpr W line_den=W(Fine)*1024;
struct AreaLine {
    W offset=0;
    std::array<W,11> slope{};
    bool valid=false;
    W minimum(const Box& lo,const Box& hi) const {
        W z=offset;
        for(int j=0;j<11;j++)z+=slope[j]*(slope[j]>=0?lo[j]:hi[j]);
        return z;
    }
};
W mix_min(const AreaLine& a,const AreaLine& b,int weight,const Box& lo,const Box& hi){
    W value=a.offset*weight+b.offset*(256-weight);
    for(int j=0;j<11;j++){
        W g=a.slope[j]*weight+b.slope[j]*(256-weight);
        value+=g*(g>=0?lo[j]:hi[j]);
    }
    return value>=0 ? value/256 : -((-value+255)/256);
}
W pair_min(const AreaLine& a,const AreaLine& b,const Box& lo,const Box& hi,W best){
    for(int j=0;j<11;j++){
        W x=a.slope[j],y=b.slope[j];
        if(!(x<0&&y>0) && !(x>0&&y<0))continue;
        int w=int((-256*y)/(x-y));
        for(int v:{w,w+1})if(v>0&&v<256)best=std::max(best,mix_min(a,b,v,lo,hi));
    }
    return best;
}

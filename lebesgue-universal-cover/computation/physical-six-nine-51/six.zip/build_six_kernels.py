"""Build precisely the native six-input kernels used by a frozen forest."""
import argparse,gzip,json,shlex,subprocess
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('forest',type=Path);p.add_argument('output',type=Path);p.add_argument('--cxx',default='c++');p.add_argument('--extra',default='');a=p.parse_args()
    src=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    d=json.loads(gzip.decompress(a.forest.read_bytes()))
    for method in sorted({m['method'] for m in d['packets'].values()}):
        stem='slice' if method=='slice' else method+'6';f=out/(stem+'.o')
        subprocess.run([a.cxx,'-O3','-std=c++17','-fPIC','-ftrapv',*shlex.split(a.extra),'-I',src,'-c',src/(stem+'.cpp'),'-o',f],check=True)
        subprocess.run([a.cxx,'-shared',f,'-o',out/(stem+'.dylib')],check=True)
if __name__=='__main__':main()

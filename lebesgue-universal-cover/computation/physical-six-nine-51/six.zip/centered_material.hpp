// Centered rotation proposals are implemented by rigorous integer approximants.
// Rounding is symmetric, with an error at most one half of one coordinate tick.
constexpr L Trig=L(1)<<30;
L round_nearest(W n,W d){
    if(d<=0)std::abort();
    return n>=0?L((n+d/2)/d):-L((-n+d/2)/d);
}
void rotate_material(L& x,L& y,L s,L c){
    // A body with inradius 2/5 gains 3.2 inward Q-grid ticks under this homothety.
    L a=x-round_nearest(8*W(x),Q), b=y-round_nearest(8*W(y),Q);
    x=round_nearest(W(c)*a-W(s)*b,Trig);
    y=round_nearest(W(s)*a+W(c)*b,Trig);
}

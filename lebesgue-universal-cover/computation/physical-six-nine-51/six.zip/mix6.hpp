W line_at(const AreaLine& line,const Box& position){
    W v=line.offset;
    for(int j=0;j<11;j++)v+=line.slope[j]*position[j];
    return v;
}
AreaLine normalized_mix(const AreaLine& a,const AreaLine& b,int w,const Box& lo,const Box& hi){
    AreaLine out;out.valid=true;
    out.offset=(w*a.offset+(256-w)*b.offset)/256-1;
    for(int j=0;j<11;j++){
        out.slope[j]=(w*a.slope[j]+(256-w)*b.slope[j])/256;
        // Truncation of a slope is smaller than one at this common scale.
        out.offset-=std::max(std::abs(lo[j]),std::abs(hi[j]));
    }
    return out;
}
bool improve_mix(AreaLine& point,const AreaLine& other,const Box& lo,const Box& hi,W& best){
    int chosen=0;W bound=best;
    for(int j=0;j<11;j++){
        W x=point.slope[j],y=other.slope[j];
        if(!(x<0&&y>0) && !(x>0&&y<0))continue;
        int w=int((-256*y)/(x-y));
        for(int v:{w,w+1})if(v>0&&v<256){
            W estimate=mix_min(point,other,v,lo,hi);
            if(estimate>bound){bound=estimate;chosen=v;}
        }
    }
    if(!chosen)return false;
    AreaLine mixed=normalized_mix(point,other,chosen,lo,hi);
    W m=mixed.minimum(lo,hi);
    if(m<=best)return false;
    best=m;point=mixed;return true;
}

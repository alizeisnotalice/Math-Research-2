"""Enclose every defining unit-disk center at each row angle in two integer coordinate units."""
from fractions import Fraction
import numpy as np
from flint import arb,ctx

def rounded_centers(original_upper):
    ctx.prec=160
    def ball(value):
        return arb(value.numerator)/value.denominator
    q=2**28
    table=np.empty((1025,24,2),dtype=np.int64)
    pos=0
    for order,k in [(3,None),(5,2),(7,5),(9,8)]:
        radius=q/(2*(arb.pi()/(2*order)).cos())
        last=Fraction(0) if k is None else Fraction(int(original_upper[k]),2**44)
        for row in range(1025 if k is not None else 1):
            angle=ball(last*row/1024)
            for j in range(order):
                sn,cs=(angle+2*arb.pi()*j/order).sin_cos()
                for axis,num in enumerate([radius*cs,radius*sn]):
                    z=round(float(num.mid()))
                    assert num>z-1 and num<z+1
                    table[row,pos+j,axis]=z
        if k is None:table[:,pos:pos+order]=table[0,pos:pos+order]
        pos+=order
    return table.ravel()

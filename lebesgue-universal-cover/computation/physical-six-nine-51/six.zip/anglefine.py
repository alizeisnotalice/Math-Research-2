"""Pure five-curve native proof on a shifted, locally refined grid of material rotations."""
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from fractions import Fraction as F
import argparse,ctypes,hashlib,json,sys
import numpy as np
from flint import arb,ctx
Q=2**28;S=2**44;T=2**30

def ar(x):x=F(x);return arb(x.numerator)/x.denominator

def base(comp):
    sys.path.insert(0,str(comp.resolve()));from certify_nine import arc_body,append_point,S as den
    assert hashlib.sha256((comp/'certify_nine.py').read_bytes()).hexdigest()=='610e94cf22e901453bc34f77afb8f0994d9e471432cbe20498fca3b1530c9541'
    ctx.prec=160;pi=arb.pi();ret=[]
    for n,k in [(0,1024),(3,128),(5,128),(7,128),(9,112)]:
        pts=[]
        if n:
            assert 1-1/(2*(pi/(2*n)).cos())>ar('.4') and 1/(2*(pi/(2*n)).cos())<ar('.6')
            arc_body(pts,k,pi,n,arb(0),arb(0),arb(0))
        else:
            for j in range(k):
                s,c=(2*pi*j/k).sin_cos();append_point(pts,c/2,s/2)
        pts=list(dict.fromkeys(pts))
        out=np.array([[round(F(x*(Q-10),den)) for x in v] for v in pts],np.int64)
        assert len(out)<=1024 and np.max(np.abs(out))<Q
        ret.append(out)
    # Exact true scaled material has an inward Euclidean margin >= (2/5)*10 grid ticks.
    # From the unscaled arc samples to base points: sqrt(2)*Q/1e12+sqrt(2)/2 ticks.
    # From base through the rotation rounded on 2^30 and final int round: <=2 Q/2^30+sqrt(2)/2 ticks.
    assert arb(2).sqrt()*(ar(F(Q,den))+1)+ar(F(2*Q,T))<4
    return ret

def rounded(x):return int((x+ar(F(1,2))).floor().unique_fmpz())

def material(pts,low,high):
    counts=np.array(list(map(len,pts)),np.int32);table=np.empty((1025,sum(counts),2),np.int32);pos=0
    for b,p in enumerate(pts):
        n=len(p);B=table[:,pos:pos+n];pos+=n
        if b<2:B[:]=p;continue
        axis=3*b-4;lo=int(low[axis]);span=int(high[axis])-lo
        assert span>0
        c=[];s=[]
        for j in range(1025):
            S0,C0=ar(F(1024*lo+j*span,1024*S)).sin_cos();c.append(rounded(C0*T));s.append(rounded(S0*T))
        c=np.array(c,np.int64)[:,None];s=np.array(s,np.int64)[:,None]
        x,y=p.T
        # Every numerator has absolute value <2*Q*T, inside signed int64.
        B[:,:,0]=(c*x-s*y+T//2)//T;B[:,:,1]=(s*x+c*y+T//2)//T
    return table.ravel(),counts

def run(a):
    pts=base(a.comp);D=ctypes.CDLL(str(a.lib.resolve()));fn=D.dynamic_guard_run
    l=np.ctypeslib.ndpointer(np.int64,ndim=1,flags='C_CONTIGUOUS');i=np.ctypeslib.ndpointer(np.int32,ndim=1,flags='C_CONTIGUOUS')
    fn.argtypes=[l]*3+[i]*2+[ctypes.c_int64,ctypes.c_int,ctypes.c_int]+[l]*5+[ctypes.c_int]*2+[l,ctypes.c_int64,l,l];fn.restype=ctypes.c_int
    zeros=np.zeros(1,np.int64);goal=int(F(a.target)*2**57)+1
    with a.output.open('w') as stream:
        for g in json.loads(a.input.read_bytes()):
            key=g['leaf'];rr=g['regions'];B=np.array([r['bounds'] for r in rr],np.int64)
            if 'window' in g:low,high=map(lambda x:np.array(x,np.int64),g['window'])
            else:low=B[:,:,0].min(axis=0);high=B[:,:,1].max(axis=0)
            assert np.all(low<=B[:,:,0]) and np.all(high>=B[:,:,1]);window=[low.tolist(),high.tolist()]
            table,counts=material(pts,low,high);shift=np.zeros(11,np.int64);orig=np.full(11,S//2,np.int64)
            for ax in [2,5,8]:shift[ax]=low[ax];orig[ax]=high[ax]-low[ax]
            def solve(item):
                j,reg=item;bounds=np.array(reg['bounds'],np.int64)
                L=bounds[:,0]-shift;H=bounds[:,1]-shift;ret=np.zeros(33,np.int64)
                assert fn(L,H,orig,table,counts,goal,a.depth,a.cap,zeros,zeros,zeros,zeros,zeros,256,6912,ret,0,zeros,zeros)==0
                assert ret[3]==ret[5]==ret[6]==ret[29]==ret[30]==0
                assert not ret[0] or ret[1]==2*ret[2]-1
                front=None if ret[0] else [*(ret[7:18]+shift).tolist(),*(ret[18:29]+shift).tolist()]
                return dict(leaf=[*map(int,key.split('/')),j],target=str(F(a.target)),out=ret[:5].tolist(),front=front,P128=0,oldQ=0,newQ=0,P15=0,shared=0,curved=0,window=window)
            with ThreadPoolExecutor(a.workers) as ex:
                for row in ex.map(solve,enumerate(rr)):stream.write(json.dumps(row,separators=(',',':'))+'\n');stream.flush()
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ['comp','lib','input','output']:p.add_argument(k,type=Path)
    p.add_argument('--depth',type=int,default=110);p.add_argument('--target',default='.83750');p.add_argument('--cap',type=int,default=131071);p.add_argument('--workers',type=int,default=3);run(p.parse_args())

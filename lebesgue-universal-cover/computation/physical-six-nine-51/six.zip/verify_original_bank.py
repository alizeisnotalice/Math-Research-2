"""Recompute the native angular guards directly from the historical rational point cloud."""
from hashlib import sha256
from pathlib import Path
import argparse,json
from fractions import Fraction as F
import numpy as np
from flint import arb,ctx

def main():
    p=argparse.ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('bank',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    f=a.comp/'finite-point-leaf-input.json';assert sha256(f.read_bytes()).hexdigest()=='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
    data=json.loads(f.read_bytes());P=np.array(data['points'],dtype=np.int64);D=data['denominator']
    assert len(P)==30 and set(map(tuple,P))=={(int(x),-int(y)) for x,y in P}
    assert max((int(x)-int(u))**2+(int(y)-int(v))**2 for x,y in P for u,v in P)<=D*D
    b=json.loads(a.bank.read_bytes());from dual_bank import grid
    assert b['directions']==list(map(list,grid()));d=np.array(b['directions']);cells=b['cells'];Q=2**28;U=2**22
    assert len(cells)==6912 and all(not r for r in cells[:384]+cells[2304:])
    ctx.prec=192;checked=0
    for K,off in [(384,384),(1536,768)]:
        l=arb(0).sin_cos()
        for j in range(K):
            r=(2*arb.pi()*(j+1)/K).sin_cos();sn,cs=((2*j+1)*arb.pi()/K).sin_cos();s,c=float(sn.mid()),float(cs.mid())
            ids=(d@(P@np.array([[c,s],[-s,c]])).T).argmax(axis=1);hs={}
            for row in cells[off+j]:
                assert len(row)==10
                js,w=row[:3],row[3:6];den=row[6]
                assert all(0<=i<256 for i in js) and len(set(js))==3 and min(w)>0 and sum(w)==den
                assert all(sum(weight*int(d[i,ax]) for weight,i in zip(w,js))==0 for ax in range(2))
                for i in js:
                    if i in hs:continue
                    x,y=map(int,P[ids[i]]);nx,ny=map(int,d[i])
                    hs[i]=[(nx*x+ny*y)*C+(ny*x-nx*y)*S for S,C in [l,r]]
                for h in range(2):
                    val=sum(weight*hs[i][h] for i,weight in zip(js,w))*Q/(D*U*den)
                    assert row[8+h]==int(val.lower().floor().unique_fmpz())
                assert row[7]==min(row[8:]) and row[7]>0
                checked+=1
            l=r
    result=dict(historical_P30_sha256=sha256(f.read_bytes()).hexdigest(),angular_bank_sha256=sha256(a.bank.read_bytes()).hexdigest(),direction_count=256,angular_cells=[384,1536],positive_balances=checked,other_point_slots_empty=True,reflected_cloud_identical=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()

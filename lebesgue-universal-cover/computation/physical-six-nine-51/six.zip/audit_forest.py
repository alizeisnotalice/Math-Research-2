"""Check the physical six-input proof forest against source tree roots, ancestral receipts and true DFS siblings."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter
from functools import lru_cache
from hashlib import sha256
import argparse,gzip,json,sys,subprocess
import numpy as np

def read(p):return json.loads(p.read_bytes())
def dig(p):return sha256(p.read_bytes()).hexdigest()
def boxes_from(base,steps):
    b=[v[:] for v in base]
    for s in steps:
        axis,side=divmod(s,2);assert 0<=axis<11
        lo,hi=b[axis];assert lo<hi and not (lo+hi)%2
        b[axis][1-side]=(lo+hi)//2
    return b

def main():
    p=argparse.ArgumentParser()
    for k in ['comp','tree','r248','r6','seven','forest','scores']:p.add_argument(k,type=Path)
    p.add_argument('--merged45',type=Path,required=True);p.add_argument('--native',action='store_true');p.add_argument('--src',type=Path,default=Path('.'))
    for k in ['table','bank','libdir','scratch','field']:p.add_argument('--'+k,type=Path)
    p.add_argument('--only');p.add_argument('--source');p.add_argument('--limit',type=int,default=0);p.add_argument('--workers',type=int,default=3);a=p.parse_args()
    sys.path.insert(0,str(a.comp.resolve()));from tomar_leaf_box import leaf_box
    D=json.loads(gzip.decompress(a.forest.read_bytes()));target=F(D['target']);assert target in (F('.83748'),F('.83750')) and D['integer_goal']==int(target*2**57)+1 and D['root_count']==5442
    assert D['sources']==dict(r6=dig(a.r6),original_seven_selection=dig(a.seven))
    assert D['floor_sha256']==dig(a.scores)
    floors=read(a.scores)['scores'];agr=read(a.comp/'global-083750/records/merged45-report.json')
    Z={int(p):(n,ps,fs) for p,n,ps,fs in agr['rows']}
    for pt in sorted({int(k.split('/')[0]) for k in floors}):
        with np.load(a.merged45/f'part{pt:04}.npz',allow_pickle=False) as archive:
            pos=archive['pos'];full=archive['full_floor']
        n,ps,fs=Z[pt];assert len(pos)==len(full)==n and sha256(pos.tobytes()).hexdigest()==ps and sha256(full.tobytes()).hexdigest()==fs
        for k in (k for k in floors if k.startswith(str(pt)+'/')):
            j=int(k.split('/')[1]);ix=np.searchsorted(pos,j);assert pos[ix]==j and full[ix]==floors[k]

    selected=json.loads(gzip.decompress(a.seven.read_bytes()));allroots=set(selected)
    fewer=set(read(a.r6)['focal']['six_P30']['thresholds']['.83750']['unresolved'])
    missing=fewer&{k for k,v in selected.items() if 'physical_old_Q11' in v[2]}
    assert len(allroots)==5442 and len(allroots-missing)==D['baseline'] and set(D['roots'])|set(D['open'])==missing and not set(D['roots'])&set(D['open'])
    per=read(a.comp/'global-083750/records/retained.json');perkeys={f'{p}/{i}' for p,ids in per.items() for i in ids};assert perkeys==allroots
    manifest=a.tree/'SHA256SUMS';from verify_tomar_fan_table import PINNED_MANIFEST
    assert dig(manifest)==PINNED_MANIFEST;pin={name.removeprefix('./'):h for h,name in [l.split() for l in manifest.read_text().splitlines()]}
    @lru_cache(None)
    def part(p):
        h=a.tree/f'part{p:04}.json';f=h.with_suffix('.npy')
        assert dig(h)==pin[h.name] and dig(f)==pin[f.name]
        c=np.load(f,allow_pickle=False);return np.r_[1,1+np.cumsum(np.where(c<11,1,-1))],c,read(h)
    @lru_cache(None)
    def receipt(name,h):
        f=a.r248/name;assert dig(f)==h;return list(map(json.loads,f.read_text().splitlines()))
    plans=defaultdict(list);counter=Counter();model=Counter()
    def go(k,node,root,expected):
        box=node['box'];assert box['leaf']==k and box['steps']==expected and box['bounds']==boxes_from(root,expected)
        if 'axis' in node:
            ax=node['axis'];cs=node['children'];assert len(cs)==2 and 0<=ax<11
            counter['explicit_bisection']+=1
            v0=go(k,cs[0],root,expected+[2*ax]);v1=go(k,cs[1],root,expected+[2*ax+1]);return v0 or v1
        r=node['r'];c=node.get('children',[])
        if 'external' in node:
            x=node['external'];assert receipt(x['file'],x['sha256'])[x['line']-1]==r and r['leaf']==k and not(r['guard_uses'] or r['stats'][4] or r['stats'][5])
            assert F(r['goal'])==F('.83750') and r['pending']==len(c) and r['lo']==[i[0] for i in root] and r['hi']==[i[1] for i in root]
            st=r['stats'];assert not st[0];front=st[11:33];mode='R248';uses=bool(st[3])
        else:
            f=node['input'];conf=D['packets'][f];assert conf['method'] in ('slice','affine','mix','anchor','bundle','minimax','oracle','localfine','centered','contract','balanced') and type(conf['floor']) is bool
            assert r['leaf'][:2]==list(map(int,k.split('/'))) and target<=F(r['target'])<=F('.83750') and r['P128']==r['newQ']==r['P15']==0
            st=r['out'];assert st[3]==r['oldQ'];front=r['front'];mode=conf['method'];uses=bool(st[3])
            if a.native and (not a.only or k in a.only.split(',')) and (not a.source or f==a.source):
                cap=st[1] if not st[0] else 4194303
                plans[f,cap,r['target']].append((k,node))
        counter[mode]+=1
        if st[0]:
            assert not c and front is None and st[1]==2*(st[2]+st[3])-1
            return uses
        assert c and len(c)==st[1]-2*(st[2]+st[3])+1-node.get('visited_stop',0)
        assert c[0]['box']['bounds']==list(map(list,zip(front[:11],front[11:])))
        address=c[0]['box']['steps'];assert address[:len(expected)]==expected;tail=address[len(expected):]
        if node.get('visited_stop'):assert len(tail)==110 and st[4]==110
        addresses=[address]+[expected+tail[:j]+[s+1] for j,s in reversed(list(enumerate(tail))) if s%2==0]
        assert len(addresses)==len(c)
        for child,addr in zip(c,addresses):uses=go(k,child,root,addr) or uses
        return uses
    for k,node in D['roots'].items():
        pp,i=map(int,k.split('/'));pre,c,h=part(pp);center,w=leaf_box(pre,c,pp,i,h)
        b=np.column_stack(((center-w)*2**44,(center+w)*2**44)).astype(np.int64).tolist()
        uses_P=go(k,node,b,[]);model['historical_P30' if uses_P else 'five_only']+=1
    print('baseline',D['baseline'],'selected',len(D['roots']),'unresolved',len(D['open']),'geometry',dict(counter),'added_models',dict(model),flush=True)
    if not a.native:return
    assert a.table and a.bank and a.libdir and a.scratch and dig(a.bank)=='55920cb7d0bc0b486e3cc2e669ce1ef5a27974f1b50d3ccfd8f1f18686585a90'
    a.scratch.mkdir(parents=True,exist_ok=True);total=0
    for index,((file,cap,native_target),nodes) in enumerate(plans.items()):
        if a.limit:
            nodes=nodes[:a.limit-total]
            if not nodes:break
        meta=D['packets'][file];method=meta['method'];groups=defaultdict(list)
        for k,node in nodes:groups[k].append(node)
        pk=a.scratch/f'input-{index}.json';out=a.scratch/f'out-{index}.jsonl';win=a.scratch/f'window-{index}.json'
        pk.write_text(json.dumps([dict(leaf=k,regions=[v['box'] for v in vs]) for k,vs in groups.items()]));win.write_text(json.dumps(meta['dense']))
        lib={'slice':'slice','affine':'affine6','mix':'mix6','anchor':'anchor6','bundle':'bundle6','minimax':'minimax6','oracle':'oracle6','localfine':'localfine6','centered':'centered6','contract':'contract6','balanced':'balanced6'}[method]
        if method in ('localfine','centered','contract','balanced'):
            entries=[]
            for key,vs in groups.items():
                win0=vs[0]['r']['window'];assert all(v['r']['window']==win0 for v in vs)
                entries.append(dict(leaf=key,window=win0,regions=[v['box'] for v in vs]))
            pk.write_text(json.dumps(entries))
            cmd=[sys.executable,'-B',a.src/'anglefine.py',a.comp,a.libdir/(lib+'.dylib'),pk,out,'--target',native_target,'--cap',str(cap),'--workers',str(a.workers)]
        else:
            cmd=[sys.executable,'-B',str(a.src/('oracle_slice.py' if method=='oracle' else 'floor_slice.py')),a.comp,a.tree,a.table,a.libdir/(lib+'.dylib'),a.bank,out,'--dense-window',win,'--frontiers',pk,'--only',','.join(groups),'--caps','--mesh','--target',native_target,'--cap',str(cap),'--workers',str(a.workers)]
        if method=='balanced':cmd+=['--depth','180']
        if meta['floor']:cmd+=['--floor-file',a.scores]
        if method=='oracle':assert a.field and dig(a.field)=='9822fee33bf8bd7c293b11808358b54c187df944f10271602aab71c84d7236cd';cmd+=['--field',a.field]
        subprocess.run(cmd,check=True)
        computed=list(map(json.loads,out.read_text().splitlines()));expected=[v for vs in groups.values() for v in vs];assert len(computed)==len(expected)
        for row,v in zip(computed,expected):
            old=v['r'];assert row['leaf'][:2]==old['leaf'][:2] and {k:w for k,w in row.items() if k!='leaf'}=={k:w for k,w in old.items() if k!='leaf'},(file,v['line'],row,old)
        total+=len(expected)
    print('native_matches',total)
if __name__=='__main__':main()

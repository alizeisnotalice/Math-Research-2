"""Verify the actual .83751 point census, five-body material interfaces and cap kernels."""
from pathlib import Path
import json,hashlib,zipfile,sys
from fractions import Fraction as F
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
comp,high,out=map(Path,sys.argv[1:]);src=high/'theorem-083751-nine.json';a=read(src)
assert sha(src.read_bytes())=='6b99f08c697ac1ce944a896e78a0fa439c7bfc7ffdba9babe716693f6309c759'
assert a['complete_global'] and not a['old_core_pending'] and a['old_core_closed']==len(a['known_originals'])==5442
G=F(120697911165410052,2**57)
assert F(a['integer_area_numerator'],a['integer_area_denominator'])==G and a['exterior_closed']==6704872
reg=read(high/'exterior-083751-complete.json');assert reg['reopened_new_outside_closed']=={'pure-five':507,'physical-old-Q':5} and reg['canonical_original_leaves']==6710314
assert F(reg['certified_minimum_outside_5442'])==G
profiles={}
for label in a['finite_inputs']:
 profiles[label]={'any':sum(label in v['families'] for v in a['known_originals'].values()),'only':sum(v['families']==[label] for v in a['known_originals'].values())}
assert [profiles[k]['any'] for k in ('P128','oldQ','newQ','P15')]==[2961,3205,1644,1263]
sig=F('.999999006');m=read(comp/'refined-material-contraction.json');assert F(m['curve_scale'])==sig
for key in ['32','64']:
 r=m['material_squared_maxima'][key];assert len(r)==5 and 4*r[0]<(sig*2**28)**2 and all(i<(sig*2**28)**2 for i in r[1:])
raw=(high/'slice/slice.cpp').read_bytes();hdr=(high/'slice/slice_support.hpp').read_bytes()
def check_caps(code):
 for token in (b'W e=t.goal-std::max<W>(t.last,baseline);',b'if(e>W(Scale)/4000)return false;',b'(U-2)*(Q/C)',b'up_signed(W(d)*(U+2),U)',b'W kappa=std::min<W>(length/2',b'last=twice-error;',b'#include "slice_support.hpp"'):
  assert token in code,token
check_caps(raw)
assert b'band{Q/5000,Q/2500,Q/1600,Q/1000,Q/700,Q/500,' in hdr and b'const W c=W(1023)*length, a=W(1024)*gap;' in hdr
f=(high/'refine_p128.py').read_text();assert 'source = a.slice.read_text()' in f and 'src_path.write_text(source.replace(expected,actual))' in f
with zipfile.ZipFile(high/'affine-nine-083751-kernels-benchmark.zip') as z:
 versions={n:sha(z.read(n)) for n in ['affine-nine.cpp','anchor-nine.cpp','my/include/affine6.hpp','my/include/mix6.hpp']}
 for n in ['affine-nine.cpp','anchor-nine.cpp']:
  code=z.read(n);check_caps(code)
  assert b'last=twice-error;' in code and b't.last=std::max(t.last,best/line_den)' in code
 rr=(high/'slice/run_slice.py').read_text()
 assert 'pts,cnt=verified_table(a.table,a.tree,head)' in rr and 'from disk_centers import rounded_centers' in rr
paths=['slice/slice.cpp','slice/slice_support.hpp','slice/run_slice.py','slice/disk_centers.py','kit/support_grid.py','refine_p128.py','PERIMETER.md','exterior-083751-complete.json','affine-nine-083751-kernels-benchmark.zip']
rec=dict(theorem_sha=sha(src.read_bytes()),actual_family_counts=profiles,source_sha={k:sha((high/k).read_bytes()) for k in paths},affine_members=versions,global_G=str(G),base_material_sha=sha((comp/'refined-material-contraction.json').read_bytes()))
out.write_text(json.dumps(rec,indent=2)+'\n')

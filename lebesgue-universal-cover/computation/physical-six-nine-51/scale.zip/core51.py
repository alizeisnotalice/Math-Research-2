from fractions import Fraction as F
from pathlib import Path
import sys,gzip,json,zipfile,numpy as np,hashlib
c,t,z,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(c.resolve()));from tomar_leaf_box import leaf_box
assert hashlib.sha256(z.read_bytes()).hexdigest()=='2b9bbb532b2aecb30c0f86fec1c2c0ac6a7b6c43c3ec94f80bd51bac393da8e9'
sel={f'{part}/{pos}' for part,v in json.loads(z.read_bytes()).items() for pos in v}
from verify_tomar_fan_table import PINNED_MANIFEST
assert hashlib.sha256((t/'SHA256SUMS').read_bytes()).hexdigest()==PINNED_MANIFEST
pin=dict((name.removeprefix('./'),h) for h,name in (l.split() for l in (t/'SHA256SUMS').read_text().splitlines()))
keys=sorted(tuple(map(int,k.split('/'))) for k in sel);assert len(keys)==5954;res=[]
for p in sorted({k[0] for k in keys}):
 src=t/f'part{p:04}.json';assert all(hashlib.sha256(v.read_bytes()).hexdigest()==pin[v.name] for v in (src,src.with_suffix('.npy')));meta=json.loads(src.read_bytes());co=np.load(src.with_suffix('.npy'),allow_pickle=False);pr=np.r_[1,1+np.cumsum(np.where(co<11,1,-1))]
 for pp,i in keys:
  if pp!=p:continue
  x,h=leaf_box(pr,co,p,i,meta);res.append([x-h,x+h])
np.save(out,np.asarray(res));print(np.asarray(res).shape)

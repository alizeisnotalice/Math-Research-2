"""Pointwise old-to-new support and cap geometry with the genuine .83751 localization."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from flint import arb,ctx
import numpy as np,json,sys
ctx.prec=192
def ar(q):
 q=F(q);return arb(q.numerator)/q.denominator
def read(p):return json.loads(p.read_bytes())
core,inputs,oldp,radii,out=map(Path,sys.argv[1:])
X=np.load(core);assert X.shape==(5954,2,11)
sc=F('.999999006');s=F('.99999912422');j=F('.999998915');low=F('.99999891');M=F('.033');r=F('.422')
G=F(120697911165410052,2**57);B=F(120666927296517964,2**57);U=2**22;Q=2**28;ec=1-sc;ep=1-s
C2s=[];lower=[]
for i,n in enumerate([3,5,7,9]):
 c2=max(sum(max(abs(F(float(row[z,k]))) for z in (0,1))**2 for k in (3*i,3*i+1)) for row in X)
 R=1/(2*(arb.pi()/(2*n)).cos());C=ar(c2).sqrt()
 assert ar(c2)<ar(M*M) and 1-R>ar(r) and R+C<ar('.62')
 C2s.append(str(c2));lower.append((1-R).max(arb('.5')-C))
R=max(ar(x['upper']) for x in read(radii).values())
files={'P128':'p128.json','oldQ':'physical-q.json','newQ':'distinct-q.json','P15':'p15.json'}
for name,x in read(radii).items():
 d=read(inputs/files[name]);a,b=map(F,x['center'])
 r2=max((F(i,d['denominator'])-a)**2+(F(k,d['denominator'])-b)**2 for i,k in d['points'])
 assert r2==F(x['radius2'])<F(x['upper'])**2
h=min([arb('.5')]+lower);paid=ar(ec)*h-ar(ep)*R;assert paid>0
p66=read(oldp);p128=read(inputs/files['P128'])
def pset(d):return {(F(a,d['denominator']),F(b,d['denominator'])) for a,b in d['points']}
assert len(pset(p66))==66 and pset(p66)<=pset(p128)
bar=(sc-j)*r-(1-j)*M
norm=F(U+2,U);f=F(Q//5000,Q);over=((sc-j)*F('.62')+ec*M)*norm
chord=j/norm**2*f/(j*f+over)-F(1023,1024)
cash=sc*F(1,2*(U-2))-ec*(M+F(1,60))
sg=ar(sc/2);z=ar('.706')
assert bar>0 and cash>0 and chord>0 and j/norm**2>F(1023,1024) and F(1,60)**2>F(1,4000)
assert (arb.pi()-(sg/z).acos())*sg**2+sg*(z*z-sg**2).sqrt()>ar(G)
assert F('.706')**2<sc**2/2 and j*j*F('.8373034')>B
floor=(2**57*low**2*B).__floor__();assert F(floor,2**57)<sc**2*B
receipt=dict(G=str(G),curve_scale=str(sc),finite_scale=str(s),j=str(j),centers_squared=C2s,body_retreat_bounds=[v.str(38) for v in lower],retreat_coefficient=h.str(40),finite_radius=R.str(42),pointwise_increase=paid.str(42),center_inclusion_spare=str(bar),chord_spare=str(chord),denominator_spare=str(cash),root_floor=floor,source_area=str(G/s**2),source_decimal=ar(G/s**2).str(60))
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['source_decimal'],receipt['pointwise_increase'])

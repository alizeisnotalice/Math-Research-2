"""Replay .83751 normalized nine inputs, the 501-new-target baseline bridge and finite certificates."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import argparse,sys,json,gzip,importlib.util,zipfile,subprocess,shutil
HERE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sha(b):return sha256(b).hexdigest()
def run(xs):subprocess.run(list(map(str,xs)),check=True)
def check(a,b):assert a.read_bytes()==b.read_bytes(),a
def unzip(p,out):
 with zipfile.ZipFile(p) as z:z.extractall(out)
def one(p,key):
 with zipfile.ZipFile(p) as z:return z.read(next(k for k in z.namelist() if Path(k).name==key))
def main():
 pa=argparse.ArgumentParser()
 for k in ['first','comp','tree','table','cache','out']:pa.add_argument(k,type=Path)
 pa.add_argument('--reuse-roots',type=Path);pa.add_argument('--workers',type=int,default=4);a=pa.parse_args()
 c=a.comp.resolve();w=a.out.resolve();w.mkdir(exist_ok=False);py=[sys.executable,'-B']
 first=w/'first';assert sha(a.first.read_bytes())=='d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666';unzip(a.first,first)
 h=w/'high';unzip(HERE/'source51.zip',h)
 run(py+[HERE/'sources51.py',c,h,w/'sources51.json']);check(w/'sources51.json',HERE/'sources51.json')
 core=w/'core51.npy';run(py+[HERE/'core51.py',c,a.tree.resolve(),h/'stage4-audit51/retained.json',core])
 run(py+[HERE/'geometry51.py',core,HERE/'inputs',c/'scaled-eight-50/p66.json',HERE/'cloud-radii.json',w/'geometry51.json']);check(w/'geometry51.json',HERE/'geometry51.json')
 for n,t in [(730,'.83750'),(1931,'.83751'),(1991,'.8375101')]:
  wd=w/f'finite{n}';run(py+[HERE/'finite_scaled.py',HERE/'inputs',wd,'--N',n,'--target',t])
  r=read(wd/'finite-report.json');s=read(HERE/f'finite{n}-report.json')
  for k in ('python','flint'):r.pop(k);s.pop(k)
  assert r==s
 idx=read(c/'five-global-localization.json')['retained'];keys={(int(p),n) for p,ns in idx.items() for n in ns};assert len(keys)==501
 if a.reuse_roots:
  f=a.reuse_roots.resolve()
 else:
  kit=w/'kit.zip';kit.write_bytes(one(c/'physical-nine-47/r6.zip','nine-replay-kit.zip'));assert sha(kit.read_bytes())=='19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467'
  build=w/'build.py';build.write_bytes(one(c/'scaled-eight-50/scale.zip','build_dichotomy.py'));assert sha(build.read_bytes())=='a5128c9116af0060385fdf60b8b9920524770885c3bd2ad9accad8f37c483ce4'
  ref=w/'ref';run(py+[build,kit,ref]);bank=w/'angular66.json';bank.write_bytes(gzip.decompress((first/'angular-66.json.gz').read_bytes()))
  assert sha(bank.read_bytes())=='b0d3e4d6b3dc065a59c3a2de48256399813d8cb599f1cb3393d631dbdbe38181'
  k=w/'native';run(py+[first/'baseline.py',ref,bank,k]);s=(k/'run_nine.py').read_text();token="floor=(M*F('.9999999')**2*2*Z*Z).__floor__()";assert s.count(token)==1
  driver=k/'run_floor995.py';driver.write_text(s.replace(token,"floor=(120666927296517964*F('.99999891')**2).__floor__()"))
  assert sha(driver.read_bytes())=='920ec3fb4ecd3070675411d926603cea973d183a052bc5edfe1b997e21c9881b'
  assert sha((k/'nine.cpp').read_bytes())=='4cdc9342725b105bf63d29b8dcdd4a6e600c65ea37fb8b7585d259dabd4b7df9'
  assert sha((k/'bank.json').read_bytes())=='ead43afb275a93d7ae8de12ef61beb976f8de24b449b1885b883481b0ad8deb9'
  lib=k/'kernel.so';run([shutil.which('clang++'),'-O3','-std=c++17','-fsanitize=signed-integer-overflow','-fsanitize-undefined-trap-on-error','-fPIC','-shared',f'-fmodules-cache-path={a.cache.resolve()}','-I',c/'three-leaf-083750',k/'nine.cpp','-o',lib])
  ip=w/'index.json';ip.write_text(json.dumps(idx)+'\n');f=w/'roots51.jsonl'
  run(py+[driver,c,a.tree.resolve(),a.table.resolve(),lib,k/'bank.json',f,'--index',ip,'--target','.83751','--caps','--mesh','--workers',a.workers,'--cap',3000000])
 rows=[json.loads(l) for l in f.read_text().splitlines()]
 assert len(rows)==501 and {tuple(d['leaf']) for d in rows}==keys
 for d in rows:
  o=d['out'];assert F(d['target'])==F('.83751') and o[0]==1 and o[1]==2*(o[2]+o[3])-1 and o[3]==d['P128']+d['oldQ'] and d['newQ']==d['P15']==0 and d['front'] is None
 rows.sort(key=lambda d:d['leaf']);r=dict(rows=len(rows),totals=[sum(d['out'][i] for d in rows) for i in [1,2,3]]+[sum(d[k] for d in rows) for k in ['P128','oldQ']],sha256=sha((json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode()));assert r==read(HERE/'roots51-receipt.json')
 print('GLOBAL 83751 SCALED NINE: VERIFIED; FINITE 730, 1931, 1991')
if __name__=='__main__':main()

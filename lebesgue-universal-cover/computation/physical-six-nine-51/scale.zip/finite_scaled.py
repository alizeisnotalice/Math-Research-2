"""Exact finite inputs for transfer of the physical nine-body 83751 area theorem."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from hashlib import sha256
from math import isqrt
from flint import arb,ctx
import argparse,gzip,json,platform,flint
ctx.prec=192
G=F(120697911165410052,2**57);Q=10**20
NAMES={'P128':('p128.json','d2be06dcd7aa9500e7fe48c5cd3a0c39b9d18358b8f5047c02faad4c32398620'),'oldQ':('physical-q.json','7c656ce6491d23e0619e7aa78527fa5b17f6dc011b6f3034981413fa0cb80d93'),'newQ':('distinct-q.json','f13bf7699231a325d939de7892a9be8e661937e9c9fe146152a34b27b96df8a5'),'P15':('p15.json','d5374aa909dc6bb8c4e6db3edc069c05f68795a1977a6adbd9807049798d5145')}
def ar(x):
 q=F(x);return arb(q.numerator)/q.denominator
def rnd(x):
 b=int((x+ar(F(1,2))).mid().floor().unique_fmpz());assert abs(b-x)<1
 return b
def d2(points):
 return max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(points,2))
def turn(a,b,p):
 return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def hull(points):
 p=sorted(set(points))
 def half(ps):
  h=[]
  for x in ps:
   while len(h)>1 and turn(h[-2],h[-1],x)<=0:h.pop()
   h.append(x)
  return h[:-1]
 return half(p)+half(reversed(p))
def disk(n):
 # Circumscribed unit disk, variable normal gaps. The following geometrical checks use only output integers.
 M=10**6;w=[M]*n;m=n//2;c=[634599,971435,997893,999779,1096241,1007040,1000425]
 if n%2==0:
  w[0]=w[1]=c[0]
  for i in range(3):w[2+i]=w[n-1-i]=c[1+i];w[m-i]=w[m+1+i]=c[4+i]
 W=sum(w);s=0;p=[]
 for v in w:
  phi=arb.pi()*ar(F(2*s+v,W));uy,ux=phi.sin_cos();f=(arb.pi()*ar(F(v,W))).cos()
  p.append((rnd(Q*ux/f),rnd(Q*uy/f)));s+=v
 d=isqrt(d2(p))+1;h=hull(p);assert len(h)==n;R=None
 for a,b in zip(h,h[1:]+h[:1]):
  c=turn(a,b,(0,0));assert c>0
  L=(b[0]-a[0])**2+(b[1]-a[1])**2
  t=F(4*c*c,L*d*d);R=t if R is None else min(R,t)
 return d,p,R
def regular(n,factor):
 sc=F(10**16-1,10**16);delta=F(2,Q);R=1/(2*(arb.pi()/(2*n)).cos());r=1-R;m=1
 while True:
  err=ar(sc)*(1-(arb.pi()/(2*n*m)).cos())+ar(delta)
  if ar(sc)-err/r>factor:break
  m+=1
 p=[]
 for j in range(n):
  cy,cx=(2*arb.pi()*j/n).sin_cos()
  for k in range(m+1):
   vy,vx=(arb.pi()*ar(F(2*j,n)+1-F(1,2*n)+F(k,n*m))).sin_cos()
   p.append((rnd(ar(sc)*Q*(R*cx+vx)),rnd(ar(sc)*Q*(R*cy+vy))))
 return list(dict.fromkeys(p)),m
def main():
 pa=argparse.ArgumentParser();pa.add_argument('kit',type=Path);pa.add_argument('out',type=Path);pa.add_argument('--N',type=int,required=True);pa.add_argument('--target',type=F,required=True);a=pa.parse_args();a.out.mkdir(exist_ok=True)
 sc=F('.999999006');s=F('.99999912422');den,pts,alpha2=disk(a.N);alpha=ar(alpha2).sqrt();data=[dict(name='disk',denominator=den,points=pts)];stages={}
 assert G*alpha2/sc**2>a.target and alpha2*s*s<sc*sc
 prior=(arb.pi()/(a.N-1)).cos()/(arb.pi()/(2*a.N-2)).cos()
 for n in (3,5,7,9):
  p,m=regular(n,alpha);stages[n]=m;data.append(dict(name='R'+str(n),denominator=Q,points=p))
 for name,(src,digest) in NAMES.items():
  raw=(a.kit/src).read_bytes();assert sha256(raw).hexdigest()==digest
  y=json.loads(raw);data.append(dict(name=name,denominator=y['denominator'],points=y['points']))
 rec=[]
 for d in data:
  p=d['points'];den=d['denominator'];sd=F(d2(p),den*den);assert sd<1 and len(p)<=a.N
  rec.append(dict(name=d['name'],points=len(p),diameter_squared=str(sd)))
 raw=(json.dumps(data,separators=(',',':'))+'\n').encode();(a.out/'nine-finite.json.gz').write_bytes(gzip.compress(raw,compresslevel=8,mtime=0))
 r=dict(conditional='under the contracted G theorem for the specified physical nine inputs', n=a.N, target=str(a.target), s=str(s), curve_scale=str(sc),G=str(G),alpha_squared=str(alpha2),finite_bound=str(G*alpha2/sc**2),finite_decimal=ar(G*alpha2/sc**2).str(58),previous_upper=(ar(G/sc**2)*prior**2).str(46),groups=rec,arc_subdivisions=stages,uncompressed_sha256=sha256(raw).hexdigest(),precision=ctx.prec,python=platform.python_version(),flint=flint.__version__)
 (a.out/'finite-report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['finite_decimal'],[(j['name'],j['points']) for j in rec],r['previous_upper'],r['uncompressed_sha256'])
if __name__=='__main__':main()

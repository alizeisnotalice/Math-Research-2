# .83751 九输入的共同缩放与有限见证

一般面积下端 .83751146695094269361337962811932078。有限下端分别为 Λ₇₃₀>.8375000129486401961、Λ₁₉₃₁>.8375100023748197373、Λ₁₉₉₁>.8375101010716655908。证明、量词和冻结全域依赖见 PROOF.md。

~~~sh
python -B replay.py "$R272_FIRST_ZIP" "$COMP" "$TOMAR_TREE" "$TABLE64" "$CLANG_CACHE" "$NEW_OUTPUT" --workers 4
~~~

R272_FIRST_ZIP 是 physical-seven-flex50.zip，SHA-256 d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666。COMP 为主仓 computation，TREE 为 cert11d_08366，TABLE64 已验 SHA-256 0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d。默认重建公开原生源，直接以 .83751 访遍501例外根，并核准全行规范摘要。已有本靶根计数时可加 --reuse-roots 根回执.jsonl。角行、全域原树及源全账是已列明的输入定理，包内绑定本靶选择账及新核源。三档有理点在输出目录 finite730、finite1931、finite1991 中自动生成。

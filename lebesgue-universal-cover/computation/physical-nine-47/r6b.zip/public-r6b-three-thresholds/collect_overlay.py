"""Verify the second common-angle forest and a fixed tranche of MacBook continuations."""
from argparse import ArgumentParser
from pathlib import Path
from types import SimpleNamespace
import json
import subprocess
import sys

from audit_wave import Roots,load
from audit_layers_mixed import verify_layers

MAC={
    'r6-direct-01':(1201,24,False,'144bb57a7f6b34e0c8465bd8bb219f83a3cbd417d331660adcfd0a1b312a91b3'),
    'r6-direct-02':(1201,5,False,'b7ab080368fa91f401f47338a8cb1fc1ee6df577f62b1078798bd16d066bc76e'),
    'r6-181-direct-01':(181,19,False,'9e9032e23e497720bcbe52cc31180970c1d28a95e6b5633a78f73b846abba61a'),
    'r6-cont-01':(1201,5,True,'65adb710f16c3e906e28fc475d9f08c88d3da2b9bd247b71df62852a00806249'),
    'r6-181-cont-01':(181,18,True,'49563c177dbb731f942b3b844ee5ad0ceadccc49e1a8abc82578c5a3a2bb53ff'),
    'r6-181-deep-01':(181,3,True,'cccd983941ff1cdab33cad5aab2b7f6715005812bc1939cee81843379318607b'),
}


def main():
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','r6','sources','work','output'):
        p.add_argument(n,type=Path)
    a=p.parse_args()
    sys.path.append(str(a.r6.resolve()))
    from collect import direct,extract
    w=a.work
    w.mkdir(parents=True,exist_ok=False)
    sources=a.sources
    roots=Roots(a)
    original=load(a.r6/'frozen/rows-mac-donors.json')
    order_by_part={n:load(sources/(f'order-{n}.json')) for n in (1201,181)}
    assert all(len(x)==len(set(x)) for x in order_by_part.values())
    known=set(original['mac']['proved'])
    for label,(part,count,layered,hash) in MAC.items():
        raw=w/label
        extract(sources/(label+'.zip'),hash,raw)
        ids=load(raw/'source-indices.json')
        want=[order_by_part[part][i] for i in ids]
        assert len(want)==len(set(want))==count and not(set(want)&known)
        known.update(want)
        if layered:
            data,counts=verify_layers(roots,raw,order_by_part[part],part)
        else:
            out=w/(label+'-audit.json')
            subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('audit_direct_mixed.py')),
                            *map(str,(a.comp,a.tree,a.r248,raw,out))],check=True,stdout=subprocess.DEVNULL)
            read=load(out)
            data={k:{**v,'target':'67/80','avg_transfer':True}for k,v in read['proved'].items()}
            for v in data.values():
                v['parent_source']=v.pop('source')
            counts=read['exact_counts']
        assert want==list(data)
        original['mac']['packages'][label]=dict(sha256=hash,roots=want,**counts)
        original['mac']['proved'].update(
            {k:{**v,'source':label,'archive_sha256':hash} for k,v in data.items()})
    more=direct(SimpleNamespace(r248=a.r248,sources=sources,work=w),roots)
    original['direct']['proved'].extend(more['proved'])
    original['direct']['packages'].update(more['packages'])
    original['direct']['common_angle'].update(more['common_angle'])
    a.output.write_text(json.dumps(original,indent=2)+'\n')
    print('MacBook next originals',len(known)-132,'updated forests',len(more['proved']),flush=True)


if __name__=='__main__':
    main()

"""Verify exact frontiers, native results and fixed-input counts at three thresholds."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys

P='original_P30'
D='augmented_P128'
Q='physical_old_Q11'
A='average_Q11'
R='replacement_P30'
C='reduced_P66'
GOAL=Fraction(67,80)


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def lines(raw):
    return [json.loads(x) for x in raw.splitlines()]


def order(keys):
    return sorted(keys,key=lambda k:tuple(map(int,k.split('/'))))


def verify_closed(row):
    n,old,new=row['out'][1:4]
    assert not row['paired'] and new==row['P128']+row['oldQ']
    assert row['out'][0]==1 and row['front'] is None and n==2*(old+new)-1


class Roots:
    def __init__(self,a):
        sys.path.insert(0,str(a.comp))
        from certify_tomar_six_high import FINE, SourceTree
        self.tree=SourceTree(a.tree)
        self.scale=FINE
        self.r248=a.r248
        self.records={}
        spec=spec_from_file_location('audit_r248',a.r248/'audit_refined_scope.py')
        self.audit=module_from_spec(spec)
        spec.loader.exec_module(self.audit)

    def verify(self,packet):
        prefix=packet['source'].split('/')[0]
        leaf=packet['leaf']
        if prefix not in self.records:
            path=self.r248/'refined'/(prefix+'.jsonl')
            assert load(path.with_name(prefix+'-receipt.json'))['result_sha256']==digest(path)
            self.records[prefix]={r['leaf']:(i,r) for i,r in enumerate(lines(path.read_bytes()),1)}
        line,parent=self.records[prefix][leaf]
        root=self.tree.leaf(*map(int,leaf.split('/')))
        bounds=[(x*self.scale,y*self.scale) for x,y in root]
        assert bounds==list(zip(parent['lo'],parent['hi'],strict=True))
        assert GOAL==Fraction(parent['goal'])
        assert parent['threshold_integer']==120696470013529293
        stats=parent['stats']
        assert stats[0]==stats[5]==parent['pending_visited']==parent['guards']==parent['center_stops']==0
        assert stats[7]==1 and stats[1]==2*sum(stats[2:5])+parent['pending']-1
        path=self.r248/'refined/frontiers'/packet['source']
        assert digest(path)==packet['digest'] and load(path)==packet['regions']
        self.audit.audit_paths(parent,packet['regions'])
        return dict(source=prefix+'.jsonl',line=line,frontier=packet['source'],frontier_sha256=digest(path)),parent


def load_stages(a,roots):
    original=load(a.data/'frontiers-chord.json')
    packets={p['leaf']:p for p in original}
    assert len(packets)==54
    origins={k:roots.verify(p) for k,p in packets.items()}
    new={}
    old={}
    stages=[]
    for data,results,cap in (
        ('frontiers-chord.json','disk-chord-2047.jsonl',2047),
        ('saturation-24.json','disk-chord-32767.jsonl',32767),
        ('saturation-10.json','disk-chord-131071.jsonl',131071),
    ):
        subset=load(a.data/data)
        rows=iter(lines((a.data/results).read_bytes()))
        counts=Counter()
        for p in subset:
            k=p['leaf']
            refs=packets[k]
            assert p['digest']==refs['digest'] and p['source']==refs['source']
            selected=p.get('origin_indices',list(range(len(refs['regions']))))
            assert len(selected)==len(set(selected))
            for i,(j,box) in enumerate(zip(selected,p['regions'],strict=True)):
                assert refs['regions'][j]==box
                row=next(rows)
                assert row['leaf']==[*map(int,k.split('/')),i]
                assert Fraction(row['target'])==GOAL and 0<row['out'][1]<=cap
                assert (k,j) not in new or not new[k,j][0]['out'][0]
                if row['out'][0]:
                    verify_closed(row)
                new[k,j]=(row,results)
                counts['boxes']+=1
                counts['visits']+=row['out'][1]
                counts['direct_closed']+=row['out'][0]
        assert next(rows,None) is None
        stages.append(dict(source=results,sha256=digest(a.data/results),**counts))
    for data,results in (('frontiers-chord.json','old-chord-2047.jsonl'),
                         ('saturation-24.json','old-chord-32767.jsonl'),
                         ('saturation-10.json','old-chord-131071.jsonl')):
        rows=iter(lines((a.data/results).read_bytes()))
        for p in load(a.data/data):
            k=p['leaf']
            for i,j in enumerate(p.get('origin_indices',range(len(p['regions'])))):
                row=next(rows)
                assert row['leaf']==[*map(int,k.split('/')),i]
                assert Fraction(row['target'])==GOAL
                if row['out'][0]:
                    verify_closed(row)
                if (k,j) not in old or not old[k,j]['out'][0]:
                    old[k,j]=row
        assert next(rows,None) is None
    complete={}
    for key,p in packets.items():
        subtrees=[new[key,j] for j in range(len(p['regions']))]
        if not all(r['out'][0] for r,_ in subtrees):
            continue
        link,parent=origins[key]
        s=parent['stats']
        n=s[1]+sum(r['out'][1] for r,_ in subtrees)
        terms=Counter({P:s[3],Q:s[4],'five':s[2]})
        for r,_ in subtrees:
            terms.update({D:r['P128'],Q:r['oldQ'],'five':r['out'][2]})
        assert n==2*sum(terms.values())-1
        complete[key]=dict(inputs=[tag for tag in (P,D,Q) if terms[tag]],
            nodes=n,terms=terms,**link,selected_rows=[src for _,src in subtrees],
            control_complete=all(old[key,j]['out'][0] for j in range(len(p['regions']))))
    return complete,stages


def verify_lower(path,roots):
    donor=json.loads(decompress((path/'high.json.gz').read_bytes()))
    physical=lines(decompress((path/'physical-receipts.jsonl.gz').read_bytes()))
    assert physical==[row for d in donor for row in d['subtrees']]
    closed={}
    for d in donor:
        p=d['packet']
        key=p['leaf']
        link,parent=roots.verify(p)
        assert parent==d['prefix'] and link['line']==d['line']
        assert digest(roots.r248/d['source'])==d['sha256']
        s=parent['stats']
        assert s[3]==0 and s[4]>0 and len(d['subtrees'])==len(p['regions'])
        for j,r in enumerate(d['subtrees']):
            assert r['leaf']==[*map(int,key.split('/')),j]
            assert Fraction(r['target'])==Fraction(20937,25000) and r['P128']==0
            verify_closed(r)
        closed[key]=dict(inputs=[Q],**link)
    assert len(closed)==17 and len(physical)==338
    assert sum(r['out'][1] for r in physical)==8041542
    return closed


def main(a):
    base=load(a.ledger)
    assert digest(a.ledger)=='012aabbbbfab9adf1511277fadb40d22827b74db3f74d55841111d05ca057900'
    assert base['scope']==5442 and len(base['all_256_model_counts'])==256
    initial=set(base['model_census']['all_archived_inputs']['unresolved'])
    assert len(initial)==519
    roots=Roots(a)
    current,stage=load_stages(a,roots)
    mac={}
    for slot in ('03','04'):
        path=a.data/f'mac-{slot}-audit.json'
        report=load(path)
        assert report['strict'] and Fraction(report['target'])==GOAL
        assert len(report['proved'])==36 and not set(report['proved']) & mac.keys()
        for k,v in report['proved'].items():
            assert v['inputs']==[Q]
            mac[k]={**v,'source':path.name,'report_sha256':digest(path)}
    assert set(current)<=initial and mac.keys()<=initial and not current.keys() & mac.keys()
    lower=verify_lower(a.q48,roots)
    assert lower.keys()<=initial
    current_rows={**mac,**current}
    proofs={k:[set(v['required']) for v in q] for k,q in base['proof_masks_by_leaf'].items()}
    for key,v in current_rows.items():
        proofs[key].append(set(v['inputs']))
    out={}
    for bits,v in base['all_256_model_counts'].items():
        allowed=set(v['allowed'])
        if D in allowed: allowed.update((C,R,P))
        if C in allowed: allowed.update((R,P))
        if R in allowed: allowed.add(P)
        if A in allowed: allowed.add(Q)
        high={k for k,rs in proofs.items() if not any(r<=allowed for r in rs)}
        short=high-(lower.keys() if Q in allowed else set())
        out[bits]=dict(inputs=v['allowed'],high_remaining=len(high),
            lower_remaining=len(short),
            high_unresolved_sha256=sha256(('\n'.join(order(high))+'\n').encode()).hexdigest(),
            lower_unresolved_sha256=sha256(('\n'.join(order(short))+'\n').encode()).hexdigest())
        if bits in ('05','06','44','48','54','58','d4','d8','ff'):
            out[bits]['high_unresolved']=order(high)
            out[bits]['lower_unresolved']=order(short)
    high=initial-current_rows.keys()
    assert out['ff']['high_remaining']==len(high)
    lower_open=high-lower.keys()
    assert out['ff']['lower_remaining']==len(lower_open)
    result=dict(strict=True,original_leaves=5442,
        target='67/80',reuse_thresholds=['20937/25000','83747/100000'],
        inherited_full_shards=base['complete_source_shards'],
        initial_high_remaining=len(initial),mac72=mac,local_native=current,local_stages=stage,
        high_unresolved=order(high),lower_unresolved=order(lower_open),lower_sources=lower,
        new_only_lower=order(lower.keys()&high),fixed_models=out)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(high=len(high),lower=len(lower_open),mac=len(mac),local=len(current),
                          native_only_vs_control=sum(not v['control_complete'] for v in current.values()),
                          lower_only=len(lower.keys()&high))),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','ledger','data','q48','output'):
        p.add_argument(name,type=Path)
    main(p.parse_args())

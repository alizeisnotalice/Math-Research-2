"""Replay the additional forest and MacBook roots from pinned original-domain archives."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import os
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
PINS={
    'r248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'r4plus':'3ecfcebdfcab476b2250927d07432c37c45f66a325feb35d193f51831a6f7b90',
    'r5':'e06073af59738402181b27aa8214c210a20100b651b35c35809d0d393bab0562',
    'r597':'eb2dec682d277c423e834a9f4443afc5cd11067fed5990dd80af4a9b02ced094',
    'r6':'ba9d943114016e17be388cdad2505b3f341f6ca0cdceba7008a423dff5fb0510',
    'kit':'19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467',
}


def extract(path,pin,out):
    assert sha256(path.read_bytes()).hexdigest()==pin,path
    with ZipFile(path) as z:
        names=z.namelist()
        assert len(set(names))==len(names) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(out)


def run(*args,env=None):
    subprocess.run(list(map(str,args)),check=True,env=env)


def main():
    p=ArgumentParser(description=__doc__)
    for label in ('comp','tree','r248','r4plus','r5','r597','r6','work'):
        p.add_argument(label,type=Path)
    p.add_argument('--trace',action='store_true')
    p.add_argument('--table',type=Path)
    p.add_argument('--cache',type=Path)
    a=p.parse_args()
    for n,v in vars(a).items():
        if isinstance(v,Path):
            setattr(a,n,v.resolve())
    w=a.work
    w.mkdir(parents=True,exist_ok=False)
    for n in ('r248','r4plus','r5','r597','r6'):
        extract(getattr(a,n),PINS[n],w/n)
    r248=w/'r248/public-replay-r2-083750'
    r4plus=w/'r4plus/public-r4-followup-083750/frozen/ledger.json'
    r5=w/'r5/public-r5-083750/frozen/wave-ledger.json'
    r597=w/'r597/public-r5-pool-first97/frozen/ledger.json'
    r6=w/'r6/public-r6-three-thresholds'
    rows=w/'rows-overlay-74.json'
    result=w/'ledger-overlay-74.json'
    extracted=w/'extract-proofs'
    run(sys.executable,'-B',HERE/'collect_overlay.py',a.comp,a.tree,r248,r6,HERE/'sources',extracted,rows)
    run(sys.executable,'-B',HERE/'integrate.py',r4plus,r5,r597,rows,r6/'frozen/rows-ordinary.json',result)
    for path in (rows,result):
        assert path.read_bytes()==(HERE/'frozen'/path.name).read_bytes()
    if a.trace:
        if not a.table or not a.cache:
            raise ValueError('--trace needs --table and --cache')
        kit=w/'kit'
        extract(r6/'frozen-sources/nine-replay-kit.zip',PINS['kit'],kit)
        lib=w/'trace.dylib'
        run('clang++','-O3','-std=c++17','-fsanitize=signed-integer-overflow',
            '-fsanitize-undefined-trap-on-error','-shared','-fPIC',f'-fmodules-cache-path={a.cache}',
            '-I',a.comp/'three-leaf-083750',kit/'frontier-path.cpp','-o',lib,
            env=dict(os.environ,TMPDIR=str(w)))
        run(sys.executable,'-B',extracted/'forest-second/replay_forest.py',r248,
            '--trace','--kit',kit,'--comp',a.comp,'--tree',a.tree,'--table',a.table,
            '--axial',lib,'--scratch',w/'trace-second')
    print('reproduced R6 overlay, all 256 fixed models and three thresholds',flush=True)


if __name__=='__main__':
    main()

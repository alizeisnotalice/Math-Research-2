"""Select one whole-domain proof for every fourth-layer original using only physical inputs."""
import argparse,gzip,hashlib,json
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def main():
    a=argparse.ArgumentParser()
    for x in ['outer','r4plus','r5','r597','joined','out']:a.add_argument(x,type=Path)
    a=a.parse_args();st=rd(a.joined);I=st['baseline_files_sha256'];sha={k:digest(getattr(a,n)) for k,n in [('R4plus','r4plus'),('R5','r5'),('R5plus97','r597')]};assert I==sha
    layer=rd(a.outer/'layers-audit.json');assert layer['seed']==699060 and [(v['parts'],v['remaining']) for v in layer['layers']]==[(1024,136243),(1024,22418),(1024,8792),(1024,5442)]
    allkeys={f'{p}/{x}' for p,v in rd(a.outer/'retained.json').items() for x in v};assert len(allkeys)==5442
    b4,b5,b97=map(rd,[a.r4plus,a.r5,a.r597]);assert set(b4['proof_masks_by_leaf'])==allkeys
    G=F((F('.83747')*2**57).__floor__()+1,2**57);lo,mid,high=map(F,['.83747','.83748','.83750'])
    direct={'augmented_P128','physical_old_Q11','new_Q11','P152_interior15'}
    transfer={'reduced_P66','replacement_P30','original_P30'}
    ok={k:[] for k in allkeys}
    def add(k,source,target,inputs):
        assert k in allkeys
        req=set(inputs);target=F(target)
        if target<lo or req-direct-transfer:return
        assert 'average_Q11' not in req
        ok[k].append((target,-len(req),source,sorted(req)))
    for k,items in b4['proof_masks_by_leaf'].items():
        for v in items:add(k,'R4plus/'+v['source'],high,v['required'])
    for group in ['mac72','local_native','lower_sources']:
        for k,v in b5[group].items():add(k,'R5/'+group,mid if group=='lower_sources' else high,v['inputs'])
    for k,v in b97['new'].items():add(k,'R5plus97',high,v['inputs'])
    for k,items in st['receipts_by_leaf'].items():
        for v in items:add(k,v['source'],v['target'],v['inputs'])
    choices={};count=Counter();sources=Counter();types=Counter()
    for k in sorted(allkeys,key=lambda k:tuple(map(int,k.split('/')))):
        assert ok[k],k
        t,_,src,req=max(ok[k]);assert (t*2**57).__floor__()+1>=G*2**57
        choices[k]=[str(t),src,req];count[str(t)]+=1;sources[src]+=1;types.update(req)
    assert st['focal']['nine_P128_physical_Q_new_Q_P152']['thresholds']['.83747']['remaining']==0
    a.out.mkdir(exist_ok=True)
    raw=(json.dumps(choices,separators=(',',':'))+'\n').encode();(a.out/'physical-selection.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    out=dict(checked_roots=len(ok),domains=6710314,outside=6710314-len(ok),goal=str(G),area_grid=2**57,selected_thresholds=dict(count),required_appeared=dict(types),sources=dict(sources),sha256_sources=sha|{'R6c':digest(a.joined),'retained':digest(a.outer/'retained.json')},selection_sha256=hashlib.sha256(raw).hexdigest())
    (a.out/'selection-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(len(ok),count,types)
if __name__=='__main__':
    assert __debug__;main()

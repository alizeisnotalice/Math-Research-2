"""Verify the second common-angle forest and a fixed tranche of MacBook continuations."""
from argparse import ArgumentParser
from pathlib import Path
from types import SimpleNamespace
import json
import subprocess
import sys

from audit_wave import Roots,load
from audit_layers_mixed import verify_layers

def main():
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','r6','r6b','sources','work','output'):
        p.add_argument(n,type=Path)
    a=p.parse_args()
    sys.path.append(str(a.r6.resolve()))
    from collect import direct,extract
    w=a.work
    w.mkdir(parents=True,exist_ok=False)
    sources=a.sources
    roots=Roots(a)
    original=load(a.r6b/'frozen/rows-overlay-74.json')
    mac=load(sources/'mac-sources.json')
    order_by_part={n:load(sources/(f'order-{n}.json')) for n in {x[0] for x in mac.values()}}
    assert all(len(x)==len(set(x)) for x in order_by_part.values())
    known=set(original['mac']['proved'])
    before=len(known)
    for label,(part,count,layered,hash) in mac.items():
        raw=w/label
        extract(sources/(label+'.zip'),hash,raw)
        ids=load(raw/'source-indices.json')
        want=[order_by_part[part][i] for i in ids]
        assert len(want)==len(set(want))==count and not(set(want)&known)
        known.update(want)
        if layered:
            data,counts=verify_layers(roots,raw,order_by_part[part],part)
        else:
            out=w/(label+'-audit.json')
            subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('audit_direct_mixed.py')),
                            *map(str,(a.comp,a.tree,a.r248,raw,out))],check=True,stdout=subprocess.DEVNULL)
            read=load(out)
            data={k:{**v,'target':'67/80','avg_transfer':True}for k,v in read['proved'].items()}
            for v in data.values():
                v['parent_source']=v.pop('source')
            counts=read['exact_counts']
        assert want==list(data)
        original['mac']['packages'][label]=dict(sha256=hash,roots=want,**counts)
        original['mac']['proved'].update(
            {k:{**v,'source':label,'parent_target':'67/80','archive_sha256':hash} for k,v in data.items()})
    more=direct(SimpleNamespace(r248=a.r248,sources=sources,work=w),roots)
    for proof in more['proved']:
        proof['parent_target']='67/80'
        proof['suffix_minimum_target']=proof['target']
    original['direct']['proved'].extend(more['proved'])
    original['direct']['packages'].update(more['packages'])
    original['direct']['common_angle'].update(more['common_angle'])
    a.output.write_text(json.dumps(original,indent=2)+'\n')
    print('MacBook next originals',len(known)-before,'updated forests',len(more['proved']),flush=True)


if __name__=='__main__':
    main()

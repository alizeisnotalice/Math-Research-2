"""Recompute every defining-disk terminal call in a frozen forest."""
from argparse import ArgumentParser, Namespace
from collections import defaultdict
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
import sys


def walk(nodes):
    for n in nodes:
        yield n
        yield from walk(n['children'])


def main():
    p=ArgumentParser(description=__doc__)
    for name in ('forest','slice_kit','nine_kit','comp','tree','table','lib','bank','work','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    a.work.mkdir(parents=True,exist_ok=False)
    sys.path[:0]=[str(a.slice_kit.resolve()),str(a.nine_kit.resolve())]
    from run_slice import run
    assert sha256(a.bank.read_bytes()).hexdigest()=='d0b523be89a12f97c0716575f66e2010832498a642e55af45f9c0263475ea999'
    source=a.forest/'forest.json.gz'
    forest=json.loads(decompress(source.read_bytes()))
    selected=defaultdict(dict)
    for root,entry in forest.items():
        for n in walk(entry['forest']):
            if n['mode']=='slice':
                r=n['r']
                assert r['out'][0] and r['front'] is None and not n['children']
                selected[Fraction(r['target'])].setdefault(root,[]).append(n)
    assert selected
    reports={}
    for goal,group in sorted(selected.items()):
        name=f'{goal.numerator}-{goal.denominator}'
        request=a.work/(name+'-request.json')
        request.write_text(json.dumps([dict(leaf=k,regions=[z['box'] for z in zs])
                                       for k,zs in group.items()])+'\n')
        output=a.work/(name+'-output.jsonl')
        run(Namespace(comp=a.comp,tree=a.tree,table=a.table,lib=a.lib,bank=a.bank,output=output,
            caps=True,mesh=True,target=str(goal),cap=4194303,workers=4,index=None,
            only=','.join(group),resume=None,precontract=0,frontiers=request))
        expected=[{**z['r'],'leaf':[*z['r']['leaf'][:2],j]}
                  for nodes in group.values() for j,z in enumerate(nodes)]
        obtained=list(map(json.loads,output.read_bytes().splitlines()))
        assert obtained==expected
        reports[str(goal)]=dict(complete_roots_with_slice=list(group),boxes={k:len(z)for k,z in group.items()},
            visits=sum(z['out'][1]for z in obtained),arithmetic_sha256=sha256(output.read_bytes()).hexdigest())
    answer=dict(source_sha256=sha256(source.read_bytes()).hexdigest(),thresholds=reports)
    a.output.write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps(answer),flush=True)


if __name__=='__main__':
    main()

"""Join the authenticated five-body exterior to the globally closed nine-input ledger."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

EXTERIOR={
    'records/retained.json':'06c7b4202f85d404c5e04cd53d19f4e4bd51a81da8e355e85f1f05a2913dcbc0',
    'records/layers-audit.json':'9ece68a7a31248c287cdd40c32fca958f33b72ba8ff09487f4aa665bbb8bf077',
    'records/base-report.json':'7240df495f163ed93da55ee733e6b9b178de3b64f7c1c85ee3a1d7408264d152',
    'records/merged45-report.json':'81bab0c38c561b4c0192c9e67f4ff33a43eee855e4d9c75a75553c2d7fd7b589',
    'records/root50.json':'8f3d7612fc76fc8403d5c987cbe9e59c890e4118e4b2d5fa748d99dd29759589',
    'records/stage-ledger.json':'3e83c009e5776e2af17be09d3d712d0cd5bc83236df439ed02cb83559fec1dd9',
    'volumes/seed50.zip':'9738fff07eaed42db51bf27839e4ed76c457ade80d7a1e5352efb9f0e5c31905',
    'volumes/screen1.zip':'b78fa27548a7fc95c269d1901418aa6016a5a2e2619e9ee3e1d073eeabcceb9e',
    'volumes/screen2.zip':'d987d17b50ec3f37c04e9b6682952658096501943e60375cb3abb602ce066edc',
    'volumes/screen3.zip':'5f87230a15f255984260750a43753bbcfe0ac0308ce616d05c4016bb95530437',
    'volumes/screen4.zip':'902f6b22beac1a28a5e07236535285c7e26d570845db033dd8fb544bfbedfc0f',
}
ROOT_MANIFEST='56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410'
FINITES=['augmented_P128','physical_old_Q11','new_Q11','P152_interior15']


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    p=ArgumentParser(description=__doc__)
    for x in ('comp','tree','r248','r4plus','ledger','output'):
        p.add_argument(x,type=Path)
    a=p.parse_args()
    ext=a.comp/'global-083750'
    for name,pin in EXTERIOR.items():
        assert digest(ext/name)==pin,name
    assert digest(a.tree/'SHA256SUMS')==ROOT_MANIFEST
    assert (ext/'records/retained.json').read_bytes()==(a.r248/'stage4-retained.json').read_bytes()
    outer=subprocess.check_output([sys.executable,'-B',str(ext/'audit_root50.py'),str(a.comp),str(a.tree)])
    assert outer==(ext/'records/root50.json').read_bytes()
    base=read(ext/'records/base-report.json')
    trace=read(ext/'records/layers-audit.json')
    core={f'{k}/{i}'for k,v in read(ext/'records/retained.json').items()for i in v}
    assert len(core)==5442 and set(read(a.r4plus)['proof_masks_by_leaf'])==core
    assert trace['seed']==699060 and [z['remaining']for z in trace['layers']]==[136243,22418,8792,5442]
    canonical=base['canonical_leaves']
    assert canonical==6710314 and trace['complete_four_layers']
    led=read(a.ledger)
    row=led['focal']['nine_P128_physical_Q_new_Q_P152']
    assert row['inputs']==FINITES and row['total_shapes']==9
    assert led['strict'] and led['original_leaves']==5442
    g=row['thresholds']['.83747']
    assert g['closed']==len(core) and g['remaining']==0 and g['unresolved']==[]
    for src in led['receipts_by_leaf']['1201/73612']:
        if src['source']=='r6-deep-03':
            assert src['target']==src['parent_target']=='67/80' and src['inputs']==['physical_old_Q11']
            final_root=src
            break
    else:
        raise AssertionError('last root')
    den=2**57
    target=Fraction('.83747')
    dyadic=(target*den).__floor__()+1
    assert dyadic==120692146557887018
    area=Fraction(dyadic,den)
    assert area>target
    result=dict(strict=True,threshold=str(target),integer_area_numerator=dyadic,
        integer_area_denominator=den,lower_bound=str(area),strict_rational_margin=str(area-target),
        true_disk_and_reuleaux_orders=[3,5,7,9],finite_inputs=FINITES,
        original_tree_manifest_sha256=ROOT_MANIFEST,canonical_leaves=canonical,
        exterior_high_certified=canonical-len(core),core_full_originals=len(core),
        last_core_root=final_root,exterior_source_sha256=EXTERIOR,ledger_sha256=digest(a.ledger))
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print('nine physical inputs support area at least',area,'on all',canonical,'canonical leaves',flush=True)


if __name__=='__main__':
    main()

"""Directed support-loss decisions following the five-arc odd-mesh estimate of R242."""
from fractions import Fraction
from pathlib import Path
from flint import arb,ctx
import argparse
import json

S=2**57
T=Fraction('.83747')
G=Fraction((S*T).__floor__()+1,S)


def exact(x):
    return arb(x.numerator)/x.denominator


def lower(n):
    x=arb.pi()/n
    return exact(G)*(x.cos()/(x/2).cos())**2


def count(t):
    lo,hi=50,50
    def accept(i):
        b=lower(2*i+1)
        if b>exact(t):
            return True
        assert b<exact(t)
        return False
    while not accept(hi):
        hi*=2
    while lo<hi:
        mid=(lo+hi)//2
        if accept(mid):
            hi=mid
        else:
            lo=mid+1
    n=2*lo+1
    assert accept(lo) and (lo==50 or not accept(lo-1))
    return n,lower(n).str(53)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    ctx.prec=256
    targets=('.83746','.837465','.837469','.8374699','.83746999','.83747')
    rows=[]
    for k in targets:
        n,bound=count(Fraction(k))
        rows.append(dict(target=k,first_odd_n=n,rigorous_bound=bound))
    out=dict(floor=str(G),margin=str(G-T),rows=rows,precision_bits=256)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()

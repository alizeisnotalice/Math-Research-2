"""Schedule only still-open frontier boxes of the most advanced original roots."""
from argparse import ArgumentParser
from collections import defaultdict
import json
from pathlib import Path


def read(p):
    return json.loads(p.read_bytes())


def records(p):
    return [json.loads(line) for line in p.read_bytes().splitlines()]


def main(a):
    initial=read(a.initial)
    by_leaf=defaultdict(list)
    for row in records(a.receipts):
        leaf='/'.join(map(str,row['leaf'][:2]))
        assert row['target']=='67/80'
        by_leaf[leaf].append(row)
    prior_stage=set()
    for packets_path,receipts_path in a.continuation:
        packets=read(packets_path)
        prior_rows=defaultdict(list)
        for row in records(receipts_path):
            prior_rows['/'.join(map(str,row['leaf'][:2]))].append(row)
        for packet in packets:
            leaf=packet['leaf']
            prior_stage.add(leaf)
            dest=by_leaf[leaf]
            for original,row in zip(packet['origin_indices'],prior_rows.pop(leaf),strict=True):
                assert not dest[original]['out'][0]
                dest[original]={**row,'leaf':[*row['leaf'][:2],original]}
        assert not prior_rows
    candidates=[]
    for p in initial:
        leaf=p['leaf']
        rows=by_leaf.pop(leaf)
        assert len(rows)==len(p['regions']) and [r['leaf'][2] for r in rows]==list(range(len(rows)))
        missing=[j for j,r in enumerate(rows) if not r['out'][0]]
        if missing and (not prior_stage or leaf in prior_stage):
            candidates.append((len(missing),len(rows),leaf,p,missing))
    assert not by_leaf
    chosen=sorted(candidates)[:a.count]
    by_name=sorted(chosen,key=lambda v:tuple(map(int,v[2].split('/'))))
    packets=[{**p,'regions':[p['regions'][j] for j in missing],'origin_indices':missing}
             for _,_,_,p,missing in by_name]
    a.output.write_text(json.dumps(packets,separators=(',',':'))+'\n')
    print('roots',len(packets),'boxes',sum(len(x['regions']) for x in packets),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('initial','receipts','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--count',type=int,default=24)
    p.add_argument('--continuation',type=Path,nargs=2,action='append',default=[])
    main(p.parse_args())

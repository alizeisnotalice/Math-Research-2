"""Choose unreserved exact R248 frontier groups from the frozen 519-leaf census."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from math import prod
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def main(a):
    open_leaves=read(a.ledger)['model_census']['all_archived_inputs']['unresolved']
    assert len(open_leaves)==519
    q48=read(a.q48)
    assert len(q48)==17
    reserved=set()
    for path in a.reserved:
        reserved.update(read(path))
    usable=set(open_leaves)-reserved
    choices={}
    for path in sorted((a.r248/'refined').glob('refined-*.jsonl')):
        for row in map(json.loads,path.read_bytes().splitlines()):
            leaf=row['leaf']
            if leaf not in usable:
                continue
            assert row['threshold_integer']==120696470013529293
            assert row['stats'][0]==0 and row['stats'][7]==1 and row['stats'][5]==0
            front=path.stem+'/'+leaf.replace('/','-')+f"-mode{row['mode']}-frontier.json"
            source=a.r248/'refined/frontiers'/front
            regions=read(source)
            assert len(regions)==row['pending']>0
            simple_volume=lambda b:prod(y-x for x,y in b)
            fraction=Fraction(sum(simple_volume(z['bounds']) for z in regions),
                              simple_volume(zip(row['lo'],row['hi'],strict=True)))
            data=dict(leaf=leaf,source=front,digest=sha256(source.read_bytes()).hexdigest(),regions=regions)
            score=(leaf not in q48,len(regions),fraction,leaf)
            if leaf not in choices or score<choices[leaf][0]:
                choices[leaf]=(score,data)
    assert set(choices)==usable
    groups=[]
    for part in ('181','1201','1205'):
        pool=sorted(v for k,v in choices.items() if k.startswith(part+'/'))
        groups.extend(v[1] for v in pool[:a.per_part])
    groups.sort(key=lambda p:tuple(map(int,p['leaf'].split('/'))))
    a.output.write_text(json.dumps(groups,separators=(',',':'))+'\n')
    print('available',len(usable),'reserved',len(set(open_leaves)&reserved),
          'picked',Counter(x['leaf'].split('/')[0] for x in groups),
          'boxes',sum(len(x['regions']) for x in groups),
          'lower overlap',sum(x['leaf'] in q48 for x in groups),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('r248','ledger','q48','output'):
        p.add_argument(key,type=Path)
    p.add_argument('--per-part',type=int,default=14)
    p.add_argument('--reserved',type=Path,nargs='*',default=[])
    main(p.parse_args())

"""Bind the physical-Q MacBook proof stages to exact R248 original roots."""
from argparse import ArgumentParser
from collections import Counter
from functools import lru_cache
from hashlib import sha256
from importlib.util import spec_from_file_location,module_from_spec
import json
from pathlib import Path
import sys

STAGES=(('dispatch','results'),('dispatch-02','results-02'),('dispatch-03','results-03'),
        ('dispatch-cont','results-cont'),('dispatch-more','results-more'),
        ('dispatch-deep','results-deep'),('dispatch-last','results-last'))
INITIAL=('dispatch-181-mac','dispatch-181-mac-02','dispatch-181-mac-03')
STAGES_120X=(('dispatch-120x','results-120x'),('dispatch-120x-cont','results-120x-cont'),
             ('dispatch-120x-contb','results-120x-contb'))
STAGES_120X_02=(('dispatch-120x-02','results-120x-02'),('dispatch-120x-02-cont','results-120x-02-cont'),
                ('dispatch-120x-02-deep','results-120x-02-deep'))

def read(p):return json.loads(p.read_bytes())
def dig(p):return sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(x) for x in p.read_bytes().splitlines()]

def main(a):
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import SourceTree,FINE
    tree=SourceTree(a.tree)
    s=spec_from_file_location('scope_248',a.r248/'audit_refined_scope.py')
    mod=module_from_spec(s);s.loader.exec_module(mod)
    data=a.mac
    if a.phase_family=='120x':
        stages,initial,sizes,top=STAGES_120X,('dispatch-1201-1205-mac',),(14,),194
        initial_phases=(frozenset(initial),)
    elif a.phase_family=='120x-02':
        stages,initial,sizes,top=STAGES_120X_02,('dispatch-1201-mac-02','dispatch-1205-mac-02'),(12,12),322
        initial_phases=(frozenset(initial),)
    elif a.phase_family in ('120x-03','120x-04'):
        number=a.phase_family[-2:]
        stages=tuple((f'dispatch-120x-{number}{suffix}',f'results-120x-{number}{suffix}')
                     for suffix in ('','-cont','-deep'))
        initial=(f'dispatch-1201-mac-{number}',f'dispatch-1205-mac-{number}')
        sizes=(18,18)
        top={'03':552,'04':534}[number]
        initial_phases=(frozenset(initial),)
    else:
        stages,initial,sizes,top=STAGES,INITIAL,(12,36,7),796
        initial_phases=tuple(frozenset((name,)) for name in initial)
    assert dig(a.comp/'multi-host-points.json')=='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
    assert all(dig(data/'inputs'/n/'q-original-angles.json')==
               'c956e535ab0ed2bdc0a289c388ce88cf7a26132a356b6adb2076b36d508ef93a' for n in initial)
    known={};events={};parents={};root_data={};expected_initial={}
    hashes={}
    def key_file(p):
        name=p.relative_to(data).as_posix()
        hashes[name]=dig(p)
        return p
    for n,expected in zip(initial,sizes,strict=True):
        directory=data/'inputs'/n
        keys=read(key_file(directory/'keys.json'))
        packet=read(key_file(directory/'packet.json'))
        assert keys==[v['leaf']for v in packet] and len(set(keys))==len(keys)==expected
        assert [b for x in packet for b in x['regions']]==read(key_file(directory/'subboxes.json'))
        for entry in packet:
            leaf=entry['leaf']
            assert leaf not in root_data
            parent_file=a.r248/'refined'/(entry['source'].split('/')[0]+'.jsonl')
            if parent_file not in parents:
                rec=read(parent_file.with_name(parent_file.stem+'-receipt.json'))
                digest=dig(parent_file)
                assert rec['complete'] and digest==rec['result_sha256']
                parents[parent_file]=(digest,{r['leaf']:(i,r) for i,r in enumerate(lines(parent_file),1)})
            digest,h=parents[parent_file]
            line,y=h[leaf]
            assert y['leaf']==y['label']==leaf and y['goal']=='67/80' and y['threshold_integer']==120696470013529293
            r=tree.leaf(*map(int,leaf.split('/')))
            assert all(l*FINE==a and h*FINE==b for (l,h),(a,b) in zip(r,zip(y['lo'],y['hi'],strict=True),strict=True))
            s=y['stats']
            assert s[0]==s[3]==s[5]==y['pending_visited']==y['guards']==y['center_stops']==0
            assert s[7]==1 and s[4]>0 and s[1]==2*(s[2]+s[4])+y['pending']-1
            front=a.r248/'refined/frontiers'/entry['source']
            assert dig(front)==entry['frontier_sha256'] and read(front)==entry['regions']
            assert mod.audit_paths(y,entry['regions'])>0
            for b in entry['regions']:
                assert b['label'] not in known
                known[b['label']]=b
                expected_initial[b['label']]=n
            root_data[leaf]=(entry,y,dict(parent_file=parent_file.name,parent_line=line,
                  parent_sha256=digest,frontier=entry['source'],frontier_sha256=dig(front)))
    assert len(root_data)==sum(sizes) and len(expected_initial)==top
    execution={}
    for phase,(dispatch,result) in enumerate(stages):
        stage=Counter()
        for raw in sorted((data/result).glob('result-??.jsonl')):
            i=raw.stem[-2:]
            assert key_file(data/result/f'exit-{i}').read_text().strip()=='0'
            ids=read(key_file(data/dispatch/f'keys-{i}.json'))
            request=read(key_file(data/dispatch/f'subboxes-{i}.json'))
            assert ids==list(dict.fromkeys(a['leaf']for a in request))
            for sec,y in zip(request,lines(key_file(raw)),strict=True):
                key=y['label']
                assert known[key]==sec and key not in events and y['leaf']==sec['leaf']
                if phase<len(initial_phases):assert expected_initial[key] in initial_phases[phase]
                assert y['goal']=='67/80' and y['threshold_integer']==120696470013529293
                assert y['mode']==1 and y['q_mesh'] and y['panels']==256 and y['q_trigger_divisor']==4000
                assert y['shared_angles'] and y['edge_caps'] and y['shared_dense']
                assert sec['bounds']==[list(x)for x in zip(y['lo'],y['hi'],strict=True)]
                s=y['stats'];p=y['pending'];pv=y['pending_visited']
                assert s[3]==s[5]==y['guards']==y['center_stops']==0
                assert s[0] in (0,1) and s[0]==int(not p) and 0<=pv<=p
                assert 1<=s[1]<=y['budget'] and s[1]==2*(s[2]+s[4])+p-1+pv
                f=data/result/f'front-{i}.json'/(key.replace('/','-')+'-mode1-frontier.json')
                ch=read(key_file(f));assert len(ch)==p
                if ch:
                    local=[]
                    for j,z in enumerate(ch):
                        prefix=sec['steps'];actual=z['steps']
                        assert actual[:len(prefix)]==prefix and z['label'] not in known
                        known[z['label']]=z
                        local.append({**z,'steps':actual[len(prefix):],'label':f"{y['leaf']}-{j}"})
                    assert mod.audit_paths(y,local)>0
                stage['boxes']+=1;stage['direct_closed']+=s[0];stage['visits']+=s[1]
                events[key]=(s[1],s[2],s[4],pv,[z['label']for z in ch])
        execution[result]=stage
    assert set(events)==set(known)
    used=set()
    @lru_cache(maxsize=None)
    def fold(key):
        used.add(key)
        n,f,o,pv,child=events[key]
        for label in child:
            v,t,q=fold(label)
            n+=v;f+=t;o+=q
        n-=pv
        assert n==2*(f+o)-1
        return n,f,o
    data_out={}
    for leaf,(entry,row,link) in root_data.items():
        s=row['stats']
        n,f,q=s[1],s[2],s[4]
        for b in entry['regions']:
            x,y,z=fold(b['label']);n+=x;f+=y;q+=z
        assert n==2*(f+q)-1 and q>0
        data_out[leaf]=dict(inputs=['physical_old_Q11'],nodes=n,five_terminals=f,old_q_terminals=q,
                            top_frontiers=len(entry['regions']),**link)
    assert used==set(events)
    out=dict(strict=True,target='67/80',scope=len(root_data),proved=data_out,arithmetic_stage_counts=execution,
             visited_original_subboxes=len(expected_initial),checked_tree_records=len(events),files_sha256=hashes)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(scope=len(data_out),first_level=len(expected_initial),checked_records=len(events),
                         arithmetic_visits=sum(z['visits']for z in execution.values()),
                         whole_tree_nodes=sum(z['nodes']for z in data_out.values()))),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','mac','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--phase-family',choices=('181','120x','120x-02','120x-03','120x-04'),default='181')
    main(p.parse_args())

"""Replay the whole-leaf ledger and optionally all native chord computations."""
from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
PINS={
    'R248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'R4':'49ee0eb63126b08733e88d5aa921aea2e51ca2eb0f4d7152e2d5711e508b9f86',
    'R4plus':'3ecfcebdfcab476b2250927d07432c37c45f66a325feb35d193f51831a6f7b90',
    'mac03':'8727a89d6e305f2f9fa5aade68dd46b5b73f3ac418f59fd834042791cf4ea916',
    'mac04':'1addfa6d69bd7b123b201bba543f4d4626061728e6784f948b562b624d18c5f1',
    'low48':'2eae08db27a31db614b990bbf70ac8f01a9e3f0dee9608c4c8c54978d020d4d0',
}
STAGES=(('frontiers-chord.json',2047),('saturation-24.json',32767),('saturation-10.json',131071))


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def extract(archive,name,root):
    assert digest(archive)==PINS[name],name
    with ZipFile(archive) as z:
        names=z.namelist()
        assert len(set(names))==len(names) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(root)


def run(*args):
    subprocess.run(list(map(str,args)),check=True)


def identical(a,b):
    assert a.read_bytes()==b.read_bytes(),a.name


def native(a,w,r4,bank,data):
    if not a.table or not a.cache:
        raise ValueError('--native requires --table and --cache')
    p128=r4/'evidence/p128'
    flags=['-O3','-std=c++17','-fsanitize=signed-integer-overflow',
           '-fsanitize-undefined-trap-on-error','-shared','-fPIC',
           f'-fmodules-cache-path={a.cache.resolve()}','-DNO_SPLIT_MASK']
    for label,src in (('old',p128/'ordinary-control.cpp'),('disk',HERE/'disk-chord-control.cpp')):
        lib=w/f'{label}-chord.dylib'
        run('clang++',*flags,'-I',a.comp/'three-leaf-083750',src,'-o',lib)
        for packet,cap in STAGES:
            f=data/packet
            keys=','.join(p['leaf'] for p in read(f))
            out=w/f'{label}-chord-{cap}.jsonl'
            run(sys.executable,'-B',p128/'run_native.py',a.comp,a.tree,a.table,
                lib,bank,out,'--frontiers',f,'--only',keys,'--caps','--mesh','--workers',a.workers,
                '--target','.83750','--cap',cap)
            identical(out,data/out.name)


def main(a):
    w=a.work.resolve()
    w.mkdir(parents=True,exist_ok=False)
    extract(a.r248,'R248',w/'r248')
    extract(a.r4,'R4',w/'r4')
    extract(a.r4plus,'R4plus',w/'r4plus')
    r248=w/'r248/public-replay-r2-083750'
    r4=w/'r4/public-replay-r4-083750'
    base=w/'r4plus/public-r4-followup-083750/frozen/ledger.json'
    data=w/'auditable-inputs'
    data.mkdir()
    for file in (HERE/'frozen').iterdir():
        if file.name!='wave-ledger.json':
            copyfile(file,data/file.name)

    for n in ('03','04'):
        source=w/f'mac-{n}'
        extract(HERE/'evidence'/f'mac-1201-1205-replay-{n}.zip',f'mac{n}',source)
        report=data/f'mac-{n}-audit.json'
        run(sys.executable,'-I','-B',HERE/'audit_mac_full.py',a.comp.resolve(),a.tree.resolve(),
            r248,source,report,'--phase-family','120x-'+n)
        identical(report,HERE/'frozen'/report.name)

    low=w/'low48'
    extract(HERE/'evidence/seventeen-originals48.zip','low48',low)
    out=w/'wave-ledger.json'
    run(sys.executable,'-I','-B',HERE/'audit_wave.py',a.comp.resolve(),a.tree.resolve(),
        r248,base,data,low,out)
    identical(out,HERE/'frozen'/out.name)

    bank=w/'physical-bank.json'
    bank.write_bytes(decompress((r4/'evidence/physical-q-bank/physical-bank.json.gz').read_bytes()))
    assert digest(bank)=='97d2d0c35d74dedb0577ac4d9311e1bf9cdb0cd827fdadae07a86d70438f0223'
    if a.native:
        native(a,w,r4,bank,data)
    print('reproduced all 256 models at each threshold; native rows verified by replay' if a.native
          else 'reproduced all 256 models at each threshold from frozen arithmetic rows',flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','r4','r4plus','work'):
        p.add_argument(name,type=Path)
    p.add_argument('--native',action='store_true')
    p.add_argument('--table',type=Path)
    p.add_argument('--cache',type=Path)
    p.add_argument('--workers',type=int,default=4)
    main(p.parse_args())

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,gzip,math,random
from flint import arb,ctx
import diam,geom
W=Path(__file__).resolve().parent;ctx.prec=192;report=json.loads((W/'report.json').read_text());raw=(W/'rational-nine-837469998.json.gz').read_bytes();assert sha256(raw).hexdigest()==report['point_file_sha256'];groups=json.loads(gzip.decompress(raw));S=report['coordinate_scale'];pi=arb.pi()
# Axis algorithm is independently checked on small random and full P/Q brute-force cases.
rng=random.Random(20261119)
for _ in range(300):
 pts=list({(rng.randrange(-10000,10001),rng.randrange(-10000,10001)) for j in range(rng.randrange(3,80))});b=max(((x-u)**2+(y-v)**2) for x,y in pts for u,v in pts);assert diam.axis_max(pts)[0]==b
checks=[]
for group,row,n in zip(groups[:5],report['rows'][:5],(0,3,5,7,9)):
 a,b=row['integer_axis'];sq=int(row['integer_diameter_squared']);den=group['denominator'];assert a*a+b*b==sq==den
 rawpts=[]
 for X,Y in group['points']:
  xx=a*X-b*Y;yy=b*X+a*Y;assert xx%sq==yy%sq==0;rawpts.append((xx//sq,yy//sq))
 H=diam.hull(rawpts);assert len(H)>=3; maxsq,axis=diam.axis_max(rawpts);assert maxsq==sq
 if n:
  phase=2*math.pi/n; R=1/(2*(pi/(2*n)).cos()); smid=(pi/(2*n)).sin();sm= (pi/n).sin(); cm=(pi/n).cos()
  cs=[((2*j*pi/n).cos(),(2*j*pi/n).sin()) for j in range(n)]
 min_gap=None; branches={'vertex':0,'arc':0,'tie':0}
 for (x,y),(X,Y) in zip(H,H[1:]+H[:1]):
  dx,dy=X-x,Y-y; nx,ny=dy,-dx;L=arb(nx*nx+ny*ny).sqrt();B=arb(nx*x+ny*y)
  if n==0:h=L/2
  else:
   j=int(round(math.atan2(ny,nx)/phase))%n
   for other in ((j-1)%n,(j+1)%n):
    if nx*cs[other][0]+ny*cs[other][1]>nx*cs[j][0]+ny*cs[j][1]:j=other
   c,s=cs[j];dot=nx*c+ny*s;cross=ny*c-nx*s; ac=abs(cross)
   assert dot>0 and ac<(sm+arb('1e-30'))*L,('nearest',n,j)
   v=R*dot;arc=L-R*(cm*dot+sm*ac)
   if ac<smid*L: h=v;branches['vertex']+=1
   elif ac>smid*L:h=arc;branches['arc']+=1
   else:h=max(v,arc);branches['tie']+=1
   h+=arb('1e-25')*L # guards an endpoint shared with the adjacent symmetric sector
  gap=(B-(S-2)*h)/L
  assert gap>0,('support',n,str(gap))
  if min_gap is None or gap<min_gap:min_gap=gap
 checks.append({'shape':group['body'],'vertices':len(H),'support_minimum_lower_grid_units':str(min_gap.lower()),'branches':branches,'all_support_walls_verified':True})
 print('support',group['body'],len(H),str(min_gap.lower()),flush=True)
for group in groups[5:]:
 p=group['points'];exact=max((x-u)**2+(y-v)**2 for x,y in p for u,v in p);fast,_=diam.axis_max(p);assert exact==fast<group['denominator']**2
 checks.append({'shape':group['body'],'all_pairs':len(p)*(len(p)-1)//2,'brute_agrees':True,'diameter_below_one':True});print('checked',group['body'],flush=True)
(W/'support-verification.json').write_text(json.dumps({'precision_bits':192,'random_small_diameter_crosschecks':300,'all':checks,'point_sha256':sha256(raw).hexdigest()},indent=2)+'\n')

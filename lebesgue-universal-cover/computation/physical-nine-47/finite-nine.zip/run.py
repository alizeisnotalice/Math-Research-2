from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,gzip,platform,time,zipfile
import flint
from flint import arb,ctx
import geom,diam
W=Path(__file__).resolve().parent;ctx.prec=192;geom.S=10**21;geom.farthest=diam.axis_max
T=F('.837469998'); T0=F('.83747');G=F((T0*2**57).__floor__()+1,2**57);assert G>T0>T
upstream=W/'upstream/physical-nine-083747.zip'; assert sha256(upstream.read_bytes()).hexdigest()=='be111f57ac6af334e73476ce036e206499911224bde914e24ae8e56062ff22fd'
with zipfile.ZipFile(upstream) as z:
 raw=z.read('public-r6c-global-083747/frozen/global-theorem.json');assert sha256(raw).hexdigest()=='925b13b165ed6f1b31636e40482af22998aaa0600052abb7521933a17e4899d3';u=json.loads(raw)
 assert F(u['lower_bound'])==G and u['strict'] and u['finite_inputs']==['augmented_P128','physical_old_Q11','new_Q11','P152_interior15']
pinf={'P128':'13d9a52243efadcb2281aa60e41282349e3c4c64bc9925f9ad20ece8dab2ecb1','physical':'9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282','newQ':'45cb554f79d2c30f23cdc526f7cc1a333b6f98c3dbaa60234862d449bb66de05','P152':'fd28a8fb8beb00f3b30daa4b62fedc30753fb153a4143867d792cab66cba21c4'}
pi=arb.pi();target=geom.ar(T);ratio=geom.ar(T/G).sqrt()
def val(n):return geom.ar(G)*((pi/n).cos()/(pi/(2*n)).cos())**2
lo,hi=3,5
while val(hi)<target:hi=2*hi+1
while hi-lo>2:
 mid=(lo+hi)//4*2+1
 if val(mid)>target:hi=mid
 else:assert val(mid)<target;lo=mid
N=hi;assert N==55675 and val(N-2)<target<val(N)
rows=[];groups=[];t0=time.monotonic()
for n in (0,3,5,7,9):
 if n==0:k=N;step=2
 else:k=int((pi/(2*n*ratio.acos())).upper().ceil().unique_fmpz());step=1
 while True:
  cloud,sq,den,axis=geom.curve_points(n,k,pi);inner=F((geom.S-2)**2,sq)
  if G*inner>T:break
  k+=step
 sq2,_=diam.axis_max(cloud['points']);assert sq2==cloud['denominator']**2
 rows.append({'shape':cloud['body'],'grid':k,'count':len(cloud['points']),'inner_squared':str(inner),'inner_192':str(geom.ar(inner)),'integer_diameter_squared':str(sq),'integer_axis':axis,'exact_output_squared_diameter':'1','min_area_lower':str(G*inner)})
 groups.append(cloud);print('generated',cloud['body'],'k',k,'count',len(cloud['points']),'area',float(G*inner),flush=True)
for name,pin in pinf.items():
 raw=(W/f'inputs/{name}.json').read_bytes();assert sha256(raw).hexdigest()==pin
 data=json.loads(raw);den=data.get('denominator',data.get('point_denominator'));pts=data['points'];sq,axis=diam.axis_max(pts);assert sq<=den**2
 # exact P/Q inputs are preserved with no reflection averaging or modification
 groups.append({'body':name,'points':pts,'denominator':den});rows.append({'shape':name,'count':len(pts),'diameter_squared':str(F(sq,den*den)),'axis':axis,'source_sha256':pin})
inner=min(F(r['inner_squared']) for r in rows[:5]);bound=G*inner;assert bound>T
out=W/'rational-nine-837469998.json.gz';out.write_bytes(gzip.compress(geom.packed(groups),compresslevel=9,mtime=0))
report={'assumption':'physical nine-body theorem from the pinned upstream archive; its dependencies must be independently replayed','upstream_zip_sha256':sha256(upstream.read_bytes()).hexdigest(),'upstream_global_theorem_sha256':'925b13b165ed6f1b31636e40482af22998aaa0600052abb7521933a17e4899d3','G':str(G),'G_above_83747':str(G-T0),'target':str(T),'analytic_first_odd':N,'previous_odd_192':str(val(N-2)),'first_odd_192':str(val(N)),'coordinate_scale':geom.S,'rows':rows,'counts':[len(c['points']) for c in groups],'common_inner_squared':str(inner),'true_area_lower':str(bound),'decimal_down_24':geom.decimal_down(bound,24),'point_file_sha256':sha256(out.read_bytes()).hexdigest(),'precision_bits':ctx.prec,'python':platform.python_version(),'flint':flint.__version__,'seconds':time.monotonic()-t0}
(W/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report['counts'],report['decimal_down_24'],flush=True)

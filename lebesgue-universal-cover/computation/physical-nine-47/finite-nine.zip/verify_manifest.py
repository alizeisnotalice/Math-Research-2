from pathlib import Path
from hashlib import sha256
import json
W=Path(__file__).resolve().parent
for name,digest in json.loads((W/'SHA256.json').read_text()).items():
 assert sha256((W/name).read_bytes()).hexdigest()==digest,name
print('all archived files verified')

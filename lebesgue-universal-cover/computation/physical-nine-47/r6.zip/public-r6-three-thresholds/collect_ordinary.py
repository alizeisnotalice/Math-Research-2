"""Verify the Qavg-only original trees and their authentic R248 prefix sources."""
from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path
import subprocess
import sys

from audit_wave import Roots, digest, load, lines


def main():
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','ordinary','work','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    a.work.mkdir(parents=True,exist_ok=False)
    o=a.ordinary
    report=a.work/'ordinary-high.json'
    subprocess.run([sys.executable,'-I','-B',str(o/'audit_scope.py'),*map(str,(a.comp,a.tree,
        o/'inputs/first',report)),'--target','.83750','--phase',str(o/'inputs/first'),str(o/'results/high50'),
        '--phase',str(o/'inputs/tail50'),str(o/'results/tail50')],check=True)
    assert digest(report)==digest(o/'status-50-complete.json')=='d19a69a02f3ea248554ffc6f504161e28cc98d1bf48dbd50ce6c085a69fc9ef6'
    scope=load(report)
    assert scope['target']=='67/80' and scope['complete_roots']==scope['roots']==45 and not scope['remaining']
    assert scope['visits']['p66']==0 and scope['visits']['qavg']>0
    roots=Roots(a)
    pinned={}
    for rec in (a.r248/'refined').glob('refined-*-receipt.json'):
        receipt=load(rec)
        file=rec.with_name(rec.name.removesuffix('-receipt.json')+'.jsonl')
        assert digest(file)==receipt['result_sha256']
        pinned[receipt['result_sha256']]=file
    counts={}
    for stage in ('high50','tail50'):
        for result in sorted((o/'results'/stage).glob('batch-*.jsonl')):
            for row in lines(result.read_bytes()):
                leaf=row['leaf']
                s=row['stats']
                assert s[3]==s[5]==0 and row['q_family']=='Qavg_exact'
                counts.setdefault(leaf,Counter()).update(five=s[2],qavg=s[4],visits=s[1],
                                                          revisited=row['pending_visited'])
    out=[]
    orig=load(o/'inputs/first/origins.json')
    assert set(orig)==set(counts)==set(scope['integer_floors'])
    for k,origins in orig.items():
        path=pinned[origins['source_sha256']]
        f=a.r248/'refined/frontiers'/path.stem/(k.replace('/','-')+'-mode1-frontier.json')
        packet=dict(leaf=k,source=f.relative_to(a.r248/'refined/frontiers').as_posix(),
            regions=origins['frontier'],digest=origins['frontier_sha256'])
        link,row=roots.verify(packet)
        assert row==origins['parent'] and row['stats'][3]==0
        terminal_five=row['stats'][2]+counts[k]['five']
        terminal_qavg=row['stats'][4]+counts[k]['qavg']
        nodes=row['stats'][1]+counts[k]['visits']-counts[k]['revisited']
        assert nodes==2*(terminal_five+terminal_qavg)-1
        link['parent_source']=link.pop('source')
        inputs=['average_Q11'] if terminal_qavg else []
        out.append(dict(leaf=k,source='ordinary-Qavg',target='67/80',inputs=inputs,
            avg_transfer=False,integer_floor=scope['integer_floors'][k],nodes=nodes,
            terminal_five=terminal_five,terminal_qavg=terminal_qavg,**link))
    assert sum(not x['inputs'] for x in out)==8
    data=dict(proved=out,audit=dict(scope=45,actual_family=['average_Q11'],results=scope['uses'],
             pure_five_originals=8,raw_counts=scope['visits'],report_sha256=digest(report)))
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    print('authenticated all 45 full R248 roots with exact Qavg only',flush=True)


if __name__=='__main__':
    main()

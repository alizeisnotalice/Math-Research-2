"""Replay the independent R6 ledger, with optional Arb and native split-axis checks."""
from argparse import ArgumentParser
from pathlib import Path
import os
import subprocess
import sys

from collect import extract
from audit_wave import digest,load

HERE=Path(__file__).resolve().parent
PINS={
    'r248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'r251':'84f8de1fed4a4e116601ff511a212de04f586767e935a77161401f13fa5ba169',
    'r4':'49ee0eb63126b08733e88d5aa921aea2e51ca2eb0f4d7152e2d5711e508b9f86',
    'r4plus':'3ecfcebdfcab476b2250927d07432c37c45f66a325feb35d193f51831a6f7b90',
    'r5':'e06073af59738402181b27aa8214c210a20100b651b35c35809d0d393bab0562',
    'r597':'eb2dec682d277c423e834a9f4443afc5cd11067fed5990dd80af4a9b02ced094',
    'ordinary':'636e988205dedb23b1360afa336147d473b7c2f03dc63e21dbf8c39cca4d7722',
    'nine':'19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467',
}


def execute(*args,env=None):
    subprocess.run(list(map(str,args)),check=True,env=env)


def match_points(kit,files):
    meta=load(kit/'sources.json')
    for name,path in files.items():
        cloud=load(path)
        assert digest(path)==meta['public_source_sha256'][name]
        denominator=cloud.get('denominator',cloud.get('point_denominator'))
        assert load(kit/(name+'.json'))==dict(points=cloud['points'],denominator=denominator)


def checks(a,w,r248,kit,donors):
    if not a.table or not a.cache:
        raise ValueError('--math needs --table and --cache')
    execute(sys.executable,'-B',kit/'prepare.py',kit,w/'verified-banks')
    compiler_flags=['-O3','-std=c++17','-fsanitize=signed-integer-overflow',
        '-fsanitize-undefined-trap-on-error','-shared','-fPIC',
        '-fmodules-cache-path='+str(a.cache.resolve())]
    axial=w/'trace-branch.dylib'
    env=dict(os.environ,TMPDIR=str(w))
    execute('clang++',*compiler_flags,'-I',a.comp/'three-leaf-083750',kit/'frontier-path.cpp','-o',axial,env=env)
    execute(sys.executable,'-B',donors/'forest-first/replay_forest.py',r248,'--trace',
        '--kit',kit,'--comp',a.comp,'--tree',a.tree,'--table',a.table,
        '--axial',axial,'--scratch',w/'trace-forest')


def run(a):
    w=a.work.resolve()
    w.mkdir(parents=True,exist_ok=False)
    for name in ('r248','r251','r4','r4plus','r5','r597'):
        extract(getattr(a,name),PINS[name],w/name)
    r248=w/'r248/public-replay-r2-083750'
    r251=w/'r251/public-replay-r3-083750'
    r4=w/'r4/public-replay-r4-083750'
    r4plus=w/'r4plus/public-r4-followup-083750/frozen/ledger.json'
    r5=w/'r5/public-r5-083750/frozen/wave-ledger.json'
    r597=w/'r597/public-r5-pool-first97/frozen/ledger.json'
    ordinary=w/'ordinary'
    kit=w/'nine'
    sources=HERE/'frozen-sources'
    extract(sources/'portable-1205-083750.zip',PINS['ordinary'],ordinary)
    extract(sources/'nine-replay-kit.zip',PINS['nine'],kit)
    match_points(kit,{'p128':r4/'evidence/p128/inputs/augmented.json',
        'physical-q':a.comp/'multi-host-points.json','distinct-q':r251/'new-q-package/new-points.json',
        'p15':r4/'evidence/p152/points-greedy15.json'})
    donor_dir=w/'donors'
    new=w/'rows-mac-donors.json'
    ordinary_rows=w/'rows-ordinary.json'
    out=w/'r6-ledger.json'
    execute(sys.executable,'-B',HERE/'collect.py',a.comp,a.tree,r248,r597,sources,donor_dir,new)
    execute(sys.executable,'-B',HERE/'collect_ordinary.py',a.comp,a.tree,r248,ordinary,
            w/'audit-ordinary',ordinary_rows)
    execute(sys.executable,'-B',HERE/'integrate.py',r4plus,r5,r597,new,ordinary_rows,out)
    for path in (new,ordinary_rows,out):
        assert path.read_bytes()==(HERE/'frozen'/path.name).read_bytes(),path.name
    if a.math:
        checks(a,w,r248,kit,donor_dir)
    print('R6 original-address coverage and all 256 fixed-input censuses reproduced',flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','r251','r4','r4plus','r5','r597','work'):
        p.add_argument(name,type=Path)
    p.add_argument('--math',action='store_true')
    p.add_argument('--table',type=Path)
    p.add_argument('--cache',type=Path)
    a=p.parse_args()
    for name,value in vars(a).items():
        if isinstance(value,Path):
            setattr(a,name,value.resolve())
    run(a)

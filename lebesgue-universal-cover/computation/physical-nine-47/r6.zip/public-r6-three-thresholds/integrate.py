"""Compute threshold-specific proof masks and source intersections on the 5,442 originals."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

from audit_wave import load, order, digest

P='original_P30'
R='replacement_P30'
C='reduced_P66'
D='augmented_P128'
Q='physical_old_Q11'
A='average_Q11'
N='new_Q11'
W='P152_interior15'
HIGH=Fraction(67,80)
MID=Fraction('.83748')
LOW=Fraction('.83747')
LEVELS=(HIGH,MID,LOW)
FOCUS={
    'five_curves':(),
    'six_P30':(P,),
    'six_replacement30':(R,),
    'six_P66':(C,),
    'six_P128':(D,),
    'six_physical_Q':(Q,),
    'six_Qavg':(A,),
    'seven_original_P30_physical_Q':(P,Q),
    'seven_replacement_P30_physical_Q':(R,Q),
    'seven_P66_physical_Q':(C,Q),
    'seven_P66_Qavg':(C,A),
    'seven_P128_physical_Q':(D,Q),
    'seven_P128_Qavg':(D,A),
    'eight_P128_physical_Q_new_Q':(D,Q,N),
    'eight_P128_Qavg_new_Q':(D,A,N),
    'eight_P128_physical_Q_P152':(D,Q,W),
    'eight_P128_Qavg_P152':(D,A,W),
    'nine_P128_physical_Q_new_Q_P152':(D,Q,N,W),
    'nine_P128_Qavg_new_Q_P152':(D,A,N,W),
}


def target_tag(x):
    return {HIGH:'.83750',MID:'.83748',LOW:'.83747'}[x]


def hash_keys(keys):
    return sha256(('\n'.join(order(keys))+'\n').encode()).hexdigest()


def entails(inputs):
    ans=set(inputs)
    if D in ans:
        ans.update((C,R,P))
    if C in ans:
        ans.update((R,P))
    if R in ans:
        ans.add(P)
    return ans


def append(proofs,key,source,target,inputs,avg_transfer=False):
    needed=frozenset(inputs)
    proofs[key].append((Fraction(target),needed,source))
    if avg_transfer and Q in needed:
        # A source-specific support-row comparison can permit Qavg. The
        # refined physical-only bank used by the new common-angle kernel
        # has its own rows and does not inherit this permission.
        proofs[key].append((Fraction(target),needed-{Q}|{A},source))


def open_at(proofs,inputs,goal):
    allowed=entails(inputs)
    return {k for k,options in proofs.items() if not any(g>=goal and p<=allowed for g,p,_ in options)}


def baseline(r4plus,r5,r597):
    a,b,c=map(load,(r4plus,r5,r597))
    assert digest(r4plus)=='012aabbbbfab9adf1511277fadb40d22827b74db3f74d55841111d05ca057900'
    assert a['scope']==b['original_leaves']==5442 and len(c['new'])==97
    proofs={k:[] for k in a['proof_masks_by_leaf']}
    for k,records in a['proof_masks_by_leaf'].items():
        for x in records:
            append(proofs,k,'R4plus/'+x['source'],HIGH,x['required'],True)
    for label in ('mac72','local_native'):
        for k,x in b[label].items():
            append(proofs,k,'R5/'+label,HIGH,x['inputs'],True)
    for k,x in b['lower_sources'].items():
        append(proofs,k,'R5/physical17',MID,x['inputs'],True)
    for k,x in c['new'].items():
        append(proofs,k,'R5+97',HIGH,x['inputs'],True)
    for tag,data in c['models'].items():
        for goal,prefix in ((HIGH,'high'),(MID,'lower')):
            remaining=open_at(proofs,data['inputs'],goal)
            assert len(remaining)==data[prefix+'_remaining'],(tag,prefix)
            if prefix+'_unresolved_sha256' in data:
                assert hash_keys(remaining)==data[prefix+'_unresolved_sha256'],(tag,prefix)
            if prefix+'_unresolved' in data:
                assert order(remaining)==data[prefix+'_unresolved'],(tag,prefix)
    return proofs,c


def analyze(a):
    base,prev=baseline(a.r4plus,a.r5,a.r597)
    old={k:tuple(v) for k,v in base.items()}
    new=load(a.collected)
    events=[]
    for k,v in new['mac']['proved'].items():
        assert v['inputs']==[Q] and v['avg_transfer'] and Fraction(v['target'])==HIGH
        assert k not in prev['new']
        events.append(dict(v,leaf=k))
    events.extend(new['direct']['proved'])
    ordinary=load(a.ordinary)
    events.extend(ordinary['proved'])
    groups=defaultdict(set)
    by_leaf=defaultdict(list)
    for v in events:
        k=v['leaf'];source=v['source']
        assert k in base
        assert Fraction(v['target']) in LEVELS
        append(base,k,source,v['target'],v['inputs'],v['avg_transfer'])
        groups[source].add(k)
        by_leaf[k].append(v)

    models={}
    for tag,data in prev['models'].items():
        inputs=data['inputs']
        rows={}
        for g in LEVELS:
            left=open_at(base,inputs,g)
            before=open_at(old,inputs,g)
            assert left<=before
            rows[target_tag(g)]=dict(closed=5442-len(left),remaining=len(left),
                                    newly_closed=len(before-left),unresolved_sha256=hash_keys(left))
        models[tag]=dict(inputs=inputs,thresholds=rows)
    focal={}
    for label,inputs in FOCUS.items():
        rows={}
        for g in LEVELS:
            left=open_at(base,inputs,g)
            before=open_at(old,inputs,g)
            proven=before-left
            by_part=Counter(k.split('/')[0] for k in left)
            for k in proven:
                assert k in by_leaf
            rows[target_tag(g)]=dict(closed=5442-len(left),remaining=len(left),newly_closed=order(proven),
                unresolved=order(left),unresolved_per_shard=dict(sorted(by_part.items(),key=lambda v:int(v[0]))),
                unresolved_sha256=hash_keys(left))
        focal[label]=dict(inputs=list(inputs),total_shapes=5+len(inputs),thresholds=rows)
    # Preserve candidates that several calculations covered. Some have
    # different highest thresholds or use different independent point inputs.
    common={x+'|'+y:order(groups[x]&groups[y]) for x,y in combinations(sorted(groups),2)
            if groups[x]&groups[y]}
    major_groups={
        'MacPoolNew':set(new['mac']['proved']),
        'LowerGlobalDirect':{x['leaf'] for x in new['direct']['proved']},
        'OrdinaryQavg':{x['leaf'] for x in ordinary['proved']},
        'R5+97':set(prev['new']),
    }
    major={x+'|'+y:order(major_groups[x]&major_groups[y]) for x,y in combinations(major_groups,2)}
    return dict(strict=True,original_leaves=5442,thresholds=list(map(target_tag,LEVELS)),
        ordinary=ordinary['audit'],mac_summary=new['mac']['packages'],
        mac_total_pool_closed=new['mac']['total_pool_closed'],mac_pending_pool=new['mac']['pending_pool'],
        lower_global_direct_sources=new['direct']['packages'],common_angle=new['direct']['common_angle'],
        focal=focal,all_256=models,
        receipts_by_leaf={k:by_leaf[k] for k in order(by_leaf)},
        duplicate_source_pairs=common,duplicate_major_group_pairs=major,
        baseline_files_sha256={name:digest(p) for name,p in
                              (('R4plus',a.r4plus),('R5',a.r5),('R5plus97',a.r597))})


def main():
    p=ArgumentParser(description=__doc__)
    for k in ('r4plus','r5','r597','collected','ordinary','output'):
        p.add_argument(k,type=Path)
    a=p.parse_args()
    out=analyze(a)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    for k,r in out['focal'].items():
        print(k,[x['remaining']for x in r['thresholds'].values()],flush=True)


if __name__=='__main__':
    main()

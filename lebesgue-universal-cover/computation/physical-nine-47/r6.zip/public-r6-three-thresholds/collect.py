"""Validate and deduplicate additional proof trees against the exact R248 roots."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from gzip import decompress
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

from audit_pool_layers import verify_layers
from audit_wave import Roots, digest, load, order

Q='physical_old_Q11'
A='average_Q11'
D='augmented_P128'
P='original_P30'
N='new_Q11'
W='P152_interior15'
S='reduced_P66'
GOAL='67/80'


def extract(path,expected,dest):
    assert digest(path)==expected,path.name
    with ZipFile(path) as z:
        names=z.namelist()
        assert len(set(names))==len(names) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(dest)


def mac(a,roots):
    sources=a.sources
    pinned=load(sources/'mac-sources.json')
    pool_order=load(sources/'pool-order.json')
    assert len(pool_order)==len(set(pool_order))==229
    earlier=load(a.baseline)['new']
    assert len(earlier)==97
    out={}
    checked={}
    occupied=set()
    for spec in pinned:
        tag=spec['package'].removesuffix('.zip')
        expected=spec['roots']
        assert set(expected).isdisjoint(occupied) and len(expected)==spec['count']
        assert expected==[pool_order[i] for i in spec['source_indices']]
        occupied.update(expected)
        if set(expected)<=earlier.keys():
            continue
        assert not set(expected)&earlier.keys(),tag
        root=a.work/tag
        extract(sources/spec['package'],spec['sha256'],root)
        if tag.startswith('pool-direct'):
            report=a.work/(tag+'-audit.json')
            subprocess.run([sys.executable,'-I','-B',str(Path(__file__).with_name('audit_mac.py')),
                            *map(str,(a.comp,a.tree,a.r248,root,report))],check=True,
                           stdout=subprocess.DEVNULL)
            de=load(report)
            assert list(de['proved'])==expected
            closed={}
            for k,row in de['proved'].items():
                row['parent_source']=row.pop('source')
                closed[k]={**row,'target':GOAL,'avg_transfer':True}
            counts=de['exact_counts']
            assert load(root/'source-indices.json')==spec['source_indices']
        else:
            closed,counts=verify_layers(roots,root,pool_order)
        assert list(closed)==expected
        for k,v in closed.items():
            assert v['inputs']==[Q]
            out[k]={**v,'source':tag,'archive_sha256':spec['sha256']}
        checked[tag]=dict(sha256=spec['sha256'],roots=expected,**counts)
    assert len(out)+len(earlier)==len(occupied)
    return dict(proved=out,packages=checked,
                total_pool_closed=len(occupied),pending_pool=order(set(pool_order)-occupied))


def direct(a,roots):
    """Reconstruct each reported full original domain and actual point dependencies."""
    out=[]
    packages={}
    profiles={}
    manifest=load(a.sources/'direct-sources.json')
    for info in manifest:
        name=info['file']
        source=a.work/Path(name).stem
        extract(a.sources/name,info['sha256'],source)
        forest=bool(info.get('forest'))
        if forest:
            subprocess.run([sys.executable,'-B',str(source/'replay_forest.py'),str(a.r248)],
                           check=True,stdout=subprocess.DEVNULL)
        entries=json.loads(decompress((source/('forest.json.gz' if forest else 'leaves.json.gz')).read_bytes()))
        audit_summary=load(source/'scope.json')
        histogram=Counter()
        winning=Counter()
        shared_keys=set()
        for k,e in entries.items():
            p=e['packet']
            link,parent=roots.verify(p)
            assert p['leaf']==k and parent==e['prefix']
            assert link['line']==e['line'] and digest(a.r248/e['r248_path'])==e['r248_sha256']
            stage=e['forest'] if forest else e['suffix']
            assert len(p['regions'])==len(stage)
            sg=parent['stats']
            total=Counter(dict(five=sg[2],original_P30=sg[3],physical_old_Q11=sg[4]))
            native_q=0
            level=[]
            nodes=0
            methods=Counter()
            def walk(items):
                for z in items:
                    yield z
                    if forest:
                        yield from walk(z['children'])
            invocations=0
            for z in walk(stage):
                invocations+=1
                row=z['r' if forest else 'receipt']
                s=row['out']
                hdr=row['leaf']
                assert hdr[:2]==list(map(int,k.split('/')))
                continuation=len(z['children']) if forest else 0
                assert bool(s[0])==(not continuation)==(row['front'] is None)
                assert s[1]==2*(s[2]+s[3])+continuation-1
                assert s[3]==sum(row[x] for x in ('P128','oldQ','newQ','P15'))
                level.append(Fraction(row['target']))
                assert level[-1] in {Fraction('.83747'),Fraction('.83748'),Fraction('.83750')}
                terms={D:row['P128'],Q:row['oldQ'],N:row['newQ'],W:row['P15'],'five':s[2]}
                total.update(terms)
                native_q+=row['oldQ']
                nodes+=s[1]
                methods[z['mode']]+=1
                if row.get('shared',0) or row.get('curved',0):
                    shared_keys.add(k)
                    winning.update(shared=row.get('shared',0),curved=row.get('curved',0))
            assert 2*sum(total.values())-1==nodes+sg[1]
            actual=sorted(x for x in (P,D,Q,N,W) if total[x])
            lower=str(min(level))
            q=audit_summary[k]
            assert q['target']==lower and q['new_visits']==nodes
            if forest:
                assert q['new_geometric_runs']==invocations and e['target']==lower
            else:
                assert q['boxes']==len(p['regions'])
            assert (total[D]+total[P],total[Q],total[N],total[W])==tuple(q['point_terminals_with_r248_prefix'][x]for x in ('P128','oldQ','newQ','P15'))
            link['parent_source']=link.pop('source')
            out.append(dict(leaf=k,source=name,archive_sha256=info['sha256'],target=lower,
                avg_transfer=native_q==0,inputs=actual,nodes=nodes+sg[1],native_nodes=nodes,
                terminals=dict(total),methods=dict(methods),**link))
            histogram[lower]+=1
        assert set(entries)==set(audit_summary)
        packages[name]=dict(sha256=info['sha256'],counts=histogram,leaves=order(entries))
        profiles[name]=dict(actual_common_angle_leaves=order(shared_keys),actual_terminal_counts=winning)
    return dict(proved=out,packages=packages,common_angle=profiles)


def main():
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','baseline','sources','work','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    a.work.mkdir(parents=True,exist_ok=False)
    roots=Roots(a)
    result=dict(mac=mac(a,roots),direct=direct(a,roots))
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print('new mac',len(result['mac']['proved']),'direct',len(result['direct']['proved']),
          'pool pending',len(result['mac']['pending_pool']),flush=True)


if __name__=='__main__':
    main()

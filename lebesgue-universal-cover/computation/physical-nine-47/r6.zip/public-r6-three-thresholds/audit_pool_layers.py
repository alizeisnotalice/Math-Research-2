"""Attach every frozen MacBook frontier path to an authenticated public R248 root."""
from collections import Counter


def verify_layers(roots,source,pool_order):
    from audit_wave import digest, lines, load

    inputs=source/'inputs/dispatch-1205-mac-pool'
    original=load(inputs/'packet.json')
    keys=load(source/'selected.json')
    indices=load(source/'source-indices.json')
    assert keys==[p['leaf'] for p in original]==load(inputs/'keys.json')
    assert keys==[pool_order[i] for i in indices]
    assert len(keys)==len(set(keys)) and len(keys)==len(set(indices))
    assert [r for p in original for r in p['regions']]==load(inputs/'subboxes.json')
    assert digest(inputs/'q-original-angles.json')=='c956e535ab0ed2bdc0a289c388ce88cf7a26132a356b6adb2076b36d508ef93a'
    parents={}
    boxes={}
    for p in original:
        link,row=roots.verify({**p,'digest':p['frontier_sha256']})
        assert row['stats'][3]==0 and row['stats'][4]>0
        parents[p['leaf']]=(p['regions'],link,row)
        for b in p['regions']:
            assert b['label'] not in boxes
            boxes[b['label']]=b
    pending=set(boxes)
    first_boxes=len(boxes)
    arithmetic=Counter()
    visits={}
    layers=sorted(k for k in source.glob('results-1205-pool*') if k.is_dir())
    assert 2<=len(layers)<=5
    for layer in layers:
        request=source/layer.name.replace('results-','dispatch-',1)
        completed=set()
        entries={}
        for receipt in sorted(layer.glob('result-*.jsonl')):
            i=receipt.stem.split('-')[-1]
            assert (layer/f'exit-{i}').read_text().strip()=='0'
            rs=lines(receipt.read_bytes())
            rs_expected=load(request/f'subboxes-{i}.json')
            assert load(request/f'keys-{i}.json')==list(dict.fromkeys(z['leaf'] for z in rs_expected))
            for b,y in zip(rs_expected,rs,strict=True):
                k=y['label']
                assert k in pending and k not in completed and boxes[k]==b and b['leaf']==y['leaf']
                assert b['bounds']==[list(t) for t in zip(y['lo'],y['hi'],strict=True)]
                assert y['threshold_integer']==120696470013529293 and y['goal']=='67/80'
                assert y['mode']==1 and y['panels']==256 and y['q_trigger_divisor']==4000
                assert y['q_mesh'] and y['shared_angles'] and y['shared_dense'] and y['edge_caps']
                s=y['stats']
                assert s[3]==s[5]==y['guards']==y['center_stops']==0
                n,f,q=s[1],s[2],s[4]
                p,pv=y['pending'],y['pending_visited']
                assert 0<=pv<=p and s[0]==int(not p) and n==2*(f+q)+p-1+pv
                assert 0<n<=y['budget']
                name=k.replace('/','-')+'-mode1-frontier.json'
                ch=load(layer/f'front-{i}.json'/name)
                assert len(ch)==p
                local=[]
                for j,c in enumerate(ch):
                    assert c['leaf']==b['leaf'] and c['label'] not in boxes
                    assert c['steps'][:len(b['steps'])]==b['steps']
                    local.append(dict(c,steps=c['steps'][len(b['steps']):],label=f"{b['leaf']}-{j}"))
                    boxes[c['label']]=c
                if local:
                    assert roots.audit.audit_paths(y,local)>0
                assert k not in visits
                visits[k]=(n,f,q,pv,[c['label'] for c in ch])
                completed.add(k)
                entries.update((c['label'],c) for c in ch)
                arithmetic.update(boxes=1,visits=n,direct_closed=s[0])
        assert completed
        pending=(pending-completed)|entries.keys()
    # A packaged stage can leave sibling boxes for a later stage. Every such
    # box must be present and exhausted by the end of the package.
    assert not pending and set(boxes)==set(visits)

    def fold(label):
        n,f,q,pv,ch=visits[label]
        for idx in ch:
            t,g,r=fold(idx)
            n+=t;f+=g;q+=r
        n-=pv
        assert n==2*(f+q)-1
        return n,f,q

    proved={}
    for key in keys:
        ps,link,row=parents[key]
        s=row['stats']
        n,f,q=s[1],s[2],s[4]
        for p in ps:
            t,g,r=fold(p['label'])
            n+=t;f+=g;q+=r
        assert n==2*(f+q)-1 and q>0
        link=dict(link)
        link['parent_source']=link.pop('source')
        proved[key]=dict(target='67/80',inputs=['physical_old_Q11'],
                        avg_transfer=True,nodes=n,terminals=dict(five=f,physical_old_Q11=q),**link)
    return proved,dict(first_frontiers=first_boxes,**arithmetic)

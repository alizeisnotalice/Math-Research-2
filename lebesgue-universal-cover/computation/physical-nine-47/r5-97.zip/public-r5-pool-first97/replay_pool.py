"""Attach the first 97 direct physical-Q roots to the frozen R5 census."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
SOURCES={
    'R248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'R4':'49ee0eb63126b08733e88d5aa921aea2e51ca2eb0f4d7152e2d5711e508b9f86',
    'R5':'e06073af59738402181b27aa8214c210a20100b651b35c35809d0d393bab0562',
    '01':'ebb1f485f00f494b855845748c691cbb6c731f2df62e76a327ba8d86261db48e',
    '02':'42508cd814b0b2e4cd48073235e6b0b0bfd3c3a9704eef225fcdc3897171b6ca',
    '03':'b337f9f79327028f9ecd3eb76993d5ec8da0a33a669c35f6526d2b542dfa5093',
    '04':'71030992f89ca240a90221d8d69a003aecff211b7adafc19deb5acc084329d0b',
    '05':'58db3a6463331f58496775a5431354543fe708fabf0e8d57c14588cee4cf391d',
    '06':'208aabe90f65b6df691adf2a5dfbfe1edd567178f98243f57a4c19f2dbcd351d',
}
PACKETS={'01':15,'02':20,'03':20,'04':12,'05':20,'06':10}


def read(path):
    return json.loads(path.read_bytes())


def verify_extract(archive,source,place):
    assert sha256(archive.read_bytes()).hexdigest()==SOURCES[source]
    with ZipFile(archive) as z:
        names=z.namelist()
        assert len(set(names))==len(names) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(place)


def integrate(ledger,reports):
    original=read(ledger)
    assert original['target']=='67/80' and original['strict']
    assert len(original['high_unresolved'])==435 and len(original['lower_unresolved'])==421
    scope=set(original['high_unresolved'])
    add={}
    counters=Counter()
    for report,expect in zip(reports,PACKETS.values(),strict=True):
        data=read(report)
        assert data['strict'] and data['target']=='67/80'
        assert len(data['proved'])==expect
        for k,v in data['proved'].items():
            assert k in scope and k not in add and k.startswith('1205/')
            assert v['inputs']==['physical_old_Q11']
            add[k]={**v,'report':report.name}
        counters.update(data['exact_counts'])
    assert counters=={'nodes':5471842,'closed_boxes':1494,'boxes':1494}
    assert set(add)<=set(original['lower_unresolved'])
    models={}
    for mask,m in original['fixed_models'].items():
        q={'physical_old_Q11','average_Q11'}&set(m['inputs'])
        count=len(add) if q else 0
        row=dict(inputs=m['inputs'],high_remaining=m['high_remaining']-count,
                 lower_remaining=m['lower_remaining']-count)
        for k in ('high','lower'):
            if k+'_unresolved' in m:
                old=m[k+'_unresolved']
                assert not q or set(add)<=set(old)
                new=[z for z in old if not(q and z in add)]
                assert len(new)==row[k+'_remaining']
                row[k+'_unresolved']=new
                row[k+'_unresolved_sha256']=sha256(('\n'.join(new)+'\n').encode()).hexdigest()
        models[mask]=row
    assert [models['44'][k+'_remaining'] for k in ('high','lower')]==[408,394]
    assert [models['d4'][k+'_remaining'] for k in ('high','lower')]==[338,324]
    return dict(target='67/80',strict=True,reuse_thresholds=original['reuse_thresholds'],new=add,
                source_ledgers=SOURCES,physical_old_q_counts=counters,models=models)


def run(a):
    w=a.work.resolve()
    w.mkdir(parents=True,exist_ok=False)
    for name,p in (('R248',a.r248),('R4',a.r4),('R5',a.r5)):
        verify_extract(p,name,w/name)
    source=w/'R248/public-replay-r2-083750'
    r4=w/'R4/public-replay-r4-083750'
    before=w/'R5/public-r5-083750/frozen/wave-ledger.json'
    reports=[]
    for n in PACKETS:
        data=w/f'pool-{n}'
        verify_extract(HERE/'evidence'/f'pool-direct-{n}.zip',n,data)
        report=w/f'audit-{n}.json'
        subprocess.run([sys.executable,'-I','-B',str(r4/'audit_mac.py'),str(a.comp.resolve()),
            str(a.tree.resolve()),str(source),str(data),str(report)],check=True)
        assert report.read_bytes()==(HERE/'frozen'/report.name).read_bytes()
        reports.append(report)
    total=json.dumps(integrate(before,reports),indent=2)+'\n'
    (w/'ledger.json').write_text(total)
    assert (w/'ledger.json').read_bytes()==(HERE/'frozen/ledger.json').read_bytes()
    print('97 physical-Q original roots reassembled; fixed seven 408, fixed nine 338')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','r4','r5','work'):
        p.add_argument(n,type=Path)
    run(p.parse_args())

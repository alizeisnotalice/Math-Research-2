"""Rebuild hash-locked compressed raw j32–39 receipts and run the .014 verifier."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import argparse,shutil,subprocess,sys
P=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('part_a',type=Path);p.add_argument('part_b',type=Path);p.add_argument('part_c',type=Path);p.add_argument('raw36',type=Path);p.add_argument('work',type=Path);p.add_argument('--partial',action='store_true');p.add_argument('--full',action='store_true');p.add_argument('--assemble-only',action='store_true');a=p.parse_args();assert not(a.partial and a.full);W=a.work.resolve();assert not W.exists() and not W.is_relative_to(P);W.mkdir(parents=True);K=W/'kit';shutil.copytree(P,K,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));D=K/'segments/j32_39';D.mkdir(parents=True,exist_ok=True)
parts=[(a.part_a,'dba4d471d5c2085da7c1ebb5a3f016111439c65a325e01951616139557488325','raw32-parts/part-aa'),(a.part_b,'9f77e3379485502fa6bd67efe74991c595a1dbc6d46b1ec3e2cac742fa33b429','raw32-parts/part-ab'),(a.part_c,'481eec203b4354ef6b61b33b9ad76fd1e503acb095c317499bf35ee359070562','raw32-parts/part-ac')]
def read(path,h,name):
 assert sha256(path.read_bytes()).hexdigest()==h,path
 with ZipFile(path) as z:
  assert z.testzip() is None and [x for x in z.namelist() if not x.endswith('/')]==[name];return z.read(name)
with (D/'full-32-35.json').open('wb') as f:
 for path,h,name in parts:f.write(read(path.resolve(),h,name))
(D/'full-36-39.json').write_bytes(read(a.raw36.resolve(),'6421b391fbf2e7d3e376275dcdd4a41655b53e7a6a0b820f0038ea16e40a617d','full-36-39.json'))
for n,h in [('full-32-35.json','6ecaf46bd8f26104f503ee16a9c175673354cb19762ed132f029f93a2b854cd7'),('full-36-39.json','ded8ccb0f3a79099599390dbaf192757c2442c3c1dbc50d75356825f51836069')]:assert sha256((D/n).read_bytes()).hexdigest()==h
if a.assemble_only:print('PASS: archive hashes and reconstruction only; no mathematics verified');sys.exit(0)
cmd=[sys.executable,'-I','-B',str(K/'verify01400.py'),str(W/'checked')]
if a.partial:cmd.append('--partial')
if a.full:cmd.append('--full')
subprocess.run(cmd,cwd=K,check=True)
if not(a.partial or a.full):assert (W/'checked/result.json').read_bytes()==(K/'result.json').read_bytes()
print('PASS: .014 verifier and all archive hashes')

"""Use a larger right angular endpoint for the positive-slope branch of j16."""
from pathlib import Path

root=Path(__file__).resolve().parent
baseline=root/'certify_front10.py'
source=baseline.read_text()
tag='    pose=(0,1) if side<0 else (120,-1)'
extra="""    if j==16 and side>0 and ori==0:
        brackets=[('8','22'),('8','22.25'),('8','22.5'),('8','23'),('8','24'),
                  ('7.5','22'),('7.5','23'),('6.25','23')]+brackets
"""
assert source.count(tag)==1
source=source.replace(tag,extra+tag)
mark="sources=[D/k for k in ['certify_front10.py'"
assert source.count(mark)==1
source=source.replace(mark,"sources=[D/k for k in ['certify_j16.py','certify_front10.py'")
env=dict(__file__=str(baseline),__name__='__main__')
exec(compile(source,str(baseline),'exec'),env)

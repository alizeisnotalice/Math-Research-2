"""Condition the ordered contact simplex on the exact initial derivative."""
import inspect,itertools
from certify_sigma_derivative_classes import validate as upstream
from ordered_state import support_bound


def derivative_bound(ns,j,a,b):
    E,v,ed,raw,_=support_bound(ns,j,a,b)
    local=inspect.getclosurevars(raw).nonlocals
    base=local['base'];event=local['event'];extremal=local['extr']
    normals=list(map(ns['av'],ns['d']['n']))
    actions=[(i,ns['mul'](ns['A']((-1)**k),(-normals[k][1],normals[k][0]))) for k,i in enumerate([1,3,0])]
    S0=sum(ns['dot'](v[i],u) for i,u in actions);ns['_model_slope']=S0
    def bound(ts):
        extra=[];terms=[]
        for c,u in ts:
            if u is None:extra.extend((i,ns['mul'](c,w)) for i,w in actions)
            else:terms.append((c,u))
        if not extra:return raw(terms)
        correct=base['correction'](terms)
        groups=[base['choices'](c,u) for c,u in terms]
        return extremal([event(sum(g,[])+correct+extra) for g in itertools.product(*groups)]).upper()
    A=ns['A']
    ns['_actual_slope']=(S0-E*bound([(A(-1),None)])).lower().union((S0+E*bound([(A(1),None)])).upper())
    return E,v,ed,bound,None


def validate(ns,j,left,right,turn,sign,orientation,**kw):
    env={**upstream.__globals__,'derivative_bound':derivative_bound}
    source=inspect.getsource(upstream)
    if '_end_index' in ns:
        mark='    env={**affine.__globals__'
        assert source.count(mark)==1
        source=source.replace(mark,'''    src=replace_line(src,'a=r0+i*step;b=a+step','a=r0+i*step;b=r0+ns["_end_index"]*step')
'''+mark)
    mark='    env={**affine.__globals__'
    before='        for k in range(angular):visit('
    after='        if rm<=0:continue\n'+before
    source=source.replace(mark,"    src=replace_line(src,"+repr(before)+","+repr(after)+")\n"+mark)
    changes=(
        ("            nonlocal pm,pid,placed,excluded,gap_min", 
         "            nonlocal pm,pid,placed,excluded,gap_min\n            if pm<=0:return"),

        ("if value<A('.0001'):value=lower", "if value<=0:value=lower"),
        ("if margin>A('.0001'):break", "if margin>0:break"),
        ("poses=[(turn,sign)]+[(k,s) for k in (0,60,120,180,240,300) for s in (1,-1) if (k,s)!=(turn,sign)]",
         "poses=list(dict.fromkeys(([(300,1),(120,-1),(180,-1)] if condition_sign>0 else [(0,1)])+[(turn,sign)]+[(k,s) for k in (0,60,120,180,240,300) for s in (1,-1)]))"),
    )
    inject=''.join("    src=replace_line(src,"+repr(before)+","+repr(after)+")\n" for before,after in changes)
    source=source.replace(mark,inject+mark)
    exec(compile(source,'ordered_initial_derivative','exec'),env)
    return env['validate'](ns,j,left,right,turn,sign,orientation,**kw)

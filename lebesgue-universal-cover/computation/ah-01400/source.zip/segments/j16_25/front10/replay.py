from pathlib import Path
from hashlib import sha256
from concurrent.futures import ThreadPoolExecutor
import argparse,json,subprocess,sys
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('scratch',type=Path);p.add_argument('--full',action='store_true');p.add_argument('--workers',type=int,default=1);a=p.parse_args()
scratch=a.scratch.resolve();scratch.mkdir(exist_ok=True,parents=True);assert not any(scratch.iterdir())
for n,h in json.loads((D/'manifest.json').read_bytes()).items():assert sha256((D/n).read_bytes()).hexdigest()==h,n
if a.full:
 def recompute(j):
    raw=D/f'result-{j}.json'
    verified=scratch/f'check-{j}.json'
    with (scratch/f'{j}.log').open('w') as f:
        subprocess.run([sys.executable,'-I','-B',str(D/'recheck_leaves.py'),str(raw),str(verified)],cwd=D,stdout=f,check=True)
    result=json.loads(verified.read_bytes())
    assert result['success'] and result['raw_sha256']==sha256(raw.read_bytes()).hexdigest()
 with ThreadPoolExecutor(max_workers=a.workers) as pool:list(pool.map(recompute,range(16,26)))
target=scratch/'summary.json';subprocess.run([sys.executable,'-I','-B',str(D/'audit_front10.py'),str(target),'--ledger',str(scratch/'ledger.json')],cwd=D,check=True)
assert target.read_bytes()==(D/'summary.json').read_bytes()
assert (scratch/'ledger.json').read_bytes()==(D/'ledger.json').read_bytes()
comp=D/'comp062'
with (scratch/'geometry-area.json').open('wb') as f:subprocess.run([sys.executable,'-I','-B',str(comp/'certify_sigma154_deeper_composition.py'),str(comp),str(D/'physical-0140.json'),'--eh',str(comp)],cwd=D,stdout=f,check=True)
assert (scratch/'geometry-area.json').read_bytes()==(D/'geometry-area.json').read_bytes()
print('Verified all ten synchronized AH .01400 contact trees.')

"""Independently recompute the successful terminal leaves using their saved proof parameters."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json
import sys

here=Path(__file__).resolve().parent
args=ArgumentParser(description=__doc__)
args.add_argument('raw',type=Path)
args.add_argument('out',type=Path)
a=args.parse_args()
record=json.loads(a.raw.read_bytes())
j=int(record['bin'])
base=here/'certify_front10.py'
argv=sys.argv[:]
sys.argv=[str(base),str(j),str(a.out)]
code=base.read_text().split('\nrows=[]',1)[0]
state={'__file__':str(base),'__name__':'__main__'}
exec(compile(code,str(base),'exec'),state)
sys.argv[:]=argv
n=state['n']
if 'ordered_stop.py' in record['sources']:
    from ordered_stop import validate
elif 'ordered_quick.py' in record['sources']:
    from ordered_quick import validate
else:
    from ordered_fast import validate
assert sha256(state['src'].encode()).hexdigest()==record['geometry_sha256']
assert state['cfg']==record['physical']
assert record['EH_cost_upper']==str(state['eh_cost'])
for name,dig in record['sources'].items():
    assert sha256((here/name).read_bytes()).hexdigest()==dig


def visit(tree,orientation,side,k,l):
    if 'children' in tree:
        for child in tree['children']:
            yield from visit(child,orientation,side,k,l)
        return
    assert 'failed' not in tree
    key=tree['row']
    n['_first_orientation']=orientation
    n['_end_index']=l
    n['_class_counts']=tuple(tree['counts'])
    n['_e_class']=tuple(map(Q,tree['e']))
    L,R=map(Q,key['bracket'])
    turn,sign=(0,1) if side<0 else (120,-1)
    check=validate(n,j,L,R,turn,sign,side,cut=Q(record['derivative_cut']),
                   side=side,begin=k,end=k+1,angular=12,depth=4)
    check['subcells']=[k,l]
    assert json.dumps(check,sort_keys=True)==json.dumps(key,sort_keys=True),(j,orientation,side,k,l,tree['counts'],tree['e'])
    yield 1


count=0
for box in record['rows']:
    k,l=box['block']
    count+=sum(n0 for t in box['trees'] for n0 in visit(t,box['orientation'],box['side'],k,l))
    print(j,'verified',box['orientation'],box['side'],k,l,flush=True)
assert count>0
audit=dict(bin=j,success=True,checked_terminal_leaves=count,geometry_sha256=record['geometry_sha256'],
           raw_sha256=sha256(a.raw.read_bytes()).hexdigest(),recheck_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
a.out.write_text(json.dumps(audit,indent=2)+'\n')

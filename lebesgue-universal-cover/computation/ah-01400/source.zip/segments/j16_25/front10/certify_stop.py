"""Retry the same certificate with early acceptance of any strict placement."""
from pathlib import Path

p=Path(__file__).resolve().with_name('certify_front10.py')
text=p.read_text()
start='from ordered_fast import validate'
assert text.count(start)==1
text=text.replace(start,'from ordered_stop import validate')
marker='    pose=(0,1) if side<0 else (120,-1)'
extra="""    if side>0:
        brackets=[('8','21'),('8','22'),('7.5','20')]+brackets
"""
assert text.count(marker)==1
text=text.replace(marker,extra+marker)
point="sources=[D/k for k in ['certify_front10.py'"
assert text.count(point)==1
text=text.replace(point,"sources=[D/k for k in ['certify_stop.py','ordered_stop.py','certify_front10.py'")
mark='def solve(counts,lo,hi,ori,side,a,b):'
pre=mark+"""
    if ori==0 and side==1 and (hi-lo)==1 and counts in ((1,4),(2,3)):
        return dict(counts=list(counts),e=[str(lo),str(hi)],split='four-deficits',
                    children=[solve(counts,Q(k,4),Q(k+1,4),ori,side,a,b)for k in range(4)])
"""
assert text.count(mark)==1
text=text.replace(mark,pre)
scope={'__file__':str(p),'__name__':'__main__'}
exec(compile(text,str(p),'exec'),scope)

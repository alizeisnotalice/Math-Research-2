"""Recompute all ten original front interval trees, preserving complete raw receipts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys,json
P=Path(__file__).resolve().parent;D=P/'front10';O=Path(sys.argv[1]).resolve();assert not O.exists();O.mkdir(parents=True)
def run(j):
 script='certify_j16.py' if j==16 else 'certify_stop.py' if j in (21,24,25) else 'certify_front10.py';out=O/f'result-{j}.json'
 with (O/f'{j}.log').open('w') as f:subprocess.run([sys.executable,'-I','-B',str(D/script),str(j),str(out)],cwd=D,check=True,stdout=f,stderr=subprocess.STDOUT)
 assert out.read_bytes()==(D/out.name).read_bytes(),j
 return j
with ThreadPoolExecutor(max_workers=3) as pool:done=sorted(pool.map(run,range(16,26)))
assert done==list(range(16,26));(O/'comparison.json').write_text(json.dumps({'bins':done,'all_original_raw_byte_equal':True},indent=2)+'\n')

from pathlib import Path
from hashlib import sha256
import tempfile,subprocess,json,sys
P=Path(__file__).resolve().parent;D=P/'front10';O=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix='j16-25-',dir=O.parent) as t:
 S=Path(t)/'summary.json';L=Path(t)/'ledger.json';subprocess.run([sys.executable,'-I','-B',str(D/'audit_front10.py'),str(S),'--ledger',str(L)],check=True,stdout=subprocess.DEVNULL);assert S.read_bytes()==(D/'summary.json').read_bytes() and L.read_bytes()==(D/'ledger.json').read_bytes();z=json.loads(L.read_bytes())
manifest=json.loads((D/'manifest.json').read_bytes());assert all(sha256((D/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
ind=json.loads((D/'independent-check.json').read_bytes());assert ind['complete'] and set(ind['independent'])==set(map(str,range(16,26))) and all(v['raw_sha256']==sha256((D/f'result-{j}.json').read_bytes()).hexdigest() for j,v in ind['independent'].items())
q=sha256((D/'physical-0140.json').read_bytes()).hexdigest();assert z['complete'] and z['geometry_sha256']=='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256' and q=='adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32' and z['bins']==list(range(16,26)) and z['physical_cells']==750
out={'complete':True,'geometry_sha256':z['geometry_sha256'],'physical_sha256':q,'bins':z['bins'],'physical_cells':750,'independent_modes':{j:v['mode'] for j,v in ind['independent'].items()},'audit':z};O.write_text(json.dumps(out,indent=2)+'\n')

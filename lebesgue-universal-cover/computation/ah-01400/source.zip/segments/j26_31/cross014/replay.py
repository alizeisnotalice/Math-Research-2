from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from fractions import Fraction
import json
import shutil
import subprocess
import sys
from flint import arb,ctx
ctx.prec=160
D=Path(__file__).resolve().parent
q26,q31,scratch=map(lambda s:Path(s).resolve(),sys.argv[1:4])
scratch.mkdir(parents=True,exist_ok=True)
assert not any(scratch.iterdir())
def sha(p):
    return sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_bytes())
sigs={26:'8b22579fa205830595c21ba81c7c8af55f0adb07b68f8dfd3a31d14c2d05cad3',31:'b1fd6f580952e4dbed8f1b35f4918adf93fac922dc0d5802a6e9f39d8123c4d4'}
for p,j in [(q26,26),(q31,31)]:
    assert sha(p)==sigs[j]
    with ZipFile(p) as z:z.extractall(scratch)
    root=scratch/f'j{j}-0-75'
    original=(root/f'audit-015-{j}-0-75.json').read_bytes()
    independent=read(D/f'independent-015-j{j}.json')
    assert independent['archive_sha256']==sigs[j] and independent['all_15_same']
    assert len(independent['raw_sha256'])==15 and all(sha(root/k)==v for k,v in independent['raw_sha256'].items())
    subprocess.run([sys.executable,'-I','-B',str(root/'audit_whole.py'),'015',str(j),'0','75'],cwd=root,check=True)
    assert original==(root/f'audit-015-{j}-0-75.json').read_bytes()
deep=scratch/'j31-0-75'; shallow=scratch/'comp062';shutil.copytree(deep/'comp068',shallow)
shutil.copyfile(D/'graph062.py',shallow/'certify_sigma_extended_graph.py')
records=[]
for tag,comp,inp in [('014',shallow,D/'physical-0140.json'),('015',deep/'comp068',deep/'physical-0150-tight.json')]:
    p=scratch/f'{tag}.json'
    subprocess.run([sys.executable,'-I','-B',str(D/'register.py'),str(comp),str(inp),str(p)],check=True)
    records.append(read(p))
a,b=records
assert [r['graph'] for r in records]==['772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256','5726407e8820a48adee03a8ac2efebe10225c48accf09893a36ee224c30fa82d']
assert a['common']==b['common']
s,d=arb(14)/1000,arb(15)/1000
ca=(d-s).sin()/d.sin();cb=s.sin()/d.sin()
assert ca>0 and cb>0
common=a['common']
out=dict(depths=['.014','.015'],q_sha=[r['config'] for r in records],graphs=[r['graph'] for r in records],deep_receipts=sigs,all_chart_definitions=sorted(common['definitions']),all_fixed_chart_constants=sorted(common['constants']),all_knots=len(common['knots']),bins={k:dict(closed_cells=len(v)-1,w=[v[0][0],v[-1][0]],first_coordinate_labels=[0,1],sha256=sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()) for k,v in common['bins'].items()},sine_factors=[str(ca),str(cb)],actual_deficit_ordering_unchanged=True)
target=scratch/'cross-014-015.json';target.write_text(json.dumps(out,indent=2)+'\n')
assert target.read_bytes()==(D/'registered.json').read_bytes()
print(sha(target),flush=True)

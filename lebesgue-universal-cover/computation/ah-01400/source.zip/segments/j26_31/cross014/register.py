"""Rebuild either chart and the reference values at every common closed boundary."""
import ast
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import sys
root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root))
from certify_sigma_extended_graph import geometry
from certify_sigma_reachable_roots import reach
p=Path(sys.argv[2]);q=json.loads(p.read_bytes())
ns,source,_=geometry(root,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']),strict=True)))
frac=lambda xs:list(map(str,xs))
A=ns['A']
names={'inverse','cc','X','psi','ell_partner','straight_graph','graph_value','chart','points','reflection','derivs'}
definitions={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names}
assert set(definitions)==names
constants={}
for k in ('z','D','l0','mid','nl','nn','el','en','direct','normal','r3','half'):
    v=ns[k];constants[k]=list(map(str,v)) if isinstance(v,tuple) else str(v)
bins={}
for j in (26,31):
    a,b=ns['knots'][j:j+2]
    assert reach(ns,j)==[(0,75)]
    points=[]
    for k in range(76):
        w=a+(b-a)*k/75
        x=ns['add'](ns['z'],ns['mul'](A(w),ns['D']))
        l,t=ns['chart'](x)
        partner=ns['psi'](l)
        points.append([str(w),str(l),str(t),str(partner),str(ns['graph_value'](l)),str(ns['graph_value'](partner))])
    bins[str(j)]=points
out=dict(config=sha256(p.read_bytes()).hexdigest(),graph=sha256(source.encode()).hexdigest(),common=dict(constants=constants,definitions=definitions,knots=frac(ns['knots']),bins=bins))
Path(sys.argv[3]).write_text(json.dumps(out,indent=2)+'\n')

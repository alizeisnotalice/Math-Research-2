# .014 的 j27–30 五细格直接摆放

深度 .014、铰点 .429，.62 真图及物理参数 (.352,.403,.020)。标号0；每块是相邻5个固定物理细格。每块从原始物理图计算 Fsharp 和 S，严格验证 S≥Fsharp>0。取 τ=e/Fsharp， λ=τ y5，固定姿态 Q_A=(240°,−1)，F_K(0)=0。所有接触类在 y5≤1/3 时，行松弛下界写为 a−bτ−cλ，c≥0；每一潜在支撑扇和同一宿主行一起留下有理系数。28行都使用同一个物理块、同一真实输入、同一摆放和 .00000009488 的 EH 预退。见 PROOF.md 的支持估计。新四格均独立验证了 S≥Fsharp 并实际重算全部系数。

用 Python 3.13.18、python-flint 0.9.0 运行

    python -I -B quick/replay.py EMPTY 2

manifest.json 逐项记录计算核、每个请验器、输入与四份原始回执的 SHA256。final.json 指出按同一块归并的原始回执 SHA 和闭覆盖量。每个 j 的最小全格通用 τ 下端在 uniform_tau_min 中，y5 可达1/32。四格也均可直接用 τ≥5/8、y5≤1/32。原分支的导数正负不影响零角摆放。

Python 直接调用 query(j,begin,end,orientation,e,counts)。e 为两个有理字符串，counts 是由低至高的有序接触人数分层。CLI 依次传 j,begin,end,orientation,e_lo,e_hi,counts 的 JSON 数组。函数自动从最后一个非空层的闭上端取得 y5 的保守界。它用两端点及每条有理直线计算整个原闭叶的最小余量。若 applicable 为真，则提供姿态、原始物理块、Fsharp/S、有理正余量、最紧边、原回执和生成图哈希。合成前核对旧失败叶确在同一五格及同一 Fsharp 标度下，同时确认接触 y 使用 v=min(e,S)=e；若其他归一不同须先换成实际变量。单格薄化不能擅自沿用原 e 百分比。applicable 为假只表示该直接证明未覆盖相应旧叶。

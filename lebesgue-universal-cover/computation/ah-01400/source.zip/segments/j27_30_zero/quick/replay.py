from pathlib import Path
from hashlib import sha256
from concurrent.futures import ThreadPoolExecutor
import subprocess
import sys
import shutil
import json
D=Path(__file__).resolve().parent;S=Path(sys.argv[1]).resolve()
S.mkdir(parents=True,exist_ok=True);assert not any(S.iterdir())
def sha(p):return sha256(p.read_bytes()).hexdigest()
registry=json.loads((D/'manifest.json').read_bytes())
for n,h in registry.items():
    assert sha(D/n)==h
    if n.startswith('third-014-') or n in ('final.json','README.md','PROOF.md','replay.py'):continue
    target=S/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/n,target)
def run(j):
    subprocess.run([sys.executable,'-I','-B',str(S/'third_transfer.py'),'014',str(j),'0','75'],cwd=S,check=True)
    n=f'third-014-{j}.json';assert (S/n).read_bytes()==(D/n).read_bytes()
workers=int(sys.argv[2]) if len(sys.argv)>2 else 2
assert 1<=workers<=4
with ThreadPoolExecutor(max_workers=workers) as pool:list(pool.map(run,range(27,31)))
subprocess.run([sys.executable,'-I','-B',str(S/'reduce.py'),str(S),str(S/'final.json')],check=True)
assert (S/'final.json').read_bytes()==(D/'final.json').read_bytes()
for j in range(27,31):
    for k in range(0,75,5):
        counts=[5]+[0]*31
        q=json.loads(subprocess.check_output([sys.executable,'-I','-B',str(S/'query.py'),str(j),str(k),str(k+5),'0','5/8','1',json.dumps(counts)]))
        assert q['applicable'] and q['pose']==[240,-1] and q['closed_block']==[k,k+5]
print('Replayed sixty common physical blocks, four exact registries and every high-deficit query.')

from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json
import sys

D=Path(sys.argv[1]).resolve()
J=Path(sys.argv[2])
mains={}
def sha(p):
    return sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_bytes())
def A2(row):
    return [(s,F(a),F(b),F(c)) for s,a,b,c in row['constraints']]
def for_y(constraints,y):
    assert all(c>=0 for _,a,b,c in constraints)
    assert all(a-b-c*y>0 for _,a,b,c in constraints)
    actual=max([F(0)]+[a/(b+c*y) for _,a,b,c in constraints if b+c*y<0])
    m=F(0) if min(a for _,a,b,c in constraints)>0 else F(int(max(F(0),actual)*65536)+1,65536)
    assert 0<=m<=1
    margin,label=min((a-(b+c*y)*t,s) for s,a,b,c in constraints for t in (m,F(1)))
    assert margin>0
    return dict(tau_min=str(m),positive_margin=str(margin),lowest_edge=label)
def subtree_margin(constraints,y_bound,e_lo,e_hi):
    return min(a-(b+c*y_bound)*t for s,a,b,c in constraints for t in (e_lo,e_hi))
for j in range(27,31):
    p=D/f'third-014-{j}.json'
    q=read(p);assert q['geometry_sha256']=='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256' and q['orientation']==0 and q['pose']==[240,-1]
    assert q['source']==sha(D/'third_transfer.py')
    assert q['reference']==j and q['subcells']==[0,75] and [r['block'] for r in q['rows']]==[[k,k+5] for k in range(0,75,5)]
    rows=[]
    for r in q['rows']:
        cs=A2(r)
        profiles={str(y):for_y(cs,y) for y in [F(0),F(1,64),F(1,32),F(1,16)] if all(a-b-c*y>0 for _,a,b,c in cs)}
        assert str(F(1,32)) in profiles
        rows.append(dict(block=r['block'],profile=profiles))
    h=max(F(r['profile']['1/32']['tau_min']) for r in rows)
    low=min(subtree_margin(A2(r),F(1,32),h,F(1)) for r in q['rows'])
    assert low>0
    mains[str(j)]=dict(individual_raw_sha256=sha(p),actual_cells=75,rows=rows,uniform_tau_min=str(h),uniform_margin=str(low))
tree=dict(physical_sha256=sha(D/'physical-0140.json'),source=sha(D/'third_transfer.py'),orientation=0,pose=[240,-1],y_max='1/32',actual_physical_cells=300,bins=mains)
J.write_text(json.dumps(tree,indent=2)+'\n')
print([(k,float(F(v['uniform_tau_min'])),float(F(v['uniform_margin']))) for k,v in mains.items()],sha(J),flush=True)

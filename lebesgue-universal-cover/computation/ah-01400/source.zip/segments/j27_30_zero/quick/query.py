"""Query the .014 Q_A zero-angle support bound for a closed tree leaf."""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import json
import sys

D=Path(__file__).resolve().parent
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
@lru_cache
def data(j):
    final=json.loads((D/'final.json').read_bytes())
    p=D/f'third-014-{j}.json'
    assert int(j) in range(27,31) and digest(p)==final['bins'][str(j)]['individual_raw_sha256']
    return json.loads(p.read_bytes()),digest(p)

def query(j,begin,end,ori,e,counts):
    """The incoming e class uses the returned first_budget on precisely this physical block."""
    if ori!=0 or j not in range(27,31) or not 0<=begin<end<=75 or begin%5 or end!=begin+5:
        return dict(applicable=False,why='different physical block or first-contact label')
    if not counts or any(type(x)!=int or x<0 for x in counts) or sum(counts)!=5:
        raise ValueError('five ordered entries required')
    lo,hi=map(F,e)
    if not F(0)<=lo<=hi<=1:
        raise ValueError('invalid closed e class')
    y=F(1+max(k for k,v in enumerate(counts) if v),len(counts))
    if y>F(1,3):
        return dict(applicable=False,why='y5 support domain exceeds 1/3',y5_upper=str(y))
    q,s=data(j); r=q['rows'][begin//5];assert r['block']==[begin,end]
    cons=[(lab,F(a),F(b),F(c)) for lab,a,b,c in r['constraints']]
    assert all(c>=0 for lab,a,b,c in cons)
    m,name,where=min((a-(b+c*y)*t,lab,t) for lab,a,b,c in cons for t in (lo,hi))
    return dict(applicable=m>0,reference=j,closed_block=[begin,end],orientation=0,pose=[240,-1],e_class=[str(lo),str(hi)],counts=list(counts),y5_upper=str(y),first_budget=r['first_budget'],second_budget=r['second_budget'],all_28_margin=str(m),limiting_face=name,limiting_tau=str(where),raw_sha256=s,geometry_sha256=q['geometry_sha256'],EH_retreat='0.00000009488')
if __name__=='__main__':
    cert=query(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),sys.argv[5:7],json.loads(sys.argv[7]))
    print(json.dumps(cert,indent=2))

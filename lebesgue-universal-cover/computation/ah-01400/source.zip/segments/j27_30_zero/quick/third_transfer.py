"""Find and certify an explicit pinned or bracketed placement on every closed class of an AH reference block."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,sys
D=Path(__file__).resolve().parent
tag,j,start,stop=sys.argv[1],*map(int,sys.argv[2:5])
assert tag in ('014','015') and 0<=start<stop<=75 and start%5==stop%5==0
comp=D/('comp062' if tag=='014' else 'comp068');sys.path[:0]=[str(D),str(comp)]
from flint import arb
from ordered_state import support_bound
from ordered_fast import validate
from certify_sigma_extended_graph import geometry
from certify_sigma_reachable_roots import reach
cfg=json.loads((D/('physical-0140.json' if tag=='014' else 'physical-0150-tight.json')).read_bytes())
kwargs=dict(zip(('far','negative','eps'),map(F,cfg['physical_parameters']),strict=True))
n,src,_=geometry(comp,[tuple(map(F,cfg['line']))],sigma=cfg['sigma_degrees'],**kwargs)
assert reach(n,j)==[(0,75)]
A=n['A'];n['_sharpen_jets']=True;n['_tighten_first']=True
i,=[k for k,(lab,u,z) in enumerate(n['rows']) if lab.startswith('U1-Te')]
lab,u,h=n['rows'][i];n['rows'][i]=lab,u,h-A(F('.00000009488'))
import inspect
from sharp_first_hit import dyadic
from certify_ah_local_physical_support import local_budgets
from sharp_first_hit import first_budget
orient=0;n['_first_orientation']=0;n['_class_counts']=(5,0,0);n['_e_class']=F(0),F(1)
zero=A(0);z=(zero,zero);rows=[];sn=n['trig'](A(-240))
def discrete_lower(x):return dyadic(x.lower())
def discrete_upper(x):return dyadic(x.upper())
for k in range(start,stop,5):
 w0,w1=n['knots'][j:j+2];step=(w1-w0)/75;a=w0+k*step;b=a+5*step
 n['_end_index']=k+5
 E,v,ed,raw,_=support_bound(n,j,a,b);bottom=inspect.getclosurevars(raw).nonlocals
 event=inspect.getclosurevars(bottom['event']).nonlocals;assert event['ori']==0
 base=bottom['base'];ce=inspect.getclosurevars(base['event']).nonlocals;local=ce['ns']['two_hit_budgets'][j][0]
 f=first_budget(n,a,b,local[0]);smax=local[1];assert f>0 and smax>=f
 loc=event['loc'];m=event['m'];chain=event['chain'];constraints=[]
 for label,u,h in n['rows']:
  pre=(u[0],-u[1]);U=n['rotate'](pre,sn);hm=n['supports'](v,ed,sn,pre)
  const=discrete_lower(h-hm)
  for actions in base['choices'](A(1),U):
   vec=[z]*5
   for i,du in actions:vec[i]=n['add'](vec[i],du)
   dot=n['dot'];ll=dot(vec[0],n['el']);lr=dot(vec[1],n['reflection'](n['el']));dt=dot(vec[3],n['en'])
   a2,t2=(dot(vec[2],p) for p in loc[2]);a4,t4=(dot(vec[4],p) for p in loc[4])
   coeff=[ll/(m*A('.95')),-lr/m,-a2/m,t2,-dt]
   kappa=chain(coeff,zero,A(1))
   c0=discrete_upper(f*(dt-t2-t4));c1=discrete_upper(2*f*kappa)
   constraints.append((label,const,c0,max(F(0),c1)))
 result={}
 for t in [F(1,2),F(5,8),F(3,4),F(7,8),F(1)]:
  # c0*tau+c1*tau*y<const over every tau in [t,1]; the linear product is checked at both endpoints.
  upper=F(1,3);ok=True;worst=None
  for lab,const,c0,c1 in constraints:
   for tau in (t,F(1)):
    residue=const-tau*c0
    if residue<=0:ok=False
    if c1>0:
     limit=residue/(tau*c1)
     if limit<upper:upper=limit;worst=lab
  # Strictly interior dyadic lower candidate, with the independent all-row slack at both endpoints.
  yh=F(min(int(upper*65536)-1,21845),65536) if ok and upper>0 else F(0)
  residual=min(const-tau*(c0+c1*yh) for lab,const,c0,c1 in constraints for tau in (t,F(1)))
  result[str(t)]=dict(y=str(yh),all_positive=residual>0,margin=str(residual),limiter=worst)
 rows.append(dict(block=[k,k+5],first_budget=str(f),second_budget=str(smax),constraints=[[lab,*map(str,(a,b,c))] for lab,a,b,c in constraints],inner=result))
out=dict(reference=j,subcells=[start,stop],tag=tag,physical=cfg,geometry_sha256=sha256(src.encode()).hexdigest(),pose=[240,-1],orientation=0,source=sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows)
(D/f'third-{tag}-{j}.json').write_text(json.dumps(out,indent=1)+'\n')
for t in rows[0]['inner']:
 print(t,min(F(r['inner'][t]['y']) for r in rows),all(r['inner'][t]['all_positive'] for r in rows),flush=True)

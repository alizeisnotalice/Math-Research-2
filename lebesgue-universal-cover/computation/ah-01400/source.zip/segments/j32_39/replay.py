"""Recreate the complete middle or tail proof from a frozen package."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
from subprocess import run
import json
import sys

root=Path(__file__).resolve().parent
p=ArgumentParser(description=__doc__)
p.add_argument('out',type=Path)
a=p.parse_args()
out=a.out.resolve()
out.mkdir(parents=True,exist_ok=True)
assert not any(out.iterdir())
case=root/'case'
kernel=root/'kernel'
expected=(root/'summary.json').read_bytes()
known=json.loads(expected)['raw_sha256']
cmd=[sys.executable,'-I','-B']


def recompute(pair):
    name,digest=pair
    prefix,l,r=Path(name).stem.split('-')
    assert prefix=='full'
    output=out/name
    run([*cmd,str(kernel/'certify_middle.py'),str(case),str(output),l,r],check=True)
    assert sha256(output.read_bytes()).hexdigest()==digest
    return str(output)


with ThreadPoolExecutor(min(4,len(known))) as pool:
    files=list(pool.map(recompute,known.items()))
target=out/'summary.json'
run([*cmd,str(root/'audit.py'),str(case),str(kernel),str(target),*files],check=True)
assert target.read_bytes()==expected

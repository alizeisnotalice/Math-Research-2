"""Prove the closed physical middle blocks for one fixed AH depth."""
from argparse import ArgumentParser,Namespace
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import inspect
import json
import sys
import traceback

from flint import arb

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'joint')]
from certify_tail import MARGINS,RETREAT,build,load

BRACKETS=tuple((F(l),F(r),sgn) for l,r,sgn in (
    ('.5','6.2',-1),('.5','6.35',-1),('.5','6.55',-1),('.5','6.8',-1),
    ('.4','7',-1),('.4','7.25',-1),('.4','7.5',-1),('.4','7.75',-1),
    ('.4','8',-1),('.4','8.25',-1),('.4','8.75',-1),('.4','9.25',-1),
    ('.1','7.5',-1),('.1','8.25',-1),('6.2','18',1),('6.5','18',1),
    ('7','18',1),('7.5','18',1),('8','18',1),('9','20',1)))

def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def solve(a):
    ns,cfg,reach,plain,base,eh,cost=load(Namespace(comp=a.case/'comp',case=a.case,main_comp=a.case/'comp'))
    from positive_cone import base_data,cone_model,support_for_cone
    from search_endpoint import cases_of,patches,signed_endpoint
    zero,_=build(ns,plain,base)
    ns['_e_class']=F(0),F(1)
    model=None
    packet_override=None

    def support_bridge(state,j,w0,w1):
        lo,hi=state['knots'][j:j+2]
        k,l=state['_physical_block']
        step=(hi-lo)/75
        assert w0==lo+k*step and w1==w0+step
        assert model[3]['w']==[str(w0),str(lo+l*step)]
        return packet_override or support_for_cone(state,model)

    env={**plain.__globals__,'support_bound':support_bridge}
    exec(compile(inspect.getsource(plain),'physical_joint_both_labels','exec'),env)
    positive=env['validate']

    def call(kernel,j,k,l,r,sgn):
        return kernel(ns,j,l,r,0,1,sgn,begin=k,end=k+1,angular=12,depth=4)

    def direct(kernel,j,k):
        best=None
        for l,r,s in BRACKETS:
            cell=call(kernel,j,k,l,r,s)
            value=min(arb(cell[m]) for m in MARGINS)
            if best is None or value>best[0]:
                best=value,cell
            if value>0 and cell['placed_leaves']>0:
                return True,cell
        return False,best[1]

    def joint(j,k):
        nonlocal packet_override
        packet=support_for_cone(ns,model)
        uniform={}
        rows=[]
        possible=[]
        best=None

        def evaluate(l,r,sign,bounds,counts=None):
            nonlocal packet_override,best
            gl,gr=bounds
            if not (gl>0 and gr>0):
                return None
            packet_override=packet
            cell=call(positive,j,k,l,r,sign)
            cell['unrefined_root_margin_lower']=cell['root_margin_lower']
            cell['root_margin_lower']=str(min(gl,gr))
            cell['endpoint_support']=dict(partition=counts, left_lower=str(gl),right_lower=str(gr),
                                          active=[[x,y]for x,y,_ in rows])
            score=min(arb(cell[m])for m in MARGINS)
            if best is None or score>best[0]:
                best=score,cell
            if score>0 and cell['placed_leaves']>0:
                return cell
            return None

        for l,r,s in BRACKETS:
            gl=uniform.setdefault((l,s),signed_endpoint(ns,packet,l,s))
            gr=uniform.setdefault((r,-s),signed_endpoint(ns,packet,r,-s))
            match=evaluate(l,r,s,(gl,gr))
            if match is not None:
                packet_override=None
                return True,match
        cases=cases_of(model)
        for counts in ((2,2,1),(2,2,2),(4,2,2),(8,4,4)):
            rows=patches(ns,model,cases,counts)
            refined={}
            for l,r,s in BRACKETS:
                for t,sign in ((l,s),(r,-s)):
                    key=(t,sign)
                    if key not in refined:
                        refined[key]=max(uniform[key],min(signed_endpoint(ns,P,t,sign)for _,_,P in rows))
                gl,gr=refined[(l,s)],refined[(r,-s)]
                match=evaluate(l,r,s,(gl,gr),counts)
                if match is not None:
                    packet_override=None
                    return True,match
            possible=[(l,r,s,refined[(l,s)],refined[(r,-s)])for l,r,s in BRACKETS]
        if best is not None:
            packet_override=None
            return False,best[1]
        l,r,s,gl,gr=max(possible,key=lambda row:min(row[3:]))
        packet_override=packet
        cell=call(positive,j,k,l,r,s)
        cell['unrefined_root_margin_lower']=cell['root_margin_lower']
        cell['root_margin_lower']=str(min(gl,gr))
        cell['endpoint_support']=dict(partition=[8,4,4],left_lower=str(gl),right_lower=str(gr),
                                      active=[[x,y]for x,y,_ in rows])
        packet_override=None
        return False,cell

    rows=[]
    for j in range(a.start,a.finish+1):
        [water]=reach(ns,j)
        assert water[0]==0
        n=water[1]
        lo,hi=ns['knots'][j:j+2]
        step=(hi-lo)/75
        for ori in (0,1):
            ns['_first_orientation']=ori
            starts=range(0,n,5)
            if a.scout:
                starts=sorted({0,5*(n//10),5*((n-1)//5)})
            for k in starts:
                l=min(k+5,n)
                ns['_physical_block']=k,l
                u,v=lo+k*step,lo+l*step
                row=dict(j=j,ori=ori,block=[k,l],w=[str(u),str(v)])
                try:
                    f=base_data(ns,j,u,v)[4]
                    if not f:
                        assert ori==1
                        row['first_positive_impossible']=True
                    else:
                        model=cone_model(ns,j,u,v)
                        row['condition']=model[3]
                        row['zero']=direct(zero,j,k)
                        row['positive']=joint(j,k) if model[2] else (True,None)
                except AssertionError as exc:
                    row['rejected']=[str(exc),str(traceback.extract_tb(exc.__traceback__)[-1])]
                rows.append(row)
                view={key:(x[0],x[1]['bracket'],x[1]['root_margin_lower'],x[1]['placement_margin_lower'])
                      for key,x in row.items() if key in ('zero','positive') and x[1]}
                if a.scout or 'rejected' in row or any(not v[0] for v in view.values()):
                    print(j,ori,k,view,row.get('first_positive_impossible'),row.get('rejected'),flush=True)
            print('complete',j,ori,n,len(starts),flush=True)
    source_names=('certify_middle.py','certify_tail.py','chart_geometry.py','ordered_state.py','sharp_first_hit.py',
                  'joint/positive_cone.py','joint/physical_profile.py','joint/clip_polytope.py','joint/search_endpoint.py')
    raw_geo=json.loads((a.case/'geometry-area.json').read_bytes())
    return dict(complete=True,scout=a.scout,physical=cfg,geometry_sha256=raw_geo['chart']['geometry_sha256'],
                physical_graph_endpoint=raw_geo['chart']['physical_graph_endpoint'],bin_range=[a.start,a.finish],
                EH_retreat=str(RETREAT),EH_cost_upper=str(cost),EH_source_sha256=digest(eh),
                source_sha256={name:digest(HERE/name)for name in source_names},
                all_passed=all(t.get('first_positive_impossible') or
                               (not t.get('rejected') and t['zero'][0] and t['positive'][0])for t in rows),
                rows=rows)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('case',type=Path)
    p.add_argument('out',type=Path)
    p.add_argument('start',type=int)
    p.add_argument('finish',type=int)
    p.add_argument('--scout',action='store_true')
    a=p.parse_args()
    a.out.write_text(json.dumps(solve(a),indent=2)+'\n')

"""Read the paired (ℓ,t) enclosures from the frozen physical AH chart."""
import inspect
import linecache

from certify_ah_two_hit_budgets import geometry as budget_geometry
from certify_sigma_ah_full_chart import geometry as full_geometry
from certify_sigma_extended_graph import geometry as extended_geometry

LIST = 'physical_vertical_coordinates=[]\n'
RECORD = '    physical_vertical_coordinates.append(t)\n'


def execute(src, name, env):
    filename=f'<AH chart reader {name}>'
    linecache.cache[filename]=len(src),None,src.splitlines(keepends=True),filename
    exec(compile(src,filename,'exec'),env)


def with_global(fn, key, value):
    env = {**fn.__globals__, key: value}
    execute(inspect.getsource(fn),key,env)
    return env[fn.__name__]


def geometry(*args, **kw):
    env = dict(budget_geometry.__globals__)
    source = inspect.getsource(budget_geometry)
    anchor = "    ns={'__file__':old['__file__'],'__name__':'__main__'}"
    assert source.count(anchor)==1
    extra = (
        "    prefix=replace_line(prefix,'physical_deficits=[]',"
        f"{(LIST+'physical_deficits=[]')!r})\n"
        "    prefix=replace_line(prefix,'    physical_deficits.append((l,cell_deficit))',"
        f"{(RECORD+'    physical_deficits.append((l,cell_deficit))')!r})\n")
    execute(source.replace(anchor,extra+anchor),'source',env)
    full=with_global(full_geometry,'assemble',env['geometry'])
    ext=with_global(extended_geometry,'base',full)
    ns,src,info=ext(*args,**kw)
    assert src.count(LIST)==src.count(RECORD)==1
    assert len(ns['physical_vertical_coordinates'])==len(ns['physical_deficits'])
    return ns,src.replace(LIST,'').replace(RECORD,''),info

"""Close both zero-deficit and all-depth tail branches of the AH .01350 graph."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import inspect
import json
from pathlib import Path
import sys

from flint import arb
HERE=Path(__file__).resolve().parent
GEOMETRY='d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'
RETREAT=F('.00000009488')
BRACKETS=tuple((l,r) for l,r in (('.5','6.2'),('.5','6.15'),('.5','6.25'),
    ('.5','6.3'),('.5','6.10'),('.5','6.4'),('.5','6.0'),('.5','6.5'),
    ('.5','6.6'),('.5','6.8'),('.25','6.20'),('.25','7.0'),('.1','8.0')))
MARGINS=('root_margin_lower','placement_margin_lower')

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def load(a):
    sys.path[:0]=[str(HERE),str(a.comp.resolve())]
    from chart_geometry import geometry
    from certify_sigma_reachable_roots import reach
    from certify_ah_local_physical_support import validate
    from ordered_state import support_bound
    cfg=read(a.case/'physical.json')
    area=read(a.case/'geometry-area.json')
    assert cfg==area['parameters']
    assert cfg['sigma_degrees']=='1.54'
    p,d=map(F,cfg['line'])
    assert p==F('.429')
    far,negative,eps=map(F,cfg['physical_parameters'])
    graph_end=F(area['chart']['physical_graph_endpoint'])
    ns,src,_=geometry(a.comp.resolve(),[(p,d)],sigma=cfg['sigma_degrees'],
        far=far,negative=negative,eps=eps,graph_end=graph_end)
    assert sha256(src.encode()).hexdigest()==area['chart']['geometry_sha256']
    assert F(ns['eh_depth'])==F('.000555')
    assert ns['cuts'][-1]==(p,d)
    assert all(0<x<p and 0<y<d for x,y in ns['cuts'][:-1])
    # The EH retreat belongs to the original transfer. Verify its own true
    # rational cost instead of inheriting a numerical offset.
    eh=a.main_comp/'sigma154-ah429-eh-chain997-composition.json'
    assert digest(eh)=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
    assert read(eh)['sigma']=='1.54'
    cost=F(read(eh)['transfer_cost']['exact'][1])
    assert 0<cost<RETREAT
    return ns,cfg,reach,validate,support_bound,eh,cost

def build(ns,validate,support):
    code=inspect.getsource(support)
    mark="    first,second=n['two_hit_budgets'][j][ori]\n"
    assert code.count(mark)==1
    code=code.replace(mark,mark+"    second=zero\n")
    ev=dict(support.__globals__)
    exec(compile(code,'ah01350_true_zero_partner','exec'),ev)
    kernel=ev['support_bound']
    sel,=[i for i,(name,_,_)in enumerate(ns['rows']) if name.startswith('U1-Te')]
    name,n,h=ns['rows'][sel]
    ns['rows'][sel]=name,n,h-ns['A'](RETREAT)
    ns.update(_sharpen_jets=True,_tighten_first=True,_first_orientation=0,_class_counts=(5,))
    def block_support(state,j,a,b):
        lo,hi=state['knots'][j:j+2]
        k,l=state['_physical_block']
        step=(hi-lo)/75
        assert a==lo+step*k and b==a+step and k<l
        return kernel(state,j,a,lo+step*l)
    ev={**validate.__globals__,'support_bound':block_support}
    exec(compile(inspect.getsource(validate),'ah01350_pinned_root','exec'),ev)
    return ev['validate'],sha256(code.encode()).hexdigest()

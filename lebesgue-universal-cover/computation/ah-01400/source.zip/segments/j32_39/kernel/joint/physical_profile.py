"""Transfer the real positive AH depth table to the same ordered mate variables."""
from fractions import Fraction as F

from sharp_first_hit import dyadic


def upper_hull(points):
    upper = {}
    for x, y in points:
        upper[x] = max(upper.get(x, F(0)), y)
    hull = []
    for point in sorted(upper.items()):
        while len(hull) >= 2:
            a, b = hull[-2:]
            if ((b[0]-a[0])*(point[1]-b[1]) <
                    (b[1]-a[1])*(point[0]-b[0])):
                break
            hull.pop()
        hull.append(point)
    return hull


def profile(ns, mate_l, f, m):
    """Return exact necessary halfplanes in (e/F,r,s)."""
    A = ns['A']
    factor = m/(2*A(f))
    lo, hi = mate_l.lower(), mate_l.upper()
    positions = []
    ord_line = []
    for index, (ell, depth) in enumerate(ns['physical_deficits']):
        if depth.is_zero():
            continue
        assert depth > 0
        a = max(F(0), dyadic((factor*(lo-ell.upper())).lower()))
        b = min(F(1), dyadic((factor*(hi-ell.lower())).upper()))
        if a <= b:
            d = dyadic((depth/A(f)).upper())
            ord_line.append((index, a, b, d))
            positions.extend(((a, d), (b, d)))
    hull = upper_hull(positions)
    if not hull:
        return [((0, 0, 0), F(-1))], dict(cells=[], upper_hull=[])
    r_low,r_high=hull[0][0],hull[-1][0]
    cuts = [((0,-1,0), -r_low), ((0,1,0), r_high)]
    if len(hull) == 1:
        cuts.append(((1,2,-2), hull[0][1]))
    for (x0,y0),(x1,y1) in zip(hull,hull[1:]):
        slope = (y1-y0)/(x1-x0)
        intercept = y0-slope*x0
        cuts.append(((1,2-slope,-2),intercept))
    record = dict(cells=[[i,str(a),str(b),str(d)]for i,a,b,d in ord_line],
                  upper_hull=[list(map(str,v)) for v in hull])
    return cuts, record


def vertical_profile(ns, mate_l, mate_t, f, m):
    """Transport the joint physical (ell,t) outer boxes to (r,C/F)."""
    A=ns['A']
    lo,hi=mate_l.lower(),mate_l.upper()
    factor=m/(2*A(f))
    cells=zip(ns['physical_deficits'],ns['physical_vertical_coordinates'],strict=True)
    low=[]
    high=[]
    for (ell,depth), t in cells:
        if depth.is_zero():
            continue
        assert depth>0
        a=max(F(0),dyadic((factor*(lo-ell.upper())).lower()))
        b=min(F(1),dyadic((factor*(hi-ell.lower())).upper()))
        if a>b:
            continue
        c=(t-mate_t)/A(f)
        u,v=dyadic(c.lower()),dyadic(c.upper())
        low.extend(((a,-u),(b,-u)))
        high.extend(((a,v),(b,v)))
    if not low:
        return [((0,0,0),F(-1))],dict(lower=[],upper=[])
    lower,upper=upper_hull(low),upper_hull(high)
    cuts=[]
    for sense,hull in ((-1,lower),(1,upper)):
        if len(hull)==1:
            cuts.append(((-sense,0,2*sense),hull[0][1]))
        for (x0,y0),(x1,y1) in zip(hull,hull[1:]):
            slope=(y1-y0)/(x1-x0)
            cuts.append(((-sense,-slope,2*sense),y0-slope*x0))
    return cuts,dict(lower=[[str(x),str(-y)]for x,y in lower],
                     upper=[[str(x),str(y)]for x,y in upper])

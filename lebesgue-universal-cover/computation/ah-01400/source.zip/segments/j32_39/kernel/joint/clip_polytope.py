"""Exact halfspace clipping of a bounded polytope already given by its vertices."""
from itertools import combinations


def dot(a, b):
    return sum(x*y for x,y in zip(a,b,strict=True))


def independent(a,b):
    return (a[1]*b[2] != a[2]*b[1] or
            a[2]*b[0] != a[0]*b[2] or
            a[0]*b[1] != a[1]*b[0])


def clip(vertices, initial_rows, cuts):
    rows=list(initial_rows)
    verts=list(vertices)
    active={v: frozenset(i for i,(n,h)in enumerate(rows) if dot(n,v)==h)
            for v in verts}
    for n, h in cuts:
        depths={v: dot(n,v)-h for v in verts}
        outside=[v for v in verts if depths[v]>0]
        if not outside:
            continue
        inside=[v for v in verts if depths[v]<0]
        kept={v:active[v] for v in inside}
        entering=len(rows)
        for v in verts:
            if depths[v]==0:
                kept[v]=active[v]|{entering}
        for a in inside:
            for b in outside:
                common=active[a]&active[b]
                if not any(independent(rows[i][0],rows[j][0])
                           for i,j in combinations(common,2)):
                    continue
                u,v=depths[a],depths[b]
                pt=tuple((s*v-t*u)/(v-u)
                         for s,t in zip(a,b,strict=True))
                kept[pt]=common|{entering}
        if not kept:
            return []
        rows.append((n,h))
        active=kept
        verts=list(active)
    return sorted(verts)

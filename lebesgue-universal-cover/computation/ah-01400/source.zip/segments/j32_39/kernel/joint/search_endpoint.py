"""Find strict signs for a common bracket on a closed physical block."""
from fractions import Fraction as F
from itertools import product

from clip_polytope import clip,dot
from positive_cone import support_for_cone,vertices


def signed_endpoint(ns, packet, phi, sign):
    A=ns['A']
    E,v,edges,bound,_=packet
    n0=ns['av'](ns['d']['n'][0])
    angle=A(phi)
    args=[(A(-sign*(-1)**k),ns['rotate'](n0,ns['trig'](angle+A(60*k)))) for k in range(3)]
    return (sign*ns['F_at'](v,edges,angle)-E*bound(args)).lower()


def halfplanes(axis, low, high, count):
    if count==1:
        return [[]]
    return [[(axis, low+(high-low)*F(k+1,count)),
             (tuple(-u for u in axis), -low-(high-low)*F(k,count))] for k in range(count)]


def cases_of(model):
    data=model[3]
    physical=[(tuple(map(F,n)),F(h)) for n,h in data['physical_profile_rows']]
    gamma=F(data['M_over_m_upper'])
    standard=[((0,-1,0),0),((0,1,-1),0),((-1,0,1),0),
              ((1,0,0),1),((-1,-2*gamma,2),0)]
    cases=[]
    for item in data['cuts']:
        n,h=item['necessary_halfplane']
        sense=item['C_sign']
        rows=[*standard,((sense,0,-2*sense),0),(tuple(map(F,n)),F(h))]
        pts=clip(vertices(rows),rows,physical)
        assert len(pts)==item['vertices']
        if pts:
            active=[(n,h)for n,h in rows+physical if any(dot(n,v)==h for v in pts)]
            cases.append((pts,active))
    assert sorted({q for pts,_ in cases for q in pts})==model[2]
    return cases


def patches(ns, model, cases, count):
    parts=product(halfplanes((0,1,0),0,1,count[0]),
                  halfplanes((-1,0,2),-1,1,count[1]),
                  halfplanes((1,0,0),0,1,count[2]))
    records=[]
    for i,(xs,ys,zs) in enumerate(parts):
        patch=[*xs,*ys,*zs]
        pts=sorted({p for ext,rows in cases for p in clip(ext,rows,patch)})
        if pts:
            local=(model[0],model[1],pts,model[3])
            records.append((i,len(pts),support_for_cone(ns,local)))
    assert records
    return records

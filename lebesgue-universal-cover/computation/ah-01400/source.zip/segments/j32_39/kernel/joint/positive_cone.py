"""True-mate retention cuts in (e/F, e*y3/F, e*y4/F), with exact rational vertices."""
from fractions import Fraction as F
from inspect import getclosurevars
from itertools import combinations, product

from certify_ah_single_contact_chain import local_slope
from certify_sigma_pinned_fan import support_bound as original_support
from sharp_first_hit import dyadic,first_budget
from physical_profile import profile,vertical_profile
from clip_polytope import clip as exact_clip


def add(x,y):return tuple(a+b for a,b in zip(x,y,strict=True))
def sub(x,y):return tuple(a-b for a,b in zip(x,y,strict=True))
def scale(s,x):return tuple(s*a for a in x)
def dot(x,y):return sum(a*b for a,b in zip(x,y,strict=True))
def cross(x,y):
    a,b,c=x;d,e,f=y
    return b*f-c*e,c*d-a*f,a*e-b*d


def vertices(rows):
    result=set()
    for ((x,bx),(y,by),(z,bz)) in combinations(rows,3):
        yz,zx,xy=cross(y,z),cross(z,x),cross(x,y)
        det=dot(x,yz)
        if not det:continue
        p=scale(F(1)/det,add(add(scale(bx,yz),scale(by,zx)),scale(bz,xy)))
        if all(dot(n,p)<=h for n,h in rows):result.add(p)
    return sorted(result)


def slope_upper_table(ns,ori):
    key=('_cone_slope_upper',ori)
    data=ns.get(key)
    if data is not None:return data
    A,add,mul,dot=(ns[k] for k in ('A','add','mul','dot'))
    z,D=ns['z'],ns['D']
    data=[]
    assert F(ns['wmax'])*1000==int(F(ns['wmax'])*1000)
    for j in range(int(F(ns['wmax'])*1000)):
        a,b=F(j,1000),F(j+1,1000)
        ell=[ns['chart'](add(z,mul(A(q),D)))[0] for q in (a,b)]
        ll=ell[0].union(ell[1]);lp=ns['coord_hull'](ns['psi'],ll)
        _,g,t=ns['points'](ns['box'](a,b))
        lprime=dot(g,D);tprime=dot(t,D)
        assert lprime<0
        ratio=-ns['psi_prime'](add(ns['l0'],mul(ll,ns['el'])))
        speed=-tprime/lprime
        assert speed>A('3.5') and A('.95')<ratio<A('1.05')
        data.append((ll,speed.upper()) if ori else (lp,(speed/ratio).upper()))
    ns[key]=data
    return data


def base_data(ns,j,a,b):
    """The actual old support callback fixes the exact F,S,m used here."""
    E,v,edges,hull_bound,_=original_support(ns,j,a,b)
    base=getclosurevars(hull_bound).nonlocals
    ce=getclosurevars(base['event']).nonlocals
    ori=ns['_first_orientation']
    old_f,s=ce['ns']['two_hit_budgets'][j][ori]
    f=dyadic(first_budget(ns,a,b,old_f).upper())
    m=ce['local_m'][ori]
    return E,v,edges,base,F(f),s,m


def cone_model(ns,j,a,b,extra=()):
    A,add,sub,mul,dot,cross=(ns[k] for k in ('A','add','sub','mul','dot','cross'))
    zero=A(0);D,z=ns['D'],ns['z']
    old=base_data(ns,j,a,b)
    E,v,edges,base,Ff,S,m=old
    f=A(Ff)
    assert f>0 and m>3,(str(Ff),str(S),str(m))

    def xy(w):return ns['chart'](add(z,mul(A(w),D)))
    ori=ns['_first_orientation']

    def partner_coord(w):
        l,t=xy(w)
        return (l,t) if ori else (ns['psi'](l),-t)

    def ideal(w):return ns['X'](*partner_coord(w))

    ell,t=[u.union(v) for u,v in zip(xy(a),xy(b),strict=True)]
    lp=ns['coord_hull'](ns['psi'],ell)
    mid=(a+b)/2
    qa,qb,qm=ideal(a),ideal(b),ideal(mid)
    mate_l,mate_t=(ell,t) if ori else (lp,-t)
    dl0,dt0=ns['derivs'](*ns['chart_bounds'](mate_l,mate_t))
    _,gl,gt=ns['points'](ns['box'](a,b))
    p_w=ns['psi_prime'](add(ns['l0'],mul(ell,ns['el'])))*dot(gl,D)
    qt=add(mul(dot(gl,D),dl0),mul(dot(gt,D),dt0)) if ori else sub(mul(p_w,dl0),mul(dot(gt,D),dt0))
    xi=(-2*f/m).union(zero)
    mate,lc,nc=ns['chart_bounds'](mate_l+xi,mate_t+(-f).union(f))
    ss=dot(sub(nc,lc),sub(nc,lc));cc=-cross(sub(mate,lc),sub(mate,nc))
    assert 0<ss<4 and cc>0
    ql,qv=ns['derivs'](mate,lc,nc)
    target=mate_l+xi
    table=slope_upper_table(ns,ori)
    matched=[x for dom,x in table if dom.overlaps(target)]
    assert matched
    # Check strict containment in the true first and last endpoints of the
    # positive paired graph before using its 430-interval slope table.
    lp0=partner_coord(F(0))[0];lp1=partner_coord(F(ns['wmax']))[0]
    assert (lp1<target<lp0) if ori else (lp0<target<lp1),('paired graph range',ori,lp0,target,lp1)
    M=max(matched)
    gamma=dyadic((M/m).upper())
    # Order tetrahedron in variables (tau,r,s)=(e,e*y3,e*y4)/F.
    standard=[((0,-1,0),0),((0,1,-1),0),((-1,0,1),0),((1,0,0),1)]
    # Positive real second deficit implies C <= M * (-xi).
    standard.append(((-1,-2*gamma,2),0))
    physical, physical_receipt = profile(ns, mate_l, Ff, m)
    vertical, vertical_receipt = vertical_profile(ns, mate_l, mate_t, Ff, m)
    physical.extend(vertical)
    cuts=[q for q in ns['rows'] if q[0].startswith('AH-line:')]
    assert [q[0] for q in cuts]==[f'AH-line:{k}' for k in range(4)]
    results=[]
    ledger=[]
    for (name,n,h),p,d in zip(cuts,ns['pivot_set'],ns['cut_dirs'],strict=True):
        assert all(x.contains(0) for x in sub(n,mul(-1,ns['perp'](d))))
        assert (h-dot(n,p)).contains(0)
        drift=-dot(n,qt)
        if drift>0:basecut=h-dot(n,qa)
        elif drift<0:basecut=h-dot(n,qb)
        else:basecut=h-dot(n,qm)+ns['box'](a-mid,b-mid)*drift
        al=dot(n,ql)/m;bt=dot(n,qv)
        alpha=dyadic(al.lower())
        clip=-dyadic(basecut.lower())/Ff
        for sign in (1,-1):
            beta=dyadic(bt.upper() if sign==1 else bt.lower())
            condition=((beta,2*alpha,-2*beta),clip)
            sign_constraint=((sign,0,-2*sign),0)
            halfplanes=[*standard,*extra,sign_constraint,condition]
            extreme=exact_clip(vertices(halfplanes),halfplanes,physical)
            results.extend(extreme)
            ledger.append(dict(cut=name,C_sign=sign,vertices=len(extreme),
                               necessary_halfplane=[list(map(str,condition[0])),str(condition[1])]))
    ext=sorted(set(results))
    meta=dict(F= str(Ff), S=str(S), m=str(m), graph_slope_upper=str(M), M_over_m_upper=str(gamma),
              w=[str(a),str(b)],physical_profile=physical_receipt,vertical_profile=vertical_receipt,physical_profile_rows=[(list(map(str,n)),str(h)) for n,h in physical],extra=[(list(map(str,n)),str(h)) for n,h in extra],mate_circle_clearance=str(cc.lower()),cuts=ledger,
              scaled_vertices=[list(map(str,p)) for p in ext])
    return old,(ell,t,lp),ext,meta


def support_for_cone(ns,model):
    old,(ell,t,lp),ext,meta=model
    E,v,edges,base,Ff,S,m=old
    assert ext
    A,add,mul,dot,reflect=(ns[k] for k in ('A','add','mul','dot','reflection'))
    zero=A(0);z=(zero,zero)
    f=A(Ff)

    def bounded(vals):return min(x.lower() for x in vals).union(max(x.upper() for x in vals))

    depth=bounded([A(p[0])*f for p in ext])
    xi=bounded([-2*f*A(p[1])/m for p in ext])
    C=bounded([(2*A(s)-A(e))*f for e,r,s in ext])
    loc={}
    ori=ns['_first_orientation']
    if ori:
        ranges=((4,ell,t,xi,C),(2,lp,-t,zero,-depth))
    else:
        ranges=((4,ell,t,zero,-depth),(2,lp,-t,xi,C))
    for k,L,T,dl,dt in ranges:
        su=z;sv=z
        for step in range(8):
            lam=A(F(step,8)).union(A(F(step+1,8)))
            x,c,d=ns['chart_bounds'](L+lam*dl,T+lam*dt)
            dlx,dtx=ns['derivs'](x,c,d)
            su=add(su,mul(A(F(1,8)),dlx));sv=add(sv,mul(A(F(1,8)),dtx))
        loc[k]=(su,sv) if k==4 else (reflect(su),reflect(sv))
    actual=[[A(x) for x in p] for p in ext]
    largest=base['extremal']
    z5lo,z5hi=map(A,ns.get('_y5_band',(F(0),F(1))))

    def event(action):
        vec=[z]*5
        for i,u in action:vec[i]=add(vec[i],u)
        ll=dot(vec[0],ns['el'])
        lr=dot(vec[1],reflect(ns['el']))
        de=dot(vec[3],ns['en'])
        a2,t2=(dot(vec[2],u) for u in loc[2])
        a4,t4=(dot(vec[4],u) for u in loc[4])
        x,eta,xi,first,de,partner=(ll,lr,a2,t4,de,t2) if ori==0 else (lr,ll,a4,t2,-de,t4)
        c1,c2,c3,c4,c5=(x/(m*A('.95')),-eta/m,-xi/m,partner,-de)
        c12=largest([zero,c2,c1+c2])
        const=de-first-partner
        vals=[]
        for e,r,s in actual:
            last=largest([c5*s.max(z5lo*e),c5*z5hi*e])
            vals.append(2*((c12+c3)*r+c4*s+last)+const*e)
        return f*largest(vals)/E

    def bound(terms):
        choices=base['choices'];adj=base['correction'](terms)
        return largest([event(sum(c,[])+adj) for c in product(*(choices(w,u) for w,u in terms))]).upper()

    return E,v,edges,bound,None

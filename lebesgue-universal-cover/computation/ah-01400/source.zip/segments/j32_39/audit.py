"""Audit the complete oriented closed blocks on the selected true chart."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

from flint import arb,ctx

POSES={f'{i},{s}' for i in range(0,360,60) for s in (-1,1)}
COUNTS={(2,2,1),(2,2,2),(4,2,2),(8,4,4)}
RETREAT=F('.00000009488')


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def audit(case,source,raws):
    ctx.prec=160
    geom=read(case/'geometry-area.json')
    physical=read(case/'physical.json')
    assert physical==geom['parameters']
    chart=geom['chart']
    g=chart['geometry_sha256']
    eh=case/'comp/sigma154-ah429-eh-chain997-composition.json'
    assert sha(eh)==geom['geometry']['EH_first'][eh.name]
    cost=F(read(eh)['transfer_cost']['exact'][1])
    _,eleven=geom['geometry']['cases']
    assert eleven['label']=='eleven' and F(eleven['transfer_cost_upper'])==cost<RETREAT
    sources={}
    seen={}
    for name in raws:
        data=read(name)
        assert data['complete'] and data['all_passed'] and not data['scout']
        assert data['geometry_sha256']==g and data['physical']==physical
        assert F(data['physical_graph_endpoint'])==F(chart['physical_graph_endpoint'])
        assert data['EH_source_sha256']==sha(eh)
        assert F(data['EH_cost_upper'])==cost and F(data['EH_retreat'])==RETREAT
        for p,expected in data['source_sha256'].items():
            assert sha(source/p)==expected
        a,b=data['bin_range']
        expected=[]
        for j in range(a,b+1):
            [entry]=chart['reference_ranges'][str(j)]
            assert entry[0]==0
            length=entry[1]
            for o in (0,1):
                expected.extend((j,o,(k,min(k+5,length)))for k in range(0,length,5))
        keys=[(r['j'],r['ori'],tuple(r['block']))for r in data['rows']]
        assert keys==expected
        for key,r in zip(keys,data['rows'],strict=True):
            assert key not in seen
            seen[key]=r
        sources[name.name]=sha(name)
    bins=sorted({x[0] for x in seen})
    assert bins==list(range(bins[0],bins[-1]+1))
    counts={}
    margins={}
    summary=[]
    for j in bins:
        points=[(o,b,r)for (i,o,b),r in seen.items()if i==j]
        n=chart['reference_ranges'][str(j)][0][1]
        reached=sum(b[1]-b[0]for o,b,_ in points if o==0)
        assert reached==n
        audited=0
        for o,b,r in points:
            k,last=b
            assert 'rejected' not in r
            if k>0:
                prev=seen[j,o,(k-5,k)]
                assert F(prev['w'][1])==F(r['w'][0])
            if r.get('first_positive_impossible'):
                assert o==1 and seen[j,0,b]['zero'][0]
                counts['zero_label']=counts.get('zero_label',0)+1
                continue
            for mode in ('zero','positive'):
                ok,cell=r[mode]
                assert ok
                if cell is None:
                    assert mode=='positive'
                    assert r.get('first_primary_zero') or not r['condition']['scaled_vertices']
                    counts['positive_empty']=counts.get('positive_empty',0)+1
                    continue
                assert cell['reference_bin']==j and cell['subcells']==[k,k+1]
                assert cell['starting_angle_cells']==12 and cell['placed_leaves']>0
                assert cell['placed_leaves']+cell['root_free_leaves']>=12
                assert set(cell['verified_dihedral_pose_counts'])<=POSES
                assert sum(cell['verified_dihedral_pose_counts'].values())==cell['placed_leaves']
                if mode=='positive':
                    bounds=cell['endpoint_support']
                    assert arb(bounds['left_lower'])>0 and arb(bounds['right_lower'])>0
                    if bounds['partition'] is not None:
                        assert tuple(bounds['partition']) in COUNTS
                        assert len(bounds['active'])>0
                        size=1
                        for n0 in bounds['partition']:
                            size*=n0
                        assert all(0<=a<size and b0>0 for a,b0 in bounds['active'])
                    assert abs(arb(cell['root_margin_lower'])-
                               min(arb(bounds['left_lower']),arb(bounds['right_lower'])))<arb('1e-35')
                for qty in ('root_margin_lower','placement_margin_lower'):
                    value=arb(cell[qty])
                    assert value>0
                    margins[qty]=min(margins.get(qty,arb(1)),value.lower())
                counts[mode]=counts.get(mode,0)+1
                audited+=1
        summary.append(dict(bin=j,physical_cells=n,closed_blocks=(n+4)//5,
                            labelled_rows=len(points),verified_branch_rows=audited))
    return dict(complete=True,physical=physical,geometry_sha256=g,
                physical_graph_endpoint=chart['physical_graph_endpoint'],bins=bins,
                physical_cells=sum(x['physical_cells']for x in summary),
                closed_blocks=sum(x['closed_blocks']for x in summary),labelled_rows=len(seen),
                counts=counts,minima={k:str(v)for k,v in margins.items()},
                area_eleven=eleven['area'],EH_retreat=str(RETREAT),EH_cost_upper=str(cost),
                geometry_area_file_sha256=sha(case/'geometry-area.json'),raw_sha256=sources,coverage=summary)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('case',type=Path)
    p.add_argument('source',type=Path)
    p.add_argument('out',type=Path)
    p.add_argument('raw',nargs='+',type=Path)
    a=p.parse_args()
    x=audit(a.case,a.source,a.raw)
    a.out.write_text(json.dumps(x,indent=2)+'\n')
    print(x['physical_cells'],x['closed_blocks'],x['labelled_rows'],x['minima'],flush=True)

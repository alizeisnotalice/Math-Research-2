"""Close the true-zero and true-positive mate branches on fixed closed physical blocks."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import inspect
import json
import sys

from flint import arb

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path[:0]=[str(ROOT),str(HERE)]
from certify_tail import BRACKETS,GEOMETRY,MARGINS,RETREAT,build,load


def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()


def run(a):
    ns,cfg,reach,prior_validator,support,eh,cost=load(a)
    from positive_cone import cone_model,support_for_cone

    uncond,ks=build(ns,prior_validator,support)
    ns['_e_class']=(F(0),F(1))
    model=None

    def positive_support(state,j,w0,w1):
        k,l=state['_physical_block']
        ka,kb=state['knots'][j:j+2];step=(kb-ka)/75
        assert w0==ka+k*step and w1==w0+step
        assert model[3]['w']==[str(w0),str(ka+l*step)]
        return support_for_cone(state,model)

    env={**prior_validator.__globals__,'support_bound':positive_support}
    exec(compile(inspect.getsource(prior_validator),'AH_gate_positive_mate','exec'),env)
    cond=env['validate']

    def trial(kernel,j,k,l,range_):
        ns['_physical_block']=k,l
        best_score=None;best=None
        for left,right in range_:
            t=kernel(ns,j,F(left),F(right),0,1,-1,begin=k,end=k+1,angular=12,depth=4)
            score=min(arb(t[c]) for c in MARGINS)
            if best_score is None or score>best_score:best_score,best=score,t
            if score>0 and t['placed_leaves']>0:
                assert t['placed_leaves']==sum(t['verified_dihedral_pose_counts'].values())
                return t,True
        return best,False

    counts={str(j):i for j,i in a.ranges}
    all_rows=[]
    for j,used in a.ranges:
        assert reach(ns,j)==[(0,75)] and ns['labelled_deficits'][1][j].is_zero()
        ka,kb=ns['knots'][j:j+2];step=(kb-ka)/75
        rows=[]
        blocks=range(0,used,5) if not a.scout else sorted({0,max(0,used-5)})
        for k in blocks:
            l=k+5
            model=cone_model(ns,j,ka+k*step,ka+l*step)
            ext=model[2]
            z,zok=trial(uncond,j,k,l,BRACKETS)
            p,pok=trial(cond,j,k,l,BRACKETS) if ext else (None,True)
            rows.append(dict(j=j,block=[k,l],scout=a.scout,zero=z,zero_pass=zok,positive=p,
                             positive_pass=pok,actual_positive_mate_empty=not ext,condition=model[3]))
            if a.scout or not pok or not zok:
                print('block',j,k,l,'poly verts',len(ext),'zero',zok,'pos',pok,
                      {name:p[name] for name in MARGINS} if p is not None else 'empty',flush=True)
        print(j,len(rows),sum(x['zero_pass'] and x['positive_pass'] for x in rows),flush=True)
        all_rows.extend(rows)
    return dict(complete=True,scout=a.scout,geometry_sha256=GEOMETRY,physical_parameters=cfg,
                EH_retreat=str(RETREAT),EH_cost_upper=str(cost),EH_source_sha256=digest(eh),zero_kernel=ks,
                ranges=counts,rows=all_rows,all_passed=all(x['zero_pass'] and x['positive_pass'] for x in all_rows),
                source_sha256={p.name:digest(p)for p in (Path(__file__),HERE/'positive_cone.py',ROOT/'certify_tail.py',
                    ROOT/'ordered_state.py',ROOT/'sharp_first_hit.py',ROOT/'physical-0140.json',ROOT/'geometry-area.json')})


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','main_comp','out'):p.add_argument(name,type=Path)
    p.add_argument('--ranges',required=True,type=lambda x:[tuple(map(int,a.split(':')))for a in x.split(',')])
    p.add_argument('--scout',action='store_true')
    a=p.parse_args()
    a.out.write_text(json.dumps(run(a),indent=2)+'\n')

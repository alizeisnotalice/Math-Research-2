"""Verify the .01400 tail's two genuine-mate branches and the .62 chart interface."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import sys

from flint import arb,ctx

PARTS=((40,49),(50,56),(57,63),(64,69))
SPECIAL={j:75 for j in range(40,50)}
SPECIAL[49]=70
LEAVES=('root_margin_lower','placement_margin_lower')
POSES={f'{i},{s}' for i in range(0,360,60) for s in (-1,1)}
GEO='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256'
RET=F('.00000009488')


def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()


def audit_leaf(r,j,k):
    assert r['reference_bin']==j and r['subcells']==[k,k+1]
    assert all(arb(r[n])>0 for n in LEAVES)
    assert set(r['verified_dihedral_pose_counts'])<=POSES
    assert sum(r['verified_dihedral_pose_counts'].values())==r['placed_leaves']>0
    assert r['placed_leaves']+r['root_free_leaves']>=r['starting_angle_cells']==12


def compose(work,comp):
    ctx.prec=160
    sys.path[:0]=[str(work),str(work/'joint'),str(comp)]
    from positive_cone import vertices

    params=read(work/'physical-0140.json')
    assert params==dict(sigma_degrees='1.54',line=['.429','.01400'],physical_parameters=['.352','.403','.020'])
    geom=read(work/'geometry-area.json')
    assert geom['parameters']==params and geom['chart']['geometry_sha256']==GEO
    assert F(geom['chart']['physical_graph_endpoint'])==F('.62')
    assert geom['chart']['reference_subcells']==5184
    actual=geom['chart']['reference_ranges']
    assert actual['69']==[[0,9]]
    area,=[x for x in geom['geometry']['cases'] if x['label']=='eleven']
    eh=comp/'sigma154-ah429-eh-chain997-composition.json'
    assert sha(eh)==geom['geometry']['EH_first'][eh.name]=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
    cost=F(read(eh)['transfer_cost']['exact'][1])
    assert F(area['transfer_cost_upper'])==cost and 0<cost<RET
    files={name:sha(work/name) for name in ('physical-0140.json','geometry-area.json','certify_tail.py','partner_retention.py',
        'ordered_state.py','sharp_first_hit.py','joint/joint_tail.py','joint/positive_cone.py')}
    files['compose.py']=sha(Path(__file__))
    special={};kernels=set()
    statistics={k:[] for k in ('zero_depth','zero_mate','positive_mate')}
    n_empty=0;n_positive=0
    positive_vertex_tot=0
    det_min=arb(1)
    for a,b in ((40,44),(45,49)):
        name=f'joint/joint-{a}-{b}.json'
        d=read(work/name);files[name]=sha(work/name)
        assert d['complete'] and d['all_passed'] and not d['scout']
        assert d['geometry_sha256']==GEO and d['physical_parameters']==params
        assert d['ranges']=={str(j):SPECIAL[j] for j in range(a,b+1)}
        assert F(d['EH_retreat'])==RET and F(d['EH_cost_upper'])==cost and d['EH_source_sha256']==sha(eh)
        for filename,val in d['source_sha256'].items():
            pos=work/filename
            assert sha(pos if pos.exists() else work/'joint'/filename)==val
        kernels.add(d['zero_kernel'])
        for r in d['rows']:
            j=r['j'];k,l=r['block']
            assert a<=j<=b and 0<=k<l<=SPECIAL[j] and k%5==0 and l==k+5
            assert (j,k,l) not in special and r['zero_pass'] and r['positive_pass'] and not r['scout']
            c=r['condition']
            f=F(c['F']);gamma=F(c['M_over_m_upper'])
            assert 0<f and arb(c['S'])>arb(f.numerator)/f.denominator
            assert arb(c['m'])>3 and gamma>0
            det=arb(c['mate_circle_clearance']);assert det>0
            det_min=min(det_min,det.lower())
            standard=[((0,-1,0),0),((0,1,-1),0),((-1,0,1),0),((1,0,0),1),((-1,-2*gamma,2),0)]
            assert [(x['cut'],x['C_sign']) for x in c['cuts']]==list(product((f'AH-line:{i}' for i in range(4)),(1,-1)))
            extreme=set()
            for shut in c['cuts']:
                n,h=shut['necessary_halfplane'];sign=shut['C_sign']
                v=vertices([*standard,((sign,0,-2*sign),0),(tuple(map(F,n)),F(h))])
                assert len(v)==shut['vertices']
                extreme.update(v)
            assert sorted(extreme)==[tuple(map(F,q)) for q in c['scaled_vertices']]
            flag=r['actual_positive_mate_empty']
            assert flag==(not extreme)
            if flag:
                assert r['positive'] is None
                n_empty+=1
            else:
                audit_leaf(r['positive'],j,k)
                statistics['positive_mate'].append(r['positive'])
                n_positive+=1
                positive_vertex_tot+=len(extreme)
            audit_leaf(r['zero'],j,k)
            statistics['zero_mate'].append(r['zero'])
            special[j,k,l]=tuple(map(F,c['w']))
    assert len(kernels)==1
    assert set(special)=={(j,k,k+5) for j,n in SPECIAL.items() for k in range(0,n,5)}
    marked={(j,i) for j,n in SPECIAL.items() for i in range(n)}
    assert len(marked)==745 and len(special)==149
    n_cells=0;n_blocks=0;n_unsupported_by_rectangle=0
    per=[]
    min_mate=arb(1);min_nom=arb(1)
    for a,b in PARTS:
        n1,n2=f'partner-{a}-{b}.json',f'tail-{a}-{b}.json'
        p,q=read(work/n1),read(work/n2);files[n1]=sha(work/n1);files[n2]=sha(work/n2)
        assert p['geometry_sha256']==q['geometry_sha256']==GEO and p['complete'] and q['all_zero']
        assert p['physical_parameters']==q['params']==params and p['orientation']==0
        assert p['verifier_sha256']==files['partner_retention.py']
        assert q['zero_partner_kernel_sha256'] in kernels
        assert q['source_sha256'][n1]==files[n1]
        assert q['EH_source_sha256']==sha(eh) and F(q['EH_retreat'])==RET and F(q['EH_cost_upper'])==cost
        for f,h in q['source_sha256'].items():assert sha(work/f)==h
        assert [(s['j'],s['i']) for s in p['cases']]==list(product(range(a,b+1),range(75)))
        assert [s['j'] for s in q['coverage']]==list(range(a,b+1))
        log={}
        for s in p['cases']:
            j,i=s['j'],s['i']
            n=9 if j==69 else 75
            if i>=n:continue
            vals=[arb(v) for v in s['all_AH_slacks']]
            nom=[arb(v) for v in s['nominal_slacks']]
            assert len(vals)==len(nom)==4 and min(nom)>0
            assert s['positive']==(min(vals)>0)
            if (j,i) not in marked:
                assert s['positive']
                min_mate=min(min_mate,*[x.lower() for x in vals])
            if not s['positive']:n_unsupported_by_rectangle+=1
            min_nom=min(min_nom,*[x.lower() for x in nom])
            for field in ('front_tube','partner_tube'):
                lo,hi,d=map(arb,s[field]);assert 0<lo<hi<4 and d>0
                det_min=min(det_min,d.lower())
            log[j,i]=tuple(map(F,s['w']))
        for row in q['coverage']:
            j=row['j'];n=9 if j==69 else 75
            assert row['reach']==[[0,n]]==actual[str(j)] and row['cells']==n
            assert row['positive_orientation_1_empty']
            assert all(log[j,i][1]==log[j,i+1][0] for i in range(n-1))
            coverage=[];normal_blocks=0
            for s in row['rows']:
                k,l=s['block'];assert 0<=k<l<=n and s['zero_pass']
                coverage.extend(range(k,l));audit_leaf(s['zero'],j,k)
                assert s['zero']['physical_block']==[k,l]
                statistics['zero_depth'].append(s['zero'])
                cells={(j,i) for i in range(k,l)}
                if cells&marked:
                    assert cells<=marked
                else:
                    assert s['partner_retained'] and s['all_e_pass']
                    audit_leaf(s['all_e'],j,k)
                    assert s['all_e']['physical_block']==[k,l]
                    statistics['zero_mate'].append(s['all_e'])
                    normal_blocks+=1
            assert coverage==list(range(n))
            rescued=[(k,l) for (u,k,l) in special if u==j]
            assert all(special[j,k,l]==(log[j,k][0],log[j,l-1][1]) for k,l in rescued)
            n_blocks+=normal_blocks+len(rescued)
            n_cells+=n
            per.append(dict(bin=j,reach=row['reach'],physical_cells=n,ordinary_blocks=normal_blocks,
                            positive_cone_blocks=len(rescued)))
    assert n_cells==2184 and n_blocks==437 and n_unsupported_by_rectangle==741
    assert len(per)==30
    summary={k:dict(rows=len(v),root_lower=str(min(arb(x['root_margin_lower']).lower() for x in v)),
                      pose_lower=str(min(arb(x['placement_margin_lower']).lower() for x in v)),
                      placed_leaves=sum(x['placed_leaves'] for x in v),root_free_leaves=sum(x['root_free_leaves'] for x in v))
             for k,v in statistics.items()}
    files[eh.name]=sha(eh)
    return dict(complete_tail=True,physical_parameters=params,geometry_sha256=GEO,EH_retreat=str(RET),
                EH_transfer_upper=str(cost),candidate_area_eleven=area['area'],cells=n_cells,closed_blocks=n_blocks,
                all_orientation_1_positive_first_deficits_absent=True,
                ordinary_true_zero_partner_cells=n_cells-len(marked),
                covered_by_joint_mate_cone_cells=len(marked),joint_mate_blocks_empty=n_empty,
                joint_mate_blocks_nonempty=n_positive,total_joint_vertices=positive_vertex_tot,
                ordinary_partner_retaining_margin=str(min_mate),all_ideal_partner_margin=str(min_nom),
                true_circles_negative_cross_min=str(det_min),branch_summary=summary,per_bin=per,sources=files)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('work','comp','out'):p.add_argument(key,type=Path)
    a=p.parse_args()
    result=compose(a.work.resolve(),a.comp.resolve())
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['cells'],result['closed_blocks'],result['joint_mate_blocks_nonempty'],result['branch_summary'],flush=True)

"""Rebuild the frozen .01400 true chart, ordinary tail, and joint positive mate branches."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil
from subprocess import DEVNULL,run
import sys

HERE=Path(__file__).resolve().parent
PARTS=((40,49),(50,56),(57,63),(64,69))
CONES=(('40-44','40:75,41:75,42:75,43:75,44:75'),('45-49','45:75,46:75,47:75,48:75,49:70'))
INPUTS=('physical-0140.json','geometry-area.json','certify_tail.py','partner_retention.py',
        'ordered_state.py','sharp_first_hit.py','compose.py','joint/positive_cone.py','joint/joint_tail.py')


def replay(out):
    out.mkdir(parents=True,exist_ok=True)
    assert not any(out.iterdir())
    for n in INPUTS:
        (out/n).parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(HERE/n,out/n)
    shutil.copytree(HERE/'comp012',out/'comp012')

    def task(exe,args,expected,stdout=None):
        command=[sys.executable,'-I','-B',exe,*map(str,args)]
        if stdout is None:
            run(command,cwd=out,check=True,stdout=DEVNULL)
        else:
            with (out/stdout).open('w') as f:run(command,cwd=out,check=True,stdout=f)
        for actual,frozen in expected:
            assert (out/actual).read_bytes()==(HERE/frozen).read_bytes(),(actual,frozen)
        print(exe,expected,flush=True)

    def tail(part):
        a,b=part;p,t=f'partner-{a}-{b}.json',f'tail-{a}-{b}.json'
        task('certify_tail.py',('comp012','comp012',p,t,a,b),[(p,p),(t,t)])

    def area():
        task('comp012/certify_sigma154_deeper_composition.py',
             ('comp012','physical-0140.json','--eh','comp012'),
             [('area-replayed.json','geometry-area.json')],stdout='area-replayed.json')

    def cone(pair):
        tag,span=pair;name=f'joint/joint-{tag}.json'
        task('joint/joint_tail.py',('comp012','comp012',name,'--ranges',span),[(name,name)])

    with ThreadPoolExecutor(4) as pool:
        jobs=[pool.submit(f,x) for f,group in ((tail,PARTS),(cone,CONES)) for x in group]
        jobs.append(pool.submit(area))
        for job in jobs:job.result()
    task('compose.py',('.','comp012','tail-final.json'),[('tail-final.json','tail-final.json')])


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('out',type=Path)
    a=p.parse_args();replay(a.out.resolve())

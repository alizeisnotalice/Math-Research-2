from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,sys,subprocess,argparse
p=argparse.ArgumentParser();p.add_argument('scratch',type=Path);p.add_argument('--full',action='store_true');p.add_argument('--bins',default='0,1,2,3,4,5,6,7');a=p.parse_args();D=Path(__file__).resolve().parent;S=a.scratch.resolve();assert not S.exists();S.mkdir(parents=True);bins=sorted({int(k) for k in a.bins.split(',')});assert bins and all(k in range(8) for k in bins);manifest=json.loads((D/'MANIFEST.json').read_text());outputs=[]
for j in bins:
 f=D/f'ah01400-j{j}-portable.zip';assert sha256(f.read_bytes()).hexdigest()==manifest[str(j)];P=S/f'input-{j}';P.mkdir()
 with ZipFile(f) as z:
  assert z.testzip() is None
  assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist());z.extractall(P)
 run=[sys.executable,'-E','-B',str(P/f'ah01400-j{j}'/'verify.py'),str(S/f'audit-{j}')]+(['--full'] if a.full else [])
 subprocess.run(run,check=True);outputs.append(j)
(S/'summary.json').write_text(json.dumps({'bins':outputs,'full_replay':a.full,'geometry_sha256':'772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256'},indent=2)+'\n')

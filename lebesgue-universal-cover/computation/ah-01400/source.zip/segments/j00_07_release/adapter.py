from pathlib import Path
from hashlib import sha256
import subprocess,tempfile,json,sys
from zipfile import ZipFile
P=Path(__file__).resolve().parent;R=P/'ah01400-j0-7';O=Path(sys.argv[1]).resolve()
for j in range(8):
 with ZipFile(R/f'ah01400-j{j}-portable.zip') as z:
  assert sha256(z.read(f'ah01400-j{j}/physical-0140.json')).hexdigest()=='adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32'
  d=json.loads(z.read(f'ah01400-j{j}/j{j}-joined-audit.json'));blocks=d.get('replaced_parent_blocks',d.get('replaced_5cell_parents'));assert {b-a for a,b in blocks}==({5} if j<4 else {15})
with tempfile.TemporaryDirectory(prefix='j0-7-',dir=O.parent) as t:
 W=Path(t)/'work';subprocess.run([sys.executable,'-I','-B',str(R/'verify_all.py'),str(W)],check=True,stdout=subprocess.DEVNULL);d=json.loads((W/'summary.json').read_bytes())
assert d['bins']==list(range(8)) and d['geometry_sha256']=='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256'
out={'complete':True,'geometry_sha256':d['geometry_sha256'],'physical_sha256':'adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32','bins':d['bins'],'physical_cells':600,'scope':'all early class joins, including verified local m and Fsharp interfaces'};O.write_text(json.dumps(out,indent=2)+'\n')

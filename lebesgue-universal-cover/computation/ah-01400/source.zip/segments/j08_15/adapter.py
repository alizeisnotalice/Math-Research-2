from pathlib import Path
from hashlib import sha256
import tempfile,shutil,subprocess,sys,json
P=Path(__file__).resolve().parent;S=P/'upper-01400-j08-15';O=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(dir=O.parent,prefix='j08-15-') as t:
 K=Path(t)/'kit';shutil.copytree(S,K);subprocess.run([sys.executable,'-I','-B',str(K/'assemble014.py')],check=True,stdout=subprocess.DEVNULL);assert (K/'assembled-audit.json').read_bytes()==(S/'assembled-audit.json').read_bytes();d=json.loads((K/'assembled-audit.json').read_bytes())
assert d['all_passed'] and d['geometry_sha256']=='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256' and d['physical_sha256']=='adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32' and set(d['bins'])==set(map(str,range(8,16))) and all(v['physical_cells']==75 for v in d['bins'].values())
ledger=json.loads((P/'independent-ledger.json').read_bytes());assert len(ledger)==35 and all(v['byte_equal'] and v['prior']==v['replay']==sha256((S/n).read_bytes()).hexdigest() for n,v in ledger.items())
out={'complete':True,'geometry_sha256':d['geometry_sha256'],'physical_sha256':d['physical_sha256'],'bins':list(range(8,16)),'physical_cells':600,'independent_raw_replays':35,'audit_sha256':sha256((S/'assembled-audit.json').read_bytes()).hexdigest()};O.write_text(json.dumps(out,indent=2)+'\n')

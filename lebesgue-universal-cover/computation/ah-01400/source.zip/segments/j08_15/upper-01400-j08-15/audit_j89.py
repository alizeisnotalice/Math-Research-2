from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from flint import arb,ctx
import json,sys,subprocess
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from audit_bins_013 import audit,REFERENCE
ctx.prec=128;j=int(sys.argv[1]);assert j in (8,9);base=audit(j);assert base is not None
for name in ('ordered_state.py','sharp_first_hit.py'):
 assert sha256((P/name).read_bytes()).digest()==sha256((P/'scout'/name).read_bytes()).digest(),name
orig=(P/'certify_early_sharp.py').read_text();tree=(P/'scout'/'certify_tree.py').read_text()
for text in (orig,tree):
 assert 'b=r0+ns[\"_end_index\"]*step' in text and "['_sharpen_jets']=True" in text and "['_tighten_first']=True" in text
assert "['_first_orientation']=ori" in orig and "['_first_orientation']=0" in tree
assert "anchor=F(23)" in tree and "threshold=F('.00002')" in tree and "condition_sign=1" in tree

assert {(a,b,tuple(c),tuple(d)) for a,b,c,_,d,*_ in base['bad']}=={(0,1,(1,4),(i,i+25)) for i in (0,25,50)}
raw=json.loads((P/f'output-{j}.json').read_bytes());retained=[]
for t in raw['rows']:
 r=t['row'];bad=not(arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0)
 if not bad:retained.append(t)
patch=[]
for start in (0,25,50):
 f=P/'scout'/f'j{j}-{start}-{start+25}.json';o=P/'scout'/f'audit-j{j}-{start}-{start+25}.json';subprocess.run([sys.executable,'-I','-B',str(P/'scout'/'audit_tree.py'),str(f),str(o),str(j)],check=True,stdout=subprocess.DEVNULL);d=json.loads(o.read_bytes());assert d['physical_block']==[start,start+25] and d['all_passed'];patch.append(d)
rm=min([arb(t['row']['root_margin_lower']).lower() for t in retained]+[arb(t['min_root']).lower() for t in patch]);pm=min([arb(t['row']['placement_margin_lower']).lower() for t in retained]+[arb(t['min_pose']).lower() for t in patch]);assert rm>0 and pm>0
result={'bin':j,'geometry_sha256':REFERENCE,'physical_sha256':sha256((P/'physical-0140.json').read_bytes()).hexdigest(),'parent_sha256':base['sha256'],'physical_cells':75,'two_orientation_labels':[0,1],'contact_classes':6,'conditional_signs':[-1,1],'replaced_class':[0,1,[1,4]],'tree_patches':patch,'root_lower':str(rm),'common_placement_lower':str(pm),'EH_retreat':'593/6250000000','all_passed':True,'scope':'single bin; EH transfer and other bins separate'};(P/f'audit-j{j}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import defaultdict
from flint import arb,ctx
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from audit_bins_013 import audit,REFERENCE
ctx.prec=128;j=int(sys.argv[1]);assert j in (13,14);first=15 if j==13 else 0
base=audit(j);assert base is not None;expected={(0,-1,(5,0),(a,a+15)) for a in range(first,75,15)}
assert {(a,b,tuple(c),tuple(d)) for a,b,c,_,d,*_ in base['bad']}==expected
parent=json.loads((P/f'output-{j}.json').read_bytes());old=[t for t in parent['rows'] if not(t['orientation']==0 and t['angle_class']==-1 and t['counts']==[5,0] and t['row']['subcells'][0]>=first)]
read=lambda p:json.loads(p.read_bytes());h=lambda p:sha256(p.read_bytes()).hexdigest();groups={};source={}
for k in range(9):
 f=P/f'repair-{j}-{k}-output.json';d=read(f);cfg=read(P/f'repair-{j}-{k}.json');assert d['complete'] and d['all_passed'] and d['parameters']==cfg and d['geometry_sha256']==REFERENCE
 assert d['physical_parameters']==read(P/'physical-0140.json') and d['reachable']=={str(j):[[0,75]]} and d['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'}
 for n,v in d['source_hashes'].items():
  x=P/n if (P/n).exists() else P/'comp012'/n;assert h(x)==v,(k,n)
 rr=d['rows'];assert rr and all(t['orientation']==0 and t['angle_class']==-1 and t['counts']==cfg['counts_override'] and t['e_class']==[str(F(x)) for x in cfg['e_class']] for t in rr)
 assert sorted(tuple(t['row']['subcells']) for t in rr)==[(a,a+15) for a in range(first,75,15)]
 for t in rr:
  r=t['row'];assert all(arb(r[n])>0 for n in ('root_margin_lower','placement_margin_lower'));assert F(r['anchor_degrees'])==23 and r['anchor_comparison_sign']==-1 and F(r['anchor_threshold'])==-F(1,50000);assert r['placed_leaves']==sum(r['pose_counts'].values())
 key=tuple(cfg['counts_override']),tuple(map(F,cfg['e_class']));assert key not in groups;groups[key]=rr;source[str(k)]=h(f)
keys={((5,0),(F(i,4),F(i+1,4))) for i in range(3)}|{((i,5-i,0,0),(F(3,4),F(1))) for i in range(6)};assert groups.keys()==keys
# Same a,b, chart, support_bound, first-hit tightening and shared validator preserve local normalization.
orig=(P/'certify_early_sharp.py').read_text();derived=(P/'certify_early_box.py').read_text()
for s in (orig,derived):assert 'b=r0+ns[\"_end_index\"]*step' in s and "['_sharpen_jets']=True" in s and "['_tighten_first']=True" in s
repair=[t for rr in groups.values() for t in rr];rows=old+repair;rm=min(arb(t['row']['root_margin_lower']).lower() for t in rows);pm=min(arb(t['row']['placement_margin_lower']).lower() for t in rows);assert rm>0 and pm>0
out={'bin':j,'geometry_sha256':REFERENCE,'physical_sha256':h(P/'physical-0140.json'),'original_sha256':base['sha256'],'repair_sha256':source,'rows':len(rows),'physical_cells':75,'replaced_parent_blocks':len(expected),'repair_classes':9,'root_lower':str(rm),'common_placement_lower':str(pm),'EH_retreat':'593/6250000000','all_passed':True,'scope':'this bin only; first EH transfer/global other bins separate'};(P/f'audit-j{j}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

"""Join independently audited j8--15 .01400 shards, without adding global claims."""
from pathlib import Path
import sys,subprocess,json,hashlib
from flint import arb,ctx
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from audit_bins_013 import audit,REFERENCE
ctx.prec=128
for j in (8,9):subprocess.run([sys.executable,'-I','-B',str(P/'audit_j89.py'),str(j)],check=True,stdout=subprocess.DEVNULL)
for j in (13,14):subprocess.run([sys.executable,'-I','-B',str(P/'audit_j1314.py'),str(j)],check=True,stdout=subprocess.DEVNULL)
subprocess.run([sys.executable,'-I','-B',str(P/'audit_j15.py')],check=True,stdout=subprocess.DEVNULL)
bins={}
for j in range(8,16):
 if j in (10,11,12):
  d=audit(j);assert d is not None and not d['bad'];entry={'bin':j,'physical_cells':75,'root_lower':d['root_lower'],'common_placement_lower':d['placement_lower'],'raw_sha256':d['sha256'],'all_passed':True}
 else:entry=json.loads((P/f'audit-j{j}.json').read_bytes())
 assert entry['all_passed'] and arb(entry['root_lower'])>0 and arb(entry['common_placement_lower'])>0
 bins[str(j)]=entry
r={'all_passed':True,'geometry_sha256':REFERENCE,'physical_sha256':hashlib.sha256((P/'physical-0140.json').read_bytes()).hexdigest(),'EH_retreat':'593/6250000000','bins':bins,'scope':'bins 8--15 with physical transfer assumptions; first EH transfer and other bins separately'};(P/'assembled-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({j:{'root_lower':v['root_lower'],'common_placement_lower':v['common_placement_lower']} for j,v in bins.items()},indent=2))

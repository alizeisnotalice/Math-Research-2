"""Rebuild .01400 j8--15 plus interval repairs in a new external directory."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import argparse,shutil,subprocess,sys,os,json
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('--jobs',type=int,default=3);a=p.parse_args();root=Path(__file__).resolve().parent;work=a.work.resolve();assert not work.exists() and not work.is_relative_to(root) and 1<=a.jobs<=8
shutil.copytree(root,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));names=[f'output-{j}.json' for j in range(8,16)]+[f'scout/j{j}-{i}-{i+25}.json' for j in (8,9) for i in (0,25,50)]+[f'repair-{j}-{k}-output.json' for j in (13,14) for k in range(9)]+[f'repair-15-{k}-output.json' for k in range(3)]
h=lambda p:sha256(p.read_bytes()).hexdigest();prior={n:h(work/n) for n in names};env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','MKL_NUM_THREADS':'1'};tasks=[]
for j in range(8,16):
 script='certify_ordered_direct_mixed.py' if j==15 else 'certify_early_sharp.py';cmd=[sys.executable,'-I','-B',str(work/script),str(work/'comp012')]
 if j==15:cmd.append(str(work))
 cmd += [str(work/f'config-{j}.json'),str(work/f'output-{j}.json')];tasks.append((f'base-{j}',cmd))
for j in (8,9):
 for i in (0,25,50):tasks.append((f'tree-{j}-{i}',[sys.executable,'-E','-B',str(work/'scout/certify_tree.py'),str(j),str(i),str(work/f'scout/j{j}-{i}-{i+25}.json'),'--block','25']))
for j in (13,14):
 for k in range(9):tasks.append((f'repair-{j}-{k}',[sys.executable,'-I','-B',str(work/'certify_early_box.py'),str(work/'comp012'),str(work/f'repair-{j}-{k}.json'),str(work/f'repair-{j}-{k}-output.json')]))
for k in range(3):tasks.append((f'repair-15-{k}',[sys.executable,'-I','-B',str(work/'certify_ordered_direct_mixed.py'),str(work/'comp012'),str(work),str(work/f'repair-15-{k}.json'),str(work/f'repair-15-{k}-output.json')]))
def run(task):
 tag,cmd=task
 with (work/f'replay-{tag}.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=work)
 if r.returncode:raise RuntimeError((tag,r.returncode))
 print(json.dumps({'task':tag,'returncode':0}),flush=True)
with ThreadPoolExecutor(max_workers=a.jobs) as ex:list(ex.map(run,tasks))
comp={n:{'prior':prior[n],'replay':h(work/n),'byte_equal':prior[n]==h(work/n)} for n in names};(work/'replay-comparison.json').write_text(json.dumps(comp,indent=2)+'\n')
subprocess.run([sys.executable,'-I','-B',str(work/'assemble014.py')],cwd=work,env=env,check=True);print('PASS j8--15',work/'assembled-audit.json',flush=True)

from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from hashlib import sha256
import json,sys
from flint import arb,ctx
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P))
from audit_bins_013 import audit,REFERENCE
ctx.prec=128
read=lambda f:json.loads(f.read_bytes());h=lambda f:sha256(f.read_bytes()).hexdigest()
base=audit(15);assert base is not None and len(base['bad'])==15
assert {(z[0],z[1],tuple(z[2]),tuple(z[4])) for z in base['bad']}=={(0,0,(5,0),(i,i+5)) for i in range(0,75,5)}
raw=read(P/'output-15.json');old=[z for z in raw['rows'] if not (z['orientation']==0 and z['counts']==[5,0])];repair=[];digests={}
for k in range(3):
 f=P/f'repair-15-{k}-output.json';d=read(f);cfg=read(P/f'repair-15-{k}.json');assert d['complete'] and d['all_passed'] and d['geometry_sha256']==REFERENCE and d['parameters']==cfg
 assert d['physical_parameters']==read(P/'physical-0140.json') and d['reachable']=={'15':[[25*k,25*(k+1)]]} and d['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'}
 for name,v in d['source_hashes'].items():
  x=P/name if (P/name).exists() else P/'comp012'/name;assert h(x)==v,(f,name)
 for t in d['rows']:
  r=t['row'];assert t['bin']==r['reference_bin']==15 and t['orientation']==0 and t['positive'] and t['tighten_first'];assert all(arb(r[z])>0 for z in ('root_margin_lower','placement_margin_lower'));assert r['placed_leaves']==sum(r['verified_dihedral_pose_counts'].values());repair.append(t)
 digests[str(k)]=h(f)
groups=defaultdict(list)
for t in repair:groups[(tuple(t['counts']),tuple(map(F,t['e_class'])))].append(tuple(t['row']['subcells']))
keys={((5,0),(F(i,4),F(i+1,4))) for i in range(3)} | {((i,5-i,0,0),(F(3,4),F(1))) for i in range(6)}
assert groups.keys()==keys
for k,v in groups.items():
 assert sorted(v)==[(i,i+5) for i in range(0,75,5)],(k,sorted(v))
 assert [x for a,b in sorted(v) for x in range(a,b)]==list(range(75)),(k,sorted(v))
rows=old+repair;rm=min(arb(t['row']['root_margin_lower']).lower() for t in rows);pm=min(arb(t['row']['placement_margin_lower']).lower() for t in rows);assert rm>0 and pm>0
out={'bin':15,'geometry_sha256':REFERENCE,'physical_sha256':h(P/'physical-0140.json'),'original_sha256':base['sha256'],'repair_sha256':digests,'rows':len(rows),'physical_cells':75,'root_lower':str(rm),'common_placement_lower':str(pm),'EH_tightening':{'label':'U1-Te-0','retreat':'593/6250000000'},'original_failed_blocks_replaced':15,'repair_classes':9,'all_passed':True,'scope':'j15 only; EH first-transfer and other bins separate'};(P/'audit-j15.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

# 0.01400 physical chart: j8–15

This bundle certifies only j=8,…,15 of the AH double-hit placement argument. The fixed chart is (sigma,pivot,turn,far,negative,eps)=(1.54°,.429,.01400,.352,.403,.020), geometry SHA-256 `772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256`, physical-file SHA `adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32`. Each j has 75 closed physical fine cells and both first-hit orientations. j8–14 have both conditional signs; j15 uses direct roots. Six ordered parent classes are covered, and every accepted interval uses one common rigid placement against every physical support row.

The row U1-Te-0 is tightened by 593/6250000000 in every original and repair kernel. This bundle checks that tightening but does not prove the separate old-to-new EH first-hit transfer, the physical chart's global coverage, or the remaining j values. These interfaces must be verified in the global integration.

Original j10–12 pass directly. In j8–9 the entire orientation 0, positive sign, counts (1,4) class is replaced by three closed contact/deficit trees on the original 25-cell blocks; the two paths use identical source hashes and local normalization, not a cross-block class identification. j13 replaces its four failed orientation 0, negative sign, (5,0) parent blocks of length 15 with nine closed deficit/contact strata; j14 does the same for five blocks. j15 replaces its 15 failed orientation 0, (5,0) parent blocks of length 5 with the same nine strata. In each case all repair blocks exactly match parent physical endpoints, preserving the local m and first-hit budgets. Original failed receipts remain in the package and are not counted as passing.

`assemble014.py` validates all source hashes, parent–child covers and same-pose margins and writes `assembled-audit.json`. The smallest common placement margin in this shard is >6.01719e-8 (j9); the smallest root margin is >1.72443e-6 (j8).

## Reproduce

Requires Python 3.13 and python-flint 0.9.0. All code and data needed for these 35 original and repair calculations are included relative to this directory; no repository checkout is needed. The initial certified computations were actually run in the producing workspace and the copied bundle's structural auditor was run independently with Python isolated mode. To recompute everything in a fresh, external, nonexistent working directory and then re-audit:

```sh
/path/to/python -B replay.py /absolute/path/to/new-working-directory --jobs 3
```

The run stores per-task logs and `replay-comparison.json` containing the source and replay SHA-256 for all 35 raw receipts. The source is deterministic but the checker does not rely on raw byte equality: the final acceptance requires the interval and structural audit. To audit the supplied records only:

```sh
/path/to/python -I -B assemble014.py
```

Computational sources come from `luc-astra-a-roots/nov19-ah014-015-central-scout/comp062`; base j8–15 configurations derive from `nov19-chain-audit/upper-01350-8-15` with the physical input replaced. The contact-tree scheme was adapted from `lebesgue-terra-01400-j0-25/scout/certify_5tree.py` in a separate copy; the included tree code and audits fix parent blocks to their original 25-cell endpoints. See `provenance.json` and `SHA256SUMS` for recorded source identities.

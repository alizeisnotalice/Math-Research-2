"""Rebuild fixed .014 first stage, audit each complete segment, and enumerate gaps."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import argparse,json,subprocess,sys
P=Path(__file__).resolve().parent;G='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256';Q='adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32'
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--partial',action='store_true');p.add_argument('--full',action='store_true');a=p.parse_args();O=a.out.resolve();assert not O.is_relative_to(P) and not O.exists();O.mkdir(parents=True)
def run(script,args,label):
 with (O/(label+'.log')).open('w') as f:subprocess.run([sys.executable,'-I','-B',str(script),*map(str,args)],cwd=P,stdout=f,stderr=subprocess.STDOUT,check=True)
def read(p):return json.loads(p.read_bytes())
assert sha256((P/'physical-0140.json').read_bytes()).hexdigest()==Q
run(P/'firststage.py',[O/'firststage'],'firststage');first=read(O/'firststage/result.json');assert first['complete'] and first['geometry_sha256']==G and first['reference_subcells']==5184
B=set();reports={};C=P/'segments/j26_31';run(C/'cross014/replay.py',[C/'deep-26.zip',C/'deep-31.zip',O/'cross'],'cross');assert (O/'cross/cross-014-015.json').read_bytes()==(C/'cross014/registered.json').read_bytes();B.update((26,31));reports['26_31']='independent same-input cross-angle registration and deep audited trees'
M=P/'segments/j32_39';out=O/'middle.json';run(M/'audit.py',[M/'case',M/'kernel',out,M/'full-32-35.json',M/'full-36-39.json'],'middle');assert out.read_bytes()==(M/'summary.json').read_bytes();v=read(out);assert v['complete'] and v['geometry_sha256']==G and v['bins']==list(range(32,40));B.update(v['bins']);reports['32_39']='recomputed structural audit of independent raw interval results'
T=P/'segments/j40_69';out=O/'tail.json';run(T/'compose.py',[T,T/'comp012',out],'tail');assert out.read_bytes()==(T/'tail-final.json').read_bytes();v=read(out);assert v['complete_tail'] and v['geometry_sha256']==G;B.update(range(40,70));reports['40_69']='recomputed join of physical tail and positive partner cones'
A=P/'segments/adapters';assert A.is_dir()
for d in sorted(A.glob('*.json')):
 z=read(d);K=(P/z['package']).resolve();assert K.is_relative_to(P);out=O/(d.stem+'.json');run(K/z['script'],[out],d.stem);v=read(out);bins=set(z['bins']);assert v['complete'] and v['geometry_sha256']==G and v['physical_sha256']==Q and set(v['bins'])==bins and not B&bins;B|=bins;reports[d.stem]=v
miss=sorted(set(range(70))-B)
if a.full:
 assert not miss,'full replay requires every segment'
 F=O/'full';F.mkdir()
 for j in (26,31):
  D=O/'cross'/f'j{j}-0-75';run(D/'replay_whole.py',[F/f'deep-{j}','--full','--workers','2'],f'full-deep-{j}')
 run(M/'replay.py',[F/'middle'],'full-middle');run(T/'replay.py',[F/'tail'],'full-tail')
 Z=P/'segments/j27_30_zero/quick';run(Z/'replay.py',[F/'zero','2'],'full-zero')
 for j in range(27,31):
  out=F/f'central-{j}.json';run(P/'central/certify_adjacent.py',[j,out],f'full-central-{j}');assert out.read_bytes()==(P/f'central/result-014-{j}.json').read_bytes()
 for d in sorted(A.glob('*.json')):
  z=read(d)
  if set(z['bins']).issubset(set(range(27,31))):continue
  assert 'full_script' in z,d
  K=(P/z['package']).resolve();target=F/d.stem;argv=[target if x=='{work}' else x for x in z['full_args']];run(K/z['full_script'],argv,'full-'+d.stem)
  if 'full_comparison' in z:
   comparisons=read(target/z['full_comparison']);assert len(comparisons)==z['full_comparison_count'] and all(r['byte_equal'] and r['prior']==r['replay'] for r in comparisons.values())
v={'complete':not miss,'geometry_sha256':G,'physical_sha256':Q,'bins_verified':sorted(B),'missing_bins':miss,'physical_cells':sum(9 if j==69 else 75 for j in B),'firststage':first,'reports':reports,'full_interval_replay':bool(a.full)};(O/'result.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2));assert not miss or a.partial

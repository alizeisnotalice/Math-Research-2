# .01400 j27–30 closed-tree synthesis

The physical chart uses `(1.54 degrees, .429, .01400, .352, .403, .020)` with graph SHA `772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256` and EH row retreat `593/6250000000`. Each five-cell block is common to all six ordered half-count classes, each of the two first-contact labels and the two derivative sides. `certify_adjacent.py` keeps every original failed leaf in its receipt.

`audit_join.py OUT BIN...` checks all contact/e split identities, both endpoints of each actual block, source hashes and strict root/one-pose bounds. It replaces a failed leaf only if `../segments/j27_30_zero/quick/query.py` proves the same actual first label, same physical block, same Fsharp normalization and ordered-contact interval gives a single Q_A placement meeting all host rows. The two copies of all common comp Python files, ordered support and sharp budget source are hash-compared. The raw zero-angle package separately proves S>=Fsharp, so its v=min(e,S) equals e on these same blocks.

Recompute one raw bin in an empty file, compare it byte-for-byte with `result-014-BIN.json`, and run the audit; the sibling quick package has its own independent full source replay. A structurally audited failed-leaf replacement is conditional on that package and the global first-EH transfer, not a standalone universal-cover claim.

"""Audit closed contact trees and use exact same-block Q_A certificates only on failed leaves."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from hashlib import sha256
import json,sys
from flint import arb,ctx
ctx.prec=128
D=Path(__file__).resolve().parent;P=D.parent;Q=P/'segments/j27_30_zero/quick';sys.path.insert(0,str(Q));from query import query
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();G='772095354f0cab5a1dffeecab68ac0f7d642c6d2a0b133fdd921af6fedf0c256';PH='adb4e26624f92648ff8789201dff4083ac610dad1450d2fa6a819533fd6fff32'
assert digest(D/'physical-0140.json')==PH and digest(Q/'physical-0140.json')==PH
for name in ['ordered_state.py','sharp_first_hit.py']:
 assert digest(D/name)==digest(Q/name)
for f in (D/'comp012').glob('*.py'):
 assert (Q/'comp062'/f.name).is_file() and digest(f)==digest(Q/'comp062'/f.name),f.name
ledger=read(Q.parent/'independent-ledger.json');assert ledger['all_five_byte_equal'] and len(ledger['outputs'])==5 and all(digest(Q/n)==h for n,h in ledger['outputs'].items())
source_manifest=read(D/'source-manifest.json');assert len(source_manifest)==53 and all(digest(D/n)==h for n,h in source_manifest.items())
manifest=read(Q/'manifest.json')
for n,h in manifest.items():assert digest(Q/n)==h,n
results={}
for j in map(int,sys.argv[2:]):
 src=(D/f'fast-014-{j}.json' if (D/f'fast-014-{j}.json').exists() else D/f'result-014-{j}.json');raw=read(src);assert raw['bin']==j and raw['physical']==read(D/'physical-0140.json') and raw['geometry_sha256']==G and F(raw['EH_retreat'])==F(593,6250000000) and F(raw['derivative_cut'])==-F(3,250)
 for n,h in raw['sources'].items():assert digest(D/n)==h,n
 cert=read(Q/f'third-014-{j}.json');assert cert['physical']==raw['physical'] and cert['geometry_sha256']==G
 assert len(raw['rows'])==60 and {(r['orientation'],r['side'],*r['block']) for r in raw['rows']}=={(o,s,a,a+5) for o in (0,1) for s in (-1,1) for a in range(0,75,5)}
 accepted=[];replaced=[]
 def ident(t):return tuple(t['counts']),*map(F,t['e'])
 def walk(t,ori,side,a,b):
  cs,lo,hi=ident(t);assert sum(cs)==5 and 0<=lo<hi<=1
  if 'children' in t:
   if t['split']=='contacts':want={(sum(x,()),lo,hi) for x in product(*[[(i,c-i) for i in range(c+1)] for c in cs])}
   else:
    n={'two-deficits':2,'four-deficits':4}[t['split']];want={(cs,lo+(hi-lo)*i/n,lo+(hi-lo)*(i+1)/n) for i in range(n)}
   assert len(t['children'])==len(want) and {ident(c) for c in t['children']}==want
   for c in t['children']:walk(c,ori,side,a,b)
   return
  if 'pinned' in t:
   r=query(j,a,b,ori,[str(lo),str(hi)],list(cs));assert r==t['pinned'] and r['applicable'] and r['geometry_sha256']==G and F(r['all_28_margin'])>0;replaced.append({'side':side,**r});return
  if 'failed' in t:
   r=query(j,a,b,ori,[str(lo),str(hi)],list(cs));assert r['applicable'] and r['geometry_sha256']==G and r['closed_block']==[a,b] and F(r['all_28_margin'])>0,(j,ori,side,a,b,cs,lo,hi,r);replaced.append({'side':side,**r});return
  r=t['row'];assert r['reference_bin']==j and r['subcells']==[a,b] and F(r['anchor_degrees'])==0 and F(r['anchor_threshold'])==F(3,250) and r['anchor_comparison_sign']==side and arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0 and r['placed_leaves']==sum(r['pose_counts'].values());accepted.append(r)
 for b in raw['rows']:
  trees=b['trees'];assert len(trees)==6 and {ident(t) for t in trees}=={((k,5-k),F(0),F(1)) for k in range(6)}
  for t in trees:walk(t,b['orientation'],b['side'],*b['block'])
 replay=read(D/'independent-ledger.json')['outputs'].get(str(j));assert replay is None or (replay['byte_identical'] and replay['replay_exit_code']==0 and replay['sha256']==digest(src))
 results[str(j)]={'independent_raw_replay':bool(replay),'physical_cells':75,'raw_sha256':digest(src),'root_leaf_count':len(accepted),'pinned_replacement_count':len(replaced),'minimum_root':str(min(arb(r['root_margin_lower']).lower() for r in accepted)),'minimum_root_pose':str(min(arb(r['placement_margin_lower']).lower() for r in accepted)),'replacements':replaced}
out={'complete':True,'all_passed':True,'geometry_sha256':G,'physical_sha256':PH,'bins':list(map(int,sys.argv[2:])),'segments':results,'scope':'original closed contact/e trees; failed leaves replaced only by same-block same-Fsharp Q_A support certificate'}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print('audited',out['bins'])

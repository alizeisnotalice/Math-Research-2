from pathlib import Path
import subprocess,sys,json
P=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();subprocess.run([sys.executable,'-I','-B',str(P/'audit_join.py'),str(O),'27'],check=True,stdout=subprocess.DEVNULL)

"""Reconstruct the .01200 physical chart and actual polygon area."""
from pathlib import Path
from hashlib import sha256
from flint import ctx
import json,sys
D=Path(__file__).resolve().parent;C=D/'computation';sys.path.insert(0,str(C));import certify_sigma154_deeper_composition as base
cfg=json.loads((D/'physical.json').read_text());assert cfg=={'sigma_degrees':'1.54','line':['.429','.01200'],'physical_parameters':['.319','.36','.015']}
ctx.prec=160;chart,normal=base.physical_chart(C,cfg);ctx.prec=160;geometry=base.area_geometry(C,C,cfg,normal)
out={'parameters':cfg,'decision':'true area and physical gate','chart':chart,'geometry':geometry,'placement':None,'config_sha256':sha256((D/'physical.json').read_bytes()).hexdigest(),'source_sha256':sha256((C/'certify_sigma154_deeper_composition.py').read_bytes()).hexdigest()};(D/'area.json').write_text(json.dumps(out,indent=2)+'\n');print('cells',chart['reference_subcells'],'geometry',chart['geometry_sha256'],'eleven',next(z for z in geometry['cases'] if z['label']=='eleven')['area']['decimal'],flush=True)

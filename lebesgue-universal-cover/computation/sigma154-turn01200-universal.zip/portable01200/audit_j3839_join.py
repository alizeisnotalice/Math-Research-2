"""Glue .01200 j38/39 retained original classes to repaired highest tail."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
ctx.prec=160;D=Path(__file__).resolve().parent;K=D/'kit';M=K/'middle';R=K/'j3839-01200';load=lambda p:json.loads(p.read_text());dig=lambda p:sha256(p.read_bytes()).hexdigest();area=load(D/'area.json');q=area['parameters'];geo=area['chart']['geometry_sha256'];blocks=lambda n:[[i,i+n] for i in range(0,75,n)]
spec={j:(M/(f'01150-j{j}-easy.json' if j==39 else '01150-38-40-41-easy.json'),M/f'01150-j{j}-tightcap.json') for j in (38,39)}
agent=load(D/'j3839-audit.json');assert agent['complete'] and agent['geometry_sha256']==geo and agent['physical']==q and agent['direct_blocks']==525 and agent['empty_cases']==150
nested=load(D/'nested.json');assert nested['parameters']==q and nested['geometry_sha256']==geo
result=[]
for j in (38,39):
 for_nest,=[x for x in nested['bins'] if x['bin']==j];assert for_nest['exact_budget_pairs']==95 and for_nest['S_less_than_F_blocks']==0
 easy,sharp=spec[j];allrows=[];sources={}
 expected={(o,(k,5-k),('0','1'),False):blocks(15) for o in (0,1) for k in range(6) if (o,k)!=(0,5)}
 residual={(0,(5,0),('0','1/2'),False):blocks(5)};residual.update({(0,(k,5-k,0,0),('1/2','1'),False):blocks(5) for k in range(5)})
 if j==38:deep=(0,(5,0,0,0),('1/2','1'),True);residual[deep]=blocks(1)
 else:
  residual.update({(0,(k,5-k,0,0,0,0,0,0),('1/2','1'),True):blocks(1) for k in range(6)});deep=(0,(5,0,0,0,0,0,0,0),('1/2','1'),True)
 for path,target in ((easy,expected),(sharp,residual)):
  d=load(path);assert d['complete'] and d['physical_parameters']==q and d['geometry_sha256']==geo and d['reachable'][str(j)]==[[0,75]] and F(d['EH_tightening']['retreat'])==F('.00000009488')
  sources[path.name]=dig(path);groups={}
  for item in [z for z in d['rows'] if z['bin']==j]:
   row=item['row'];key=(item['orientation'],tuple(item['counts']),tuple(item['e_class']),item['tighten_first']);groups.setdefault(key,[]).append(row['subcells']);assert row['reference_bin']==j
   options=[v for v in d['parameters']['classes'] if v['orientation']==item['orientation'] and v['counts']==item['counts'] and tuple(v.get('e_class',['0','1']))==tuple(item['e_class']) and v.get('tighten_first',d['parameters'].get('tighten_first',False))==item['tighten_first']];assert len(options)==1
   assert any(list(map(F,z[:2]))==list(map(F,row['bracket'])) and z[2:]==row['pose'] for z in options[0]['brackets'])
   if key!=deep:
    assert item['positive'] and arb(row['root_margin_lower'])>0 and arb(row['placement_margin_lower'])>0
    assert sum(row['verified_dihedral_pose_counts'].values())==row['placed_leaves'];allrows.append(row)
  assert groups==target,(j,path.name,set(groups)^set(target))
 # The independently audited replacement covers each deepest original class.
 relevant=[R/'j38-eighths-full-output.json',R/'j38-extreme-full-output.json'] if j==38 else [R/'j39-esplit-full-output.json']
 for p in relevant:
  d=load(p);sources[p.name]=dig(p);assert d['all_passed'] and d['geometry_sha256']==geo and d['physical_parameters']==q
  allrows.extend(x['row'] for x in d['rows'])
 assert allrows
 root=min(arb(z['root_margin_lower']).lower() for z in allrows);pose=min(arb(z['placement_margin_lower']).lower() for z in allrows);assert root>0 and pose>0
 result.append({'bin':j,'physical_cells':75,'retained_and_replacement_rows':len(allrows),'zero_class_cells':75,'root_lower':str(root),'placement_lower':str(pose),'sources':sources})
out={'complete_local_join':True,'geometry_sha256':geo,'physical_parameters':q,'nested_sha256':dig(D/'nested.json'),'replacement_audit_sha256':dig(D/'j3839-audit.json'),'bins':result};(D/'j3839-composed.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

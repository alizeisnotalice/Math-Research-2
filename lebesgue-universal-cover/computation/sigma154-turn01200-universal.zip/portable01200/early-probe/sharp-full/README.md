# .01200: reference bins 4–7

The four independently synchronized receipts use physical data `.429, .01200, .319, .36, .015`, sigma `1.54` degrees and geometry SHA-256 `2d29fcb947abb65e5e12dd40b69ccd74561ee7bb4ddc5a28d46251dda8db5a88`. The first-hit sharpening and its two actual orientation fibres are those of the adjacent j12–14 package; `first-hit-budget-proof.md` is historical background for the monotonicity argument and its old numeric conclusions do not describe this .01200 packet; it is essential that the chosen fibre corresponds to the same actual input. EH retreat is 593/6250000000 and must be checked against the transfer bound in the global composition.

For each j, both first-hit labels and both closed sign branches at 23 degrees cover 75 physical cells, and each branch includes all six ordered count classes. Each accepted angle leaf uses a single placement for all host rows. Audit root and placement margins, source hashes, exact geometry, class labels, and closed physical partitions with Python 3.13 and python-flint 0.9.0:

```
for j in 4 5 6 7; do python -I -B audit.py "$j" "output-$j.json" "audit-$j.json"; done
```

Recompute a receipt from the frozen source and compare it with the original:

```
python -I -B certify_angle_sharp.py comp012 config-4.json replay-4.json
cmp output-4.json replay-4.json
```

Repeat with j=5,6,7. This packet establishes only these four bins; global coverage needs the remaining bins, the common geometry, the first-hit and two-hit reduction, and the retreat-versus-transfer bound.

"""Audit both origin labels, derivative signs, synchronized partitions and dihedral placements."""
import argparse
import hashlib
import json
from pathlib import Path
from fractions import Fraction as Q
import sys
from flint import arb,ctx

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(root, receipt, j):
    ctx.prec=128
    assert j in range(4,8)
    rec=json.loads(receipt.read_bytes())
    files={p.name:p for p in (root/'comp012').glob('*.py')}
    files.update({p.name:p for p in root.glob('*') if p.is_file()})
    assert set(rec['source_hashes'])=={'certify_angle_sharp.py','ordered_state.py','sharp_first_hit.py',f'config-{j}.json','physical-01200-wide.json','certify_sigma_pinned_fan.py','certify_ah_affine_root_class.py','certify_sigma_extended_graph.py'}
    for name,value in rec['source_hashes'].items():
        assert sha(files[name])==value,name
    assert rec['complete'] and rec['synchronized'] and rec['tighten_first'] and rec['all_passed']
    assert rec['parameters']==json.loads((root/f'config-{j}.json').read_bytes())
    assert rec['physical_parameters']==json.loads((root/'physical-01200-wide.json').read_bytes())
    assert rec['physical_parameters']==dict(sigma_degrees='1.54',line=['.429','.01200'],physical_parameters=['.319','.36','.015'])
    assert rec['reachable']=={str(j):[[0,75]]}
    assert rec['EH_tightening']==dict(label='U1-Te-0',retreat='593/6250000000')
    assert rec['geometry_sha256']=='2d29fcb947abb65e5e12dd40b69ccd74561ee7bb4ddc5a28d46251dda8db5a88'
    assert Q(rec['parameters']['threshold'])==Q(1,50000) and Q(rec['parameters']['anchor'])==23
    groups={}
    root_min=pose_min=arb(1)
    placed=excluded=conditional_empty=0
    for item in rec['rows']:
        axis,side=item['orientation'],item['angle_class']
        assert item['bin']==j and axis in (0,1) and side in (-1,1)
        k,l=item['counts'];assert k in range(6) and l==5-k
        row=item['row'];assert row['reference_bin']==j and row['anchor_degrees']=='23'
        assert row['anchor_comparison_sign']==side and Q(row['anchor_threshold'])==-Q(1,50000)
        options=rec['parameters']['low_brackets' if side==-1 else 'high_brackets']
        assert list(map(Q,row['bracket'])) in [list(map(Q,b[:2])) for b in options]
        root_min=min(root_min,arb(row['root_margin_lower']).lower())
        pose_min=min(pose_min,arb(row['placement_margin_lower']).lower())
        assert row['placed_leaves']==sum(row['pose_counts'].values())
        assert row['empty_conditional_subcells'] in (0,1)
        placed+=row['placed_leaves'];excluded+=row['root_free_leaves'];conditional_empty+=row['empty_conditional_subcells']
        groups.setdefault((axis,side,k),[]).append(row['subcells'])
    assert root_min>0 and pose_min>0
    for axis in (0,1):
        for side in (-1,1):
            parts=rec['partitions'][f'{j},{axis},{side}']
            assert [i for a,b in parts for i in range(a,b)]==list(range(75)) and all(a<b for a,b in parts)
            assert all(groups[axis,side,k]==parts for k in range(6))
    return dict(geometry_sha256=rec['geometry_sha256'],receipt_sha256=sha(receipt),rows=len(rec['rows']),
        physical_cells=75,orientation_and_anchor_pairs=4,count_classes=6,root_lower=str(root_min),placement_lower=str(pose_min),
        placed_leaves=placed,root_free_leaves=excluded,empty_conditional_rows=conditional_empty)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('j',type=int);p.add_argument('receipt',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();a.out.write_text(json.dumps(audit(Path(__file__).resolve().parent,a.receipt,a.j),indent=2)+'\n')

"""Validate all eight closed reference bins and optionally recompute every support witness."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
p=argparse.ArgumentParser()
p.add_argument('scratch',type=Path)
p.add_argument('--full',action='store_true')
args=p.parse_args()
base=Path(__file__).resolve().parent
out=args.scratch.resolve();out.mkdir(exist_ok=True,parents=True)
def sha(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
for name,h in json.loads((base/'manifest.json').read_bytes()).items():assert sha(base/name)==h,name
for j in range(16,24):
    original=base/f'output-{j}.json'
    receipt=original
    if args.full:
        receipt=out/original.name
        with (out/f'bin{j}.log').open('w') as log:
            subprocess.run([sys.executable,'-I','-B',base/'certify_j31_sharp.py',base/'comp012',base/f'config-{j}.json',receipt],stdout=log,check=True)
        calculated=json.loads(receipt.read_bytes()); target=json.loads(original.read_bytes())
        calculated['python']=target['python']; assert calculated==target,original
    audited=out/f'audit-{j}.json'
    subprocess.run([sys.executable,'-I','-B',base/'audit.py',str(j),receipt,audited],check=True)
    calculated=json.loads(audited.read_bytes());target=json.loads((base/audited.name).read_bytes())
    assert calculated['receipt_sha256']==sha(receipt)
    calculated['receipt_sha256']=target['receipt_sha256'];assert calculated==target
print('Verified all eight closed reference bins.')

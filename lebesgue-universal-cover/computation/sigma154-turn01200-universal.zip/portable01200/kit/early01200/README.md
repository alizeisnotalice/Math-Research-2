# .01200 早段 j0–3：同步接触类闭证

固定 σ=1.54°、AH 铰点 .429、转角 .01200 rad、物理参数 (.319,.36,.015)，EH 行先退 593/6250000000。第 j=0,1,2,3 格的两个首命中标号和锚点两支共16个分支，经 `audit_early.py` 在同一几何核上完整拼接，覆盖 960 个闭物理块与接触类。对每一分支，同一物理分块上的六个有序接触人数类全部验证。所有被选用的非空根端和共同姿态余量严格为正；179 个类块在相应闭锚条件下被证明为空。统一下界记录在 `audit-portable.json`。

## 量词与数据

实际体在锚角 23° 按相容函数 `F(23°)+0.00002` 的非正、非负分两闭支，等号可重叠。每个分支再按真实首标号及该物理块内五个有序坐标落在半区的个数分六类；同一分支六类使用完全相同的物理划分。两锚支之间允许不同分块和不同有效预算，因为它们各自对整个同一输入分支给出证明。空块只排除该物理块、锚支、首标号和接触类的交集；不应把179个空块当成整个参考格为空。

- `paired/paired-low-output.json`：两标号、低锚支，4格×2标号×5个15细格块×6类=240行；根括 [12°,23°]。
- `paired/paired-high-output.json`：标号1、高锚支，4格×15个5细格块×6类=360行；根括 [36°,46°]。
- `sharp-high-output.json`：标号0、高锚支，4格×15个5细格块×6类=360行。文件自身 `all_passed=false`，因 j2、j3 的 [1,4] 类在深0摆放估计有25行失败。**不得单独将其视为完整通过证书。**
- `sharp-high-k1-output.json`：只替换 j2、j3 标号0高支的 [1,4] 类；同一15个5细格块共30行，根括 [37°,46°]、角细分深1，全部通过。根端余量 >.0002639328756，姿态余量 >.00004325673757。其他五类沿用原同一分块；不依赖跨尺度迁移。

`audit_early.py` 明确丢弃上面原 [1,4] 的30行，加入对应30行补证，并对每个分支、每个标号、每个接触类检查块序列精确覆盖75细格、同块分区、根端与姿态余量、EH退量、源散列及物理/几何哈希。组合后 960 行的根端最小严格大于 1.99999999999e−5，姿态最小严格大于 9.828437846e−8。条件空块在原算子中直接通过严格不等式证空；非空块在闭根括给出异号，并对所有可能含根角叶给出同一宿主全部行的姿态。

`paired/` 的 `sharp_first_hit.py` 与 `ordered_state.py` 对两个标号使用直接或配对曲线的首亏损预算；主目录对应核用于标号0。所得上界依赖原首次命中处在新增 AH 裁线切除侧、纤维导数正及原图支撑估计；这些前提应与主课题首次命中和伙伴图证明一并审查。参考 `luc-astra-a-roots/nov19-j12-14-01200/` 的同核证明及项目已有局部支撑证明。该包只解决条件双命中摆放，不能单独推出整体万能覆盖面积。

## 审计与重放

本目录包含原两个源核、输入、回执和44个冻结计算模块 `comp/`。在本目录，以 Python 3.13.18、python-flint 0.9.0 执行：

```
python -B audit_early.py comp paired
python -E -B paired/certify_early_sharp.py comp paired/paired-low-config.json NEW-low.json
python -E -B paired/certify_early_sharp.py comp paired/paired-high-config.json NEW-high1.json
python -E -B certify_early_sharp.py comp sharp-high-config.json NEW-high0.json
python -E -B certify_early_k1.py comp sharp-high-k1-config.json NEW-k1.json
```

最后两份要按上述规则重组，不能要求原 high0 作为整体 all_passed。算子源码记录实际 Fsharp 打开；原高支首次探针和 sweep 只用于寻找参数，不是最终证明。`audit-portable.json` 是对冻结包的实际源哈希、分区和结果重验；该审计不自行重新运行全部区间运算。

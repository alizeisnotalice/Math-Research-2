"""Combine synchronized .01200 j0--3 branch certificates, retaining exact common blocks."""
from pathlib import Path
from argparse import ArgumentParser
from hashlib import sha256
from flint import arb,ctx
import json
ctx.prec=160;p=ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('paired',type=Path);a=p.parse_args();here=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_bytes());dig=lambda p:sha256(p.read_bytes()).hexdigest();lowfile=a.paired/'paired-low-output.json';high1file=a.paired/'paired-high-output.json';high0file=here/'sharp-high-output.json';repairfile=here/'sharp-high-k1-output.json';files=[lowfile,high1file,high0file,repairfile];D=[load(q) for q in files];low,hi1,hi0,fix=D;phys=load(here/'sigma154-turn01150-physical.json');assert phys['line']==['.429','.01200'] and phys['physical_parameters']==['.319','.36','.015'];geo=low['geometry_sha256']
for f,d in zip(files,D):
 assert d['complete'] and d['synchronized'] and d['physical_parameters']==phys and d['geometry_sha256']==geo and d['EH_tightening']['retreat']=='593/6250000000'
 for k,v in d['source_hashes'].items():
  q=f.parent/k
  if not q.exists():q=a.comp/k
  assert dig(q)==v,(f,k)
assert low['all_passed'] and hi1['all_passed'] and fix['all_passed'] and not hi0['all_passed']
assert len(low['rows'])==240 and len(hi1['rows'])==360 and len(hi0['rows'])==360 and len(fix['rows'])==30
for x in low['rows']:assert x['angle_class']==-1
for d in [hi1,hi0,fix]:assert all(x['angle_class']==1 for x in d['rows'])
assert all(r['orientation']==1 for r in hi1['rows']) and all(r['orientation']==0 for d in [hi0,fix] for r in d['rows'])
for d in [low,hi1,hi0,fix]:
 for j in range(4):
  if d is fix and j not in (2,3):continue
  oris=(0,1) if d is low else (1,) if d is hi1 else (0,)
  for ori in oris:
   ks=[1] if d is fix else list(range(6));size=15 if d is low else 5
   for k in ks:
    q=[r for r in d['rows'] if r['bin']==j and r['orientation']==ori and r['counts']==[k,5-k]]
    assert [r['row']['subcells'] for r in q]==[[i,i+size] for i in range(0,75,size)],(j,ori,k)
chosen=low['rows']+hi1['rows']+[r for r in hi0['rows'] if not (r['bin'] in (2,3) and r['counts']==[1,4])]+fix['rows'];assert len(chosen)==960
assert all(arb(r['row']['root_margin_lower'])>0 and arb(r['row']['placement_margin_lower'])>0 for r in chosen)
mins={k:str(min(arb(r['row'][k]).lower() for r in chosen)) for k in ('root_margin_lower','placement_margin_lower')}
print(json.dumps({'complete':True,'scope':'j0..3, both orientations, anchor side -1 and +1; conditional two-hit placement','physical':phys,'geometry_sha256':geo,'branches':16,'class_blocks':len(chosen),'empty_conditional_blocks':sum(r['row']['empty_conditional_subcells'] for r in chosen),'minima':mins,'receipt_sha256':{p.name:dig(p) for p in files}},indent=2))

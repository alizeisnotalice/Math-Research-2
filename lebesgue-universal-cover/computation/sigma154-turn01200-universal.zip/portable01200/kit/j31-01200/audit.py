"""Audit both origin labels, derivative signs, synchronized partitions and dihedral placements."""
import argparse
import hashlib
import json
from pathlib import Path
from fractions import Fraction as Q
import sys
from flint import arb,ctx

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(root, receipt):
    ctx.prec=128
    rec=json.loads(receipt.read_bytes())
    files={p.name:p for p in (root/'comp012').glob('*.py')}
    files.update({p.name:p for p in root.glob('*') if p.is_file()})
    for name,value in rec['source_hashes'].items():
        assert sha(files[name])==value,name
    assert rec['complete'] and rec['synchronized'] and rec['tighten_first'] and rec['all_passed']
    assert rec['parameters']==json.loads((root/'config.json').read_bytes())
    assert rec['physical_parameters']==json.loads((root/'physical-01200-wide.json').read_bytes())
    assert rec['reachable']=={'31':[[0,75]]}
    assert rec['EH_tightening']==dict(label='U1-Te-0',retreat='593/6250000000')
    assert rec['geometry_sha256']=='2d29fcb947abb65e5e12dd40b69ccd74561ee7bb4ddc5a28d46251dda8db5a88'
    assert Q(rec['parameters']['cut'])==-Q(3,250)
    groups={}
    root_min=pose_min=arb(1)
    placed=excluded=conditional_empty=0
    for item in rec['rows']:
        axis,side=item['orientation'],item['initial_derivative_sign']
        assert item['positive'] and item['bin']==31 and axis in (0,1) and side in (-1,1)
        k,l=item['counts'];assert k in range(6) and l==5-k
        row=item['row'];assert row['reference_bin']==31 and row['anchor_degrees']=='0'
        assert row['anchor_comparison_sign']==side and Q(row['anchor_threshold'])==Q(3,250)
        root_min=min(root_min,arb(row['root_margin_lower']).lower())
        pose_min=min(pose_min,arb(row['placement_margin_lower']).lower())
        assert row['placed_leaves']==sum(row['pose_counts'].values())
        assert row['empty_conditional_subcells'] in (0,1)
        placed+=row['placed_leaves'];excluded+=row['root_free_leaves'];conditional_empty+=row['empty_conditional_subcells']
        groups.setdefault((axis,side,k),[]).append(row['subcells'])
    assert root_min>0 and pose_min>0
    for axis in (0,1):
        for side in (-1,1):
            parts=rec['partitions'][f'31,{axis},{side}']
            assert [i for a,b in parts for i in range(a,b)]==list(range(75)) and all(a<b for a,b in parts)
            assert all(groups[axis,side,k]==parts for k in range(6))
    return dict(geometry_sha256=rec['geometry_sha256'],receipt_sha256=sha(receipt),rows=len(rec['rows']),
        physical_cells=75,orientation_and_slope_pairs=4,count_classes=6,root_lower=str(root_min),placement_lower=str(pose_min),
        placed_leaves=placed,root_free_leaves=excluded,empty_conditional_rows=conditional_empty)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('receipt',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();a.out.write_text(json.dumps(audit(Path(__file__).resolve().parent,a.receipt),indent=2)+'\n')

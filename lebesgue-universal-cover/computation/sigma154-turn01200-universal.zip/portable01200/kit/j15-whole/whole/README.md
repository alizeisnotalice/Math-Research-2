# 第15角格两首点标号的统一证书

物理图参数与 1.54°、.01200 的原图完全一致。对两种真实首点均以 AH 末支撑面计算实际首亏损上界。标号0使用 \(X(l(w),T(w)-e)\)，标号1使用 \(X(\psi(l(w)),-T(w)-e)\)。后一族将平均导数的 \(l_w,T_w\) 换成 \(\psi'(l)l_w,-T_w\)，先验已验证 \(\psi'<0\)。每个五细格块以 32 个亏损闭段验证正导数并从单调端点或中心式推出真实预算。缓存键同时包括标号、物理块与旧上界。

两标号、六个闭有序计数及十五个固定物理块共180行。全部使用原有序参数的 \(v=\min(e,S)\)、全体首点实际亏损，以及相同的物理分割 [0,5]、[5,10]、…、[70,75]。每个可能有根的角叶选同一二面体摆放检验所有行，包括收进 \(593/6250000000\) 的 EH 行。所有已选角括、同姿态根叶和区间余量列于 output.json。与单独的三来源组合相比，本证书已在一个几何实例中重新计算全部180行，可单独接第15参考格。audit_whole.py 核验所有计数、共同分块、源哈希和两项严格余量。

复算使用 Python 3.13、python-flint 0.9.0。在 whole 目录运行

    python -I -B certify_ordered_direct_mixed.py comp012 . config.json /path/to/replayed.json
    python -I -B audit_whole.py comp012 /path/to/replayed.json /path/to/replayed-audit.json
    cmp output.json /path/to/replayed.json

SHA256SUMS 包含归档后的每个源、配置和回执。相同的解释器版本字符串可逐字节重现原回执。

"""Check all ordered contact classes on the same five-cell physical blocks for both first labels."""
import argparse,json
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from flint import arb,ctx
ctx.prec=128
p=argparse.ArgumentParser()
for n in ['comp','receipt','out']:p.add_argument(n,type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parent
d=json.loads(a.receipt.read_bytes())
assert d['complete'] and d['all_passed'] and d['reachable']=={'15':[[0,75]]}
assert d['geometry_sha256']=='2d29fcb947abb65e5e12dd40b69ccd74561ee7bb4ddc5a28d46251dda8db5a88'
assert d['EH_tightening']==dict(label='U1-Te-0',retreat='593/6250000000')
for name,h in d['source_hashes'].items():
    f=root/name
    if not f.exists():f=a.comp/name
    assert sha256(f.read_bytes()).hexdigest()==h,name
assert d['parameters']==json.loads((root/'config.json').read_bytes())
assert d['physical_parameters']==json.loads((root/'physical-01200-wide.json').read_bytes())
seen=set();root_min=pose_min=arb(1);placed=excluded=0
for item in d['rows']:
    assert item['bin']==15 and item['positive'] and item['tighten_first'] and list(map(F,item['e_class']))==[0,1]
    k,l=item['counts']; assert k+l==5
    row=item['row']; i,end=row['subcells'];assert row['reference_bin']==15 and end==i+5
    key=(item['orientation'],k,i)
    assert key not in seen
    seen.add(key)
    root_min=min(root_min,arb(row['root_margin_lower']).lower());pose_min=min(pose_min,arb(row['placement_margin_lower']).lower())
    assert row['placed_leaves']==sum(row['verified_dihedral_pose_counts'].values()) and row['placed_leaves']>0
    placed+=row['placed_leaves'];excluded+=row['root_free_leaves']
assert seen=={(ori,k,i) for ori in (0,1) for k in range(6) for i in range(0,75,5)} and root_min>0 and pose_min>0
a.out.write_text(json.dumps(dict(receipt_sha256=sha256(a.receipt.read_bytes()).hexdigest(),geometry_sha256=d['geometry_sha256'],physical_cells=75,five_cell_blocks=15,full_bin_rows=len(seen),root_lower=str(root_min),placement_lower=str(pose_min),placed_leaves=placed,root_free_leaves=excluded),indent=2)+'\n')

# Universal-cover candidate at AH turn .01200

The fixed construction has Gibbs angle 1.54°, AH pivot .429, AH turn .01200 radians, and chart parameters (.319,.36,.015). Its eleven-EH true area is strictly below 0.844089757357370395405720665141284138284. The physical chart has 70 reference bins, 75 reachable closed cells in bins 0–68 and 8 in bin 69, hence 5183 cells. `cover-result.json` gives the exact rational area endpoint.

Use Python 3.13 and python-flint 0.9.0. In this directory run

```
python -I -B verify_all.py /path/to/writable-scratch
python -I -B verify_all.py /path/to/writable-scratch --full
```

The first command recomputes the original first EH single-chord and .997 chain certificates, the new physical chart and true area, the nested budgets and all interval-receipt composition audits. `--full` also recomputes the raw interval receipts; it can take substantial CPU time. Each raw receipt is checked against its stored mathematical fields; Python version strings alone are not geometric data. The output explicitly records which mode ran. This package relies on the mathematical reductions recorded below; hashes alone never prove their hypotheses.

The first EH placement, its Q1/Q2/Q3 alternatives, and the eleven-line transfer are explained in `proofs/sigma154-ah429-eh550-composition.md`, `proofs/062-shifted-chord.md`, and `proofs/eh-deep-second-relocation.md`. The first-EH replays use `firstEH/comp`, a frozen copy of the original geometry, and are bound to the single and .997 receipts in `computation/`. The `.01200` chart is rebuilt separately by `area.py` and tests the first-hit trigger boxes used to apply the same original reflection rule. The deeper-AH composition and transfer inequality are in `proofs/sigma154-deeper-composition.md`.

For the remaining AH case, `proofs/ah-segment-cap.md` requires the same body K and the fixed reflection Q_A K to hit the new AH ear. If either avoids the ear, the earlier placement supplies the result. Otherwise the two actual hit points belong to that same body after applying Q_A; exchanging them also exchanges the two labels. The local root certificates split both labels and use closed parameter classes. For every possible root leaf, a single dihedral pose is tested against every host row simultaneously. The .000555 EH support row is retreated by exactly 593/6250000000, which exceeds the verified upper bound for transfer to the .997 eleven-line chain.

In bins 34–37 the deepest positive-deficit classes are replaced by a necessary condition for the *actual second hit*: its four new AH retained-side margins are strictly positive. Its placement in a new cap would require at least one nonpositive margin. Old support slope and budgets are checked on the same single cell, and the closed parent-to-child budget nesting is audited. Zero deficit remains in the low-deficit branch. The full tail proof, including the zero-deficit relabelling and both hands, is in `tail-audit/partner-tail-proof.md`. The special j32 and j38–39 joins are documented in their component READMEs and checked explicitly by `verify_all.py`.

`normalization-ledger.json` identifies every file changed solely to replace original machine-specific physical-input paths and propagate the resulting SHA-256 bindings. The mathematical source outputs before relocation and their digests are recorded there. Replayed formulas and inequalities, rather than the ledger alone, substantiate the result.

from flint import arb,ctx,__version__
from fractions import Fraction as F
import json,sys
ctx.prec=256
A=lambda q:arb(q.numerator)/q.denominator if isinstance(q,F) else arb(q)
s=F(4999999,5000000);G=F(120696470013529293,2**57);L=A(G/s**2);S=F(10**16-1,10**16);delta=F(3,10**20)
def v_u(m):return (2-1/(arb.pi()/(2*m)).cos())**2*L
def v_global(m):return (arb.pi()/(m-1)).cos()**2*L
def v_fin(m):
 disk=A(S)*(arb.pi()/m).cos()/(arb.pi()/(2*m)).cos()-A(2*delta)
 curves=[A(S-(S*F(22,7)**2/(8*n*n*((m-n)//n)**2)+delta)*F(5,2)) for n in (3,5,7,9)]
 alpha=min([disk]+curves)
 alpha=A(F(int((alpha*10**36).lower().floor().unique_fmpz()),10**36))
 return alpha*alpha*L
targets=['.83750','.8375001','.8375002','.8375003','.83750033','.837500335']
out=[]
for kind,fun in [('U',v_u),('Lambda_global',v_global),('Lambda_finite',v_fin)]:
 for t in targets:
  goal=A(F(t));lo,hi=(12 if kind=='U' else 64),10**9
  while lo<hi:
   mid=(lo+hi)//2
   if fun(2*mid+1)>goal:hi=mid
   else:lo=mid+1
  m=2*lo+1;assert fun(m)>goal and fun(m-2)<goal
  out.append(dict(method=kind,target=t,first_odd=m,above=str((fun(m)-goal).lower()),previous_below=str((goal-fun(m-2)).lower())))
print(json.dumps(dict(python=sys.version,flint=__version__,bits=ctx.prec,L=str(L),rows=out),indent=2))

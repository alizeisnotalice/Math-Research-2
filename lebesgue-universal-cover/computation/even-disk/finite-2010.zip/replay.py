from pathlib import Path
from hashlib import sha256
import argparse,subprocess,sys
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);a=p.parse_args();W=a.work.resolve();W.mkdir(parents=True,exist_ok=True)
for script,target in [('disk2010.py',W),('threshold.py',W/'threshold.json'),('assemble.py',W)]:
 subprocess.run([sys.executable,'-I','-B',str(R/script),str(target)],check=True)
for f in ['disk2010.json.gz','disk2010-receipt.json','threshold.json','seven-2010.json.gz','seven-2010-receipt.json']:
 a=(W/f).read_bytes();b=(R/'expected'/f).read_bytes();assert a==b,(f,sha256(a).hexdigest(),sha256(b).hexdigest())
print('FINITE2010_ALL_PASS')

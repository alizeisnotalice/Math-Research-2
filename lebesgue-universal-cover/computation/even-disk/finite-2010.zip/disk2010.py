"""Build and check a 2010-point rational disk witness, using all integer pairs."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
import argparse,gzip,json,sys
from flint import arb,ctx
ctx.prec=192
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('out',type=Path);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
D=json.loads((R/'rational-params.json').read_bytes());n=D['n'];m=n//2;mid=D['transition_offset'];den=D['parameter_denominator'];b=[F(0)]*m
for i,z in enumerate(D['b_numerator']):b[mid+i]=F(z,den)
special=[F(v,den) for v in D['a_numerator']];ix=range(mid-2,mid+5);assert len(special)==7
av=-sum(special,F(0))/(m-len(special));alpha=[av]*m
for i,x in zip(ix,special):alpha[i]=x
u=[1+x-y for x,y in zip(alpha,b)]+[1+x+y for x,y in zip(alpha,b)];assert len(u)==n and sum(u)==n and min(u)>F(1,2) and max(u)<F(3,2)
ar=lambda x:arb(F(x).numerator)/F(x).denominator
N=10**18;step=2*arb.pi()/n;assert step*ar(min(u))>arb(4)/N
norm=[];prefix=F(0);quarters=[]
for ui in u:
 theta=step*ar(prefix);quarter=round(float(theta/(arb.pi()/2)));assert abs(theta-quarter*arb.pi()/2)<arb.pi()/4+arb('1e-30')
 q=int((((theta-quarter*arb.pi()/2)/2).tan()*N+arb(1)/2).floor().unique_fmpz());assert abs(q)<=N
 x=F(N*N-q*q,N*N+q*q);y=F(2*q*N,N*N+q*q)
 for _ in range(quarter%4):x,y=-y,x
 assert x*x+y*y==1;norm.append((x,y));quarters.append(quarter);prefix+=ui
assert prefix==n and quarters==sorted(quarters) and quarters[0]==0 and quarters[-1]==4
Q=D['coordinate_grid'];points=[];mindet=F(1)
for (x,y),(z,w) in zip(norm,norm[1:]+norm[:1]):
 det=x*w-y*z;assert det>0 and x*z+y*w>0;mindet=min(mindet,det)
 vx=(w-y)/det;vy=(x-z)/det;ix=round(vx*Q);iy=round(vy*Q)
 assert (vx*Q-ix)**2+(vy*Q-iy)**2<1
 points.append((ix,iy))
assert len(set(points))==n
maxd=-1;arg=None
for i,(x,y) in enumerate(points):
 for j in range(i+1,n):
  xx,yy=points[j];d=(x-xx)**2+(y-yy)**2
  if d>maxd:maxd=d;arg=(i,j)
T=D['diameter_denominator'];assert maxd<T*T
sc=F('.999999083');s=F('.99999909');G=F(120696470013529293,2**57);H=G/s**2
alpha_disk=F(2*(Q-1),T);beta=alpha_disk*s/sc;result=H*beta**2;assert 0<beta<1 and result>F(67,80)
cloud={'name':'disk-2010','denominator':T,'points':points};raw=json.dumps(cloud,separators=(',',':'),sort_keys=True).encode();(a.out/'disk2010.json.gz').write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
rec=dict(points=n,integer_distance_pairs=n*(n-1)//2,strict_diameter_margin=str(T*T-maxd),diameter_arg=arg,coordinate_error_norm_upper=f'1/{Q}',normal_grid=N,inradius_original_lower=str(F(Q-1,Q)),diameter_normalizer=str(F(T,Q)),disk_containment_factor=str(alpha_disk),common_seven_beta=str(beta),area_lower=str(result),area_above_target=str(result-F(67,80)),canonical_sha256=sha256(raw).hexdigest(),parameters_sha256=sha256((R/'rational-params.json').read_bytes()).hexdigest(),precision=ctx.prec)
(a.out/'disk2010-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print('PASS n',n,'integer pairs',rec['integer_distance_pairs'],'area gap',float(result-F(67,80)),flush=True)

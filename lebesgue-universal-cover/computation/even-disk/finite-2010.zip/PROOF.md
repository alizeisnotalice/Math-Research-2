# 2010-point common-inclusion threshold for the two-centre certificate

Let G=120696470013529293/2^57, s_c=.999999083, s=.99999909, and H=G/s². The upstream two-centre theorem (input archive SHA256 17dd03bfeb5177285d9f5afe9e18eecd2778e5f96b1f823703b8506c4b4c6673) proves that the disk and regular Reuleaux 3,5,7,9 bodies each contracted by s_c, together with the two actual rational point clouds in its points.json, have combined convex-hull area at least G under independent rigid placements. Dividing each group by s gives seven inputs of diameter at most one. This result depends on that theorem; this package does not rerun its entire 501-tree proof.

We construct rational finite groups of sizes 2010,1164,1165,1169,1170,66,11. The last two groups are exactly the upstream clouds divided by s. The middle four are the previously certified rational tangent polygons. `assemble.py` independently recomputes each entire convex hull and support edge using 256-bit Arb, verifies the two exact diameter algorithms, checks the certificates byte-for-byte, and verifies both point groups and their strict integer diameters against the upstream archive.

## Even 2010-point disk polygon

Write μ=π/2010 and let 2μu_i be the angular gaps between neighboring unit normals. The explicit rational coefficients in rational-params.json produce positive u_i and exactly sum u_i=2010. They originate in a numerical search but are fixed rational data; correctness does not depend on that search. Each desired angle is converted at 192-bit Arb precision to a rational unit normal via a rounded stereographic coordinate. The quarter-turn chart is certified; adjacent normals have positive cross and dot, and form one counterclockwise turn. Intersecting consecutive lines n_i·x=1 gives the exact circumscribed polygon Q. Every exact vertex is rounded to the grid Z²/10^15 and independently checked within Euclidean distance <10^−15. Hence the convex hull Q' of the rounded vertices has support in every direction ≥1−10^−15 and contains that concentric disk.

The 2010 rounded vertices form the final finite disk group after division by the rational diameter bound 2.000001833980000. The verifier compares all 2019045 distinct pairs of integer vertices and proves strict diameter less than this bound. Thus the normalized 2010-point hull contains a disk scaled by

    alpha_disk=999999999999999/1000000916990000.

Relative to the normalized upstream disk, this provides β_disk=alpha_disk*s/s_c. The four independently replayed curve inclusion factors, likewise multiplied by s/s_c, all strictly exceed β_disk; the two point sets are unchanged and β_disk<1. Thus all seven finite hulls contain the corresponding same β-scaled inputs and

    Λ_2010 ≥ H β_disk²
      =1178676464975869644600195048257174770214975872001953125/
       1407374883522765636023442697511795465874372818257313792
      > .83750000001815680010332402524259 > 67/80.

Each of the seven inputs has its own placement. A host covering each finite set must contain the corresponding independently placed β-scaled source body, so the old area theorem gives β²G/s². The inequality for Λ_2010 is general, conditional on the upstream area theorem.

## Exact minimum in the fixed transfer

For any diameter-one convex polygon with at most n vertices and a concentric inscribed disk of diameter alpha, the perimeter/Jensen argument gives

    alpha ≤ cos(π/n)/cos(π/(2n)).

The right side increases with n. At n=2009, direct 256-bit Arb arithmetic gives

    G/s_c² · [cos(π/2009)/cos(π/4018)]²
       < .837499999993541681 < 67/80.

Therefore no common-β transfer of the fixed upstream G can cross 67/80 with all groups of size at most 2009. The explicit 2010 seven-group certificate attains the crossing, so 2010 is the exact minimum for this fixed transfer. This exclusion is not a general upper bound on Λ_2009 and does not rule out other finite test families or stronger upstream area bounds. Odd regular polygons attain the Jensen bound at n=2009; the 2010 construction is genuinely even and nonregular.

# 2010-point finite certificate for the two-centre scale

Run using Python 3.13.18, python-flint 0.9.0:

    python -I -B replay.py /path/to/empty/workdir

The command independently rebuilds the rational 2010 disk group, checks all 2,019,045 integer pairs and the inradius error, reruns all four arc-body support and diameter checks, binds the two unchanged point groups to `inputs/upstream-two-centers.zip`, checks the 2009 lower threshold, and writes the seven rational point groups and per-stage certificates. It byte-compares all outputs to expected/ and prints FINITE2010_ALL_PASS. `inputs/previous-seven.json.gz` and its receipt supply only the other four polygon groups and the already generated point-cloud inputs; they are independently checked, not trusted by filename. The upstream archive contains the original area proof; its 501 integer trees are not replayed by this finite-stage package.

Result: general Λ_2010 > .83750000001815680010332402524259, assuming the upstream theorem. Group sizes [2010,1164,1165,1169,1170,66,11], total 6755. Within the fixed G/common-β transfer, 2010 is minimal; neither claim asserts a general upper bound for Λ_2009. See PROOF.md for quantifiers, constants and the complete disk argument.

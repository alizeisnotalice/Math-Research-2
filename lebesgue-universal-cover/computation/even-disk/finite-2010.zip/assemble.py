"""Recheck four original curve groups and two fixed calibrators, then combine with disk2010."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from hashlib import sha256
import gzip,json,sys,zipfile
from flint import ctx
ctx.prec=256
R=Path(__file__).resolve().parent
outdir=Path(sys.argv[1]).resolve();up=R/'inputs';lib=R/'library';sys.path.insert(0,str(lib));import certify as t
old=up/'previous-seven.json.gz';raw=gzip.decompress(old.read_bytes());source=json.loads(raw)
oldrec=json.loads((up/'previous-receipt.json').read_bytes())['tiers']['.83750'];assert sha256(raw).hexdigest()==oldrec['point_coordinates_sha256']
archive=up/'upstream-two-centers.zip';assert sha256(archive.read_bytes()).hexdigest()=='17dd03bfeb5177285d9f5afe9e18eecd2778e5f96b1f823703b8506c4b4c6673'
with zipfile.ZipFile(archive) as z: pointsraw=z.read('points.json')
points=json.loads(pointsraw);s=F('.99999909');sc=F('.999999083');G=F(120696470013529293,2**57);H=G/s**2
newdisk=json.loads(gzip.decompress((outdir/'disk2010.json.gz').read_bytes()));dr=json.loads((outdir/'disk2010-receipt.json').read_bytes());assert len(newdisk['points'])==2010 and newdisk['denominator']==int(F(dr['diameter_normalizer'])*10**15)
rec=[]
for i,order in enumerate((3,5,7,9),1):
 oldc=oldrec['curve_certificates'][i];row=t.cert_curve(source[i],t.Curve(order),oldc['axis'],oldc['grid']);assert row==oldc,(i,row,oldc);rec.append(row);print('curve',order,'PASS',row['count'],flush=True)
for idx,name in [(5,'P66'),(6,'physicalQ')]:
 target=source[idx];rawc=points[name];assert target['body']==name and target['denominator']==rawc['denominator']*s.numerator
 assert target['points']==[[x*s.denominator,y*s.denominator] for x,y in rawc['points']]
 assert max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(target['points'],2))<target['denominator']**2
 print(name,'PASS',len(target['points']),flush=True)
diskbeta=F(dr['common_seven_beta']);curvebetas=[F(x['included_scale'])*s/sc for x in rec];beta=min(F(1),diskbeta,*curvebetas);result=H*beta**2;assert beta==diskbeta and result>F(67,80)
combined=[{'body':0,'denominator':newdisk['denominator'],'points':newdisk['points']},*source[1:]];assert max(len(r['points']) for r in combined)==2010
payload=t.packed(combined);(outdir/'seven-2010.json.gz').write_bytes(gzip.compress(payload,compresslevel=9,mtime=0))
out=dict(counts=[len(x['points']) for x in combined],source_old_payload_sha256=sha256(raw).hexdigest(),source_point_clouds_sha256=sha256(pointsraw).hexdigest(),certified_curve_rows=rec,disk_beta=str(diskbeta),curve_betas=list(map(str,curvebetas)),common_beta=str(beta),area_lower_exact=str(result),area_lower_decimal=t.decimal_floor(result),area_gap=str(result-F(67,80)),canonical_sha256=sha256(payload).hexdigest())
(outdir/'seven-2010-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print('ALL SEVEN PASS',out['counts'],out['area_lower_decimal'],flush=True)

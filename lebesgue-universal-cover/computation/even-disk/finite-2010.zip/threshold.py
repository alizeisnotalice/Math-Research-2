from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
import json,sys
ctx.prec=256
G=arb(120696470013529293)/2**57;sc=arb(F('.999999083').numerator)/F('.999999083').denominator;goal=arb(67)/80
vals=[]
for n in (2008,2009,2010,2011):
 mu=arb.pi()/n;L=mu.cos()/(mu/2).cos();bound=G/sc**2*L**2;vals.append({'n':n,'disk_upper_factor':str(L),'factor_area_upper':str(bound),'above_target':str(bound-goal)})
assert arb(vals[1]['above_target'])<0 and arb(vals[2]['above_target'])>0
out={'2009_upper_strict':True,'2010_Jensen_only_inconclusive':True,'scope':'fixed G and common beta with actual curve scale sc; odd n=2009 achieves disk-only Jensen factor, n=2010 is even','rows':vals}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print('PASS 2009 impossible; 2010 Jensen unresolved')

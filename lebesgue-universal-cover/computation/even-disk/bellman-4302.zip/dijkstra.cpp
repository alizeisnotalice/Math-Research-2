#include <vector>
#include <queue>
#include <fstream>
#include <iostream>
#include <limits>
#include <functional>
#include <algorithm>
#include <cstdint>
int main(int argc,char**argv){
 constexpr int n=480,nb=280;std::vector<int32_t>w(n*nb);std::ifstream f(argv[1],std::ios::binary);f.read((char*)w.data(),w.size()*4);if(!f||f.peek()!=EOF)return 2;
 using X=std::pair<int64_t,int>;std::priority_queue<X,std::vector<X>,std::greater<X>>q;std::vector<int64_t>d(n*nb,std::numeric_limits<int64_t>::max());
 for(int i=0;i<=145;i++)for(int j=0;j<nb;j++){int id=i*nb+j;d[id]=w[id]/2;q.push({d[id],id});}
 int done=0;while(!q.empty()){auto [cost,id]=q.top();q.pop();if(cost!=d[id])continue;int i=id/nb,j=id%nb;if(i>=334){std::cout<<"distance="<<cost<<"/1000000000 nodes="<<done<<"\n";return 0;}
 for(int jj=0;jj<nb;jj++){int low2=2*i+j+jj-280,high2=2*(i+1)+j+jj-278;int imin=std::max(0,(low2-4)/2-1),imax=std::min(n-1,(high2+2)/2+1);
 for(int ii=imin;ii<=imax;ii++){if(2*(ii+1)<low2||2*ii>high2)continue;int next=ii*nb+jj;int64_t nd=cost+(ii>=334?w[next]/2:w[next]);if(nd<d[next]){d[next]=nd;q.push({nd,next});}}}done++;}
 return 3;
}

# An even circumscribed-polygon stability bound

Let n=4302, m=n/2, and let a convex n-gon be circumscribed about the unit disk with diameter 2δ. Put μ=π/n, let its consecutive tangent-normal half-gaps be y_i=μu_i, and write g(x)=x²(3+x). For i=0,…,m−1 set

    a_i=(u_i+u_{i+m})/2−1,  b_i=(u_{i+m}−u_i)/2.

Let z_i be the oriented angular midpoint offset of the opposite vertices divided by μ, with z_{i+m}=−z_i. The vertex geometry gives the exact identity

    z_{i+1}−z_i=2(b_i+b_{i+1}).

Extend a,b,z antiperiodically in the natural way: a_{i+m}=a_i, b_{i+m}=−b_i, z_{i+m}=−z_i. In particular the energy

    E=Σ_{i=0}^{m−1} [g(a_i−b_i)+g(a_i+b_i)]

is also the Jensen energy of all n gaps; the extended 2m-cycle has energy 2E. Each u_i≥0, so g(u_i−1)≥2(u_i−1)² and each pair costs at least 4(a_i²+b_i²).

## The Jensen conversion

The inradius/perimeter inequality and the diameter/perimeter inequality give δ≥Σtan(y_i)/(2n sin(μ/2)). Since tan(x)−x−x³/3 is convex on [0,π/2), Jensen and Σu_i=n yield

    δ−e_n ≥ μ³ E/(6n sin(μ/2)),  e_n=cos(μ/2)/cos μ.            (1)

Suppose for contradiction that δ<e_n+μ³(23/50)/(6n sin(μ/2)). Then E<23/50. From the quadratic bound above, all |b_i|<.35 and |u_i−1|<1/2, hence 0<u_i<3/2.

## A rigorous local potential

For |z_i|≤1, exact opposite-vertex geometry gives

    D_i²=sec²(μu_i)+sec²(μu_{i+m})
        +2 sec(μu_i)sec(μu_{i+m})cos(μz_i) ≤ 4δ².

For the stated ranges, sec² x≥1+x², sec x≥1+x²/2, and cos x≥1−x²/2. The upper bound δ<e_n+μ³(23/50)/(6n sin(μ/2)) and a directed 256-bit calculation then give

    (1+a_i)²+b_i² ≤ (3+z_i²)/4+ε,     ε=8/100000.            (2)

The computed upper error is <7.181798e−5. Since 1+a_i≥0 and sqrt(1−v)≤1−v/2, (2) implies

    a_i ≤ −(1−z_i²)/8 − b_i²/2 + ε/2.                         (3)

If every |z_i|<19/20, (3) and E_i≥4a_i² imply E>1.26962, a contradiction. Otherwise antiperiodicity supplies both a z_i≥19/20 and a z_j≤−19/20. The 2m-cycle contains a transition in each direction; choose consecutive first-hitting transitions. Their interiors are disjoint, and if they share endpoints, charging each endpoint at one half counts its energy at most once.

## Finite exact graph certificate

Partition z into 480 closed cells of width 1/100 on [−12/5,12/5] and b into 280 closed cells of width 1/400 on [−7/20,7/20]. Every relevant crossing can be selected inside this z range: |Δz|<7/5, so the last point on the starting side and the first point on the destination side are within 47/20 of zero. Closed-cell overlap is permitted.

For a cell let q be the minimum b² in its b interval. If its z interval is entirely in [−1,1], let p=max(0,1−max|z|²) and A=−p/8−q/2+ε/2; otherwise impose no restriction on a. Because a≥−1 and

    g(a−b)+g(a+b)=2a³+6a²+6(1+a)b²,

replacing b² by q lowers the expression. Its global minimizer on a≥−1 is a*=−1+sqrt(1−q). Under a≤A the minimizer is min(A,a*). `fine_weights.py` evaluates the resulting cell minimum with 160-bit directed Arb arithmetic and rounds down to an integer multiple of 10⁻⁹. In cells crossing |z|=1 it uses the unconstrained minimum, which is conservative.

A directed edge joins two cells whenever their closed z and b intervals permit Δz=2(b+b'). A start cell can meet z≤−19/20; an end cell can meet z≥19/20. Charge half the start weight, full intermediate weights, and half the end weight. This graph deliberately allows impossible sequences and therefore can only underestimate the true crossing energy. The integer Dijkstra run returns 0.463833847. More importantly, `potential.bin` is a capped Bellman potential of 0.46. The independent checker verifies source bounds, target potentials and all 85,246,142 directed edge inequalities with integer arithmetic. Thus each crossing costs at least 23/50; the two opposite crossings in the extended cycle give 2E≥2(23/50), contradicting E<23/50. This proves the unconditional n=4302 bound

    δ−e_n ≥ μ³(23/50)/(6n sin(μ/2)) > 1.5133393751/n³.          (4)

## Restricted 4302 conclusion and asymptotics

For the R275 fixed seven-input lower-bound certificate let

    H=736672790609920001220703125/879608950377114296052088832.

If an at-most-4302-point group of diameter ≤1 had convex hull containing a common β-scaled unit-diameter disk, then after normalizing its inradius and moving/adding tangent halfplanes one obtains a 4302-tangent polygon with δ≤1/β. By (4), Hβ²≤H/(e_n+gap)²<.837499999998854<67/80. Hence that fixed H/common-β transfer cannot prove a strict 67/80 bound with maximum group size 4302. This is not a general bound on Λ_4302 nor a ban on a different witness or transfer.

The same finite graph proves the asymptotic statement. If a sequence of even n→∞ had n³(δ−e_n)<23π²/150−c for any c>0, (1) would eventually give E<23/50. Then |b|<.35, u<1.5, the exact-distance error in (2) tends to zero and is eventually below 8e−5. The low-amplitude cost is m times a fixed positive constant and exceeds 23/50 for large n; otherwise the same antiperiodic crossing graph gives E≥23/50. Therefore

    liminf_{n→∞, n even} n³(δ_n−e_n) ≥ 23π²/150
        =1.5133393415003683… .

The liminf applies to arbitrary circumscribed even n-gons, not only minimizers. Equality in the asymptotic comparison causes no difficulty: the contradiction uses an arbitrary strictly smaller constant.

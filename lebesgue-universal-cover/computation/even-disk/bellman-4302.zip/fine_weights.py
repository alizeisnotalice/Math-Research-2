from fractions import Fraction as F
from flint import arb,ctx
from pathlib import Path
import struct,sys
ctx.prec=160;h=F(1,100);k=F(1,400);n=480;nb=280;z0=F(-12,5);b0=F(-7,20);eps=F(8,100000);scale=10**9
ar=lambda x:arb(F(x).numerator)/F(x).denominator
p=Path(sys.argv[1]);out=bytearray()
for i in range(n):
 zl=z0+i*h;zr=zl+h
 for j in range(nb):
  bl=b0+j*k;br=bl+k;q=min(abs(bl),abs(br))**2 if bl*br>0 else F(0);astar=-arb(1)+(arb(1)-ar(q)).sqrt()
  if zl>=-1 and zr<=1:
   pp=max(F(0),1-max(abs(zl),abs(zr))**2);A=-pp/8-q/2+eps/2;x=ar(A) if ar(A)<astar else astar
  else:x=astar
  E=2*x*x*x+6*x*x+6*(1+x)*ar(q);out.extend(struct.pack('<i',max(0,int((E.lower()*scale).floor().unique_fmpz()))))
p.write_bytes(out);print('weights',len(out))

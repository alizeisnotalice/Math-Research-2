#include <vector>
#include <queue>
#include <fstream>
#include <iostream>
#include <limits>
#include <functional>
#include <algorithm>
#include <cstdint>
int main(int argc,char**argv){
 constexpr int n=480,nb=280;constexpr int32_t cap=460000000;std::vector<int32_t>w(n*nb);std::ifstream f(argv[1],std::ios::binary);f.read((char*)w.data(),w.size()*4);if(!f||f.peek()!=EOF)return 2;
 using X=std::pair<int32_t,int>;std::priority_queue<X,std::vector<X>,std::greater<X>>q;std::vector<int32_t>d(n*nb,cap);
 for(int i=0;i<=145;i++)for(int j=0;j<nb;j++){int id=i*nb+j;int32_t x=std::min(cap,w[id]/2);if(x<d[id]){d[id]=x;q.push({x,id});}}
 int done=0;while(!q.empty()){auto [cost,id]=q.top();q.pop();if(cost!=d[id])continue;int i=id/nb,j=id%nb;if(i>=334){std::cerr<<"TARGET BELOW CAP "<<cost<<"\n";return 3;}
 for(int jj=0;jj<nb;jj++){int low2=2*i+j+jj-280,high2=2*(i+1)+j+jj-278;int imin=std::max(0,(low2-4)/2-1),imax=std::min(n-1,(high2+2)/2+1);
 for(int ii=imin;ii<=imax;ii++){if(2*(ii+1)<low2||2*ii>high2)continue;int next=ii*nb+jj;int64_t nd=int64_t(cost)+(ii>=334?w[next]/2:w[next]);if(nd<d[next]){d[next]=int32_t(nd);q.push({d[next],next});}}}done++;}
 std::ofstream o(argv[2],std::ios::binary);o.write((char*)d.data(),d.size()*4);if(!o)return 4;std::cout<<"potential-cap="<<cap<<" settled="<<done<<" states="<<d.size()<<"\n";
}

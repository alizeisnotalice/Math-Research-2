from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
import json,sys
ctx.prec=256
n=4302;m=n//2;mu=arb.pi()/n;H=arb(736672790609920001220703125)/arb(879608950377114296052088832);goal=arb(67)/80;d2=H/goal;delta=d2.sqrt();e=(mu/2).cos()/mu.cos();budget=(delta-e)*6*n*(mu/2).sin()/mu**3
gap=mu**3*(arb(23)/50)/(6*n*(mu/2).sin());candidate=e+gap
error=(candidate**2-1)/mu**2-arb(3)/4+mu**2*arb(9)/16
lowamp=arb(m)*4*(arb(39)/400/8-arb(8)/200000)**2
assert budget<arb(23)/50 and error<arb(8)/100000 and lowamp>arb(23)/50
assert (arb(23)/200).sqrt()<arb(7)/20 and (arb(23)/100).sqrt()<arb(1)/2 and mu*arb(3)/2<arb.pi()/2
bound=H/candidate**2;assert bound<goal
out={'n':n,'H':str(F(736672790609920001220703125,879608950377114296052088832)),'Jensen_energy_budget_for_4302':str(budget),'geometry_error_if_delta_below_candidate':str(error),'epsilon_used':'8/100000','low_amplitude_energy_lower':str(lowamp),'certified_energy':'23/50','scaled_diameter_gap':str(gap*n**3),'restricted_area_upper':str(bound),'asymptotic_constant':str(arb(23)*arb.pi()**2/150),'precision':ctx.prec}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(out)

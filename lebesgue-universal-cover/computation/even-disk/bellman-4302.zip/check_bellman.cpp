#include <vector>
#include <fstream>
#include <iostream>
#include <cstdint>
#include <algorithm>
bool read(const char* p,std::vector<int32_t>&v){std::ifstream f(p,std::ios::binary);f.read((char*)v.data(),v.size()*4);return f&&f.peek()==EOF;}
int floor2(int x){return x>=0?x/2:-((-x+1)/2);}
int ceil2(int x){return -floor2(-x);}
int main(int argc,char**argv){
 constexpr int n=480,b=280,cap=460000000;std::vector<int32_t>w(n*b),p(n*b);if(!read(argv[1],w)||!read(argv[2],p))return 2;
 for(int i=0;i<n;i++)for(int j=0;j<b;j++){int id=i*b+j;if(w[id]<0||p[id]<0||p[id]>cap)return 3;if(i<=145&&p[id]>w[id]/2)return 4;if(i>=334&&p[id]!=cap)return 5;}
 int64_t edges=0;for(int i=0;i<334;i++)for(int j=0;j<b;j++){int id=i*b+j;
 for(int jj=0;jj<b;jj++){
  // Independent enumeration: the two cells can meet if their interval endpoints intersect.
  int lo2=2*i+j+jj-280,hi2=2*(i+1)+j+jj-278;
  int k0=std::max(0,ceil2(lo2-2)),k1=std::min(n-1,floor2(hi2));
  for(int ii=k0;ii<=k1;ii++){if(2*(ii+1)<lo2||2*ii>hi2)continue;int v=ii*b+jj;int64_t edge=(ii>=334?w[v]/2:w[v]);if(int64_t(p[v])>int64_t(p[id])+edge){std::cerr<<"bad "<<id<<" "<<v<<"\n";return 6;}edges++;}}
 }
 std::cout<<"BELLMAN PASS states="<<p.size()<<" edges="<<edges<<" lower="<<cap<<"/1000000000\n";
}

from pathlib import Path
from hashlib import sha256
import argparse,subprocess,sys,os
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('--clang-cache',type=Path,required=True);a=p.parse_args();W=a.work.resolve();W.mkdir(parents=True,exist_ok=True);cache=a.clang_cache.resolve()
def run(*args):return subprocess.run(list(map(str,args)),check=True,stdout=subprocess.PIPE,text=True).stdout.strip()
def digest(p):return sha256(p.read_bytes()).hexdigest()
assert sys.byteorder=='little'
weights=W/'weights.bin';scalar=W/'scalar.json'
print(run(sys.executable,'-I','-B',R/'fine_weights.py',weights),flush=True)
assert digest(weights)=='0c97eca854ec1b1585fc10f2eb6ce1557e6a1a02e1a9adc3f9918fa8e2ca7e33'
assert digest(R/'potential.bin')=='31fb483b4f3fae399857b001e94afdd72b52533d8f5efdc81079da0baa809dbb'
print(run(sys.executable,'-I','-B',R/'scalar.py',scalar),flush=True)
assert digest(scalar)=='21498f78a98297ad8a71227aca727e12fe3adc538655e8e4f92bab6a3b802f36'
cc=os.environ.get('CXX','clang++')
for src in ['dijkstra','potential','check_bellman']:
 run(cc,'-O3','-std=c++17','-ftrapv',f'-fmodules-cache-path={cache}',R/f'{src}.cpp','-o',W/src)
r=run(W/'dijkstra',weights);assert r=='distance=463833847/1000000000 nodes=64137';print(r,flush=True)
r=run(W/'potential',weights,W/'potential.bin');assert 'potential-cap=460000000' in r;assert digest(W/'potential.bin')==digest(R/'potential.bin');print(r,flush=True)
r=run(W/'check_bellman',weights,R/'potential.bin');assert r=='BELLMAN PASS states=134400 edges=85246142 lower=460000000/1000000000';print(r,flush=True)
print('ALL_4302_CERTIFICATES_PASS')

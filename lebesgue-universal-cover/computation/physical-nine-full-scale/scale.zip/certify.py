"""Exact deformation, disk pads and all required old material row lower bounds."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import lcm,isqrt
from hashlib import sha256
import argparse,json,gzip
import numpy as np
from flint import arb,ctx
ctx.prec=192
def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator
def read(p):return json.loads(p.read_bytes())
def encoded(Y):
 d=lcm(*(x.denominator for xy in Y for x in xy))
 return dict(denominator=d,points=[[int(a*d),int(b*d)] for a,b in Y])
def d2(Y):return max((x-a)**2+(y-b)**2 for (x,y),(a,b) in combinations(Y,2))
def main():
 pa=argparse.ArgumentParser()
 for k in ['inputs','fit','radii','bank','old','out']:pa.add_argument(k,type=Path)
 pa.add_argument('--s',required=True,type=F);pa.add_argument('--balanced',type=Path);a=pa.parse_args()
 def sha(p):return sha256(p.read_bytes()).hexdigest()
 assert sha(a.bank)=='e849b308e0f32cfeef8423e5e23866e7e83b681807fb808d4c0b062bcf6d91d5' and sha(a.old)=='b0d3e4d6b3dc065a59c3a2de48256399813d8cb599f1cb3393d631dbdbe38181'
 b=read(a.bank);old=read(a.old);assert b['directions']==old['directions']
 U=2**22;Q=2**28;sc=F('.999999006');ec=1-sc;s=a.s;assert sc<=s<1;e=1-s;dirs=b['directions'];V=np.array(dirs);assert len(dirs)==256
 rho=[];pad=[];pi=arb.pi()
 for j,(x,y) in enumerate(dirs):
  sn,cs=(2*pi*j/256).sin_cos();assert (ar(F(x,U))-cs)**2+(ar(F(y,U))-sn)**2<ar(F(1,U))**2
  r=ar(F(x*x+y*y,U**2)).sqrt();z=r*Q/2;raw=round(float(z.mid()))+2;g=(raw-z)/Q
  assert ar(F(U-1,U))<r<ar(F(U+1,U)) and ar(F(149,100*Q))<g<ar(F(3,Q))
  assert ar(F(2,5*U)) > ar(ec)*r*(ar('.5')-ar('.422'))+g
  rho.append(r);pad.append(ar(ec)*r/2+g)
 fits=read(a.fit);R=read(a.radii);groups=[];summary={};point_move={}
 for name,f in [('P128','p128.json'),('oldQ','physical-q.json'),('newQ','distinct-q.json'),('P15','p15.json')]:
  d=read(a.inputs/f);Y=[(F(x,d['denominator']),F(y,d['denominator'])) for x,y in d['points']]
  if name=='P128':
   p=Y.copy();Y=[(x+e*vx/fits['denominator'],y+e*vy/fits['denominator']) for (x,y),(vx,vy) in zip(Y,fits['directions'],strict=True)]
   assert {(x,-y) for x,y in Y}==set(Y);P=Y.copy()
  elif name!='P15':
   z1,z2=map(F,R[name]['center']);Y=[(s*x+e*z1,s*y+e*z2) for x,y in Y]
  move=max((F(x,d['denominator'])-u)**2+(F(y,d['denominator'])-v)**2 for (x,y),(u,v) in zip(d['points'],Y))
  D=d2(Y);assert D<s*s,(name,float(D-s*s));gap=min(pj/r for pj,r in zip(pad,rho))-ar(move).sqrt()
  if name!='P128' or a.balanced is None:assert gap>0,(name,gap)
  y=encoded(Y);y['name']=name;groups.append(y)
  summary[name]=dict(move2=str(move),diameter2=str(D),pointwise=gap.str(30))
 tables=[]
 if a.balanced:
  import balanced
  assert s==sc and a.balanced.is_file()
  cert=a.out/'balanced-new.json';a.out.mkdir(exist_ok=True)
  balanced.audit(a.bank,a.old,a.inputs/'p128.json',a.fit,cert)
  assert cert.read_bytes()==a.balanced.read_bytes()
  tables.append(read(cert))
 G=F(120697911165410052,2**57);A=G/s**2
 out=dict(s=str(s),sigma=str(sc),area=str(A),decimal=ar(A).str(60),min_direction_credit=min(x/y for x,y in zip(pad,rho)).str(42),groups=summary,tables=tables)
 a.out.mkdir(exist_ok=True);(a.out/'result.json').write_text(json.dumps(out,indent=2)+'\n');(a.out/'physical.json').write_text(json.dumps(groups,separators=(',',':'))+'\n');print(out['decimal'],flush=True)
if __name__=='__main__':main()

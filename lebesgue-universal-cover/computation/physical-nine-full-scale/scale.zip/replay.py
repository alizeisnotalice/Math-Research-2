"""Replay the .83751 transfer increment and two finite nine-cloud witnesses."""
from pathlib import Path
from hashlib import sha256
import argparse,subprocess,sys,gzip,zipfile,json,os
HERE=Path(__file__).resolve().parent
def sha(p):return sha256(p.read_bytes()).hexdigest()
def run(cmd):subprocess.run(list(map(str,[sys.executable,'-B',*cmd])),check=True)
def unpack(src,dst):
 with zipfile.ZipFile(src) as z:z.extractall(dst)
def main():
 p=argparse.ArgumentParser()
 for k in ['comp','out']:p.add_argument(k,type=Path)
 p.add_argument('--fine-bank',type=Path);a=p.parse_args();c=a.comp.resolve();w=a.out.resolve();w.mkdir(exist_ok=False)
 prev=c/'physical-six-nine-51/scale.zip';geom=c/'physical-nine-51/geometry.zip';first=c/'seven-compression-61/scaled.zip'
 assert sha(prev)=='c2b030544c6565a8379aaa271cec35582d060486463866f8dabeac7ccf7b90ea' and sha(geom)=='3b616977d76bfef245f6a46bef1989f56fe2542af2d835ab2a8ab599db7c9e7d' and sha(first)=='d484f99fbe8d776fdfff975da4dbcca95fc184709ac70aad5ce45fb810304666'
 q=w/'prior';h=w/'geometry';unpack(prev,q);unpack(geom,h)
 old=w/'angular66.json'
 with zipfile.ZipFile(first) as z:old.write_bytes(gzip.decompress(z.read('angular-66.json.gz')))
 if a.fine_bank:bank=a.fine_bank.resolve()
 else:
  run([h/'kit/prepare.py',h/'kit',w/'bank'])
  run([h/'refine_p128.py',w/'bank/angular-bank.json',h/'kit/p128.json',h/'slice/slice.cpp',w/'fine','--keep-nine'])
  bank=w/'fine/angular-nine-fine-p128.json'
 grid=h/'kit/support_grid.py';assert sha(grid)=='c46dfbac6105ce339197ad1a466e9260c3335fb8509427e38e2a9b3b7c13745d'
 tokens=['L b=disk[j];','const L axis=L(j)*(K/n);','std::max(tbl[left%K],tbl[right%K])','h+=up_signed(pmax, (Fine/Q)*U);','b=std::max(b,h);']
 for src in (h/'slice/slice.cpp',h/'affine-nine.cpp',h/'anchor-nine.cpp'):
  text=src.read_text();assert all(t in text for t in tokens)
 assert 'disk=ints([upper_q(length/2)' in (h/'slice/run_slice.py').read_text()
 for key,s,fit,opt in [('uniform','.999999018','P-delta.json',[]),('final','.999999006','supported.json',['--balanced',HERE/'balanced-report.json'])]:
  out=w/key;run([HERE/'certify.py',q/'inputs',HERE/fit,q/'cloud-radii.json',bank,old,out,'--s',s,*opt])
  for name in ['result.json','physical.json']:assert (out/name).read_bytes()==(HERE/key/name).read_bytes()
 for n,t in [(6131,'.8375115'),(9769,'.8375116')]:
  dest=w/f'finite{n}';run([HERE/'finite.py',q/'finite_scaled.py',w/'final/physical.json',w/'final/result.json',dest,'--N',n,'--target',t])
  assert (dest/'receipt.json').read_bytes()==(HERE/f'finite{n}/receipt.json').read_bytes()
 print('VERIFIED .83751 SIGMA, 6131 AND 9769',flush=True)
if __name__=='__main__':main()

"""Produce exact rational finite witnesses by the registered .83751 circular-arc construction."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import argparse,gzip,json,sys
def main():
 a=argparse.ArgumentParser()
 for key in ['construction','physical','result','out']:a.add_argument(key,type=Path)
 a.add_argument('--N',type=int,required=True);a.add_argument('--target',type=F,required=True);a=a.parse_args()
 assert sha256(a.construction.read_bytes()).hexdigest()==SOURCE
 import importlib.util
 spec=importlib.util.spec_from_file_location('geom',a.construction);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 def diameter(p):
  h=g.hull(p);m=len(h);assert m>=3;j=1;maximum=0
  for i,z in enumerate(h):
   v=h[(i+1)%m]
   while g.turn(z,v,h[(j+1)%m])>g.turn(z,v,h[j]):j=(j+1)%m
   for t in [h[j],h[(j+1)%m]]:
    maximum=max(maximum,(t[0]-z[0])**2+(t[1]-z[1])**2,(t[0]-v[0])**2+(t[1]-v[1])**2)
  return maximum
 g.d2=diameter
 r=json.loads(a.result.read_bytes());sigma=F(r['sigma']);s=F(r['s']);G=g.G
 den,p,alpha2=g.disk(a.N);groups=[dict(name='disk',denominator=den,points=p)];alpha=g.ar(alpha2).sqrt()
 for n in [3,5,7,9]:
  p,m=g.regular(n,alpha);groups.append(dict(name='R'+str(n),denominator=g.Q,points=p))
 for raw in json.loads(a.physical.read_bytes()):
  groups.append(dict(name=raw['name'],denominator=s.numerator*raw['denominator'],points=[(x*s.denominator,y*s.denominator) for x,y in raw['points']]))
 rec=[]
 for d in groups:
  p=d['points'];D=F(diameter(p),d['denominator']**2);assert D<1 and len(p)<=a.N
  rec.append(dict(name=d['name'],count=len(p),diameter_squared=str(D)))
 bound=G*min(alpha2/sigma**2,1/s**2);assert bound>a.target
 a.out.mkdir(exist_ok=True);byt=(json.dumps(groups,separators=(',',':'))+'\n').encode()
 (a.out/'points.json.gz').write_bytes(gzip.compress(byt,compresslevel=8,mtime=0))
 result=dict(N=a.N,target=str(a.target),inner_squared=str(alpha2),general_lower=str(G/s**2),lower=str(bound),decimal=g.ar(bound).str(58),columns=rec,points_sha=sha256(byt).hexdigest())
 (a.out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(result['decimal'],[x['count'] for x in rec],flush=True)
SOURCE='0dc66d10d64df09296b5b009c73c84a808151d5a33c6e89e2f36971ce3723ea8'
if __name__=='__main__':main()

# .83751 实体九输入的完整尺度与有限点

在含 NumPy、python-flint 的本机 Python 中重算，COMP 是项目 computation，OUT 是新的输出目录。

    python -B replay.py "$COMP" "$OUT"

已有由 .83751 公共几何内核产生的实体九完整细角表时，可附加 `--fine-bank PATH`。复算验证输入 SHA，默认从公开几何包重建。三个上游归档路径固定在 replay.py。旧全域与 .83751 地板可用 physical-six-nine-51/scale.zip 的重放命令。有限有理坐标完整生成于 OUT/finite6131/points.json.gz 和 OUT/finite9769/points.json.gz。输入生成无随机性；拟合器不是证明依赖。普通和全尺度四组物理点表、完整行比较、有限回执随包冻结；精确的范围与数值见 PROOF.md。

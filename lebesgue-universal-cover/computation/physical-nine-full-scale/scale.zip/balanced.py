"""Directed integer support comparison for every P row over its complete rotation cell."""
import argparse,json
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from flint import arb,ctx
import numpy as np
ctx.prec=160
def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator
def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def audit(bank,old,source,fit,out):
 assert sha(bank)=='e849b308e0f32cfeef8423e5e23866e7e83b681807fb808d4c0b062bcf6d91d5' and sha(old)=='b0d3e4d6b3dc065a59c3a2de48256399813d8cb599f1cb3393d631dbdbe38181' and sha(source)=='d2be06dcd7aa9500e7fe48c5cd3a0c39b9d18358b8f5047c02faad4c32398620'
 b=read(bank);ob=read(old);p0=read(source);df=read(fit);p=np.array(p0['points'],dtype=np.int64);delta=np.array(df['directions'],dtype=np.int64);den=df['denominator'];d=p0['denominator'];assert den==d==10**9 and np.abs(p).max()<=d and 4*np.abs(delta).max()<=3*den
 U=2**22;Q=2**28;ec=F('.000000994');S=2**29;T=10**12;N=1536;v=b['directions'];assert v==ob['directions']
 def flo(x):return int(x.lower().floor().unique_fmpz())
 credits=[];rho_max=ar(F(U+1,U))
 for x,y in v:
  rho=ar(F(x*x+y*y,U*U)).sqrt();g=(round(float((rho*Q/2).mid()))+2)/ar(Q)-rho/2
  credits.append(flo(T*(rho/2+g/ar(ec))))
 fee=F(221,100000)
 assert ar(fee)>ar(2)/S+ar('0.75')*ar(2).sqrt()*rho_max*arb.pi()/N
 def integer_frame(j):
  sn,cs=(arb.pi()*j/N).sin_cos();a=[]
  for x,y in v:
   pair=[]
   for z in ((cs*x+sn*y)*S/U,(cs*y-sn*x)*S/U):
    k=round(float(z.mid()));assert abs(z-k)<1;pair.append(k)
   a.append(pair)
  return np.array(a,dtype=np.int64)
 # All int64 dot products have absolute value <=2*(S+2)*1e9 < 2**61.
 assert 2*(S+200)*max(d,den)<2**61
 prev=integer_frame(0)@p.T;worst=None;cnt=[0]*3;counts={};vmax=0
 for j in range(N):
  middle=integer_frame(2*j+1);L=prev;R=integer_frame(2*j+2)@p.T;prev=R;ix=(middle@p.T).argmax(axis=1);ix0=np.arange(256)
  # The exact old difference for candidate x and the chosen old anchor is negative at both endpoints
  # if both inequalities below fail. Throughout this cell the direction is a positive combination
  # of the two endpoints, hence such x never supports. Per coordinate difference <2*d.
  allow=(L>=L[ix0,ix,None]-4*d)|(R>=R[ix0,ix,None]-4*d)
  proj=middle@delta.T;loss=np.min(np.where(allow,proj,2**62),axis=1);vmax=max(vmax,int(allow.sum(axis=1).max()))
  # Worst matched displacement is compared with each frozen direction's actual rounded disk pad.
  k=[int(lo)*T//(S*den)+c-int(T*fee) for lo,c in zip(loss,credits)]
  rows=set()
  for z,(src,off) in enumerate([(b,j//4),(ob,j//4),(b,6912+j)]):
   inp=src['cells'][off];cnt[z]+=len(inp)
   for r in inp:rows.add(tuple(r[:7]))
  for r in rows:
   a,bs=r[:3],r[3:6];sw=r[6];assert min(bs)>0 and sum(bs)==sw and all(sum(w*v[i][t] for i,w in zip(a,bs))==0 for t in (0,1))
   value=F(sum(w*k[i] for w,i in zip(bs,a)),T*sw)
   if worst is None or value<worst:worst=value;where=[j,list(r)]
 assert worst>0,(float(worst),where)
 result=dict(K=N,tested=cnt,scale='.999999006',max_candidate_count=vmax,least_excess_over_epsilon=str(worst),physical_projection_spare=str(worst*ec),decimal_projection_spare=ar(worst*ec).str(40),worst=where,bank_hashes=[sha(bank),sha(old)],fit_sha=sha(fit))
 out.write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
if __name__=='__main__':
 import sys
 audit(*map(Path,sys.argv[1:]))

"""Rebuild two nine-body hosts and replay the true-body cross-tests."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import subprocess
import sys

from flint import arb,ctx,__version__ as version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from exact_r7 import host,sha,read,ar,direction,dot,sub
from w_upper import restore_body,outer_upper

TARGET=F(".839649")


def stage(*args):
    subprocess.run([sys.executable,"-I","-B",*map(str,args)],check=True)


def file_write(path,obj):
    path.write_text(json.dumps(obj,indent=2)+"\n")


def rebuild(work,prefix,full):
    p=HERE/(prefix+"host.json");meta=HERE/(prefix+"nine.json");data=read(meta)
    assert len(data["exact_rigid_pose"]["cloud_poses"])==4
    assert all(sha(HERE/"clouds"/(name+".json"))==digest for name,digest in data["inputs_sha256"].items())
    part=work/("v2" if prefix else "v1")
    part.mkdir()
    src=part/"exact-pose.json";file_write(src,data["exact_rigid_pose"])
    generated=part/"host.json";out=part/"host-rebuilt.json"
    extra=["--diagnostics"] if full else []
    stage(HERE/"rebuild_host.py",HERE/"clouds",HERE,src,generated,out,"--samples","131072",*extra)
    assert p.read_bytes()==generated.read_bytes()
    r=read(out)
    fields=["exact_rigid_pose","host_sha256","inputs_sha256","exact_outer_area",
            "outer_vertices","raw_sample_count","outer_padding_integer"]
    if full:fields+=["proved_inner_area"]
    assert all(r[k]==data[k] for k in fields)
    return p,meta,data,part


def regular_five(model):
    """The given diameter-one five-point test is the exact vertex subset of R5."""
    t,x,y=map(ar,model["exact_rigid_pose"]["curve_pose"][2:5])
    pi=arb.pi()
    r=1/(2*(pi/10).cos())
    V=[]
    for i in range(5):
        u,v=direction(t+2*pi*i/5)
        V.append((x+r*u,y+r*v))
    for i,p in enumerate(V):
        for j in range(i):
            d=sub(p,V[j]);squared=dot(d,d)
            if (i-j)%5 in (2,3):
                assert squared.contains(1) # exact: sin(2*pi/5)=cos(pi/10)
            else:
                assert squared<1
    return dict(contained=True,mode="five exact vertices of the posed true R5",
                pose=model["exact_rigid_pose"]["curve_pose"][2:5])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("work",type=Path);p.add_argument("cache",type=Path)
    p.add_argument("--clang",default="clang++")
    a=p.parse_args();assert __debug__;ctx.prec=192
    for line in (HERE/"MANIFEST.sha256").read_text().splitlines():
        digest, name=line.split("  ",1)
        assert sha(HERE/name)==digest,name
    W=a.work.resolve();W.mkdir(parents=True,exist_ok=False)
    p1,m1,v1,b1=rebuild(W,"",False)
    r7=b1/"r7-fit.json"
    stage(HERE/"exact_r7.py",p1,m1,HERE/"r7-poses-tight.json",r7)
    body=restore_body()
    P,D,A,inner=host(p1,v1)
    upper=outer_upper(P,D,A,inner,body,read(HERE/"w93-pose.json"),16384)
    assert upper==read(HERE/"expected-w-upper.json")
    stage(HERE/"hinge_w.py",p1,m1,str(TARGET),b1/"integer",a.cache,
          "--max-grid","2097152","--points","672","--host-points","1280","--clang",a.clang)
    low=read(b1/"integer/result.json")
    assert low["status"]=="PASS"
    assert all(low[k]==read(HERE/"expected-hinge.json")[k]
               for k in ("input_area_target","w_material_count","curvature","angular_first_derivative_upper"))
    p2,m2,v2,b2=rebuild(W,"v2-",True)
    r72=b2/"r7-fit.json"
    stage(HERE/"exact_r7.py",p2,m2,HERE/"v2-r7-poses-tight.json",r72,"--outer-only")
    v2repair=F(v2["exact_outer_area"])-F(v2["proved_inner_area"])
    assert 0<v2repair<F("1.203969971e-9")
    receipts=dict(status="PASS",flint=version,python=platform.python_version(),
        v1=dict(model_sha256=sha(m1),host_sha256=sha(p1),r7=read(r7),
                regular_pentagon=regular_five(v1),
                W=dict(lower=low,upper=upper,added_area_lower=str(TARGET-A),
                       added_area_upper=upper["true_increment_upper"])),
        v2=dict(model_sha256=sha(m2),host_sha256=sha(p2),r7_outer=read(r72),
                 simultaneous_true_area_increment_upper=str(v2repair)))
    file_write(W/"receipt.json",receipts)
    print("PASS nine-body true-host cross-tests",flush=True)


if __name__=="__main__":
    main()

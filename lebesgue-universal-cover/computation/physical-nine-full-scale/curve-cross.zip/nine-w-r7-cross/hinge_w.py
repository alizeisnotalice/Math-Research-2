"""All-angle, all-translation W area lower bound using an adaptive integer hinge."""
import argparse
from fractions import Fraction as F
import json
import os
from pathlib import Path
import subprocess
import sys

from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from exact_r7 import host,hull,sha,read,add,sub,dot,cross,direction,mul
from w_upper import ar,restore_body

S=10**7
SPEED=F(".186")


def speed(W):
    """All-angle derivative bound for the width-one support."""
    assert sum((abs(a)+abs(b))/F(k*k-1) for k,a,b in W.modes) < F(1,2)
    n=8192;sup=arb(0)
    for j in range(n+1):
        angle=arb.pi()*j/n
        z=direction(3*angle);q=direction(2*angle)
        h=arb(0)
        for k,a,b in W.h:
            h+=k*(b*z[0]-a*z[1])
            z=(z[0]*q[0]-z[1]*q[1],z[0]*q[1]+z[1]*q[0])
        sup=max(sup,abs(h).upper())
    bound=(sup+arb.pi()/(2*n)).upper()  # |h''|<=1, proven curvature in [0,1].
    assert bound<ar(SPEED)
    return bound


def choose(P,k):
    # Rank candidates by approximate cumulative perimeter. Every selected
    # vertex is a genuine proven inner point, regardless of this heuristic.
    from math import hypot
    from bisect import bisect_left
    L=[hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(P,P[1:]+P[:1],strict=True)]
    c=[0.]
    for z in L:c.append(c[-1]+z)
    rows=set(min(len(P)-1,bisect_left(c,r*c[-1]/k)) for r in range(k))
    for j in sorted(range(len(P)),key=lambda j:-L[j])[:70]:
        rows.add(j);rows.add((j+1)%len(P))
    return sorted(rows)


def emit(f,P):
    f.write(str(len(P))+" "+" ".join(f"{x} {y}"for x,y in P)+"\n")


def round_ball(x):
    q=int((x+ar(F(1,2))).floor().unique_fmpz())
    assert abs(x-q)<ar(F(501,1000))
    return q


def w_points(W,m):
    # Origin inradius >.45. Rational 4/S contraction more than pays for the
    # final integer rounding in any rotation/reflection.
    r=F(1,2)-sum((abs(a)+abs(b))/F(n*n-1)for n,a,b in W.modes)
    assert r>F(".45") and 4*ar(r)>arb(2).sqrt()*ar(F(501,1000))
    return [mul(arb(S-4),W.material(2*arb.pi()*j/m))for j in range(m)]


def angle_table(path,bank,cells,grid):
    with path.open("w") as f:
        f.write(f"{S} {len(cells)}\n")
        for hand,i in cells:
            co,si=direction(arb.pi()*(2*i+1)/grid)
            points=[(round_ball(co*x-hand*si*y),round_ball(si*x+hand*co*y))for x,y in bank]
            emit(f,hull(points))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("host","model","target","work","cache"):p.add_argument(name,type=Path if name!="target" else F)
    p.add_argument("--start",type=int,default=256)
    p.add_argument("--max-grid",type=int,default=32768)
    p.add_argument("--points",type=int,default=320)
    p.add_argument("--host-points",type=int,default=760)
    p.add_argument("--clang",default="clang++")
    a=p.parse_args();assert __debug__;ctx.prec=192
    W=restore_body();curvature=W.curvature()
    derivative=speed(W)
    P,D,A,scale=host(a.host,read(a.model));assert A<a.target<1
    work=a.work.resolve();work.mkdir(exist_ok=False,parents=True)
    cache=a.cache.resolve();cache.mkdir(exist_ok=True,parents=True)
    exe=work/"hinge"
    subprocess.run([a.clang,"-std=c++17","-O3","-fsanitize=undefined","-fsanitize-trap=undefined",
                    f"-fmodules-cache-path={cache}",HERE/"hinge_angles.cpp","-o",exe],
                   env=dict(os.environ,TMPDIR=str(work),TMP=str(work),TEMP=str(work)),cwd=work,check=True)
    h=work/"host.dat"
    f=F(S-4,D)*scale
    P0=hull([tuple(round(f*x)for x in P[i])for i in choose(P,a.host_points)])
    with h.open("w") as out:out.write(f"{S} 1\n");emit(out,P0)
    b=w_points(W,a.points)
    grid=a.start
    cells=[(j,i) for j in (1,-1) for i in range(grid)]
    leaf={1:[], -1:[]};levels=[]
    while cells and grid<=a.max_grid:
        table=work/"rotations.dat";angle_table(table,b,cells,grid)
        # If the true joint hull has area <=T and contains the original
        # radius .5 disk, its perimeter is <=4T. The midpoint polygon is
        # contained in the actual hull + omega*disk.
        omega=ar(SPEED)*arb.pi()/grid
        sigma=ar(a.target)*(1+4*omega)+arb.pi()*omega**2
        budget=int((sigma*10**6).upper().ceil().unique_fmpz())
        run=subprocess.check_output([exe,h,table,str(budget)],cwd=work,text=True).splitlines()
        assert len(run)==2
        missing=set(map(int,run[0].split()))
        count,requested=map(int,run[1].split())
        assert requested==len(cells) and len(missing)+count==requested and all(0<=x<requested for x in missing)
        levels.append(dict(grid=grid,requested=requested,covered=count,failed=len(missing),integer_target=budget))
        print(levels[-1],flush=True)
        for r,(j,i) in enumerate(cells):
            if r not in missing:leaf[j].append([i,grid])
        cells=[(j,2*i+e) for r,(j,i) in enumerate(cells) if r in missing for e in (0,1)]
        grid*=2
    report=dict(status="PASS" if not cells else "OPEN",host_sha256=sha(a.host),input_area_target=str(a.target),
                host_vertices=len(P0),w_material_count=a.points,host_sampling_target=a.host_points,levels=levels,open_count=len(cells),
                angular_first_derivative_upper=str(derivative),curvature=curvature,min_true_area_increment=str(a.target-A))
    for j in (1,-1):
        if cells:break
        here=F(0)
        for i,g in sorted(leaf[j],key=lambda a:F(a[0],a[1])):
            lo,hi=F(i,g),F(i+1,g)
            assert here==lo;here=hi
        assert here==1
    (work/"result.json").write_text(json.dumps(report,indent=2)+"\n")
    (work/"angle-tree.json").write_text(json.dumps(leaf,separators=(',',':'))+"\n")
    assert not cells


if __name__=="__main__":main()

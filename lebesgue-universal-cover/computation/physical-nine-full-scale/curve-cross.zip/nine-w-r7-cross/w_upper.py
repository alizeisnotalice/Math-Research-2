"""Prove a full-pose true W repair bracket for a frozen nine-body host."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sys

from flint import arb,ctx
HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from exact_r7 import host,hull,sha,read,dot,cross,direction,sub,add,mul
from w_support import ar, Spectrum


def norm(p):
    return arb(dot(p,p)).sqrt()


def edges(P):
    return zip(P,P[1:]+P[:1],strict=True)


def restore_body():
    p=HERE/'W93.json'
    assert sha(p)=='f791b04432770b59ab2e339c548a5d578d897d9816a56908855327aec0e19537'
    return Spectrum(read(p))


def outer_upper(P,D,area,scale,W,pose,N):
    assert pose["hand"] in (-1,1)
    s=pose["hand"]
    angle=ar(pose["angle"]);c0,s0=direction(angle)
    t=tuple(map(ar,pose["translation"]))
    def rotated(z):
        x,y=z
        return c0*x-s*s0*y,s0*x+s*c0*y
    def snap(x):
        a=int((x*D).lower().floor().unique_fmpz())
        assert x>=ar(F(a,D)) and x<ar(F(a+2,D))
        return a
    points=[]
    for j in range(N):
        theta=2*arb.pi()*j/N
        p=add(t,rotated(W.material(theta)))
        points.append(tuple(map(snap,p)))
    # With curvature 0<=rho<=1, the support difference between a true
    # contact and its nearest sampled normal is <= integral[0,pi/N]sin(x)dx.
    pad=2+int((D*(1-(arb.pi()/N).cos())).upper().ceil().unique_fmpz())
    Wouter=hull((x+u,y+v)for x,y in hull(points)for u in (-pad,pad)for v in (-pad,pad))
    K=hull(P+Wouter)
    A=F(sum(cross(p,q)for p,q in edges(K)),2*D*D)
    assert area<A<F(".8396531")
    delta=A-area*scale**2
    return dict(pose=pose,true_union_area_upper=str(A),true_increment_upper=str(delta),
                support_material_count=N,rational_hull_vertices=len(K),
                outward_point_padding_boxes=pad)


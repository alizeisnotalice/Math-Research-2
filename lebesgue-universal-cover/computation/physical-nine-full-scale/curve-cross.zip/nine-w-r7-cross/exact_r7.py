"""Arb check of the full seven arcs and their placement in the true nine-body hull."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
from flint import arb, acb, ctx
HERE=Path(__file__).resolve().parent


def ar(x):
    f=F(x)
    return arb(f.numerator)/f.denominator


def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def mul(s,a):return s*a[0],s*a[1]
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def orth(a):return -a[1],a[0]
def direction(a):
    s,c=a.sin_cos()
    return c,s


class Seven:
    def __init__(self,data):
        n=data["n"]
        assert n==7 and len(data["free_edge_angles"])==n-2
        angles=list(map(F,data["free_edge_angles"]))
        assert angles[0]==0
        side=data["final_side"]
        assert side in (-1,1)
        P=[(arb(0),arb(0))]
        for a in angles:
            P.append(add(P[-1],direction(ar(a))))
        vec=P[-1]
        length=dot(vec,vec).sqrt()
        assert 0<length<2
        last=add(mul(-arb(1)/2,vec),mul(-side*(1-length**2/4).sqrt()/length,orth(vec)))
        P.append(add(vec,last))
        assert len(P)==n
        P=[P[i] for i in sorted(range(n),key=lambda i:(3*i)%n)]
        mid=mul(arb(1)/n,(sum(x for x,_ in P),sum(y for _,y in P)))
        self.V=[sub(x,mid) for x in P]
        edge=[]
        self.strict_nonstar=arb(1)
        for i,p in enumerate(self.V):
            q=self.V[(i+1)%n]
            assert all(cross(sub(q,p),sub(r,p))>0 for j,r in enumerate(self.V) if j not in (i,(i+1)%n))
            for j,r in enumerate(self.V):
                if j==i:continue
                distance=dot(sub(r,p),sub(r,p))
                if (j-i)%n in (3,4):
                    assert distance.contains(1)  # exact equality by the unit star construction
                else:
                    assert distance<1
                    self.strict_nonstar=min(self.strict_nonstar,(1-distance).lower())
        self.segments={}
        normal={}
        for i in range(n):
            for j in ((i+3)%n,(i-3)%n):
                normal[(i,j)]=sub(self.V[i],self.V[j])
        for i in range(n):
            ends=[(i,(i+3)%n),(i,(i-3)%n)]
            if cross(normal[ends[0]],normal[ends[1]])<0:
                ends.reverse()
            a,b=ends
            assert cross(normal[a],normal[b])>0
            ai,bi=a[::-1],b[::-1]
            assert a not in self.segments and ai not in self.segments
            self.segments[a]=(b,0,i)
            self.segments[ai]=(bi,1,i)
        assert len(self.segments)==14
        # The symbolic directed star normals are exact opposites. Their cyclic
        # piece adjacency and one winding prove all vertex/arc sectors partition S^1.
        current=next(iter(self.segments))
        first=current;seen=set();self.angle_pieces=[];total=arb(0)
        for _ in range(14):
            assert current not in seen
            seen.add(current)
            tail,rho,i=self.segments[current]
            a,b=normal[current],normal[tail]
            turn=cross(a,b)
            assert turn>0
            total+=acb(dot(a,b),turn).arg()
            self.angle_pieces.append((a,b,rho,self.V[i]))
            current=tail
        assert current==first and total.contains(2*arb.pi()) and arb.pi()<total<3*arb.pi()

    def support(self,n):
        possible=[]
        for a,b,rho,p in self.angle_pieces:
            if not (cross(a,n)<0 or cross(n,b)<0):
                possible.append((dot(p,n)+rho).upper())
        assert possible
        return max(possible)


def read(path):return json.loads(path.read_bytes())
def sha(path):return sha256(path.read_bytes()).hexdigest()


def host(hpath,exact):
    data=read(hpath);D=data["denominator"];P=list(map(tuple,data["vertices"]));n=len(P)
    assert sha(hpath)==exact["host_sha256"] and n==exact["outer_vertices"]
    assert D==exact["snap_grid"]==10**15 and exact["curve_scale"]=="1"
    assert P==hull(P) # independent canonical strict convex order
    outer=F(sum(cross(x,y)for x,y in zip(P,P[1:]+P[:1],strict=True)),2*D*D)
    assert outer==F(exact["exact_outer_area"])
    factor=F("0.999999999")
    # H_outer <= H_true+(pad+2)*sqrt(2)*D^-1 in every support direction.
    # The fixed centered disk in H_true has radius 1/2.
    pad=ar(F(exact["outer_padding_integer"]+2,D))*arb(2).sqrt()
    assert pad<ar((1-factor)/2)
    return P,D,outer,factor


def hull(points):
    points=sorted(set(points))
    def half(s):
        out=[]
        for p in s:
            while len(out)>=2 and cross(sub(out[-1],out[-2]),sub(p,out[-1]))<=0:out.pop()
            out.append(p)
        return out[:-1]
    return half(points)+half(reversed(points))


def fit(spectrum,P,D,scale,pose):
    rot=direction(-ar(pose["angle"]));t=tuple(map(ar,pose["translation"]));hand=pose["hand"]
    assert hand in (-1,1)
    least=arb(1);index=-1
    for i,(x,y) in enumerate(zip(P,P[1:]+P[:1],strict=True)):
        dx,dy=sub(y,x);u=(dy,-dx);L=arb(dot(u,u)).sqrt()
        wall=ar(F(dot(u,x),D)*scale)/L
        a,b=mul(1/L,u)
        U=(rot[0]*a-rot[1]*b,hand*(rot[1]*a+rot[0]*b))
        gap=(wall-dot((a,b),t)-spectrum.support(U)).lower()
        if gap<least:least=gap;index=i
    return least,index


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("host",type=Path);p.add_argument("host_meta",type=Path);p.add_argument("pose_plan",type=Path)
    p.add_argument("out",type=Path)
    p.add_argument("--outer-only",action="store_true")
    args=p.parse_args();ctx.prec=192
    P,D,outer,factor=host(args.host,read(args.host_meta))
    plan=read(args.pose_plan)
    report=dict(status="PASS",host_sha256=sha(args.host),host_meta_sha256=sha(args.host_meta),
                host_vertices=len(P),true_host_area_lower=str(outer*factor**2),
                true_host_area_upper=str(outer),inner_dilation=str(factor),
                containment_scope="rational outer polygon" if args.outer_only else "true nine-body hull",bodies={})
    for name, ps in plan.items():
        path=HERE/(name+".json")
        s=Seven(read(path));out=[]
        for pose in ps:
            gap,face=fit(s,P,D,F(1) if args.outer_only else factor,pose)
            z=dict(pose=pose,least=str(gap),face=face,certified_inside=bool(gap>0))
            print(name,z,flush=True)
            assert gap>0
            out.append(z)
        report["bodies"][name]=dict(shape_sha256=sha(path),arcs=7,vertex_cones=7,
                                    min_nondiameter_square_slack=str(s.strict_nonstar),poses=out)
    args.out.write_text(json.dumps(report,indent=2)+"\n")


if __name__=='__main__':
    main()

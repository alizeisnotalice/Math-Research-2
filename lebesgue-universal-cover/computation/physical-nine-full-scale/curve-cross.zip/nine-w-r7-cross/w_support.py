"""Exact R286 support, point-containment and area calculations."""
from fractions import Fraction as F
from math import isqrt
from flint import arb, ctx


def ar(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def edges(poly):
    return zip(poly, poly[1:] + poly[:1], strict=True)


def unit(theta):
    s, c = theta.sin_cos()
    return c, s


def rotate(z, u):
    return z[0] * u[0] - z[1] * u[1], z[0] * u[1] + z[1] * u[0]


class Spectrum:
    def __init__(self, data):
        self.modes = [(n, F(a), F(b)) for n, a, b in data["curvature_modes"]]
        assert data["degree"] == 93
        assert [n for n, _, _ in self.modes] == list(range(3, 94, 2))
        assert any(self.modes[-1][1:])
        self.rho = [(n, ar(a), ar(b)) for n, a, b in self.modes]
        self.h = [(n, ar(a / (1-n*n)), ar(b / (1-n*n))) for n, a, b in self.modes]

    def curvature(self):
        """One closed half-circle and antiperiodicity cover the true profile."""
        grid = 32768
        pi = arb.pi()
        d2 = ar(sum(n*n*(abs(a)+abs(b)) for n, a, b in self.modes))
        largest = arb(0)
        for j in range(grid + 1):
            theta = pi * j / grid
            z = unit(3 * theta)
            step = unit(2 * theta)
            g = arb(0)
            for _, a, b in self.rho:
                g += a*z[0] + b*z[1]
                z = rotate(z, step)
            largest = max(largest, abs(g).upper())
        biggest = (largest + d2*(pi/grid)**2/8).upper()
        lo, hi = (ar(F(1,2))-biggest).lower(), (ar(F(1,2))+biggest).upper()
        assert lo > ar(".0000225") and hi < ar(".9999775")
        return dict(grid=grid, strict_interval=list(map(str, (lo, hi))))

    def material(self, theta):
        n = unit(theta)
        h, dh = arb("0.5"), arb(0)
        for k, a, b in self.h:
            c, s = unit(k*theta)
            h += a*c+b*s
            dh += k*(b*c-a*s)
        return h*n[0]-dh*n[1], h*n[1]+dh*n[0]

    def support(self, u):
        step = rotate(u, u)
        z = rotate(u, step)
        h = arb("0.5")
        for _, a, b in self.h:
            h += a*z[0] + b*z[1]
            z = rotate(z, step)
        return h

    def verify_inner(self, table):
        p = table["points"]
        q = table["denominator"]
        assert q == 10**12 and len(p) == 256
        inradius = F(1, 2)-sum((abs(a)+abs(b))/F(n*n-1) for n,a,b in self.modes)
        assert inradius > F(".45074883")
        scale = F(".999999")
        assert ar(inradius * (1-scale)) > arb(2).sqrt()/q
        for j, row in enumerate(p):
            real = self.material(2*arb.pi()*j/len(p))
            assert all(abs(ar(scale)*z*q-k) < 1 for z,k in zip(real,row,strict=True))
        squared = max((x-u)**2 + (y-v)**2 for x,y in p for u,v in p)
        assert squared <= q*q
        return dict(count=len(p), diameter_squared=str(F(squared,q*q)),
                    centered_inradius_lower=str(inradius))


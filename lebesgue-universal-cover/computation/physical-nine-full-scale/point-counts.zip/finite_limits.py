from fractions import Fraction as F
from flint import arb,ctx
from pathlib import Path
import json,sys
ctx.prec=192
G=F(120697911165410052,2**57)/F('.999999006')**2;vals={}
for n,t in [(6130,'.8375115'),(9768,'.8375116')]:
 z=arb(G.numerator)/G.denominator*((arb.pi()/n).cos()/(arb.pi()/(2*n)).cos())**2
 a=F(t);assert z<arb(a.numerator)/a.denominator
 vals[n]=dict(target=str(a),upper=z.str(50))
Path(sys.argv[1]).write_text(json.dumps(vals,indent=2)+'\n')

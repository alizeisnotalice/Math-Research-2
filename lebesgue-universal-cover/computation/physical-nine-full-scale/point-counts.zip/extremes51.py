"""Same convex hull for the deformed nine-input theorem under every isometry."""
import hashlib,json,sys
from pathlib import Path
def det(a,b,p):
 return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def chain(pts):
 h=[]
 for p in pts:
  while len(h)>1 and det(h[-2],h[-1],p)<=0:h.pop()
  h.append(p)
 return h[:-1]
source,out=map(Path,sys.argv[1:]);groups=json.loads(source.read_bytes());result=[]
for x in groups:
 pts=list(map(tuple,x['points']));order=sorted(set(pts));h=chain(order)+chain(reversed(order))
 assert min(det(a,b,p) for a,b in zip(h,h[1:]+h[:1]) for p in pts)>=0
 result.append(dict(name=x['name'],denominator=x['denominator'],points=h,source_indices=[pts.index(t) for t in h]))
assert [len(g['points']) for g in result]==[114,11,11,15]
out.write_text(json.dumps(result,separators=(',',':'))+'\n');print(hashlib.sha256(out.read_bytes()).hexdigest())

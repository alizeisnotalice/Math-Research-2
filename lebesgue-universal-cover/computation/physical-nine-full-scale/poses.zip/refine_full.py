"""Refine the 23-dimensional true nine-body objective via smoothed and discrete restarts."""
from argparse import ArgumentParser
import json
from pathlib import Path
from time import monotonic

import numpy as np
from scipy.optimize import minimize

from search import Model, NAMES, ORD, read
from staged_search import add_best, coordinates, load_pose


def refine(args):
    model=Model(args.library,[ORD/'kit'/f'{v}.json' for v in NAMES])
    base=[]
    for source in args.seeds:
        for row in read(source)['trials'][:30]:
            p,hand=load_pose(model,row['pose'])
            area,_=model.area(p,hand)
            base=add_best(base,[(area,hand,p,row['source'])],args.keep,15)
    initial=base[0][0]
    start=monotonic()
    rng=np.random.default_rng(4283755)
    scale=np.ones(23)
    scale[[2,5,8,11,14,17,20]]=3.
    runtime=[]

    def submit(a,h,x,label):
        nonlocal base
        old=base[0][0]
        base=add_best(base,[(a,h,x,label)],args.keep,15)
        if a<old:
            runtime.append(dict(improvement=float(a),source=label,objective_evaluations=model.calls))
            print(label,a,model.calls,'seconds',round(monotonic()-start,1),flush=True)

    for k,(value,hand,pose,_) in enumerate(base.copy()[:args.smooth]):
        axes=rng.normal(size=(4,23))
        axes=np.r_[axes,-axes]*scale
        for it,eps in enumerate((.0001,.000025,.000003,.00000025,.000000025)):
            current=pose.copy()
            best=[value,pose]

            def objective(z):
                p=current+z*scale
                a,_=model.area(p,hand)
                if a<best[0]:
                    best[:]=a,p
                total=0.
                gsum=np.zeros(23)
                for d in axes:
                    f,g=model.area(p+eps*d,hand)
                    total+=f-.83755
                    gsum+=g
                return total/len(axes),gsum*scale/len(axes)

            opt=minimize(objective,np.zeros(23),jac=True,method='BFGS',
                         options={'maxiter':120,'gtol':1.e-9,'xrtol':1.e-11})
            tail=current+opt.x*scale
            x,v,_=model.optimize(tail,hand,15,coordinates(15),750)
            value,pose=min((best,(v,x)),key=lambda a:a[0])
            submit(value,hand,pose,f'smooth-{k}-{it}')

    for k in range(args.hops):
        _,hand,pose,_=base[k%len(base)]
        jitter=[.0002,.0007,.0024,.006,.012][(k//len(base))%5]
        u=pose+jitter*scale*rng.normal(size=23)
        if k%11==0:
            j=(k//11)%4
            u[11+3*j]+=rng.choice((-1,1))*math_tau_over(3)
        x,v,_=model.optimize(u,hand,15,coordinates(15),950)
        submit(v,hand,x,f'hop-{k}')

    for k,(_,hand,base_pose,_) in enumerate(base.copy()[:args.refit]):
        pose=base_pose.copy()
        for j in range(4):
            flag=1<<j
            kept=hand&~flag
            old=model.area(pose,hand)[0]
            candidates=[(old,hand,pose)]
            for _,sg,params,_ in model.placements(pose,j,4,15^flag,kept):
                candidate=pose.copy()
                candidate[11+3*j:14+3*j]=params
                hg=kept|(flag if sg<0 else 0)
                x,v,_=model.optimize(candidate,hg,15,coordinates(15),850)
                candidates.append((v,hg,x))
                submit(v,hg,x,f'refit-{k}-{j}')
            _,hand,pose=min(candidates,key=lambda a:a[0])

    def freeze(q):
        a,h,x,s=q
        return dict(area=float(a),source=s,pose=model.recipe(x,h))

    output=dict(initial_area=float(initial),trials=[freeze(q) for q in base],
                improvements=runtime,objective_evaluations=model.calls,random_seed=4283755)
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print('final',base[0][0],model.calls,'seconds',round(monotonic()-start,1),flush=True)


def math_tau_over(n):
    return 2*np.pi/n


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('library',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('seeds',type=Path,nargs='+')
    p.add_argument('--keep',type=int,default=14)
    p.add_argument('--smooth',type=int,default=8)
    p.add_argument('--hops',type=int,default=224)
    p.add_argument('--refit',type=int,default=8)
    refine(p.parse_args())

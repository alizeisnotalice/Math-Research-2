"""Certify rational outer enclosures of actual posed curves and finite clouds."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from math import lcm
from pathlib import Path

from flint import arb, ctx

D = 10**15


def ar(v):
    f = F(v)
    return arb(f.numerator)/f.denominator


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return sha256(p.read_bytes()).hexdigest()


def turn(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def pairs(seq):
    return zip(seq, [*seq[1:],seq[0]], strict=True)


def area(p):
    return F(sum(x*v-y*u for ((x,y),(u,v)) in pairs(p)), 2*D*D)


def hull(pts):
    pts = sorted(set(pts))

    def chain(seq):
        result = []
        for q in seq:
            while len(result)>1 and turn(result[-2],result[-1],q)<=0:
                result.pop()
            result.append(q)
        return result[:-1]

    return chain(pts) + chain(reversed(pts))


def snap(x):
    k = int((x*D).lower().floor().unique_fmpz())
    assert x >= ar(F(k,D)) and x < ar(F(k+2,D))
    return k


def circle_samples(n, a, x, y, subdivisions, lam):
    pi = arb.pi()
    a,x,y = map(ar,(a,x,y))
    if n == 0:
        for i in range(subdivisions):
            s,c = (2*pi*ar(F(i,subdivisions))).sin_cos()
            yield snap(c*lam/2),snap(s*lam/2)
        return
    m = (subdivisions+2*n-1)//(2*n)
    r = lam/(2*(pi/(2*n)).cos())
    for j in range(n):
        t = a + 2*pi*j/n
        u,v = t.sin_cos()
        cx,cy = x+r*v,y+r*u
        for k in range(m+1):
            angle = t+pi+pi*ar(F(2*k-m,2*m*n))
            s,c = angle.sin_cos()
            yield snap(cx+lam*c),snap(cy+lam*s)


def posed_cloud(input_data, pose):
    s = F(pose['half_tangent'])
    c,t = (1-s*s)/(1+s*s),2*s/(1+s*s)
    tx,ty = map(F,pose['translation'])
    hand = pose['hand']
    assert hand in (1,-1) and t*t+c*c == 1
    d = input_data['denominator']
    pts = input_data['points']
    assert max((x-u)**2+(y-v)**2 for x,y in pts for u,v in pts) <= d*d
    return [(tx+(c*x-hand*t*y)/d,ty+(t*x+hand*c*y)/d) for x,y in pts]


def exact_cloud_margin(material, points):
    """Minimum signed slack divided by the L1 norm of the integer wall normal."""
    sides=[]
    for u,v in pairs(material):
        nx,ny=v[1]-u[1],u[0]-v[0]
        sides.append((nx,ny,nx*u[0]+ny*u[1],abs(nx)+abs(ny)))
    best=None
    for x,y in points:
        d=lcm(x.denominator,y.denominator)
        xx,yy=int(x*d*D),int(y*d*D)
        for nx,ny,h,norm in sides:
            gap=h*d-nx*xx-ny*yy
            den=norm*d
            if best is None or gap*best[1] < best[0]*den:
                best=gap,den
    return F(best[0],best[1]*D)


def run(args):
    data=read(args.pose)
    if 'trials' in data:
        record=data['trials'][args.index]
        pose=record['pose']
    else:
        pose=data
        record={}
    a=list(map(F,pose['curve_pose']))
    assert len(a)==11
    lam=ar(args.curve_scale)
    assert 0<args.curve_scale<=1 and args.samples>=32
    # R*delta^2/8 bounds sagitta, with R<=1 and delta<=2*pi/N.
    pi=arb.pi()
    pad=2+int(((pi**2*lam*D)/(2*args.samples**2)).upper().ceil().unique_fmpz())
    p=[]
    translations=[(0,0,0,0),(3,0,*a[:2]),(5,*a[2:5]),(7,*a[5:8]),(9,*a[8:11])]
    for q in translations:
        p.extend(circle_samples(*q,args.samples,lam))
    curve_count=len(p)
    inputs={}
    clouds={}
    snapped={}
    for name, placement in pose['cloud_poses'].items():
        path=(args.comp/'finite-point-leaf-input.json' if name=='original-p30' else args.kit/(name+'.json'))
        inputs[name]=sha(path)
        own=posed_cloud(read(path),placement)
        clouds[name]=own
        snapped[name]=[(int((x*D).__floor__()),int((y*D).__floor__())) for x,y in own]
        p.extend(snapped[name])
    if record.get('input_sha256'):
        assert record['input_sha256']==inputs
    inner=hull(p)
    outer=hull((x+u,y+v) for x,y in inner for u in (-pad,pad) for v in (-pad,pad))
    bound=area(outer)
    assert bound>0 and area(inner)<bound
    # Check each finite group after the exact independent rational motion.
    for own in clouds.values():
        assert exact_cloud_margin(outer,own)>=0
    args.host.write_text(json.dumps({'denominator':D,'vertices':outer},separators=(',',':'))+'\n')
    result={'source_sha256':sha(args.pose),'host_sha256':sha(args.host),'inputs_sha256':inputs,
            'exact_rigid_pose':pose,'curve_scale':str(args.curve_scale),'snap_grid':D,
            'arc_sampling_per_turn':args.samples,'raw_sample_count':len(p),
            'outer_padding_integer':pad,'precision_bits':ctx.prec,'outer_vertices':len(outer),
            'numeric_true_envelope_if_recorded':record.get('area'),
            'exact_outer_area':str(bound),'exact_outer_area_decimal':ar(bound).str(35),
            'proved_strictly_below_083755':bound<F('.83755')}
    if args.diagnostics:
        r=F('.49') * args.curve_scale
        for a,b in pairs(inner):
            dx,dy=b[0]-a[0],b[1]-a[1]
            h=dy*a[0]-dx*a[1]
            assert h>0 and h*h>(r*D)**2*(dx*dx+dy*dy)
        delta=1-F(3,D)/r
        assert delta>0
        lower=delta*delta*area(inner)
        result['proved_inner_area']=str(lower)
        result['proved_inner_area_decimal']=ar(lower).str(35)
        result['fixed_pose_redundancy']={}
        for name,xy in clouds.items():
            other=hull([*p[:curve_count],*(pt for k,v in snapped.items() if k!=name for pt in v)])
            margin=exact_cloud_margin(other,xy)
            other_outer=hull((x+u,y+v) for x,y in other for u in (-pad,pad) for v in (-pad,pad))
            result['fixed_pose_redundancy'][name]={
                'exact_sample_hull_linf_margin':str(margin),
                'exact_sample_hull_linf_margin_decimal':ar(margin).str(22),
                'certified_redundant':margin>F(2,D),
                'certified_exposed':margin<-F(pad,D),
                'area_after_removal_enclosure':[str(delta*delta*area(other)),str(area(other_outer))],
            }
    args.receipt.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print('actual upper',result['exact_outer_area_decimal'],'bodies',5+len(inputs),'vertices',len(outer),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('kit','comp','pose','host','receipt'):
        p.add_argument(k,type=Path)
    p.add_argument('--index',type=int,default=0)
    p.add_argument('--samples',type=int,default=16384)
    p.add_argument('--curve-scale',type=F,default=F(1))
    p.add_argument('--diagnostics',action='store_true')
    args=p.parse_args()
    assert __debug__
    ctx.prec=192
    run(args)

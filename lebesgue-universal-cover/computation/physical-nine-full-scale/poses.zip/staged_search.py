"""Add clouds in all orders, with local continuation and point-family diagnostics."""
import argparse
import json
import math
from pathlib import Path
from time import monotonic

import numpy as np
from scipy.optimize import minimize

from search import Model, NAMES, ORD, initial_seeds, matrix, read


def load_pose(model, recipe):
    x = np.r_[np.array(recipe['curve_pose'],dtype=float),np.zeros(12)]
    hand = 0
    for name, p in recipe['cloud_poses'].items():
        j = NAMES.index(name)
        a, s = float(p['angle_radians']), p['hand']
        t = np.array(p['translation'],dtype=float)+matrix(a,s)@model.centers[j]
        x[11+3*j:14+3*j] = a,*t
        hand |= (1<<j) if s < 0 else 0
    return x, hand


def coordinates(mask):
    return np.array([*range(11),*(11+3*j+k for j in range(4) if mask & (1<<j) for k in range(3))])


def distinguish(a,b,mask):
    if a[1]&mask != b[1]&mask:
        return True
    d = a[2] - b[2]
    for j,n in ((2,5),(5,7),(8,9),(11,1),(14,1),(17,1),(20,1)):
        d[j] = math.remainder(d[j],math.tau/n)/3
    return np.linalg.norm(d[coordinates(mask)]) > .002


def add_best(bank, values, count, mask):
    selected = []
    for q in sorted([*bank,*values],key=lambda p:p[0]):
        if all(distinguish(q,r,mask) for r in selected):
            selected.append(q)
        if len(selected)>=count:
            break
    return selected


def save(path, model, banks, extra=()):
    def entry(k,p):
        return dict(area=float(p[0]),source=p[3],pose=model.recipe(p[2],p[1],mask=k))

    r = {str(k):[entry(k,p) for p in v] for k,v in sorted(banks.items()) if v}
    report = dict(trials=r.get('15',[]),bank=r,objective_evaluations=model.calls,local_diagnostics=list(extra))
    path.write_text(json.dumps(report,indent=2)+'\n')


def run(args):
    model=Model(args.library,[ORD/'kit'/f'{v}.json' for v in NAMES])
    banks={k:[] for k in range(16)}
    seeds=initial_seeds(model, args.fronts, (), terrain=args.terrain)
    inarg={}
    for name,p,path in seeds:
        area=model.area(p,0,0)[0]
        base=(area,0,p,name)
        inarg[name] = base
        banks[0]=add_best(banks[0],[base],args.per_mask,0)
    optim=[]
    for _,_,p,name in banks[0]:
        x,v,_=model.optimize(p,0,0,coordinates(0),350)
        optim.append((v,0,x,name+':curve minimum'))
    banks[0]=add_best(banks[0],optim,args.per_mask,0)
    for label in ('R155-six','R237-seven','R286-176/35402','H175'):
        if label in inarg and all(distinguish(inarg[label],p,0) for p in banks[0]):
            banks[0].append(inarg[label])
    for path in args.known:
        for q in read(path)['trials'][:30]:
            x,hand=load_pose(model,q['pose'])
            val=model.area(x,hand,15)[0]
            banks[15]=add_best(banks[15],[(val,hand,x,q['source'])],args.per_mask,15)
    start=monotonic()
    for level in range(4):
        for mask in [k for k in banks if k.bit_count()==level]:
            for f in range(4):
                bit=1<<f
                if mask&bit:
                    continue
                target=mask|bit
                candidates=[]
                for _,hand,seed,name in banks[mask]:
                    for _,sign,pos,_ in model.placements(seed,f,args.choices,mask,hand):
                        p=seed.copy()
                        p[11+3*f:14+3*f]=pos
                        hand_new=hand|(bit if sign<0 else 0)
                        x,value,_=model.optimize(p,hand_new,target,coordinates(target),700)
                        candidates.append((value,hand_new,x,name+'+'+NAMES[f]))
                banks[target]=add_best(banks[target],candidates,args.per_mask,target)
                print('mask',target,'from',mask,'area',banks[target][0][0],
                      'calls',model.calls,'seconds',round(monotonic()-start,1),flush=True)
                save(args.output,model,banks)
    rng=np.random.default_rng(5954)
    best=banks[15].copy()
    scale=np.ones(23)
    scale[[2,5,8,11,14,17,20]]=3.0
    for k in range(args.mutations):
        _,h,p,name=best[k%len(best)]
        radius=[.00003,.00018,.00075,.002,.0045][(k//len(best))%5]
        u=p+radius*scale*rng.normal(size=23)
        if k%7==0:
            h^=1<<((k//7)%4)
        x,v,_=model.optimize(u,h,15,coordinates(15),900)
        best=add_best(best,[(v,h,x,name)],args.per_mask,15)
        if v<banks[15][0][0]:
            print('improvement',k,v,flush=True)
            banks[15]=best
            save(args.output,model,banks)
    banks[15]=best
    extra=[]
    v,h,x,name=banks[15][0]
    for mask in range(16):
        literal=model.area(x,h,mask)[0]
        xx,sol,_=model.optimize(x,h,mask,coordinates(mask),800)
        extra.append({'mask':mask,'from_best_fixed':literal,'from_best_reoptimized':sol})
        banks[mask]=add_best(banks[mask],[(sol,h,xx,name+': leave out')],args.per_mask,mask)
    val,hand,pose,name=banks[15][0]
    for a in range(2):
        base=pose.copy()
        step=2.e-5 if a==0 else 2.e-6
        def fun(v):
            return model.area(base+step*scale*v,hand,15)[0]-.83755
        r=minimize(fun,np.zeros(23),method='Powell',options={'maxfev':9000,'ftol':1e-12,'xtol':1e-7})
        if r.fun+.83755<val:
            val,pose=r.fun+.83755,base+step*scale*r.x
    banks[15]=add_best(banks[15],[(val,hand,pose,name+': Powell')],args.per_mask,15)
    save(args.output,model,banks,extra)
    print('final',banks[15][0][0],'calls',model.calls,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('library',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--fronts',type=int,default=20)
    p.add_argument('--per-mask',type=int,default=6)
    p.add_argument('--choices',type=int,default=3)
    p.add_argument('--mutations',type=int,default=95)
    p.add_argument('--terrain',type=Path,action='append',default=[])
    p.add_argument('--known',type=Path,action='append',default=[])
    run(p.parse_args())

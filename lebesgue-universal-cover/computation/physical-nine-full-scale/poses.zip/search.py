"""Search feasible poses by integrating the numerical true support envelope."""
import argparse
import ctypes as C
from hashlib import sha256
from itertools import product
import json
import math
from pathlib import Path
from time import monotonic

import numpy as np
from scipy.optimize import minimize, minimize_scalar

NAMES = ('p128', 'physical-q', 'distinct-q', 'p15')
GOAL = .83755
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
ORD = ROOT / 'lebesgue-nine-margin47'
COMP = ROOT / 'lebesgue-main/lebesgue-universal-cover/computation'
WITNESS = ROOT / 'lebesgue-sol-b150-adversary'
Q = 2**44


def read(path):
    return json.loads(path.read_bytes())


def matrix(angle, sign):
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -sign*s], [s, sign*c]])


def host_support(angles, pose):
    u = np.column_stack((np.cos(angles), np.sin(angles)))
    answer = np.full(len(u), .5)
    for n, a, shift in ((3, 0., pose[:2]), (5, pose[2], pose[3:5]),
                         (7, pose[5], pose[6:8]), (9, pose[8], pose[9:11])):
        t = a + np.arange(n) * (math.tau/n)
        v = np.cos(angles[:, None] - t)
        r = .5 / math.cos(math.pi/(2*n))
        base = r*v
        h = np.maximum(base, np.where(v <= -math.cos(math.pi/(2*n)), 1+base, -1))
        answer = np.maximum(answer, u@shift + h.max(axis=1))
    return u, answer


class Model:
    def __init__(self, library, paths):
        self.lib = C.CDLL(str(library.resolve()))
        v = np.ctypeslib.ndpointer(np.float64, ndim=1, flags='C_CONTIGUOUS')
        self.lib.configure_cloud.argtypes = [C.c_int, v, C.c_int]
        self.lib.configure_cloud.restype = None
        self.lib.joint_area.argtypes = [v, C.c_int, C.c_int, v]
        self.lib.joint_area.restype = C.c_double
        self.lib.fit_slack.argtypes = [C.c_int, C.c_int, C.c_double, v, v, C.c_int, v]
        self.lib.fit_slack.restype = C.c_double
        self.paths = paths
        self.centers = []
        self.points = []
        self.symmetric = []
        for i, p in enumerate(paths):
            data = read(p)
            pts = np.array(data['points'], dtype=float) / data['denominator']
            mean = pts.mean(axis=0)
            self.centers.append(mean)
            self.points.append(pts-mean)
            self.symmetric.append({(x, -y) for x, y in data['points']} == set(map(tuple, data['points'])))
            self.lib.configure_cloud(i, (pts-mean).ravel(), len(pts))
        self.calls = 0

    def area(self, pose, hand=0, mask=15):
        g = np.empty(23)
        self.calls += 1
        return self.lib.joint_area(np.ascontiguousarray(pose), hand, mask, g), g

    def placements(self, pose, i, choices=3, mask=0, basehand=0):
        grid = np.arange(192) * (math.tau/192)
        fine = np.arange(512) * (math.tau/512)
        u, h = host_support(grid, pose)
        uu, hh = host_support(fine, pose)
        for j in range(4):
            if mask & (1<<j):
                sign = -1 if basehand & (1<<j) else 1
                a,x,y = pose[11+3*j:14+3*j]
                pts = self.points[j]@matrix(a,sign).T + [x,y]
                h = np.maximum(h,(u@pts.T).max(axis=1))
                hh = np.maximum(hh,(uu@pts.T).max(axis=1))
        u, uu = u.ravel(), uu.ravel()
        trials = []
        for hand in (1,) if self.symmetric[i] else (1, -1):
            def calc(angle, directions, support):
                xy = np.zeros(2)
                slack = self.lib.fit_slack(i, hand, angle, directions, support, len(support), xy)
                return slack, xy

            s = np.array([calc(x, u, h)[0] for x in grid])
            lows = np.flatnonzero((s <= np.roll(s, 1)) & (s <= np.roll(s, -1)))
            for j in sorted(lows, key=s.__getitem__)[:4]:
                a = grid[j]
                step = math.tau/192
                r = minimize_scalar(lambda x: calc(x, uu, hh)[0],
                                    bounds=(a-1.3*step,a+1.3*step), method='bounded',
                                    options={'xatol': 3.e-8, 'maxiter': 36})
                slack, xy = calc(r.x, uu, hh)
                x = pose.copy()
                ii = np.arange(11+3*i,14+3*i)
                x[ii] = (r.x, *xy)
                flag = basehand | ((1<<i) if hand < 0 else 0)
                best, area, _ = self.optimize(x, flag, mask|(1<<i), ii, 70)
                trials.append((area, hand, best[ii], slack))
        selected = []
        for v in sorted(trials, key=lambda z: z[0]):
            if any(v[1] == q[1] and abs(math.remainder(v[2][0]-q[2][0], math.tau)) < .06 for q in selected):
                continue
            selected.append(v)
            if len(selected) >= choices:
                break
        return selected

    def optimize(self, pose, hand, mask, indexes, maxiter):
        scale = np.where(np.isin(indexes, (2,5,8,11,14,17,20)), 3., 1.)
        initial = self.area(pose, hand, mask)[0]
        best = [initial, pose]

        def f(v):
            x = pose.copy()
            x[indexes] += v*scale
            a, g = self.area(x, hand, mask)
            if a < best[0]:
                best[:] = a, x
            return a-GOAL, g[indexes]*scale

        r = minimize(f, np.zeros(len(indexes)), jac=True, method='BFGS',
                     options={'maxiter': maxiter, 'gtol': 3.e-11, 'xrtol': 1.e-13})
        return best[1], best[0], str(r.message)

    def recipe(self, pose, hand, names=NAMES, mask=15):
        groups = {}
        for i, name in enumerate(names):
            if mask & (1<<i):
                a, *t = pose[11+3*i:14+3*i]
                sign = -1 if hand & (1<<i) else 1
                shift = np.array(t)-matrix(a, sign)@self.centers[i]
                groups[name] = {'hand':sign,'angle_radians':format(a, '.17g'),
                                'half_tangent':format(math.tan(a/2), '.17g'),
                                'translation':[format(t,'.17g') for t in shift]}
        return {'curve_pose':[format(v, '.17g') for v in pose[:11]],
                'cloud_poses':groups}


def initial_seeds(model, limit, optional, extra_fronts=(), terrain=()):
    sources = {
        'R286-176/35402': WITNESS/'r286-portable/basin/host.json',
        'R237-seven': WITNESS/'r237-metal-seven/final-pose.json',
        'R226-seven': COMP/'five-point-tube/joint-pose.json',
        'R155-six': COMP/'free-p30-reoptimized-pose.json',
        'H175': COMP/'seven-point-families-pose.json',
        'newer-upper': ROOT/'luc-astra-lower-global/upper-pose.json',
        'low-blind': COMP/'mixed-support-blind-low-pose.json',
    }
    seeds = []
    for label, path in sources.items():
        if not path.is_file():
            continue
        p = read(path)
        if isinstance(p, list):
            x = list(map(float, p[:11]))
        elif 'center' in p:
            x = [v/Q for v in p['center']]
        elif 'pose' in p and isinstance(p['pose'], list):
            x = [float(v)/p.get('coordinate_denominator',1) for v in p['pose'][:11]]
        elif 'parameters' in p and isinstance(p['parameters'], list):
            x = list(map(float,p['parameters'][:11]))
        else:
            continue
        if len(x) == 11:
            seeds.append((label, np.r_[x, np.zeros(12)], path))
    candidates = []
    frontier = [ORD/'priority5-recovery55/first-stops.jsonl',
                *sorted((ORD/'core-083755').glob('batch-*.jsonl')), *extra_fronts]
    for path in frontier:
        for row in path.read_text().splitlines():
            try:
                v = json.loads(row)
            except json.JSONDecodeError:
                break
            if not v['out'][0] and v.get('front') and len(v['front']) == 22:
                lo, hi = np.array(v['front']).reshape((2,11))
                seed = np.r_[(lo+hi)/(2*Q),np.zeros(12)]
                label = 'frontier-' + '/'.join(map(str, v['leaf']))
                candidates.append((model.area(seed,0,0)[0], label, seed, path))
    angles = (2,5,8)
    def same(x,y):
        d = x[:11]-y[:11]
        for j,n in zip(angles,(5,7,9),strict=True):
            d[j] = math.remainder(d[j],math.tau/n)/3
        return np.linalg.norm(d) < .006
    counts = 0
    for _, label, seed, path in sorted(candidates,key=lambda x:x[0]):
        if not any(same(seed,b) for _,b,_ in seeds):
            seeds.append((label,seed,path))
            counts += 1
            if counts >= limit:
                break
    for path in optional:
        row=read(path)
        x=np.array(row['curve_pose'],dtype=float)
        seeds.insert(0,(path.stem,np.r_[x,np.zeros(12)],path))
    for path in terrain:
        for row in read(path)['representative_boxes']:
            x=np.mean(row['first_stop'],axis=1)/row['coordinate_unit']
            assert np.max(np.abs(x-row['center']))<1.e-15
            label='terrain-'+'/'.join(map(str,row['key']))+f".{row['source_region']}"
            seeds.append((label,np.r_[x,np.zeros(12)],path))
    return seeds


def run(args):
    paths = [ORD/'kit'/f'{v}.json' for v in NAMES]
    if args.references:
        paths[0] = COMP/'finite-point-leaf-input.json'
    names = (('original-p30', *NAMES[1:]) if args.references else NAMES)
    model = Model(args.library, paths)
    seeds = initial_seeds(model, args.fronts, args.extra, args.front_source, args.terrain)
    seeds = [s for s in seeds if not args.only or any(v in s[0] for v in args.only)]
    assert seeds
    active = [j for j in range(4) if args.mask & (1<<j)]
    indexes = np.array([*range(11),*(11+3*j+k for j in active for k in range(3))])
    p = seeds[0][1] + np.random.default_rng(20261119).normal(0,1.e-4,23)
    for j in active:
        p[12+3*j:14+3*j] *= 5
    first, g = model.area(p,1,args.mask)
    err = max(abs((model.area(p+e,1,args.mask)[0] - model.area(p-e,1,args.mask)[0])/2.e-7 - v)
              for e,v in zip(np.eye(23)*1.e-7,g,strict=True))
    assert err<4.e-7, (first,err)
    start = monotonic()
    updates = []
    for name, seed, path in seeds:
        picks = [model.placements(seed,j,args.choices) for j in active]
        options = []
        for combo in product(*picks):
            x = seed.copy()
            hand = 0
            for j,(_,s,v,_) in zip(active,combo,strict=True):
                x[11+3*j:14+3*j] = v
                if s < 0:
                    hand |= 1<<j
            options.append((model.area(x,hand,args.mask)[0],hand,x))
        for rank,(init, hand, x) in enumerate(sorted(options,key=lambda x:x[0])[:args.branches]):
            best, area, state = model.optimize(x, hand, args.mask, indexes, args.iterations)
            rec = {'source':name,'source_name':path.name,'source_sha256':sha256(path.read_bytes()).hexdigest(),
                   'seed_area':init,'area':area,'branch':rank,'solver_status':state,'area_calls':model.calls,
                   'pose':model.recipe(best,hand,names,args.mask),
                   'sizes':{v:len(read(paths[j])['points']) for j,v in enumerate(names) if j in active},
                   'input_sha256':{v:sha256(paths[j].read_bytes()).hexdigest() for j,v in enumerate(names) if j in active}}
            updates.append(rec)
            print(name,rank,'initial',init,'true numeric',area,'calls',model.calls,
                  'seconds',round(monotonic()-start,1),flush=True)
            args.output.write_text(json.dumps({'fd_error':err,'trials':sorted(updates,key=lambda p:p['area'])},
                                              indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('library',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--only',action='append',default=[])
    parser.add_argument('--extra',action='append',type=Path,default=[])
    parser.add_argument('--front-source',action='append',type=Path,default=[])
    parser.add_argument('--terrain',action='append',type=Path,default=[])
    parser.add_argument('--fronts',type=int,default=12)
    parser.add_argument('--choices',type=int,default=3)
    parser.add_argument('--branches',type=int,default=2)
    parser.add_argument('--iterations',type=int,default=800)
    parser.add_argument('--mask',type=int,default=15)
    parser.add_argument('--references',action='store_true')
    run(parser.parse_args())

"""Generalize the R237 numerical support envelope to four independent clouds."""
from hashlib import sha256
from pathlib import Path
import argparse

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('source', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
s = a.source.read_text()
print('R237 source', sha256(a.source.read_bytes()).hexdigest())
changes = {
    'Cloud cloudP,cloudQ;': 'std::array<Cloud,4> clouds;',
    'const std::array<Fan,7>& families,double* g=nullptr':
        'const std::vector<Fan>& families,double* g=nullptr',
    'std::array<size_t,7> at{};': 'std::array<size_t,9> at{};',
    'std::array<Piece,7> ls{};': 'std::array<Piece,9> ls{};',
    'g+17': 'g+23',
    'for(int i=0;i<7;i++)for(int k=i+1;k<7;k++)':
        'for(size_t i=0;i<families.size();i++)for(size_t k=i+1;k<families.size();k++)',
    'ls.begin(),ls.end()': 'ls.begin(),ls.begin()+families.size()',
}
for x, y in changes.items():
    assert s.count(x) == 1, x
    s = s.replace(x, y)
s = s[:s.index('extern "C" void set_cloud')]
a.output.write_text(s + r'''
extern "C" void configure_cloud(int i,const double* xy,int n) {
    auto& cloud=clouds.at(i);
    cloud.clear();
    for(int j=0;j<n;j++)cloud.push_back({xy[2*j],xy[2*j+1]});
    cloud=hull(std::move(cloud));
}

extern "C" double joint_area(const double* a,int hand,int mask,double* gradient) {
    std::vector<Fan> f{Fan{{0,tau,{0.,0.,.5}}},regular(3,0.,a[0],a[1]),regular(5,a[2],a[3],a[4]),
        regular(7,a[5],a[6],a[7]),regular(9,a[8],a[9],a[10])};
    for(int i=0;i<4;i++)if(mask&(1<<i)){
        int j=11+3*i, sign=hand&(1<<i)?-1:1;
        f.push_back(polygon(clouds[i],a[j],a[j+1],a[j+2],sign,i+4));
    }
    return area(f,gradient);
}

// Only used to rank starting guesses. The final area uses the full envelope.
extern "C" double fit_slack(int i,int sign,double angle,const double* directions,
                           const double* support,int n,double* shift) {
    const double C=std::cos(angle),S=std::sin(angle);
    Cloud p;
    for(auto q:clouds.at(i))p.push_back(rotate({q.x,sign*q.y},C,S));
    std::vector<double> b(n);
    for(int j=0;j<n;j++){
        double best=-10.;
        for(auto q:p)best=std::max(best,q.x*directions[2*j]+q.y*directions[2*j+1]);
        b[j]=support[j]-best;
    }
    double lo=-*std::max_element(b.begin(),b.end()),hi=-*std::min_element(b.begin(),b.end())+1.e-12;
    shift[0]=shift[1]=0.;
    Cloud old,newer;
    old.reserve(n+4);newer.reserve(n+4);
    for(int step=0;step<29;step++){
        const double h=(lo+hi)/2;
        old={{-1.,-1.},{1.,-1.},{1.,1.},{-1.,1.}};
        for(int j=0;j<n&&!old.empty();j++){
            const double x=directions[2*j],y=directions[2*j+1],rhs=b[j]+h;
            newer.clear();
            auto u=old.back();
            double du=x*u.x+y*u.y-rhs;
            for(auto v:old){
                const double dv=x*v.x+y*v.y-rhs;
                if((du<=0.)!=(dv<=0.)){
                    const double t=du/(du-dv);
                    newer.push_back({u.x+(v.x-u.x)*t,u.y+(v.y-u.y)*t});
                }
                if(dv<=0.)newer.push_back(v);
                u=v;du=dv;
            }
            old.swap(newer);
        }
        if(old.empty())lo=h;
        else{
            hi=h;
            shift[0]=shift[1]=0.;
            for(auto v:old){shift[0]+=v.x/old.size();shift[1]+=v.y/old.size();}
        }
    }
    return hi;
}
''')

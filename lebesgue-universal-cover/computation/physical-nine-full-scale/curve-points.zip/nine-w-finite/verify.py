"""Verify small explicit rational W clouds with the same true fixed nine-body lower bound."""
from fractions import Fraction as F
from pathlib import Path
import json,sys,argparse

from flint import arb,ctx
HERE=Path(__file__).resolve().parent

Q=10**12
SHRINK=F("0.99999999999")
REFERENCE=F(".839649")


def verify(W,plan):
    from exact_r7 import ar, sub, dot
    turns=list(map(F,plan["normals"]))
    assert turns==sorted(set(turns)) and turns[-1]<turns[0]+1
    assert all(0<v-u<F(1,4) for u,v in zip(turns,turns[1:]+[turns[0]+1],strict=True))
    P=[W.material(2*arb.pi()*ar(x)) for x in turns]
    top=arb(0)
    for p,q in zip(P,P[1:]+P[:1],strict=True):
        dx,dy=sub(q,p);L=(dx*dx+dy*dy).sqrt();assert L>0
        u=dy/L,-dx/L
        v=(W.support(u)-dot(p,u)).upper()
        top=max(top,v)
    def integer(x):
        z=x*ar(Q*SHRINK)
        k=int((z+ar(F(1,2))).floor().unique_fmpz())
        assert abs(k-z)<ar(F(501,1000))
        return k
    cloud=[tuple(map(integer,row)) for row in P]
    max_distance_sq=max((a-x)**2+(b-y)**2 for a,b in cloud for x,y in cloud)
    assert max_distance_sq<=Q*Q
    total=sum((abs(a)+abs(b))/F(n*n-1) for n,a,b in W.modes)
    assert total<F(".05") # hence W lies in radius .55 and contains radius .45
    numeric=arb(2).sqrt()*ar(F(501,1000*Q))
    assert numeric<ar(F(".45")*(1-SHRINK))
    epsilon=(top+ar(F(".55")*(1-SHRINK))+numeric).upper()
    T=F(plan["target"])
    true_w_bound=(ar(T)*(1+4*epsilon)+arb.pi()*epsilon**2).upper()
    assert true_w_bound<ar(REFERENCE)
    old = {F(".83900"): F(".837599"), F(".83920"): F(".837799")}.get(T)
    if old is not None:
        old_upper=(ar(old)*(1+4*epsilon)+arb.pi()*epsilon**2).upper()
        assert old_upper<ar(".838247")
    return dict(target=str(T),denominator=Q,points=cloud,hausdorff_upper=str(epsilon),
                optional_r286_old_six_lower=str(old) if old is not None else None,
                transferred_true_w_upper=str(true_w_bound),squared_diameter=str(F(max_distance_sq,Q*Q)),count=len(P))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("nine_archive_directory",type=Path)
    p.add_argument("nine_actual_replay_receipt",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--r286-actual-replay-receipt",type=Path)
    a=p.parse_args();assert __debug__;ctx.prec=192
    source=a.nine_archive_directory.resolve()
    sys.path.insert(0,str(source))
    from exact_r7 import sha,read
    from w_upper import restore_body
    assert sha(source/"verify.py")=="7a7ba0824fe85e814987b7f2da81be0722f36c9fee18fa5652a9b7e929e8e8ca"
    has_old=a.r286_actual_replay_receipt is not None
    r=read(a.nine_actual_replay_receipt)
    expected=dict(r)
    expected.pop("python")
    assert expected==read(source/"expected-receipt.json")
    assert r["status"]=="PASS" and r["v1"]["host_sha256"]=="6a5f12ede0c2168f7ca5a4141811bd086fe52dd5de0eb220a849a28d35ffed09"
    assert r["v1"]["W"]["lower"]["status"]=="PASS" and F(r["v1"]["W"]["lower"]["input_area_target"])==REFERENCE
    if has_old:
        old=read(a.r286_actual_replay_receipt)
        assert old["status"]=="PASS" and old["r280_W"]["sha256"]==sha(source/"W93.json")
        assert old["fixed_six"]["source_sha256"]=="f657d2314e8a460f4baac61ee88589ff80f8b854d9ac51fe5c65cb99dccf19e6"
        assert F(old["fixed_six"]["lower"]["target"])==F(".838247") and old["fixed_six"]["lower"]["failed"]==0
    W=restore_body();curv=W.curvature()
    data=HERE/"finite-plans.json"
    out=[verify(W,plan)for plan in read(data)]
    if not has_old:
        for item in out:item.pop("optional_r286_old_six_lower")
    a.output.write_text(json.dumps(dict(status="PASS",arithmetic=curv,plans_sha256=sha(data),
         reference_sha256=sha(a.nine_actual_replay_receipt),fixed_nine_physical_sha256=r["v1"]["model_sha256"],
         optional_old_six=bool(has_old),clouds=out),indent=2)+"\n")
    print([(item["count"],item["target"],item.get("optional_r286_old_six_lower"))for item in out],flush=True)


if __name__=="__main__":
    main()

"""Propose a P128 extension while preserving every original physical point."""
import argparse
from fractions import Fraction as F
from itertools import combinations
import json
from math import lcm
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar

from search import Model, NAMES, ORD, matrix, read


def circle_intersections(points):
    i,j=np.triu_indices(len(points),1)
    a,b=points[i],points[j]
    delta=b-a
    norm=np.linalg.norm(delta,axis=1)
    ortho=delta[:,::-1]*[-1,1]/norm[:,None]
    offset=np.sqrt(1-norm**2/4)[:,None]*ortho
    mid=(a+b)/2
    return np.r_[mid+offset,mid-offset]


def feasible(proposals, points):
    mask=np.max(np.sum((proposals[:,None,:]-points[None,:,:])**2,axis=2),axis=1)<=1.+3.e-13
    return proposals[mask]


def narrow(p, mean, integer_pts, denominator):
    scale=10**12
    den=lcm(scale,denominator)
    pts=[(x*(den//denominator),y*(den//denominator)) for x,y in integer_pts]
    for amount in (1.e-8,1.e-7,1.e-6,1.e-5):
        x,y=np.rint(scale*((1-amount)*p+amount*mean)).astype('int64')
        xx,yy=int(x)*(den//scale),int(y)*(den//scale)
        if (xx,yy) in pts:
            continue
        diameter=max((xx-u)**2+(yy-v)**2 for u,v in pts)
        if diameter<den*den:
            return (xx,yy),pts,den,diameter
    return None


def real_point(local, den, recipe):
    s=F(recipe['half_tangent']); c,t=(1-s*s)/(1+s*s),2*s/(1+s*s)
    a,b=map(F,recipe['translation'])
    x,y=map(lambda i:F(i,den),local)
    return a+c*x-recipe['hand']*t*y,b+t*x+recipe['hand']*c*y


def verify_fit(coords,den,host,recipe):
    v=host['vertices']
    D=host['denominator']
    sides=[]
    for j,u in enumerate(v):
        w=v[(j+1)%len(v)]
        nx,ny=w[1]-u[1],u[0]-w[0]
        sides.append((nx,ny,nx*u[0]+ny*u[1],abs(nx)+abs(ny)))
    best=None
    for local in coords:
        x,y=real_point(local,den,recipe)
        d=lcm(x.denominator,y.denominator)
        xx,yy=int(x*d*D),int(y*d*D)
        for nx,ny,h,length in sides:
            value=h*d-nx*xx-ny*yy
            scale=d*length
            if best is None or value*best[1] < best[0]*scale:
                best=value,scale
    return F(best[0],D*best[1])


def run(a):
    inp=a.kit/'p128.json'
    data=read(inp)
    d0=data['denominator']
    pts=np.array(data['points'],dtype=float)/d0
    mean=pts.mean(axis=0)
    assert len(pts)==128
    host=read(a.host)
    D=host['denominator']; V=host['vertices']
    v=np.array(V,dtype=float)/D
    tangent=np.roll(v,-1,axis=0)-v
    walls=tangent[:,::-1]*[1,-1]
    lengths=np.linalg.norm(walls,axis=1)
    walls/=lengths[:,None]
    h=(walls*v).sum(axis=1)
    audit=read(a.audit)
    recipe=audit['exact_rigid_pose']['cloud_poses']['p128']
    R=matrix(float(recipe['angle_radians']),recipe['hand'])
    t=np.array(recipe['translation'],dtype=float)
    local=walls@R
    upstream=pts@R.T+t
    closeness=np.max(walls@upstream.T,axis=1)-h
    keep=set(np.argsort(closeness)[-64:])
    for j in range(360):
        theta=2*np.pi*j/360
        keep.add(int(np.argmax(walls@np.array([np.cos(theta),np.sin(theta)]))))
    ii=np.array(sorted(keep))
    cornersets=[feasible(batch,pts) for batch in np.array_split(circle_intersections(pts),32)]
    crossings=np.vstack([batch for batch in cornersets if len(batch)])
    proposals=[]
    for j in ii:
        u=local[j]
        candidates=feasible(pts+u,pts)
        corners=np.r_[crossings,candidates]
        if len(corners):
            k=np.argmax(corners@u)
            p=corners[k]
            excess=(p@R.T+t)@walls[j]-h[j]
            proposals.append((excess,j,p))
    model=Model(a.library,[a.kit/f'{v}.json' for v in NAMES])

    def support_bank(n, facets):
        angles=np.arange(n)*(2*np.pi/n)
        u=np.column_stack((np.cos(angles),np.sin(angles)))
        strongest=np.argsort(lengths)[-facets:]
        return np.r_[u,walls[strongest]].ravel(),np.r_[np.max(u@v.T,axis=1), h[strongest]]

    directions,support=support_bank(256,128)
    fine,finsup=support_bank(1152,512)

    def probe(coords):
        sampled=256
        model.lib.configure_cloud(0,np.ascontiguousarray(coords-mean).ravel(),len(coords))
        xy=np.zeros(2)
        rows=[]
        for sign in (1,-1):
            def f(angle, dirs, supp):
                return model.lib.fit_slack(0,sign,angle,dirs,supp,len(supp),xy)
            step=2*np.pi/sampled
            vals=np.array([f(j*step,directions,support) for j in range(sampled)])
            hits=np.flatnonzero((vals<=np.roll(vals,1))&(vals<=np.roll(vals,-1)))
            chosen=[j*step for j in sorted(hits,key=vals.__getitem__)[:6]]
            if sign==recipe['hand']:
                chosen.append(float(recipe['angle_radians']))
            for q in chosen:
                o=minimize_scalar(lambda x:f(x,fine,finsup),bounds=(q-1.2*step,q+1.2*step),method='bounded',
                                  options={'xatol':1.e-8,'maxiter':32})
                val=f(o.x,fine,finsup)
                rows.append((val,sign,o.x,xy.copy()))
        return min(rows,key=lambda z:z[0])

    rows=[]
    picked=[]
    parent=probe(pts)
    def finish(coords,den,trial):
        val,hand,angle,xy=trial
        t=xy-matrix(angle,hand)@mean
        fit=dict(hand=hand,half_tangent=format(np.tan(angle/2),'.17g'),
                 translation=[format(x,'.17g') for x in t])
        margin=verify_fit(coords,den,host,fit)
        return dict(numeric_slack=float(val),pose=fit,exact_outer_margin=str(margin),
                    outer_margin_decimal=float(margin),
                    true_joint_contains=margin>F(audit['outer_padding_integer']+2,D))

    for _,j,p in sorted(proposals,key=lambda q:q[0],reverse=True):
        if any(np.linalg.norm(p-q)<.027 for q in picked):
            continue
        proposed=narrow(p,mean,data['points'],d0)
        if proposed is None:
            continue
        local_point,old,den,dist=proposed
        x,y=real_point(local_point,den,recipe)
        u,w=V[j],V[(j+1)%len(V)]
        nx,ny=w[1]-u[1],u[0]-w[0]
        excess=(nx*x+ny*y-F(nx*u[0]+ny*u[1],D))/(abs(nx)+abs(ny))
        if excess<=0:
            continue
        cloud=np.array([*old,local_point],dtype=float)/den
        trial=probe(cloud)
        val=trial[0]
        picked.append(p)
        rows.append(dict(point=list(local_point),denominator=den,old_count=len(old),
                         exact_new_pair_diameter_squared=str(F(dist,den*den)),
                         frozen_pose_wall=int(j),frozen_pose_linf_excess=str(excess),
                         frozen_pose_decimal=float(excess),free_fit_numeric=float(val),
                         free_pose_fit=finish([*old,local_point],den,trial)))
        print('point',len(rows),'fixed',float(excess),'free numeric',val,flush=True)
        if len(rows)>=a.candidates:
            break
    rows.sort(key=lambda z:z['free_fit_numeric'],reverse=True)
    combo=[]
    if rows:
        den=rows[0]['denominator']
        assert all(q['denominator']==den for q in rows) and den%d0==0
        old=[(x*(den//d0),y*(den//d0)) for x,y in data['points']]
        all_new=list(map(lambda row:tuple(row['point']),rows))
        for n in range(len(all_new),1,-1):
            for group in combinations(all_new,n):
                if any((x-u)**2+(y-v)**2>den**2 for (x,y),(u,v) in combinations(group,2)):
                    continue
                trial=probe(np.array([*old,*group],dtype=float)/den)
                fit=finish([*old,*group],den,trial)
                combo.append(dict(count=n,points=group,denominator=den,free_pose_fit=fit))
            if any(x['free_pose_fit']['true_joint_contains'] for x in combo):
                break
    a.output.write_text(json.dumps(dict(parent_numeric_slack=float(parent[0]),rows=rows,combined=combo),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('library','host','audit','output'):
        p.add_argument(k,type=Path)
    p.add_argument('--kit',type=Path,default=ORD/'kit')
    p.add_argument('--candidates',type=int,default=16)
    run(p.parse_args())

"""Replay fixed-pose escapes and reoptimized exact containment for P128 extensions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from math import lcm
import json
from pathlib import Path


def exact_points(source,p,den,motion):
    q=F(motion['half_tangent'])
    c,s=(1-q*q)/(1+q*q),2*q/(1+q*q)
    t=motion['hand']
    a,b=map(F,motion['translation'])
    assert t in (-1,1) and c*c+s*s==1
    base=source['denominator']
    assert den%base==0
    old={(x*(den//base),y*(den//base)) for x,y in source['points']}
    extra=set(map(tuple,p))
    assert len(old)==128 and len(extra)==len(p) and not old&extra
    seen=old|extra
    assert max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(seen,2))<=den*den
    return [(a+(c*x-t*s*y)/den,b+(s*x+t*c*y)/den) for x,y in seen]


def enclosure_margin(pts,walls,D):
    best=None
    for x,y in pts:
        d=lcm(x.denominator,y.denominator)
        xx,yy=int(x*d*D),int(y*d*D)
        for nx,ny,h,length in walls:
            scaled_gap=h*d-nx*xx-ny*yy
            norm=d*length
            if best is None or scaled_gap*best[1] < best[0]*norm:
                best=scaled_gap,norm
    return F(best[0],D*best[1])


def verify(a):
    get=lambda p:json.loads(p.read_bytes())
    original,host,audit,data=map(get,(a.p128,a.host,a.audit,a.extensions))
    assert sha256(a.host.read_bytes()).hexdigest()==audit['host_sha256']
    assert sha256(a.p128.read_bytes()).hexdigest()==audit['inputs_sha256']['p128']
    assert audit['curve_scale']=='1'
    D=host['denominator']; V=host['vertices']
    walls=[]
    for j,(x,y) in enumerate(V):
        u,v=V[(j+1)%len(V)]
        nx,ny=v-y,x-u
        walls.append((nx,ny,nx*x+ny*y,abs(nx)+abs(ny)))
    old=audit['exact_rigid_pose']['cloud_poses']['p128']
    frozen=[]
    for row in data['rows']:
        den=row['denominator']
        as_before=exact_points(original,[row['point']],den,old)
        gate=walls[row['frozen_pose_wall']]
        negative=-enclosure_margin(as_before,[gate],D)
        assert negative==F(row['frozen_pose_linf_excess'])>0
        frozen.append(float(negative))
    results=[]
    total_pad=F(audit['outer_padding_integer']+2,D)
    cases=[(q,[q['point']]) for q in data['rows']]+[(q,q['points']) for q in data['combined']]
    assert len(cases)==6
    for row,points in cases:
        fit=row['free_pose_fit']
        pts=exact_points(original,points,row['denominator'],fit['pose'])
        margin=enclosure_margin(pts,walls,D)
        assert margin==F(fit['exact_outer_margin'])>total_pad and fit['true_joint_contains']
        results.append({'points':len(pts),'confirmed_outer_linf_margin':str(margin),
                        'true_joint_linf_margin_at_least':str(margin-total_pad)})
    a.output.write_text(json.dumps({'fixed_pose_escapes':frozen,'refits':results},indent=2)+'\n')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('p128','host','audit','extensions','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    assert __debug__
    verify(a)

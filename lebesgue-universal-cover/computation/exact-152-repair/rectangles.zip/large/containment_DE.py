from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'frozen'),str(D/'frozen/computation')]
from local_support import A,Arc,add,sub,angle,arc,periodize,load,pentagon
from deformed_reuleaux_support import body,environment
from verify_geometry import preclip_core,visible_parts,prove_exterior
ctx.prec=192;old,_,core=load(D/'frozen/computation');ns=environment(str(D/'frozen/computation'),'1.5497');ctx.prec=192
extra=[pentagon(ns,*map(F,p),240,-1,'D'+str(i))[0] for i,p in enumerate([('.7982906999','.03268800001')])];coremat,_,_=visible_parts(core);bodies=old+extra+coremat
v,_=body(ns,F('1.19999'),F('.08464486'));edges=[sub(v[i],v[j]) for i,j in ns['orders']];u0=(arb(1),arb(0));angles=[angle(n) for n in edges]
for i in range(1,len(angles)):
 while angles[i]<angles[i-1]: angles[i]+=360
angles.append(angles[0]+360)
roots=json.loads((D/'large-result.json').read_text())['root_brackets'][1:];out=[]
for r in roots:
 t=ns['box'](*map(F,r))
 for k,hand in ((0,1),(180,-1)):
  def h(a):return ns['supports'](v,edges,ns['trig'](a*hand-k+t),u0,False)
  tx=A('.5')-h(arb(0));ty=(2*(A('.5')-h(arb(120)))+tx)/arb(3).sqrt();tpose=A(k)-t
  arcs=[arc(f'P:{i}',angles[i],angles[i+1],v[c],arb(rad),tpose,hand) for i,(c,rad) in enumerate(ns['sector'])]
  arcs=periodize([Arc(x.label,x.lo,x.hi,add(x.center,(tx,ty)),x.rho) for x in arcs]);gap=F('0.001');domains=[(F(j)+gap,F(j+60)-gap) for j in range(0,360,60)]
  try: proof=prove_exterior(bodies,arcs,domains);print('pass',r,k,hand,proof,flush=True);out.append(dict(root=r,turn=k,hand=hand,complete=True,exclude_boundary_degrees=str(gap),proof=proof))
  except Exception as e: print('not certified',r,k,hand,repr(e),flush=True);out.append(dict(root=r,turn=k,hand=hand,complete=False,error=repr(e)))
(D/'containment-DE.json').write_text(json.dumps(out,indent=2)+'\n')

"""Directed parameter and angular checks for a common, uninflated reflected host."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json
import sys
from flint import arb, ctx
root = Path(__file__).resolve().parent
frozen = root / 'frozen'
comp = frozen / 'computation'
sys.path[:0] = [str(frozen), str(comp)]
import certify_family as cf
from local_support import A, load, pentagon, direction, dot, pose
from verify_geometry import visible_parts, settle_hex_normals, intersect, gap, increasing_difference, possible
from deformed_reuleaux_support import environment
from certify_nonideal_pentagon_pose_library import verify

def compare_exterior(bodies, physical, family, env, w, e, domains, rw, re):
    base, _ = pentagon(env, cf.W, cf.E, *cf.QA, 'X')
    centers = {x.label: x for x in base}
    jets = cf.vertex_jets(env, w, e)
    fields = {x.label: [pose(jet[env['sector'][int(x.label.split(':')[1])][0]], A(240), -1)
                        for jet in jets] for x in family}
    old = bodies + physical
    counts = {'height': 0, 'hex_derivative': 0, 'corner': 0}
    margins = []
    def settle(l, r, level=0):
        a, b = A(l), A(r)
        mid = (a+b)/2
        u = direction(mid)
        un = direction(a.union(b))
        candidates = possible(family, a, b)
        assert candidates
        groups = [possible(row, a, b) for row in old]
        ranking = sorted(range(len(old)),key=lambda k:max(x.height(u).mid() for x in possible(old[k],mid,mid)),reverse=True)
        for k in ranking:
            gr = groups[k]
            bounds = []
            for target in candidates:
                projected = [dot(v, un) for v in fields[target.label]]
                err = A(rw)*abs(projected[0]).upper()+A(re)*abs(projected[1]).upper()
                for term in gr:
                    interval = intersect(a.lower(), b.upper(), term, target)
                    if interval:
                        bounds.append(gap(term,centers[target.label],*interval).lower()-err)
            assert bounds
            margin = min(z.lower() for z in bounds)
            if margin > 0:
                margins.append(margin)
                counts['height'] += 1
                return
        # The same attaining corner dominates whenever both parameter derivatives keep
        # the signs proved on the central window; the active sector must be common.
        if len({x.label for x in candidates}) == 1:
            q = candidates[0]
            dw, de = (dot(v, un) for v in fields[q.label])
            if dw < 0 and de > 0:
                counts['corner'] += 1
                return
        # All diameter-one old bodies contained in H have support 1/2 at its six
        # normals. Integrate derivative differences outward from that common value.
        pin = 60*round((l+r)/120)
        if min(abs(l-pin), abs(r-pin)) < 3 and (r<=pin or pin<=l):
            side = 1 if pin<=l else -1
            aa, bb = A(min(F(pin),l)), A(max(F(pin),r))
            nslices = possible(family,aa,bb)
            for k in ranking:
                if k>=len(bodies):continue
                oslices = possible(old[k],aa,bb)
                try:
                    signs=[increasing_difference(x,y,*iv) if side==1 else increasing_difference(y,x,*iv)
                           for x in oslices for y in nslices if (iv:=intersect(aa.lower(),bb.upper(),x,y))]
                except AssertionError:continue
                assert signs and min(signs)>0
                endpoint=A(pin)
                assert all((x.height(direction(endpoint))-A('1/2')).contains(0)
                           for x in possible(old[k],endpoint,endpoint)+possible(family,endpoint,endpoint))
                counts['hex_derivative'] += 1
                return
        if level==8: raise ValueError(f'no shared exterior/corner witness on {l}, {r}')
        m=(l+r)/2
        settle(l,m,level+1)
        settle(m,r,level+1)
    for l,r in domains:
        n=int((r-l)//F(1,2))+1
        for j in range(n):settle(l+(r-l)*F(j,n),l+(r-l)*F(j+1,n))
    return dict(cells=counts,minimum_directed_height_gap=str(min(margins)))

def run(rw, re, out):
    cf.W, cf.E = F('1.2'), F('.08464386')
    cf.RW, cf.RE = rw, re
    cf.WINDOW = (F('112.31'), F('115.57'))
    ctx.prec = 192
    env = environment(str(comp), '1.5497')
    ctx.prec = 192
    w = env['box'](cf.W-rw, cf.W+rw)
    e = env['box'](cf.E-re, cf.E+re)
    family, _ = pentagon(env, w, e, *cf.QA, 'X')
    corner, derivatives = cf.family_corner(env, family, w, e)
    print('corner', corner, flush=True)
    bodies, _, core = load(comp)
    oldcorner, _ = pentagon(env, F('.7982906999'), F('.03268800001'), *cf.QA, 'corner151')
    bodies.append(oldcorner)
    physical, _, _ = visible_parts(core)
    _, endpoints = settle_hex_normals(bodies, family)
    delta = F(1,100)
    left, right = cf.WINDOW
    domain = [(delta,60-delta),(60+delta,left),(right,120-delta)]
    domain.extend((j+delta,j+60-delta) for j in (120,180,240,300))
    exterior = compare_exterior(bodies, physical, family, env, w, e, domain, rw, re)
    capmargins = []
    for k in (3, 5):
        angle = A(30+60*k) + A('1.5497')
        normal = env['av'](env['d']['m'][k])
        margin = min((A('1/2')-arc.height(normal)).lower() for arc in possible(family, angle, angle))
        assert margin>0
        capmargins.append(str(margin))
    result = dict(center=list(map(str,(cf.W,cf.E))),radii=list(map(str,(rw,re))),corner=list(map(str,corner)),
                  derivative_certificate=derivatives,exterior=exterior,pins=endpoints,caps=capmargins,
                  interval_precision=ctx.prec)
    out.write_text(json.dumps(result, indent=2)+'\n')
    print('complete', exterior, capmargins, flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('rw',type=F)
    p.add_argument('re',type=F)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    run(a.rw,a.re,a.output)

from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'frozen'),str(D/'frozen/computation')]
from local_support import A,Arc,add,sub,angle,arc,periodize,load,pentagon,direction,dot
from deformed_reuleaux_support import body,environment
from verify_geometry import preclip_core,visible_parts,prove_exterior,possible,gap,perp
ctx.prec=192;old,_,core=load(D/'frozen/computation');ns=environment(str(D/'frozen/computation'),'1.5497');ctx.prec=192
coremat,_,_=visible_parts(core)
v,_=body(ns,F('1.19999'),F('.08464486'));edges=[sub(v[i],v[j]) for i,j in ns['orders']];u0=(arb(1),arb(0));angles=[angle(n) for n in edges]
for i in range(1,len(angles)):
 while angles[i]<angles[i-1]: angles[i]+=360
angles.append(angles[0]+360)
roots=json.loads((D/'large-result.json').read_text())['root_brackets'][1:];out=[]
for r in roots:
 t=ns['box'](*map(F,r))
 for k,hand in ((0,1),(180,-1)):
  def h(a):return ns['supports'](v,edges,ns['trig'](a*hand-k+t),u0,False)
  tx=A('.5')-h(arb(0));ty=(2*(A('.5')-h(arb(120)))+tx)/arb(3).sqrt();tpose=A(k)-t
  arcs=[arc(f'P:{i}',angles[i],angles[i+1],v[c],arb(rad),tpose,hand) for i,(c,rad) in enumerate(ns['sector'])]
  arcs=periodize([Arc(x.label,x.lo,x.hi,add(x.center,(tx,ty)),x.rho) for x in arcs]);band=F('0.001');domains=[(F(j)+band,F(j+60)-band) for j in range(0,360,60)]
  # Each named material point below lies exactly on the specified regular
  # hexagon face by line-pair, orthogonal projection, or line intersection.
  anchors={0:('core:B1','core:C3'),60:('core:B1','core:Q'),120:('core:P','core:F1'),180:('core:F1','core:H'),240:('core:E3','core:D1'),300:('core:D1','core:G')}
  results=[]
  for face in range(0,360,60):
   u=direction(A(face)); candidates=[p for b in coremat for p in b if (dot(p.center,u)-A('.5')).contains(0)]
   assert {p.label for p in candidates}==set(anchors[face]),(face,'unexpected face points')
   for side in (-1,1):
    a=F(face) if side==1 else F(face)-band; b=F(face)+band if side==1 else F(face)
    # Domains crossing 0 are compared at 360, because arcs are periodized to [0,360].
    if a<0:a+=360;b+=360
    fn=F(face) if face or side==1 else F(360)
    tests=[]
    active=possible(arcs,A(a),A(b)); assert len(active)==1
    for p in active:
     assert p.lo.upper()<=A(a).lower() and p.hi.lower()>=A(b).upper(),(face,side,p.label)
     anchor=A(fn); assert p.lo.lower()<=anchor<=p.hi.upper() and (p.height(direction(anchor))-A('.5')).contains(0),(face,side,p.label)
     viable=[]
     for q in candidates:
      derivative=gap(Arc('derivative',arb(0),arb(360),perp(sub(q.center,p.center)),arb(0)),Arc('zero',arb(0),arb(360),(arb(0),arb(0)),arb(0)),A(a).lower(),A(b).upper())
      if (side==1 and derivative>0) or (side==-1 and derivative<0): viable.append((q.label,str(derivative)))
     if not viable: print('fail face',r,k,hand,face,side,p.label,'host',[q.label for q in candidates],flush=True)
     tests.append(dict(candidate=p.label,witnesses=viable))
    results.append(dict(face=face,side=side,candidate_anchors=[q.label for q in candidates],tests=tests,passed=bool(tests) and all(z['witnesses'] for z in tests)))
  case=dict(source_root_sha=__import__('hashlib').sha256((D/'large-result.json').read_bytes()).hexdigest(),root=r,turn=k,hand=hand,all_passed=all(x['passed'] for x in results),face_tests=results)
  out.append(case);print('case',r,k,hand,'faces',sum(x['passed'] for x in results),'/',len(results),flush=True)
(D/'boundary-v4.json').write_text(json.dumps(out,indent=2)+'\n')

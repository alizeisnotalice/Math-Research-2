"""Verify every hexagon-compatible placement, including shifted nonzero roots."""
import argparse
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from flint import arb, ctx, __version__ as flint_version

SOURCE_SHA = "d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf"
RETAINED = ((".7982906999", ".03268800001"), ("1.2", ".08464386"))


def run(comp, spec):
    from deformed_reuleaux_support import body, environment
    from local_support import A, add, direction, dot, load, pentagon, rot, sub
    from verify_geometry import cross, possible, preclip_core, visible_parts

    ctx.prec = 192
    earlier, _, core = load(comp)
    ns = environment(str(comp), "1.5497")
    ctx.prec = 192
    additions = [pentagon(ns,*map(F,p),240,-1,"D"+str(i))[0] for i,p in enumerate(RETAINED)]
    host = [p for row in earlier+additions for p in row] + preclip_core(core)

    spec_point = tuple(map(F,spec["input"]))
    verts, _ = body(ns,*spec_point)
    edges = [sub(verts[i],verts[j]) for i,j in ns["orders"]]
    # Width one is the exact Reuleaux-pentagon construction. This verifies
    # the construction's strictly ordered unit-circle arc and vertex normals.
    assert all(ns["cross"](edges[i],edges[(i+1)%10])>0 for i in range(10))
    u0=(arb(1),arb(0))
    rad_per_degree=arb.pi()/180
    box=ns["box"]

    def h(angle, derivative=False):
        return ns["supports"](verts,edges,ns["trig"](angle),u0,derivative)

    def comp_h(q, derivative=False):
        v=h(q,derivative)-h(q+60,derivative)+h(q+120,derivative)
        return v * rad_per_degree if derivative else v - A(".5")

    @cache
    def value(t):
        return comp_h(A(t))

    sign = lambda x: 1 if x>0 else -1 if x<0 else 0
    # The chosen five-arc shape is in the same analytic pin chart.
    for k,i in enumerate((1,3,0)):
        d=ns["av"](ns["d"]["n"][k])
        u=(-d[0],-d[1])
        picks=[j for j,v in enumerate(edges) if ns["cross"](v,u)>0 and ns["cross"](u,edges[(j+1)%10])>0]
        assert len(picks)==1 and tuple(ns["sector"][picks[0]])==(i,0)
        assert dot(verts[i],u).contains(A(".5"))
    eps=F(".01")
    for _ in range(35):
        lo_deriv=comp_h(box(F(0),eps),True)
        hi_deriv=comp_h(box(60-eps,F(60)),True)
        if sign(lo_deriv) and sign(hi_deriv): break
        eps/=2
    assert sign(lo_deriv) and sign(hi_deriv)
    print("endpoint sector radius",str(eps),flush=True)
    leaves=[(F(0),eps,"exact pinned root and monotonic",lo_deriv)]
    roots=[(F(0),F(0))]

    def cover(a,b,depth):
        interval=box(a,b)
        whole=comp_h(interval)
        if sign(whole):
            leaves.append((a,b,"sign",whole))
            return
        derivative=comp_h(interval,True)
        if sign(derivative):
            s1,s2=sign(value(a)),sign(value(b))
            assert s1 and s2,(a,b,str(value(a)),str(value(b)))
            if s1==s2:
                leaves.append((a,b,"monotonic",derivative))
                return
            x,y=a,b
            while y-x>F("1e-18"):
                t=(x+y)/2
                s=sign(value(t))
                assert s,(t,str(value(t)))
                if s==s1:
                    x=t
                else:
                    y=t
            assert sign(value(x))*sign(value(y))==-1
            assert sign(derivative)==sign(value(y))
            roots.append((x,y))
            leaves.append((a,b,"unique sign-changing",derivative))
            return
        assert depth<32,(a,b,str(whole),str(derivative))
        mid=(a+b)/2
        cover(a,mid,depth+1)
        cover(mid,b,depth+1)

    for k in range(120):
        cover(eps+(60-2*eps)*F(k,120),eps+(60-2*eps)*F(k+1,120),0)
    leaves.append((60-eps,F(60),"same exact pinned root modulo 60 and monotonic",hi_deriv))
    assert leaves[0][0]==0 and leaves[-1][1]==60
    assert all(l[1]==r[0] for l,r in zip(leaves,leaves[1:]))
    assert roots
    assert len(roots)==len({x for x,y in roots})
    print("roots",[(float(x),float(y)) for x,y in roots],flush=True)

    # Certify an origin-centered quarter disk inside the host. Each vertex is
    # genuine clipped-core material. The oriented supporting lines of a triangle
    # are at least a quarter unit from its center.
    art,_,_=visible_parts(core)
    disk=None
    radius=A("1/4")
    for row in combinations([q for ps in art for q in ps],3):
        cyc=list(row)
        if cross(sub(cyc[1].center,cyc[0].center),sub(cyc[2].center,cyc[0].center))<0:
            cyc[1],cyc[2]=cyc[2],cyc[1]
        tests=[]
        for p,q in zip(cyc,cyc[1:]+cyc[:1]):
            edge=sub(q.center,p.center)
            tests.append(cross(p.center,q.center)/dot(edge,edge).sqrt()-radius)
        if all(t>0 for t in tests):
            disk=[p.label for p in cyc],str(min(t.lower() for t in tests))
            break
    assert disk

    def upper_at(angle):
        a=A(angle)
        u=direction(a)
        return (a,u,*max((p.height(u).upper(),p.label) for p in possible(host,a,a)))

    dirs=[upper_at(F(i,4)) for i in range(1440)]
    dirs+=[upper_at(F(p)) for p in spec["support_probes"]]
    dirs+=[(A(p),direction(A(p)),A(".5"),"original_cap") for p in ("211.5497","331.5497")]
    base=A(spec["base_lower"])
    target=A(spec["B"])
    assert base<target
    print("support scan",len(dirs),flush=True)
    rows=[]
    for x,y in roots:
        t=box(x,y)
        for k in range(0,360,60):
            for hand in (1,-1):
                inv=lambda a: h(a*hand-k+t)
                tx=A(".5")-inv(arb(0))
                ty=(2*(A(".5")-inv(arb(120)))+tx)/arb(3).sqrt()
                best=None
                for a,u,b,label in dirs:
                    height=inv(a)+dot((tx,ty),u)
                    delta=height.lower()-b
                    if delta <= 0:
                        continue
                    # The hull of a support tip and a perpendicular diameter of
                    # the quarter disk forms a triangle. Cutting above the
                    # host-support line leaves a homothetic triangle.
                    area=radius*delta**2/height.upper()
                    if best is None or area.lower()>best[0]:
                        best=(area.lower(),a,delta,height,b,label)
                if best is None:
                    rows.append(dict(root=[str(x),str(y)],turn=k,reflection=hand,
                                     separated=False,translation=[str(tx),str(ty)]))
                    continue
                area,a,delta,height,b,label=best
                rows.append(dict(root=[str(x),str(y)],turn=k,reflection=hand,separated=True,
                                 translation=[str(tx),str(ty)],angle=str(a),height=str(height),
                                 host_upper=str(b),host_feature=label,gap_lower=str(delta),
                                 area_gain_lower=str(area),overshoots_B_with_original_H=base+area>target))
    return dict(geometry="all H-compatible rigid placements relative to fixed D152",
                validated_inputs=list(map(str,spec_point)),source_zip_sha=SOURCE_SHA,
                root_brackets=[[str(a),str(b)] for a,b in roots],root_leaf_count=len(leaves),
                closed_root_partition=[[str(a),str(b),typ,str(m)] for a,b,typ,m in leaves],
                elliptic_disk=dict(radius="1/4",core_triangle=disk[0],edge_margin=disk[1]),
                exact_hex_faces="Opposite width-one supports force equality; 0 and 120 degrees solve translation",
                source_for_D_E_area_lower="Frozen R253 result.json, closed_box.total_area_strict[0]",
                base_lower=spec["base_lower"],B=spec["B"],poses=rows,
                every_pose_separated=all(r["separated"] for r in rows),
                every_pose_in_original_H_overshoots_B=all(r.get("overshoots_B_with_original_H",False) for r in rows))


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ("source_zip","input","output","work"):
        ap.add_argument(name,type=Path)
    args=ap.parse_args()
    if not __debug__:
        raise SystemExit("Assertions must be enabled.")
    assert sha256(args.source_zip.read_bytes()).hexdigest()==SOURCE_SHA
    with TemporaryDirectory(dir=args.work.resolve()) as work:
        frozen=Path(work)
        with ZipFile(args.source_zip) as z:
            z.extractall(frozen)
        comp=frozen/"computation"
        sys.path[:0]=[str(frozen),str(comp)]
        spec=json.loads(args.input.read_bytes())
        family=json.loads((frozen/"family.json").read_bytes())
        assert F(spec["base_lower"])<=F(family["total_area_strict_fractions"][0])
        result=run(comp,spec)
    result.update(input_sha=sha256(args.input.read_bytes()).hexdigest(),
                  verifier_sha=sha256(Path(__file__).read_bytes()).hexdigest(),
                  precision=ctx.prec,python=sys.version.split()[0],flint=flint_version)
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print([(r["turn"],r["reflection"],r.get("gap_lower"),r.get("area_gain_lower"))
           for r in result["poses"]],flush=True)

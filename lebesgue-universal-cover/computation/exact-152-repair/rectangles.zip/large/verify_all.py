"""Replay the large Q-family and the four DE-contained nonzero-root poses."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from zipfile import ZipFile
import argparse,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('work',type=Path);a=p.parse_args();D=a.work.resolve();assert not D.exists();D.mkdir(parents=True)
def sha(p):return sha256(p.read_bytes()).hexdigest()
assert sha(P/'true-boundary.zip')=='d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf'
assert sha(P/'r253-result.json')=='4559a4ee0d924fefe5b22399d8c854409af1b29bbecd0cb88c58f19f23e9c0e1'
with ZipFile(P/'true-boundary.zip') as z:z.extractall(D/'frozen')
fam=json.loads((D/'frozen/family.json').read_text());r253=json.loads((P/'r253-result.json').read_text());assert list(map(F,fam['total_area_strict_fractions']))==list(map(F,r253['closed_box']['total_area_strict']))
for name in ('true-boundary.zip','r253-result.json','large.json','certify_corner.py','containment_DE.py','boundary_cert_v4.py','corner_exterior.py','corner_exact_large.py'):shutil.copyfile(P/name,D/name)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def run(name,args):
 with (D/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-E','-B',*args],cwd=D,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
def same(actual,expected):
 assert json.loads((D/actual).read_text())==json.loads((P/expected).read_text()),(actual,'mismatch');return sha(D/actual)
h={}
run('large-roots',['certify_corner.py','true-boundary.zip','large.json','large-result.json','.']);h['large-result.json']=same('large-result.json','large-result.json')
run('large-containment',['containment_DE.py']);h['containment-DE.json']=same('containment-DE.json','containment-DE.json')
run('large-boundary',['boundary_cert_v4.py']);h['boundary-v4.json']=same('boundary-v4.json','boundary-v4.json')
run('large-family',['corner_exterior.py','1/100000','1/1000000','whole-large.json']);h['whole-large.json']=same('whole-large.json','whole152-large.json')
run('large-exact',['corner_exact_large.py']);h['corner-exact-large.json']=same('corner-exact-large.json','corner-exact-large.json')
roots=json.loads((D/'large-result.json').read_text());interior=json.loads((D/'containment-DE.json').read_text());boundary=json.loads((D/'boundary-v4.json').read_text());whole=json.loads((D/'whole-large.json').read_text());area=json.loads((D/'corner-exact-large.json').read_text())
assert len(roots['root_brackets'])==3 and len(interior)==len(boundary)==4 and all(x['complete'] for x in interior) and all(x['all_passed'] for x in boundary)
assert whole['radii']==['1/100000','1/1000000'] and whole['corner']==['119999/100000','4232243/50000000']
assert 0<F(area['strict_increment'][0])<F(area['strict_increment'][1])
result={'complete':True,'scope':'large rectangle Q family; 4 nonzero-root corner placements contained in DE, modulo exact six-face anchoring lemma','r253_archive_sha256':sha(P/'true-boundary.zip'),'replayed':h,'Q_increment':area['strict_increment'],'corner_optimized_increment':'0'}
(D/'verify-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)

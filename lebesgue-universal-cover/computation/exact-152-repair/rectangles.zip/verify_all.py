"""Single-entry replay for large and small P152 rectangles, with isolated outputs."""
from pathlib import Path
from hashlib import sha256
import argparse,json,os,subprocess,sys
P=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('work',type=Path);a=p.parse_args();D=a.work.resolve();assert not D.exists();D.mkdir(parents=True)
for line in (P/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);f=P/name;assert f.is_file() and sha256(f.read_bytes()).hexdigest()==h,name
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for name in ('large','small'):
 with (D/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-I','-B',str(P/name/'verify_all.py'),str(D/name)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
results={name:json.loads((D/name/'verify-summary.json').read_text()) for name in ('large','small')};assert all(x['complete'] for x in results.values());(D/'verify-summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2),flush=True)

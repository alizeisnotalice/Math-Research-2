"""Small corner: exact zero-root placements versus the two old cap chords."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
W=Path(__file__).resolve().parent;C=W/'frozen/computation';sys.path[:0]=[str(W/'frozen'),str(C)]
from local_support import A,angle,core_vertices,dot,load,sub
from deformed_reuleaux_support import environment,body
ctx.prec=192;old,_,core=load(C);n=environment(str(C),'1.5497');ctx.prec=192
labels,pts,_=core_vertices(core);base=json.loads((W/'r253-result.json').read_text());cutoff=F('.844082046521218581802948589770767704354')-F(base['closed_box']['total_area_strict'][0]);caps=[]
for idx,ends in ((3,('I','E3')),(5,('K','C3'))):
 normal=n['av'](n['d']['m'][idx]); p,q=[pts[labels.index(t)] for t in ends];assert all((dot(v,normal)-A('.5')).contains(0) for v in (p,q)); margin=min((l-dot(m,v)).lower() for _,m,l in core['otherEH'] for v in (p,q));assert margin>0;d=sub(q,p);length=dot(d,d).sqrt();assert length>A('.2535');caps.append((idx,normal,length,ends,margin))
v,_=body(n,F('1.19999994'),F('.084643866'));edges=[sub(v[i],v[j]) for i,j in n['orders']];u0=(arb(1),arb(0)); rows=[]
for k in range(0,360,60):
 for hand in (1,-1):
  def h(a):return n['supports'](v,edges,n['trig'](a*hand-k),u0,False)
  tx=A('.5')-h(arb(0));ty=(2*(A('.5')-h(arb(120)))+tx)/arb(3).sqrt();values=[]
  for i,normal,length,ends,margin in caps:
   gap=h(angle(normal))+dot((tx,ty),normal)-A('.5');values.append(dict(cap=i,gap=str(gap),area_lower=str((length*gap/2).lower())))
  vals=[arb(x['area_lower']) for x in values];win=max(vals);rows.append(dict(turn=k,hand=hand,caps=values,cap_overshoots=bool(win>A(cutoff))))
identity=json.loads((W/'corner-identity-small.json').read_text());assert arb(identity['atomic_lower'])>A(cutoff)
for row in rows:
 if (row['turn'],row['hand']) not in [(0,1),(240,-1)]:assert row['cap_overshoots'],row
 if (row['turn'],row['hand'])==(0,1):row['identity_atomic_lower']=identity['atomic_lower'];row['identity_overshoots']=True
 if (row['turn'],row['hand'])==(240,-1):row['role']='Q candidate'
out={'scope':'small corner zero-root poses relative to DE; actual caps serve only as DE chord witnesses','budget_upper':str(cutoff),'cap_data':[{'cap':i,'endpoints':ends,'length':str(length),'core_margin':str(margin)} for i,normal,length,ends,margin in caps], 'poses':rows,'identity_sha256':sha256((W/'corner-identity-small.json').read_bytes()).hexdigest()};(W/'small-12-area.json').write_text(json.dumps(out,indent=2)+'\n');print('all 10 cap + identity exceed budget; Q remains',flush=True)

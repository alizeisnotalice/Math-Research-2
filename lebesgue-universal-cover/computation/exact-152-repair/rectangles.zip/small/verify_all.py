"""Replay small-box containment, roots, area ordering, and non-Q cap witnesses."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from zipfile import ZipFile
import argparse,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('work',type=Path);a=p.parse_args();D=a.work.resolve();assert not D.exists();D.mkdir(parents=True)
def sha(p):return sha256(p.read_bytes()).hexdigest()
assert sha(P/'true-boundary.zip')=='d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf'
assert sha(P/'r253-result.json')=='4559a4ee0d924fefe5b22399d8c854409af1b29bbecd0cb88c58f19f23e9c0e1'
with ZipFile(P/'true-boundary.zip') as z:z.extractall(D/'frozen')
fam=json.loads((D/'frozen/family.json').read_text());r253=json.loads((P/'r253-result.json').read_text());assert list(map(F,fam['total_area_strict_fractions']))==list(map(F,r253['closed_box']['total_area_strict']))
files=('true-boundary.zip','r253-result.json','small.json','certify_corner.py','corner_exterior.py','corner_exact_small.py','corner_identity_small.py','small_12_area.py')
for name in files:shutil.copyfile(P/name,D/name)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def run(name,args):
 with (D/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-E','-B',*args],cwd=D,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
def same(actual,expected):
 x=json.loads((D/actual).read_text());y=json.loads((P/expected).read_text());assert x==y,(actual,'mismatch');return sha(D/actual)
hashes={}
run('small-roots',['certify_corner.py','true-boundary.zip','small.json','small-result.json','.']);hashes['small-result.json']=same('small-result.json','small-result.json')
run('small-family',['corner_exterior.py','3/50000000','3/500000000','whole-small.json']);hashes['whole-small.json']=same('whole-small.json','whole152-small.json')
run('small-exact',['corner_exact_small.py']);hashes['corner-exact-small.json']=same('corner-exact-small.json','corner-exact-small.json')
run('small-identity',['corner_identity_small.py']);hashes['corner-identity-small.json']=same('corner-identity-small.json','corner-identity-small.json')
run('small-12',['small_12_area.py']);hashes['small-12-area.json']=same('small-12-area.json','small-12-area.json')
small=json.loads((D/'small-result.json').read_text());area=json.loads((D/'corner-exact-small.json').read_text());whole=json.loads((D/'whole-small.json').read_text());caps=json.loads((D/'small-12-area.json').read_text())
assert small['root_brackets']==[['0','0']] and len(small['poses'])==12 and all(x['separated'] for x in small['poses'])
assert whole['radii']==['3/50000000','3/500000000'] and whole['corner']==['59999997/50000000','42321933/500000000']
assert all(x['cap_overshoots'] or x.get('identity_overshoots') or x.get('role')=='Q candidate' for x in caps['poses'])
assert 0<F(area['strict_increment'][0])<F(area['strict_increment'][1])<F(caps['budget_upper'])
result={'complete':True,'scope':'small rectangle Q family enclosure and exact corner area; all 11 non-Q corner poses exceed B; Q corner excluded from DE','r253_archive_sha256':sha(P/'true-boundary.zip'),'r253_result_sha256':sha(P/'r253-result.json'),'replayed':hashes,'Q_increment':area['strict_increment'],'budget_upper':caps['budget_upper']}
(D/'verify-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)

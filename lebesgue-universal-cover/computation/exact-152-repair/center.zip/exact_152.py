"""True support-envelope area increment of QP152 over the R253 D_E host."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,platform
from flint import arb,ctx,__version__
W=Path(__file__).resolve().parent;FRO=W/'frozen';C=FRO/'computation';sys.path[:0]=[str(FRO),str(C)]
from local_support import load,pentagon,A,direction,dot,sub
from verify_geometry import preclip_core,intersect,strictly_above,with_touch,bracketed_intersection,green_delta,perp
from deformed_reuleaux_support import environment
from certify_increment import decimal_outward
ctx.prec=192;bodies,_,core=load(C);n=environment(str(C),'1.5497');ctx.prec=192
corner,_=pentagon(n,F('.7982906999'),F('.03268800001'),240,-1,'corner151');new,_=pentagon(n,F('1.2'),F('.08464386'),240,-1,'Z');a,b=A('112.31'),A('115.57')
labels=['118:3:-1:1','corner151:0','113:0','112:0'];allold=[p for body in bodies for p in body]+corner+preclip_core(core);selected=[]
for label in labels:
 matches=[p for p in allold if p.label==label and p.lo<a and p.hi>b];
 if not matches:matches=[p for p in allold if p.label==label and not(p.lo>b or p.hi<a)]
 assert len(matches)==1,(label,len(matches));selected.append(matches[0])
x,=[q for q in new if q.label=='Z:0' and q.lo<a and q.hi>b]
switches=[bracketed_intersection(p,q,l,r) for (p,q),(l,r) in zip(zip(selected,selected[1:]), [('112.327','112.328'),('115.24','115.25'),('115.50','115.54')],strict=True)]
L=bracketed_intersection(selected[0],x,'112.32','112.328');R=bracketed_intersection(selected[-1],x,'115.54','115.57');assert a<L<switches[0]<switches[1]<switches[2]<R<b
zones=list(zip([a,*switches],[*switches,b],strict=True));margins=[];touching=[]
for i,(p,(l,r)) in enumerate(zip(selected,zones,strict=True)):
 assert p.lo<l and r<p.hi; margin=arb(1);checks=0
 for q in allold:
  if q.label==p.label:continue
  overlap=intersect(l.lower(),r.upper(),q)
  if not overlap:continue
  if i and q.label==selected[i-1].label:
   d,k,sl=with_touch(p,q,*overlap,switches[i-1],True);touching.append(str(sl))
  elif i<len(selected)-1 and q.label==selected[i+1].label:
   d,k,sl=with_touch(p,q,*overlap,switches[i],False);touching.append(str(sl))
  else:d,k=strictly_above(p,q,*overlap)
  margin=min(margin,d);checks+=k
 margins.append({'piece':p.label,'strict_margin':str(margin),'intervals':checks});print('envelope',p.label,checks,margin,flush=True)
_,_,dl=with_touch(selected[0],x,a.lower(),L.upper(),L,False)
with_touch(x,selected[0],L.lower(),switches[0].upper(),L,True)
with_touch(x,selected[-1],switches[-1].lower(),R.upper(),R,False)
_,_,dr=with_touch(selected[-1],x,R.lower(),b.upper(),R,True)
for p,l,r in zip(selected[1:-1],switches[:-1],switches[1:],strict=True):strictly_above(x,p,l.lower(),r.upper())
integ=[]
for p,l,r in zip(selected,[L,*switches],[*switches,R],strict=True):
 ca,sa=direction(l);cb,sb=direction(r);d=sub(x.center,p.center)
 value=(x.rho+p.rho)*(dot(d,(sb-sa,ca-cb))+(x.rho-p.rho)*(r-l)*arb.pi()/180)/2
 assert value>=0;integ.append(value)
atoms=[]
for p,q,t in zip(selected[:-1],selected[1:],switches,strict=True):
 u=direction(t);length=dot(sub(q.center,p.center),perp(u));f=x.height(u)-p.height(u);assert length>0 and f>0
 atoms.append({'angle':str(t),'length':str(length),'gap':str(f),'area':str(f*length/2)})
val=sum(integ)+sum(arb(row['area']) for row in atoms)
green=green_delta(x,selected,[L,*switches,R]);assert val.overlaps(green) and abs(val-green)<A('1e-30')
ends=decimal_outward(val.lower(),val.upper(),39);print('increment',ends,'green',green,flush=True)
result={'scope':'Q P152 fixed pose over D_E; global exterior inherited from bound-152.json and frozen R253','python':platform.python_version(),'flint':__version__,'precision_bits':ctx.prec,'local_window_degrees':['112.31','115.57'],'exposure_roots_degrees':[str(L),str(R)],'old_pieces':labels,'old_switches_degrees':list(map(str,switches)),'old_envelope':margins,'touch_derivatives':touching,'exposure_slopes':[str(dl),str(dr)],'arc_contributions':list(map(str,integ)),'atoms':atoms,'independent_green':str(green),'strict_increment':ends}
(W/'exact-152.json').write_text(json.dumps(result,indent=2)+'\n')

#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
int main(int argc,char **argv){@autoreleasepool{
 if(argc!=3)return 2;NSString *dir=[NSString stringWithUTF8String:argv[1]]; uint32_t N=std::stoul(argv[2]);
 id<MTLDevice> dev=MTLCreateSystemDefaultDevice();if(!dev){std::cerr<<"No Metal device\n";return 3;}
 NSError *err=nil;NSString *source=[NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:@"screen.metal"] encoding:NSUTF8StringEncoding error:&err];MTLCompileOptions* opts=[MTLCompileOptions new];opts.fastMathEnabled=NO;
 id<MTLLibrary> lib=[dev newLibraryWithSource:source options:opts error:&err];if(!lib){NSLog(@"%@",err);return 4;}id<MTLComputePipelineState> pipe=[dev newComputePipelineStateWithFunction:[lib newFunctionWithName:@"scan"] error:&err];if(!pipe){NSLog(@"%@",err);return 5;}
 auto load=[&](NSString* name)->id<MTLBuffer>{NSData* d=[NSData dataWithContentsOfFile:[dir stringByAppendingPathComponent:name]];if(!d)return nil;return [dev newBufferWithBytes:d.bytes length:d.length options:MTLResourceStorageModeShared];};
 id<MTLBuffer> old=load(@"old.bin"),oi=load(@"old-offset.bin"); if(!old||!oi)return 6;auto queue=[dev newCommandQueue];double total=0;
 std::cerr<<"device="<<dev.name.UTF8String<<" samples_per_variant="<<N<<" variants=10\n";
 for(int i=0;i<10;i++){@autoreleasepool {NSString* a=[NSString stringWithFormat:@"new%d.bin",i];NSString* b=[NSString stringWithFormat:@"new%d-offset.bin",i];id<MTLBuffer> x=load(a),idx=load(b),out=[dev newBufferWithLength:N*4*sizeof(float) options:MTLResourceStorageModeShared];if(!x||!idx||!out)return 7;
 auto cb=[queue commandBuffer];auto en=[cb computeCommandEncoder];[en setComputePipelineState:pipe];[en setBuffer:old offset:0 atIndex:0];[en setBuffer:oi offset:0 atIndex:1];[en setBuffer:x offset:0 atIndex:2];[en setBuffer:idx offset:0 atIndex:3];[en setBuffer:out offset:0 atIndex:4];[en setBytes:&N length:sizeof(N) atIndex:5];[en dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[en endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted){NSLog(@"%@",cb.error);return 8;}double t=cb.GPUEndTime-cb.GPUStartTime;if(!(t>0))return 9;total+=t;NSString* fn=[dir stringByAppendingPathComponent:[NSString stringWithFormat:@"screen-%d.bin",i]];std::ofstream file(fn.UTF8String,std::ios::binary);file.write((char*)out.contents,N*4*sizeof(float));std::cerr<<"variant="<<i<<" gpu_seconds="<<std::setprecision(17)<<t<<"\n";
 }}std::cerr<<"GPU seconds="<<total<<"\n";return 0;
}}

from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
W=Path(__file__).resolve().parent;FRO=W/'frozen';C=FRO/'computation';sys.path[:0]=[str(FRO),str(C)]
from local_support import A,pentagon
from deformed_reuleaux_support import environment,body
from certify_family import vertex_jets
ctx.prec=192;ns=environment(str(C),'1.5497');ctx.prec=192
w,e=F('1.2'),F('.08464386');rw,re=F('6e-8'),F('6e-9');wb=ns['box'](w-rw,w+rw);eb=ns['box'](e-re,e+re)
v,_=body(ns,wb,eb);dw,de=vertex_jets(ns,wb,eb)
def bound(v):return max((abs(x).upper()+abs(y).upper()).upper() for x,y in v)
Mw,Me=bound(dw),bound(de);print('derivative norm1 bounds',Mw,Me,flush=True);assert Mw<A('.22') and Me<A('1.37')
# For each fixed normal the support branch is either a marked vertex or a unit-circle arc centered at one, with continuous joins. Thus the entire Q body moves by <= epsilon in Hausdorff distance.
epsilon=F('.22')*rw+F('1.37')*re
extra=4*epsilon+4*epsilon**2
orig=json.loads((W/'r253-result.json').read_bytes()); base=json.loads((C/'single-repair'/'single-repair.json').read_bytes()); B=F(base['B']); prior=F(orig['closed_box']['total_area_strict'][1]); add=F(json.loads((W/'exact-152.json').read_bytes())['strict_increment'][1]);margin=B-prior-add-extra;assert margin>F('1e-8')
r={'center_w':str(w),'center_e':str(e),'closed_radii':[str(rw),str(re)],'pose':[240,-1], 'maximum_vertex_derivative_l1':{'w':str(Mw),'e':str(Me)},'derivative_simple_bounds':['.22','1.37'],'epsilon':str(epsilon),'diameter_perimeter_upper':'4','dilation_area_upper':str(extra),'remaining_B_margin_strict_lower':str(margin),'scope':'All inputs in the closed box are contained with the same Q pose in D152 + epsilon disk; derivative bounds and continuous sector joins needed.'};(W/'neighborhood.json').write_text(json.dumps(r,indent=2)+'\n');print('remaining strict lower',float(margin),flush=True)

# R253 host and the 152nd five-arc input

Let `D_E` be the published R253 host for the 151st closed family. Let `Z=P(6/5,.08464386)`, in the old σ=1.5497° coordinates, and `Q` be 240° rotation followed by reflection in the x-axis. The explicit host is

    D_152 = conv(C_150 ∪ QP(.7982906999,.03268800001) ∪ QZ).

All displayed poses have zero translation. The newly certified area increase lies in the strict interval

    (0.000000003721652952651306201470860014307,
     0.000000003721652952651306201470860080259).

When the host must retain `D_E` and lie in the old hexagon and two caps, R253 reduces Z to identity or Q. `identity_atom.py` checks that the old 118-to-151-corner exposed tangent alone contributes >.000000107519925560170559249951 for identity, exceeding its maximum available B budget <.00000010370495796962184. For Q, the above increment is below budget. Thus the Q construction is the unique minimum-area host in this constrained class. This does not claim that it is a universal cover.

## Exact increment

`exact_152.py` reconstructs the true support pieces, checks all old source pieces and the preclip outer body, and certifies the old envelope 118 → 151 corner → 113 → 112 on [112.31°,115.57°]. The new body contributes a single vertex between its certified exposure roots. It evaluates the arc contributions and the three tangent atoms of `2Δ=∫(h_Z−h_D)_+ d(S_D+S_Z)` and independently checks the same quantity by the Green boundary formula. Strict interval comparisons cover all competitors, including one-sided tangent crossings.

The exterior is proved in `bound_152.py`: 714 closed cells have strict domination by actual included material, and twelve one-sided derivative checks treat the six hexagon contact directions. `bound_152.py` additionally proves the older coarse upper bound by a support-gap maximum and endpoint-projection boundary-length bounds; it is retained because `exact_152.py` inherits its exterior proof. The preclip body is an outer bound used for comparisons, never treated as included.

The predecessor R253 result and the original three-stage lower tree are inherited; this package does not claim to have rerun them. `check_sources.py` checks 74 frozen SHA256SUMS entries, both original 68- and 70-entry source indexes, and the published result/lower-chain hashes. Passing the public R253 zip as an optional argument also checks its fixed public hash and compares every archive member byte-for-byte.

## Replay

Extract this package into a new directory, then run from that directory with a Python environment containing python-flint, NumPy and SciPy:

    PY=python3
    "$PY" check_sources.py
    "$PY" bound_152.py
    "$PY" identity_atom.py
    "$PY" exact_152.py
    "$PY" neighborhood.py

To additionally compare the public source zip, set `R253_ZIP` to the original `true-boundary.zip` and run `"$PY" check_sources.py "$R253_ZIP"`. The working directory need not be a specific absolute path. The Python scripts locate the frozen predecessor relative to themselves and write results beside themselves.

## Closed neighbourhood

For the closed box `|w−6/5|≤6e−8`, `|e−.08464386|≤6e−9`, the script bounds every vertex derivative in l1 norm. The support function is piecewise a vertex projection or a unit-circle support centered at a vertex, with continuous joins. Therefore every box member in the same Q pose lies in `D_152 + ε B_2` for ε=1071/50000000000=2.142e−8. Since D_152 lies inside the original unit-width regular hexagon, its perimeter is <4. Steiner's formula costs at most `4ε+4ε²`; the residual margin exceeds 1.37027454035632e−8; the exact rational is in the receipt. This is a deliberately dilated common host; it does not assert that D_152 itself contains the box or that the dilation stays inside the old hexagon or caps.

## GPU exploration

Apple M6 Metal scanned 10 variants × 1,048,576 equally spaced normal angles in 0.051460166669130558 completed GPU-command seconds. Variants are both poses and, for each, the center and four ±1e-8/±1e-9 parameter perturbations. Packed geometry and arithmetic use float32, so these perturbations were below coordinate resolution and cannot establish neighbourhood coverage. `prepare.py`, `screen.metal`, `screen.mm`, `summarize.py`, summary, full-output hashes and compressed window samples record the experiment. The GPU scan is heuristic and is not used in the proof.

from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
W=Path(__file__).resolve().parent;FR=W/'frozen';C=FR/'computation';sys.path[:0]=[str(FR),str(C)]
from local_support import pentagon,mirror,A,direction,dot,sub
from verify_geometry import bracketed_intersection,perp,possible
from deformed_reuleaux_support import environment
from certify_ah_tapered_mirror_counterexample import Support,Polygon
from certify_increment import decimal_outward
ctx.prec=192;n=environment(str(C),'1.5497');ctx.prec=192
mirrorbody=Polygon(Support(json.loads((C/'ah-tapered-mirror-counterexample-input.json').read_text()),arb.pi()))
p=[z for z in mirror(mirrorbody,240,1,'118') if z.label=='118:3:-1:1'][0]
corner=[z for z in pentagon(n,F('.7982906999'),F('.03268800001'),240,-1,'corner151')[0] if z.label=='corner151:0'][0]
new=pentagon(n,F('1.2'),F('.08464386'),0,1,'Z')[0]
t=bracketed_intersection(p,corner,'112.327','112.328');u=direction(t);sel=possible(new,t,t);assert len(sel)==1;z=sel[0]
ell=dot(sub(corner.center,p.center),perp(u));f=z.height(u)-p.height(u);v=(ell*f/2).lower()
print('angle',t,'length',ell,'gap',f,'atom lower',v,flush=True)
base=json.loads((C/'single-repair/single-repair.json').read_bytes()); prior=json.loads((W/'r253-result.json').read_bytes()); budget=F(base['B'])-F(prior['closed_box']['total_area_strict'][0]); assert ell>0 and f>0 and v>A(budget)
r={'angle_degrees':str(t),'edge_length':str(ell),'gap':str(f),'atomic_lower':str(v),'outward_lower':decimal_outward(v,v,30)[0], 'budget_upper':str(budget),'scope':'Conditional on R253 proof that the 118-to-corner151 tangent is exposed on D_E; positive contribution from its surface measure alone.'}
(W/'identity-atom.json').write_text(json.dumps(r,indent=2)+'\n')

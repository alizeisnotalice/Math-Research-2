import json
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;mapping=json.loads((p/'old-map.json').read_text());rows=[]
for i in range(10):
 a=np.fromfile(p/f'screen-{i}.bin',dtype=np.float32).reshape(-1,4);mask=a[:,0]>1e-7;ix=np.flatnonzero(mask);edges=np.flatnonzero(np.diff(ix)>1)+1;groups=np.split(ix,edges);g=[(float(a[v[0],3]),float(a[v[-1],3]),len(v)) for v in groups if len(v)>3];k=np.argmax(a[:,0]);z=a[k];rows.append({'variant':i,'max_gap':float(z[0]),'angle':float(z[3]),'old_piece':mapping[int(z[1])], 'positive_groups_above_1e-7':g,'count':len(ix)})
print(json.dumps(rows,indent=2));(p/'screen-summary.json').write_text(json.dumps(rows,indent=2)+'\n')

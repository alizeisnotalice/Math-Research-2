"""Check frozen R253 SHA list and its two original source indexes; optional compare supplied public zip."""
from pathlib import Path
import hashlib,json,sys,zipfile
W=Path(__file__).resolve().parent;F=W/'frozen';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=F.joinpath('SHA256SUMS').read_text().splitlines()
for row in rows:
 h,name=row.split(None,1);p=F/name.strip();assert p.is_file() and H(p)==h,name
counts={}
for kind in ('center','family'):
 data=json.loads((F/f'{kind}-source-SHA256.json').read_bytes());counts[kind]=len(data)
 for name,h in data.items():
  p=F/(f'{kind}-proof.md' if name=='proof.md' else name);assert p.is_file() and H(p)==h,(kind,name)
expected={'r253-result.json':'4559a4ee0d924fefe5b22399d8c854409af1b29bbecd0cb88c58f19f23e9c0e1','r253-chain-153-lower.json':'5700da374eaeb9bd2041a67c517bd791984bbda1b322e1161ed1b0eecc9944de'}
for name,h in expected.items():assert H(W/name)==h,name
if len(sys.argv)>1:
 z=Path(sys.argv[1]);assert H(z)=='d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf'
 with zipfile.ZipFile(z) as f:
  for name in f.namelist():
   if name.endswith('/'):continue
   assert (F/name).read_bytes()==f.read(name),name
print(json.dumps({'R253_internal_SHA256_files':len(rows),'original_index_counts':counts,'public_zip_rechecked':len(sys.argv)>1,'result_and_lower_chain_public_SHA256':True}))

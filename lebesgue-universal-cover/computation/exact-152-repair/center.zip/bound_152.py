from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import ctx,arb
W=Path(__file__).resolve().parent;FRO=W/'frozen';sys.path.insert(0,str(FRO));sys.path.insert(0,str(FRO/'computation'))
from local_support import load,pentagon,A,direction,dot,sub
from verify_geometry import preclip_core,possible,gap,settle_hex_normals,prove_exterior,visible_parts
from deformed_reuleaux_support import environment
from certify_increment import decimal_outward
ctx.prec=192;comp=FRO/'computation';bodies,_,core=load(comp);ns=environment(str(comp),'1.5497');ctx.prec=192
corner,_=pentagon(ns,F('.7982906999'),F('.03268800001'),240,-1,'corner151');bodies.append(corner);art,_,_=visible_parts(core); witness=bodies+art
upper=[p for body in bodies for p in body]+preclip_core(core)
selected=[p for p in upper if p.label in {'118:3:-1:1','corner151:0','113:0','112:0'}]
results={}
def endpoint(allpieces, t, target):
 u=direction(t); ps=possible(allpieces,t,t); ordered=sorted(ps,key=lambda p:float(p.height(u).mid()),reverse=True);best=ordered[0];other=max([p.height(u).upper() for p in ordered[1:] if p.label!=best.label],default=arb('-10'));v=best.height(u).lower()-other
 assert v>0,(target,str(t),best.label,str(v));print('endpoint',target,t,best.label,'margin',v,flush=True);return best.point(u),best.label,v
for idx,(turn,sign,left,right) in enumerate([(240,-1,F('112.31'),F('115.57'))]):
 new,_=pentagon(ns,F('1.2'),F('.08464386'),turn,sign,'Z');a,b=A(left),A(right);print('pose',turn,sign,flush=True)
 pa,la,_=endpoint(upper,a,'old');pb,lb,_=endpoint(upper,b,'old');qa,lqa,_=endpoint(new,a,'new');qb,lqb,_=endpoint(new,b,'new')
 mid=direction((a+b)/2); tangent=(-mid[1],mid[0]);coshalf=((b-a)*arb.pi()/360).cos();length1=dot(sub(pb,pa),tangent)/coshalf;length2=dot(sub(qb,qa),tangent)/coshalf
 assert length1>0
 length2=max(arb(0),length2.upper())
 n=4000;maxgap=arb(0)
 for i in range(n):
  l=A(left+(right-left)*F(i,n));r=A(left+(right-left)*F(i+1,n)); candidates=[p for p in selected if p.lo<l and p.hi>r]; targets=possible(new,l,r); assert candidates and targets
  bound=max(min(gap(q,p,l.lower(),r.upper()).upper() for p in candidates) for q in targets)
  maxgap=max(maxgap,bound)
 bound=(maxgap*(length1+length2)/2).upper();print('local bound',bound,'gap',maxgap,'lengths',length1,length2,flush=True)
 assert bound<A('1.031044e-7')
 _,pins=settle_hex_normals(bodies,new)
 delta=F(1,100);domains=[(delta,F(60)-delta),(F(60)+delta,left),(right,F(120)-delta)]+[(F(j)+delta,F(j+60)-delta) for j in (120,180,240,300)]
 ext=prove_exterior(witness,new,domains);print('exterior',ext,flush=True)
 results[f'{turn},{sign}']={'window':[str(left),str(right)],'strict_upper':decimal_outward(arb(0),bound,30)[1],'max_gap':str(maxgap),'old_boundary_length_upper':str(length1.upper()),'new_boundary_length_upper':str(length2.upper()),'old_endpoint_pieces':[la,lb],'new_endpoint_pieces':[lqa,lqb],'outside':ext,'pins':pins}
 (W/'bound-152.json').write_text(json.dumps({'scope':'Added area of specified pose over D_E; lower bound from published R253 separate','precision':192,'cells_per_window':n,'results':results},indent=2)+'\n')

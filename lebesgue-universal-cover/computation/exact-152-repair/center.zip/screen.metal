#include <metal_stdlib>
using namespace metal;
struct Arc { float4 data; float4 domain; };
kernel void scan(device const Arc* old [[buffer(0)]],device const uint* oi [[buffer(1)]],device const Arc* nw [[buffer(2)]],device const uint* ni [[buffer(3)]],device float4* out [[buffer(4)]],constant uint &N [[buffer(5)]],uint id [[thread_position_in_grid]]) {
 if(id>=N)return;
 float deg=360.f*(float(id)+.5f)/float(N);uint bin=min(uint(deg*10.f),3599u);
 float rad=deg*0.01745329251994329577f; float2 u=float2(cos(rad),sin(rad));
 float oldmax=-10.f,newmax=-10.f; uint oldi=0,newi=0;
 for(uint i=oi[bin];i<oi[bin+1];i++){Arc p=old[i];if(deg+1.e-5f<p.domain.x || deg-1.e-5f>p.domain.y)continue;float h=dot(p.data.xy,u)+p.data.z;if(h>oldmax){oldmax=h;oldi=i;}}
 for(uint i=ni[bin];i<ni[bin+1];i++){Arc p=nw[i];if(deg+1.e-5f<p.domain.x || deg-1.e-5f>p.domain.y)continue;float h=dot(p.data.xy,u)+p.data.z;if(h>newmax){newmax=h;newi=i;}}
 Arc a=old[oldi], b=nw[newi];float gap=dot(b.data.xy-a.data.xy,u)+b.data.z-a.data.z;
 out[id]=float4(gap,a.data.w,b.data.w,deg);
}

from pathlib import Path
from fractions import Fraction as F
import sys,json,time
import numpy as np
from flint import ctx
W=Path(__file__).resolve().parent;FRO=W/'frozen';sys.path.insert(0,str(FRO));from local_support import load,pentagon
from verify_geometry import preclip_core
sys.path.insert(0,str(FRO/"computation"))
from deformed_reuleaux_support import environment
ctx.prec=160;comp=FRO/'computation'; bodies,_,core=load(comp);ns=environment(str(comp),'1.5497');ctx.prec=160
x,_=pentagon(ns,F('.7982906999'),F('.03268800001'),240,-1,'corner151');bodies.append(x)
old=[p for body in bodies for p in body]+preclip_core(core)
new=[]
for sign in [(0,1),(240,-1)]:
 for dw,de in [(0,0),(-1,0),(1,0),(0,-1),(0,1)]:
  p,_=pentagon(ns,F('1.2')+F(dw,10**8),F('.08464386')+F(de,10**9),*sign,'candidate');new.append(p)
def pack(groups,path):
 records=[];offset=[0]; bins=3600
 for b in range(bins):
  l=b/10;h=(b+1)/10
  for j,p in enumerate(groups):
   if float(p.lo.lower())<=h+1e-8 and float(p.hi.upper())>=l-1e-8:
    records.append((float(p.center[0].mid()),float(p.center[1].mid()),float(p.rho.mid()),float(j),float(p.lo.mid()),float(p.hi.mid()),0.,0.))
  offset.append(len(records))
 arr=np.asarray(records,dtype=np.float32);off=np.asarray(offset,dtype=np.uint32)
 print(path,'pieces',len(groups),'packed',len(arr),'maxbin',int(np.diff(off).max()),flush=True)
 arr.tofile(W/(path+'.bin'));off.tofile(W/(path+'-offset.bin'))
 (W/(path+'-map.json')).write_text(json.dumps([p.label for p in groups]))
pack(old,'old')
for i,g in enumerate(new):pack(g,'new'+str(i))
(W/'source.json').write_text(json.dumps({'old_pieces':len(old),'new_pieces':[len(g) for g in new],'bins':3600,'old_includes':'preclip core, an outer bound on actual clipped core, plus 151 existing bodies','new_variants':'for each pose (0,1),(240,-1): center, w-1e-8, w+1e-8, e-1e-9, e+1e-9'},indent=2))

"""Compare exact point order and denominator against R261 ten/fourteen ZIPs."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,sys
assert len(sys.argv)==3,'usage: compare_r261.py TEN_ZIP FOURTEEN_ZIP'
out=[]
for n,zfile,member in [(10,sys.argv[1],'points.json'),(14,sys.argv[2],'input.json')]:
 path=Path(f'input{n}.json');a=json.loads(path.read_bytes());src=Path(zfile).read_bytes()
 with ZipFile(zfile) as z:raw=z.read(member)
 b=json.loads(raw);assert a['denominator']==b['denominator'] and a['points']==b['points']
 out.append(dict(count=n,member=member,archive_sha256=sha256(src).hexdigest(),member_sha256=sha256(raw).hexdigest(),local_sha256=sha256(path.read_bytes()).hexdigest(),coordinates_and_denominator_match=True))
print(json.dumps(out,indent=2)+'\n')

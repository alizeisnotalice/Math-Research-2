import mpmath as m,json,sys
m.mp.dps=60
out=[]
for k in range(1,9):
 h=m.pi/k; w=2*m.asin(m.sin(h/2)/2); runs=[]
 for i in range(k):
  a=i*h; lo=a+(h-w)/2;hi=a+(h+w)/2;z=(m.exp(1j*hi)-m.exp(1j*lo))/1j;goal=(m.exp(1j*(a+h))-m.exp(1j*a))/(2j);runs.append((lo,hi));assert abs(z-goal)<m.mpf('1e-55')
 seg=runs+[(m.pi+i*h,m.pi+a) for i,(a,b) in enumerate(runs)]+[(m.pi+b,m.pi+(i+1)*h) for i,(a,b) in enumerate(runs)];seg.sort(); merged=[]
 for a,b in seg:
  if merged and abs(merged[-1][1]-a)<m.mpf('1e-55'):merged[-1]=(merged[-1][0],b)
  else:merged.append((a,b))
 if abs(merged[-1][1]-2*m.pi)<m.mpf('1e-55') and abs(merged[0][0])<m.mpf('1e-55'):merged.pop()
 assert len(merged)==2*k+1
 out.append({'m':k,'arc_count':len(merged),'cell_arc_width':m.nstr(w,20)})
print(json.dumps(dict(python=sys.version,mpmath=m.__version__,digits=60,rows=out),indent=2))

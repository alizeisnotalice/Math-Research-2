import numpy as np,json,sys,math
rng=np.random.default_rng(20261119); rows=[]
for n in range(3,11):
 for trial in range(20):
  F=[np.array([0.,0.]),np.array([1.,0.])]
  while len(F)<n:
   p=np.array([rng.uniform(.01,.99),rng.uniform(-.85,.85)])
   if all(np.linalg.norm(p-q)<.99999 for q in F):F.append(p)
  plus=sum(p[1]>0 for p in F[2:]);minus=n-2-plus
  sign=1 if minus<=plus else -1
  G=[F[0],F[1]]+[np.array([p[0],sign*p[1]]) for p in F[2:] if sign*p[1]<0]
  cand=[]
  for i in range(len(G)):
   for j in range(i):
    a,b=G[i],G[j];d=np.linalg.norm(a-b)
    if d<1e-12 or d>2:continue
    mid=(a+b)/2;off=np.array([-(a-b)[1],(a-b)[0]])/d*math.sqrt(1-d*d/4)
    for v in [mid+off,mid-off]:
     if v[1]>1e-10 and all(np.linalg.norm(v-c)<1+1e-10 for c in G):cand.append(v)
  cand.sort(key=lambda p:p[0]);
  unique=[]
  for p in cand:
   if not unique or np.linalg.norm(p-unique[-1])>1e-8:unique.append(p)
  # generic samples: each upper envelope breakpoint is an intersection.
  L=len(unique)+1; k=len(G)-2; assert L<=k+2,(n,trial,L,k)
  vertices=G+unique;diam=max(np.linalg.norm(p-q) for p in vertices for q in vertices)
  assert diam<1+1e-9
  assert all(np.linalg.norm(np.array([p[0],sign*p[1]])-v)<1+1e-9 for p in F for v in vertices)
  rows.append(dict(n=n,trial=trial,k=k,upper_arcs=L,bound=2*L-1,universal_bound=2*(n//2)+1,diameter_max=diam))
print(json.dumps(dict(python=sys.version,numpy=np.__version__,seed=20261119,instances=len(rows),max_violation=max(x['bound']-x['universal_bound'] for x in rows),representatives=[next(x for x in rows if x['n']==n) for n in range(3,11)]),indent=2))

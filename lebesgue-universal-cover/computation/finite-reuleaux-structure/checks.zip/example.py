import json,sys,mpmath as m
m.mp.dps=80
rho=lambda t:m.mpf('0.5')+m.cos(3*t)/4+m.sin(5*t)/8
ends=[m.mpf(0),m.pi*m.mpf('0.3'),m.pi*m.mpf('0.7'),m.pi]
items=[]; segments=[]
for a,b in zip(ends,ends[1:]):
 z=m.quad(lambda t:rho(t)*m.exp(1j*t),[a,b]);p=m.arg(z)
 if p<a:p+=2*m.pi
 half=m.asin(abs(z)/2);lo,hi=p-half,p+half
 assert a<=lo<hi<=b
 z1=(m.exp(1j*hi)-m.exp(1j*lo))/1j
 items.append(dict(a=m.nstr(a,25),b=m.nstr(b,25),lo=m.nstr(lo,25),hi=m.nstr(hi,25),moment_error=m.nstr(abs(z-z1),6),boundary_margin=m.nstr(min(lo-a,b-hi),10)))
 segments.append((lo,hi))
# Build 1-density intervals on second half as the complement of first half.
for (a,b),(lo,hi) in zip(zip(ends,ends[1:]),segments.copy()):
 if lo>a:segments.append((a+m.pi,lo+m.pi))
 if hi<b:segments.append((hi+m.pi,b+m.pi))
segments.sort();unions=[]
for a,b in segments:
 if unions and abs(a-unions[-1][1])<m.mpf('1e-60'):unions[-1]=(unions[-1][0],b)
 else:unions.append((a,b))
# circular interval crossing 0/2pi joins if both ends touch
if len(unions)>1 and abs(unions[0][0])<m.mpf('1e-60') and abs(unions[-1][1]-2*m.pi)<m.mpf('1e-60'):unions[0]=(unions[-1][0]-2*m.pi,unions[0][1]);unions.pop()
closure=sum((m.exp(1j*b)-m.exp(1j*a))/1j for a,b in unions)
print(json.dumps(dict(precision=80,python=sys.version,mpmath=m.__version__,rho='1/2 + cos(3θ)/4 + sin(5θ)/8',rho_range_certificate='[1/8,7/8]',cells=items,arc_count=len(unions),arc_count_bound=7,closure_error=m.nstr(abs(closure),8)),indent=2))

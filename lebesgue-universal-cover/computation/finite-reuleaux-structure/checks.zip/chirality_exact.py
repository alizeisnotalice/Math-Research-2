import itertools,json,sympy as s
R=s.Rational
X=[(R(-2,5),R(-3,5)),(R(4,5),R(-2,5)),(R(-2,5),R(0))];N=[(1,0),(0,1),(-2,-1)]; b=[1,1,3]
res=[]
for sig in [1,-1]:
 rows=[];B=[]
 for x,y in X:
  y*=sig
  for (a,c),v in zip(N,b):rows.append([a,c,a*x+c*y,-a*y+c*x]);B.append(v)
 A=s.Matrix(rows);rhs=s.Matrix(B);candidates=[]
 for ix in itertools.combinations(range(9),4):
  M=A[list(ix),:]
  if M.det()==0:continue
  v=M.inv()*rhs[list(ix),:]
  if all(a<=b for a,b in zip(A*v,rhs)):candidates.append((v[2]**2+v[3]**2,ix,v))
 assert candidates
 val,ix,v=max(candidates,key=lambda y:y[0]);res.append({'sign':sig,'max_rho_squared':str(val),'rho':float(s.sqrt(val)),'active_rows':ix,'witness':list(map(str,v)),'feasible_vertices':len(candidates)})
assert res[0]['max_rho_squared']!=res[1]['max_rho_squared']
print(json.dumps({'C':'[-1,1]^2','P':'x<=1, y<=1, -2x-y<=3','X':list(map(lambda v:list(map(str,v)),X)),'results':res},indent=2))

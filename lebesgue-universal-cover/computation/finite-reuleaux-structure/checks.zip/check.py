import numpy as np
from scipy.optimize import linprog, minimize_scalar
from scipy.spatial import ConvexHull
import json,sys,scipy
out=[]
for n in range(4,15):
 a=2*np.pi*np.arange(n)/n; V=np.column_stack((np.cos(a),np.sin(a)));H=ConvexHull(V[1:]);A=H.equations[:,:2];b=-H.equations[:,2]
 def score(phi):
  R=np.array([[np.cos(phi),-np.sin(phi)],[np.sin(phi),np.cos(phi)]]); h=np.max((V@R.T)@A.T,axis=0); m=linprog([0,0,-1],A_ub=np.column_stack((A,h)),b_ub=b,bounds=[(None,None),(None,None),(0,None)],method='highs');assert m.success; return m.x[2]
 grid=np.linspace(0,2*np.pi/n,721); vals=np.array([score(t) for t in grid]);inds=[i for i in range(1,720) if vals[i]>=vals[i-1] and vals[i]>=vals[i+1]]; best=max([vals[0],vals[-1]]+[-minimize_scalar(lambda t:-score(t),bounds=(grid[i-1],grid[i+1]),method='bounded',options={'xatol':1e-14}).fun for i in inds]); form=np.cos(np.pi/n)**2 if n%2==0 else 2*np.cos(np.pi/n)-1
 out.append(dict(n=n,numerical=best,formula=form,difference=best-form,grid_max=float(vals.max())))
print(json.dumps({'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'grid':721,'output':out},indent=2))

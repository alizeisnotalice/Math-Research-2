import mpmath as m,json,sys
m.mp.dps=80;out=[]
for h in (m.pi,m.pi/2,m.pi/3,m.pi/10,m.mpf('0.01')):
 H=h/2;eta=m.asin(m.sin(H)/2);u=lambda t:m.exp(1j*t)
 z0=m.quad(u,[-H,-eta])+m.quad(u,[eta,H]);z1=m.quad(u,[-eta,eta]);f=m.quad(lambda t:m.sin(-t),[-eta,0])-m.quad(lambda t:m.sin(-t),[-H,-eta]);delta=2*m.sqrt(1-m.sin(H)**2/4)-1-m.cos(H)
 assert abs(z0-z1)<m.mpf('1e-70') and abs(f+delta)<m.mpf('1e-70')
 out.append(dict(h=m.nstr(h,35),eta=m.nstr(eta,35),support_gap=m.nstr(f,35),claimed_bound=m.nstr(delta,35),moment_difference=m.nstr(abs(z0-z1),5),equality_error=m.nstr(abs(f+delta),5)))
print(json.dumps(dict(python=sys.version,mpmath=m.__version__,digits=80,rows=out),indent=2))

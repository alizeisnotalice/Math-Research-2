from flint import arb,ctx,__version__
from fractions import Fraction as F
import json,sys
ctx.prec=256
G=arb(120696470013529293)/144115188075855872
rows=[]
for n in [35,51,101,115,129,455,1439,4547,14377,45459,1220259405]:
 value=(2-1/(arb.pi()/(2*n)).cos())**2*G
 rows.append(dict(arcs=n,bound=str(value),strict_lower=str(value.lower())))
print(json.dumps(dict(python=sys.version,flint=__version__,precision_bits=ctx.prec,G=str(G),rows=rows),indent=2))

from flint import arb,ctx,__version__
from fractions import Fraction as F
import json,sys
ctx.prec=256
A=lambda x:arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
L=A(F(120689264254125501,2**57))/A(F('0.9999990055114'))**2
out=[]
for target,n in [(F('.83745'),1115),(F('.83745160'),5611),(F('.83745166'),19089)]:
 def val(j):return (2-1/(arb.pi()/(2*j)).cos())**2*L
 low=val(n);before=val(n-2); assert low>A(target) and before<A(target)
 out.append(dict(target=str(target),minimal_odd=n,strict_above=str((low-A(target)).lower()),previous_strict_below=str((A(target)-before).lower())))
print(json.dumps(dict(python=sys.version,flint=__version__,precision_bits=ctx.prec,L=str(L),rows=out),indent=2))

G=A(F(120696470013529293,144115188075855872))
def bound(n):return (2-1/(arb.pi()/(2*n)).cos())**2*G
more=[]
for target in map(F,['.83749','.837499','.8374999','.83749999','.837499999','.83750']):
 lo,hi=64,10**10
 while lo<hi:
  mid=(lo+hi)//2
  if bound(2*mid+1)>A(target):hi=mid
  else:lo=mid+1
 n=2*lo+1;assert n>=129 and bound(n)>A(target) and bound(n-2)<A(target)
 more.append(dict(target=str(target),minimal_odd=n,strict_above=str((bound(n)-A(target)).lower()),previous_strict_below=str((A(target)-bound(n-2)).lower())))
print(json.dumps(dict(round265_G=str(G),rows=more),indent=2))

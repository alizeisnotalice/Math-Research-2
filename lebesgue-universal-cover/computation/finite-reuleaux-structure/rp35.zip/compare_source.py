from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,sys
assert len(sys.argv)==2
archive=Path(sys.argv[1]).read_bytes();local=Path('P128.json').read_bytes()
with ZipFile(sys.argv[1]) as f:original=f.read('inputs/P128.json')
a,b=json.loads(local),json.loads(original);assert a['denominator']==b['denominator'] and a['points']==b['points'] and len(a['points'])==128
print(json.dumps(dict(source_archive_sha256=sha256(archive).hexdigest(),source_member_sha256=sha256(original).hexdigest(),local_sha256=sha256(local).hexdigest(),points_and_denominator_equal=True),indent=2)+'\n')

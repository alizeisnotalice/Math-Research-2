# R265 的 P128：35 弧真实单位宽 Reuleaux 容纳证书

冻结 `P128.json` 的128个有理点（分母10^9，文件 SHA256 `13d9a52243efadcb2281aa60e41282349e3c4c64bc9925f9ad20ece8dab2ecb1`）被一个真实、原位、宽恰为一的 **35 弧** Reuleaux 多边形包含。代数构造用原点集真实最远点 (26,99) 作轴，经单位圆交点公式取得17个上链接点；候选组合只使用 `P128-recipe.json` 的整数索引及根的正负分支，不使用浮点近似。`P128-completion.json` 包含35个圆心的 Arb 区间、每个单位弧反时针起角、跨度和端点编号。

运行（相同 Python 3.13.18 / python-flint 0.9.0 使输出字节一致）：

    PY=python3
    "$PY" -I -B verify_p128.py "$OUT/completion.json"
    cmp P128-completion.json "$OUT/completion.json"
    "$PY" -I -B check_arb_both.py > "$OUT/thresholds.txt"
    cmp thresholds-both-arb.txt "$OUT/thresholds.txt"

可选核对 R263 冻结源：

    python3 -I -B compare_source.py /path/to/finite-nine.zip > "$OUT/source.json"
    cmp P128-source.json "$OUT/source.json"

320-bit Arb 核对所有输入点的整数平方距离和真实最远轴、每个接点的单位圆代数定义、35个顶点所有非直径环边、每个原点到35个圆心的包含、弧方向及闭环。除锚点的两个代数等号外，最小点—圆盘距离平方余量 >2.5548×10⁻¹²；非环边距离平方余量 >1.0623×10⁻¹⁰。将原点集自身直径 d<1 的 Reuleaux 完备扩张以轴起点为中心放大至宽1，故包含原点无需缩小。精确交点公式和证书原理与包内核程序一致；回执坐标是包络，点的真实值由输入有理数和所选单位圆根定义。

`REPORT.md` 给出 R254/R265 非均匀面积下界、严格阈值、一般 Λ 的双边关系与非均匀法向的最优原位 Hausdorff 插值常数。R265 八体全域面积 G265 的证明为引用此前已冻结轮次，本包不重新生成八体搜索树。相邻的两个11点组的直径与点数沿用 R263/R265 的公开核验；M(11)=11 的有限完备扩张定理用于它们。

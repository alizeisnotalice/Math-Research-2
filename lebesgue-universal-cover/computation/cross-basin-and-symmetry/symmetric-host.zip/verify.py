"""One host covers all listed independent classes. Each placement is common to its faces."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import itertools,json
import numpy as np
from flint import arb,ctx
ctx.prec=192
root=Path(__file__).resolve().parent
pi=arb.pi()
Q=10**8
M=60
N=960
budget=arb('.844082046521218581802948589770767704354')
def A(t):
    t=F(t);return arb(t.numerator)/t.denominator
def read(s):return json.loads((root/s).read_bytes())
@lru_cache(None)
def trig(q):return (2*pi*A(q)).sin_cos()
u=[trig(F(i,60))[::-1] for i in range(60)]
def dot(n,p):return n[0]*p[0]+n[1]*p[1]
def det(n,p):return n[0]*p[1]-n[1]*p[0]
def poly(b,active):
    v=[]
    assert active==sorted(set(active))
    for i,j in zip(active[-1:]+active[:-1],active):
        n,m=u[i],u[j];t=det(n,m);assert t>0
        xx=((b[i]*m[1]-b[j]*n[1])/t,(n[0]*b[j]-m[0]*b[i])/t)
        for k in range(60):
            if k not in (i,j):assert dot(u[k],xx)<b[k]
        v.append(xx)
    return v,sum(det(a,b) for a,b in zip(v,v[1:]+v[:1]))/2
def cap_regular(m,z):
    T=F(1,2*m)
    x=abs((z+T)%(2*T)-T)
    R=1/(2*trig(T/2)[1])
    if x<=T/2:return R*trig(x)[1]
    return 1-R*trig(T-x)[1]
def cap_class(m,z):
    T=F(1,2*m);x=z%(2*T);w=T
    if x>=T:
        w=T/2;x=(x-T)%w
    return trig(x-w/2)[1]/(2*trig(w/2)[1])
def placement(b,m,q,func):
    phi=F(q[0],10**11);v=[arb(a)/10**11 for a in q[1:]]
    gaps=[(b[i]-dot(n,v)-func(m,F(i,M)-phi)).lower() for i,n in enumerate(u)]
    assert min(gaps)>0,(m,str(min(gaps)));return min(gaps)
def integer(x):
    j=round(float(x)*Q)
    assert abs(x-arb(j)/Q)<arb(1)/Q
    return j
def table():
    D=[];G=[]
    for j in range(N+1):
        z=pi*j/N
        D.append([integer(a) for a in (z.cos(),z.sin(),(3*z).cos(),(3*z).sin(),(5*z).sin(),(5*z).cos(),(7*z).sin(),(7*z+3*pi/10).cos())])
    for i in range(M):
        row=[]
        for j in range(N+1):
            k,r=divmod(i*(2*N//M)-j,N);v=pi*r/N
            S=-v.cos()/2+(pi/2-v)*v.sin()
            row.append(integer((1 if k%2 else -1)*S/pi))
        G.append(row)
    return np.array(G,dtype=np.int64),np.array(D,dtype=np.int64)
def density(b):
    dt=read('green-coeff.json');raw=dt['coeff'];den=dt['den'];assert den==Q
    assert min(b[i]+b[i+M//2] for i in range(M//2))>1
    G,D=table();assert np.max(abs(G))<Q and np.max(abs(D))<=Q
    sin=[trig(F(i,M))[0] for i in range(M)]
    irow=0;weak=arb(1)
    pts=[(F(8,1000),F(23,100)),(F(0),F(23,100))]
    dlim=[arb(2) for x in pts];alim=[arb(2) for x in pts];unconditional=arb(2)
    for i,j,k in itertools.combinations(range(M),3):
        gaps=(k-j,M+i-k,j-i)
        if max(gaps)>=M//2:continue
        p=raw[irow];irow+=1;assert len(p)==8 and min(p[5:])>=0 and max(map(abs,p))<Q
        w=[sin[x] for x in gaps];s=sum(w);w=[x/s for x in w];assert all(x>0 for x in w)
        wi=np.array([integer(v) for v in w],dtype=np.int64)
        zz=abs(wi@G[[i,j,k]]-D@np.array(p,dtype=np.int64))
        assert max(map(abs,wi))<=Q
        h=2*sum(map(int,zz))-int(zz[0])-int(zz[-1])
        err=(4+arb(sum(map(abs,p)))/den)/Q
        der=(arb(5)/2+pi/2)/pi+sum(n*n*arb(abs(c))/den for n,c in zip((1,1,3,3,5,5,7,7),p))
        I=pi*(arb(h)/(2*N*Q**2)+err+der*(pi/N)**2/12)/2
        P=pi*(arb(p[2]*p[2]+p[3]*p[3])).sqrt()/(2*den)
        free=sum(s*t for s,t in zip(w,[b[i],b[j],b[k]]))-arb(1)/2
        # For all true |g|<=d/2, its third amplitude is <=2d/pi.
        unconditional=unconditional.min((free/(I+2*P/pi)).lower())
        for ii,(a,d) in enumerate(pts):
            gap=free-A(a)*P-A(d)*I
            assert gap>0,(i,j,k,str(gap));weak=weak.min(gap.lower())
            dlim[ii]=dlim[ii].min(((free-P*A(a))/I).lower())
            if p[2] or p[3]:alim[ii]=alim[ii].min(((free-I*A(d))/P).lower())
    assert irow==len(raw)==8120
    return dict(triples=irow,opposites=M//2,min_margin=str(weak),amplitudes=str(alim[0]),density_at_008=str(dlim[0]),
                density_at_zero=str(dlim[1]),unconditional_density_factor=str(unconditional))
def main():
    d=read('host.json');b=[arb(x)/10**10 for x in d['cap']];bb=[arb(x)/10**10 for x in d['low_cap']]
    v,ar=poly(b,d['active']);v0,ar0=poly(bb,d['low_active']);assert ar<budget and ar0<ar
    containment=min((b[i]-dot(n,p)).lower() for i,n in enumerate(u) for p in v0);assert containment>0
    mm=d['from_m'];assert mm%2==1
    r0=min((bound-dot(n,[arb(x)/10**11 for x in d['central']])).lower() for n,bound in zip(u,b))
    assert r0>1/(2*trig(F(1,4*mm))[1])
    assert sorted(map(int,d['reg']))==[3,5,7] and sorted(map(int,d['cm']))==list(range(9,mm,2))
    regs={m:str(placement(b,int(m),pose,cap_regular)) for m,pose in d['reg'].items()}
    sym={m:str(placement(b,int(m),pose,cap_class)) for m,pose in d['cm'].items()}
    print(json.dumps(dict(faces=len(d['active']),area=str(ar),old_inclusion_margin=str(containment),
                          disk_radius=str(r0),odd_from=mm,regular=regs,classes=sym,low=density(bb)),indent=2))
if __name__=='__main__':main()

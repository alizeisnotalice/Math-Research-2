from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from flint import ctx,arb
import json
ctx.prec=192
pi=arb.pi();root=Path(__file__).resolve().parent
m=7;T=F(1,2*m);a=T/2;phi=F(43,36000)
def A(z):return arb(z.numerator)/z.denominator
@lru_cache(None)
def trig(z):return (2*pi*A(z)).sin_cos()
def sn(z):return trig(z)[0]
def cs(z):return trig(z)[1]
def load(k):return json.loads((root/k).read_bytes())
src=load('host.json');cap=[arb(v)/10**10 for v in src['cap']]
u=[(cs(F(j,60)),sn(F(j,60))) for j in range(60)]
def area():
    act=src['active'];vs=[];assert act==sorted(set(act))
    for i,j in zip(act[-1:]+act[:-1],act):
        x,y=u[i];z,w=u[j];det=x*w-z*y;assert det>0
        xx=(cap[i]*w-y*cap[j])/det;yy=(x*cap[j]-cap[i]*z)/det
        for k,(c,s) in enumerate(u):
            if k not in (i,j):assert c*xx+s*yy<cap[k]
        vs.append((xx,yy))
    ar=sum(x*w-y*z for (x,y),(z,w) in zip(vs,vs[1:]+vs[:1]))/2
    assert ar<arb('0.844082046521218581802948589770767704354')
    assert all(cap[i]+cap[i+30]>1 for i in range(30))
    return ar
@lru_cache(None)
def green(z,x):return sn(min(z,x))*sn(T-max(z,x))/sn(T)
x=[];sign=[]
for i in range(60):
    k,r=divmod(F(i,60)-phi,T);sign.append(1 if k%2 else -1);x.append(r)
def integral(term,lam,eta):
    assert lam>=0
    cuts=sorted(set([0,a,T]+[x[k] for _,k in term]))
    def val(z):
        return sum(w*sign[k]*green(z,x[k]) for w,k in term)-lam*green(z,a)-eta*sn(z-T/2)
    vals=[val(z) for z in cuts];out=arb(0)
    for lo,hi,left,right in zip(cuts,cuts[1:],vals,vals[1:]):
        d=2*pi*A(hi-lo)
        if left*right<0:
            if left<0:left,right=-left,-right
            zero=arb.atan2(left*d.sin(),left*d.cos()-right)
            out+=left*(zero/2).tan()-right*((d-zero)/2).tan()
        else:
            out+=(abs(left)+abs(right))*(d/2).tan()
    return out/2
def main():
    ar=area();tri=[];B=[];W=[];P=[];up=[];coef=load('dual.json')
    for i,j,k in combinations(range(60),3):
        dif=(k-j,60+i-k,j-i)
        if max(dif)>=30:continue
        ix=(i,j,k);ww=[sn(F(v,60)) for v in dif];tot=sum(ww);ww=[v/tot for v in ww]
        assert all(v>0 for v in ww)
        q=coef[len(tri)];lam,eta=[arb(z)/10**9 for z in q]
        tri.append(ix);W.append(ww);P.append((lam,eta));B.append(sum(w*cap[k] for w,k in zip(ww,ix)))
        up.append(arb(1)/2+integral(list(zip(ww,ix)),lam,eta))
    assert len(tri)==len(coef)==8120
    lookup={v:i for i,v in enumerate(tri)}
    def perm(o,ix):return lookup[tuple(sorted((o%60+(1 if o<60 else -1)*k)%60 for k in ix))]
    i0=36;i1=109
    f0=[r for r,ix in enumerate(tri) if not up[r]<B[perm(i0,ix)]]
    f1=[r for r,ix in enumerate(tri) if not up[r]<B[perm(i1,ix)]]
    worst=arb(1);count=0;weights=[]
    for r in f0:
        for s in f1:
            ok=False
            for n in (50,25,75,90,10,97,3,99,1,65,35,85,15):
                w=arb(n)/100;c=1-w
                term=list(zip([q*w for q in W[r]],tri[r]))+list(zip([q*c for q in W[s]],tri[s]))
                p=[w*v+c*z for v,z in zip(P[r],P[s])]
                gap=w*B[perm(i0,tri[r])]+c*B[perm(i1,tri[s])]-arb(1)/2-integral(term,*p)
                if gap>0:
                    worst=worst.min(gap.lower());count+=1;weights.append(n);ok=True;break
            assert ok,(r,s)
    print(json.dumps(dict(area=str(ar),m=m,rows=len(tri),orientations=[i0,i1],
                         first_rows=f0,second_rows=f1,mixed_tests=count,weight_percent=weights,minimum=str(worst)),indent=2))
if __name__=='__main__':main()

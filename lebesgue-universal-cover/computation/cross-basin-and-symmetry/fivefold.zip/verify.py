from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from flint import arb,ctx
import json
ctx.prec=192
root=Path(__file__).resolve().parent
pi=arb.pi();T=F(1,10);Tr=pi/5;goal=arb('.844082046521218581802948589770767704354')
def A(x):return arb(x.numerator)/x.denominator
@lru_cache(None)
def sc(x):return (2*pi*A(x)).sin_cos()
u=[sc(F(i,60))[::-1] for i in range(60)]
tan=sc(T/2)[0]/sc(T/2)[1];R=1/(2*sc(T/2)[1])
h=json.loads((root/'host.json').read_bytes());b=[arb(x)/10**10 for x in h['cap']]
def det(x,y):return x[0]*y[1]-x[1]*y[0]
def dot(x,y):return x[0]*y[0]+x[1]*y[1]
def geometry():
    assert h['active']==list(range(60));v=[]
    for i in range(60):
        j=(i+1)%60;w=det(u[i],u[j]);assert w>0
        q=((b[i]*u[j][1]-b[j]*u[i][1])/w,(u[i][0]*b[j]-u[j][0]*b[i])/w)
        for k in range(60):
            if k not in (i,j):assert dot(q,u[k])<b[k]
        v.append(q)
    ar=sum(det(x,y) for x,y in zip(v,v[1:]+v[:1]))/2
    L=[sum((c-e)*(c-e) for c,e in zip(v[i],v[i-1])).sqrt() for i in range(60)]
    return ar,L
@lru_cache(None)
def primitive(x):
    k,z=divmod(x,T);s,c=sc(z)
    return (1 if k%2==0 else -1)*(1-c-tan*s)/2
@lru_cache(None)
def support(z,alpha):
    cut=[F(0),T*(F(1,2)-alpha),T/2,T*(F(1,2)+alpha),T]
    v=[primitive(z-q) for q in cut]
    return (1+sum((1 if j%2 else -1)*(v[j]-v[j+1]) for j in range(4)))/2
def main():
    d=json.loads((root/'band.json').read_bytes());ar,L=geometry();weights=[]
    for raw in d['banks']:
        assert len(raw)==60 and raw[0]==raw[15]==0
        y=[arb(c)/10**13 for c in raw]
        for ii in (0,15):
            k=0 if ii==0 else 1
            y[ii]=-sum(y[j]*u[j][k] for j in range(60) if j not in (0,15))
        assert all(0<=v and 2*v<=ll for v,ll in zip(y,L))
        weights.append(y)
    assert [p[0] for p in d['panels']]==list(range(134,152))
    worst=arb(2);n=0
    for hh,cells in d['panels']:
        pos=0
        for l,r,ix in cells:
            assert l==pos and l<r<=2**16;pos=r;y=weights[ix];off=sum(y[j]*b[j] for j in range(60))
            w=2*pi*A(F(r-l,5*2**16))
            err=sum(y)*(R*w*w+Tr*Tr/(sc(T/2)[1]*10**6))/8
            for k in (l,r):
                ph=F(k,5*2**16)
                for aa in (F(hh,1000),F(hh+1,1000)):
                    left=sum(y[j]*support(F(j,60)-ph,aa) for j in range(60))
                    low=ar+left-off-err;assert low>goal,(hh,l,r,str(low));worst=worst.min(low.lower())
            n+=1
        assert pos==2**16
    print(json.dumps(dict(alpha=['0.134','0.152'],panels=len(d['panels']),boxes=n,balanced_weights=len(weights),
                          area=str(ar),hull_area_lower=str(worst),excess_over_B=str((worst-goal).lower())),indent=2))
if __name__=='__main__':main()

"""Rule out two distinct failed translation certificates for the same physical curvature."""
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('fixed_host',Path(__file__).with_name('verify.py'))
lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
from flint import arb
import numpy as np,json,itertools
from fractions import Fraction
pi=lib.pi;Q=lib.Q;N=lib.N;M=lib.M
def tables():
    dt=lib.read('green-coeff.json');raw=dt['coeff'];assert dt['den']==Q
    h=lib.read('host.json');b=[arb(x)/10**10 for x in h['cap']]
    _v,ar=lib.poly(b,h['active']);assert ar<lib.budget
    assert all(b[i]+b[i+30]>1 for i in range(30))
    G,T=lib.table();sin=[lib.trig(Fraction(i,60))[0] for i in range(60)]
    ids=[];BB=[];fields=[];errors=[];P=[];A3=[]
    for i,j,k in itertools.combinations(range(60),3):
        dif=(k-j,M+i-k,j-i)
        if max(dif)>=30:continue
        p=raw[len(ids)];ids.append((i,j,k))
        assert len(p)==8 and min(p[5:])>=0 and max(map(abs,p))<Q
        w=[sin[q] for q in dif];s=sum(w);w=[x/s for x in w]
        wi=np.array([lib.integer(x) for x in w],dtype=np.int64);assert max(map(abs,wi))<=Q
        BB.append(sum(x*y for x,y in zip(w,[b[i],b[j],b[k]])))
        q=wi@G[[i,j,k]]-T@np.array(p,dtype=np.int64)
        fields.append((q+Q//2)//Q)
        # Round once more onto the 1/Q residual grid. Every representable term
        # in this and the preceding integer dot product has magnitude < 2^63.
        rnd=(arb(9)/2+arb(sum(map(abs,p)))/Q)/Q
        curv=(arb(5)/2+pi/2)/pi+sum(n*n*arb(abs(c))/Q for n,c in zip([1,1,3,3,5,5,7,7],p))
        errors.append(pi*(rnd+curv*(pi/N)**2/12)/2)
        P.append((p[2],p[3]));A3.append(pi*arb(p[2]*p[2]+p[3]*p[3]).sqrt()/(2*Q))
    assert len(ids)==len(raw)==8120
    V=np.array(fields,dtype=np.int64);assert np.max(abs(V))<2*Q
    TR=2*np.sum(abs(V),axis=1,dtype=np.int64)-abs(V[:,0])-abs(V[:,-1])
    I=[pi*arb(int(t))/(4*N*Q)+e for t,e in zip(TR,errors)]
    return ids,BB,V,errors,P,A3,I,ar
def main():
    ids,B,V,E,P,A3,I,ar=tables()
    remap={v:i for i,v in enumerate(ids)}
    perm={}
    for o in range(120):
        sign=1 if o<60 else -1;off=o%60
        perm[o]=[remap[tuple(sorted((sign*k+off)%60 for k in ix))] for ix in ids]
    result=[]
    for case in lib.read('choices.json'):
        a=lib.A(case['a']);d=lib.A(case['d']);choices=case['choices'];assert a>=0 and d>=0
        upper=[arb(1)/2+d*n+a*g for n,g in zip(I,A3)]
        root=[r for r in range(len(ids)) if not (upper[r]<B[r])]
        pair_count=0;min_gap=arb(1);used=set()
        for r in root:
            # If r prevents the initial pose, every failed row at this second
            # pose will be incompatible with that same r.
            ori=choices[str(r)];assert 0<ori<120;pr=perm[ori];used.add(ori)
            secondary=[s for s in range(len(ids)) if not upper[s]<B[pr[s]]]
            for s in secondary:
                success=False
                for q in (50,75,25,90,10,97,3,99,1,60,40,85,15):
                    v=abs(q*V[r]+(100-q)*V[s])
                    tr=2*int(v.sum(dtype=np.int64))-int(v[0])-int(v[-1])
                    norm=pi*arb(tr)/(4*N*100*Q)+(q*E[r]+(100-q)*E[s])/100
                    px=q*P[r][0]+(100-q)*P[s][0];py=q*P[r][1]+(100-q)*P[s][1]
                    penalty=pi*arb(px*px+py*py).sqrt()/(2*100*Q)
                    delta=(q*B[r]+(100-q)*B[pr[s]])/100-arb(1)/2-d*norm-a*penalty
                    if delta>0:
                        min_gap=min_gap.min(delta.lower());success=True;break
                assert success,(case['a'],case['d'],r,ori,s)
                pair_count+=1
        result.append(dict(a=case['a'],d=case['d'],first_rows=len(root),second_poses=sorted(used),
                           paired_tests=pair_count,min_paired_margin=str(min_gap)))
    print(json.dumps(dict(area=str(ar),classes=result),indent=2))
if __name__=='__main__':main()

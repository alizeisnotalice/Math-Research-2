from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import json
from flint import arb,ctx
ctx.prec=192
pi=arb.pi()
def A(v):
    v=Fraction(v)
    return arb(v.numerator)/v.denominator
@lru_cache(None)
def trig(turn):
    return (2*pi*A(turn)).sin_cos()
def dot(x,y):return x[0]*y[0]+x[1]*y[1]
def det(x,y):return x[0]*y[1]-x[1]*y[0]
R=1/(2*(pi/10).cos())
n=[trig(Fraction(j,60))[::-1] for j in range(60)]
def verify(d):
    cap=list(map(A,d['caps']));vs=[]
    for i in range(60):
        j=(i+1)%60;w=det(n[i],n[j]);assert w>0
        q=((cap[i]*n[j][1]-cap[j]*n[i][1])/w,(n[i][0]*cap[j]-n[j][0]*cap[i])/w)
        for k in range(60):
            if k not in (i,j):assert dot(n[k],q)<cap[k]
        vs.append(q)
    lengths=[sum((a-b)*(a-b) for a,b in zip(vs[i],vs[i-1])).sqrt() for i in range(60)]
    area=sum(det(a,b) for a,b in zip(vs,vs[1:]+vs[:1]))/2
    assert area<A('.844082046521218581802948589770767704354')
    pos=0;worst=arb(2);goal=A(d['goal']);root=2**14
    for l,r,point,raw in d['plan']:
        assert pos==l and l<r<=root and 2*(r-l)<5*root and len(raw)==len(point)==60
        pos=r
        y=[arb(q)/10**13 for q in raw];assert raw[0]==raw[15]==0
        # The omitted normals are exactly (1,0),(0,1).
        y[0]=-sum(y[i]*n[i][0] for i in range(60) if i not in (0,15))
        y[15]=-sum(y[i]*n[i][1] for i in range(60) if i not in (0,15))
        assert all(v>=0 and 2*v<=L for v,L in zip(y,lengths)),(d['tag'],l,[(i,str(v),str(L),str(L-2*v)) for i,(v,L) in enumerate(zip(y,lengths)) if not (v>=0 and 2*v<=L)])
        intercept=sum(v*b for v,b in zip(y,cap));assert intercept+goal-area>0
        for h in (l,r):
            val=arb(0)
            for i,j in enumerate(point):
                assert 0<=j<5
                turn=Fraction(i,60)-Fraction(h,5*root)-Fraction(j,5)
                val+=y[i]*R*trig(turn)[1]
            out=area+val-intercept;assert out>goal;worst=worst.min(out.lower())
    assert pos==root
    a,tx,ty=d['four_pose'];tr=(arb(tx)/10**12,arb(ty)/10**12);clear=arb(1)
    for i in range(60):
        for j in range(4):
            zz=Fraction(i,60)-Fraction(a,720)-Fraction(j,5)
            clear=clear.min((cap[i]-dot(n[i],tr)-R*trig(zz)[1]).lower())
    assert clear>0
    return dict(tag=d['tag'],original_area=str(area),five_hull_lower=str(worst),angular_cells=len(d['plan']),four_clearance=str(clear))
data=json.loads((Path(__file__).parent/'five.json').read_bytes())
assert len(data)==5
print(json.dumps([verify(d) for d in data],indent=2))

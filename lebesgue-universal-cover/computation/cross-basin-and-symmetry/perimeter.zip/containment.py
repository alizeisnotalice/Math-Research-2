from perimeter import *
assert hashlib.sha256((ROOT/'source-eh.json').read_bytes()).hexdigest()=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
assert hashlib.sha256((ROOT/'source-eh-dual.py').read_bytes()).hexdigest()=='b12010f2a2ec5a05763b999a8e771c74fbd33803f253f21dd2a7cb914b91e11d'
eh=json.loads((ROOT/'source-eh.json').read_bytes());assert eh['old_parameters']==['0.000553335','0.0005505434','0.0075']
ctx.prec=192
p=project(g,n[2]) # perimeter polygon clipping reuses the name p
H=[(A(x),A(y)) for x,y in poly]
def hp(a,b):
 e=sub(b,a);v=(e[1],-e[0]);v=mul(1/norm(v),v);return v,dot(v,a)
cut_records=[]
def score(name,v,b):
 h=max(dot(v,x).upper() for x in H);ratio=b/h;assert h>0 and b>0 and ratio>A('.9995');cut_records.append({'name':name,'sufficient_scale_lower':str(ratio.lower()),'margin':str((b-A('.9995')*h).lower())});print(name,'scale lower',str(ratio),flush=True);return ratio
q0,q1,h0=map(A,eh['old_parameters']);rad=sub(u,c3)
def moved(d):return add(c3,sub(mul(d.cos(),rad),mul(d.sin(),perp(rad))))
u0=moved(q0);u1=moved(q1);hinge=add(u1,mul(h0,sub(teh,u1)));old=[hp(u0,hinge),hp(hinge,teh)];X=meet(old[0][0],old[1][0],old[0][1]-A('.00000001036'),old[1][1]-A('.0000000000086'));rows=[hp(u0,X),hp(X,teh)]
for d,p_param in eh['EH_chain_params']:
 Y=add(X,mul(A(p_param),sub(u0,X)));rows.append(hp(moved(A(d)),Y))
for i,(v,b) in enumerate(rows):score('EH'+str(i),v,b)
Dlt=sub(t,z);length=norm(Dlt);base=mul(-1/length,Dlt)
for pp,angle in [('.355','.00060'),('.410','.00030'),('101/250','23/50000'),('.429','.01400')]:
 angle=A(angle);c0,s0=angle.cos(),angle.sin();d=add(mul(c0,base),mul(s0,perp(base)));anchor=add(z,mul(A(pp),Dlt));v=(d[1],-d[0]);v=mul(1/norm(v),v);b=dot(v,anchor)
 if not b>0:v=mul(-1,v);b=-b
 score('AH'+pp,v,b)

# An inscribed ordered Gibbs-boundary polygon supplies a rigorous perimeter lower bound.
pts=[b1,q]
def add_arc(a,b,c):
 ua=sub(a,c);ub=sub(b,c);assert cross(ua,ub)>0 and dot(ua,ub)>0
 for j in range(1,17):
  v=add(mul(A(F(16-j,16)),ua),mul(A(F(j,16)),ub));pts.append(add(c,mul(1/norm(v),v)))
add_arc(q,y,e3);add_arc(y,t,C);pts.append(z)
for j in range(1,17):pts.append(pair(add(z,mul(A(F(j,16)),sub(t,z)))))
add_arc(tp,p,g);pts.extend([f1,h]);add_arc(h,u,c3);pts.append(teh);add_arc(teh,ip,b3);pts.extend([e3,d1,g]);add_arc(g,k,f3);pts.append(c3)
per=sum((norm(sub(a,b)) for a,b in zip(pts,pts[1:]+pts[:1])),arb(0));Plow=F(int((per*10**9).lower().floor().unique_fmpz()),10**9);assert per>A(Plow)
P_U_low=A('.9995')*A(Plow)
area_low=F(source['geometry']['cases'][1]['area']['exact'][0]);tt=A('.999');lower=(1-tt)**2*pi/4+tt*(1-tt)*P_U_low/2+tt**2*A(area_low);assert lower>A(B)
# Derivative remains positive throughout [.999,1], using the lower area and the certified upper perimeter.
interval=arb('.999').union(arb(1)); derivative=2*(1-interval)*(-pi/4)+(1-2*interval)*A(Pup)/2+2*interval*A(area_low);assert derivative>0
out={'gibbs_perimeter_lower':str(Plow),'gibbs_inscribed_perimeter':str(per),'scale':'1999/2000','cut_count':len(rows)+4,'P_U_lower':str(P_U_low),'area_at_t_0999_lower':str(lower),'area_above_B_margin':str((lower-A(B)).lower()),'derivative_lower_on_0999_1':str(derivative.lower()),'inscribed_vertices':len(pts),'cuts':cut_records}
(ROOT/'containment-result.json').write_text(json.dumps(out,indent=2)+'\n');print('LOWER',json.dumps(out),flush=True)

from fractions import Fraction as F
from flint import arb,arb_series,ctx
from pathlib import Path
import json,math,hashlib
ctx.prec=192;ctx.cap=2
ROOT=Path(__file__).resolve().parent
assert hashlib.sha256((ROOT/'source-geometry.json').read_bytes()).hexdigest()=='8181f9f47d2a0fa88f30e5443ccc48067a740286bfc84f7f5ee38c51b301d63c'
assert hashlib.sha256((ROOT/'gibbs-source.py').read_bytes()).hexdigest()=='b3e0c0200e60927ee5a76d157149586fa6195eb2dee550eeddf7902239caa38b'
source=json.loads((ROOT/'source-geometry.json').read_bytes());assert source['parameters']=={'sigma_degrees':'1.54','line':['.429','.01400'],'physical_parameters':['.352','.403','.020']}
A=lambda q: arb(F(q).numerator)/F(q).denominator
pi=arb.pi();sqrt3=arb(3).sqrt();r=arb(1)/2
add=lambda a,b:(a[0]+b[0],a[1]+b[1]);sub=lambda a,b:(a[0]-b[0],a[1]-b[1]);mul=lambda t,a:(t*a[0],t*a[1]);dot=lambda a,b:a[0]*b[0]+a[1]*b[1];cross=lambda a,b:a[0]*b[1]-a[1]*b[0];perp=lambda a:(-a[1],a[0]);norm=lambda a:dot(a,a).sqrt()
def meet(a,b,ra=r,rb=r):
 d=cross(a,b);return ((ra*b[1]-rb*a[1])/d,(rb*a[0]-ra*b[0])/d)
def project(x,n):return sub(x,mul(dot(x,n)-r,n))
def cl(c,n,sign):
 d=dot(n,c)-r;return add(project(c,n),mul(sign*(1-d*d).sqrt(),perp(n)))
def cc(a,b,sign):
 q=sub(b,a);return add(mul(r,add(a,b)),mul(sign*(1/dot(q,q)-A('1/4')).sqrt(),perp(q)))
n=[(arb(1),arb(0)),(r,sqrt3/2),(-r,sqrt3/2),(-arb(1),arb(0)),(-r,-sqrt3/2),(r,-sqrt3/2)]
a=pi/6+pi*A('1.54')/180;c,s=a.cos(),a.sin();m=[(u*c-v*s,v*c+u*s) for u,v in n]
b1,f1,d1=meet(n[0],n[1]),meet(n[2],n[3]),meet(n[4],n[5]);b3=meet(n[1],m[0]);c3=meet(n[0],m[5]);e3=meet(n[4],m[3]);f3=meet(n[3],m[2]);g=cl(f3,n[5],1);q,p,ip,h,k=project(e3,n[1]),project(g,n[2]),project(b3,m[3]),project(c3,n[3]),project(f3,m[5]);r0=meet(m[2],n[1],r,arb(0));ss=cl(r0,n[0],-1);teh=cc(ss,b3,1);u=cl(c3,(-sqrt3/2,-r),-1);C=(-e3[0],e3[1]);mid=(-A('1/4'),-sqrt3/4);l0=(sqrt3/2-r,(sqrt3/2-r-1)/sqrt3);z=cc(l0,mid,-1);y=(arb(0),C[1]+(1-C[0]*C[0]).sqrt());v=sub(z,C);v2=dot(v,v);t=add(C,sub(mul(1/v2,v),mul((v2-1).sqrt()/v2,perp(v))))
nl=(r,-sqrt3/2);nn=(-r,-sqrt3/2);el=(sqrt3/2,r);en=(-sqrt3/2,r)
def pair(point):
 def inv(n,e):
  d=dot(n,point)-r;return sub(sub(point,mul(d,n)),mul((1-d*d).sqrt(),e))
 l=inv(nl,el);N=inv(nn,en);v0=l[0]+r;lx=(v0+sqrt3*(1-v0*v0).sqrt())/2-r
 return cc((lx,(lx-1)/sqrt3),sub(mul(2,mid),N),-1)
tp=pair(t)
arcs=[(q,y,e3),(y,t,C),(tp,p,g),(h,u,c3),(teh,ip,b3),(g,k,f3)]
D=10**10
lines=[]
# H contains U, and the rounded normals differ from true normals by < 1e-10 per coordinate. H lies in a unit disk.
for v in n:
 ix=int(round(float(v[0].mid())*D));iy=int(round(float(v[1].mid())*D)); assert abs(A(F(ix,D))-v[0])<A('1e-10') and abs(A(F(iy,D))-v[1])<A('1e-10')
 lines.append((ix,iy,F(D,2)+2,'hex'))
for index,(a,b,center) in enumerate(arcs):
 u0=sub(a,center);u1=sub(b,center);assert cross(u0,u1)>0 and dot(u0,u1)>0
 for j in range(1,32):
  vv=add(mul(A(F(32-j,32)),u0),mul(A(F(j,32)),u1));vv=mul(1/norm(vv),vv);ix=int(round(float(vv[0].mid())*D));iy=int(round(float(vv[1].mid())*D));w=(arb(ix),arb(iy));assert cross(u0,w)>0 and cross(w,u1)>0
  support=dot(w,center)+norm(w);top=F(int((support*10**10).upper().ceil().unique_fmpz()),10**10)
  assert A(top)>support
  lines.append((ix,iy,top,'arc'+str(index)))
# Straight segments on the positively oriented Gibbs boundary.
for start,end in ((b1,q),(t,z),(p,f1),(f1,h),(u,teh),(ip,e3),(e3,d1),(d1,g),(k,c3),(c3,b1)):
 delta=sub(end,start); nv=(delta[1],-delta[0]);nv=mul(1/norm(nv),nv)
 ix=int(round(float(nv[0].mid())*D));iy=int(round(float(nv[1].mid())*D));assert abs(arb(ix)-D*nv[0])<1 and abs(arb(iy)-D*nv[1])<1
 support=ix*start[0]+iy*start[1]+4;top=F(int((support*10**10).upper().ceil().unique_fmpz()),10**10);assert A(top)>support
 lines.append((ix,iy,top,'segment'))
# Additional exact support directions on the smooth pair(z+w(t-z)) boundary.
for j in range(1,32):
 w=arb_series([A(F(j,32)),arb(1)]); curve=pair(add(z,mul(w,sub(t,z))))
 pt=(curve[0][0],curve[1][0]);vel=(curve[0][1],curve[1][1]);assert norm(vel)>0
 nv=(vel[1],-vel[0]);nv=mul(1/norm(nv),nv)
 ix=int(round(float(nv[0].mid())*D));iy=int(round(float(nv[1].mid())*D));assert abs(arb(ix)-D*nv[0])<1 and abs(arb(iy)-D*nv[1])<1
 # Both boundary point and the Gibbs body lie in the unit disk, so distance <=2.
 support=ix*pt[0]+iy*pt[1]+4
 top=F(int((support*10**10).upper().ceil().unique_fmpz()),10**10);assert A(top)>support
 lines.append((ix,iy,top,'smooth'))
assert all(A(b) > norm((arb(nx),arb(ny)))/2 for nx,ny,b,_ in lines)
# Exact rational intersection of these valid supporting halfspaces, with a generous initial box.
poly=[(F(-2),F(-2)),(F(2),F(-2)),(F(2),F(2)),(F(-2),F(2))]
for nx,ny,b,name in lines:
 out=[]
 for p,q0 in zip(poly,poly[1:]+poly[:1]):
  f=nx*p[0]+ny*p[1]-b;g0=nx*q0[0]+ny*q0[1]-b
  if f<=0:out.append(p)
  if (f<0 and g0>0) or (f>0 and g0<0):
   lam=f/(f-g0);out.append((p[0]+lam*(q0[0]-p[0]),p[1]+lam*(q0[1]-p[1])))
 poly=out
assert len(poly)>3
P=sum((A((a[0]-b[0])**2+(a[1]-b[1])**2).sqrt() for a,b in zip(poly,poly[1:]+poly[:1])),arb(0));Pup=F(int((P*10**12).upper().ceil().unique_fmpz()),10**12);assert A(Pup)>P
area=F(17951783324125664260754635376011697236155558740145005910413400123365511272466575651183,21267647932558653966460912964485513216000000000000000000000000000000000000000000000000);B=F('.844082046521218581802948589770767704354');assert F(source['geometry']['cases'][1]['area']['exact'][1])==area
def area_bound(t):return (1-A(t))**2*pi/4+A(t)*(1-A(t))*A(Pup)/2+A(t)**2*A(area)
assert pi/4-A(Pup)/2+A(area)<0
assert area_bound(F(0))<A(B)<area_bound(F(1))
lo=F(0);hi=F(1);N=10**9
for _ in range(80):
 mid0=(lo+hi)/2
 if area_bound(mid0)<A(B):lo=mid0
 else:hi=mid0
T=F((lo*N).__floor__(),N);val=area_bound(T);assert val<A(B)
safe=F('.99828');safe_area=area_bound(safe);assert safe_area<A(B)
out={'safe_t':str(safe),'safe_q':str(safe/2),'safe_area':str(safe_area),'safe_gap':str((A(B)-safe_area).lower()),'perimeter_bound':str(Pup),'perimeter_interval':str(P),'support_lines':len(lines),'polygon_vertices':len(poly),'polygon':[[str(x),str(y)] for x,y in poly],'area_upper':str(area),'B':str(B),'t':str(T),'q':str(T/2),'area_at_t':str(val),'strict_gap':str((A(B)-val).lower()),'input_arc_sources':[[str(x) for x in []] for _ in arcs]}
Path(__file__).with_name('perimeter-result.json').write_text(json.dumps(out,indent=2)+'\n');print('P',P,'Pup',Pup,'t',T,'q',float(T/2),'gap',out['strict_gap'])

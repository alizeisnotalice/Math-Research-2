"""Recompute the R285 fixed-six W bounds and the independent 176/35402 crossing."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
from io import BytesIO
import json
from math import ceil
import os
from pathlib import Path
import platform
import subprocess
import sys
from zipfile import ZipFile

import flint
from flint import arb, ctx
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from geometry import ar, Spectrum, outer_area, five_area_upper, fit_five_points, fit_complete_w, p30_inside

PUBLISHED = {
    "certify_nine.py": "610e94cf22e901453bc34f77afb8f0994d9e471432cbe20498fca3b1530c9541",
    "tomar_leaf_box.py": "e22ccc0d076537dc7b46fcf40f14c13f4fa4cc11daac0de4a1dd75e870e9eee1",
    "finite-point-leaf-input.json": "b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc",
    "free-p30-reoptimized-pose.json": "21e6fceeb7f2033b69a6c2a7ae633abb26b6afd3621e32f6e6aa57f9b8770593",
    "inclusion-minimal-eleven/template.py": "1afabd291eda01c45fcaa933045476f46bd98f45e39c5adcf5a17dc2df95e2f4",
    "inclusion-minimal-eleven/hinge_bank.py": "116f6dc05ea939deb094e5697c07f3c597a8d323f85191f62f72d24bd5c8a1f4",
    "inclusion-minimal-eleven/hinge.cpp": "839fa7dc71b0bbe16b62a9c8d8602d9ba08bd3c0a17b8612c044ff8d9e3913e6",
    "repair-and-obstruction/degree93.zip": "7caccdc69a9a42b57b37faf67c0005ead3ec42b631f2ee31263f10751916a384",
    "repair-and-obstruction/cross-pentagon.zip": "ee83527bd481f70c557ee84006ccd4f2bec84d3555aaa0b896d419af9045c94b",
    "repair-and-obstruction/five-inner-points.json": "0946004f1411496a47c4ab4665f1920e3dd0fab30c579825d97f249287e7a9f6",
    "repair-and-obstruction/new-spur.zip": "7d021ab583835f2b0435bd4df0e5eeb5c1c90b519f8322fa25357a69e4473889",
    "repair-and-obstruction/illumination.zip": "5659223e36b422b7bd1b5335320b8b59e488175faaee1b9a24b7bfc440d6e0dd",
    "repair-and-obstruction/verify_illumination.py": "29df7a671fd581013e6a7e14767e23513e5a959ea8a744e05eb116a83348d3b7",
    "released-gibbs-sector/base.zip": "85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1",
    "directional-seven/six-low-continuous.zip": "8fb8f4704f2e33795ec50b4d5936cc4317987b96e36bf3d18afef32f83dcc726",
}
TREE_PARTS = {
    1205: ("df2413c532134b4853c744da6e2fecac592c106bc81d62f9832c78b0cbe96112",
           "0529338eac7b0fe9e02577cb9d2de7bbe597a3f9ae49dd96561a3c93bb8d1b4c"),
    176: ("d5367237a966b45fdc8ef8f4cac7cd63311fa1cae1a6d7cd18479a254051fd24",
          "7d77675667e5bf60ffb1fa5f266177e0e42895b334b62b829b4c42f2923ace07"),
}


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n")


def announcement(message):
    print(message, flush=True)


def source_pins(comp):
    for file, expected in PUBLISHED.items():
        assert sha(comp/file) == expected, file
    for line in (HERE/"MANIFEST.sha256").read_text().splitlines():
        digest, path = line.split("  ", 1)
        assert sha(HERE/path) == digest, path


def archive_member(path, name):
    with ZipFile(path) as z:
        return z.read(name)


def install_zip_members(archive, prefix, dest):
    for name in archive.namelist():
        if name.startswith(prefix) and not name.endswith("/"):
            relative = Path(name.removeprefix(prefix))
            assert not relative.is_absolute() and ".." not in relative.parts
            target = dest/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(name))


def pentagon(C, W):
    """Rebuild the published R280 physical centers and test every defining disk."""
    folder = W/"r280-source"
    folder.mkdir()
    with ZipFile(C/"released-gibbs-sector/base.zip") as base:
        for name in ("candidate.py", "shared.py"):
            (folder/name).write_bytes(base.read("kit/"+name))
        with ZipFile(BytesIO(base.read("kit/obstruction.zip"))) as old:
            install_zip_members(old, "barrier/comp068/", folder/"comp068")
    with ZipFile(C/"repair-and-obstruction/new-spur.zip") as source:
        install_zip_members(source, "kit/payload/", folder)
    geom = folder/"spur-proof/witness.py"
    variables = {"__file__": str(geom), "__name__": "r280_five_vertices"}
    prefix, marker, _ = geom.read_text().partition("w,e=")
    assert marker
    exec(compile(prefix, str(geom), "exec"), variables)
    A = variables["A"]
    vertices, _ = variables["body"](variables["env"], A(F(241,400)), A(-F(22,1125)))
    public = C/"repair-and-obstruction"
    source = public/"five-inner-points.json"
    cloud = read(source)
    cross_zip = public/"cross-pentagon.zip"
    reference = json.loads(archive_member(cross_zip, "spur-vertices.json"))
    assert len(vertices) == len(reference) == len(cloud["points"]) == 5
    for pt, bound in zip(vertices, reference, strict=True):
        assert all(arb(x).contains(z) for x,z in zip(bound,pt,strict=True))
    ctx.prec = 192
    Q = cloud["denominator"]
    margin = min((1-(arb(x)/Q-a)**2-(arb(y)/Q-b)**2).lower()
                 for x,y in cloud["points"] for a,b in vertices)
    assert margin > ar("9.4389e-9")
    return cloud, dict(parameters=["241/400", "-22/1125"], point_count=5,
                       minimum_squared_slack=str(margin), points_sha256=sha(source))


def origin_leaf(tree, part, idx, rec, period_nine=False):
    from tomar_leaf_box import leaf_box
    fn = tree/f"part{part:04}.npy"
    meta = tree/f"part{part:04}.json"
    assert (sha(fn), sha(meta)) == TREE_PARTS[part]
    codes = np.load(fn, allow_pickle=False)
    assert codes.dtype == np.uint8 and codes.ndim == 1
    assert codes[idx] == 253
    prefix = np.r_[1, 1+np.cumsum(np.where(codes<11,1,-1))]
    z,d = leaf_box(prefix, codes, part, idx, read(meta))
    span0=[(F(u)-F(v))*2**44 for u,v in zip(z,d,strict=True)]
    span1=[(F(u)+F(v))*2**44 for u,v in zip(z,d,strict=True)]
    assert all(x.denominator == 1 for x in span0+span1)
    span=[[int(x),int(y)] for x,y in zip(span0,span1,strict=True)]
    if "bounds" in rec:
        assert rec["bounds"] == span
    center = rec["center"]
    assert len(center)==11 and all(type(x) is int for x in center)
    for j, (u,(l,h)) in enumerate(zip(center,span,strict=True)):
        if period_nine and j == 8:
            assert not l<=u<=h
            angle = ar(F(u,2**44)) + 2*arb.pi()/9
            assert ar(F(l,2**44)) < angle < ar(F(h,2**44))
        else:
            assert l<=u<=h
    return dict(part=part, terminal=idx, terminal_code=int(codes[idx]), bounds=span,
                center=center, denominator=2**44, tree_sha256=sha(fn),
                ninefold_rotation="2*pi/9 added to coordinate 8" if period_nine else None)


def illuminate(C, W, pose, points, plan, report_name):
    path = W/report_name
    subprocess.run([sys.executable,"-I","-B",C/"repair-and-obstruction/verify_illumination.py",
                    C,pose,points,plan,path],check=True)
    return read(path)


def baseline_pentagon(C, W, six_path):
    public = C/"repair-and-obstruction"
    arc = public/"illumination.zip"
    plan = W/"five-inner-fixed685-plan.json"
    plan.write_bytes(archive_member(arc, "plan-fixed685.json"))
    result = illuminate(C,W,six_path,public/"five-inner-points.json",plan,"five-inner-fixed685.json")
    assert result == json.loads(archive_member(arc,"receipt-fixed685.json"))
    assert F(result["target"]) == F(".837685") and result["cells"] == 3072 and result["failed"] == 0
    return result


def hinge(C, W, cache, clang, center):
    from hinge_bank import host, write_poly, S
    bank = W/"p30-angle-bank.dat"
    subprocess.run([sys.executable,"-I","-B",HERE/"basin/angle_intersection.py",
                    C/"finite-point-leaf-input.json","4096",bank],check=True)
    bank_digest = sha(bank)
    assert bank_digest == "13fdbf455046ce9b1a89eccb062da4929f41c85a9c2b3f3dd70ad7ecd4c70d90"
    r=F(".00046")
    radii=[ceil(r*2**44*(5 if j in (2,5,8) else 1)) for j in range(11)]
    box=[[x-d,x+d] for x,d in zip(center,radii,strict=True)]
    H=host(C,box,384)
    assert len(H)==523
    data=W/"p30-host-box.dat"
    with data.open("w") as f:
        f.write(f"{S} 1\n")
        write_poly(f,H)
    d = sha(data)
    assert d == "30e266ffe2a9d0392eca481b0d0c72fa51d21704fc4f239f7982d2745996d79f"
    source=C/"inclusion-minimal-eleven/hinge.cpp"
    executable=W/"integer-hinge"
    work_env = dict(os.environ, TMPDIR=str(W), TMP=str(W), TEMP=str(W))
    cmd = [clang,"-std=c++17","-O3","-fsanitize=undefined","-fsanitize-trap=undefined",
           f"-fmodules-cache-path={cache}",source,"-o",executable]
    subprocess.run(cmd,cwd=W,env=work_env,check=True)
    done = subprocess.check_output([executable,data,bank,"837550"],cwd=W,text=True)
    (W/"integer-hinge.log").write_text(done)
    assert list(map(int,done.split())) == [0,8192,8192,-1], done
    version = subprocess.check_output([clang,"--version"],text=True).splitlines()[0]
    return dict(target="837550/1000000", translation_half_width=str(r), angle_half_width=str(5*r),
                actual_dyadic_box=box, host_vertices=len(H), angular_cells_per_hand=4096,
                integer_verified_cells=8192, bank_sha256=bank_digest, host_sha256=d,
                source_sha256=sha(source), compiler=version)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("computation",type=Path)
    p.add_argument("tree",type=Path)
    p.add_argument("work",type=Path)
    p.add_argument("cache",type=Path)
    p.add_argument("--clang",default="clang++")
    args=p.parse_args()
    assert __debug__
    C,T,W,cache=[x.resolve() for x in (args.computation,args.tree,args.work,args.cache)]
    source_pins(C)
    W.mkdir(parents=True,exist_ok=False)
    cache.mkdir(parents=True,exist_ok=True)
    sys.path[:0]=[str(C/"inclusion-minimal-eleven"),str(C)]
    from template import build

    six_archive=C/"directional-seven/six-low-continuous.zip"
    six_member=archive_member(six_archive,"true-best-pose.json")
    linked=archive_member(C/"repair-and-obstruction/cross-pentagon.zip","true-best-pose.json")
    assert six_member==linked
    six=json.loads(six_member)
    six_path=W/"six-pose.json"
    six_path.write_bytes(six_member)
    assert sha(six_path)=="f657d2314e8a460f4baac61ee88589ff80f8b854d9ac51fe5c65cb99dccf19e6"
    five=read(HERE/"basin/host.json")
    ctx.prec=192
    root1=origin_leaf(T,1205,152529,six,True)
    root2=origin_leaf(T,176,35402,five)
    announcement("Both original leaves reconstructed, including the ninefold phase representative")
    supp=archive_member(C/"repair-and-obstruction/degree93.zip","degree93.json")
    spectrum_sha=sha256(supp).hexdigest()
    assert spectrum_sha=="f791b04432770b59ab2e339c548a5d578d897d9816a56908855327aec0e19537"
    spectrum=Spectrum(json.loads(supp))
    curve=spectrum.curvature()
    material_path=HERE/"w93/inner93.json"
    inner=spectrum.verify_inner(read(material_path))
    announcement("Published degree 93 and all 256 genuine rational inner points verified")
    cloud, pent=pentagon(C,W)
    announcement("R280's five physical centers and their five exact interior points verified")
    poly,d=build(C,False,384,True,box=[[x,x] for x in six["center"]])
    h=read(HERE/"w93/host-inner.json")
    assert d==h["denominator"] and poly==[tuple(row) for row in h["vertices"]]
    lower=illuminate(C,W,six_path,material_path,HERE/"w93/illum-.838247.json","six-w-lower.json")
    assert lower==read(HERE/"w93/illum-ver-.838247.json")
    assert F(lower["target"])==F(".838247") and lower["cells"]==16384 and lower["failed"]==0
    ctx.prec=192
    upper_source=read(HERE/"w93/upper-best-4096.json")
    assert upper_source["M"]==4096
    points93=read(C/"finite-point-leaf-input.json")
    p30_gap=p30_inside(poly,d,six["point_pose"],points93)
    upper=outer_area(six["center"],six["point_pose"],points93,spectrum,upper_source["pose"],4096)
    pent_lower=baseline_pentagon(C,W,six_path)
    announcement("Fixed six-body W minimum strictly between .838247 and .839503800")
    hi=five_area_upper(build,C,five)
    poly,d=build(C,False,384,True,box=[[x,x] for x in five["center"]])
    pose=read(HERE/"basin/pent-fit.json")
    assert pose["host_leaf"]==five["leaf"]=="176/35402"
    gap=fit_five_points(poly,d,cloud,pose)
    crossing=fit_complete_w(poly,d,hi,spectrum,five["center"],read(HERE/"basin/w93-pose-source.json"),
                            read(HERE/"basin/full-w-fitcert.json"))
    crossing["minimum_five_point_determinant"]=gap
    announcement("176/35402: same real five-body pose, full W and five R280 points fit below .837324828897371")
    integer=hinge(C,W,cache,args.clang,five["center"])
    report=dict(status="PASS", r280_W=dict(sha256=spectrum_sha, curvature=curve, finite_inner=inner),
                r280_pentagon=pent, fixed_six=dict(source_sha256=sha(six_path),leaf=root1,lower=lower,upper=upper,
                                                  historical_p30_inside_margin=p30_gap,pentagon_points_lower=pent_lower),
                basin=dict(leaf=root2,whole_W_and_five_points=crossing,p30_closed_neighborhood=integer),
                python=platform.python_version(),flint=flint.__version__,numpy=np.__version__)
    save(W/"receipt.json",report)
    announcement("PASS, including all 8192 integer P30 angle-intersection cells")


if __name__=="__main__":
    main()

# R286 两个真姿态的交叉证书

设 \(W\) 为第 280 轮公开的严格正曲率 93 阶宽一体，\(Q\) 为同轮五角体 \(P(241/400,-22/1125)\) 的五个有理内点。两处几何都使用同一个 \(W\) 和同一个 \(Q\)。两组宿主姿态不同。

| 姿态或邻域 | 可重算结论 |
|---|---|
| 1205/152529 的固定六体真姿态 | 让完整 \(W\) 自由平移、旋转、反射，与固定六体作凸包所得最小面积严格在 \((.838247,.839503799377581)\) 中 |
| 同一个固定六体姿态 | 单独加入任意摆放的 \(Q\)，面积大于 .837685。历史 P30 已包含在其余五曲体的真凸包内 |
| 176/35402 的固定真五体姿态 | 完整 \(W\) 和 \(Q\) 可各用一套摆放，同时加入同一个五体凸包。严格面积小于 .837324828897371 |
| 176/35402 中心的 11 维闭邻域 | 五体平移半宽 .00046，角半宽 .0023，向外取 dyadic 格。加入任意摆放的完整历史 P30 后，面积大于 .83755。两种手性各 4096 个闭角格全部通过整数核 |

1205/152529 的公布姿态只在索引 8 的正九弧体角度采用了另一同余代表。把实际角度加 \(2\pi/9\)，九重对称保证几何集合相同，且该坐标严格进入原闭叶。另外十个 dyadic 坐标直接在闭叶内。176/35402 的十一坐标直接在另一原闭叶内。最后一行证明整个指定闭邻域，也适用于它与原叶的交集；原叶其余部分仍开放。第一行固定全部六体的真实相对姿态。第三行使用五个点和完整 \(W\)，完整五角体与历史 P30 不属于该面积上端的输入。

## 可移植重放

```sh
python -I -B verify.py COMPUTATION TOMAR_TREE NEW_WORK CLANG_CACHE
```

Python 需要 NumPy 与 python-flint。默认编译器为 `clang++`，可用 `--clang /path/to/clang++` 指定。`NEW_WORK` 是尚未创建的目录，重放在其中保存再生材料、编译程序、真实积分与完整回执 `receipt.json`。`CLANG_CACHE` 是编译器模块缓存目录。源数据只读取。`verify.py` 按指纹核对输入并重新运算，不需要读任何其他工位。

## 外部材料

- `TOMAR_TREE` 只需 `part0176.json`、`part0176.npy`、`part1205.json`、`part1205.npy`。文件应来自冻结的 `cert11d_08366`。直接解码原预序树，再验证全部闭端点与姿态。
- `COMPUTATION` 所需最小外部清单为 `verify.py` 的 `PUBLISHED`。公开 `directional-seven/six-low-continuous.zip` 提供六体姿态；`repair-and-obstruction/cross-pentagon.zip` 绑定该姿态与 R280 的五个实际圆心。`repair-and-obstruction/degree93.zip` 提供完整 93 阶有理曲率谱；`new-spur.zip` 与 `released-gibbs-sector/base.zip` 提供重建同一个五角体的原物理几何。公开的 `illumination.zip` 和 `verify_illumination.py` 直接用于 R280 五点及新 W 下界的实际重放。
- `finite-point-leaf-input.json` 是历史 P30 的 30 点输入。`inclusion-minimal-eleven` 的模板、整数内包及 C++ 核均使用公开文件。5.5 MB 角表、外部编译产物、全树其他分块、浮点筛选器及原根有限试算均无需归档。
- 本包冻结的 W 下界行、材料和可行姿态来自 `w93-fixedhost-bounds.zip`，SHA-256 `7197311a6c0007224bc688af5445004c2c37a04637ad8ceebba2ce920037837f`。176/35402 的中心、五点定姿和旋转格构造来自 `basin176-cross.zip`，SHA-256 `7983b371dc584c1c34e1430893b0fdfe1c974a97b808a6b0124eaf457a43911a`。完整 \(W\) 的有理半角参数及平移来自该盆地的原 Mac 证书，已单独冻结在 `basin/w93-pose-source.json`，原曲线复算覆盖所有 500 个面。

双环境完整重放使用 Python 3.12.14 和 3.13.18、python-flint 0.9.0、Apple Clang 21。两环境的数学回执一致，见 [参考回执](expected-receipt.json)。

[证明说明](PROOF.md) · [归档指纹](MANIFEST.sha256)


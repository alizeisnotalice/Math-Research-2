"""Exact R286 support, point-containment and area calculations."""
from fractions import Fraction as F
from math import isqrt
from flint import arb, ctx


def ar(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def edges(poly):
    return zip(poly, poly[1:] + poly[:1], strict=True)


def unit(theta):
    s, c = theta.sin_cos()
    return c, s


def rotate(z, u):
    return z[0] * u[0] - z[1] * u[1], z[0] * u[1] + z[1] * u[0]


class Spectrum:
    def __init__(self, data):
        self.modes = [(n, F(a), F(b)) for n, a, b in data["curvature_modes"]]
        assert data["degree"] == 93
        assert [n for n, _, _ in self.modes] == list(range(3, 94, 2))
        assert any(self.modes[-1][1:])
        self.rho = [(n, ar(a), ar(b)) for n, a, b in self.modes]
        self.h = [(n, ar(a / (1-n*n)), ar(b / (1-n*n))) for n, a, b in self.modes]

    def curvature(self):
        """One closed half-circle and antiperiodicity cover the true profile."""
        grid = 32768
        pi = arb.pi()
        d2 = ar(sum(n*n*(abs(a)+abs(b)) for n, a, b in self.modes))
        largest = arb(0)
        for j in range(grid + 1):
            theta = pi * j / grid
            z = unit(3 * theta)
            step = unit(2 * theta)
            g = arb(0)
            for _, a, b in self.rho:
                g += a*z[0] + b*z[1]
                z = rotate(z, step)
            largest = max(largest, abs(g).upper())
        biggest = (largest + d2*(pi/grid)**2/8).upper()
        lo, hi = (ar(F(1,2))-biggest).lower(), (ar(F(1,2))+biggest).upper()
        assert lo > ar(".0000225") and hi < ar(".9999775")
        return dict(grid=grid, strict_interval=list(map(str, (lo, hi))))

    def material(self, theta):
        n = unit(theta)
        h, dh = arb("0.5"), arb(0)
        for k, a, b in self.h:
            c, s = unit(k*theta)
            h += a*c+b*s
            dh += k*(b*c-a*s)
        return h*n[0]-dh*n[1], h*n[1]+dh*n[0]

    def support(self, u):
        step = rotate(u, u)
        z = rotate(u, step)
        h = arb("0.5")
        for _, a, b in self.h:
            h += a*z[0] + b*z[1]
            z = rotate(z, step)
        return h

    def verify_inner(self, table):
        p = table["points"]
        q = table["denominator"]
        assert q == 10**12 and len(p) == 256
        inradius = F(1, 2)-sum((abs(a)+abs(b))/F(n*n-1) for n,a,b in self.modes)
        assert inradius > F(".45074883")
        scale = F(".999999")
        assert ar(inradius * (1-scale)) > arb(2).sqrt()/q
        for j, row in enumerate(p):
            real = self.material(2*arb.pi()*j/len(p))
            assert all(abs(ar(scale)*z*q-k) < 1 for z,k in zip(real,row,strict=True))
        squared = max((x-u)**2 + (y-v)**2 for x,y in p for u,v in p)
        assert squared <= q*q
        return dict(count=len(p), diameter_squared=str(F(squared,q*q)),
                    centered_inradius_lower=str(inradius))


def placed_curves(center):
    z = [ar(F(x, 2**44)) for x in center]
    assert len(z) == 11
    pi = arb.pi()
    pieces = []
    for n, j in ((3, None), (5, 2), (7, 5), (9, 8)):
        phase, t = (arb(0), z[:2]) if j is None else (z[j], z[j+1:j+3])
        r = 1/(2*(pi/(2*n)).cos())
        v = []
        for k in range(n):
            axis = unit(phase + 2*pi*k/n)
            v.append(((t[0]+r*axis[0], t[1]+r*axis[1]), (-axis[0], -axis[1])))
        pieces.append(((pi/(2*n)).cos(), v))
    return pieces


def five_support(pieces, normal):
    values = [arb("0.5")]
    for cutoff, terms in pieces:
        for center, opposite in terms:
            height = dot(normal, center)
            values.append(height)
            # Every possible support from a circular arc is retained, including
            # the cases where the interval comparison touches an endpoint.
            if not dot(normal, opposite) < cutoff:
                values.append(1+height)
    return values


def orthogonal_from_tangent(t):
    t = F(t)
    return ar((1-t*t)/(1+t*t)), ar(2*t/(1+t*t))


def support_placed(spectrum, n, orthogonal, translation, hand):
    local = rotate((orthogonal[0], -orthogonal[1]), n)
    return spectrum.support((local[0], hand*local[1])) + dot(n, translation)


def placed_p30(point_pose, point_data):
    theta = ar(point_pose[2])
    orientation = unit(theta)
    tx, ty = map(ar, point_pose[:2])
    q = point_data["denominator"]
    original30 = []
    for x, y in point_data["points"]:
        zx, zy = rotate(orientation, (ar(F(x,q)), ar(F(y,q))))
        original30.append((tx+zx, ty+zy))
    return original30


def p30_inside(poly, d, point_pose, point_data):
    points = placed_p30(point_pose, point_data)
    least = arb(1)
    for (x,y),(u,v) in edges(poly):
        normal = v-y,x-u
        length = arb(dot(normal,normal)).sqrt()
        offset = ar(F(dot(normal,(x,y)),d))
        row = min(((offset-dot(normal,p))/length).lower() for p in points)
        least = min(least,row)
    assert least > ar(".000213526157")
    return str(least)


def outer_area(center, point_pose, point_data, spectrum, wpose, count):
    """Outer supporting polygon for the fixed six true inputs plus all of W."""
    pi = arb.pi()
    pieces = placed_curves(center)
    original30 = placed_p30(point_pose, point_data)
    phase, tx, ty = map(ar, wpose)
    transform = unit(phase)
    ns, hs = [], []
    for j in range(count):
        n = unit(2*pi*j/count)
        ns.append(n)
        vals = five_support(pieces,n)
        vals.extend(dot(n,p) for p in original30)
        vals.append(support_placed(spectrum,n,transform,(tx,ty),1))
        hs.append(max(v.upper() for v in vals)+ar("1e-20"))
    v = []
    for i in range(count):
        j = (i+1)%count
        x,y = ns[i]
        u,w = ns[j]
        h,k = hs[i],hs[j]
        divisor = cross(ns[i],ns[j])
        assert divisor > 0
        v.append(((h*w-y*k)/divisor,(x*k-h*u)/divisor))
    for i, n in enumerate(ns):
        p,q = v[i-1],v[i]
        assert dot((-n[1],n[0]), (q[0]-p[0],q[1]-p[1])) > 0
    area = (sum(cross(p,q) for p,q in edges(v))/2).upper()
    assert area < ar(".839503799377581")
    return dict(grid=count, hand=1, pose=wpose, area_upper=str(area))


def five_area_upper(build, comp, record):
    """Rebuild the dense material and bound the true five-curve hull by Steiner."""
    k = record["k"]
    assert k == 1024
    center = record["center"]
    poly, d = build(comp, False, k, True, box=[[x,x] for x in center])
    s = d-4
    twice = sum(cross(p,q) for p,q in edges(poly))
    lo = F(twice,2*d*d)
    # Every radius-one arc's sample step is <= pi/(3k); the disk's is pi/(4k).
    # The largest circular sagitta is <= pi^2/(72k^2).
    error = F(2,s)+F(22,7)**2/(72*k*k)
    p_upper = F(sum(isqrt((x-u)**2+(y-v)**2)+1 for (x,y),(u,v) in edges(poly)),s)
    hi = F(twice,2*s*s)+error*p_upper+F(22,7)*error*error
    assert lo == F(record["area_lower"]) and hi == F(record["area_upper"])
    return hi


def fit_five_points(poly, d, cloud, pose):
    """Strict exact determinant test for the five R280 interior points."""
    assert pose["point_count"] == len(cloud["points"]) == 5
    assert pose["vertices"] == len(poly) == 500
    q = cloud["denominator"]
    t = F(pose["tan_half_angle"])
    hand = pose["hand"]
    assert hand in (-1, 1)
    co, si = (1-t*t)/(1+t*t),2*t/(1+t*t)
    tx,ty = map(F,pose["translation"])
    gaps = []
    for a,b in cloud["points"]:
        x,y = F(a,q),F(hand*b,q)
        X,Y = d*(co*x-si*y+tx),d*(si*x+co*y+ty)
        gaps.extend((u-p)*(Y-r)-(v-r)*(X-p) for (p,r),(u,v) in edges(poly))
    m = min(gaps)
    assert m>0 and m==F(pose["min_edge_determinant"])
    return str(m)


def fit_complete_w(poly, d, high, spectrum, center, pose, expected):
    """W fits in the inner polygon enlarged by radius 1e-8."""
    assert pose["leaf"] == "176/35402" and expected["facets"] == len(poly)
    ctx.prec = 192
    hand = pose["hand"]
    assert hand == expected["hand"] and hand in (-1, 1)
    t = orthogonal_from_tangent(pose["t"])
    tx = F(pose["tx"])+F(expected["translation_correction"][0])
    ty = F(pose["ty"])+F(expected["translation_correction"][1])
    normals, gaps = [], []
    for (x,y),(u,v) in edges(poly):
        nx,ny = v-y,x-u
        normal = (nx,ny)
        normals.append(normal)
        L = arb(dot(normal, normal)).sqrt()
        nn = (arb(nx)/L,arb(ny)/L)
        gaps.append((ar(F(nx*x+ny*y,d))/L-
                     support_placed(spectrum,nn,t,(ar(tx),ar(ty)),hand)).lower())
    delta = ar(expected["delta"])
    least = min(gaps)
    assert F(expected["delta"]) == F("1e-8") and least > -delta/2
    for a,b in edges(normals):
        w = dot(a,b)
        assert cross(a,b)>0 and (w>=0 or 4*w*w<dot(a,a)*dot(b,b))
    # Every true curve is in the unit disk, giving perimeter <= 2*pi.
    for n,j in ((3,0),(5,3),(7,6),(9,9)):
        p = [ar(F(center[j+k],2**44)) for k in (0,1)]
        assert dot(p,p)<ar(".16")
        assert 1/(2*(arb.pi()/(2*n)).cos())<ar(".6")
    upper = (ar(high)+2*arb.pi()*delta+arb.pi()*delta**2).upper()
    assert upper < ar(".837324828897371")
    return dict(facets=len(poly), lowest_gap=str(least), delta=expected["delta"],
                w_pose=dict(hand=hand,tan_half_angle=pose["t"],translation=[str(tx),str(ty)]),
                five_body_area_upper=str(high), union_area_upper=str(upper))

"""Compose .01150 cells 24–31 and 38–41 after strict replays."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from flint import arb,ctx

p=ArgumentParser(description=__doc__)
p.add_argument('work',type=Path);p.add_argument('output',type=Path)
a=p.parse_args();ctx.prec=160
work=a.work.resolve();load=lambda p:json.loads(p.read_bytes());sha=lambda p:sha256(p.read_bytes()).hexdigest()
area=load(work/'01150-area.json');physical=area['parameters'];chart=area['chart']; geom=chart['geometry_sha256']
minimum_keys=('root_margin_lower','placement_margin_lower')
cap=next(x for x in area['geometry']['cases'] if x['label']=='eleven'); assert F(cap['area']['exact'][1])<F('.844090000000')
retreat=F('.00000009488');assert retreat>F(cap['transfer_cost_upper'])
scales_path=work/'01150-partition-monotone.json';scales=load(scales_path)
assert scales['complete'] and scales['geometry_sha256']==geom and scales['physical']==physical
assert scales['monotone_F_S_across_nested_blocks'] and [r['bin'] for r in scales['results']]==list(range(38,42))


def common(pth,j):
    r=load(pth)
    assert r['complete'] and r['all_passed'] and r['geometry_sha256']==geom and r['physical_parameters']==physical
    assert F(r['EH_tightening']['retreat'])==retreat and r['reachable'][str(j)]==chart['reference_ranges'][str(j)]
    return r


def span(rows):
    return [i for x,y in rows for i in range(x,y)]


def blocks(step):
    return [[i,min(i+step,75)] for i in range(0,75,step)]


def checked_min(rows):
    assert rows and all(x['positive'] and all(arb(x['row'][k])>0 for k in minimum_keys) for x in rows)
    return {k:str(min(arb(x['row'][k]).lower() for x in rows)) for k in minimum_keys}

summary=[]
for j in range(24,32):
    pth=work/f'01150-j{j}-slopes.json';r=common(pth,j)
    assert r['synchronized'] and r['parameters']['bins']==[j] and F(r['parameters']['cut'])==F('-.012')
    assert r['source_hashes']['ordered_state.py'] in [sha(work/n) for n in ('ordered_state.py','ordered_state_v1.py')]
    assert r['source_hashes']['certify_derivative_synchronized.py'] in [sha(work/n) for n in ('certify_derivative_synchronized.py','certify_derivative_synchronized_v1.py')]
    groups={}
    for row in r['rows']:
        c=row['counts'];assert row['bin']==row['row']['reference_bin']==j and sum(c)==5
        k=row['orientation'],row['initial_derivative_sign'],tuple(c)
        groups.setdefault(k,[]).append(row['row']['subcells'])
    for o in (0,1):
        for s in (-1,1):
            model=groups[o,s,(0,5)]
            assert span(model)==list(range(75)) and all(groups[o,s,(k,5-k)]==model for k in range(6))
    assert len(groups)==24
    summary.append(dict(bin=j,classes=len(groups),blocks=len(r['rows']),minima=checked_min(r['rows']),
                        sha256={pth.name:sha(pth)}))

for j in range(38,42):
    pp=(work/(f'01150-j{j}-easy.json' if j==39 else '01150-38-40-41-easy.json'),work/f'01150-j{j}-tightcap.json')
    p,s=[common(path,j) for path in pp]
    for d in (p,s):
        for fn in ('sharp_first_hit.py','ordered_state.py','certify_ordered_direct_mixed.py'):
            assert d['source_hashes'][fn]==sha(work/fn)
    expected={(o,(k,5-k),('0','1'),False):blocks(15) for o in (0,1) for k in range(6) if (o,k)!=(0,5)}
    residual={(0,(5,0),('0','1/2'),False):blocks(5)}
    residual.update({(0,(k,5-k,0,0),('1/2','1'),False):blocks(5) for k in range(5)})
    if j==39:
        residual.update({(0,(k,5-k,0,0,0,0,0,0),('1/2','1'),True):blocks(1) for k in range(6)})
    else:
        residual[(0,(5,0,0,0),('1/2','1'),True)]=blocks(1)
    collected=[]
    for raw,target in ((p,expected),(s,residual)):
        rows=[a for a in raw['rows'] if a['bin']==j]; actual={}
        for item in rows:
            row=item['row']; assert row['reference_bin']==j
            key=item['orientation'],tuple(item['counts']),tuple(item['e_class']),item['tighten_first']
            actual.setdefault(key,[]).append(row['subcells'])
        assert actual==target
        collected+=rows
    summary.append(dict(bin=j,classes=len(expected)+len(residual),blocks=len(collected),minima=checked_min(collected),
                        sha256={x.name:sha(x) for x in pp}))
result=dict(complete=True,geometry_sha256=geom,parameters=physical,subcells=900,bins=summary,
            min_margins={k:str(min(arb(r['minima'][k]).lower() for r in summary)) for k in minimum_keys},
            area_upper=cap['area']['decimal'][1],scales_sha256=sha(scales_path),source_sha256=sha(Path(__file__)))
a.output.write_text(json.dumps(result,indent=2)+'\n');print(result['subcells'],result['min_margins'])

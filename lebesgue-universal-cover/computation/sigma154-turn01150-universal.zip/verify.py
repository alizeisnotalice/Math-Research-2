"""Reconstruct the cap and check an exhaustive assignment of its physical cells."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from subprocess import run
import json
import sys

from flint import arb, ctx

KIT = Path(__file__).resolve().parent
sys.path.insert(0, str(KIT))
from replay import digest, indexed_files, read, source_recipe

EARLY = KIT/'early'
MID = KIT/'middle'
EXTRA = KIT/'extra'
PHYS = 'sigma154-turn01150-physical.json'
EXTRA_J = set(range(12,24)) | set(range(32,38)) | set(range(42,70))
MID_J = set(range(24,32)) | set(range(38,42))


def replay_audit(script, args, expected, work):
    out = work/expected.name
    run([sys.executable, '-I', '-B', str(script), *map(str,args), str(out)], check=True,stdout=sys.stderr)
    assert out.read_bytes() == expected.read_bytes(), expected.name


def checked_source(receipt, sources, cfg, geo, j, cost, original_ranges):
    rec = read(receipt)
    runner, data = source_recipe(rec, sources)
    spec = rec['parameters']
    if 'physical' in spec:
        assert spec['physical'] == PHYS and read(data[PHYS]) == cfg
        assert rec['physical_parameters'] == cfg and rec['geometry_sha256'] == geo
        assert rec['reachable'][str(j)] == original_ranges
        assert rec['EH_tightening']['label'].startswith('U1-Te')
        assert F(rec['EH_tightening']['retreat']) == F(spec['retreat']) > cost
        params, = [n for n in data if n.endswith('.json') and n!=PHYS]
        assert read(data[params]) == spec
    else:
        assert runner == 'certify_sigma_jet_bracket.py'
        assert all(spec[k] == v for k,v in cfg.items())
    return rec


def check_mid_rows(receipt, j):
    spec=receipt['parameters']
    for item in receipt['rows']:
        if item['bin'] != j:
            continue
        row=item['row']
        assert row['reference_bin']==j and item['positive']
        assert all(arb(row[k]).lower()>0 for k in ('placement_margin_lower','root_margin_lower'))
        bracket = list(map(F,row['bracket']))
        assert bracket[0] < bracket[1]
        if 'cut' in spec:
            side=item['initial_derivative_sign']
            assert side == row['anchor_comparison_sign'] and side in (-1,1)
            assert F(row['anchor_degrees'])==0 and F(row['anchor_threshold'])==-F(spec['cut'])
            options=spec['low_brackets' if side==-1 else 'high_brackets']
            assert any(bracket==list(map(F,o[:2])) for o in options)
        else:
            cls, = [c for c in spec['classes']
                    if c['orientation']==item['orientation'] and c['counts']==item['counts']
                    and list(map(F,c.get('e_class',['0','1'])))==list(map(F,item['e_class']))
                    and bool(c.get('tighten_first',spec.get('tighten_first',False)))==item['tighten_first']]
            assert any(bracket==list(map(F,o[:2])) and row['pose']==o[2:] for o in cls['brackets'])


def check(comp, work):
    assert __debug__
    work.mkdir(exist_ok=True,parents=True)
    inputs=read(KIT/'evidence-hashes.json')
    for f,h in inputs.items(): assert digest(KIT/f)==h,f
    for f,h in read(KIT/'common-sources.json').items():
        assert digest(comp/f)==h,f
    sys.path.insert(0,str(comp))
    import certify_sigma154_deeper_composition as base
    ctx.prec=160
    cfg=read(EARLY/PHYS)
    assert cfg==read(MID/PHYS)=={'sigma_degrees':'1.54','line':['.429','.01150'],
                                  'physical_parameters':['.313','.353','.0136']}
    chart, normal=base.physical_chart(comp,cfg)
    ctx.prec=160
    measure=base.area_geometry(comp,comp,cfg,normal)
    physical=read(MID/'01150-area.json')
    assert physical['parameters']==cfg and physical['source_sha256']==digest(comp/'certify_sigma154_deeper_composition.py')
    assert json.loads(json.dumps(chart))==physical['chart'] and measure==physical['geometry']
    ranges=chart['reference_ranges']
    assert set(ranges)==set(range(70)) and chart['reference_subcells']==5183
    geo=chart['geometry_sha256']
    case,=[c for c in measure['cases'] if c['label']=='eleven']
    cost=F(case['transfer_cost_upper'])
    assert F(case['area']['exact'][1])<F(case['area']['decimal'][1])<F('.84409')
    replay_audit(EARLY/'audit_early.py',[comp,MID/'01150-area.json'],EARLY/'early-composed.json',work)
    replay_audit(MID/'audit_crossdepth_mid.py',[MID],MID/'01150-mid-composed.json',work)
    replay_audit(KIT/'check_nested.py',[comp],KIT/'nested-budget-proof.json',work)
    replay_audit(KIT/'check_chart.py',[comp],KIT/'endpoint-hulls.json',work)
    hulls=read(KIT/'endpoint-hulls.json')
    assert hulls['physical']==cfg and hulls['geometry_sha256']==geo
    fibre=KIT/'partner-proof'
    assert digest(fibre/'sharp_first_hit.py')==digest(EXTRA/'kernels'/'partner'/'sharp_first_hit.py')
    replay_audit(fibre/'check_partner.py',[comp],fibre/'partner-budgets.json',work)
    nested=read(KIT/'nested-budget-proof.json')
    assert nested['geometry_sha256']==geo and nested['parameters']==cfg
    scale=work/'01150-partition-monotone.json'
    run([sys.executable,'-I','-B',str(MID/'check_partition_monotone.py'),str(comp),str(scale),
         '38','39','40','41'],check=True,stdout=sys.stderr)
    assert scale.read_bytes()==(MID/scale.name).read_bytes()
    sources=indexed_files(comp)
    selections={}
    def add(j,root,pose,receipts,folder):
        assert j not in selections
        assert arb(root).lower()>0 and arb(pose).lower()>0
        bindings={}
        for f,h in receipts.items():
            p=folder/f
            assert digest(p)==h,(j,f)
            raw=read(p)
            if 'source_hashes' in raw:
                rec=checked_source(p,sources,cfg,geo,j,cost,ranges[j])
                if folder==MID:check_mid_rows(rec,j)
            bindings[str(p.relative_to(KIT))]=h
        selections[j]={'root':root,'pose':pose,'sources':bindings,
                       'subcells':sum(b-a for a,b in ranges[j])}
    early=read(EARLY/'early-composed.json')
    assert early['geometry_sha256']==geo and early['physical']==cfg
    for tag,v in early['bins'].items():
        add(int(tag),v['root'],v['pose'],{v['receipt']:v['sha256']},EARLY)
    assert set(selections)==set(range(12))
    mid=read(MID/'01150-mid-composed.json')
    assert mid['geometry_sha256']==geo and mid['parameters']==cfg and {r['bin'] for r in mid['bins']}==MID_J
    for r in mid['bins']:
        add(r['bin'],r['minima']['root_margin_lower'],r['minima']['placement_margin_lower'],r['sha256'],MID)
    extra=read(EXTRA/'01150-extra-partition-final.json')
    assert extra['complete'] and extra['geometry_sha256']==geo and extra['parameters']==cfg
    assert {r['bin'] for r in extra['bins']}==EXTRA_J
    run([sys.executable,'-I','-B',str(KIT/'verify_extra.py'),str(comp),str(work)],check=True,stdout=sys.stderr)
    for r in extra['bins']:
        add(r['bin'],r['minima']['root_margin_lower'],r['minima']['placement_margin_lower'],r['sha256'],EXTRA)
    assert set(selections)==set(range(70)) and sum(v['subcells'] for v in selections.values())==5183
    assert sum(selections[j]['subcells'] for j in EXTRA_J)==extra['subcells']
    root,j=min((arb(v['root']).lower(),j) for j,v in selections.items())
    pose,k=min((arb(v['pose']).lower(),j) for j,v in selections.items())
    return {'complete':True,'parameters':cfg,'chart':chart,'eleven_EH':case,'root_minimum':str(root),
            'limiting_root_bin':j,'retained_pose_minimum':str(pose),'limiting_pose_bin':k,
            'bins':selections,'inputs_sha256':digest(KIT/'evidence-hashes.json')}


if __name__=='__main__':
    p=ArgumentParser()
    for arg in ('comp','work','output'):p.add_argument(arg,type=Path)
    a=p.parse_args()
    result=check(a.comp.resolve(),a.work.resolve())
    a.output.write_text(json.dumps(result,indent=1,sort_keys=True)+'\n')

"""Regenerate selected raw interval receipts in isolated directories with the original module revisions."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from functools import lru_cache
import json
import shutil
import subprocess
import sys

KIT = Path(__file__).resolve().parent
RUNNERS = {'certify_synchronized.py', 'certify_derivative_synchronized.py',
           'certify_ordered_direct.py', 'certify_ordered_direct_mixed.py', 'certify_sigma_jet_bracket.py'}


def read(path):
    return json.loads(path.read_bytes())


@lru_cache(maxsize=None)
def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def indexed_files(comp):
    result = {}
    for path in sorted(KIT.rglob('*')):
        if path.is_file() and path.suffix in ('.py', '.json'):
            result.setdefault(digest(path), path)
    for path in sorted(comp.glob('*.py')):
        result.setdefault(digest(path), path)
    return result


def raw_receipts():
    paths = list((KIT/'early').glob('*-certificate.json'))
    mid = read(KIT/'middle'/'01150-mid-composed.json')
    paths.extend({KIT/'middle'/f for row in mid['bins'] for f in row['sha256']})
    extra = KIT/'extra'/'01150-extra-partition-final.json'
    if extra.exists():
        paths.extend({KIT/'extra'/f for row in read(extra)['bins'] for f in row['sha256']
                      if 'source_hashes' in read(KIT/'extra'/f)})
    return sorted(paths, key=lambda p: p.name)


def source_recipe(receipt, sources):
    hashes = receipt['source_hashes']
    runner, = RUNNERS & hashes.keys()
    resolved = {name: sources[h] for name,h in hashes.items()}
    return runner, resolved


def replay(comp, work, selected):
    sources = indexed_files(comp)
    for p in selected:
        rec = read(p)
        runner, resolved = source_recipe(rec, sources)
        staging = work/p.stem
        staging.mkdir(parents=True, exist_ok=True)
        for name, path in resolved.items():
            if path.parent != comp or name == runner:
                shutil.copyfile(path, staging/name)
        # Component modules are imported from the common computation tree.
        # Comp's ordinary jet generator needs this tree on its initial import path.
        common = comp/runner
        execute = common if common.is_file() and digest(common) == rec['source_hashes'][runner] else staging/runner
        names = [f for f in resolved if f.endswith('.json') and f != 'sigma154-turn01150-physical.json']
        if names:
            label, = names
            cfg = staging/label
        else:
            cfg = staging/'input.json'
            cfg.write_text(json.dumps(rec['parameters'])+'\n')
        assert read(cfg) == rec['parameters']
        args = [str(comp)]
        if runner in ('certify_ordered_direct.py', 'certify_ordered_direct_mixed.py'):
            args.append(str(staging))
        output = staging/'output.json'
        subprocess.run([sys.executable, '-E', '-B', str(execute), *args, str(cfg), str(output)], check=True)
        fresh = read(output)
        fields = set(rec) - {'python'}
        assert set(fresh) == set(rec)
        for key in fields:
            assert fresh[key] == rec[key], (p.name, key)
        print('verified', p.name, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('comp',type=Path)
    parser.add_argument('work',type=Path)
    parser.add_argument('--list',action='store_true')
    parser.add_argument('--only',nargs='+')
    args = parser.parse_args()
    paths = raw_receipts()
    if args.only:
        wanted = set(args.only)
        paths = [p for p in paths if p.name in wanted]
        assert {p.name for p in paths} == wanted
    if args.list:
        print('\n'.join(p.name for p in paths))
    else:
        replay(args.comp.resolve(),args.work.resolve(),paths)

"""Recover every pending closed box from a deterministic preorder search and its first budget-stop box."""
from pathlib import Path
from fractions import Fraction
import argparse,ctypes,json,sys
import numpy as np

def trace(comp,tree,table,lib,packets,receipt,out,cap):
    sys.path.insert(0,str(comp.resolve()))
    from verify_tomar_fan_table import verified_table
    head=json.loads((tree/'part0000.json').read_bytes())
    points,counts=verified_table(table,tree,head)
    I=lambda v:np.ascontiguousarray(v,dtype=np.int64).ravel()
    original=I([int(Fraction(v)*2**44) for v in head['hi']])
    goals={}
    dll=ctypes.CDLL(str(lib.resolve()))
    f=dll.trace_remaining
    i64=np.ctypeslib.ndpointer(dtype=np.int64,flags='C_CONTIGUOUS')
    i32=np.ctypeslib.ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
    f.argtypes=[i64,i64,i64,i64,i64,i32,i32,ctypes.c_int64,i64]
    pp=json.loads(packets.read_bytes());by={q['leaf']:q for q in pp};ret={}
    data=list(map(json.loads,receipt.read_text().splitlines()))
    for row in data:
        if row['out'][0]:continue
        assert row['out'][1]==cap
        k='/'.join(map(str,row['leaf'][:2]));j=row['leaf'][2];t=by[k]['regions'][j]
        base=t['bounds'];dest=row['front'];assert len(dest)==22
        for ax in range(11):assert base[ax][0]<=dest[ax]<dest[ax+11]<=base[ax][1]
        goal=(Fraction(row['target'])*2**57).__floor__()+1
        steps=np.zeros(111,dtype=np.int64)
        length=f(I([x[0] for x in base]),I([x[1] for x in base]),I(dest[:11]),I(dest[11:]),original,points.ravel(),counts.ravel(),goal,steps)
        assert length>=0,length
        b=[v.copy() for v in base];path=t['steps'].copy();siblings=[]
        for step in map(int,steps[:length]):
            axis,side=divmod(step,2);l,h=b[axis];assert (l+h)%2==0;mid=(l+h)//2
            if side==0:
                other=[p.copy() for p in b];other[axis][0]=mid
                siblings.append(dict(leaf=k,steps=path+[step+1],bounds=other))
            b[axis][1-side]=mid;path.append(step)
        assert b==list(map(list,zip(dest[:11],dest[11:])))
        regions=[dict(leaf=k,steps=path,bounds=b)]+siblings[::-1]
        assert row['out'][1]==2*(row['out'][2]+row['out'][3])+len(regions)-1
        for i,q in enumerate(regions):q['label']=t['label']+'-restart-'+str(i)
        ret.setdefault(k,[]).extend(regions)
        goals[t['label']]=dict(location=len(ret[k])-len(regions),count=len(regions),depth=length,nodes=cap)
    out.write_text(json.dumps([dict(leaf=k,regions=v) for k,v in ret.items()],separators=(',',':'))+'\n')
    out.with_suffix('.map.json').write_text(json.dumps(goals,separators=(',',':'))+'\n');print('recovered',len(goals),'parents',sum(q['count'] for q in goals.values()),'boxes')
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ['comp','tree','table','lib','packets','receipt','out']:p.add_argument(n,type=Path)
    p.add_argument('--cap',required=True,type=int);trace(**vars(p.parse_args()))

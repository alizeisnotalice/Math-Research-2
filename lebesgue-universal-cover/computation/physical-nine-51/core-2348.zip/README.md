# .83751 的2348个旧核心原叶

这份子证书覆盖 index.json 的 2,348 个规范原闭叶，分别属于外围分片分配的第2和第3组。固定模型是半径二分之一圆盘、正定宽三、五、七、九边形、P128、原物理旧十一点、不同的新十一点与 P152 的内部十五点。所有输入都允许各自的平移、转动和反射。

| 阶段 | 真输入盒 | 预算末盒 | 原叶全闭累计 |
|---:|---:|---:|---:|
| 0 | 2348 | 634 | 1714 |
| 1 | 9562 | 613 | 2019 |
| 2 | 8792 | 337 | 2216 |
| 3 | 5126 | 112 | 2319 |
| 4 | 2032 | 29 | 2341 |
| 5 | 558 | 0 | 2348 |

全部 323,193,680 次几何访问实际在归档回执中。第一阶段只启用 P128 与原物理旧 Q。后一阶段启用全部四个实体点集。每枚原叶根据全部祖先与子树终端登记实际用到的模型。六枚从头到尾只需五曲体。

每个预算停止处记录深度优先遍历尚未访的第一个闭盒。把从已知父盒通向它的逐级移步恢复，收集每次进入左子盒时尚未遍历的右兄弟，再连同首停盒组成完整后继。这些右兄弟彼此内部不交。恢复时逐步核对真实分裂轴、绝对原树步码、所有闭端点与整数二叉节点守恒。最终审计从原闭叶重新拼接上述层次。几何面积证书采用严格整数门槛 \(120697911165410052/2^{57}>.83751\)。

## 审核与重跑

    "$PY" -B audit_core51.py index.json roots.json stage0.jsonl checked.json \
      --continuation stage1/boxes.json stage1/result.jsonl \
      --continuation stage2/boxes.json stage2/result.jsonl \
      --continuation stage3/boxes.json stage3/result.jsonl \
      --continuation stage4/boxes.json stage4/result.jsonl \
      --continuation stage5/boxes.json stage5/result.jsonl
    cmp checked.json final-audit.json

真实分裂轴可用 recover.py 重算。它的 C++ 轴库调用 frontier-path.cpp，编译时保留整数溢出陷阱。首层用 roots.json、first-stops.jsonl。后续用上一层 boxes.json、result.jsonl。recover 的 cap 参数来自上一层各自预算。每批结果必须和归档相应的下一层 boxes.json 一致。

初始 P128 细七核、基础物理九切片核和 P128 细九核由另存的原传输包提供。每个包都包含其角表、点集、源文件与逐项哈希。重放预算依次为 32767、32767、65535、262143、1048575、4194303。实际驱动都是 run_slice.py，使用 --target .83751 --caps --mesh。第0层直接传 index.json。后续各层传对应盒文件和按其原叶提取的索引。C++17 使用 -O3 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error。原树 manifest SHA-256 为 56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410。TABLE64 SHA-256 为 0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d。

本包是旧核心的真子集。配合已闭外围，本目标的全域定理仍需另外3,094个旧核心原叶的证书。

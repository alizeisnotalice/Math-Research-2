#include "ordinary-control.cpp"
extern "C" int trace_remaining(const L* lower,const L* upper,const L* cursor_lower,
    const L* cursor_upper,const L* original,const std::int32_t* table,const std::int32_t* counts,L goal,L* steps){
    Tester tester(table,counts,original,goal);
    Box lo,hi;
    std::copy(lower,lower+11,lo.begin());
    std::copy(upper,upper+11,hi.begin());
    for(int depth=0;depth<111;++depth){
        if(std::equal(lo.begin(),lo.end(),cursor_lower) && std::equal(hi.begin(),hi.end(),cursor_upper))return depth;
        if(tester.check(lo,hi)!=0)return -1;
        const int k=tester.split_axis;
        const L a=lo[k],b=hi[k];
        if(b<=a || (a+b)%2)return -2;
        const L mid=(a+b)/2;
        if(cursor_upper[k]<=mid){steps[depth]=2*k;hi[k]=mid;}
        else if(cursor_lower[k]>=mid){steps[depth]=2*k+1;lo[k]=mid;}
        else return -3;
    }
    return -4;
}

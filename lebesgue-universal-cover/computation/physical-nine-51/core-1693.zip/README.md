# .83751 非1205的1693个旧核心原叶

该证书补齐本轮计算中两组互斥的完整原叶，一个 742 原叶组与一个 951 原叶组。两组均使用圆盘、正 Reuleaux 三、五、七、九边形、P128、物理旧十一点、不同新十一点和内十五点，允许各自独立的等距摆放。精确门槛 \(120697911165410052/2^{57}>.83751\)。

| 原叶组 | 原叶 | 所有真后继层的盒数 | 整树几何访问 |
|---:|---:|---|---:|
| 冻结前缀 | 742 | 4034、2988、1112、10 | 91998874 |
| 本机续批 | 951 | 3062、220 | 20571365 |

第一个组保留本机原生首筛落盘的完整回执。它从299个预算止步原闭根逐次恢复全部真后继，在最后的181/115525原根上仍确切恢复10个未访闭盒。全通过。

第二个组原生首筛余211个预算止步原根。恢复3062真闭盒后，用祖先仿射下端严格补过3047盒。15个未闭真父被进一步恢复成220个真实闭后继，按原叶互斥分为196和24两组，均用重锚细九核完全通过。merge_real_continuations.py 核两组的完整原叶范围和每个绝对二进地址，再按原序接合。源分组原行和关联审计一并保存。

## 审计接口

    "$PY" -B audit_core51.py prefix/index.json prefix/roots.json prefix/stage0.jsonl check742.json \
      --initial-model nine --continuation prefix/stage1/boxes.json prefix/stage1/rows.jsonl \
      --continuation prefix/stage2/boxes.json prefix/stage2/rows.jsonl \
      --continuation prefix/stage3/boxes.json prefix/stage3/rows.jsonl \
      --continuation prefix/stage4/boxes.json prefix/stage4/rows.jsonl
    "$PY" -B merge_real_continuations.py local/stage2/boxes.json combined220.jsonl \
      --scope local/stage2a/boxes.json local/stage2a/rows.jsonl \
      --scope local/stage2b/boxes.json local/stage2b/rows.jsonl
    cmp combined220.jsonl local/stage2/rows.jsonl
    "$PY" -B audit_core51.py local/index.json local/roots.json local/stage0.jsonl check951.json \
      --initial-model nine --continuation local/stage1/boxes.json local/stage1/rows.jsonl \
      --continuation local/stage2/boxes.json combined220.jsonl
    cmp check742.json prefix/final.json
    cmp check951.json local/final.json

重放原几何时，742组依次使用普通细P128物理九核三次，再重锚核两次，原预算 32767、65535、262143、1048575、4194303。951组使用普通细P128物理九核、仿射核、重锚核，原预算32767、131071、1048575。均走同一 run_slice.py 驱动、同一物理角表、严格 .83751，带 --caps --mesh。两种改进核只改变五曲体面积下端，使用同一原角表并保持分裂轴。复现实参和代码来源见 KERNELS.json、外部的仿射重锚说明与九体角表包。

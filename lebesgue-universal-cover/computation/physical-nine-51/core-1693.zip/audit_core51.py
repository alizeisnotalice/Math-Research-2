"""Audit exact core forests after a whole-original-leaf prefix and descendant passes."""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("index", type=Path)
p.add_argument("root_boxes", type=Path)
p.add_argument("root_receipts", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--continuation", nargs=2, action="append", metavar=("PACKETS","RECEIPTS"), default=[])
p.add_argument("--initial-model", choices=("seven", "nine"), default="seven")
a = p.parse_args()
read = lambda f: json.loads(f.read_bytes())
read_lines = lambda f: [json.loads(line) for line in f.read_bytes().splitlines()]
sha = lambda f: sha256(f.read_bytes()).hexdigest()
wanted = {f"{p}/{i}" for p, ids in read(a.index).items() for i in ids}
root = read(a.root_boxes)
root_pending_boxes = {d["leaf"]: d["regions"][0] for d in root}
assert len(root_pending_boxes) == len(root)
assert all(box["label"] == box["leaf"] and box["steps"] == [] for box in root_pending_boxes.values())
target = Fraction(".83751")
families = ("P128", "oldQ", "newQ", "P15")
visited = {root: Counter() for root in wanted}
open_nodes = {}
total_rows = []

def check(r, key):
    assert Fraction(r["target"]) == target and key in wanted
    ok, calls, five, point, _ = r["out"]
    assert point == sum(r[name] for name in families) and calls > 0
    if ok:
        assert r["front"] is None and calls == 2*(five+point)-1
    else:
        assert len(r["front"]) == 22
    values = {f: r[f] for f in families}
    values.update(calls=calls, five=five)
    visited[key].update(values)
    return ok

def addr_bounds(bounds, steps):
    b = [v.copy() for v in bounds]
    for step in steps:
        j, side = divmod(step,2)
        lo, hi = b[j]
        assert (lo+hi)%2 == 0 and lo < (lo+hi)//2 < hi
        b[j][1-side] = (lo+hi)//2
    return b

def splits(parent_box, row, children):
    base = parent_box["steps"]
    first = children[0]["steps"]
    assert first[:len(base)] == base
    path = first[len(base):]
    want = [first] + [base+path[:j]+[q+1] for j,q in reversed(list(enumerate(path))) if q%2==0]
    assert [x["steps"] for x in children] == want
    assert children[0]["bounds"] == list(map(list,zip(row["front"][:11],row["front"][11:])))
    for i, c in enumerate(children):
        assert c["label"] == parent_box["label"]+"-restart-"+str(i)
        assert c["leaf"] == parent_box["leaf"]
        assert c["bounds"] == addr_bounds(parent_box["bounds"],c["steps"][len(base):])
    _, n, five, points, _ = row["out"]
    assert n == 2*(five+points)+len(children)-1

initial = read_lines(a.root_receipts)
seen = set()
for r in initial:
    assert len(r["leaf"]) == 2
    key = "/".join(map(str,r["leaf"]))
    assert key not in seen
    seen.add(key)
    if a.initial_model == "seven":
        assert not r["newQ"] and not r["P15"]
    if not check(r,key):
        box = root_pending_boxes[key]
        open_nodes[box["label"]] = box,r
assert seen == wanted and set(open_nodes) == set(root_pending_boxes)
total_rows.append(dict(input_nodes=len(seen), still_open=len(open_nodes), receipts_sha256=sha(a.root_receipts)))
for stage, (packets, receipts) in enumerate(a.continuation,1):
    packets, receipts = Path(packets),Path(receipts)
    packet = read(packets)
    tail = {(v["leaf"],j): box for v in packet for j,box in enumerate(v["regions"])}
    assert len(tail) == sum(len(v["regions"]) for v in packet)
    regroup = {}
    for (key,j), box in tail.items():
        parent, child = box["label"].rsplit("-restart-",1)
        assert parent in open_nodes and box["leaf"] == key
        arow = regroup.setdefault(parent,[])
        assert int(child) == len(arow)
        arow.append(box)
    assert set(regroup) == set(open_nodes)
    for parent, children in regroup.items():
        splits(*open_nodes[parent],children)
    open_nodes = {}
    seen = set()
    for r in read_lines(receipts):
        assert len(r["leaf"]) == 3
        part, pos, j = r["leaf"]
        key = f"{part}/{pos}"
        assert (key,j) not in seen
        seen.add((key,j))
        box = tail[key,j]
        if not check(r,key):
            open_nodes[box["label"]] = box,r
    assert seen == set(tail)
    total_rows.append(dict(input_nodes=len(seen), still_open=len(open_nodes),
                           packets_sha256=sha(packets),receipts_sha256=sha(receipts)))
pending = {box["leaf"] for box,r in open_nodes.values()}
tally = Counter()
for key in wanted-pending:
    data = visited[key]
    assert data["calls"] == 2*(data["five"]+sum(data[f] for f in families))-1
    used = tuple(f for f in families if data[f])
    tally["+".join(used) if used else "pure-five"] += 1
output = dict(target=str(target), original_roots=len(wanted), closed=len(wanted-pending), pending=sorted(pending),
              needed=dict(sorted(tally.items())), input_index_sha256=sha(a.index), stages=total_rows,
              all_geometric_visits=sum(v["calls"] for v in visited.values()),
              strict_selected_roots={k:dict(v) for k,v in sorted(visited.items()) if k not in pending})
a.output.write_text(json.dumps(output,indent=2)+"\n")
print(json.dumps({k:output[k] for k in ("original_roots","closed","needed","stages","all_geometric_visits")}))

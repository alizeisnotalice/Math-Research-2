"""Join actual continuation receipts from disjoint whole-original scopes."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("full_split", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--scope", nargs=2, action="append", required=True, metavar=("PACKETS","RECEIPTS"))
a = p.parse_args()
read = lambda f: json.loads(f.read_bytes())
h = lambda b: sha256(b).hexdigest()
rows = read(a.full_split)
full = {e["leaf"]:e for e in rows}
assert len(full)==len(rows)
done, found, sources = set(), {}, []
for scope, receipts in a.scope:
    scope, receipts = Path(scope),Path(receipts)
    s = read(scope)
    keys = {e["leaf"] for e in s}
    assert len(keys)==len(s) and not done&keys
    assert all(e==full[e["leaf"]] for e in s)
    done |= keys
    expected = []
    for e in s:
        part, pos = map(int,e["leaf"].split("/"))
        expected.extend((part,pos,j) for j in range(len(e["regions"])))
    raw = receipts.read_bytes()
    records = [json.loads(line) for line in raw.splitlines()]
    assert [tuple(r["leaf"]) for r in records] == expected
    assert all(Fraction(r["target"])==Fraction(".83751") for r in records)
    found.update(zip(expected,records,strict=True))
    sources.append(dict(scope_sha256=h(scope.read_bytes()),receipts_sha256=h(raw),
                        original_roots=len(keys),subboxes=len(records)))
assert done==set(full)
output = []
for e in rows:
    part, pos = map(int,e["leaf"].split("/"))
    output.extend(found[part,pos,j] for j in range(len(e["regions"])))
assert len(output)==len(found)
data = "".join(json.dumps(r,separators=(",",":"))+"\n" for r in output).encode()
a.output.write_bytes(data)
out = dict(original_roots=len(full),subboxes=len(output),complete_boxes=sum(r["out"][0] for r in output),
           full_split_sha256=h(a.full_split.read_bytes()),combined_sha256=h(data),sources=sources)
a.output.with_suffix(".audit.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))

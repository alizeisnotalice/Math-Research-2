# .83751 原片1205的1401个旧核心原叶

本卷覆盖 index.json 所列的 1,401 个规范原闭叶。所有切片均使用圆盘、正 Reuleaux 三、五、七、九边形、P128、物理旧十一点、不同的新十一点、内十五点。面积整数门槛为 \(120697911165410052\)，分母 \(2^{57}\)。每个物理体可独立摆放。

| 阶段 | 真盒 | 预算末盒 | 累计全闭原叶 |
|---:|---:|---:|---:|
| 0 | 1401 | 858 | 543 |
| 1 | 12458 | 776 | 982 |
| 2 | 11382 | 139 | 1329 |
| 3 | 2274 | 7 | 1394 |
| 4 | 128 | 0 | 1401 |

原生首筛、真后继和预算及终止后的面积证明均实际运行。实际合计263,938,115次访问。最后七枚是原片1205的81932、81933、83455、128176、139716、139730、151617。每枚最后只留一个未闭真父。在 last-seven.json 中逐项记录原闭盒、最后父的绝对原树步码、首停闭盒、128真后继各自的绝对步码及双闭端点、真几何回执行号，以及原叶全树终端和节点数。最后128盒共5,617,178次访问。

## 核查账本和末七映射

    "$PY" -B audit_core51.py index.json roots.json stage0.jsonl check-south.json --initial-model nine \
      --continuation stage1/boxes.json stage1/rows.jsonl \
      --continuation stage2/boxes.json stage2/rows.jsonl \
      --continuation stage3/boxes.json stage3/rows.jsonl \
      --continuation stage4/boxes.json stage4/rows.jsonl
    cmp check-south.json final.json
    "$PY" -B map_last_seven51.py roots.json stage3/boxes.json stage3/rows.jsonl \
      stage4/boxes.json stage4/rows.jsonl check-south.json check-seven.json
    cmp check-seven.json last-seven.json

第一轮从原树整根启动。各后继的顺序从停止处的第一个尚未访问闭盒恢复，沿路径逐级补齐未访的右兄弟，逐个验证原轴和闭端点。恢复初始末盒可用 roots.json、first-stops.jsonl，后续串联上一轮的 boxes.json、rows.jsonl。同一真盒在前缀和后缀间的节点数守恒使用整数验证。

五阶段几何预算依次32767、65535、262143、1048575、4194303。几何库依次使用普通细P128物理九两层、祖先仿射一层、重锚两层，均使用相同细P128的物理九角表。核、编译说明、强支撑和径向见 geometry-nine-083751.zip。驱动 run_slice.py 固定目标 .83751，加 --caps --mesh；原证书几何输入的 SHA-256 见 KERNELS.json 和此卷 MANIFEST.json。

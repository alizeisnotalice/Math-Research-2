"""Produce the exact last-seven coverage map from the certified outside frontier."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
for name in ("roots", "parent_boxes", "parent_rows", "last_boxes", "last_rows", "south_audit", "output"):
    p.add_argument(name, type=Path)
a = p.parse_args()
json_file = lambda f: json.loads(f.read_bytes())
sha = lambda f: sha256(f.read_bytes()).hexdigest()
key = lambda r: f"{r['leaf'][0]}/{r['leaf'][1]}"
lines = lambda f: [json.loads(b) for b in f.read_bytes().splitlines()]
original_roots = {v["leaf"]:v["regions"][0] for v in json_file(a.roots)}
parents = {v["leaf"]:v["regions"] for v in json_file(a.parent_boxes)}
descendants = {v["leaf"]:v["regions"] for v in json_file(a.last_boxes)}
last = {}
for j,r in enumerate(lines(a.last_rows),1):
    k = key(r)
    a0 = last.setdefault(k,[])
    assert r["leaf"][2] == len(a0)
    ok, n, f, g, _ = r["out"]
    assert ok and r["front"] is None and n == 2*(f+g)-1 and Fraction(r["target"])==Fraction(".83751")
    assert g==sum(r[v] for v in ("P128","oldQ","newQ","P15"))
    a0.append((j,r))
assert len(last)==7 and sum(map(len,last.values()))==128 and set(last)==set(descendants)
whole = json_file(a.south_audit)
assert whole["closed"]==whole["original_roots"]==1401 and not whole["pending"]
out = {}
for j,r in enumerate(lines(a.parent_rows),1):
    if r["out"][0]:
        continue
    k = key(r)
    assert k not in out and k in last and r["out"][1]==1048575
    parent = parents[k][r["leaf"][2]]
    children = descendants[k]
    base_steps = parent["steps"]
    trace = children[0]["steps"][len(base_steps):]
    assert children[0]["steps"]==base_steps+trace
    assert children[0]["bounds"]==list(map(list,zip(r["front"][:11],r["front"][11:])))
    expected = [base_steps+trace]
    expected.extend(base_steps+trace[:i]+[step+1] for i,step in reversed(list(enumerate(trace))) if step%2==0)
    assert [v["steps"] for v in children]==expected
    assert len(children)==len(last[k]) and r["out"][1]==2*(r["out"][2]+r["out"][3])+len(children)-1
    matches = []
    for index, (child, (line,result)) in enumerate(zip(children,last[k],strict=True)):
        assert child["leaf"]==k and child["label"]==parent["label"]+"-restart-"+str(index)
        bounds = [v.copy() for v in parent["bounds"]]
        for step in child["steps"][len(base_steps):]:
            d,sign = divmod(step,2)
            lo,hi = bounds[d]
            assert (lo+hi)%2==0 and lo<(lo+hi)//2<hi
            bounds[d][1-sign]=(lo+hi)//2
        assert bounds==child["bounds"]
        matches.append(dict(box=child, receipt_line=line, visit_count=result["out"][1],
                            five_terminals=result["out"][2],
                            point_terminals={v:result[v] for v in ("P128","oldQ","newQ","P15")}))
    out[k]=dict(whole_original=original_roots[k], previous_receipt_line=j,
                previous_first_stop=r["front"], previous_pending_box=parent, exact_tail=matches,
                final_whole_tree=whole["strict_selected_roots"][k])
assert set(out)==set(last)
report=dict(threshold="83751/100000", area_lower_numerator=120697911165410052,area_denominator=2**57,
            coordinate_denominator=2**44,roots=len(out),closed_tail_boxes=sum(len(x["exact_tail"]) for x in out.values()),
            terminal_visits=sum(v["visit_count"] for x in out.values() for v in x["exact_tail"]),
            source_sha256={k:sha(getattr(a,k)) for k in ("roots","parent_boxes","parent_rows","last_boxes","last_rows","south_audit")},
            coverage={k:out[k] for k in sorted(out)})
assert report["terminal_visits"]==5617178
a.output.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:report[k] for k in ("roots","closed_tail_boxes","terminal_visits")}))

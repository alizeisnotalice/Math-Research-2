# Whole-box chord sections of the Reuleaux inputs

The five moving or fixed curved inputs contain the radius-one-half disk and the four regular Reuleaux polygons of orders 3, 5, 7, 9 with their independently allowed poses. Fix an entire pose box, one of the 256 directions v, and the exact coordinate transform (x,y) ↦ (v·(x,y), det(v,(x,y)))/U, with U=2²². This similarity scales distances by |v|/U. In coordinates of size Q=2²⁸ the image of each defining unit disk has radius at least R=floor(Q(U−2)/U), using the authenticated direction norms.

Each defining center has material radius 1/(2 cos(π/(2n)))<3/5. The 160-bit Arb computation checks that both coordinates of each nominal center differ by less than one Q tick from their published rounding. Write T for the integer envelope of the translation error and θ for the integer envelope of the angle error in radian ticks on this box. The Euclidean motion of the center is at most 2 + T + ceil(3θ/5) ticks. After coordinate transformation and integer truncation, both its normal and tangential coordinates differ from the two stored integers a,c by at most E=1+ceil((2+T+ceil(3θ/5))(U+2)/U).

At a selected normal height h, put d=|h−a|+E for each center. If d<R, the whole horizontal interval from c+E−floor(sqrt(R²−d²)) to c−E+floor(sqrt(R²−d²)) belongs to its true disk section for every pose in the box. Intersect these intervals over all n defining disks. Any nonempty resulting interval lies in the actual Reuleaux polygon for every pose. Convexity lets us take the minimum certified left endpoint and maximum certified right endpoint over all inputs and earlier chord witnesses. In the existing chord-cap inequality this increases the guaranteed base length at the same height, for exactly the same defining input family. Integer square roots are corrected by exact squaring and every division that weakens an upper or lower estimate rounds outwards.

The two dyadic rectangles in slice-positive.json are original Tomar subboxes of 1205/81824 and 1205/91041. With a one-node budget at 83747/100000, the four-single-input shared-angle control leaves both rectangles pending. The certified-section kernel excludes each rectangle at the root, using the distinct asymmetric eleven-point input in both cases. The reduced certificate here concerns these two subboxes. A complete original-root certificate also requires its R248 prefix and all other subboxes.

Use the frozen nine-replay-kit and its prepared angular-bank.json. The kit provides dual_bank.py and support_grid.py, curved.cpp, run_curved.py, and disk_chord_support.hpp. Place this package beside the kit and supply their paths to the commands:

```sh
c++ -std=c++17 -O3 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error -shared -fPIC slice.cpp -o slice.so
c++ -std=c++17 -O3 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error -shared -fPIC "$KIT/curved.cpp" -o curved.so
export PYTHONPATH="$KIT"
python -B check_slice.py "$KIT" "$COMP" "$TREE" "$TABLE" "$BANKS/angular-bank.json" ./slice.so ./curved.so ./replayed
```

The kernel uses the authenticated R248 table; the other physical inputs retain independent rigid placements and hands. The circle-center table is regenerated from the authenticated original angle ranges on each run. The checked library builds also trap signed integer overflow. Reproduction uses Python with python-flint and NumPy.

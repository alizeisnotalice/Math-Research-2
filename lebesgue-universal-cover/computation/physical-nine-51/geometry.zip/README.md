# .83751 实体九的公共几何内核与角表

五个曲体为半径二分之一圆盘和正 Reuleaux 三、五、七、九边形。四个独立有限输入的精确整数坐标与分母在 kit/p128.json、kit/physical-q.json、kit/distinct-q.json、kit/p15.json。各自可以任意转动、平移和反射。kit/sources.json 记录上游点集来源及原始角表数据指纹。

NATIVE-SUPPORT51.md 证明实际使用的圆盘帽、曲体共高弦、共同面积预算和整角格线性支持。radial-0706-083751.json 为末端 .706 径向条件的实际 Arb 区间。root-083751-083755.json 给规范根方框外及较高靶的四个移心截断。FINE-P128.md 给精确定义与逐行复算，AFFINE-51.md 给预算子树使用的祖先仿射下端与重锚。原角表生成器和形体有理点认证见 kit/PROOF.md、kit/verify_point_rows.py、kit/angular_rows.py。五体本身的五组扇材料由公开 Tomar 原树的 T64 及 verified_table 算术认证。

## 从资料重建实际角表和库

以下在独立 WORK 目录进行。PY 是含 NumPy 及 python-flint 的 Python 3.13，KIT 是此包解档后的路径，COMP 与 TREE 是已有公开计算目录和原树。可复现的主体均为确认过的 Clang C++17，启用签名整数溢出陷阱。CXX 设为所用编译器，CACHE 为它可写的共享模块目录。

    "$PY" -B "$KIT/kit/prepare.py" "$KIT/kit" "$WORK/banks"
    "$PY" -B "$KIT/prepare_new_outer.py" mask "$WORK/banks/angular-bank.json" "$WORK/seven-base.json" \
      --model physical-seven
    "$PY" -B "$KIT/refine_p128.py" "$WORK/seven-base.json" "$KIT/kit/p128.json" "$KIT/slice/slice.cpp" "$WORK/fine-seven"
    "$PY" -B "$KIT/refine_p128.py" "$WORK/banks/angular-bank.json" "$KIT/kit/p128.json" "$KIT/slice/slice.cpp" \
      "$WORK/fine-nine" --keep-nine
    "$PY" -B "$KIT/check_cap_radius51.py"
    "$CXX" -O3 -std=c++17 -fPIC -shared -fsanitize=signed-integer-overflow \
      -fsanitize-undefined-trap-on-error -fmodules-cache-path="$CACHE" -I "$KIT/slice" -I "$KIT/include" \
      "$WORK/fine-nine/slice-nine-fine-p128.cpp" -o "$WORK/fine-nine.so"

继承的原角下端有144425行，原基角表为 d0b523be89a12f97c0716575f66e2010832498a642e55af45f9c0263475ea999。实体九细化P128的39,736行均经192位 Arb 检验，输出角表 SHA-256 e849b308e0f32cfeef8423e5e23866e7e83b681807fb808d4c0b062bcf6d91d5。实体七细角表输出为 c36b27cb44a5ce96af4eeff18970ad4a3f4b5859fe8414fd4d85d0b456289d4a。

编译 affine-nine.cpp、anchor-nine.cpp 和名义 slice.cpp 时同样使用上面的编译参数。基础九用原角表，物理旧Q-only表用 prepare_new_outer.py 保留原物理旧Q的角组。需要空角表的纯五切片树以 --model five 生成。受预算子树的重放入口均为 slice/run_slice.py，先将 kit 加入 PYTHONPATH；核库和角表成对传入。原盒用本案 index，真后继用该层 boxes，并由其中的叶标签取得相应 index。

原 T64 可用公开 $COMP/tomar_fan_table.py TREE T64 --subdiv 64 构造。已使用的 TABLE64 为 10,534,383 字节，SHA-256 0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d。原 T32 为5,233,899字节，SHA-256 fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c。原树 manifest SHA-256 56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410。表和原树在包外供给。

编译 kit/frontier-path.cpp 时加入 include 目录，包括复算第一未访真盒和各沿路未访右兄弟所需的长弦头文件。已认证的公开输入及输出通过冻结理论卷里的细分地址和闭端点检查。

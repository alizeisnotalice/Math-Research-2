"""Direct interval authentication of every score at every angle and in each required hand."""
from pathlib import Path
from fractions import Fraction
from itertools import combinations
import argparse,gzip,hashlib,json
import numpy as np
from flint import arb,ctx

def read(p):
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def run(bank,sources):
    ctx.prec=192;z=read(bank);G=z['directions'];V=np.asarray(G);U=2**22;Z=2**28;assert all((U-2)**2<a*a+b*b<(U+2)**2 for a,b in G)
    groups=[];shapes=[]
    for f in sources:
        v=read(f);P=v['points'];den=v.get('denominator',v.get('point_denominator'));assert max((x-a)**2+(y-b)**2 for (x,y),(a,b) in combinations(P,2))<=den**2;shapes.append((P,den))
    assert set(map(tuple,shapes[0][0]))=={(x,-y) for x,y in shapes[0][0]}
    sections=[(0,384,1),(1,384,1),(1,1536,1),(2,384,2),(2,1536,2),(3,384,2)]
    assert len(z['cells'])==sum(n*h for _,n,h in sections)
    offset=0;pi=arb.pi()
    for family,K,hand_count in sections:
        cloud,den=shapes[family];splits=0;total=0;unverified=[]
        for j in range(K*hand_count):
            rr=z['cells'][offset+j];total+=len(rr)
            for row in rr:
                ids=row[:3];w=row[3:6];assert min(w)>0 and sum(w)==row[6] and all(sum(t*G[i][k] for i,t in zip(ids,w))==0 for k in (0,1))
            for hand in ((1,-1) if family==1 else ((1,) if j<K else (-1,))):
                P=[(x,y*hand) for x,y in cloud];X=np.asarray(P)
                def check(parts,h,which,depth):
                    nonlocal splits
                    a=(2*((j%K)*parts+h)+1)*pi/(K*parts);sn,cs=a.sin_cos();sw,cw=(pi/(K*parts)).sin_cos()
                    s,c=float(sn.mid()),float(cs.mid());selected=(V@(X@np.array([[c,s],[-s,c]])).T).argmax(axis=1)
                    cc={};bad=[]
                    for ix in which:
                        r=rr[ix];ns=r[:3];ws=r[3:6]
                        for i in ns:
                            if i not in cc:
                                x,y=P[selected[i]];a,b=G[i];u=a*cs+b*sn;v=-a*sn+b*cs;cc[i]=u*x+v*y,v*x-u*y
                        A=sum(w*cc[i][0] for w,i in zip(ws,ns));T=sum(w*cc[i][1] for w,i in zip(ws,ns))
                        if not(A>0 and (A*cw-abs(T)*sw)*Z>=r[7]*r[6]*den*U):bad.append(ix)
                    if bad:
                        if depth==8:unverified.extend((j,hand,ix) for ix in bad);return
                        splits+=1;check(2*parts,2*h,bad,depth+1);check(2*parts,2*h+1,bad,depth+1)
                check(1,0,range(len(rr)),0)
        groups.append(dict(family=family,angles=K,rows=total,additional_subdivisions=splits,unverified=unverified));offset+=K*hand_count
        print(family,K,total,splits,len(unverified),flush=True)
    return groups
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('bank',type=Path);p.add_argument('output',type=Path);p.add_argument('sources',type=Path,nargs=4);a=p.parse_args();out=run(a.bank,a.sources);a.output.write_text(json.dumps(out,indent=2)+'\n');assert not any(g['unverified'] for g in out)

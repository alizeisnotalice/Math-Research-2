"""Certified endpoint support scores for common-angle balance inequalities."""
from pathlib import Path
import argparse,json,hashlib
from flint import arb,ctx
import numpy as np
def read(p):return json.loads(p.read_bytes())
def build(bank,P,Q,N,V,out):
    ctx.prec=192;B=read(bank);points=list(map(read,[P,Q,N,V]))
    p0,p1,p2,p3=[(t['points'],t.get('denominator',t.get('point_denominator'))) for t in points]
    dirs=B['directions'];G=np.array(dirs);U=2**22;Z=2**28;pi=arb.pi();assert len(B['cells'])==6912
    assert set(map(tuple,p0[0]))=={(x,-y) for x,y in p0[0]}
    groups=[(p0,384,1,[1]),(p1,384,1,[1,-1]),(p1,1536,1,[1,-1]),(p2,384,2,None),(p2,1536,2,None),(p3,384,2,None)]
    pos=0;total=0
    for (pts,den),K,hands,mode in groups:
        sw,cw=(pi/K).sin_cos()
        for j in range(K*hands):
            orient=mode or ([1] if j<K else [-1]);rows=B['cells'][pos];pos+=1
            h=j%K;sn,cs=((2*h+1)*pi/K).sin_cos();s,c=float(sn.mid()),float(cs.mid());sc=[[] for _ in rows]
            for side in orient:
                P0=[(x,side*y) for x,y in pts];X=np.array(P0);ids=(G@(X@np.array([[c,s],[-s,c]])).T).argmax(axis=1);cache={}
                for n,r in enumerate(rows):
                    ns=r[:3];w=r[3:6];ws=r[6];assert len(r)==8 and sum(w)==ws and min(w)>0
                    for i in ns:
                        if i in cache:continue
                        a,b=dirs[i];x,y=P0[ids[i]];u=a*cs+b*sn;v=-a*sn+b*cs;cache[i]=(u*x+v*y,v*x-u*y)
                    A=sum(wt*cache[i][0] for wt,i in zip(w,ns));T=sum(wt*cache[i][1] for wt,i in zip(w,ns))
                    ends=[int(((A*cw+side0*T*sw)*Z/(ws*den*U)).lower().floor().unique_fmpz()) for side0 in [-1,1]]
                    assert min(ends)>0;sc[n].append(ends)
            for r,ss in zip(rows,sc):r.extend(map(min,zip(*ss)));total+=1
    assert pos==len(B['cells']);out.write_text(json.dumps(B,separators=(',',':'))+'\n');print(total,hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__':
    a=argparse.ArgumentParser()
    for n in ['bank','P','Q','N','V','out']:a.add_argument(n,type=Path)
    build(**vars(a.parse_args()))

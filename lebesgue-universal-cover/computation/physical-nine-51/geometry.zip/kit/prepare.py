from pathlib import Path
import argparse,gzip,hashlib,json
from verify_point_rows import run
from angular_rows import build
def main(root,out):
    out.mkdir(exist_ok=True);source=json.loads((root/'sources.json').read_bytes())
    for q,h in source['artifacts'].items():assert hashlib.sha256((root/q).read_bytes()).hexdigest()==h
    bank=out/'nine-bank.json';bank.write_bytes(gzip.decompress((root/'nine-bank.json.gz').read_bytes()))
    assert hashlib.sha256(bank.read_bytes()).hexdigest()==source['base_bank']
    paths=[root/n for n in ['p128.json','physical-q.json','distinct-q.json','p15.json']]
    assert run(bank,paths)==json.loads((root/'rows-receipt.json').read_bytes())
    angular=out/'angular-bank.json';build(bank,*paths,angular);assert hashlib.sha256(angular.read_bytes()).hexdigest()==source['angular_bank']
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);assert __debug__;a=p.parse_args();main(a.root,a.out)

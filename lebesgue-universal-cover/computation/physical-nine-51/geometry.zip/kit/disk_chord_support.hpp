// Whole-box chord caps using the fixed disk to project five-body witnesses onto
// the chord line. Coordinates are in Q units before normal normalization.
struct LongEdgeSupport {
    const Tester& test;
    static constexpr L U=L(1)<<22;
    static_assert(W(U+2)*(U+2)*1023 < W(U)*U*1024);
    constexpr static std::array<L,12> band{Q/5000,Q/2500,Q/1600,Q/1000,Q/700,Q/500,
                                           Q/350,Q/250,Q/170,Q/125,Q/85,2*Q/125};
    constexpr static L disk_radius=(Q*(U-2))/(2*U);
    std::vector<L> displacement;

    static L upper(W n,L d) {
        return L(n>=0 ? (n+d-1)/d : n/d);
    }

    static L root_floor(W value) {
        L r=L(std::sqrt(double(value)));
        while(W(r)*r>value) --r;
        while(W(r+1)*(r+1)<=value) ++r;
        return r;
    }

    L bound(L vx,L vy,L high,W gap,L from_disk) {
        std::array<L,band.size()> left,right;
        left.fill(std::numeric_limits<L>::max()/4);
        right.fill(std::numeric_limits<L>::min()/4);
        for(std::size_t j=0;j<band.size();++j) {
            const L h=high-band[j];
            if(h<Q*45/100 || h>disk_radius) continue;
            const L half=root_floor(W(disk_radius)*disk_radius-W(h)*h);
            left[j]=-half;right[j]=half;
        }
        if(displacement.empty()) {
            for(const auto& p:test.hull)
                displacement.push_back(upper(W(test.perturb(p))*(U+2),U));
        }
        for(std::size_t k=0;k<test.hull.size();++k) {
            const auto& p=test.hull[k];
            const L error=displacement[k];
            const W n=W(vx)*p.x+W(vy)*p.y;
            const L hlo=-upper(-n,U)-error;
            const L hhi=upper(n,U)+error;
            if(hlo<high-band.back()) continue;
            const W v=W(vx)*p.y-W(vy)*p.x;
            const L tlo=-upper(-v,U)-error, thi=upper(v,U)+error;
            for(std::size_t j=0;j<band.size();++j) {
                const L h=high-band[j];
                if(h<Q*45/100 || hlo<h) continue;
                // Interpolate to the zero-normal disk point with tangential
                // coordinate clamped to [-disk_radius,disk_radius]. The map
                // increases in the tangential argument, and the shrinkage
                // factor is at most (hhi-h)/hhi.
                const L hi_loss=upper(W(hhi-h)*std::max<L>(0,-disk_radius-thi),hhi);
                const L lo_loss=upper(W(hhi-h)*std::max<L>(0,tlo-disk_radius),hhi);
                left[j]=std::min(left[j],thi+hi_loss);
                right[j]=std::max(right[j],tlo-lo_loss);
            }
        }
        L best=from_disk;
        for(std::size_t j=0;j<band.size();++j) {
            const L length=right[j]-left[j];
            if(length<=0) continue;
            const W c=W(1023)*length, a=W(1024)*gap;
            const auto enough=[&](L r){return c*r*r>=a*(W(r)+band[j]);};
            if(best<=1 || !enough(best-1)) continue;
            const double A=double(a), C=double(c);
            L r=std::max<L>(1,L(std::ceil((A+std::sqrt(A*A+4*A*C*band[j]))/(2*C))));
            while(!enough(r))++r;
            while(r>1 && enough(r-1))--r;
            best=std::min(best,r);
        }
        return best;
    }
};

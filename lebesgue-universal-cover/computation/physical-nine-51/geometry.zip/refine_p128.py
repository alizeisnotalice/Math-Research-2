"""Refine physical P128 angles in the existing seven- or nine-input family."""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

from flint import arb, ctx
import numpy as np

p = argparse.ArgumentParser(description=__doc__)
for name in ("bank", "points", "slice", "out"):
    p.add_argument(name, type=Path)
p.add_argument("--keep-nine", action="store_true")
a = p.parse_args()
ctx.prec = 192
K, Z, U = 1536, 2**28, 2**22
b = json.loads(a.bank.read_bytes())
cloud = json.loads(a.points.read_bytes())
points, den = cloud["points"], cloud["denominator"]
assert len(points) == 128 and {tuple(v) for v in points} == {(x, -y) for x, y in points}
diameter_squared = max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(points,2))
assert diameter_squared < den**2
assert len(b["directions"]) == 256 and len(b["cells"]) == 6912
assert sum(map(len,b["cells"][:384])) == 9934
if a.keep_nine:
    assert sum(map(len,b["cells"][2304:])) == 70066
else:
    assert not any(b["cells"][2304:])
for cell in b["cells"][:384]:
    for row in cell:
        ids, weights, total = row[:3], row[3:6], row[6]
        assert len(row) == 10 and min(weights) > 0 and sum(weights) == total
        assert all(sum(w*b["directions"][i][j] for w,i in zip(weights,ids)) == 0 for j in (0,1))
pi = arb.pi()
sn_width, cs_width = (pi/K).sin_cos()
nn = np.asarray(b["directions"])
pp = np.asarray(points)
gains = Counter()
fine_cells = []
for k in range(K):
    coarse = b["cells"][k//4]
    sc, cc = ((2*k+1)*pi/K).sin_cos()
    sine, cosine = float(sc.mid()), float(cc.mid())
    rot = np.array([[cosine,sine],[-sine,cosine]])
    # These point indices only suggest a material witness. Arb checks each use.
    candidates = (nn @ (pp @ rot).T).argmax(axis=1)
    used = {i for row in coarse for i in row[:3]}
    phase = {}
    for i in used:
        ax, ay = b["directions"][i]
        x, y = points[candidates[i]]
        dot = (ax*cc+ay*sc)*x+(-ax*sc+ay*cc)*y
        deriv = (-ax*sc+ay*cc)*x-(ax*cc+ay*sc)*y
        phase[i] = dot, deriv
    rows = []
    for row in coarse:
        a0 = sum(w*phase[i][0] for i,w in zip(row[:3], row[3:6], strict=True))
        b0 = sum(w*phase[i][1] for i,w in zip(row[:3], row[3:6], strict=True))
        norm = row[6]*den*U
        ends = [int(((a0*cs_width+sign*b0*sn_width)*Z/norm).lower().floor().unique_fmpz())
                for sign in (-1,1)]
        assert min(ends)>0
        floor = max(row[7],min(ends))
        gains[floor-row[7]] += 1
        rows.append([*row[:7],floor,*ends])
    fine_cells.append(rows)
source = a.slice.read_text()
expected = "const int refined[4]={-1,2*CIRCLE,8*CIRCLE,-1};\n        for(int f=0;f<4;++f){"
actual = "const int refined[4]={8*CIRCLE,2*CIRCLE,-1,-1};\n        for(int f=0;f<2;++f){"
assert source.count(expected) == 1
if a.keep_nine:
    variant = "nine"
    actual = "const int refined[4]={18*CIRCLE,2*CIRCLE,8*CIRCLE,-1};\n        for(int f=0;f<4;++f){"
    b["cells"].extend(fine_cells)
    b["knots"] = len(b["cells"])//2
    for old, new in (("cells!=18*CIRCLE", "cells!=22*CIRCLE"),
                     ("(i>=3072 && i<6144) ? 1536", "(i>=3072 && i<6144) || i>=6912 ? 1536")):
        assert source.count(old) == 1
        source = source.replace(old, new)
else:
    variant = "seven"
    b["cells"][3072:4608] = fine_cells
a.out.mkdir(exist_ok=False)
bank_path = a.out/f"angular-{variant}-fine-p128.json"
src_path = a.out/f"slice-{variant}-fine-p128.cpp"
bank_path.write_text(json.dumps(b,separators=(",",":"))+"\n")
src_path.write_text(source.replace(expected,actual))
sha = lambda p: sha256(p.read_bytes()).hexdigest()
out = dict(validated_rows=sum(gains.values()), strict_floor_improvements=sum(gains.values())-gains[0],
           max_gain_integer=max(gains), floor_grid=Z, p128_diameter_squared=str(Fraction(diameter_squared,den**2)),
           family=variant, closed_angle_cells=len(b["cells"]),
           prior_bank_sha256=sha(a.bank), cloud_sha256=sha(a.points), prior_source_sha256=sha(a.slice),
           fine_bank_sha256=sha(bank_path), fine_source_sha256=sha(src_path))
assert out["validated_rows"] == 39736
(a.out/"audit.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))

"""Verify the exact far-point guard used by the .83751 slice kernels."""
from fractions import Fraction
from flint import arb, ctx
import json

ctx.prec = 192
q = lambda f: arb(f.numerator)/f.denominator
radius = Fraction(353,500)
area = Fraction(120697911165410052,2**57)
r = q(radius)
a = (arb.pi()-(q(Fraction(1,2))/r).acos())/4 + (r*r-q(Fraction(1,4))).sqrt()/2
assert a > q(area)
assert r*r < q(Fraction(1,2))
print(json.dumps(dict(radius=str(radius),goal=str(area),radial_area_lower=str(a.lower()),
                      excess_lower=str((a-q(area)).lower())),indent=2))

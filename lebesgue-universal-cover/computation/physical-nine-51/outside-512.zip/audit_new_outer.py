"""Select one complete certified .83751 tree for each newly reopened original."""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("index", type=Path)
p.add_argument("output", type=Path)
p.add_argument("inputs", nargs="+", type=Path)
a = p.parse_args()
raw = a.index.read_bytes()
index = json.loads(raw)
expected = {(int(part), i) for part, ps in index.items() for i in ps}
assert len(expected) == sum(map(len, index.values()))
families = ("P128", "oldQ", "newQ", "P15")
selected, sources = {}, {}
for path in a.inputs:
    raw_receipts = path.read_bytes()
    sources[path.name] = sha256(raw_receipts).hexdigest()
    previous = set()
    for line, data in enumerate(raw_receipts.splitlines(), 1):
        row = json.loads(data)
        key = tuple(row["leaf"])
        assert key in expected and key not in previous
        previous.add(key)
        assert Fraction(row["target"]) == Fraction(".83751")
        passed, visits, five, point, _ = row["out"]
        assert sum(row[f] for f in families) == point
        assert not row["newQ"] and not row["P15"]
        assert (row["front"] is None) == bool(passed)
        if passed:
            assert visits == 2*(five+point)-1
            used = tuple(f for f in families if row[f])
            priority = (len(used), visits)
            if key not in selected or priority < selected[key][0]:
                selected[key] = priority, path.name, line, used, row
out = {
    "target": "83751/100000",
    "index_sha256": sha256(raw).hexdigest(),
    "source_sha256": sources,
    "original_roots": len(expected),
    "closed": len(selected),
    "pending": sorted(f"{p}/{k}" for p,k in expected-selected.keys()),
    "needed": dict(Counter(("+".join(r[3]) if r[3] else "pure-five") for r in selected.values())),
    "selected_nodes": sum(r[-1]["out"][1] for r in selected.values()),
    "per_root": {f"{part}/{pos}": dict(file=file, line=line, families=used, nodes=row["out"][1],
                                      point_terminals={f: row[f] for f in families if row[f]})
                 for (part,pos), (_,file,line,used,row) in sorted(selected.items())},
}
a.output.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k not in ("per_root","source_sha256")}))

"""Compose exact archived whole-leaf floors at .83750, .83751 and .83755."""
import argparse
from collections import Counter
from fractions import Fraction
from io import BytesIO
import hashlib
import json
from pathlib import Path
import tarfile
from zipfile import ZipFile

import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
for name in ("comp", "tree", "base_report", "base_index", "old_theorem", "output"):
    parser.add_argument(name, type=Path)
a = parser.parse_args()
c, out = a.comp, a.output
package = c / "global-083750"
area = 1 << 57
targets = tuple(map(Fraction, (".83750", ".83751", ".83755")))
goals = tuple(int(t * area) + 1 for t in targets)
old, high = goals[0], goals[-1]

def sha(value):
    return hashlib.sha256(value).hexdigest()

def checked(path, digest):
    data = path.read_bytes()
    assert sha(data) == digest, path
    return data

def check_npz(data, accepted, floor, gate):
    with np.load(BytesIO(data), allow_pickle=False) as z:
        p, v = z[accepted], z[floor]
    assert p.dtype == np.int32 and v.dtype == np.int64 and p.shape == v.shape and p.ndim == 1
    assert np.array_equal(np.unique(p), p)
    assert np.all(v >= gate)
    return p, v

def apply(part, p, v):
    positions, values = scores[part]
    ix = np.searchsorted(positions, p)
    valid = ix < len(positions)
    safe = ix[valid]
    same = positions[safe] == p[valid]
    j = safe[same]
    values[j] = np.maximum(values[j], v[valid][same])

def counts():
    return [sum(int(np.count_nonzero(v < g)) for _, v in scores.values()) for g in goals]

historical = json.loads(a.old_theorem.read_bytes())
for name, digest in historical["exterior_source_sha256"].items():
    checked(package / name, digest)
old_base = json.loads((package / "records/base-report.json").read_bytes())
merged45 = json.loads((package / "records/merged45-report.json").read_bytes())
merged = json.loads(checked(package / "records/merged-report.json", merged45["prior_report_sha256"]))
r = json.loads(a.base_report.read_bytes())
assert r["provenance"] == old_base["provenance"]
assert r["area_denominator"] == area == old_base["area_denominator"]
assert r["canonical_leaves"] == old_base["canonical_leaves"] == historical["canonical_leaves"] == 6710314
assert Fraction(r["max_index_target"]) == targets[-1]
assert sha((a.tree / "SHA256SUMS").read_bytes()) == historical["original_tree_manifest_sha256"] == r["provenance"]["manifest"]
canonical = dict((p, n) for p, n, *_ in r["rows"])
assert len(canonical) == 1024
previous = {p: (n, hp, hf) for p, n, *_, hp, hf in old_base["rows"]}
assert set(previous) == set(canonical)
scores = {}
for part, n, *_, hp, hf in r["rows"]:
    p, v = check_npz((a.base_index / f"part{part:04}.npz").read_bytes(), "pos", "full_floor", 0)
    assert len(p) <= n and np.all(v < high) and [sha(t.tobytes()) for t in (p, v)] == [hp, hf]
    ix = v < old
    assert (n, sha(p[ix].tobytes()), sha(v[ix].tobytes())) == previous[part]
    scores[part] = (p, v)
history = {"base": counts()}

for code in ("32", "35", "40", "41", "42", "43", "44"):
    path = c / f"tomar-0837{code}-stage-ledger.json"
    stage = json.loads(checked(path, merged["inputs_sha256"][path.name]))
    assert stage["complete"] and stage["parts"] == len(canonical)
    wanted = {(i, p): digest for i, layer in enumerate(stage["audits"], 1)
              for p, digest in layer["work_files"]}
    assert set(wanted) == {(i, p) for i in range(1, 5) for p in canonical}
    seen = set()
    archives = sorted(c.glob(f"tomar-scored-0837{code}*.zip"))
    assert {q.name for q in archives} == {n for n in merged["inputs_sha256"]
                                         if n.startswith(f"tomar-scored-0837{code}")}
    for archive in archives:
        checked(archive, merged["inputs_sha256"][archive.name])
        with ZipFile(archive) as z:
            for name in z.namelist():
                if not name.endswith(".npz"):
                    continue
                path = Path(name)
                key = (int(path.parts[0].removeprefix("stage")), int(path.stem.removeprefix("part")))
                data = z.read(name)
                assert key not in seen and sha(data) == wanted[key]
                seen.add(key)
                p, v = check_npz(data, "accepted", "full_floor", stage["integer_goal"])
                apply(key[1], p, v)
    assert seen == set(wanted)
    history[f"history_0837{code}"] = counts()
    print(code, history[f"history_0837{code}"], flush=True)
assert history["history_083744"][0] == merged["remaining"] == 753913

for k in range(1, 5):
    archive = c / "six-input-083745" / "volumes" / f"native45-screen-{k}.tar.gz"
    checked(archive, merged45["volumes_sha256"][archive.name])
    seen = set()
    with tarfile.open(archive) as tar:
        manifest = json.load(tar.extractfile("MANIFEST.json"))
        members = {name: (size, digest) for name, size, digest in manifest}
        assert len(members) == len(manifest) == 2048
        for member in tar:
            if not member.name.endswith(".npz"):
                continue
            path = Path(member.name)
            part = int(path.stem.removeprefix("part"))
            assert path.parts[:2] == ("screen", f"stage{k}") and part not in seen
            seen.add(part)
            data = tar.extractfile(member).read()
            assert (len(data), sha(data)) == members[member.name]
            p, v = check_npz(data, "accepted", "full_floor", 120689264254125501)
            apply(part, p, v)
    assert seen == set(canonical)
    history[f"history_083745_s{k}"] = counts()
assert history["history_083745_s4"][0] == merged45["remaining"] == 699060
print("old seed", history["history_083745_s4"], flush=True)

def members(z, expected):
    rows = json.loads(z.read("MANIFEST.json"))
    manifest = {name: (size, digest) for name, size, digest in rows}
    assert len(rows) == len(manifest) == expected and len(z.namelist()) == expected + 1
    assert set(z.namelist()) == set(manifest) | {"MANIFEST.json"}
    return manifest

def get(z, manifest, name):
    data = z.read(name)
    assert (len(data), sha(data)) == manifest[name]
    return data

original = json.loads((package / "records/retained.json").read_bytes())
ledger = json.loads((package / "records/stage-ledger.json").read_bytes())
layer_summary = []
old_boxes, packet_hashes = {}, {}
with ZipFile(package / "volumes/seed50.zip") as z:
    manifest = members(z, len(canonical) + 2)
    raw = get(z, manifest, "seed.json")
    assert sha(raw) == ledger["seed_receipt_sha"]
    seed = json.loads(raw)
    assert seed["tree_manifest_sha256"] == r["provenance"]["manifest"] and seed["target_integer"] == old
    assert seed["remaining"] == 699060 and len(seed["rows"]) == len(canonical)
    for part in canonical:
        p, v = scores[part]
        want = v < old
        data = get(z, manifest, f"seeds/part{part:04}.npz")
        pos, value = check_npz(data, "pos", "score", 0)
        assert np.array_equal(pos, p[want]) and np.array_equal(value, v[want]), part
        old_boxes[part], packet_hashes[part] = pos, sha(data)

for k, layer in enumerate(ledger["audits"], 1):
    insufficient = np.zeros(len(goals), np.int64)
    source_hash = dict(layer["work_files"])
    assert set(source_hash) == set(canonical)
    total_accepted = total_pending = 0
    with ZipFile(package / "volumes" / f"screen{k}.zip") as z:
        manifest = members(z, len(canonical) * 2)
        for part in canonical:
            stem = f"stage{k}/part{part:04}"
            data = get(z, manifest, stem + ".npz")
            meta = json.loads(get(z, manifest, stem + ".json"))
            assert sha(data) == meta["data_sha256"] == source_hash[part]
            cfg = meta["config"]
            assert cfg["source_sha256"] == packet_hashes[part] and (cfg["part"], cfg["layer"], cfg["goal"]) == (part, k, old)
            p, v = check_npz(data, "accepted", "full_floor", old)
            with np.load(BytesIO(data), allow_pickle=False) as arrays:
                pending = arrays["remaining"]
                clipped = arrays["clipped_floor"]
            assert pending.dtype == np.int32 and np.array_equal(np.unique(pending), pending)
            assert clipped.dtype == np.int64 and clipped.shape == v.shape
            assert np.all((clipped == 0) | (clipped >= v))
            assert np.array_equal(np.sort(np.concatenate((p, pending))), old_boxes[part])
            assert (len(p), len(pending), len(p) + len(pending)) == (meta["accepted"], meta["remaining"], meta["tested"])
            old_boxes[part] = pending
            packet_hashes[part] = sha(data)
            total_accepted += len(p)
            total_pending += len(pending)
            insufficient += [int(np.count_nonzero(v < goal)) for goal in goals]
            apply(part, p, v)
    assert (total_accepted, total_pending) == (layer["accepted"], layer["remaining"])
    layer_summary.append(dict(layer=k, accepted=total_accepted, still_below=insufficient.tolist()))
    history[f"history_083750_s{k}"] = counts()
    print("50", k, history[f"history_083750_s{k}"], flush=True)

assert set(map(int, original)) <= set(canonical)
for part, p in old_boxes.items():
    candidate, lower = scores[part]
    assert np.array_equal(p, np.array(original.get(str(part), []), np.int32))
    assert np.array_equal(p, candidate[lower < old])
assert history["history_083750_s4"][0] == historical["core_full_originals"] == 5442

out.mkdir(exist_ok=False)
for target, goal in zip(targets[1:], goals[1:], strict=True):
    name = str(target)
    tag = "083751" if target == targets[1] else "083755"
    folder = out / tag / "index"
    folder.mkdir(parents=True)
    rows = []
    by_group = Counter()
    for part, (p, v) in scores.items():
        keep = v < goal
        pos, lower = p[keep], v[keep]
        historical_core = lower < old
        by_group["core"] += int(historical_core.sum())
        by_group["reopened_exterior"] += int((~historical_core).sum())
        np.savez_compressed(folder / f"part{part:04}.npz", pos=pos, full_floor=lower)
        rows.append([part, canonical[part], sha(pos.tobytes()), sha(lower.tobytes())])
    report = dict(area_denominator=area, canonical_leaves=r["canonical_leaves"], max_index_target=name,
                  provenance=r["provenance"], rows=rows, curve=[{"goal": goal, "unresolved": sum(by_group.values())}])
    (folder.parent / "index-report.json").write_text(json.dumps(report, separators=(",", ":")) + "\n")
    layer_summary.append(dict(target=name, integer_goal=goal, **by_group))
final = dict(targets=list(map(str, targets)), integer_goals=goals, canonical_leaves=r["canonical_leaves"],
             history=history, detail=layer_summary, provenance=dict(base_report_sha256=sha(a.base_report.read_bytes()),
             prior_theorem_sha256=sha(a.old_theorem.read_bytes())))
(out / "audit.json").write_text(json.dumps(final, indent=2) + "\n")
print(json.dumps(final["detail"][-2:]))

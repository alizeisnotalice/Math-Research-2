"""Transfer only complete .83751 integer floors that actually cross .83755."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("old_index55", type=Path)
p.add_argument("audit51", type=Path)
p.add_argument("output", type=Path)
p.add_argument("ripples", nargs="+", type=Path)
a = p.parse_args()
load = lambda path: json.loads(path.read_bytes())
sha = lambda v: sha256(v).hexdigest()
sha_file = lambda f: sha(f.read_bytes())
probe = load(a.audit51)
assert probe["parts"] == 1024 and probe["all_four_layers"] and len(probe["replays"]) == len(a.ripples)
report = load(a.old_index55/"index-report.json")
goal = int(Fraction(".83755")*2**57)+1
below = {}
success = {}
for i, n, hp, hf in report["rows"]:
    with np.load(a.old_index55/"index"/f"part{i:04}.npz",allow_pickle=False) as f:
        pos, floor = f["pos"], f["full_floor"]
    assert [sha(x.tobytes()) for x in (pos,floor)] == [hp,hf] and np.all(floor<goal)
    below[i] = (n,pos,floor.copy())
    success[i] = {}
assert sum(len(p0) for _,p0,_ in below.values()) == 730590
new_rows = []
for i,work in enumerate(a.ripples):
    ledger = work/"stage-ledger.json"
    assert sha_file(ledger) == probe["replays"][str(i)]["ledger_sha256"]
    stages = load(ledger)["audits"]
    for k,s in enumerate(stages,1):
        for part,h in s["work_files"]:
            f = work/f"stage{k}"/f"part{part:04}.npz"
            assert sha_file(f) == h
            with np.load(f,allow_pickle=False) as z:
                accepted, full = z["accepted"], z["full_floor"]
            _, pos, lower = below[part]
            j = np.searchsorted(pos,accepted)
            assert np.all(j<len(pos)) and np.array_equal(pos[j],accepted)
            lower[j] = np.maximum(lower[j],full)
            keep = full>=goal
            for pos, value in zip(accepted[keep],full[keep],strict=True):
                assert int(pos) not in success[part]
                success[part][int(pos)] = int(value)
folder = a.output/"index"
folder.mkdir(parents=True,exist_ok=False)
count = 0
for k,(n,p0,f0) in sorted(below.items()):
    mask = f0<goal
    assert set(map(int,p0[~mask])) == set(success[k])
    pos, floor = p0[mask], f0[mask]
    count += len(pos)
    new_rows.append([k,n,sha(pos.tobytes()),sha(floor.tobytes())])
    np.savez_compressed(folder/f"part{k:04}.npz",pos=pos,full_floor=floor)
report["rows"] = new_rows
report["curve"] = [{"goal":goal,"unresolved":count}]
report["provenance"]["full_floor_overlay_083751"] = sha_file(a.audit51)
(a.output/"index-report.json").write_text(json.dumps(report,separators=(",",":"))+"\n")
new = sum(map(len,success.values()))
assert new == probe["same_receipts_directly_above_083755"] == 63224 and count == 730590-new
ret = dict(original_083755_residue=730590,strict_083751_floors_also_at_083755=new,remaining_083755=count,
           floor_goal=goal,prior55_index_sha256=sha_file(a.old_index55/"index-report.json"),
           actual51_audit_sha256=sha_file(a.audit51))
(a.output/"audit.json").write_text(json.dumps(ret,indent=2)+"\n")
print(json.dumps(ret))

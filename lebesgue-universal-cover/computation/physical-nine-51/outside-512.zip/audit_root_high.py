"""Check root and radial exterior at two strict rational targets."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb, ctx

comp, tree = map(Path, sys.argv[1:])
sys.path.insert(0, str(comp.resolve()))
from certify_polygon_083731 import lower_radius
from select_tomar_083731_scores import radius_rows, q

ctx.prec = 192
s = Fraction(".999999006")
pi = arb.pi()
manifest = (tree / "SHA256SUMS").read_bytes()
digest = sha256(manifest).hexdigest()
assert digest == "56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410"
root_bytes = (tree / "part0000.json").read_bytes()
names = {name.removeprefix("./"): h for h, name in (line.split() for line in manifest.decode().splitlines())}
assert sha256(root_bytes).hexdigest() == names["part0000.json"]
root = json.loads(root_bytes)
lo, hi = (list(map(Fraction, root[k])) for k in ("lo", "hi"))
radial_bytes = (comp / "five-body-radial-affine.json").read_bytes()
radial = json.loads(radial_bytes)
assert radial["source_sha256"] == sha256((comp / "certify_radial_affine_fans.py").read_bytes()).hexdigest()
assert radial["table_sha"] == sha256((comp / "five-body-radial-material.npz").read_bytes()).hexdigest()
out = {}
for target in map(Fraction, (".83751", ".83755")):
    goal = int(target * 2**57) + 1
    out[str(target)] = rows = []
    for i, row in enumerate(radius_rows(radial, target)):
        j = 3 * i
        edge = min(-lo[j], hi[j], -lo[j + 1], hi[j + 1])
        a = q(s / 2)
        b = q(s) * lower_radius(row["n"], pi)
        value = pi * (a * a + b * b) / 2 + q(edge) * (a + b)
        assert value > q(Fraction(goal, 2**57))
        assert Fraction(row["integer_radius"], 2**44) < edge
        assert row["integer_area_lower"] >= goal
        rows.append(dict(root_edge=str(edge), root_exterior_area_lower=str(value.lower()), **row))
print(json.dumps(dict(scale=str(s), root_tree_manifest_sha256=digest,
                      prior_radial_sha256=sha256(radial_bytes).hexdigest(), targets=out), indent=2))

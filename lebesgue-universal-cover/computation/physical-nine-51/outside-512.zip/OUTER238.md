# 组2与组3新外围在 .83751 的重算

两组附带的 retained.json 是本靶五体四层原叶余集。和 .83750 的 5,442 个旧核心逐号取差，组2得 137 个新外围原叶，组3得 101 个。两组互斥。组2的 1,335 个和组3的 1,013 个旧核心原叶另有固定实体核的任务。

先对 238 个真原叶分别只启用五曲体。组2用 131071 节点预算，组3用 65535。组2有两枚、组3有两枚达限。从各自的原闭盒重新运行强制只用物理旧十一点的核。三枚确实使用原 Q 支撑，其余一枚的树全为五体终端。最终严格通过的 238 个闭原叶中，235 个只需五体，3 个使用五体加物理旧十一点。选择的完整成功树共访问 5,192,154 个节点。所有点体终端均属于同一个物理旧 Q。

## 核与边界

纯五体运行用空角表。物理旧 Q 运行只保留原已验证总表的 384–2303 号格，包含 384 个粗格及 1,536 个细格。两种手性均以同一行向下包围。每个原叶按旧整数分数记录中的原树位置，还原原 11 维二进树端点。结果审计检查原叶号唯一性、严格门槛、端点失败指示和完整树的二叉节点守恒。四层整域继承的证据另见外围种子总账。本包补齐两组的新外围，仍需组0和组1及原核心证书。

## 复现

用本轮已认证的原总角表，SHA-256 d0b523be89a12f97c0716575f66e2010832498a642e55af9c0263475ea999。Python 3.13、NumPy 与 python-flint。原树、TABLE64 与 COMP 使用本项目已有公开复算输入。编译 CPU 溢出检查已开启。

    "$PY" -B prepare_new_outer.py mask "$ANGULAR_BANK" pure-bank.json --model five
    "$PY" -B prepare_new_outer.py mask "$ANGULAR_BANK" physical-old-q.json --model physical-old-q
    clang++ -O3 -std=c++17 -fsanitize=signed-integer-overflow \
      -fsanitize-undefined-trap-on-error -fPIC -shared -fmodules-cache-path="$CACHE" \
      -I "$COMP/three-leaf-083750" slice.cpp -o slice.dylib
    "$PY" -B run_slice.py "$COMP" "$TREE" "$TABLE64" slice.dylib pure-bank.json five-g2.jsonl \
      --target .83751 --index group2/index.json --workers 1 --caps --mesh --cap 131071
    "$PY" -B run_slice.py "$COMP" "$TREE" "$TABLE64" slice.dylib pure-bank.json five-g3.jsonl \
      --target .83751 --index group3/index.json --workers 1 --caps --mesh --cap 65535
    "$PY" -B run_slice.py "$COMP" "$TREE" "$TABLE64" slice.dylib physical-old-q.json q-g2.jsonl \
      --target .83751 --only 1201/65659,1201/66634 --workers 1 --caps --mesh --cap 524287
    "$PY" -B run_slice.py "$COMP" "$TREE" "$TABLE64" slice.dylib physical-old-q.json q-g3.jsonl \
      --target .83751 --only 1206/41936,1206/41974 --workers 1 --caps --mesh --cap 262143
    "$PY" -B audit_new_outer.py group2/index.json verify-group2.json five-g2.jsonl q-g2.jsonl
    "$PY" -B audit_new_outer.py group3/index.json verify-group3.json five-g3.jsonl q-g3.jsonl

角表的行及四分角核的证明从九输入公共包继承，使用该包中的原物理旧十一点和原角表复算入口。

"""Join the complete .83751 outside proof with its exact 5442-old-root complement."""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
for name in ("old_core", "four_layer_scope", "output"):
    p.add_argument(name, type=Path)
p.add_argument("direct_audits", nargs="+", type=Path)
a = p.parse_args()
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: sha256(path.read_bytes()).hexdigest()
keys = lambda x: {f"{part}/{pos}" for part, positions in x.items() for pos in positions}
old = keys(read(a.old_core))
scope = read(a.four_layer_scope/"audit.json")
r = keys(read(a.four_layer_scope/"retained.json"))
assert scope["all_four_layers"] and scope["parts"] == 1024
assert len(old) == 5442 and old <= r and len(r) == scope["still_in_seed"] == 5954
assert len(r-old) == scope["reopened_exterior_still_in_seed"] == 512
selected = {}
counts = Counter()
visits = 0
inputs = []
for file in a.direct_audits:
    d = read(file)
    assert Fraction(d["target"]) == Fraction(".83751")
    assert d["closed"] == d["original_roots"] and not d["pending"]
    seen = set(d["per_root"])
    assert len(seen) == d["closed"] and seen <= (r-old) and not set(selected)&seen
    for key,row in d["per_root"].items():
        needed = tuple(row["families"])
        assert needed in ((),("oldQ",))
        counts["physical-old-Q" if needed else "pure-five"] += 1
        visits += row["nodes"]
        selected[key] = list(needed)
    inputs.append(sha(file))
assert set(selected) == r-old
assert counts == {"pure-five":507,"physical-old-Q":5} and visits == 12565316
area = 2**57
g = int(Fraction(".83751")*area)+1
out = {
    "strict_target": "83751/100000",
    "certified_minimum_outside_5442": str(Fraction(g,area)),
    "canonical_original_leaves": 6710314,
    "open_originals_after_this_proof": len(old),
    "excluded_canonical_exterior": 6710314-len(old),
    "reopened_new_outside_closed": dict(counts),
    "those_requiring_physical_old_Q": sorted(k for k,data in selected.items() if data),
    "additional_selected_nodes": visits,
    "historical_retained_sha256": sha(a.old_core),
    "four_layer_audit_sha256": sha(a.four_layer_scope/"audit.json"),
    "four_layer_retained_sha256": sha(a.four_layer_scope/"retained.json"),
    "direct_audit_sha256": inputs,
}
a.output.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))

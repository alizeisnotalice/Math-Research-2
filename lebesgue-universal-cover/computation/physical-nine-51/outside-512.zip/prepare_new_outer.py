"""Create original-root lists for newly reopened outer cells, and mask point rows."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
subs = parser.add_subparsers(dest="action", required=True)
scope = subs.add_parser("scope")
for name in ("old_core", "current_retained", "output"):
    scope.add_argument(name, type=Path)
mask = subs.add_parser("mask")
mask.add_argument("source", type=Path)
mask.add_argument("output", type=Path)
mask.add_argument("--model", choices=("five", "physical-old-q", "physical-seven"), required=True)
a = parser.parse_args()
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if a.action == "scope":
    original, current = read(a.old_core), read(a.current_retained)
    assert sum(map(len, original.values())) == 5442
    assert all(v == sorted(set(v)) for v in original.values())
    old, outer = {}, {}
    for part, positions in current.items():
        assert positions == sorted(set(positions))
        core = set(original.get(part, []))
        in_core = [i for i in positions if i in core]
        outside = [i for i in positions if i not in core]
        if in_core:
            old[part] = in_core
        if outside:
            outer[part] = outside
    a.output.mkdir(exist_ok=False)
    for name, values in (("core", old), ("outside", outer)):
        (a.output / (name + ".json")).write_text(json.dumps(values, separators=(",", ":")) + "\n")
    print(json.dumps(dict(old_core=sum(map(len, old.values())), reopened_exterior=sum(map(len, outer.values())),
                          old_core_sha256=sha(a.old_core), current_retained_sha256=sha(a.current_retained))))
else:
    bank = read(a.source)
    assert len(bank["cells"]) == 6912
    counts = [sum(map(len, bank["cells"][lo:hi])) for lo, hi in ((0, 384), (384, 2304), (2304, 6912))]
    assert counts == [9934, 64425, 70066]
    if a.model == "five":
        allowed = range(0)
    elif a.model == "physical-old-q":
        allowed = range(384, 2304)
    else:
        allowed = range(2304)
    bank["cells"] = [rows if i in allowed else [] for i, rows in enumerate(bank["cells"])]
    a.output.write_text(json.dumps(bank, separators=(",", ":")) + "\n")
    print(json.dumps(dict(model=a.model, active_rows=sum(map(len, bank["cells"])),
                          source_sha256=sha(a.source), output_sha256=sha(a.output))))

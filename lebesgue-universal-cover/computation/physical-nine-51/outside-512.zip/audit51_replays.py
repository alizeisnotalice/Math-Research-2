"""Audit disjoint completed portions of the .83751 four-layer replay."""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path

import numpy as np

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("seed_directory", type=Path)
p.add_argument("old_core", type=Path)
p.add_argument("output", type=Path)
p.add_argument("replays", nargs="+", type=Path)
a = p.parse_args()
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())
seed = read(a.seed_directory / "seed.json")
target = Fraction(seed["target"])
g = int(target * 2**57) + 1
upper = int(Fraction(".83755") * 2**57) + 1
assert target == Fraction(".83751") and seed["target_integer"] == g
seed_counts = {i: (n, h, f) for i, _, _, _, n, h, f in seed["rows"]}
assert len(seed_counts) == 1024 and sum(row[0] for row in seed_counts.values()) == 352795
old_core = {int(p): np.asarray(pos, np.int32) for p, pos in read(a.old_core).items()}
assert sum(map(len, old_core.values())) == 5442

stage_config = ((2, 127), (1, 1023), (1, 8191), (1, 65535))
totals = [Counter() for _ in stage_config]
source_digest = None
group_runs, touched, closed_hi = {}, set(), Counter()
latest = {}
for ix, work in enumerate(a.replays):
    lines = read(work / "stage-ledger.json")
    assert lines["target"] == str(target) and lines["radial_target"] == str(target) and lines["integer_goal"] == g
    assert lines["seed_receipt_sha"] == sha((a.seed_directory / "seed.json").read_bytes())
    if source_digest is None:
        source_digest = lines["source_sha"]
    assert lines["source_sha"] == source_digest
    assert 1 <= len(lines["audits"]) <= len(stage_config)
    parts = {part for part, _ in lines["audits"][0]["work_files"]}
    assert not touched & parts and parts <= set(seed_counts) and len(parts) == lines["parts"]
    touched.update(parts)
    previous = {}
    for part in parts:
        stem = f"part{part:04}.npz"
        source = a.seed_directory / "seeds" / stem
        with np.load(source, allow_pickle=False) as z:
            pos, score = z["pos"], z["score"]
        assert pos.dtype == np.int32 and score.dtype == np.int64 and pos.shape == score.shape
        assert np.array_equal(np.unique(pos), pos) and np.all(score < g)
        assert (len(pos), sha(pos.tobytes()), sha(score.tobytes())) == seed_counts[part]
        previous[part] = pos, sha(source.read_bytes())
    for k, summary in enumerate(lines["audits"], 1):
        hashes = dict(summary["work_files"])
        assert len(hashes) == len(summary["work_files"]) and set(hashes) == parts
        step = Counter()
        for part in parts:
            npz = work / f"stage{k}" / f"part{part:04}.npz"
            rec = read(npz.with_suffix(".json"))
            digest = sha(npz.read_bytes())
            assert hashes[part] == digest == rec["data_sha256"]
            cfg = rec["config"]
            assert (cfg["part"], cfg["layer"], cfg["goal"], cfg["radial_goal"]) == (part, k, g, str(target))
            assert (cfg["divisor"], cfg["budget"]) == stage_config[k-1] and cfg["kernel_sha256"] == source_digest
            before, before_hash = previous[part]
            assert cfg["source_sha256"] == before_hash
            with np.load(npz, allow_pickle=False) as z:
                accepted, pending, full, clip = (z[name] for name in ("accepted", "remaining", "full_floor", "clipped_floor"))
            assert accepted.dtype == pending.dtype == np.int32
            assert full.dtype == clip.dtype == np.int64 and full.shape == accepted.shape == clip.shape
            assert np.array_equal(np.unique(accepted), accepted) and np.array_equal(np.unique(pending), pending)
            assert len(accepted) == rec["accepted"] and len(pending) == rec["remaining"] and len(before) == rec["tested"]
            assert np.array_equal(np.sort(np.r_[accepted, pending]), before)
            assert np.all(full >= g) and np.all((clip == 0) | (clip >= full))
            next_goal = int((target + Fraction(".00001")) * 2**57) + 1
            assert int((full >= next_goal).sum()) == rec["at_next_target"]
            assert int(((clip != 0) & (clip > full)).sum()) == rec["capped_by_radial"]
            for name in ("tested", "accepted", "remaining", "at_next_target", "capped_by_radial"):
                step[name] += rec[name]
            step["calls"] += rec["counts"][0]
            closed_hi[k] += int((full >= upper).sum())
            previous[part] = pending, digest
        assert all(total == summary[key] for key, total in step.items())
        step["parts"] = len(parts)
        totals[k-1].update(step)
    if len(lines["audits"]) == 4:
        retained = read(work / "retained.json")
        assert retained == {str(p): pos.tolist() for p, (pos, _) in previous.items() if len(pos)}
    group_runs[ix] = {"audited_layers": len(lines["audits"]), "parts": sorted(parts),
                      "ledger_sha256": sha((work / "stage-ledger.json").read_bytes())}
    for part, (pos, _) in previous.items():
        latest[part] = (len(lines["audits"]), pos)

for part in set(seed_counts) - touched:
    with np.load(a.seed_directory / "seeds" / f"part{part:04}.npz", allow_pickle=False) as z:
        latest[part] = (0, z["pos"])
out = {
    "whole_leaf_scope": "strict .83751; already covered outside the seed count is 6357519",
    "source_sha256": source_digest,
    "parts": len(touched),
    "all_four_layers": all(level == 4 for level, _ in latest.values()),
    "level_counts": dict(sorted(Counter(level for level, _ in latest.values()).items())),
    "replays": group_runs,
    "layer_totals": list(map(dict, totals)),
    "same_receipts_directly_above_083755": sum(closed_hi.values()),
    "still_in_seed": sum(len(pos) for _, pos in latest.values()),
    "still_in_old_core": sum(len(np.intersect1d(pos, old_core[part], assume_unique=True))
                             for part, (_, pos) in latest.items() if part in old_core),
}
out["reopened_exterior_still_in_seed"] = out["still_in_seed"] - out["still_in_old_core"]
a.output.mkdir(exist_ok=False)
(a.output / "audit.json").write_text(json.dumps(out, indent=2) + "\n")
(a.output / "retained.json").write_text(json.dumps({str(i): pos.tolist() for i, (_, pos) in sorted(latest.items())
                                                 if len(pos)}, separators=(",", ":")) + "\n")
print(json.dumps({name: out[name] for name in ("level_counts", "all_four_layers", "still_in_seed",
      "still_in_old_core", "reopened_exterior_still_in_seed", "same_receipts_directly_above_083755")}))

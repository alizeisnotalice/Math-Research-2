# 五体外围的 .83751 与 .83755 种子

在同一 Tomar 规范坐标中固定圆盘圆心和正三边形朝向。原 2,048 片中活动的 1,024 片含 6,710,314 个规范闭原叶。五体仍取各自中心缩率 \(s=499999503/500000000\) 的圆盘及四个正定宽三、五、七、九边形。允许原尺寸只会增加凸包。每个阈值 \(t\) 对应整数面积下端门槛 \(\lfloor 2^{57}t\rfloor+1\)。

| 阈值 | 整数门槛 | 继承的整原叶 | 旧种子外重开 | 旧四层内重开 | 旧核心 | 待算总数 |
|---:|---:|---:|---:|---:|---:|---:|
| .83751 | 120697911165410052 | 6,357,519 | 61,866 | 285,487 | 5,442 | 352,795 |
| .83755 | 120703675772933086 | 5,979,724 | 269,119 | 456,029 | 5,442 | 730,590 |

旧种子是 .83750 原外围第一轮的 699,060 个原叶。两列重开按原叶编号互斥。旧核心的单独实体证书未计入本外围表。原叶分类由每片有序的零基预序位置给出，其中原四层之后的旧核心恰好是同一数组中下端仍低于 .83750 严格整数门槛的项。待算表记录仍需同档证书覆盖的闭盒。

## 历史继承

对每个活动原叶重新解析旧整数桶、.83731 四层及原径向扫描的真实下端。在两档新门槛的较大值已经通过时，保留通过标记。对其他原叶保存真实整数下端。再逐原叶取 .83732/.83735/.83740/.83741/.83742/.83743/.83744、.83745 四层和 .83750 四层的整叶下端最大值。原材料转移见仓库 proofs/polygon-arithmetic-transfer-083731.md 与此前 .83750 外围 README。

仅用 full_floor 上调整叶。旧 clipped_floor 适用于原几何裁切内。新半径较大，增加的薄壳须由本靶证书覆盖。先将重扫后的 .83750 低分位置及整数逐片与旧 base-report 匹配，再和冻结 seed 完全相等比较，最后核对四层每个父输入、加入与剩余位置的分割、逐片 SHA-256，以及旧 5,442 原叶终表。本轮实际重扫了原树坐标、规范掩码及径向整数，旧四层面积核由冻结回执继承。

## 根方框与新径向边界

正定宽 \(n\) 边形包含同心半径 \(b=s(1-1/(2\cos(\pi/(2n))))\) 的圆盘。第一个圆盘半径 \(a=s/2\)。两圆心距离为 \(d\) 时，取垂直连心线的两条直径及两块朝外半圆。两条直径连成梯形，有面积 \(d(a+b)\)，其内部与两块半圆不交。于是
\[
\operatorname{area}(\operatorname{conv}(D\cup(B_n+z)))
\ \ge\ \tfrac{\pi}{2}(a^2+b^2)+d(a+b).
\]
任一平移坐标超出原根方框，即有 \(d\) 大于该方框四条边到原点距离的最小值。192 位 Arb 的实际最弱根外下端超过 .85914435。

对固定方向，圆盘与单个平移体的凸包面积 \(f(d)\) 沿平移线是凸函数。可按与平移线平行的截线证明，截线的右端是由点对凸组合得到的一组仿射函数的上确界，左端是相应下确界，截线投影区间固定，积分保持凸性。原径向材料给出某个共同半径 \(r\) 上 \(f(r)\ge L\)，中心面积有 \(f(0)\le U<L\)，故 \(f(d)\ge L+(d/r-1)(L-U)\) 对 \(d\ge r\) 成立。用这一公式在 \(2^{-44}\) 格上向外选择新半径，并向下保留整数面积下端。两档四个半径及面积见 root-083751-083755.json。每个半径都严格在原方框内，两档各用本靶的新径向裁切。

## 重建与重放

令 COMP 为公开的 computation 目录，TREE 为原树，CACHE 为共享 Clang 缓存，WORK 为独立的临时目录，HERE 为本文所在目录，OLD_THEOREM 为 R6c 独立全域账本的 global-theorem.json。PY 使用 Python 3.13、NumPy 与 python-flint，输入和输出均可用任意绝对路径。先创建 WORK，内部子目录起初不存在。

    "$PY" -B "$COMP/global-083750/prepare_stage.py" "$COMP" "$WORK/stage31"
    "$PY" -B "$COMP/audit_tomar_multi_target_scores.py" "$COMP" "$TREE" "$WORK/stage31" "$WORK/build" "$CACHE" \
      --emit "$WORK/base55" --targets .83750 .83751 .83755 > "$WORK/base55.json"
    "$PY" -B "$HERE/rescore_perimeter.py" "$COMP" "$TREE" "$WORK/base55.json" "$WORK/base55" \
      "$OLD_THEOREM" "$WORK/residue"
    "$PY" -B "$HERE/audit_root_high.py" "$COMP" "$TREE" > "$WORK/root.json"
    "$PY" -B "$COMP/prepare_tomar_multi_target_layer.py" "$WORK/residue/083751/index-report.json" \
      "$WORK/residue/083751/index" "$COMP/five-body-radial-affine.json" "$WORK/residue/083751/seeds" \
      --target .83751 --radial-target .83751 > "$WORK/residue/083751/seed.json"

为 .83755 执行最后一条命令并换用 083755 目录与 .83755 参数。归档保存索引报告、每片原叶与对应已知整数下端、径向参数和逐片哈希。可从种子归档重放五体几何，或从前三条命令独立生成种子。T32 的 SHA-256 为 fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c，可用公开的 tomar_fan_table.py TREE T32 --subdiv 32 生成。

    "$PY" -B "$HERE/seal_seeds.py" unpack "$WORK/input51" "$HERE/perimeter-083751-seeds.zip"
    "$PY" -B "$COMP/replay_tomar_signed_translation_screen.py" \
      "$COMP" "$TREE" "$T32" "$WORK/input51/seeds" "$WORK/input51/seed.json" "$WORK/screen51" "$CACHE" --workers 2 --until 2

以 --parts 传入严格互斥的原分片号可分开重算，再按原叶并集整合。partition51.json 分成 88,201、88,197、88,202 和 88,195 个种子的四组，恰覆盖全部 1,024 活动片。

## 种子 SHA-256

- .83751 归档 fdcd07864e8556faf8445ba4c9ab2fe62ebd2286af40a50956514317249a01de
- .83755 归档 b88266a91aa42df4e1eb579f84ca39aa221ef2d03760612c702af2e2fd4d46a3

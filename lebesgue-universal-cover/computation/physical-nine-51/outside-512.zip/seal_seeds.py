"""Create or unpack a target seed package, with exact per-shard receipts."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("action", choices=("pack", "unpack"))
p.add_argument("directory", type=Path)
p.add_argument("archive", type=Path)
p.add_argument("--partition", type=Path)
a = p.parse_args()
sha = lambda b: hashlib.sha256(b).hexdigest()

def write(z, name, data):
    info = ZipInfo(name)
    info.compress_type = ZIP_DEFLATED
    z.writestr(info, data)

if a.action == "pack":
    seed = (a.directory / "seed.json").read_bytes()
    report = (a.directory / "index-report.json").read_bytes()
    doc = json.loads(seed)
    assert sha(report) == doc["provenance"]["whole_leaf_index"]
    seeds = {f"seeds/part{p:04}.npz" for p, *_ in doc["rows"]}
    assert len(seeds) == len(doc["rows"]) == 1024
    data = {"seed.json": seed, "index-report.json": report}
    data.update({n: (a.directory / n).read_bytes() for n in seeds})
    if a.partition:
        b = a.partition.read_bytes()
        assert json.loads(b)["target"] == doc["target"]
        data["partition.json"] = b
    with ZipFile(a.archive, "x") as z:
        for name, payload in sorted(data.items()):
            write(z, name, payload)
        manifest = [(n, len(b), sha(b)) for n, b in sorted(data.items())]
        write(z, "MANIFEST.json", (json.dumps(manifest, separators=(",", ":")) + "\n").encode())
else:
    with ZipFile(a.archive) as z:
        rows = json.loads(z.read("MANIFEST.json"))
        names = {n for n, *_ in rows}
        assert set(z.namelist()) == names | {"MANIFEST.json"} and len(names) == len(rows)
        doc = json.loads(z.read("seed.json"))
        assert sha(z.read("index-report.json")) == doc["provenance"]["whole_leaf_index"]
        seeds = {f"seeds/part{p:04}.npz" for p, *_ in doc["rows"]}
        assert seeds | {"seed.json", "index-report.json"} <= names <= seeds | {"seed.json", "index-report.json", "partition.json"}
        assert len(seeds) == len(doc["rows"]) == 1024
        blobs = {}
        for name, size, digest in rows:
            blob = z.read(name)
            assert len(blob) == size and sha(blob) == digest, name
            blobs[name] = blob
    a.directory.mkdir(exist_ok=False)
    (a.directory / "seeds").mkdir()
    for name, data in blobs.items():
        (a.directory / name).write_bytes(data)

assert sum(row[4] for row in doc["rows"]) == doc["remaining"]
print(json.dumps(dict(target=doc["target"], roots=doc["remaining"], parts=len(seeds),
                      archive_sha256=sha(a.archive.read_bytes()))))

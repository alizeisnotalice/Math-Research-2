"""Combine the frozen six-input area tree with moved triangle witnesses."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


def read(path):
    return json.loads(path.read_bytes())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('computation','tree','table32','table64','output'):
        parser.add_argument(name,type=Path)
    parser.add_argument('--workers',type=int,default=2)
    a=parser.parse_args()
    local=Path(__file__).resolve().parent
    comp, tree, table32, table64, out=[p.resolve() for p in
        (a.computation,a.tree,a.table32,a.table64,a.output)]
    out.mkdir(parents=True,exist_ok=False)
    def run(script,*args):
        subprocess.run([sys.executable,'-E','-B',str(script),*map(str,args)],check=True)
    def filehash(path):
        return sha256(path.read_bytes()).hexdigest()
    run(local/'materials/verify.py',comp,tree,table32,table64,out/'materials','--workers',a.workers)
    run(comp/'critical-material-scale/radial_binding.py',comp,table32,out/'radial-binding.json')
    run(local/'radial_true.py',comp,out/'radial.json')
    run(local/'interval_shift.py',comp,tree,out/'interval.json',comp/'critical-material-scale/records/points/proof.json')
    run(comp/'global-row-witness/sparse_rows.py',comp,comp/'global-row-witness',out/'fifteen')
    shape=read(out/'fifteen/fifteen-proof.json')
    assert filehash(out/'fifteen/fifteen-proof.json')==filehash(comp/'global-row-witness/fifteen-proof.json')
    assert read(out/'radial-binding.json')['zero_angle_and_counts_equal']
    mat=read(out/'materials/result.json')
    transfer=read(out/'interval.json')
    radial=read(out/'radial.json')
    scale=F(mat['scale'])
    shift=F(mat['r3_translation_x'])
    goal=F(120689264254125501,2**57)
    assert mat['complete'] and mat['triangle_extra_exact_binding'] and mat['dense_leaves']==24
    assert transfer['complete'] and transfer['native_leaves']==3273
    assert F(transfer['lower'])<=scale<=F(transfer['upper']) and abs(shift)<=F(transfer['shift_abs_upper'])
    assert radial['complete'] and radial['grid']==8192 and F(radial['scale'])<=scale
    assert abs(shift)<=F(radial['shift_bound']) and F(radial['goal'])==goal and F(radial['gap'])>0
    assert len(shape['points'])==15 and F(shape['contracted_diameter_squared'])<scale**2 and shape['contracted_minimum_integer_gain']>=0
    coefficient=goal/scale**2
    run(local/'finite_rates.py',coefficient,comp/'exact-151-repair/result.json',out/'finite-rates.json')
    summary={'frozen_goal':str(goal),'scale':str(scale),'triangle_shift':str(shift),
        'lower_bound_exact':str(coefficient),'strict_decimal_floor':'.837451665671440883371603918521',
        'area_tree_round':221,'second_root_audit_round':234,
        'native_leaves':transfer['native_leaves'],'dense_leaves':mat['dense_leaves'],
        'radial_angle_cells':radial['grid'],'finite_material_points':len(shape['points']),
        'rate_thresholds':read(out/'finite-rates.json')}
    assert F(summary['strict_decimal_floor']) < coefficient
    (out/'combined.json').write_text(json.dumps(summary,indent=2)+'\n')
    assert summary==read(local/'expected.json')
    print('Verified the transferred bound',coefficient)


if __name__=='__main__':
    main()

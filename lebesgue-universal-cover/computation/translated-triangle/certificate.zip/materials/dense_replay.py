"""Recreate and compare old and lower-endpoint dense anchors on all 24 original leaves."""
from pathlib import Path
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor,as_completed
from hashlib import sha256
import sys,json
import numpy as np
D=Path(__file__).resolve().parent;C=Path(sys.argv[1]).resolve();TREE=Path(sys.argv[2]).resolve();TABLE=Path(sys.argv[3]).resolve();OUT=Path(sys.argv[4]).resolve();workers=int(sys.argv[5]) if len(sys.argv)>5 else 2
sys.path[:0]=[str(D),str(C),str(C/'six-input-083745')]
from certify_tomar_six_high import FINE,SourceTree,load_table
from replay_dense_083745 import inputs
from tomar_p30_scaled_material import scaled_material as old
from scaled_shift import scaled_material as new
oldpath=C/'tomar_p30_scaled_material.py';oldsrc=oldpath.read_text();assert sha256(oldpath.read_bytes()).hexdigest()=='da3fdc4472aaf0b09e020b6a3a7b467f227fe695c84ad0c4f502244e0f20cc2b';assert oldsrc.count('scale=arb(999999006)/1000000000')==1
expected_src=oldsrc.replace('scale=arb(999999006)/1000000000','scale=arb(999999005254)/10**12').replace('(X-scale*vx)**2+(Y-scale*vy)**2','(X-scale*vx-(arb(214)/10**12 if n==3 else 0))**2+(Y-scale*vy)**2')
assert (D/'scaled_shift.py').read_text()==expected_src
extra=np.array(json.loads((OUT.parent / "triangle-extra.json").read_text()),dtype=np.int32)
assert extra.shape==(192,2)
def job(item):
 key,raw,expected=item;data=json.loads(raw);tree=SourceTree(TREE);base=json.loads((C/'tomar-six-high-input.json').read_text());mat=load_table(TABLE,tree,base['tables']['64'])
 def scaled(xx):
  q=[F(v)*FINE for v in xx];assert all(n.denominator==1 for n in q);return np.array([int(n) for n in q],dtype=np.int64)
 lo,hi=(scaled(k) for k in zip(*tree.leaf(data['part'],data['pos']),strict=True));orig=scaled(tree.root['hi']);arr0,count0=old(mat,lo,hi,orig);arr1,count1=new(mat,lo,hi,orig);assert np.array_equal(count0,count1) and np.array_equal(arr0,arr1)
 assert count1.tolist()==[1024,384,640,896,1024]
 dense=arr1.reshape(1025,3968,2); assert np.all(dense[:,1216:1408,:]==extra[None,:,:])
 return {'leaf':key,'selection_sha256':sha256(raw).hexdigest(),'dense_sha256':sha256(arr0.tobytes()).hexdigest(),'counts':count0.tolist(),'integer_points':int(len(arr0)//2),'original_receipt_closed':bool(expected['all_closed']),'triangle_extra_exact_binding':True}
if __name__=='__main__':
 jobs=inputs(C/'six-input-083745/volumes');res=[]
 with ProcessPoolExecutor(max_workers=workers) as pool:
  for f in as_completed([pool.submit(job,x) for x in jobs]):
   x=f.result();res.append(x);print(x['leaf'],flush=True)
 assert len(res)==len({x['leaf'] for x in res})==24 and all(x['original_receipt_closed'] and x['triangle_extra_exact_binding'] for x in res)
 OUT.write_text(json.dumps({'scale':str(F('.999999005254')),'shift':str(F('.000000000214')),'all_passed':True,'leaves':sorted(res,key=lambda x:x['leaf'])},indent=2)+'\n')

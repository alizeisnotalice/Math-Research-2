"""Replay translated R3 and centered other materials; existing area certificate is an input."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import argparse,json,subprocess,sys
p=argparse.ArgumentParser(description=__doc__)
for n in ('computation','tree','table32','table64','out'): p.add_argument(n,type=Path)
p.add_argument('--workers',type=int,default=2)
a=p.parse_args();C=a.computation.resolve();T=a.tree.resolve();A=a.table32.resolve();B=a.table64.resolve();O=a.out.resolve();D=Path(__file__).resolve().parent
O.mkdir(parents=True,exist_ok=False);assert a.workers>0
assert sha256(A.read_bytes()).hexdigest()=='fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c'
assert sha256(B.read_bytes()).hexdigest()=='0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d'
def run(script,*args):
 cmd=[sys.executable,'-E','-B',str(D/script),*map(str,args)];print('RUN',script,flush=True);subprocess.run(cmd,check=True)
run('materials_precise.py',C,T,A,B,'.9999990055114',O/'materials.json')
mat=json.loads((O/'materials.json').read_text());assert Fraction(mat['scale'])==Fraction('.9999990055114')
assert len(mat['results'])==10 and {(x['table'],x['order']) for x in mat['results'] if not x['positive']}=={(32,3),(64,3)}
run('verify_triangle_precise.py',C,A,B,O)
tri=json.loads((O/'triangle-precise.json').read_text());assert [tri['results'][x]['comparisons'] for x in ('radial32','table64','extra')]==[288,576,576]
run('dense_replay.py',C,T,B,O/'dense.json',a.workers)
dense=json.loads((O/'dense.json').read_text());assert dense['all_passed'] and len(dense['leaves'])==24
out={'complete':True,'scope':'material membership and dense witness binding only; area tree and global transfer are separate inputs','scale':'0.9999990055114','r3_translation_x':'0.000000000062','dense_replay_scale':'0.999999005254','dense_replay_r3_translation_x':'0.000000000214','dense_leaves':24,'triangle_extra_exact_binding':True,'bound':tri['bound'],'output_hashes':{f.name:sha256(f.read_bytes()).hexdigest() for f in O.glob('*.json')}}
(O/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

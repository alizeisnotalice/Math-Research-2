from flint import arb,ctx
from fractions import Fraction as F
import numpy as np,json,hashlib,sys
from pathlib import Path
ctx.prec=256
R=Path(sys.argv[1]).resolve(); P32=Path(sys.argv[2]).resolve(); P=Path(sys.argv[3]).resolve(); O=Path(sys.argv[4]).resolve()
s=arb(9999990055114)/10**13; t=arb(62)/10**12; q=2**28; pi=arb.pi(); rad=1/(2*(pi/6).cos()); C=[(rad*(2*pi*j/3).cos(),rad*(2*pi*j/3).sin()) for j in range(3)]
with np.load(P32) as z: p32=z['points'][0,96:192].copy()
with np.load(P) as z: p64=z['points'][0,96:288].copy()
extra=[]
for k in range(192):
 theta=F(2*k+1,384); phi=2*pi*theta.numerator/theta.denominator; u,v=phi.cos(),phi.sin(); ci=(theta*3+2).__floor__()%3; x,y=C[ci]; dot=u*x+v*y; r=dot+(1-rad*rad+dot*dot).sqrt(); shrink=1-arb(3)/10**6; extra.append([round(float((u*r*shrink).mid())*q),round(float((v*r*shrink).mid())*q)])
(O/'triangle-extra.json').write_text(json.dumps(extra)+'\n')
results={}
for name,pts in [('radial32',p32),('table64',p64),('extra',extra)]:
 rows=[]
 for i,(xx,yy) in enumerate(pts):
  x,y=arb(int(xx))/q,arb(int(yy))/q
  for j,(cx,cy) in enumerate(C):
   gap=s*s-(x-t-s*cx)**2-(y-s*cy)**2
   assert gap>0,(name,i,j,gap)
   rows.append((float(gap.mid()),i,j,int(xx),int(yy),str(gap)))
 rows.sort(); results[name]={'comparisons':len(rows),'smallest':rows[:8]}
G=arb(120689264254125501)/2**57; bound=G/s**2; floor=F(".837451665671440883371603918521"); assert bound>arb(floor.numerator)/floor.denominator
out={'scale':str(s),'shift':str(t),'bound':str(bound),'results':results,'sha256_table64':hashlib.sha256(P.read_bytes()).hexdigest(),'sha256_table32':hashlib.sha256(P32.read_bytes()).hexdigest()};(O/'triangle-precise.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

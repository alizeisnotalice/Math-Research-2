"""Directed thresholds for the finite-point versions of the lower and upper reductions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json

from flint import arb, ctx


def value(q):
    q = F(q)
    return arb(q.numerator) / q.denominator


def odd_floor(n, bound):
    t = arb.pi() / (2 * n)
    ratio = (2 * t).cos() / t.cos()
    return value(bound) * ratio**2


def first_index(test):
    lo, hi = 1, 2
    while not test(hi):
        lo, hi = hi, 2*hi
    while hi-lo>1:
        middle = (lo+hi)//2
        if test(middle):
            hi = middle
        else:
            lo = middle
    return hi


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('lower_bound', type=F)
    parser.add_argument('repair_result', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    ctx.prec = 192
    finites = {}
    for threshold in ('.83745', '.83745160', '.83745166', '.8374516656'):
        target = value(threshold)
        half = first_index(lambda m: odd_floor(2*m+1,args.lower_bound) > target)
        odd = 2*half+1
        previous = odd_floor(odd-2,args.lower_bound)
        current = odd_floor(odd,args.lower_bound)
        assert odd-2 >= 101 and previous<target<current
        finites[threshold] = {'first_odd':odd, 'previous':str(previous), 'lower_bound':str(current)}
    area = F(json.loads(args.repair_result.read_bytes())['closed_box']['total_area_strict'][1])
    target = F('.844082046521218581802948589770767704354')
    def enlarged(n):
        return value(area)/(arb.pi()/n).cos()**2
    half = first_index(lambda m: enlarged(max(4,2*m)) < value(target))
    n = 2*half
    assert enlarged(n)<value(target)<enlarged(n-2)
    result = {'odd_thresholds':finites,'arbitrary_finite_covers':{'finite_area_budget':str(area),
              'target':str(target),'first_even':n,'at_previous':str(enlarged(n-2)),
              'at_threshold':str(enlarged(n))}}
    args.output.write_text(json.dumps(result,indent=2)+'\n')


if __name__ == '__main__':
    main()

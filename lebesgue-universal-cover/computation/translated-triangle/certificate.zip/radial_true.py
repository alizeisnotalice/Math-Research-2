from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.spatial import ConvexHull
from flint import arb,ctx
import json,sys,platform
ctx.prec=192
C=Path(sys.argv[1]);out=Path(sys.argv[2]);Q=2**28
p=np.load(C/'five-body-radial-material.npz');points=p['points'].astype(np.int64);disc=points[:96];vis=points[96:192]
S=F('.999999004');D=F('.00000001');r=F(1213521613074,2**44)-D;N=8192
ar=lambda x:arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
s=ar(S);pi=arb.pi();R=1/(2*(pi/6).cos());vs=[]
for k in range(3):
 sn,cs=(2*pi*k/3).sin_cos();vs.append((s*R*cs,s*R*sn))
assert all(4*(int(x)**2+int(y)**2)*S.denominator**2 <= (Q*S.numerator)**2 for x,y in disc)
safe=[];excluded=[]
for i,(x,y) in enumerate(vis):
 if all((arb(int(x))/Q-X)**2+(arb(int(y))/Q-Y)**2<s*s for X,Y in vs):safe.append((x,y))
 else:excluded.append([i,int(x),int(y)])
safe=np.array(safe,dtype=np.int64);assert len(safe)>3
rad=ar(r);delta=rad*pi/(6*N)+arb(2)/Q;error=int(float(delta*Q))+2;assert delta*Q<error
m=None;idx=None
for j in range(N):
 t=pi*(2*j+1)/(6*N);sn,cs=t.sin_cos();xr,yr=rad*cs*Q,rad*sn*Q;tx,ty=round(float(xr.mid())),round(float(yr.mid()));assert abs(xr-tx)<1 and abs(yr-ty)<1
 p=np.r_[disc,safe+[tx,ty]];ii=ConvexHull(p.astype(float)).vertices;v=p[ii];moving=(ii>=len(disc)).astype(np.int64);u=np.roll(v,-1,axis=0);nm=np.roll(moving,-1)
 det=v[:,0]*u[:,1]-v[:,1]*u[:,0];cx=moving*u[:,1]-nm*v[:,1];cy=nm*v[:,0]-moving*u[:,0]
 assert np.max(np.abs(v))<Q and error<Q//10 and np.min(det-error*(abs(cx)+abs(cy)))>0 and np.count_nonzero((v[:,1]<=0)&(u[:,1]>0))==1
 val=sum(map(int,det))-error*(abs(int(sum(cx)))+abs(int(sum(cy))))
 if m is None or val<m:m=val;idx=j
G=F(120689264254125501,2**57);alpha=pi/6;base=pi/4+3*(alpha.tan()-alpha)/4;assert base<ar(G);gap=F(m,2*Q**2)-G;assert gap>0
res=dict(scale=str(S),shift_bound=str(D),radius=str(r),grid=N,safe=len(safe),excluded=excluded,integer_lower=m,integer_denominator=2*Q**2,goal=str(G),gap=str(gap),gap_float=float(gap),min_cell=idx,error=error,python=platform.python_version(),numpy=np.__version__,complete=True)
out.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))

"""Replace exactly seven failed j31 rows after auditing their proof link."""
from fractions import Fraction as F
from pathlib import Path
import json,copy
from flint import arb
K=Path(__file__).resolve().parent
EXPECTED={60:'6.26',67:'6.28',68:'6.28',69:'6.26',70:'6.26',73:'6.28',74:'6.30'}

def patched(original,geometry,physical):
 r=json.loads((K/'j31-repair/receipt.json').read_text())
 assert r['complete'] and r['geometry_sha256']==geometry and r['physical_parameters']==physical
 assert original['complete'] and original['physical_parameters']==physical and original['geometry_sha256']==geometry
 assert F(r['EH_tightening']['retreat'])==F(original['EH_tightening']['retreat'])==F('.00000009488')
 assert r['EH_tightening']['label']==original['EH_tightening']['label']
 mandatory={'ordered_state.py','ordered_derivative.py','sigma154-turn01150-physical.json','certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py','certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py'}
 assert mandatory <= r['source_hashes'].keys() and mandatory <= original['source_hashes'].keys()
 assert all(r['source_hashes'][n]==original['source_hashes'][n] for n in mandatory)
 cfg=r['parameters'];assert cfg['bin']==31 and cfg['orientation']==0 and cfg['counts']==[5,0] and cfg['initial_derivative_sign']==-1 and F(cfg['cut'])==F('-.012') and cfg['angular']==12 and cfg['depth']==4
 assert {int(k):v for k,v in cfg['brackets'].items()}==EXPECTED
 new={}
 for item in r['rows']:
  row=item['row'];i=row['subcells'][0];assert i in EXPECTED and i not in new
  assert row['subcells']==[i,i+1] and item['bin']==row['reference_bin']==31 and item['orientation']==0 and item['counts']==[5,0] and item['initial_derivative_sign']==row['anchor_comparison_sign']==-1
  assert F(row['anchor_degrees'])==0 and F(row['anchor_threshold'])==F('.012')
  assert list(map(F,row['bracket']))==[F('.5'),F(EXPECTED[i])] and item['positive']
  assert arb(row['root_margin_lower'])>0 and arb(row['placement_margin_lower'])>0
  assert sum(row['pose_counts'].values())==row['placed_leaves']
  new[i]=item
 assert set(new)==set(EXPECTED)
 result=copy.deepcopy(original);bad=[]
 for k,item in enumerate(original['rows']):
  if item['positive']:continue
  row=item['row'];i=row['subcells'][0];bad.append(i)
  assert i in new and row['subcells']==[i,i+1] and item['bin']==31 and item['orientation']==0 and item['counts']==[5,0] and item['initial_derivative_sign']==-1
  result['rows'][k]=new[i]
 assert len(bad)==7 and set(bad)==set(EXPECTED) and all(x['positive'] for x in result['rows'])
 result['all_passed']=True
 return result

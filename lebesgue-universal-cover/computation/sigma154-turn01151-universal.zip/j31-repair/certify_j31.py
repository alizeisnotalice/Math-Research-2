"""Prove seven replacement cells using the original conditioned root kernel."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json
D=Path(__file__).resolve().parent;C=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);sys.path[:0]=[str(D),str(C)]
from flint import arb,ctx,__version__ as flint_version
from ordered_derivative import validate
from certify_sigma_extended_graph import geometry
assert __debug__
q=json.loads((D/'sigma154-turn01150-physical.json').read_text());cfg=json.loads((D/'parameters.json').read_text());assert q=={'sigma_degrees':'1.54','line':['.429','.01151'],'physical_parameters':['.313','.353','.0136']}
assert cfg=={'bin':31,'orientation':0,'counts':[5,0],'initial_derivative_sign':-1,'cut':'-.012','left':'.5','turn':0,'reflection':1,'retreat':'.00000009488','angular':12,'depth':4,'brackets':{'60':'6.26','67':'6.28','68':'6.28','69':'6.26','70':'6.26','73':'6.28','74':'6.30'}}
ns,src,_=geometry(C,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']))));assert sha256(src.encode()).hexdigest()=='e2437db6f43447705083984f7105bdeb3d2d640b0cff6a6b4fa17bdcbd59a09b'
ns['_sharpen_jets']=True;index,=[i for i,(label,_,_) in enumerate(ns['rows']) if label.startswith('U1-Te')];label,normal,offset=ns['rows'][index];assert F(ns['eh_depth'])==F('.000555');ns['rows'][index]=(label,normal,offset-ns['A'](F(cfg['retreat'])));ns['_first_orientation']=0;ns['_class_counts']=(5,0)
rows=[]
for key,right in cfg['brackets'].items():
 i=int(key);ns['_end_index']=i+1
 row=validate(ns,31,F(cfg['left']),F(right),cfg['turn'],cfg['reflection'],-1,cut=F(cfg['cut']),side=-1,begin=i,end=i+1,angular=cfg['angular'],depth=cfg['depth'])
 assert row['reference_bin']==31 and row['subcells']==[i,i+1] and row['anchor_comparison_sign']==-1 and F(row['anchor_degrees'])==0 and F(row['anchor_threshold'])==F('.012')
 assert list(map(F,row['bracket']))==[F(cfg['left']),F(right)]
 assert all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
 counts=row['pose_counts'];assert sum(counts.values())==row['placed_leaves'] and all(v>=0 for v in counts.values())
 rows.append({'bin':31,'orientation':0,'counts':[5,0],'initial_derivative_sign':-1,'row':row,'positive':True})
 print(i,right,row['root_margin_lower'],row['placement_margin_lower'],flush=True)
files=[D/'ordered_state.py',D/'ordered_derivative.py',D/'parameters.json',D/'sigma154-turn01150-physical.json',Path(__file__).resolve()]+[C/n for n in ('certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py','certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py')]
result={'complete':True,'parameters':cfg,'physical_parameters':q,'geometry_sha256':sha256(src.encode()).hexdigest(),'EH_tightening':{'label':label,'retreat':str(F(cfg['retreat']))},'rows':rows,'source_hashes':{p.name:sha256(p.read_bytes()).hexdigest() for p in files},'flint':flint_version}
out.write_text(json.dumps(result,indent=2)+'\n')

"""Recompute the original and refined first-hit budget on each of the joint five-cell blocks."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
base=Path(__file__).resolve().parent
comp=Path(sys.argv[1]).resolve();output=Path(sys.argv[2])
sys.path[:0]=[str(base),str(comp)]
from sharp_first_hit import first_budget
from certify_sigma_extended_graph import geometry
from certify_ah_local_physical_support import local_budgets
q=json.loads((base/'sigma154-turn01150-physical.json').read_bytes())
n,src,_=geometry(comp,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']))))
n['_first_orientation']=1
lo,hi=n['knots'][15:17];step=(hi-lo)/75
pairs=[]
for i in range(0,75,5):
    a,b=lo+i*step,lo+(i+5)*step
    first=min(n['two_hit_budgets'][15][1][0],local_budgets(n,a,b)[1][0])
    tight=first_budget(n,a,b,first)
    assert first.rad().is_zero() and tight>0 and tight.upper()<first.lower()
    pairs.append(dict(subcells=[i,i+5],initial=str(first),tight=str(tight),gain=str((first-tight).lower())))
result=dict(physical=q,geometry_sha256=sha256(src.encode()).hexdigest(),pairs=pairs)
output.write_text(json.dumps(result,indent=2)+'\n')

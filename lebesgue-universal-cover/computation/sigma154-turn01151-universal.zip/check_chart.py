"""Certify that the endpoint hulls in the ordered contact and first-hit support kernels contain the entire graph block."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,sys
comp=Path(sys.argv[1]).resolve();out=Path(sys.argv[2])
sys.path.insert(0,str(comp))
from certify_sigma_extended_graph import geometry
kit=Path(__file__).resolve().parent
q=json.loads((kit/'middle/sigma154-turn01150-physical.json').read_bytes())
n,src,_=geometry(comp,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']))))
bounds=[]
for j,(a,b) in enumerate(zip(n['knots'],n['knots'][1:])):
    _,gl,gt=n['points'](n['box'](a,b))
    dl,dt=[n['dot'](v,n['D']) for v in (gl,gt)]
    assert (dl>0 or dl<0) and (dt>0 or dt<0),(j,dl,dt)
    bounds.append({'bin':j,'ell_slope':str(dl),'t_slope':str(dt)})
assert len(bounds)==70
out.write_text(json.dumps({'physical':q,'geometry_sha256':sha256(src.encode()).hexdigest(),'bins':bounds},indent=1)+'\n')

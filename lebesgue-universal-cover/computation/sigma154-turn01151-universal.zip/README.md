# .01151 可重放合成包

本包固定 sigma=1.54°、AH 线参数 (.429,.01151)，物理参数 (.313,.353,.0136)。`computation/` 包含由 `common-sources.json` 锁定的80个公共源码及输入；`source-archive/` 按哈希保存79个原始回执及补强所需的其余来源。`snapshot-status.json` 是79项原始回执的输入与来源映射，`repair-map.json` 绑定 j31、j46、j49、j50 补强与其被替换的原始回执。

使用包含 python-flint 的 Python，开启断言，运行：

    PY -I -B verify.py computation WORKDIR OUTPUT.json
    cmp OUTPUT.json universal-cover.json

该总核重建几何和面积、验证早段、中段、额外段及其闭分割，重算闭域导数、嵌套预算、j15 partner 与 j31 补证，核对 j46、j49、j50 补强及全部源码映射。只有命令成功且与 `universal-cover.json` 一致时，才能认定本包总合成通过。

若要从各个已保存的原始参数独立重算每份区间回执：

    PY -I -B replay.py computation REPLAY_WORKDIR --list
    PY -I -B replay.py computation REPLAY_WORKDIR

重放程序为每个回执建立隔离工作目录；对历史参数中的绝对物理路径进行局部重定位，逐项核验原输入哈希及其余数学输出。重算各原始回执与总核合成是不同步骤。不能使用 Python `-O`。

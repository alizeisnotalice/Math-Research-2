"""Reconstruct the 46-bin certificate against its own fixed-layout inputs."""
from pathlib import Path
import subprocess,sys
kit=Path(__file__).resolve().parent
comp=Path(sys.argv[1]).resolve()
work=Path(sys.argv[2]).resolve()
name='01150-extra-partition-final.json'
subprocess.run([sys.executable,'-I','-B',str(kit/'extra'/'audit_extra.py'),str(comp),str(kit/'extra'),str(work/name)],check=True)
assert (kit/'extra'/name).read_bytes()==(work/name).read_bytes()

"""Verify the coverage, coupled split, physical identities, and proof sources of an ordered-class receipt."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import argparse
from flint import arb,ctx


def digest(p):return sha256(p.read_bytes()).hexdigest()


def audit(comp,config,receipt,geometry_digest,ranges):
    ctx.prec=160
    obj=json.loads(receipt.read_bytes());cfg=json.loads(config.read_bytes())
    assert obj['complete'] and obj['all_passed'] and cfg==obj['parameters']
    assert obj['geometry_sha256']==geometry_digest
    physical=config.parent/Path(cfg['physical']).name;p=json.loads(physical.read_bytes())
    assert p==obj['physical_parameters'] and F(p['sigma_degrees'])==F('1.54')
    retreat=F(cfg['retreat']);anchor=F(cfg['anchor']);threshold=F(cfg['threshold'])
    assert threshold>0 and retreat>=0 and obj['EH_tightening']['label'].startswith('U1-Te')
    assert F(obj['EH_tightening']['retreat'])==retreat
    src=Path(__file__).resolve().parent
    runner='certify_synchronized.py' if obj.get('synchronized') else 'certify_ordered_root.py'
    files=[src/runner,src/'ordered_state.py',config,physical,
           *(comp/k for k in ('certify_sigma_pinned_fan.py','certify_ah_affine_root_class.py','certify_sigma_extended_graph.py'))]
    assert obj['source_hashes']=={p.name:digest(p) for p in files}
    assert sorted(set(cfg['bins']))==sorted(cfg['bins'])
    assert {str(k):ranges[str(k)] for k in cfg['bins']}==obj['reachable']
    buckets={};blocks={};chosen={}
    for item in obj['rows']:
        j=item['bin'];ori=item['orientation'];side=item['angle_class'];k,k1=item['counts'];row=item['row']
        assert j in cfg['bins'] and ori in (0,1) and side in (-1,1) and k in range(6) and k1==5-k
        assert row['reference_bin']==j and row['anchor_comparison_sign']==side
        assert F(row['anchor_degrees'])==anchor and F(row['anchor_threshold'])==-threshold
        l,r=map(F,row['bracket']);opts=cfg['low_brackets'] if side==-1 else cfg['high_brackets']
        assert l<r and (side==1 or r==anchor) and any([l,r]==list(map(F,o[:2])) for o in opts)
        a,b=row['subcells'];assert 0<=a<b<=75
        root=arb(row['root_margin_lower']).lower();pose=arb(row['placement_margin_lower']).lower()
        assert root>0 and pose>0
        buckets.setdefault((j,ori,k,side),[]).extend(range(a,b))
        blocks.setdefault((j,ori,k,side),[]).append((a,b))
        old=chosen.get(j,(arb(1),arb(1)));chosen[j]=min(root,old[0]),min(pose,old[1])
    for j in cfg['bins']:
        indices=[i for a,b in ranges[str(j)] for i in range(a,b)]
        for ori in (0,1):
            for k in range(6):
                for side in (-1,1):
                    assert sorted(buckets[j,ori,k,side])==indices
                    assert sorted(blocks[j,ori,k,side])==sorted(blocks[j,ori,0,side])
    return {j:{'root':str(a),'pose':str(b),'retreat':str(retreat)} for j,(a,b) in chosen.items()}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for arg in ('comp','config','receipt','physical_area'):p.add_argument(arg,type=Path)
    a=p.parse_args();f=json.loads(a.physical_area.read_bytes())
    assert json.loads((a.config.parent/Path(json.loads(a.config.read_bytes())['physical']).name).read_bytes())==f['parameters']
    print(json.dumps(audit(a.comp,a.config,a.receipt,f['chart']['geometry_sha256'],f['chart']['reference_ranges']),indent=2))

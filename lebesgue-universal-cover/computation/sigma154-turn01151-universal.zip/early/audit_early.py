"""Audit .01150 original-range completeness and both physical-root branches in bins 0 through 11."""
from fractions import Fraction as F
from pathlib import Path
import sys,json
from hashlib import sha256
from flint import arb,ctx
kit=Path(__file__).resolve().parent
sys.path.insert(0,str(kit))
from audit_ordered_receipt import audit
comp=Path(sys.argv[1]).resolve();physical=Path(sys.argv[2]);out=Path(sys.argv[3])
load=lambda p:json.loads(p.read_bytes())
area=load(physical);pcfg=load(kit/'sigma154-turn01150-physical.json')
assert area['parameters']==pcfg and list(map(F,pcfg['line']))==[F('.429'),F('.01151')]
assert list(map(F,pcfg['physical_parameters']))==[F('.313'),F('.353'),F('.0136')]
geom=area['chart']['geometry_sha256'];ranges=area['chart']['reference_ranges']
assert sum(y-x for r in ranges.values() for x,y in r)==5183
cost=F(next(r['transfer_cost_upper'] for r in area['geometry']['cases'] if r['label']=='eleven'))
groups={};count=0
for s in ['j0','j1-3','j4-7','j8-11']:
    d=kit/(s+'-certificate.json');c=kit/(s+'-params.json')
    records=audit(comp,c,d,geom,ranges)
    count+=len(load(d)['rows'])
    assert not (records.keys() & groups.keys())
    for j,r in records.items():
        assert F(r['retreat'])>cost
        groups[j]={**r,'receipt':d.name,'sha256':sha256(d.read_bytes()).hexdigest()}
assert sorted(groups)==list(range(12))
assert sum(y-x for j in groups for x,y in ranges[str(j)])==900
ctx.prec=160
root,i=min((arb(r['root']).lower(),j) for j,r in groups.items())
pose,k=min((arb(r['pose']).lower(),j) for j,r in groups.items())
out.write_text(json.dumps({'complete':True,'physical':pcfg,'geometry_sha256':geom,'all_physical_subcells':5183,'verified_subcells':900,'class_records':count,'root':str(root),'limiting_root_bin':i,'pose':str(pose),'limiting_pose_bin':k,'bins':groups},indent=1)+'\n')

"""Check that the y5 and e partitions agree across nested physical blocks."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

p=ArgumentParser(description=__doc__)
p.add_argument('computation',type=Path)
p.add_argument('output',type=Path)
p.add_argument('bins',nargs='+',type=int)
a=p.parse_args()
comp=a.computation.resolve();sys.path.insert(0,str(comp))
from certify_sigma_extended_graph import geometry
from certify_ah_local_physical_support import local_budgets
from certify_sigma_reachable_roots import reach

inp=Path(__file__).with_name('sigma154-turn01150-physical.json')
q=json.loads(inp.read_bytes())
pivot,turn=map(F,q['line']);far,negative,eps=map(F,q['physical_parameters'])
ns,source,_=geometry(comp,[(pivot,turn)],sigma=q['sigma_degrees'],far=far,negative=negative,eps=eps)
results=[]
for j in a.bins:
    lo,hi=ns['knots'][j:j+2]
    step=(hi-lo)/75
    records={}
    for block in (1,5,15):
        vals={}
        for left,right in reach(ns,j):
            for beg in range(left,right,block):
                end=min(right,beg+block)
                real=local_budgets(ns,lo+beg*step,lo+end*step)
                old=ns['two_hit_budgets'][j]
                first,second=(min(c,d) for c,d in zip(real[0],old[0],strict=True))
                vals[beg,end]=first,second
        records[block]=vals
    rows=[]
    room=ns['A'](1)
    for block, vals in records.items():
        for (beg,end),(first,second) in vals.items():
            slack=(second-first).lower()
            room=min(room,slack)
            if block in (1,5):
                parent=5 if block==1 else 15
                f,s=next(v for (p,q),v in records[parent].items() if p<=beg<end<=q)
                assert f.upper()>=first.upper() and s.upper()>=second.upper(),(j,beg,end,f,s,first,second)
            rows.append([block,beg,end,str(first),str(second)])
    results.append({'bin':j,'min_S_minus_F':str(room),'rows':rows})
    print(j,room,len(rows),flush=True)
a.output.write_text(json.dumps({'complete':True,'physical':q,'physical_sha256':sha256(inp.read_bytes()).hexdigest(),
                    'geometry_sha256':sha256(source.encode()).hexdigest(),
                    'monotone_F_S_across_nested_blocks':True,
                    'results':results},indent=2)+'\n')

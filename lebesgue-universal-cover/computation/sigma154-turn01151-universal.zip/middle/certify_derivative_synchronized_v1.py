"""Split the real initial derivative, using synchronized contact-class partitions."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys


def run(comp,config,output):
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from flint import arb, __version__ as flint_version
    from ordered_derivative import validate
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach

    cfg=json.loads(config.read_bytes())
    phys_path=config.parent/cfg['physical']
    if not phys_path.exists():
        phys_path=comp/cfg['physical']
    phys=json.loads(phys_path.read_bytes())
    pivot,turn=map(F,phys['line'])
    pars=dict(zip(('far','negative','eps'),map(F,phys['physical_parameters']),strict=True))
    ns,source,_=geometry(comp,[(pivot,turn)],sigma=phys['sigma_degrees'],**pars)
    ns['_sharpen_jets']=True
    index,=[i for i,(label,_,_) in enumerate(ns['rows']) if label.startswith('U1-Te')]
    label,normal,offset=ns['rows'][index];retreat=F(cfg['retreat'])
    assert retreat>=0 and F(ns['eh_depth'])==F('.000555')
    ns['rows'][index]=label,normal,offset-ns['A'](retreat)
    ranges={j:reach(ns,j) for j in cfg['bins']}
    cut=F(cfg['cut'])
    records=[]
    def visit(j,orientation,side,a,b):
        ns['_end_index']=b;ns['_first_orientation']=orientation
        result=[]
        for count in range(6):
            ns['_class_counts']=(count,5-count)
            options=cfg['low_brackets' if side==-1 else 'high_brackets']
            for l,r,k,s in options:
                row=validate(ns,j,F(l),F(r),k,s,side,cut=cut,side=side,begin=a,end=a+1,angular=12,depth=cfg['depth'])
                valid=all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
                if valid:
                    break
            if not valid and b-a>1:
                mid=(a+b)//2
                return visit(j,orientation,side,a,mid)+visit(j,orientation,side,mid,b)
            row['subcells']=[a,b]
            result.append(dict(bin=j,orientation=orientation,counts=[count,5-count],initial_derivative_sign=side,row=row,positive=valid))
        return result
    partitions={}
    for j in cfg['bins']:
        for orientation in (0,1):
            for side in (-1,1):
                sub=[]
                for a,b in ranges[j]:
                    for l in range(a,b,cfg['block']):
                        sub+=visit(j,orientation,side,l,min(b,l+cfg['block']))
                common=[t['row']['subcells'] for t in sub if t['counts'][0]==0]
                assert [i for l,r in common for i in range(l,r)]==[i for l,r in ranges[j] for i in range(l,r)]
                assert all([t['row']['subcells'] for t in sub if t['counts'][0]==k]==common for k in range(6))
                partitions[f'{j},{orientation},{side}']=common
                records+=sub
                print(j,orientation,side,len(sub),sum(not t['positive'] for t in sub),flush=True)
    minimum={z:str(min(arb(t['row'][z]).lower() for t in records)) for z in ('root_margin_lower','placement_margin_lower')}
    here=Path(__file__).resolve()
    sources=(here,here.with_name('ordered_state.py'),here.with_name('ordered_derivative.py'),config,phys_path,
             *(comp/f for f in ('certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py',
                'certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py')))
    output.write_text(json.dumps(dict(complete=True,all_passed=all(r['positive'] for r in records),
        parameters=cfg,physical_parameters=phys,reachable=ranges,synchronized=True,partitions=partitions,
        EH_tightening={'label':label,'retreat':str(retreat)},geometry_sha256=sha256(source.encode()).hexdigest(),
        minima=minimum,source_hashes={p.name:sha256(p.read_bytes()).hexdigest() for p in sources},
        python=sys.version,flint=flint_version,rows=records),indent=2)+'\n')


if __name__=='__main__':
    assert __debug__
    p=ArgumentParser(description=__doc__)
    for name in ('comp','config','output'):
        p.add_argument(name,type=Path)
    args=p.parse_args()
    run(args.comp.resolve(),args.config.resolve(),args.output.resolve())

"""Bound the first real hit directly by the inward AH line along the chart's t fibre."""
from fractions import Fraction as F


def dyadic(x):
    m,e=map(int,x.man_exp())
    return F(m,2**(-e)) if e<0 else F(m*2**e)


def first_budget(ns,a,b,first):
    assert ns["_first_orientation"]==1
    if first.is_zero():
        return first
    cache=ns.setdefault('_first_budget_cache',{})
    upper=dyadic(first.upper())
    key=(a,b,upper)
    if key in cache:
        return cache[key]
    A,add,mul,dot,box=(ns[k] for k in ('A','add','mul','dot','box'))
    D,z=(ns[k] for k in ('D','z'))
    line, u, h=[row for row in ns['rows'] if row[0].startswith('AH-line:')][-1]
    assert line=='AH-line:3'
    # The first orientation has reference partner on the original straight graph.
    def coordinates(w):
        ell,t=ns['chart'](add(z,mul(A(w),D)))
        return ns['psi'](ell),-t
    lo,hi=coordinates(a),coordinates(b)
    l,t=[v.union(w) for v,w in zip(lo,hi,strict=True)]
    def partials(e):
        x,l0,n0=ns['chart_bounds'](l,t-e)
        xl,xt=ns['derivs'](x,l0,n0)
        return dot(u,xl),dot(u,xt)
    # Strict positivity of the e derivative for every admissible depth.
    deriv=min(partials(box(upper*i/32,upper*(i+1)/32))[1].lower() for i in range(32))
    if not deriv>0:
        cache[key]=first
        return first
    _,gl,gn=ns['points'](box(a,b))
    ell0=ns['chart'](add(z,mul(A(a),D)))[0]
    ell1=ns['chart'](add(z,mul(A(b),D)))[0]
    partner_slope=ns['psi_prime'](add(ns['l0'],mul(ell0.union(ell1),ns['el'])))
    assert partner_slope<0
    dl,dt=partner_slope*dot(gl,D),-dot(gn,D)
    mid=(a+b)/2; lm,tm=coordinates(mid)
    def retained(e):
        x_l,x_t=partials(A(e))
        dw=-dl*x_l-dt*x_t
        if dw>0:
            l0,t0=lo
            return h-dot(u,ns['X'](l0,t0-A(e)))
        if dw<0:
            l0,t0=hi
            return h-dot(u,ns['X'](l0,t0-A(e)))
        return h-dot(u,ns['X'](lm,tm-A(e)))+box(a-mid,b-mid)*dw
    if not retained(upper)>0:
        cache[key]=first
        return first
    lower=F(0)
    for _ in range(24):
        split=(lower+upper)/2
        if retained(split)>0:
            upper=split
        else:
            lower=split
    assert retained(upper)>0
    result=A(upper)
    assert result<=first or result.upper()<=first.upper()
    cache[key]=result
    return result

"""Support over an oriented and bounded contact simplex, with the averaged chart derivatives on that same class."""
import inspect,itertools
from fractions import Fraction as F
from certify_sigma_pinned_fan import support_bound as original


def support_bound(ns,j,a,b):
    E,v,edges,baseline,_=original(ns,j,a,b)
    base=inspect.getclosurevars(baseline).nonlocals
    ce=inspect.getclosurevars(base['event']).nonlocals
    n=ce['ns']
    A,mul,add,dot,reflect=[ns[k] for k in ('A','mul','add','dot','reflection')]
    zero=A(0);z=(zero,zero)
    ori=ns['_first_orientation']
    first,second=n['two_hit_budgets'][j][ori]
    if ori==0 and ns.get('_tighten_first'):
        from sharp_first_hit import first_budget
        first=first_budget(ns,a,b,first)
    levels=ns.get('_class_counts',(5,))
    assert sum(levels)==5
    ell_lo,ell_hi=ns.get('_e_class',(F(0),F(1)))
    low,high=(first*A(f) for f in (ell_lo,ell_hi))
    corner_e=[low,high,second.min(high).max(low)]
    evs=[(e,e.min(second)) for e in corner_e]
    iv=[(A(F(k,len(levels))),A(F(k+1,len(levels)))) for k,ct in enumerate(levels) for _ in range(ct)]
    def bounded(vals):return min(x.lower() for x in vals).union(max(x.upper() for x in vals))
    l1,l2=[ns['chart'](add(ns['z'],mul(A(w),ns['D']))) for w in (a,b)]
    ell,t=[l1[i].union(l2[i]) for i in (0,1)]
    paired=ns['coord_hull'](ns['psi'],ell)
    m=ce['local_m'][ori]
    xi=bounded([-(e+u)*x/m for e,u in evs for x in iv[2]])
    cc=bounded([(e+u)*x-u for e,u in evs for x in iv[3]])
    # Both inequalities in the established global graph tube also hold on every class.
    xi=xi.intersection((-A(F(2,3))*high).union(zero))
    loc={}
    for k,L,T in ((4,ell,t),(2,paired,-t)):
        is_first=(k==4)==(ori==0)
        dl=zero if is_first else xi
        dt=(-high).union(-low) if is_first else cc
        su=z;sv=z
        for kq in range(8):
            lam=A(F(kq,8)).union(A(F(kq+1,8)))
            point,ll,nn=ns['chart_bounds'](L+lam*dl,T+lam*dt)
            du,dv=ns['derivs'](point,ll,nn)
            su=add(su,mul(A(F(1,8)),du));sv=add(sv,mul(A(F(1,8)),dv))
        loc[k]=(su,sv) if k==4 else (reflect(su),reflect(sv))
    extr=base['extremal']
    chain=ce['support_chain']
    def event(action):
        vec=[z]*5
        for i,u in action:vec[i]=add(vec[i],u)
        ll=dot(vec[0],ns['el']);lr=dot(vec[1],reflect(ns['el']));dt=dot(vec[3],ns['en'])
        a2,t2=(dot(vec[2],u) for u in loc[2]);a4,t4=(dot(vec[4],u) for u in loc[4])
        x,eta,xi,first,de,partner=(ll,lr,a2,t4,dt,t2) if ori==0 else (lr,ll,a4,t2,-dt,t4)
        coeffs=[x/(m*A('.95')),-eta/m,-xi/m,partner,-de]
        kappa=zero;offset=0
        for k,count in enumerate(levels):
            if count:kappa+=chain(coeffs[offset:offset+count],*iv[offset])
            offset+=count
        return extr([((kappa-first)*e+(de-partner+kappa)*u)/E for e,u in evs])
    def bound(terms):
        choices=base['choices'];cor=base['correction'](terms)
        return extr([event(sum(c,[])+cor) for c in itertools.product(*(choices(w,u) for w,u in terms))]).upper()
    return E,v,edges,bound,None

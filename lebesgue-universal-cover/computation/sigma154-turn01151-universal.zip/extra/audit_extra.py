"""Verify the actual cap, nested contact classes and 46 assigned reference bins."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb, ctx


ROOT = 'root_margin_lower'
POSE = 'placement_margin_lower'
RETREAT = F('.00000009488')
ORDERED_BINS = (*range(32, 38), *range(42, 51))
ASSIGNED_BINS = (*range(12, 24), *ORDERED_BINS, *range(51, 70))


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def cells(intervals):
    return [i for a, b in intervals for i in range(a, b)]


def blocks(size):
    return [[a, a + size] for a in range(0, 75, size)]


def strict_margins(rows, transfer=arb(0)):
    assert rows
    root = min(arb(r[ROOT]).lower() for r in rows)
    retained_pose = min((arb(r[POSE]) - transfer).lower() for r in rows)
    assert min(root, retained_pose) > 0, (root, retained_pose)
    return {ROOT: str(root), POSE: str(retained_pose)}


def exact_budgets(comp, cfg, geometry_sha):
    from certify_ah_local_physical_support import local_budgets
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach

    ns, source, _ = geometry(comp, [tuple(map(F, cfg['line']))], sigma=cfg['sigma_degrees'],
                             **dict(zip(('far', 'negative', 'eps'), map(F, cfg['physical_parameters']), strict=True)))
    assert sha256(source.encode()).hexdigest() == geometry_sha
    summary = []
    for j in ORDERED_BINS:
        assert [list(x) for x in reach(ns, j)] == [[0, 75]]
        lo, hi = ns['knots'][j:j+2]
        step = (hi - lo) / 75
        old = ns['two_hit_budgets'][j][0]
        pairs = {}
        for width in (1, 5, 15):
            for a, b in blocks(width):
                f, s = [min(x, y) for x, y in zip(old, local_budgets(ns, lo+a*step, lo+b*step)[0], strict=True)]
                assert f.rad().is_zero() and s.rad().is_zero() and f > 0 and s >= 0, (j, a, b)
                pairs[a, b] = f, s
        assert len(pairs) == 95
        for child, parent in ((1, 5), (5, 15)):
            for a, b in blocks(child):
                start = a // parent * parent
                f, s = pairs[a, b]
                pf, ps = pairs[start, start+parent]
                assert f <= pf and s <= ps, (j, a, b, f, pf, s, ps)
        summary.append(dict(bin=j, exact_pairs=len(pairs), verified_nesting=[1, 5, 15]))
    return summary


def validated_bracket(row, brackets):
    left, right = map(F, row['bracket'])
    assert left < right
    assert any([left, right] == list(map(F, options[:2])) for options in brackets), row


def synchronized(rec, j, ranges, angle):
    settings = rec['parameters']
    key = 'angle_class' if angle else 'initial_derivative_sign'
    assert rec['complete'] and rec['all_passed'] and rec['synchronized'] and settings['bins'] == [j]
    grouped = defaultdict(list)
    for item in rec['rows']:
        row = item['row']
        o, branch = item['orientation'], item[key]
        counts = tuple(item['counts'])
        assert item['bin'] == row['reference_bin'] == j and branch == row['anchor_comparison_sign']
        assert item.get('positive', True)
        validated_bracket(row, settings['low_brackets'] if branch == -1 else settings['high_brackets'])
        if angle:
            assert F(row['anchor_degrees']) == F(settings['anchor'])
            assert F(row['anchor_threshold']) == -F(settings['threshold']) < 0
            assert branch == 1 or F(row['bracket'][1]) == F(settings['anchor'])
        else:
            assert F(row['anchor_degrees']) == 0 and F(row['anchor_threshold']) == -F(settings['cut'])
        grouped[o, branch, counts].append(row['subcells'])
    assert len(grouped) == 24
    for o in (0, 1):
        for branch in (-1, 1):
            model = grouped[o, branch, (0, 5)]
            assert cells(model) == cells(ranges)
            assert all(grouped[o, branch, (k, 5-k)] == model for k in range(6))
    return [item['row'] for item in rec['rows']]


def ordered(rec, j, required, ignored=()):
    assert rec['complete'] and rec['parameters']['bins'] == [j]
    settings = rec['parameters']

    def key(item):
        return (item['orientation'], tuple(item['counts']), tuple(map(F, item.get('e_class', ('0', '1')))),
                item.get('tighten_first', settings.get('tighten_first', False)))

    specifications = {key(item): item['brackets'] for item in settings['classes']}
    assert set(specifications) == set(required) | set(ignored)
    actual = defaultdict(list)
    retained = []
    for item in rec['rows']:
        row = item['row']
        model = key(item)
        assert item['bin'] == row['reference_bin'] == j
        plans = [option for option in specifications[model] if option[2:] == row['pose']]
        validated_bracket(row, plans)
        if model in ignored:
            continue
        assert item['positive'], (j, model, row['subcells'])
        actual[model].append(row['subcells'])
        retained.append(row)
    assert actual == required, (j, set(actual), set(required))
    return retained


def run(comp, work):
    assert __debug__
    sys.path.insert(0, str(comp))
    from certify_sigma154_deeper_composition import area_geometry, physical_chart

    cfg_name = 'sigma154-turn01150-physical.json'
    cfg = load(work/cfg_name)
    transfer_data = load(work/'01150-physics-replay.json')
    assert cfg == transfer_data['parameters']
    assert tuple(map(F, cfg['line'])) == (F('.429'), F('.01151'))
    assert tuple(map(F, cfg['physical_parameters'])) == (F('.313'), F('.353'), F('.0136'))
    ctx.prec = 160
    chart, chart_row = physical_chart(comp, cfg)
    ctx.prec = 160
    geometry = area_geometry(comp, comp, cfg, chart_row)
    assert json.loads(json.dumps(chart)) == transfer_data['chart'] and geometry == transfer_data['geometry']
    geometry_sha = chart['geometry_sha256']
    chart_ranges = chart['reference_ranges']
    assert chart['reference_subcells'] == 5183 and chart_ranges[69] == [[0, 8]]
    assert all(chart_ranges[j] == [[0, 75]] for j in range(69))
    eleven = next(r for r in geometry['cases'] if r['label'] == 'eleven')
    assert F(eleven['area']['exact'][1]) < F('.844090000000')
    cost = F(eleven['transfer_cost_upper'])
    assert 0 < cost < RETREAT
    budgets = exact_budgets(comp, cfg, geometry_sha)
    ctx.prec = 160
    result = []
    replay = {}

    def rec(stem, j, origin, kind):
        prefix = 'returned' if origin == 'MacBook' else 'local-replay/receipts'
        path = work/prefix/(f'01150-{stem}-receipt.json')
        ip = work/f'01150-{stem}-parameters.json'
        d = load(path)
        assert d['parameters'] == load(ip)
        kernels = ('base', 'sharp', 'angle', 'partner')
        candidates = [work, *(work/'kernels'/k for k in kernels), comp]
        for name, h in d['source_hashes'].items():
            paths = [*candidates, work.parent/'source-archive'/h]
            assert any((p/name).is_file() and digest(p/name) == h for p in paths), (name, h)
        if kind != 'ordinary':
            assert d['physical_parameters'] == cfg and d['geometry_sha256'] == geometry_sha
            assert d['reachable'][str(j)] == chart_ranges[j]
            assert d['EH_tightening']['label'].startswith('U1-Te') and F(d['EH_tightening']['retreat']) == RETREAT
        else:
            assert all(d['parameters'][key] == cfg[key] for key in cfg)
        rel = str(path.relative_to(work))
        replay[rel] = dict(input=ip.name, input_sha256=digest(ip), origin=origin, kind=kind)
        return d, {rel: digest(path)}

    def add_synchronized(j, kind, origin):
        data, files = rec(f'j{j}-{kind}-sync', j, origin, kind)
        rows = synchronized(data, j, chart_ranges[j], kind == 'angle')
        result.append(dict(bin=j, minima=strict_margins(rows), sha256=files, checked_class_blocks=len(rows)))

    for j in (*range(12, 15), *range(16, 24)):
        add_synchronized(j, 'angle' if j < 15 else 'slope', 'MacBook')

    for j in ORDERED_BINS:
        is_local_coarse = j in (32, 34)
        easy_size = 5 if is_local_coarse else 15
        easy = {(o, (k, 5-k), (F(0), F(1)), False): blocks(easy_size)
                for o in (0, 1) for k in range(6) if (o, k) != (0, 5)}
        direct_tag = 'direct-sync5' if is_local_coarse else ('extra-direct-frozen' if j >= 48 else 'direct-frozen')
        d, files = rec(f'j{j}-{direct_tag}', j, 'Mac mini' if is_local_coarse else 'MacBook', 'direct')
        ignored = {(0, (5, 0), (F(0), F(1)), False)} if j == 47 else set()
        rows = ordered(d, j, easy, ignored)
        mix_tag = 'remaining-mixed-v2' if j <= 46 else 'extra-remaining-mixed'
        mixed, additions = rec(f'j{j}-{mix_tag}', j, 'MacBook', 'mixed')
        files.update(additions)
        low = {(0, (5, 0), (F(0), F(1, 2)), False): blocks(5)}
        low.update({(0, (k, 5-k, 0, 0), (F(1, 2), F(1)), False): blocks(5) for k in range(5)})
        tail = (0, (5, 0, 0, 0), (F(1, 2), F(1)), False)
        if j <= 34:
            rows += ordered(mixed, j, {**low, tail: blocks(1)})
        else:
            rows += ordered(mixed, j, low, {tail})
            if j <= 46:
                stiff = {(0, (5, 0, 0, 0), (F(1, 2), F(1)), True): blocks(1)}
                sharp_tag = 'sharp-rescue'
            else:
                stiff = {(0, (k, 5-k, 0, 0, 0, 0, 0, 0), (F(1, 2), F(1)), True): blocks(1)
                         for k in range(6)}
                sharp_tag = 'sharp-eighths'
            sharp, additions = rec(f'j{j}-{sharp_tag}', j, 'Mac mini', 'sharp')
            files.update(additions)
            if j in (46,49,50):
                # Replace the deepest sharp class by an exhaustive closed
                # partition of the same local Fsharp range.
                divisions=4 if j==46 else 8
                counts=[5]+[0]*(3 if j==46 else 7)
                deepest = (0, tuple(counts), (F(1,2),F(1)), True)
                rows += ordered(sharp, j, {k:v for k,v in stiff.items() if k != deepest}, {deepest})
                rp = work/f'01151-j{j}-repair-receipt.json'
                repair = load(rp)
                assert repair['complete'] and repair['all_passed']
                assert repair['physical_parameters']==cfg and repair['geometry_sha256']==geometry_sha
                assert repair['reachable']=={str(j):[[0,75]]}
                assert F(repair['EH_tightening']['retreat'])==RETREAT
                assert repair['EH_tightening']['label'].startswith('U1-Te')
                spec=repair['parameters'];assert spec['bins']==[j] and spec['block']==1 and spec['freeze_blocks']
                assert F(spec['retreat'])==RETREAT
                assert len(spec['classes'])==divisions and len(repair['rows'])==75*divisions
                assert set(repair['source_hashes'])
                for name,h in repair['source_hashes'].items():
                    f=work.parent/'source-archive'/h/name
                    assert f.is_file() and digest(f)==h,(name,h)
                for k in range(divisions):
                    lo,hi=F(k,divisions),F(k+1,divisions)
                    cls,=[x for x in spec['classes'] if tuple(map(F,x['e_class']))==(lo,hi)]
                    assert cls['orientation']==0 and cls['counts']==counts and cls['tighten_first'] and cls['block']==1
                    part=[x for x in repair['rows'] if tuple(map(F,x['e_class']))==(lo,hi)]
                    assert len(part)==75 and [x['row']['subcells'] for x in part]==blocks(1)
                    for item in part:
                        row=item['row'];assert item['bin']==row['reference_bin']==j and item['orientation']==0
                        assert item['counts']==cls['counts'] and item['tighten_first'] and item['positive']
                        options=[z for z in cls['brackets'] if z[2:]==row['pose']]
                        validated_bracket(row,options)
                        rows.append(row)
                files[rp.name]=digest(rp)
            else:
                rows += ordered(sharp, j, stiff)
        result.append(dict(bin=j, minima=strict_margins(rows), sha256=files, checked_class_blocks=len(rows)))

    for j in range(51, 70):
        group = next((stem for lo, hi, stem in (
            (51, 51, 'j48-51-ordinary'), (52, 55, 'j52-55-ordinary'), (56, 59, 'j56-59-ordinary'),
            (60, 63, 'j60-63-ordinary'), (64, 65, 'j64-67-ordinary'), (66, 69, 'j66-69-narrow')) if lo <= j <= hi))
        d, files = rec(group, j, 'MacBook', 'ordinary')
        item, = [item for item in d['rows'] if item['bin'] == j]
        plan, = [p for p in d['parameters']['bins'] if p[0] == j]
        assert plan[1] == 'direct' and item['positive'] and item['reachable'] == chart_ranges[j]
        row, = item['classes']
        assert row['reference_bin'] == j and [row['subcells']] == chart_ranges[j] and row['pose'] == plan[2][2:]
        validated_bracket(row, [plan[2]])
        result.append(dict(bin=j, minima=strict_margins([row], arb(cost.numerator)/cost.denominator),
                           sha256=files, checked_class_blocks=1))

    direct, files = rec('j15-direct-sync', 15, 'Mac mini', 'direct')
    expected = {(0, (k, 5-k), (F(0), F(1)), False): blocks(5) for k in range(6)}
    ignored = {(1, (k, 5-k), (F(0), F(1)), False) for k in range(6)}
    rows = ordered(direct, 15, expected, ignored)
    partner, additions = rec('j15-partner-fibre', 15, 'Mac mini', 'partner')
    targets = {(1, (k, 5-k), (F(0), F(1)), True): blocks(5) for k in range(6)}
    rows += ordered(partner, 15, targets)
    files.update(additions)
    result.append(dict(bin=15, minima=strict_margins(rows), sha256=files, checked_class_blocks=len(rows)))
    result.sort(key=lambda r: r['bin'])
    assert [r['bin'] for r in result] == list(ASSIGNED_BINS)
    subcells = sum(len(cells(chart_ranges[j])) for j in ASSIGNED_BINS)
    assert subcells == 3383
    return dict(complete=True, parameters=cfg, geometry_sha256=geometry_sha, subcells=subcells, bins=result,
                minima={name: str(min(arb(r['minima'][name]).lower() for r in result)) for name in (ROOT, POSE)},
                eleven_area_upper=eleven['area']['decimal'][1], exact_nested_budgets=budgets,
                EH_transfer_cost_upper=str(cost), source_sha256=digest(Path(__file__)), replay=replay)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for key in ('computation', 'workspace', 'output'):
        parser.add_argument(key, type=Path)
    args = parser.parse_args()
    result = run(args.computation.resolve(), args.workspace.resolve())
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(result['subcells'], result['minima'], flush=True)

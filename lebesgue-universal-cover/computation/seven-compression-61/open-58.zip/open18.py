"""Dimension-58 perturbation family preserving the two physical point hulls at the same poses."""
import argparse,hashlib,json
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def family(path):
    raw=path.read_bytes();v=json.loads(raw)
    d=v.get('denominator',v.get('point_denominator')); P=[(F(x,d),F(y,d)) for x,y in v['points']]
    def half(S):
        H=[]
        for q in S:
            while len(H)>=2 and cross(H[-2],H[-1],q)<=0:H.pop()
            H.append(q)
        return H[:-1]
    V=sorted(P);H=half(V)+half(reversed(V));assert len(P)==len(H)
    ctr=tuple(sum(p[j] for p in P)/len(P) for j in (0,1))
    r=min(cross(a,b,ctr)/(abs(b[0]-a[0])+abs(b[1]-a[1])) for a,b in zip(H,H[1:]+H[:1]))
    D2=max((a[0]-b[0])**2+(a[1]-b[1])**2 for a,b in combinations(P,2))
    assert 0<r<=F(1,2) and 0<D2<1
    eps=(1-D2)/8;delta=eps*r/2
    Dhi=(1+D2)/2
    assert (1+eps)*Dhi+4*delta<1 and 2*delta<=eps*r
    return dict(count=len(P),dimension=2*len(P),source_sha256=hashlib.sha256(raw).hexdigest(),center=[str(x) for x in ctr],inradius_lower=str(r),diameter_squared=str(D2),expansion=str(1+eps),coordinate_displacement=str(delta),decimal_offset=float(delta),diameter_upper=str((1+eps)*Dhi+4*delta))
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ['hull18','physical_q','output']:p.add_argument(k,type=Path)
    a=p.parse_args();records=[family(q) for q in (a.hull18,a.physical_q)];assert [r['count'] for r in records]==[18,11]
    out={'family':records,'dimension':58,'area_floor':'120696470013529293/144115188075855872'};a.output.write_text(json.dumps(out,indent=2)+'\n')
    print([r['decimal_offset'] for r in records])

"""Independently join the physical replacement P30 and original Q over all 5,442 original core leaves."""
from pathlib import Path
import argparse,hashlib,json,gzip,zipfile
from collections import Counter
from fractions import Fraction as F
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_bytes())
def main():
    ap=argparse.ArgumentParser()
    for x in ['outer','r2','r4plus','r5','r597','r6e','mac','q17','p121','out']:ap.add_argument(x,type=Path)
    a=ap.parse_args();r2=a.r2
    pins={'mac':'539e1fe59574f9c44933e617570fe1c97af2a7aebc403047f37c084971c2e63a','q17':'3ac6f780753b122bcbaa30644555a57ab8bb1d041ab058a71ed320b8cc1b0cc1','p121':'d6ad96176ef828816739d42c5f627f4d7f37ccf9ae59a1e2c3fee52ce1e8d9ca'}
    assert all(sha(getattr(a,k))==v for k,v in pins.items())
    d=rd(a.r6e);base=rd(a.r4plus);r5=rd(a.r5);r97=rd(a.r597)
    assert d['baseline_files_sha256']=={k:sha(getattr(a,s)) for k,s in [('R4plus','r4plus'),('R5','r5'),('R5plus97','r597')]}
    retained={f'{p}/{i}' for p,v in rd(a.outer/'retained.json').items() for i in v};assert set(base['proof_masks_by_leaf'])==retained and len(retained)==5442
    allowed={'physical_old_Q11','original_P30','replacement_P30'};target=F(67,80);proofs={k:[] for k in retained}
    def put(k,src,req,t=target):
        assert k in proofs
        if F(t)>=target and set(req)<=allowed:proofs[k].append((len(set(req)),src,sorted(set(req))))
    for k,l in base['proof_masks_by_leaf'].items():
        for x in l:put(k,'R4plus/'+x['source'],x['required'])
    for label in ['mac72','local_native']:
        for k,v in r5[label].items():put(k,'R5/'+label,v['inputs'])
    for k,v in r97['new'].items():put(k,'R5+97',v['inputs'])
    for k,l in d['receipts_by_leaf'].items():
        for x in l:put(k,x['source'],x['inputs'],x['target'])
    missing={k for k,v in proofs.items() if not v};assert missing==set(d['focal']['seven_replacement_P30_physical_Q']['thresholds']['.83750']['unresolved']) and len(missing)==182
    with zipfile.ZipFile(a.mac) as z:
        prefix=next(n[:-len('packet.json')] for n in z.namelist() if n.endswith('/packet.json') or n=='packet.json')
        zz=lambda n:json.loads(z.read(prefix+n));pack=zz('packet.json');keys=zz('keys.json');assert len(keys)==len(pack)==45
        for j,(k,pp) in enumerate(zip(keys,pack,strict=True)):
            bounds=pp['regions'];f=r2/'refined/frontiers'/pp['source'];assert sha(f)==pp['frontier_sha256'] and rd(f)==bounds
            root=next(json.loads(v) for v in (r2/'refined'/(pp['source'].split('/')[0]+'.jsonl')).read_text().splitlines() if json.loads(v)['leaf']==k);st=root['stats']
            rows=[json.loads(s) for s in z.read(prefix+f'result-{j:02}.jsonl').splitlines()]
            assert F(root['goal'])==target and not st[0] and not st[5] and st[1]==2*sum(st[2:6])+len(bounds)-1 and len(rows)==len(bounds)
            used=set()
            if st[3]:used.add('original_P30')
            if st[4]:used.add('physical_old_Q11')
            for b,r in zip(bounds,rows,strict=True):
                t=r['stats'];assert pp['leaf']==k==b['leaf']==r['leaf'] and r['label']==b['label'] and b['bounds']==list(map(list,zip(r['lo'],r['hi'],strict=True)))
                assert F(r['goal'])==target and r['threshold_integer']==120696470013529293 and t[0]==1 and t[1]==2*sum(t[2:6])-1 and t[3]==t[5]==0 and not r['guard_uses'] and not r['pending']
                if t[4]:used.add('physical_old_Q11')
            put(k,'Mac45',used)
    with zipfile.ZipFile(a.q17) as z:
        q17=json.loads(z.read('six-north-scope.json'));assert len(q17)==17
        for k,q in q17.items():
            assert q['parent_P30']==q['P128']==q['newQ']==q['P15']==0;put(k,'North17',['physical_old_Q11'])
    with zipfile.ZipFile(a.p121) as z:
        selected=json.loads(z.read('scope.json'));assert len(selected)==121
        for k,x in selected.items():
            t=x['point_terminals_with_r248_prefix'];assert F(x['target'])==target and t['newQ']==t['P15']==0
            put(k,'differential121',[w for m,w in [('P30prime','replacement_P30'),('oldQ','physical_old_Q11')] if t[m]])
    assert not any(not v for v in proofs.values())
    selection={k:min(v) for k,v in sorted(proofs.items(),key=lambda i:tuple(map(int,i[0].split('/'))))}
    assert set(keys).isdisjoint(q17) and set(selected).isdisjoint(set(keys)|set(q17))
    additions=set(keys)|set(q17)|set(selected);assert len(additions)==183 and len(additions-missing)==1
    data=(json.dumps(selection,separators=(',',':'))+'\n').encode();a.out.mkdir(exist_ok=True);(a.out/'selection30.json.gz').write_bytes(gzip.compress(data,mtime=0))
    result=dict(complete=True,core=5442,perimeter=6704872,base_missing=len(missing),additional_distinct=len(additions),overlap_with_previous=sorted(additions-missing),area_lower='120696470013529293/144115188075855872',selection_sha256=hashlib.sha256(data).hexdigest(),sources=dict(Counter(label for _,label,_ in selection.values())),required=dict(Counter(q for _,_,req in selection.values() for q in req)))
    (a.out/'join30.json').write_text(json.dumps(result,indent=2)+'\n');print(result['core'],result['base_missing'],result['overlap_with_previous'],result['required'])
if __name__=='__main__':main()

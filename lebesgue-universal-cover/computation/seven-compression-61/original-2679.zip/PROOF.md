# 七组共 2,679 个有理点严格超过 .83749

实体五曲体、historicalP30、物理旧十一点的共同面积下端取 G=120696470013529293/2⁵⁷。五个凸有理多边形的顶点数分别取 789、459、460、462、468。前者是经向外作切线再有理归一的奇数多边形，其余四者用各个 Reuleaux 真圆弧的切线交点。每组按实测最远整数差向量所对应的非零复整数做复数除法，得到直径恰一的有理坐标。逐边 192 位 Arb 检验给出每组所含相应曲体的 β 倍，旋转与中心平移可统一计入该体的自由摆放。精确配对检验所有生成点的直径。最后接入原 historicalP30 和物理旧 Q 各 30、11 点，两组均可容纳以各自任意凸包锚点为中心的 β 倍原组。因此任意七组独立等距摆放的凸包面积至少是 β²G，严格超过 .83749001840255078668577459331317405865。最大单组数 789，总数 2,679。coordinates.json.gz 保存全部有理顶点和分母，certificate.json 记录各边支撑余量、精确面积分数及未压缩坐标 SHA256。

使用 Python 及 python-flint、公共 COMP/scaled-seven-46/rational.zip 和 check-finite.py，以及COMP/finite-point-leaf-input.json 的历史原三十点坐标、nine-replay-kit 中的 physical-q.json。运行 `python -B compact_tangent_original.py "$COMP" "$historicalP30" "$KIT/physical-q.json" temp out --original30`。该证书不调用原七体共同缩率定理；它使用此次物理七体的曲体面积下端，加上重新生成多边形的全部侧面验证。

"""Construct seven rational sets, verify each hull side and each diameter, and propagate the area floor."""
import argparse,gzip,hashlib,importlib.util,json,sys,zipfile
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from flint import arb,ctx
G=F(120696470013529293,2**57)
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
    p=argparse.ArgumentParser()
    for n in ['comp','P','Q','scratch','out']:p.add_argument(n,type=Path)
    p.add_argument('--target',type=F,default=F('.83749'));p.add_argument('--original30',action='store_true');p.add_argument('--legacy30',action='store_true');a=p.parse_args();a.scratch.mkdir(exist_ok=True);a.out.mkdir(exist_ok=True);ctx.prec=192
    base=a.comp/'scaled-seven-46'
    with zipfile.ZipFile(base/'rational.zip') as z:
        for n in ['geom.py','diam.py']:(a.scratch/n).write_bytes(z.read(n))
    geom=load('frozen_tangencies',a.scratch/'geom.py');diam=load('frozen_diameter',a.scratch/'diam.py');ver=load('independent_support',base/'check-finite.py')
    geom.S=10**21;geom.farthest=diam.axis_max;pi=arb.pi();safe=geom.ar(a.target/G).sqrt()
    n0=3
    while not ((pi/n0).cos()/(pi/(2*n0)).cos()>safe):n0+=2
    clouds=[];rows=[]
    for n in [0,3,5,7,9]:
        k=n0 if not n else max(1,int((pi/(2*n*safe.acos())).upper().ceil().unique_fmpz())-2);step=2 if not n else 1
        while True:
            cloud,sq,_,axis=geom.curve_points(n,k,pi);inner=F((geom.S-2)**2,sq)
            if inner*G>a.target:break
            k+=step
        A,B=axis;pts=[]
        for x,y in cloud['points']:
            u,v=x*A-y*B,x*B+y*A;assert u%sq==v%sq==0;pts.append((u//sq,v//sq))
        h=ver.polygon(pts);assert len(h)==len(pts) and ver.rotating_diameter(h)==sq
        model=ver.support_geometry(n) if n else None;least=None
        for u,v in zip(h,h[1:]+h[:1],strict=True):
            dx,dy=v[1]-u[1],u[0]-v[0];length=arb(dx*dx+dy*dy).sqrt();z=ver.height_upper(dx,dy,length,model)
            gap=((dx*u[0]+dy*u[1]-(geom.S-2)*z)/length).lower();assert gap>0
            if least is None or gap<least:least=gap
        assert max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(cloud['points'],2))==sq**2
        clouds.append(cloud);rows.append(dict(shape=n,grid=k,N=len(h),axis=axis,diameter_squared_integer=sq,inner_squared=str(inner),least_side_slack=str(least)))
    shP='1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58' if a.legacy30 else '92aca7f3c93ab146de3b4cdd60565773eb11ca38ed272e7e101cd38868334ceb'
    if a.original30:shP='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
    for f,n,digest in [(a.P,'original_P30' if a.original30 else ('replacement_P30' if a.legacy30 else 'P66'),shP),(a.Q,'physical_Q','7c656ce6491d23e0619e7aa78527fa5b17f6dc011b6f3034981413fa0cb80d93')]:
        raw=f.read_bytes();assert hashlib.sha256(raw).hexdigest()==digest
        d=json.loads(raw);pts=d['points'];den=d.get('denominator',d.get('point_denominator'));sq=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(pts,2));assert sq<den**2
        clouds.append(dict(body=n,denominator=den,points=pts))
    bound=G*min(F(r['inner_squared']) for r in rows);raw=(json.dumps(clouds,separators=(',',':'))+'\n').encode();(a.out/'coordinates.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    record=dict(curved_floor=str(G),target=str(a.target),area_lower=str(bound),area_decimal=str(geom.ar(bound)),counts=[len(v['points']) for v in clouds],total=sum(len(c['points']) for c in clouds),sha256=hashlib.sha256(raw).hexdigest(),curves=rows)
    (a.out/'certificate.json').write_text(json.dumps(record,indent=2)+'\n');print(record['counts'],record['total'],record['area_decimal'])
if __name__=='__main__':main()

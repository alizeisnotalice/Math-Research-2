"""Independently replay the seven-input compression on the Round 269 seven-input sources."""
import argparse,gzip,hashlib,io,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
PYTHON=[sys.executable,'-B']
def read(p): return json.loads(p.read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def member(z,suffix):
    with zipfile.ZipFile(z) as ar:
        ns=[n for n in ar.namelist() if n==suffix or n.endswith('/'+suffix)]
        assert len(ns)==1
        return ar.read(ns[0])
def run(args): subprocess.run([str(s) for s in args],check=True)
def summarize(file,keys):
    rows=[json.loads(l) for l in file.read_text().splitlines()]
    assert len(rows)==501 and {tuple(r['leaf']) for r in rows}==keys
    for r in rows:
        ok,v,f,p,_=r['out'];assert ok==1 and v==2*(f+p)-1 and r['newQ']==r['P15']==0 and r['oldQ']+r['P128']==p and r['front'] is None
    rows.sort(key=lambda r:r['leaf'])
    raw=(json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode()
    return dict(rows=len(rows),sha=sha(raw),totals=[sum(r['out'][i] for r in rows) for i in (1,2,3)]+[sum(r[k] for r in rows) for k in ('P128','oldQ')])
def main():
    ap=argparse.ArgumentParser()
    for k in ['comp','tree','table','cache','out']:ap.add_argument(k,type=Path)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--rebuild-original-angles',action='store_true')
    a=ap.parse_args();c=a.comp.resolve();w=a.out.resolve();w.mkdir(exist_ok=False)
    kit=w/'kit.zip';kit.write_bytes(member(c/'physical-nine-47/r6.zip','nine-replay-kit.zip'))
    assert sha(kit.read_bytes())=='19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467'
    p=c/'scaled-eight-50/p66.json';s7=c/'scaled-eight-50/seven66.zip';pold=w/'q.json';pold.write_bytes(member(kit,'physical-q.json'))
    a0=read(pold);o=read(c/'multi-host-points.json');assert a0['denominator']==o['point_denominator'] and a0['points']==o['points']
    assert sha(p.read_bytes())=='92aca7f3c93ab146de3b4cdd60565773eb11ca38ed272e7e101cd38868334ceb'
    selected=gzip.decompress(member(s7,'selection66.json.gz'));assert sha(selected)=='bd436b81be2391d4fbd75fba547e3f6076baa8dc2f2edb7513ba62f5de5e189f'
    sd=json.loads(selected);assert len(sd)==5442 and sum(x[1]=='differential121' for x in sd.values())==121
    assert all(set(x[2])<={'original_P30','replacement_P30','physical_old_Q11','reduced_P66'} for x in sd.values())
    assert all(not x[2] for x in sd.values() if x[1]=='ordinary-Qavg')
    j=json.loads(member(s7,'join66.json'));assert j['complete'] and j['perimeter']==6704872 and F(j['area_lower'])==F(120696470013529293,2**57)
    bank=w/'angular-66.json';bank.write_bytes(gzip.decompress((HERE/'angular-66.json.gz').read_bytes()))
    if a.rebuild_original_angles:
        dest=w/'kit'
        with zipfile.ZipFile(kit) as zz:zz.extractall(dest)
        run(PYTHON+[dest/'prepare.py',dest,w/'orig'])
        mk=w/'make66.py';mk.write_bytes(member(io.BytesIO(member(s7,'p66-stage-two.zip')),'make66.py'))
        run(PYTHON+[mk,w/'orig/angular-bank.json',p,bank,w/'make66-audit.json'])
    assert sha(bank.read_bytes())=='b0d3e4d6b3dc065a59c3a2de48256399813d8cb599f1cb3393d631dbdbe38181'
    b=read(bank);r4=json.loads(gzip.decompress(member(c/'rosters-083750/wave4.zip','physical-bank.json.gz')))
    assert b['directions']==r4['directions'] and [[r[:8] for r in cell] for cell in b['cells'][384:768]]==r4['cells'][384:768]
    x=w/'q-expanded-in.json';x.write_bytes(member(c/'seven-083746.zip','native/inputs/q11-expanded-angles.json'))
    run(PYTHON+[HERE/'legacy.py',c,p,w/'pleg.json'])
    run(PYTHON+[HERE/'q_legacy.py',c,c/'q11-leaf-bank.json',x,w])
    groups={}
    for kind,src,ang,fit,m,l,n in (
        ('P',p,bank,'p','.4464','P',9934),('legacy',p,w/'pleg.json','p','.4464','legacy',2493),
        ('Q',pold,bank,'q','.5','Q',128850),('Qlegacy',pold,w/'q-standard.json','q','.4464','Qlegacystandard',4516),
        ('Qlegacy',pold,w/'q-expanded.json','q','.4464','Qlegacyexpanded',7588)):
        dest=w/f'{l}61-cert.json'
        run(PYTHON+[HERE/'verify_scores.py',ang,src,HERE/f'{fit}61fit.json',dest,'--kind',kind,'--eps','.000000061','--m',m])
        v=read(dest);assert v['rows_ok'] and v['diameter_ok'] and v['rows']==n and dest.read_bytes()==(HERE/dest.name).read_bytes()
        label='P66' if fit=='p' else 'physicalQ';cloud=dict(denominator=v['denominator'],points=v['physical_points']);assert groups.get(label,cloud)==cloud;groups[label]=cloud
    points=w/'points.json';points.write_text(json.dumps(groups,separators=(',',':'))+'\n')
    assert points.read_bytes()==(HERE/'points.json').read_bytes()
    run(PYTHON+[HERE/'constants.py',w/'constants.json']);assert (w/'constants.json').read_bytes()==(HERE/'constants.json').read_bytes()
    run(PYTHON+[HERE/'dual_check.py',bank,pold,HERE/'dual64.json',w/'ceiling.json']);assert (w/'ceiling.json').read_bytes()==(HERE/'du64-certificate.json').read_bytes()
    run(PYTHON+[HERE/'dual_exact.py',bank,pold,HERE/'dual64.json',w/'dual-exact-cert.json']);assert (w/'dual-exact-cert.json').read_bytes()==(HERE/'dual-exact-cert.json').read_bytes()
    run(PYTHON+[HERE/'finite.py',points,w/'finite']);assert (w/'finite/finite-receipt.json').read_bytes()==(HERE/'finite-receipt.json').read_bytes()
    build=w/'build_dichotomy.py';build.write_bytes(member(c/'scaled-eight-50/scale.zip','build_dichotomy.py'))
    run(PYTHON+[build,kit,w/'old']);d=w/'native';run(PYTHON+[HERE/'baseline.py',w/'old',bank,d])
    run([shutil.which('clang++'),'-O3','-std=c++17','-fsanitize=signed-integer-overflow','-fsanitize-undefined-trap-on-error','-fPIC','-shared',f'-fmodules-cache-path={a.cache.resolve()}','-I',c/'three-leaf-083750',d/'nine.cpp','-o',d/'kernel.so'])
    original=c/'five-global-localization.json';assert sha(original.read_bytes())=='d85941b19b47cda83fc86268daa50569db2d80118b7fc722d4bf90adfa457504'
    keyfile=w/'keys.json';keylist=read(original)['retained'];keyfile.write_text(json.dumps(keylist)+'\n')
    roots=w/'roots.jsonl';run(PYTHON+[d/'run_nine.py',c,a.tree.resolve(),a.table.resolve(),d/'kernel.so',d/'bank.json',roots,'--index',keyfile,'--target','.83750','--caps','--mesh','--workers',a.workers,'--cap',2000000])
    stat=summarize(roots,{(int(p),i) for p,k in keylist.items() for i in k});assert stat==read(HERE/'roots-receipt.json');print('All checks passed.',stat,flush=True)
if __name__=='__main__':main()

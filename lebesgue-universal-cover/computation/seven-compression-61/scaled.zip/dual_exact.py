"""For a labeled perturbed physical Q11, give a necessary ceiling on uniform directional allowance 1/2."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,arb_mat,ctx
ctx.prec=384
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
def read(p):return json.loads(p.read_bytes())
bank,src,proposal,out=map(Path,sys.argv[1:]);b=read(bank);x0=read(src);d=read(proposal);Y=[[ar(F(x,x0['denominator'])) for x in p] for p in x0['points']];R=ar(F('.024'));m=ar(F(1,2));U=2**22;Z=2**28
picked=[];allow=None
cols=[];cs0=[];ds0=[]
for xx in d['dual']:
 A=[arb(0) for _ in range(2*len(Y))];C=arb(0);D=arb(0)
 *label,_proposal_weight=xx
 if label[0]=='pair':
  _,i,j=label;u,v=Y[i][0]-Y[j][0],Y[i][1]-Y[j][1];h=(u*u+v*v).sqrt()
  for k,f in enumerate((u/h,v/h)):A[2*i+k]+=f;A[2*j+k]-=f
  C=1-h;D=arb(1)
  cols.append(A);cs0.append(C);ds0.append(D);continue
 _,j,k,side,hand=label;K,off=(384,384) if j<768 else (1536,768)
 r=b['cells'][j][k];sn,cs=(2*arb.pi()*(j-off+side)/K).sin_cos(); score=arb(0);rho=arb(0);ids=[]
 for mid,w in zip(r[:3],r[3:6]):
  vx,vy=[ar(F(t,U)) for t in b['directions'][mid]];u=vx*cs+vy*sn;v=hand*(-vx*sn+vy*cs);length=(vx*vx+vy*vy).sqrt();ww=ar(F(w,r[6]));proj=[u*x+v*y for x,y in Y];i=max(range(len(Y)),key=lambda i:float(proj[i].mid()));ids.append(i)
  sep=min(proj[i]-s for jl,s in enumerate(proj) if jl!=i)
  assert sep>2*R*length
  a0=(sep/(2*length)).lower();allow=a0 if allow is None or a0<allow else allow
  score+=ww*proj[i];rho+=ww*length;A[2*i]-=ww*u;A[2*i+1]-=ww*v
 C=score-ar(F(max(r[7],r[8+side]),Z));D=-m*rho;picked.append([label,ids])
 cols.append(A);cs0.append(C);ds0.append(D)
assert all(sum(w*x for w,x in zip(r[3:6],[b['directions'][i][k] for i in r[:3]]))==0 for label,_ in picked for r in [b['cells'][label[1]][label[2]]] for k in (0,1))
M=arb_mat([[col[i] for col in cols] for i in range(2,len(A))]+[[arb(1) for col in cols]])
lam=M.solve(arb_mat([[0] for i in range(2,len(A))]+[[1]]))
wt=[lam[i,0] for i in range(len(cols))];assert min(wt)>0
C=sum(x*y for x,y in zip(cs0,wt));D=sum(x*y for x,y in zip(ds0,wt));assert D>0
# The invertible interval solve encloses the exact solution. The two omitted
# coordinates vanish by each column's exact translation balance.
ceil=(C/D).upper()
print('upper',ceil,'stable label radius',allow,'rows',len(picked),'pairs',len(d['dual'])-len(picked),flush=True)
out.write_text(json.dumps(dict(epsilon_upper=ceil.str(50),labeled_point_radius='.024',label_stability_implies_bound_without_metric_condition=True,minimum_multiplier=min(wt).str(40),maximum_multiplier=max(wt).str(40),minimum_stable_material_radius=allow.str(40),slope=D.str(40),old_slack=C.str(40),force_residual_L1="0",rows=picked,pairs=len(d['dual'])-len(picked)),indent=2)+'\n')

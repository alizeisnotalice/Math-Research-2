# 七输入的 .83750 全域缩率

第269轮公开的七体选源为输入。取共同尺度 .999999939，新五曲体与两个变形的有理点云在任意自由摆放下，联合凸包面积至少为 \(120696470013529293/2^{57}\)。归一化后一般下端大于 .83750010217500935040103933649。每组至多7791点的显式七个有理输入给出下端 .83750000004356877613。两个点云均经过形变，几何量词见 PROOF.md。

复算需要项目的 computation、Tomar v9 cert11d_08366、旧认证材料 table64.npz、共享 Clang 模块缓存、一个尚不存在的输出目录。环境使用 Python 3.13.18、NumPy 2.5.5、python-flint 0.9.0 与 Apple Clang。命令从本档解压目录执行。

~~~sh
python -B replay.py "$COMP" "$TREE" "$TABLE64" "$CLANG_CACHE" "$NEW_OUTPUT" --workers 4
~~~

入口核对第269轮 seven66.zip 冻结的5442叶，五种方向表、逐点直径、附加局部对偶、全部501个新增基准树和七组有限坐标。带 --rebuild-original-angles 可从公开 p66-stage-two.zip 和 nine-replay-kit.zip 另重建强角库，本档也提供逐字节相同的压缩原表。复算继承R158材料定位、R234外围、R254/R258材料包含及第269轮原七体高靶证明；原有历史全树未重复计算。标签与原理见 PROOF.md。

points.json 是直径严格小于 .999999939 的两个有理云；归一化单位直径输入须除以该尺度。finite.py 在输出目录生成完整七组坐标，其中前五个凸包分别含同尺度正曲体的一个副本。只需有限坐标时运行下式。

~~~sh
python -B finite.py points.json NEW_FINITE_DIR
~~~

roots-receipt.json 记录排序后的501个完整根输出 SHA 与终端数。dual64.json 提供10条端行和11条直径方向的索引，dual_exact.py 重新严格求解力平衡乘子。局部必要界适用于同一极值标签区域中、每方向统一允许半个缩量的路线。

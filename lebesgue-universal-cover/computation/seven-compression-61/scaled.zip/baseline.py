from pathlib import Path
import json,sys
old,bank,out=map(Path,sys.argv[1:]);out.mkdir(exist_ok=True)
d=json.loads(bank.read_bytes());d['cells']=[[r[:8] for r in c] for c in d['cells']];assert not any(d['cells'][2304:]);(out/'bank.json').write_text(json.dumps(d,separators=(',',':'))+'\n')
for n in ['nine.cpp','disk_chord_support.hpp','run_nine.py','dual_bank.py','angular_rows.py','support_grid.py']:
 raw=(old/n).read_bytes()
 if n=='nine.cpp':
  assert raw.count(b'for(int f=0;f<3;++f)')==1;raw=raw.replace(b'for(int f=0;f<3;++f)',b'for(int f=0;f<2;++f)')
 if n=='run_nine.py':
  assert raw.count(b"F('.999999995')")==1;raw=raw.replace(b"F('.999999995')",b"F('.9999999')")
 (out/n).write_bytes(raw)

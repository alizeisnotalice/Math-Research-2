"""Directed cap and chord bounds, independent of the angular-row verification."""
from fractions import Fraction as F
from flint import arb,ctx
import json,sys
from pathlib import Path
ctx.prec=256
def v(x):
    x=F(x); return arb(x.numerator)/x.denominator
s=F('.999999939');eps=1-s;U=2**22;Q=2**28;G=F(120696470013529293,2**57);r=F(1,2);m=F('.4464');a=F('.468')
assert F(71379940282225,2**56)<(r-a)**2
assert all(1-1/(2*(arb.pi()/(2*n)).cos())>v(a) for n in (5,7,9))
z=v(s).sqrt()
cap=v(F(1,4000)).sqrt()/(z*(1+z))+v((1+s)*r*r-2*m*r+m*m*eps)/(4*z*v(2*r))
assert cap<v(a-m)
x=v('.706');rad=v(s*r)
assert (arb.pi()-(rad/x).acos())*rad**2+rad*(x*x-rad**2).sqrt()>v(G)
assert F('.706')+eps/2<F('.707') and F('.707')**2<2*(s*r)**2
assert F(2,5*(U+1))>eps/2
delta=r/(U-2);assert s*delta>(F('.707')-m)*eps
assert (U-1)*(s-F('.6')*eps)>U-2
assert F(Q//5000,Q)*U/(U+1)>eps/2
assert (F('.83729500622102524')*F('.9999999')**2*2**57).__floor__()<120666927296517964*s*s
assert 3*eps<F('.8373034')-F(120666927296517964,2**57)
j=dict(scale=str(s),area_rational=str(G/s**2),area_decimal=v(G/s**2).str(58),ordinary_slope=cap.str(40),ordinary_available=str(a-m),strong_wall_pad=str(F(2,5*(U+1))),padded_denominator_spare=str(s*delta-(F('.707')-m)*eps),defining_disk_spare=str((U-1)*(s-F('.6')*eps)-(U-2)))
Path(sys.argv[1]).write_text(json.dumps(j,indent=2)+'\n')

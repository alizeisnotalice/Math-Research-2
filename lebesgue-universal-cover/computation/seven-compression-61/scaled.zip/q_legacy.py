import sys,json
from pathlib import Path
from flint import ctx
ctx.prec=192
c,st,ex,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(c.resolve()))
from build_q11_leaf_bank import EPS,reflected_average
from replay_q11_with_p30 import PointProof
p,den=reflected_average(json.loads((c/'multi-host-points.json').read_bytes()))
for tag,path in [('standard',st),('expanded',ex)]:
 data={**json.loads(path.read_bytes()),'points':p,'denominator':den,'direction_scale':2**22};b=PointProof(data,EPS);v=b.triples.reshape(-1,8);cells=[[r.tolist() for r in v[i:j]] for i,j in zip(b.pointers,b.pointers[1:])]
 (out/f'q-{tag}.json').write_text(json.dumps(dict(directions=data['directions'],cells=cells,proposals=data['cells'])))

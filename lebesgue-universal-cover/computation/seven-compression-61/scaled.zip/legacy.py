from pathlib import Path
from flint import ctx
import json,sys
comp,src,out=map(Path,sys.argv[1:]);ctx.prec=160;sys.path.insert(0,str(comp.resolve()))
from replay_q11_with_p30 import PointProof
b=PointProof(json.loads(src.read_bytes()));r=b.triples.reshape(-1,8)
c=[[v.tolist() for v in r[a:q]] for a,q in zip(b.pointers,b.pointers[1:])]
d=json.loads(src.read_bytes());out.write_text(json.dumps(dict(directions=d['directions'],cells=c)))

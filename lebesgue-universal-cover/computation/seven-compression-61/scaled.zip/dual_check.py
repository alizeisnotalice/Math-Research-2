"""For a labeled perturbed physical Q11, give a necessary ceiling on uniform directional allowance 1/2."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
ctx.prec=224
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
def read(p):return json.loads(p.read_bytes())
bank,src,proposal,out=map(Path,sys.argv[1:]);b=read(bank);x0=read(src);d=read(proposal);Y=[[ar(F(x,x0['denominator'])) for x in p] for p in x0['points']];R=ar(F(d['radius']));m=ar(F(1,2));U=2**22;Z=2**28
A=[arb(0) for _ in range(2*len(Y))];C=arb(0);D=arb(0);picked=[];allow=None
for xx in d['dual']:
 *label,num=xx;wt=ar(F(num,d['denom']));assert wt>0
 if label[0]=='pair':
  _,i,j=label;u,v=Y[i][0]-Y[j][0],Y[i][1]-Y[j][1];h=(u*u+v*v).sqrt()
  for k,f in enumerate((u/h,v/h)):A[2*i+k]+=wt*f;A[2*j+k]-=wt*f
  C+=wt*(1-h);D+=wt
  continue
 _,j,k,side,hand=label;K,off=(384,384) if j<768 else (1536,768)
 r=b['cells'][j][k];sn,cs=(2*arb.pi()*(j-off+side)/K).sin_cos(); score=arb(0);rho=arb(0);ids=[]
 for mid,w in zip(r[:3],r[3:6]):
  vx,vy=[ar(F(t,U)) for t in b['directions'][mid]];u=vx*cs+vy*sn;v=hand*(-vx*sn+vy*cs);length=(vx*vx+vy*vy).sqrt();ww=ar(F(w,r[6]));proj=[u*x+v*y for x,y in Y];i=max(range(len(Y)),key=lambda i:float(proj[i].mid()));ids.append(i)
  sep=min(proj[i]-s for jl,s in enumerate(proj) if jl!=i)
  assert sep>2*R*length
  a0=(sep/(2*length)).lower();allow=a0 if allow is None or a0<allow else allow
  score+=ww*proj[i];rho+=ww*length;A[2*i]-=wt*ww*u;A[2*i+1]-=wt*ww*v
 C+=wt*(score-ar(F(max(r[7],r[8+side]),Z)));D-=wt*m*rho;picked.append([label,ids])
assert D>0;res=sum(abs(z) for z in A);ceil=((C+R*res)/D).upper()
print('upper',ceil,'R',d['radius'],'row',len(picked),'pairs',len(d['dual'])-len(picked),'norm',res,flush=True)
out.write_text(json.dumps(dict(epsilon_upper=ceil.str(50),labeled_point_radius=d['radius'],minimum_stable_material_radius=allow.str(40),slope=D.str(40),old_slack=C.str(40),force_residual_L1=res.str(40),rows=picked,pairs=len(d['dual'])-len(picked)),indent=2)+'\n')

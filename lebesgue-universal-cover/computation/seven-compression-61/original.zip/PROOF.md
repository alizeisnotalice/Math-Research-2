# 原三十点与物理十一点的严格全域下端

固定半径 1/2 的圆盘、四个正 Reuleaux 体 B3、B5、B7、B9、历史原三十点及历史原物理十一点。每个输入允许各自平移、旋转、反射。任何容纳这七个输入的凸集的面积均至少为 120696470013529293/2^57，严格超过 .83750。前四层的 6,704,872 个外围原叶和四类根平移框外区域使用 global-083750 的五曲体收缩证书；剩余 5,442 个原叶按 selectionOld30.json.gz 逐个连接。

基线来自 R4plus、R5、R5plus97 及 R6e 的原始完整叶；固定模型本有 191 叶空缺。额外原根来自本包 130 叶、North17 及 Mac45，合并时与既存基线发生一次重复，最终覆盖全部核心。选择使用的有限体身份只有 original_P30、physical_old_Q11。每次子盒重启都严格枚举首个未访问盒及其未访问右兄弟。original130.zip 的 PROOF.md 给出曲体真实圆截弦、同角平衡行和原生复算入口。

运行 joinOld30.py，依次传入外围 records、R248、R4plus frozen/ledger.json、R5 frozen/wave-ledger.json、R5plus97 frozen/ledger.json、R6e ledger-eight.json、Mac r6e-seven-direct-01.zip、seventeen-physical-q-50.zip、original130.zip 和独立输出目录。外部 Mac45 SHA256 为 539e1fe59574f9c44933e617570fe1c97af2a7aebc403047f37c084971c2e63a。

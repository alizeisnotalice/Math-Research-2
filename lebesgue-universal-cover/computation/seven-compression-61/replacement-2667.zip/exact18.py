"""Replace the 30 labels by precisely the extreme points of their rational convex hull."""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import argparse, gzip, hashlib, json

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def make(source, output, finite):
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58'
    data=json.loads(raw); points=list(map(tuple,data['points'])); den=data['denominator']
    by={p:i for i,p in enumerate(points)}; assert len(by)==len(points)==30
    def half(seq):
        side=[]
        for v in seq:
            while len(side)>1 and cross(side[-2],side[-1],v)<=0:side.pop()
            side.append(v)
        return side[:-1]
    order=sorted(points); hull=half(order)+half(reversed(order)); assert len(hull)==18
    detmin=min(cross(a,b,c) for a,b in zip(hull,hull[1:]+hull[:1]) for c in points if c not in (a,b))
    assert detmin>0
    for j,b in enumerate(hull):assert cross(hull[j-1],b,hull[(j+1)%len(hull)])>0
    diam=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(hull,2));assert diam<den**2
    output.mkdir(exist_ok=True)
    write=lambda n,d:(output/n).write_text(json.dumps(d,indent=2)+'\n')
    write('hull18.json',dict(points=hull,denominator=den))
    write('exact-hull.json',dict(indices=[by[p] for p in hull],discarded=[j for j,p in enumerate(points) if p not in hull],minimum_nonincident_oriented_determinant=detmin,maximum_squared_distance=diam,denominator=den))
    if finite:
        clouds=json.loads(gzip.decompress((finite/'coordinates.json.gz').read_bytes()))
        cert=json.loads((finite/'certificate.json').read_bytes());assert clouds[5]['points']==data['points'] and clouds[5]['denominator']==den
        clouds[5]=dict(body='P18',points=hull,denominator=den)
        encoded=(json.dumps(clouds,separators=(',',':'))+'\n').encode()
        (output/'coordinates.json.gz').write_bytes(gzip.compress(encoded,mtime=0))
        cs=[len(c['points']) for c in clouds];assert cs==[789,459,460,462,468,18,11] and sum(cs)==2667
        cert.update(counts=cs,total=sum(cs),sha256=hashlib.sha256(encoded).hexdigest());write('certificate.json',cert)
    print([by[p] for p in hull],detmin,diam,den**2)
if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('source',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--finite',type=Path)
    a=ap.parse_args();make(a.source,a.output,a.finite)

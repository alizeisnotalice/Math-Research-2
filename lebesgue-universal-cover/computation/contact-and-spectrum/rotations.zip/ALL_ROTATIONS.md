# One host, every rotation: finite contact certificate

Let C be contained in a bounded polygon Q={x:n_i·x≤b_i, i=1,...,r}, with unit outer normals. K is a compact width-one convex body; reflections are considered separately if relevant. For each of finitely many angle centers θ_s and both hands H, choose an actual list of points p_sj∈K and a balanced row λ_sj≥0, Σλ_sj=1, Σλ_sj n_ij=0, supported on at most three distinct polygon facets. Such rows are exactly the possible extreme points of the balanced probability polytope; the constraint matrix has at most three rows. Define

 A=Σλ_j n_ij·R_θ H p_j,    B=Σλ_j n_ij·J R_θ H p_j,    b=Σλ_j b_ij.

For |δ|≤d≤π/2 and A≥0, the **single actual row** proves the entire angle interval fails whenever

 A cos d − |B| sin d − b ≥ γ > 0.                         (1)

Indeed the row gives A cosδ+B sinδ−b≥γ; the balanced normal sum makes the value invariant under any translation. The retained points only need to lie in K; they need not be support maximizers of the selected facet normals. The facet and point attached to each term must remain paired. If the closed intervals cover a circle, (1) holds for both hands and every pose. Thus no translate or allowed reflection of K fits Q, hence none fits C, with violation ≥γ in the displayed weighted support sense. The statement does not assert that C or Q is a universal cover. The angle intervals can have unequal widths.

Now suppose every chosen point is a support point of K at some specified direction. Let N be the number of distinct such unoriented directions, and let m be odd. Apply the established contact-and-odd-spectral compression theorem to the partition determined by those directions: there is a width-one body K' with at most 2N+m circular arcs, preserving the odd spectral moments through m and all selected contacts after one common translation. A width-one body has antipodal contact points differing by the corresponding unit normal: the difference has length at most 1 and projection 1, so equality holds. Therefore a contact at θ+π is preserved when θ is a partition endpoint. Every row in (1) still applies to K' and all orientations; this is one K' and one C, not a different body at each angle. It has the same quantitative margin γ. With q equally spaced centers per hand, there are at most 6q selected contacts and hence N≤6q; in particular 2N+m≤12q+m. Repeated contact directions can drastically reduce N. This conclusion is conditional on the cited compression theorem, including its contact preservation and count; the present certificate proves the rotation step.

For a coarser but universal alternative, let the row at each center have actual margin at least g. Recenter the compressed body at a minimum enclosing circle center; by the planar Jung theorem it has radius at most 1/√3 because its diameter is one. Balance cancels that translation, and the row changes by at most 2/√3 sin(d/2) for |δ|≤d. Thus g−2/√3 sin(d/2)>0 proves a uniform violation. For a q-grid d=π/q. The single-row trigonometric bound (1) normally saves grid points because it retains the actual transverse coefficient B rather than bounding it by a radius. Conversely, finding an actual placement with facet slack >2/√3 sin(d/2) proves successful containment on its angle interval. If neither strict test succeeds, the interval is unresolved: this is not a proof of either containment or noncontainment.


## Existence for an arbitrary compact convex host

Suppose no allowed pose of a compact width-one K fits a nonempty compact convex C. For each rotation/reflection O, put

 f(O)=min_t max_{|n|=1}(h_K(O^T n)+n·t−h_C(n)).

The minimizing translations lie in a common bounded set (C and K are bounded), so f is continuous in O. Compactness of O(2) yields g=min_O f(O)>0. Fix O and impose all halfplanes n·t≤h_C(n)−h_K(O^T n)+g/2; they have empty intersection. The ± coordinate constraints bound t, so the compact finite-intersection property and planar Helly yield at most three incompatible halfplanes. Farkas gives a positive balanced row whose actual support-point margin is at least g/2. Keep those at-most-three support points and their directions. Their row is a continuous function of O, hence retains a positive margin on an open neighborhood of O. A finite subcover of O(2) chooses finitely many rows and a strictly positive common margin. Define Q using the finitely many supporting halfplanes of C appearing in those rows; append four coordinate supporting halfplanes if necessary to make Q bounded. Then C⊂Q, and the preceding construction gives one compressed width-one K' that fails every pose of Q and C and preserves any fixed finite set of odd moments. This is an existence theorem; it does not supply an effective quantitative arc count without explicit row and neighborhood data.

## Independently replayable example

Q is the regular tangent octagon with inradius 1/2. K is the unit-width Reuleaux triangle, represented here solely by its three vertices p_j=(cos(2πj/3),sin(2πj/3))/√3. The script enumerates exactly the four antipodal 2-facet rows and eight positive 3-facet rows of the octagon, evaluates all arithmetic with 192-bit Arb, and searches for a row satisfying (1) for each closed interval. With q=8 per hand, all 16 intervals pass with margin > 0.02275529021813. At q=16 the bound is > 0.03579792304194. Run:

    python -I -B octagon_analytic.py output.json 8
    python -I -B octagon_analytic.py output16.json 16

The three retained vertices are genuine support points in their own radial directions, although they need not maximize the particular row facet normal. Their three unoriented directions give N=3; for m=1 the compression theorem gives at most seven arcs (the original triangle itself has three). For q=4 and q=6 this particular equal-grid row estimate fails at least one interval; this only records failure of that sufficient certificate, not a viable placement. `octagon.py` independently exercises the coarser q=128 Jung bound. The parameter q=8 is not asserted optimal.

Relation to earlier project work: the specialized multiroot argument proves an all-angle result for a particular strip-host setting by a different constructive mechanism. The present row certificate is for any specified bounded polygon, preserves prescribed odd moments, quantifies violation, and has a directly testable two-sided grid stopping condition; no general assertion is inferred from the numerical example.

Source comparison (SHA-256): `finite-oriented-cover.md` 475afa6f4ee89d0090b72837db369d97041a656a793a8b5ac54bf3e09b919597 already gives ≤3 facet rows at finitely many poses but explicitly leaves the continuous rotations open; `multiroot-exact-witness.md` c7ed6f89cf53d36d3ba8ad7400f190f38ce435fa921da4710e0cf42c7503d87e treats all poses through a special hexagonal-strip normalization; `contact-data-minimax.md` 5ebfd9153534b795b3a42a1f9ffda33cff0e6e03dd3241b53e02b7d1f69736a3 concerns optimal Hausdorff recovery from equal-grid contacts, a different error objective. All three are under `lebesgue-main/lebesgue-universal-cover/proofs/`.

"""Prove a width-one R3 cannot fit an octagon using actual vertices and 128 angle grid."""
from pathlib import Path
from itertools import combinations
from flint import arb,ctx
import json,sys
ctx.prec=192
q=128;pi=arb.pi();s2=arb(2).sqrt()/2;zero=arb(0);one=arb(1)
N=[(one,zero),(s2,s2),(zero,one),(-s2,s2),(-one,zero),(-s2,-s2),(zero,-one),(s2,-s2)]
det=lambda a,b:a[0]*b[1]-a[1]*b[0]
rows=[]
for i,j in combinations(range(8),2):
 if (j-i)%8==4:rows.append(([i,j],[arb(1)/2,arb(1)/2]))
for i,j,k in combinations(range(8),3):
 w=[det(N[j],N[k]),det(N[k],N[i]),det(N[i],N[j])]
 if any(z.contains(0) for z in w):continue
 if all(z<0 for z in w):w=[-z for z in w]
 if not all(z>0 for z in w):continue
 total=sum(w);rows.append(([i,j,k],[z/total for z in w]))
assert len(rows)==12
R=1/arb(3).sqrt();P=[]
for j in range(3):s,c=(2*pi*j/3).sin_cos();P.append((R*c,R*s))
mins=[];used={}
for hand in (-1,1):
 for k in range(q):
  s,c=(2*pi*k/q).sin_cos();v=[(c*x-s*hand*y,s*x+c*hand*y) for x,y in P]
  best=None;which=None
  for ids,w in rows:
   val=arb(0)
   for idx,weight in zip(ids,w):
    vals=[(N[idx][0]*x+N[idx][1]*y).lower() for x,y in v];val+=weight*max(vals)
   margin=(val-arb(1)/2).lower()
   if best is None or margin>best:best,which=margin,ids
  assert best>0
  mins.append(best);key=','.join(map(str,which));used[key]=used.get(key,0)+1
lower=min(mins);err=2*R*(pi/(2*q)).sin();assert lower>err
out=dict(host='regular octagon inradius 1/2',candidate='unit-width regular Reuleaux triangle',candidate_witness='three vertices of equilateral triangle, all in R3',directions=8,grid_per_hand=q,hands=2,elementary_rows=len(rows),grid_minimum=str(lower),Jung_rotation_error=str(err),all_rotation_margin=str((lower-err).lower()),used_rows=used,precision=ctx.prec)
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print('PASS grid',lower,'error',err,'all-angle', (lower-err).lower(),flush=True)

"""Effective rational-window construction for equal N partition, odd m."""
from fractions import Fraction as F
from flint import arb,ctx
from pathlib import Path
import argparse,json,math,sys
ctx.prec=192
p=argparse.ArgumentParser();p.add_argument('N',type=int);p.add_argument('m',type=int);p.add_argument('output',type=Path);a=p.parse_args();N,m=a.N,a.m;assert N>=1 and m>=1 and m%2==1
K=2*N+m-1;d=K-2
if d==0:
 a.output.write_text(json.dumps({'N':N,'m':m,'density':'1/2','minimum_arcs':3},indent=2)+'\n');print('PASS trivial disk');raise SystemExit
def z(r):return ((1-r*r)/(1+r*r),2*r/(1+r*r))
def mult(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def powz(a,k):
 x=(F(1),F(0))
 for _ in range(k):x=mult(x,a)
 return x
def integral(lo,hi,k):
 a,b=powz(z(lo),k),powz(z(hi),k);return ((b[1]-a[1])/k,(a[0]-b[0])/k)
def rank(cols):
 if not cols:return 0
 mat=[[cols[j][i] for j in range(len(cols))] for i in range(K)];nr=K;nc=len(cols);row=0
 for j in range(nc):
  ii=next((i for i in range(row,nr) if mat[i][j]),None)
  if ii is None:continue
  mat[row],mat[ii]=mat[ii],mat[row];v=mat[row][j]
  for i in range(row+1,nr):
   if mat[i][j]:
    f=mat[i][j]/v
    for l in range(j+1,nc):mat[i][l]-=f*mat[row][l]
  row+=1
  if row==nr:break
 return row
sys.path.insert(0,str(Path(__file__).resolve().parent))
from cell_location import locate

M=8
while True:
 chosen=[];cols=[];half=F(1,8*M*M)
 for i in range(1,M*M):
  lo=F(i,M)-half;hi=F(i,M)+half
  jlo,jhi=locate(lo,N),locate(hi,N)
  if jlo is None or jhi is None or jlo!=jhi:continue
  cell=jlo;first=integral(lo,hi,1);vec=[*first]
  for j in range(N-1):vec.extend(first if j==cell else (F(0),F(0)))
  for k in range(3,m+1,2):vec.extend(integral(lo,hi,k))
  assert len(vec)==K
  if rank(cols+[vec])>len(cols):chosen.append((lo,hi,cell));cols.append(vec)
  if len(cols)==K:break
 if len(cols)==K:break
 M*=2
pivot=next((i,j) for i in range(K) for j in range(i+1,K) if cols[i][0]*cols[j][1]-cols[j][0]*cols[i][1]);i,j=pivot;others=[k for k in range(K) if k not in pivot]
u,v=cols[i][0],cols[j][0];w,x=cols[i][1],cols[j][1];det=u*x-v*w;co=[]
for t in others:
 P,Q=cols[t][0],cols[t][1];A=(P*x-v*Q)/det;B=(u*Q-P*w)/det;assert cols[t][0]-A*u-B*v==cols[t][1]-A*w-B*x==0;co.append((A,B))
def primes(n):
 ans=[];x=2
 while len(ans)<n:
  if all(x%p for p in range(2,math.isqrt(x)+1)):ans.append(x)
  x+=1
 return ans
ps=primes(d);bound=sum((F(4**p)*(1+abs(A)+abs(B)) for p,(A,B) in zip(ps,co)),F(0));eps=1/(4*(1+bound))
assert eps*bound<F(1,4)  # e^sqrt(p)<4^p proves all levels lie in (1/4,3/4).
out={'N':N,'m':m,'d':d,'window_halfangle':[[str(x),str(y),j] for x,y,j in chosen],'reference_indices':list(pivot),'other_indices':others,'coefficient_pairs':[[str(x),str(y)] for x,y in co],'primes':ps,'epsilon':str(eps),'full_rank':K,'density_interval_exact':['1/4','3/4'],'classification_precision_bits':ctx.prec}
a.output.write_text(json.dumps(out,indent=2)+'\n');print('PASS N',N,'m',m,'full rank',K,'dimension',d,'grid',M)

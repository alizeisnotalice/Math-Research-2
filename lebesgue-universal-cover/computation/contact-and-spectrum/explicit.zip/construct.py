"""Explicit N=2,m=3 width-one density with four algebraically independent moments."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from flint import arb,arb_mat,ctx
import json,sys
ctx.prec=192
windows=[(F(1,10),F(1,9)),(F(1,5),F(2,9)),(F(1,3),F(3,8)),(F(6,5),F(5,4)),(F(3,2),F(8,5)),(F(2),F(21,10))]
primes=[2,3,5,7];epsilon=F(1,10**10)
def mult(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def z(r):return ((1-r*r)/(1+r*r),2*r/(1+r*r))
def power(a,k):
 p=(F(1),F(0))
 for _ in range(k):p=mult(p,a)
 return p
def integral(lo,hi,k):
 a,b=power(z(lo),k),power(z(hi),k)
 return ((b[1]-a[1])/k,(a[0]-b[0])/k)
def det(A):
 A=[row[:] for row in A];ans=F(1)
 for i in range(len(A)):
  k=next((k for k in range(i,len(A)) if A[k][i]),None)
  if k is None:return F(0)
  if k!=i:A[k],A[i]=A[i],A[k];ans=-ans
  p=A[i][i];ans*=p
  for j in range(i+1,len(A)):
   f=A[j][i]/p
   for l in range(i+1,len(A)):A[j][l]-=f*A[i][l]
 return ans
cols=[]
for a,b in windows:
 first=integral(a,b,1);third=integral(a,b,3);local=first if b<=1 else (F(0),F(0));assert b<=1 or a>=1
 cols.append([*first,*local,*third])
C=[[cols[j][i] for j in range(6)] for i in range(6)]
assert all(windows[i][1]<windows[i+1][0] for i in range(5));full=det(C);assert full
u,v=C[0][0],C[0][1];w,x=C[1][0],C[1][1];den=u*x-v*w;assert den
coefs=[];reduced=[]
for j in range(2,6):
 p,q=C[0][j],C[1][j];A=(p*x-v*q)/den;B=(u*q-p*w)/den
 assert C[0][j]-A*u-B*v==0 and C[1][j]-A*w-B*x==0
 coefs.append([A,B]);reduced.append([C[i][j]-A*C[i][0]-B*C[i][1] for i in range(2,6)])
M=[[reduced[j][i] for j in range(4)] for i in range(4)];d=det(M);assert d and d==full/den
ex=[arb(k).sqrt().exp() for k in primes];e=arb(epsilon.numerator)/epsilon.denominator
ref=[arb(1)/2-e*sum((arb(c[i].numerator)/c[i].denominator)*x for c,x in zip(coefs,ex)) for i in range(2)]
positive=[arb(1)/2+e*x for x in ex];bounds=ref+positive
assert all(x>arb('0.4999999') and x<arb('0.5000001') for x in bounds)
base=[arb(1)/2,arb(1)/2,arb(0),arb(1)/3]
actual=[base[i]+e*sum((arb(M[i][j].numerator)/M[i][j].denominator)*ex[j] for j in range(4)) for i in range(4)]
baseclosure=(F(0),F(1));out={'N':2,'m':3,'arc_lower':7,'intervals_halfangle':[[str(a),str(b)] for a,b in windows],'prime_exponents':primes,'epsilon':str(epsilon),'reference_coefficients':[[str(x) for x in v] for v in coefs],'raw_moment_matrix':[[str(x) for x in row] for row in C],'full_determinant':str(full),'closure_determinant':str(den),'reduced_determinant':str(d),'reduced_matrix':[[str(x) for x in row] for row in M],'density_bounds':[str(x) for x in bounds],'selected_half_moments':[str(x) for x in actual],'baseline_closure':list(map(str,baseclosure)),'closure_corrections_exactly_zero':True,'precision':ctx.prec}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print('PASS reduced rank 4, density bounds',*[str(x) for x in bounds])

"""Independently integrate rational half-angle formulas and check exact matrices."""
import sympy as S
from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent;d=json.loads((p/'receipt.json').read_bytes());r=S.symbols('r',real=True)
z=(1+S.I*r)**2/(1+r*r);mom={}
for k in (1,3):
 zr=S.expand_complex(z**k);mom[k]=[S.integrate(S.re(zr)*2/(1+r*r),r),S.integrate(S.im(zr)*2/(1+r*r),r)]
C=S.zeros(6,6)
for j,(lo,hi) in enumerate(d['intervals_halfangle']):
 lo,hi=S.Rational(lo),S.Rational(hi)
 for k,rows in [(1,(0,1)),(3,(4,5))]:
  for q,i in enumerate(rows):C[i,j]=S.cancel(mom[k][q].subs(r,hi)-mom[k][q].subs(r,lo))
 if hi<=1:C[2,j],C[3,j]=C[0,j],C[1,j]
assert C==S.Matrix([[S.Rational(x) for x in row] for row in d['raw_moment_matrix']])
co=S.Matrix(C[:2,:2]).inv()*C[:2,2:];M=C[2:,2:]-C[2:,:2]*co
assert co==S.Matrix([[S.Rational(x) for x in row] for row in d['reference_coefficients']]).T
assert M==S.Matrix([[S.Rational(x) for x in row] for row in d['reduced_matrix']])
assert C.det()==S.Rational(d['full_determinant']) and M.det()==S.Rational(d['reduced_determinant'])
print('SYMPY PASS exact integration, closure elimination and determinants',S.__version__)

"""Certified cell lookup; boundary endpoints are returned as None."""
from fractions import Fraction
from flint import arb,ctx

def locate(r,N):
    r=Fraction(r)
    assert r>0 and N>=1
    # Rational points in Q(i) that are roots of unity are ±1, ±i.
    # The sole interior (0, pi) rational-half-angle boundary is pi/2.
    if r==1 and N%2==0:
        return None
    precision=max(192,ctx.prec)
    while True:
        ctx.prec=precision
        angle=2*(arb(r.numerator)/r.denominator).atan()
        pi=arb.pi()
        for j in range(N):
            if angle>pi*j/N and angle<pi*(j+1)/N:
                return j
        precision*=2

import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fractions import Fraction as F
from flint import ctx
from cell_location import locate
assert locate(F(1),2) is None
assert locate(F(1),3)==1
ctx.prec=192
assert locate(F(1)-F(1,10**100),2)==0
assert ctx.prec>=384
assert locate(F(1)+F(1,10**100),2)==1
print('PASS exact boundary skipped; near-boundaries classified at',ctx.prec,'bits')

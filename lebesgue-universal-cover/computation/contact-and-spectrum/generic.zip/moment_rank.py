"""Directed example of a full moment map, including the two closing constraints."""
from flint import arb,arb_mat,ctx
from fractions import Fraction as F
from pathlib import Path
import json,sys
ctx.prec=192
ar=lambda x:arb(F(x).numerator)/F(x).denominator
centers=[F(x) for x in ['.1','.25','.4','.65','.9','1.1','1.4','1.8','2.2','2.9']];h=F(1,2000);cells=[(F(0),F(1)),(F(1),F(2)),(F(2),F(3))]
assert len(centers)==10 and all(b-a>2*h for a,b in zip(centers,centers[1:]))
mat=[[arb(0) for _ in centers] for _ in range(10)]
for j,c in enumerate(centers):
 lo,hi=c-h,c+h;cell=next(i for i,(a,b) in enumerate(cells) if a<lo and hi<b)
 for k,where in [(1,2*cell),(3,6),(5,8)]:
  mat[where][j]=((ar(hi)*k).sin()-(ar(lo)*k).sin())/k
  mat[where+1][j]=((ar(lo)*k).cos()-(ar(hi)*k).cos())/k
A=arb_mat(mat);d=A.det();assert not d.contains(0)
out={'N':3,'m':5,'raw_moment_count':10,'closure_constraints':2,'relative_data_dimension':8,'bump_centers':list(map(str,centers)),'window_halfwidth':str(h),'determinant':str(d),'determinant_nonzero':True,'precision':ctx.prec};Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print('PASS rank',len(mat),'det',d)

# Finite arc moment lower bounds

`PROOF.md` proves that for fixed N half-circle intervals and odd m, the valid moment data have relative dimension 2N+m−3, and a full-measure set in a relative open region requires at least 2N+m full-circle unit-radius arcs. If an independent 2N+m upper theorem applies to the same moment/point conventions, the worst-case bound is exact. It also gives explicit disk data with a sharp lower bound for N=1, and a support-point/finite-pose application with the quantifier limitation.

Run `python -I -B moment_rank.py OUTPUT` and `python -I -B circle_examples.py OUTPUT` with python-flint 0.9.0. These directed numerical runs illustrate rank and root-of-unity identities; the lower bound is analytic and does not rely on floating sampling.

from flint import arb,ctx
from pathlib import Path
import json,sys
ctx.prec=192
out=[]
for m in range(1,16,2):
 n=m+2;rows=[]
 for k in range(1,m+1,2):
  c=sum((2*arb.pi()*j*k/n).cos() for j in range(n));s=sum((2*arb.pi()*j*k/n).sin() for j in range(n));assert c.contains(0) and s.contains(0)
  rows.append({'frequency':k,'cos_sum':str(c),'sin_sum':str(s)})
 out.append({'m':m,'Reuleaux_n':n,'arcs':n,'rows':rows})
Path(sys.argv[1]).write_text(json.dumps({'cases':out,'precision':ctx.prec},indent=2)+'\n');print('PASS',len(out),'odd examples')

# Generic sharp lower bound for finite circular-arc moment matching

Fix N positive-length intervals I_1,…,I_N partitioning a half circle [0,π], and an odd m≥1. A width-one curvature density satisfies 0≤ρ≤1, ρ(t+π)=1−ρ(t) a.e., and the first-harmonic closing condition

    ∫_0^π ρ(t)e^{it} dt = i.                                 (1)

The data are the N complex first-harmonic integrals on the individual intervals and the full-circle complex curvature moments at odd k=3,5,…,m. Each odd full-circle moment is an invertible affine function of the corresponding half-circle integral. The partition and its support directions are fixed in advance. Set d=2N+m−3.

## The data contain a relative open d-dimensional set

Before imposing (1), the 2N local real functions 1_{I_j}cos t, 1_{I_j}sin t and the m−1 global real functions cos kt,sin kt, k=3,5,…,m, are linearly independent. Indeed, if a linear combination vanishes a.e., then on the interior of each I_j one trigonometric polynomial vanishes identically. Analytic continuation and independence of distinct harmonics force every global and local coefficient to vanish. Thus the linear moment map from L∞[0,π] is onto R^{2N+m−1}. Imposing the two independent real equations (1) leaves a surjective d-dimensional relative moment map. A small ball of perturbations around ρ≡1/2, restricted to the closing kernel, remains inside 0≤ρ≤1, so its data contain a relative open set in R^d.

These densities are actual width-one bodies: extend antiperiodically by ρ(t+π)=1−ρ(t). The closing condition annihilates the first Fourier harmonic, so h''+h=ρ has a 2π-periodic solution. Its even nonconstant harmonics vanish and its mean is 1/2, yielding h(t)+h(t+π)=1. The nonnegative curvature measure makes h a convex support function. Translation accounts for the homogeneous cos t,sin t solutions. `moment_rank.py` supplies an independent 192-bit Arb demonstration for N=3,m=5: ten explicit disjoint interval bumps have a nonzero 10×10 moment determinant; after two closing equations the relative dimension is eight.

## Switch stratification and the full-circle seam

A bang-bang density ρ∈{0,1} with finitely many pieces defines a width-one circular-arc polygon: ρ=1 gives unit-radius arcs and ρ=0 gives the intervening corner-normal intervals. Let k be its number of distinct switches strictly inside [0,π]. For a fixed initial value and ordering, the k switch angles parametrize an open simplex. For k≥2, the two closing equations have differential columns ±(cos t_j,sin t_j). Any two distinct half-circle switch angles have determinant sin(t_j−t_i)≠0. The implicit-function theorem therefore makes the closing set a smooth (k−2)-manifold. Moment maps of this manifold are locally Lipschitz and have Hausdorff dimension at most k−2. A switch exactly at a prescribed partition boundary is included by this same ambient stratum (or a lower-dimensional boundary); it cannot increase the dimension. Switches at 0 or π are handled by the seam, not treated as extra free parameters. Finitely many choices of initial bit, order and k remain, so their union has d-dimensional Lebesgue measure zero whenever k−2<d.

Antiperiodicity gives a precise seam count. If k is odd, the two half-circle endpoint bits are opposite and the extension creates no seam switches; the full circle has 2k switches and k positive-curvature arcs. If k is even, the endpoint bits agree and each antipodal seam creates a switch; there are 2k+2 switches and k+1 positive arcs. Hence the full-circle arc count L is always odd and satisfies L=k for odd k and L=k+1 for even k.

If L≤2N+m−2 then k≤2N+m−2=d+1, so k−2≤d−1. Thus the data represented with fewer than 2N+m arcs form a null subset of a relative open d-dimensional set. In particular, for almost every valid datum in that open set at least 2N+m arcs are necessary. The exceptional d=0 case is N=m=1: no zero- or one-switch bang-bang function satisfies (1), giving L≥3=2N+m directly. Together with a separately established construction of at most 2N+m arcs, this proves the exact worst-case number and its generic necessity. This lower bound is for the full-circle number of ρ=1 arcs, not the number of half-circle switches.

## A checkable explicit hard datum

Take the source body to be the disk, ρ≡1/2. For every partition interval the two local first-harmonic differences of f=2ρ_new−1 must vanish. If f has no interior switch, sin(t−a) is strictly positive on the interval (a,b) and makes ∫f sin(t−a) nonzero. If it has exactly one switch at c, sin(t−c) has the same or the opposite sign as f throughout the interval and again gives a nonzero integral. Both functions lie in span{cos t,sin t}. Thus each interval contains at least two interior switches and L≥2N+1.

The disk's global odd curvature moments through m are also zero. Suppose the approximating density has L≤m positive arcs, hence 2L antipodal switches. Choose one representative s_j of each antipodal pair and define

    q(t)=∏_{j=1}^L sin(t−s_j).

L is odd, q changes sign at exactly those switches and contains only odd Fourier frequencies ≤L. Therefore q has the same or the opposite sign as f almost everywhere, so ∫_0^{2π}f q≠0, contradicting the prescribed odd moments. Hence L≥m+2. For every fixed partition the explicit disk datum therefore requires at least max(2N+1,m+2) arcs. This is not claimed to prove the additive 2N+m bound for the disk when N>1.

For N=1 the preceding lower bound is m+2=2N+m. It is attained by the regular Reuleaux (m+2)-gon: its curvature is (m+2)-fold rotationally invariant, so every nonzero Fourier coefficient of frequency at most m vanishes, while its first-harmonic closure gives the required sole local moment. `circle_examples.py` checks root-of-unity sums in directed Arb for the first eight odd m; the exact equality is the roots-of-unity identity.

## Support points and finite poses

If r(t)=h(t)n(t)+h'(t)Jn(t), then r'(t)=ρ(t)Jn(t). Equal local complex first moments make the increments of r across each chosen interval equal. One common translation makes one chosen support point coincide, hence all endpoint support points coincide. Constant width then gives r(t+π)=r(t)−n(t), fixing their antipodes. For odd k≥3, equality of curvature moments is equivalent to equality of support-function Fourier coefficients because ρ_k=(1−k²)h_k.

Consequently, for a *specified finite list* of poses and contact directions for each input, pull all contact directions back into that body's own frame, take their union (mod π) as partition boundaries, and construct one approximating arc body for that input. Applying each previously specified rigid pose then preserves all listed support points, and the prescribed global Fourier moments remain equal. Different bodies keep independent placements. If the desired directions are chosen only after seeing an arbitrary pose, this gives ∀pose ∃arc-body; it does not establish one fixed test body valid for all poses, nor does it transfer an area lower bound requiring a different quantifier order.

from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,sys,subprocess
D=Path(__file__).resolve().parent
def main():
    for name,digest in json.loads((D/'files.json').read_bytes()).items():
        assert sha256((D/name).read_bytes()).hexdigest()==digest,name
    c=D/'compulsory-pair'
    checks=[('check_lenses.py',[], 'lens-base-cert.json'),('full_verify.py',['packed-below80.json','.84408','below80-replayed.json'],'below80-cert.json')]
    for scr,args,expected in checks:
        payload=(c/expected).read_bytes()
        subprocess.run([sys.executable,'-I','-B',str(c/scr),*args],cwd=c,check=True)
        actual=c/(args[-1] if args else expected)
        assert actual.read_bytes()==payload,expected
if __name__=='__main__':main()

from pathlib import Path
import sys,json
D0=Path(__file__).resolve().parent;up=D0.parent/'spur-proof'
sys.path.insert(0,str(up))
from spur import *
D0=Path(__file__).resolve().parent
comp=C;sub=up/'lenses';sys.path[:0]=[str(sub),str(comp)];z=sub/'certify_P_forced_hull_outer.py'
env={'__file__':str(z)};exec(compile(z.read_text().split('    # The integer directions')[0]+'    return defs,candidates,inside,g\n',str(z),'exec'),env)
defs,cc,inside,g=env['run'](comp,F('1.54'),F('1.54'))
if __name__=='__main__':
    ans={n:[list(map(float,v)) for v in a] for n,a in defs.items()}
    (D0/'centers.json').write_text(json.dumps(ans)+'\n')

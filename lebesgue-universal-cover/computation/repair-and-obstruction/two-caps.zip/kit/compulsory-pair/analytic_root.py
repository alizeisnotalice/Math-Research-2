from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from verify_roots import *
def proof(key):
    wi,ei=map(int,key.split(','));w=F(wi,1000);eps=F(ei,10000)
    v,h=body(data,A(w),A(eps));E=[sub(v[i],v[j]) for i,j in ns['orders']]
    U=[av(t) for t in dt['n'][:3]];quarter=arb.pi()/3;H=A('.5')
    def active(n):
        sg=[cross(e,n) for e in E]
        return [ns['sector'][i] for i in range(10) if sg[i]>0 and sg[(i+1)%10]<0]
    z=(A(1),A(0))
    modes0=[active(u) for u in U];assert modes0==[[(1,1)],[(3,1)],[(0,1)]]
    slope=sum((-1)**j*dot(v[m[0][0]],J(U[j])) for j,m in enumerate(modes0));sign=1 if slope>0 else -1;assert sign*slope>0
    events=[A(0),quarter]
    for j in range(3):
        for n in E:
            nn=rad(n,-j*quarter);q=arb.atan2(nn[1],nn[0]);assert q<0 or q>0
            assert q<quarter or q>quarter
            if q>0 and q<quarter:events.append(q)
    events.sort(key=float)
    assert all(a<b for a,b in zip(events,events[1:])), 'coincident events'
    margins=[]
    for i,(a,b) in enumerate(zip(events,events[1:])):
        m=(a+b)/2;aa=bb=A(0);c=-H
        for j,u in enumerate(U):
            act=active(rad(u,m));assert len(act)==1
            k,r=act[0];fac=(-1)**j;aa+=fac*dot(v[k],u);bb+=fac*dot(v[k],J(u));c+=fac*r
        aa*=sign;bb*=sign;c*=sign
        na=rad(z,a);nb=rad(z,b);f0=aa*na[0]+bb*na[1]+c;f1=aa*nb[0]+bb*nb[1]+c
        if i==0:
            assert f0.contains(0) and -aa*na[1]+bb*na[0]>0
        else:assert f0>0; margins.append(f0.lower())
        if i==len(events)-2:
            assert f1.contains(0) and -aa*nb[1]+bb*nb[0]<0
        else:assert f1>0;margins.append(f1.lower())
        amin=(-aa,-bb)
        if not cross(na,amin)<0 and not cross(amin,nb)<0:
            val=c-(aa*aa+bb*bb).sqrt()
            assert val>0; margins.append(val.lower())
    losses=[]
    for t in range(6):
        for s in (-1,1):
            if (t,s) in [(0,1),(4,-1)]:continue
            g=[]
            for j in (3,5):
                n=av(dt['m'][j]);pre=rad((n[0],s*n[1]),-t*quarter);g.append((h(pre)-H).lower())
            assert max(g)>0;losses.append(max(g))
    return dict(x=interior(v[4]),y=interior(refl(v[2])),minimum_at_internal_event_or_minimum=str(min(margins)),endpoint_slope=str((sign*slope).lower()),root_pieces=len(events)-1,root_sign=sign,cap_exclusion=str(min(losses)))
if __name__=='__main__':
    print(proof(sys.argv[1]))

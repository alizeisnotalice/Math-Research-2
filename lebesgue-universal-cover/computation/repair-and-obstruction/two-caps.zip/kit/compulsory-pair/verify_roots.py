from pathlib import Path
import sys,json,time
D0=Path(__file__).resolve().parent;upper=D0.parent/'spur-proof'
sys.path.insert(0,str(upper))
from spur import *
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0.parent/'spur-proof'/'lenses'));sys.path.insert(0,str(C))
from certify_nonideal_pentagon_pose_library import verify
from deformed_reuleaux_support import body
data=ns.copy();data['n0']=av(dt['n'][0]);aa=(C/'certify_ah_two_line_cap.py').read_text()
exec(compile(aa[aa.index('def F_at('):aa.index('def placement(')],'F_at','exec'),data)
def interior(v):
    old=mul(A(1)-A(F(1,10**10)),v);t=10**13;q=tuple(round(float(x)*t) for x in old)
    assert norm(sub(av(tuple(F(i,t) for i in q)),old))<A(F(1,2*10**10))
    return list(q)
def solve(key):
    wi,ei=map(int,key.split(','));w=F(wi,1000);e=F(ei,10000)
    qq=verify(data,w,e,F(0),F(0));v,_=body(data,A(w),A(e))
    x,y=interior(v[4]),interior(refl(v[2]))
    return dict(x=x,y=y,endpoint_margin=qq['endpoint_margin'],interior_margin=qq['interior_margin'],root_cells=qq['interior_cells'],sign=qq['F_sign'],cap_exclusion=min(float(arb(g[3]).lower()) for g in qq['cap_eliminations']))
if __name__=='__main__':
    cert=json.load(open(D0/sys.argv[1]));keys=set(cert['points'])
    for i in json.load(open(D0/'common-points.json')):
        keys.add(str(int(F(i['w'])*1000))+','+str(int(F(i['e'])*10000)))
    dst=D0/'root-cache.json';cache=json.load(open(dst)) if dst.exists() else {};failed={};left=[k for k in sorted(keys) if k not in cache];t0=time.time()
    for j,k in enumerate(left):
        try:cache[k]=solve(k)
        except (ArithmeticError,AssertionError) as exc:failed[k]=str(exc)
        if j%25==24:
            dst.write_text(json.dumps(cache)+'\n');print(j+1,len(left),len(failed),round(time.time()-t0,1),flush=True)
    dst.write_text(json.dumps(cache)+'\n');(D0/'root-failed.json').write_text(json.dumps(failed)+'\n')
    print('verified',len(keys)-len(failed),'failed',failed,flush=True)

from pathlib import Path
from fractions import Fraction as F
import json,sys
D=Path(__file__).resolve().parent;S=10**13
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def orient(a,b,c):return cross(sub(b,a),sub(c,a))
def hull(pts):
    vs=sorted(set(map(tuple,pts)))
    def part(vs):
        b=[]
        for p in vs:
            while len(b)>1 and orient(b[-2],b[-1],p)<=0:b.pop()
            b.append(p)
        return b[:-1]
    return part(vs)+part(reversed(vs))
def doubled(v):return sum(cross(a,b) for a,b in zip(v,v[1:]+v[:1]))
def extras(v,p):return [max(0,-orient(a,b,p)) for a,b in zip(v,v[1:]+v[:1])]
def meet(a,x,b,y):
    d=sub(x,a);e=sub(y,b);ab=sub(b,a);k=cross(d,e)
    if k==0:return None
    l=F(cross(ab,e),k);r=F(cross(ab,d),k)
    if not (0<=l<=1 and 0<=r<=1):return None
    p=[F(a[i])+l*d[i] for i in range(2)]
    # Actual segment intersection belongs to C in either pose. Round through the common half-disk.
    eps=F(1,10**10);q=tuple(round(z*(1-eps)) for z in p)
    assert sum((q[i]-p[i]*(1-eps))**2 for i in range(2))<(eps*S/2)**2
    return q
def base_points(lens,cache,common):
    pts=[tuple(v) for v in lens['vertices']];assert lens['scale']==S
    r=[]
    for row in common:
        a=tuple(round(i*S) for i in row['left']);b=tuple(round(i*S) for i in row['right'])
        assert a in pts and b in pts
        key=str(int(F(row['w'])*1000))+','+str(int(F(row['e'])*10000))
        cp=cache.get(key)
        if cp is None:continue
        q=meet(a,cp['x'],b,cp['y'])
        if q is not None:r.append(q)
    return hull(pts+r)
def check_tree(tree,cache,v,threshold):
    low=[10**40];stats=[0,0];bad=[]
    def go(node,v,trail):
        ar=doubled(v)
        if ar>threshold:low[0]=min(low[0],ar);stats[1]+=1;return
        if node[0] in (0,-1):
            bad.append(('range',trail,float(F(ar,2*S*S))));return
        if node[0]==1:
            edges=set();saved=0
            for k in node[1]:
                cp=cache.get(k)
                if cp is None:continue
                a,b=extras(v,cp['x']),extras(v,cp['y']);mask={i for i,(d,e) in enumerate(zip(a,b)) if d>0 or e>0}
                if edges.isdisjoint(mask):
                    edges.update(mask);saved+=min(sum(a),sum(b))
            if ar+saved<=threshold:bad.append(('packing',trail,float(F(ar+saved,2*S*S))));return
            stats[1]+=1;low[0]=min(low[0],ar+saved);return
        k=node[0];cp=cache.get(k);stats[0]+=1
        if cp is None:bad.append(('profile',k,trail));return
        for p,ch in zip((cp['x'],cp['y']),node[1:]):go(ch,hull(v+[p]),trail+str(int(p==cp['y'])))
    go(tree,v,'');return stats,low[0],bad
if __name__=='__main__':
    tr=json.load(open(D/sys.argv[1]));target=F(sys.argv[2]);cache=json.load(open(D/'root-cache.json'))
    if (D/'analytic-cache.json').exists():cache.update(json.load(open(D/'analytic-cache.json')))
    v=base_points(json.load(open(D/'lens-inner.json')),cache,json.load(open(D/'common-points.json')))
    stats,low,bad=check_tree(tr['tree'],cache,v,2*S*S*target)
    print('base',float(F(doubled(v),2*S*S)),'verified',stats,'unresolved',len(bad),'minimum',float(F(low,2*S*S)),bad[:5],flush=True)

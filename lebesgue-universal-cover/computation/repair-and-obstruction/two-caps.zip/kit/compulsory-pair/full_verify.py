from functools import lru_cache
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from exact_domain import S,hull,doubled,extras,base_points,F
from analytic_root import proof,A,av,rad,arb,body,sub,ns,add,mul,cross,interior,refl,data
B=F('.844082046521218581802948589770767704354')
@lru_cache(maxsize=None)
def normals(j):
    assert isinstance(j,int) and 0<=j<720
    return rad((A(1),A(0)),A(F(1,100)+F(j,2))*arb.pi()/180)
@lru_cache(maxsize=10000)
def shape(key):
    w,e=map(int,key.split(','))
    v,_=body(data,A(F(w,1000)),A(F(e,10000)));return v,[sub(v[i],v[j]) for i,j in ns['orders']]
@lru_cache(maxsize=None)
def sample(key,side,j):
    v,E=shape(key);n=normals(j)
    a=[cross(e,n) for e in E];ids=[i for i in range(10) if a[i]>0 and a[(i+1)%10]<0];assert len(ids)==1
    k,r=ns['sector'][ids[0]];p=add(v[k],mul(A(r),n))
    return tuple(interior(refl(p) if side else p))
def replay(path,target,out):
    doc=json.loads(path.read_bytes());common=json.load(open(D/'common-points.json'))
    cache={}
    for r in common:
        k=str(int(F(r['w'])*1000))+','+str(int(F(r['e'])*10000))
        try:cache[k]=proof(k)
        except (ValueError,AssertionError,ArithmeticError):pass
    keys=doc.get('keys',doc.get('points',[]))
    for k in keys:cache[k]=proof(k)
    v=base_points(json.load(open(D/'lens-inner.json')),cache,common)
    if doc.get('certified_closure'):
        v=json.loads((D/'closure-certified.json').read_bytes())['vertices'];v=hull(v)
    limit=2*S*S*target;lower=10**50;stats={'branch':0,'area_leaf':0,'pack_leaf':0,'enumerated_pack':0};bad=[]
    def yes(xx):return xx>limit
    def go(t,v,path):
        nonlocal lower
        ar=doubled(v)
        if yes(ar):
            lower=min(lower,ar);stats['area_leaf']+=1;return
        if t[0] in (0,-1):bad.append([path,'range',str(F(ar,2*S*S))]);return
        if t[0]==1:
            edges=set();saved=0
            for k in t[1]:
                cp=cache[k];a,b=extras(v,cp['x']),extras(v,cp['y']);mask={i for i,(d,e) in enumerate(zip(a,b)) if d>0 or e>0}
                if edges.isdisjoint(mask):
                    edges.update(mask);saved+=min(sum(a),sum(b))
            if yes(ar+saved):lower=min(lower,ar+saved);stats['pack_leaf']+=1;return
            def en(q,j):
                nonlocal lower
                z=doubled(q)
                if yes(z):
                    lower=min(lower,z);stats['enumerated_pack']+=1;return
                if j>=len(t[1]):bad.append([path,'packing',str(F(z,2*S*S))]);return
                cp=cache[t[1][j]]
                for g in (cp['x'],cp['y']):en(hull(q+[g]),j+1)
            en(v,0);return
        k=t[0];stats['branch']+=1
        for s,c in enumerate(t[-2:]):
            pts=[cache[k][('x','y')[s]]]
            if len(t)==4:pts.extend(sample(k,s,j) for j in t[1][s])
            go(c,hull(v+pts),path+str(s))
    go(doc['tree'],v,'')
    rec=dict(threshold=str(target),root_count=len(cache),stats=stats,rational_minimum=str(F(lower,2*S*S)),minimum_decimal_24=str(lower*10**24//(2*S*S))+'e-24',unresolved=len(bad),exceptions=bad[:25]);out.write_text(json.dumps(rec,indent=2)+'\n');print(rec,flush=True)
    assert not bad
if __name__=='__main__':replay(Path(sys.argv[1]),F(sys.argv[2]),Path(sys.argv[3]))

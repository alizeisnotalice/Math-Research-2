from pathlib import Path
import sys,json
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from centers import defs,arb,F,A,dot,g
info=json.loads((D/'lens-inner.json').read_bytes());out={};S=info['scale'];assert S==10**13
for (x,y),label in zip(info['vertices'],info['labels'],strict=True):
    p=A(F(x,S)),A(F(y,S))
    if label=='disk':slack=A(F(1,4))-dot(p,p)
    else:slack=min((1-dot(g.minus(p,c),g.minus(p,c))).lower() for c in defs[label])
    assert slack>0,(label,p,slack)
    out[label]=min(out.get(label,A(1)),slack.lower())
(D/'lens-base-cert.json').write_text(json.dumps({k:str(v) for k,v in out.items()},indent=2)+'\n');print(len(info['vertices']),min(out.values()),flush=True)

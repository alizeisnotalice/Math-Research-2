"""Find separating rows for the illumination region of the five-curve inner polygon."""
from fractions import Fraction as F
from pathlib import Path
import json
import math
import sys
import numpy as np
from scipy.optimize import linprog
from scipy.spatial import ConvexHull

def det(x,y): return x[0]*y[1]-x[1]*y[0]
def read(path): return json.loads(path.read_bytes())
def support_rows(h,den,target):
    n=len(h)
    full=h+h
    sums=[0]
    for a,b in zip(full,full[1:]+full[:1]):
        sums.append(sums[-1]+det(a,b))
    room=2*target*den**2-sums[n]
    assert room>0
    rows=[]; dual=[]
    for steps in [1,2,3,4,6,8,12,16,22,30,40,52,68,86,110,142,180,230]:
        if steps>=n//2:continue
        for i in range(n):
            j=i+steps;a,b=full[i],full[j]
            x=b[1]-a[1];y=a[0]-b[0]
            wall=(room+sums[j]-sums[i])/den
            assert wall>0; rows.append((int(x),int(y),wall));dual.append((x/float(wall),y/float(wall)))
    points=np.array(dual)
    active=ConvexHull(points).vertices.tolist()
    return [rows[i] for i in active[::2]]

def run(comp,pose,points,out,k,tar,grids=256, radius="0"):
    sys.path.insert(0,str(comp/'inclusion-minimal-eleven'))
    from template import build
    pos=read(pose)['center']; scale=F(radius)*2**44; w=[-((-scale*(3 if i in (2,5,8) else 1))//1) for i in range(11)]; h,d=build(comp,False,k,True,box=[[z-int(wi),z+int(wi)] for z,wi in zip(pos,w)]);h=[tuple(map(int,x)) for x in h];d=int(d)
    target=F(tar);rows=support_rows(h,d,target)
    p=read(points);V=np.array(p['points'],float)/p['denominator']
    normal=np.array([(x,y) for x,y,b in rows],float);lengths=np.linalg.norm(normal,axis=1);N=normal/lengths[:,None];H=np.array([float(b) for _,_,b in rows])/lengths
    mat=np.c_[N,-np.ones(len(H))];worst=1.; poses=[]; rec=[]
    for hand in [1,-1]:
        for j in range(grids):
            ang=2*math.pi*(j+.5)/grids;c=math.cos(ang);s=math.sin(ang)
            RV=V@np.array([[c,s],[-hand*s,hand*c]]);hs=N@RV.T
            sol=linprog([0,0,1],A_ub=mat,b_ub=H-hs.max(axis=1),bounds=[(None,None)]*3,method='highs')
            assert sol.success
            if sol.fun<worst:worst=sol.fun;poses=[hand,j,sol.x.tolist()]
            ids=np.flatnonzero(-sol.ineqlin.marginals>1.e-9).tolist()
            picks=[int(np.argmax(hs[i])) for i in ids];rec.append([hand,j,ids,picks])
    data=dict(k=k,translation_radius=radius,den=d,host_vertices=len(h),target=tar,grid=grids,n_rows=len(rows),worst=worst,pose=poses,rows=[[x,y,str(b)] for x,y,b in rows],records=rec)
    out.write_text(json.dumps(data,separators=(',',':')))
    print(k,len(h),tar,len(rows),worst,poses,flush=True)
if __name__=='__main__':
    comp,pose,points,out=map(Path,sys.argv[1:5]);run(comp,pose,points,out,int(sys.argv[5]),sys.argv[6],int(sys.argv[7]),sys.argv[8] if len(sys.argv)>8 else "0")

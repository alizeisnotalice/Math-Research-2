"""Exact rational-polygon and finite-spectrum geometry for D2162."""
from functools import cache
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from certify_poly import A, Exact, F, HOST_SHA, arb, cmul, ctx, read, sha

B=F('.844082046521218581802948589770767704354')


def det(a,b):return a[0]*b[1]-a[1]*b[0]


def dot(a,b):return a[0]*b[0]+a[1]*b[1]


def sub(a,b):return a[0]-b[0],a[1]-b[1]


def add(a,b):return a[0]+b[0],a[1]+b[1]


def mul(t,a):return t*a[0],t*a[1]


def J(a):return -a[1],a[0]


def rot(a,c,s):return (c*a[0]-s*a[1],s*a[0]+c*a[1])


def hull(points):
    points=sorted(set(points))
    def side(points):
        out=[]
        for p in points:
            while len(out)>1 and det(sub(out[-1],out[-2]),sub(p,out[-1]))<=0:
                out.pop()
            out.append(p)
        return out[:-1]
    return side(points)+side(reversed(points))


def area2(points):
    return sum(det(a,b) for a,b in zip(points,points[1:]+points[:1],strict=True))


@cache
def host():
    p=HERE/'d2162.json';w=HERE/'degree93.json'
    assert sha(p)==HOST_SHA and sha(w)=='f791b04432770b59ab2e339c548a5d578d897d9816a56908855327aec0e19537'
    h=read(p)
    Q=list(map(tuple,h['vertices']));D=h['denominator']
    assert D==10**12 and len(set(Q))==len(Q)==2162
    assert all(det(x,y)>0 for x,y in zip(Q,Q[1:]+Q[:1],strict=True))
    return Q,D,F(area2(Q),2*D*D)


class Shape:
    def __init__(self):
        doc=read(HERE/'degree93.json');assert doc['degree']==93
        self.terms=[(k,A(a)/(1-k*k),A(b)/(1-k*k)) for k,a,b in doc['curvature_modes']]
        assert [k for k,a,b in self.terms]==list(range(3,94,2))

    @cache
    def point(self,t):
        u=arb.pi()*A(2*t);s,c=u.sin_cos()
        H=A('.5');D=arb(0)
        p=(c,s);rr=cmul(p,p)
        for n,a,b in self.terms:
            p=cmul(p,rr)
            x,y=p
            H+=a*x+b*y
            D+=n*(b*x-a*y)
        return H*c-D*s,H*s+D*c

    def preset(self,x,pose):
        q=F(pose['q']);hand=pose['hand'];sgn=(-1)**int(pose['halfturn'])
        assert hand in (-1,1)
        c,s=A(sgn*(1-q*q)/(1+q*q)),A(sgn*2*q/(1+q*q))
        x,y=rot((x[0],hand*x[1]),c,s)
        return x+A(pose['tx']),y+A(pose['ty'])

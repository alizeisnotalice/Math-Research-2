"""All-pose area lower bounds from the frozen support dual and exact inner chords."""
import argparse
from functools import cache
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import *

DEPTH=tuple(map(F,('1e-10','2e-10','5e-10','1e-9','2e-9','5e-9','1e-8','2e-8','5e-8',
    '1e-7','2e-7','5e-7','1e-6','2e-6','5e-6','1e-5','2e-5','5e-5','1e-4','2e-4','5e-4','1e-3')))


class Check:
    def __init__(self,T,rows=HERE/'rows-new.json'):
        self.T=T
        self.P,self.D,_=host()
        self.ex=Exact(HERE/'degree93.json',rows)
        self.rows=read(rows)

    @cache
    def permitted(self,n):
        P,D,T=self.P,self.D,self.T
        L=arb(dot(n,n)).sqrt();l1=max(map(abs,n));tan=J(n)
        height=[dot(n,p) for p in P];hmax=max(height)
        tang=[dot(tan,p) for p in P]
        verts=list(zip(height,height[1:]+height[:1],tang,tang[1:]+tang[:1],strict=True))
        out=[]
        for depth in DEPTH:
            scaled=depth*D*l1
            num=hmax*scaled.denominator-scaled.numerator
            den=scaled.denominator
            ends=[]
            for h,k,p,q in verts:
                above=h*den-num;below=k*den-num
                if above==0:ends.append(F(p))
                elif above*below<0:ends.append(F(p*(above-below)+(q-p)*above,above-below))
            assert len(ends)>=2
            ell=A((max(ends)-min(ends))/D)/L
            setback=A(depth*l1)/L
            assert ell>0 and setback>0
            s=A(T)/ell
            out.append((s+(s*s+2*s*setback).sqrt()).upper())
        return min(out)

    @cache
    def allowance(self,i):
        row=self.rows[i]
        V=[tuple(p) for p in row['normals']]
        W=[A(F(x))*arb(dot(n,n)).sqrt() for x,n in zip(row['weights'],V,strict=True)]
        return (sum(a*self.permitted(n) for a,n in zip(W,V,strict=True) if a>0)/sum(W)).upper()

    def bound(self,i,hand,l,r):
        return (self.ex.row_lower(i,hand,l,r)-self.allowance(i)).lower()

    def verify(self,plan):
        S={}
        for hand in (1,-1):
            end=F(0);worst=None
            for l,r,i in plan[str(hand)]:
                l,r=F(l),F(r);assert l==end and l<r and 0<=i<len(self.rows)
                end=r
                b=self.bound(i,hand,l,r)
                assert b>0,(hand,str(l),str(r),i,b)
                worst=b if worst is None else min(worst,b)
            assert end==1
            S[str(hand)]={'closed_cells':len(plan[str(hand)]),'minimum_projective_slack':str(worst)}
        return S

    def make(self,old):
        import numpy as np
        const=np.array([float(v.mid())-float(self.allowance(i).mid())for i,v in enumerate(self.ex.const)])
        n=np.array(self.ex.n)
        plans={}
        for hand in (1,-1):
            co=np.array([[[float(v.mid())for v in p] for p in r]for r in self.ex.c[hand]])
            cells=[]
            def visit(l,r,i,depth):
                if self.bound(i,hand,l,r)>0:
                    cells.append([str(l),str(r),i]);return
                s=(float(l+r)*np.pi)*n
                val=const+co[:,:,0]@np.cos(s)+co[:,:,1]@np.sin(s)
                for k in np.argsort(-val)[:7]:
                    if self.bound(int(k),hand,l,r)>0:
                        cells.append([str(l),str(r),int(k)]);return
                assert depth<16,(hand,str(l),str(r),float(val.max()),int(val.argmax()))
                q=(l+r)/2
                visit(l,q,int(val.argmax()),depth+1);visit(q,r,int(val.argmax()),depth+1)
            for l,r,i in old[str(hand)]:visit(F(l),F(r),i,0)
            plans[str(hand)]=cells
        return plans


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('threshold',type=F);p.add_argument('plan',type=Path)
    p.add_argument('out',type=Path);p.add_argument('--make-plan',action='store_true');a=p.parse_args()
    assert __debug__ and a.threshold>0;ctx.prec=192
    chk=Check(a.threshold)
    if a.make_plan:
        plan=chk.make(read(HERE/'plan.json'));a.plan.write_text(json.dumps(plan,separators=(',',':'))+'\n')
    else:plan=read(a.plan)
    hands=chk.verify(plan);q=dict(complete=True,threshold=str(a.threshold),hands=hands,host_sha256=HOST_SHA,
                input_sha256=sha(HERE/'degree93.json'),rows_sha256=sha(HERE/'rows-new.json'),plan_sha256=sha(a.plan),
                chord_directions=chk.permitted.cache_info().currsize,source_sha256=sha(Path(__file__)),precision=ctx.prec)
    a.out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))

if __name__=='__main__':main()

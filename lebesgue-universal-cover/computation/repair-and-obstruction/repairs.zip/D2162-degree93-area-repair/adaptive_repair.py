"""Support separation gives a small rational outer repair of the actual smooth body."""
import argparse
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import *


class Placed:
    def __init__(self,pose):
        q=F(pose['q']);b=(-1)**int(pose['halfturn']);self.hand=pose['hand'];assert self.hand in (-1,1)
        self.c,self.s=A(b*(1-q*q)/(1+q*q)),A(2*b*q/(1+q*q))
        self.t=(A(pose['tx']),A(pose['ty']))
        self.W=Shape()

    def direction(self,n,L,needpoint=False):
        u,v=n[0]/L,n[1]/L;c,s=self.c,self.s
        b=(c*u+s*v,self.hand*(-s*u+c*v));q=b;r=cmul(b,b)
        h=A('.5');d=arb(0)
        for k,x,y in self.W.terms:
            q=cmul(q,r);f,g=q;h+=x*f+y*g
            if needpoint:d+=k*(y*f-x*g)
        sup=h+dot((u,v),self.t)
        if not needpoint:return sup
        p=add(mul(h,b),mul(d,J(b)))
        return sup,add(rot((p[0],self.hand*p[1]),c,s),self.t)


def find(pose_file,output,pad,passes):
    P,D,old=host();T=Placed(read(pose_file));grid=10**15
    assert grid%D==0
    core=[(x*(grid//D),y*(grid//D)) for x,y in P]
    p=list(core)
    for step in range(passes):
        V=hull(p);new=[];gaps=[]
        for v,w in zip(V,V[1:]+V[:1],strict=True):
            n=(w[1]-v[1],v[0]-w[0]);L=arb(dot(n,n)).sqrt()
            b=A(F(dot(n,v),grid))/L
            raw=T.direction(n,L)-b
            if raw<0:continue
            g,X=T.direction(n,L,True)
            z=tuple(round(float(u.mid())*grid) for u in X)
            assert all(abs(A(F(i,grid))-u)<A(F(3,4*grid)) for i,u in zip(z,X,strict=True))
            new.extend((z[0]+i,z[1]+j) for i in (-pad,pad) for j in (-pad,pad));gaps.append(raw.upper())
        a=F(area2(V),2*grid**2)-old
        print(step,'facets',len(V),'bad',len(gaps),'max support',str(max(gaps)) if gaps else None,'delta',float(a),flush=True)
        if not gaps:
            assert 0<a<B-old
            output.write_text(json.dumps({'denominator':grid,'vertices':V},separators=(',',':'))+'\n')
            return
        assert new and set(new)-set(p)
        p.extend(new)
    raise AssertionError('Support search stopped before prescribing a closed repair')


def verify(pose_file,repair,target):
    P,D,area=host();T=Placed(read(pose_file))
    E=Exact(HERE/'degree93.json',HERE/'rows-new.json');curv=E.strict_curvature(32768,F('.0000225'))
    out=read(repair);N=out['denominator'];v=list(map(tuple,out['vertices'])); assert N%D==0 and len(set(v))==len(v)
    assert all(type(x) is int and type(y) is int for x,y in v)
    assert hull(v)==v
    total=F(area2(v),2*N**2);cost=total-area
    assert area<total<B and cost<target
    least=None
    for x,y in zip(v,v[1:]+v[:1],strict=True):
        n=(y[1]-x[1],x[0]-y[0]);h=dot(n,x)
        assert all(dot(n,p)*(N//D)<=h for p in P)
        L=arb(dot(n,n)).sqrt()
        gap=(A(F(h,N))/L-T.direction(n,L)).lower()
        assert gap>0,gap
        least=gap if least is None else min(least,gap)
    return dict(complete=True,geometry='original D2162 and a true rigid pose of the rational 93rd-degree width-one spectrum',
                upper_bound=str(target),exact_increase=str(cost),decimal_increase=float(cost),
                exact_base_area=str(area),exact_repaired_area=str(total),exact_budget_remaining=str(B-total),
                vertices=len(v),pose=read(pose_file),least_directed_support_slack=str(least),proved_curvature_interval=curv,
                source_sha256=sha(Path(__file__)),host_sha256=HOST_SHA,profile_sha256=sha(HERE/'degree93.json'),
                pose_sha256=sha(pose_file),repair_sha256=sha(repair),precision=ctx.prec)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('pose',type=Path);p.add_argument('repair',type=Path)
    p.add_argument('receipt',type=Path);p.add_argument('--target',type=F,default=F('8e-11'));p.add_argument('--find',action='store_true')
    p.add_argument('--pad',type=int,default=64);p.add_argument('--passes',type=int,default=40);x=p.parse_args()
    assert __debug__;ctx.prec=192
    if x.find:find(x.pose,x.repair,x.pad,x.passes)
    data=verify(x.pose,x.repair,x.target);x.receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2),flush=True)


if __name__=='__main__':main()

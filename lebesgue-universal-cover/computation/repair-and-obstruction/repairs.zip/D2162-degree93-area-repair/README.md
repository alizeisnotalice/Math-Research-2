# D2162 与 93 阶谱的自由修补和八母体闭单形

固定 D2162 的全部旧顶点。同一个原始 93 阶有理谱真定宽体在所有旋转、反射和平移中的最小真凸包新增面积满足

\[
6.5\times10^{-11}<\min \Delta A<7.6822\times10^{-11}.
\]

`repair-free-exact.json` 为自由单体上端，原宿主距 B 的预算约为 \(2.09599045577\times10^{-7}\)。`repair-common-exact.json` 保留原七母体的共同正交映射，容纳原 93 阶谱加入后的整个八母体闭 Minkowski 单形。其新增面积严格小于 \(4.822\times10^{-9}\)，剩余预算严格大于 \(2.04777\times10^{-7}\)。

从解压目录使用启用断言的 Python 和 `python-flint` 重算

```sh
python -I -B verify_release.py receipt.json
```

重放逐项复算真内弦、全闭角、弱角段真径向扇、两套有理修补的精确面积和原七母体真实边界支持。`PROOF.md` 给出数学依据。`rows-new.json` 与 `plan.json` 取自 D2162 对同一原 93 阶谱的上游全角漏装证书。`family/seven-receipt.json` 及七个母体取自既有 D2162 七母体闭单形证书。两个修补多边形的顶点已冻结。

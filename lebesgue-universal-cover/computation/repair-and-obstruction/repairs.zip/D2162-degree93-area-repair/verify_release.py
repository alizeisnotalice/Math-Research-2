"""Replay the all-pose lower bound, true small repairs and raw closed simplex."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys
from flint import ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import read,sha,B,host
from chord_lower import Check as Chord
from true_fan import Check as Fan
from adaptive_repair import verify as repair
from verify_family import run as family


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('out',type=Path);args=p.parse_args()
    assert __debug__;ctx.prec=192
    cfg=read(HERE/'settings.json');assert F(cfg['B'])==B
    chord=Chord(F(cfg['chord_lower'])).verify(read(HERE/'chord-3e11.json'))
    print('unrestricted area lower from inner chords',chord,flush=True)
    plan=read(HERE/'fan-plan.json');assert F(plan['threshold'])==F(cfg['lower'])
    strong=Fan(cfg['lower'],plan['fan_samples']).verify(plan)
    print('unrestricted area lower with true radial fans',strong,flush=True)
    free=repair(HERE/'free-pose.json',HERE/'repair-free-exact.json',F(cfg['upper']))
    common=family(HERE/'common-raw-pose.json',HERE/'repair-common-exact.json')
    assert F(free['exact_repaired_area'])<B and F(common['repair']['exact_repaired_area'])<B
    print('true areas above D2162:',free['decimal_increase'],common['repair']['decimal_increase'],flush=True)
    names=('verify_release.py','geometry.py','certify_poly.py','chord_lower.py','true_fan.py','adaptive_repair.py',
           'verify_family.py','d2162.json','degree93.json','rows-new.json','plan.json','chord-3e11.json','fan-plan.json',
           'free-pose.json','repair-free-exact.json','common-raw-pose.json','repair-common-exact.json','settings.json',
           'family/profile_source.py','family/seven-receipt.json')+tuple(f'family/parent-{c}.json' for c in 'abcdefg')
    paths=[HERE/n for n in names]
    result=dict(complete=True,settings=cfg,original_budget=str(B-host()[2]),
                chords=chord,free_lower=strong,free_upper=free,common_family=common,
                source_sha256={str(p.relative_to(HERE)):sha(p) for p in paths},
                precision=ctx.prec,python=platform.python_version(),flint=flint_version)
    args.out.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()

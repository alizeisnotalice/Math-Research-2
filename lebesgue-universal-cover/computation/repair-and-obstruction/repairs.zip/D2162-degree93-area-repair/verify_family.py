"""Place the seven original bodies and the raw 93rd-degree body at one common orthogonal map."""
import argparse
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import *
from adaptive_repair import verify as repair_check
sys.path.insert(0,str(HERE/'family'))
from profile_source import Profile


def run(pose_file,repair):
    receipts=read(HERE/'family'/'seven-receipt.json')
    pose=read(pose_file)
    for k in ('q','hand','halfturn'):
        assert receipts[k]==pose[k]
    assert receipts['host_sha256']==HOST_SHA
    R=repair_check(pose_file,repair,F('4.822e-9'))
    letters='abcdefg';files=[HERE/'family'/f'parent-{x}.json' for x in letters]
    assert all(sha(p)==receipts['inputs'][x] for x,p in zip(letters,files,strict=True))
    bodies=[Profile(read(x)) for x in files]
    P,D,base=host()
    T=[tuple(map(A,row)) for row in receipts['translations']]
    q=F(pose['q']);d=(-1)**int(pose['halfturn']);hand=pose['hand']
    c,s=A(d*(1-q*q)/(1+q*q)),A(d*2*q/(1+q*q))
    least=[None]*len(bodies)
    for v,w in zip(P,P[1:]+P[:1],strict=True):
        n=(w[1]-v[1],v[0]-w[0]);L=arb(dot(n,n)).sqrt()
        x,y=(A(z)/L for z in n)
        u=(c*x+s*y,hand*(-s*x+c*y));z=A(F(dot(n,v),D))/L
        for i,(b,t) in enumerate(zip(bodies,T,strict=True)):
            k=(z-dot((x,y),t)-b.support(u)).lower()
            assert k>0,(i,v,k)
            if least[i] is None or k<least[i]:least[i]=k
    return dict(complete=True,closed_simplex_vertices=8,common_orthogonal_map={k:pose[k] for k in ('q','hand','halfturn')},
                inherited_mothers_checked_faces=len(P),inherited_minimal_slacks=list(map(str,least)),
                additional_parent_uses_original_profile=True,translation_combination='affine interpolation of the eight rational translations',
                parent_sha256=dict(zip(letters,map(sha,files),strict=True)),family_source_sha256=sha(HERE/'family'/'seven-receipt.json'),
                family_geometry_kernel_sha256=sha(HERE/'family'/'profile_source.py'),repair=R,verifier_sha256=sha(Path(__file__)))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('pose',type=Path);p.add_argument('repair',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();assert __debug__;ctx.prec=192
    result=run(a.pose,a.repair);a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()

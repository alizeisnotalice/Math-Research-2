from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from zipfile import ZipFile
import json,shutil,subprocess,sys
D=Path(__file__).resolve().parent;core=Path(sys.argv[1]).resolve();w=Path(sys.argv[2]).resolve()
w.mkdir(parents=True,exist_ok=True);assert not any(w.iterdir())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
for n,h in read(D/'manifest.json').items():assert sha(D/n)==h
assert sha(core)=='85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1'
with ZipFile(core) as z:z.extractall(w/'base')
k=w/'base'/'kit'
with ZipFile(k/'obstruction.zip') as z:z.extractall(w/'old')
shutil.copytree(w/'old'/'barrier'/'comp068',w/'comp068')
for n in ['candidate.py','shared.py']:shutil.copyfile(k/n,w/n)
shutil.copytree(D/'payload',w,dirs_exist_ok=True)
rg=read(w/'legacy-150-poses.json')['poses'];q=read(w/'profile-source/nonideal-pentagon-library.json')['parameters'];assert q['sigma']=='1.5497'
lib={'nonideal-pentagon-library.json':q['points'],'nonmonotone-pentagon-inputs.json':read(w/'profile-source/nonmonotone-pentagon-inputs.json')}
for row in rg:
    if 'w' in row:assert tuple(map(F,lib[row['source']][row['body_index']]))==(F(row['w']),F(row['e']))
checks=[('', 'legacy_profiles.py','profile-cert.json'),('','mirror_refined.py','mirror-cert.json'),('mirror-lp','certify.py','counterexample.json'),('mirror-lp','binary.py','binary.json')]
checks+=[('spur-proof',s+'.py',o+'.json') for s,o in [('inputs','five-inputs'),('other_inputs','other-inputs'),('forced_lenses','lenses'),('cert_area','area'),('family','family'),('witness','witness'),('repair_lower','repair-lower')]]
for sub,s,out in checks:
    loc=w/sub;subprocess.run([sys.executable,'-I','-B',str(loc/s)],cwd=loc,check=True,stdout=subprocess.DEVNULL)
    assert (loc/out).read_bytes()==(D/'payload'/sub/out).read_bytes(),out
print('Verified the 11-wall tri-parametric area, all registered regression inputs, actual closed witness box and both repair-area lower bounds.')

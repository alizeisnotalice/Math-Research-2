from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;src=(D0/'certify.py').read_text()
exec(compile(src.split('knots=')[0],str(D0/'certify.py'),'exec'))
pieces=[]
for lo,hi,r in zip(breaks,breaks[1:],dev):
    l=A(lo)*U;h=A(hi)*U;rho=r+A('.5')
    if rho==0 or rho==1:pieces.append((l,h,r))
    else:
        m=(l+h)/2;length=(rho*((h-l)/2).sin()).asin()
        assert 0<length<(h-l)/2
        pieces.extend([(l,m-length,A('-.5')),(m-length,m+length,A('.5')),(m+length,h,A('-.5'))])
rows=[];a=center;b=A(0)
for l,r,f in pieces:
    sl,cl=l.sin_cos();sr,cr=r.sin_cos()
    rows.append([a-f*cl,b-f*sl,f]);a+=f*(cr-cl);b+=f*(sr-sl)
def calc(q,d=False):
    s,c=q.sin_cos();out=[]
    for (l,r,_),(a,b,f) in zip(pieces,rows):
        if not (q<l or q>r):out.append(-a*s+b*c if d else a*c+b*s+f)
    assert out
    ret=out[0]
    for v in out[1:]:ret=ret.union(v)
    return ret
def support(n):
    th=arb.atan2(n[1],n[0])/U-30
    while th>180:th-=360
    while th< -180:th+=360
    q=abs(th);sg=1
    if q>90:q=180-q;sg=-1
    assert q>0 and q<90
    return A('.5')+sg*calc(q*U)
root=[]
for i in range(3000):
    t=upperbox(F(i,100),F(i+1,100))*U
    if i<50:v=-calc(30*U-t,True)-calc(30*U+t,True)+calc(90*U-t,True)
    else:v=calc(30*U-t)-calc(30*U+t)-calc(90*U-t)
    assert v<0,(i,v)
    root.append(v.upper())
def back(j,n):return rad(n,-A(j)*arb.pi()/3)
remaining=[]
for j,i in [(0,5),(1,5),(3,3),(4,3),(5,3)]:
    n=av(dt['m'][i]);v=support(back(j,n))-A('.5');remaining.append(str(v.lower()))
ar=[]
for j in range(512):
    al=upperbox(F('-.002')+F(j,128000),F('-.002')+F(j+1,128000));n=rad(N,al)
    ar.append((support(back(2,n))-(dot(n,M)-A('.00093'))).lower())
m=min(min(arb(t).lower() for t in remaining),min(ar));assert m>A('.00034')
s=[int(f>0) for l,r,f in pieces];ring=s+[1-v for v in s[::-1]]+[1-v for v in s]+s[::-1]
arcs=sum(ring[i] and not ring[i-1] for i in range(len(ring)))
out=dict(unit_circle_arcs=arcs,cap_excess=remaining,EH_excess_minimum=str(min(ar)),root_derivative_max=str(max(root[:50])),root_max=str(max(root[50:])),unit_binary_intervals=[(str(l),str(r)) for l,r,v in pieces if v>0])
(D0/'binary.json').write_text(json.dumps(out,indent=2)+'\n');print(arcs,m,flush=True)

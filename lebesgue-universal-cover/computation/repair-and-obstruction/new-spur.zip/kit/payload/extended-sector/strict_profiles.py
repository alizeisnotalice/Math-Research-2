from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0.parent))
from candidate import *
deg=arb.pi()/180
def sc(t):return (t*deg).sin_cos()
class Body:
    def __init__(self,spec):
        self.kind=int(spec['root_sign']);self.turn=F(spec['turn'])
        data=list(map(F,spec['values']));nb=len(data);step=F(90,nb)
        self.br=[j*step for j in range(nb+1)]
        q=[A(v) for v in data];ix=spec['solved']
        z=[sc(A(r))[0]-sc(A(l))[0] for l,r in zip(self.br,self.br[1:])]
        q[ix]=-sum(z[i]*q[i] for i in range(nb) if i!=ix)/z[ix]
        assert all(v>=A(F(-1,2)) and v<=A(F(1,2)) for v in q)
        self.q=q;self.step=step;self.rows=[]
        a=b=A(0)
        for l,r,f in zip(self.br,self.br[1:],q):
            sl,cl=sc(A(l));sr,cr=sc(A(r));self.rows.append([a-f*cl,b-f*sl,f])
            a+=f*(cr-cl);b+=f*(sr-sl)
        center=-self.val(F(30))[0]/sc(A(30))[1]
        for row in self.rows:row[0]+=center
        assert self.val(F(90))[0].contains(0) and self.val(F(30))[0].contains(0)
    def row(self,t):return self.rows[min(len(self.rows)-1,int(t//self.step))]
    def val(self,t):
        a,b,c=self.row(t);s,k=sc(A(t))
        return a*k+b*s+c,-a*s+b*k
    def dir(self,theta):
        h=(theta-self.turn-30+180)%360-180;ratio=(1 if h>=0 else -1);q=abs(h);sg=1
        if q>90:q=180-q;sg=-1;ratio=-ratio
        g,dp=self.val(q)
        return A(F(1,2))+sg*g,sg*ratio*dp
    def point(self,theta):
        h,hp=self.dir(theta);s,c=sc(A(theta));return (h*c-hp*s,h*s+hp*c)
    def root_check(self):
        ends=sorted(set([F(0),F(30)]+[t for v in self.br for t in (30-v,v-30,90-v) if 0<=t<=30]))
        maxF=lo= A(-1);maxder=A(-1)
        for l,r in zip(ends,ends[1:]):
            m=(l+r)/2;arr=[]
            for of,sg in [(30,-1),(30,1),(90,-1)]:
                a,b,c=self.row(of+sg*m);s,k=sc(A(of))
                arr.append((a*k+b*s,sg*(b*k-a*s),c))
            a,b,c=[self.kind*(p-q-r0) for p,q,r0 in zip(*arr)]
            count=int((r-l)*100)
            for j in range(count):
                al=upperbox(l+(r-l)*F(j,count),l+(r-l)*F(j+1,count));s,k=sc(al)
                if l==0 and j<min(count,50):
                    v=-a*s+b*k;maxder=max(maxder,v.upper())
                else:v=a*k+b*s+c;maxF=max(maxF,v.upper())
                assert v<0,(l,r,j,str(v),self.kind)
        return str(maxder),str(maxF)
    def exclude(self,active):
        rows=[]
        for j,ww in active:
            theta=F(180 if ww==0 else 300)+F('31.54')-j*60+self.turn
            v=self.dir(theta)[0]-A(F(1,2));assert v>0
            rows.append(str(v.lower()))
        assert sorted(j for j,l in active)==[j for j in range(6) if j*60!=self.turn]
        return rows

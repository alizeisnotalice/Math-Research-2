from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from cert_area import *
sys.path.insert(0,str(D0/'lenses'));sys.path.insert(0,str(C))
from deformed_reuleaux_support import body
env=ns
w,e0=F(241,400),F(-22,1125);true,_=body(env,A(w),A(e0));ed=[sub(true[i],true[j]) for i,j in ns['orders']]
def facets(lines):
    polar=convex(lines,lambda r:(F(r[0],r[2]),F(r[1],r[2])))
    vv=[]
    for (a,b,c),(d,e,f) in zip(polar,polar[1:]+polar[:1]):
        k=a*e-b*d;assert k>0
        vv.append((A(F(c*e-b*f,k)),A(F(a*f-c*d,k))))
    return vv
def intpt(v):
    eps=A(F(1,10**10));s=10**13;old=mul(1-eps,v);q=tuple(round(float(p)*s) for p in old)
    assert norm(sub(av(tuple(F(p,s) for p in q)),old))<eps/2
    return q
def lower(vv):
    hull=convex([intpt(x) for x in vv],lambda z:z)
    area=F(sum(a*d-b*c for (a,b),(c,d) in zip(hull,hull[1:]+hull[:1])),2*10**26)
    return area
basepoints=facets(inner);srcpoints=[]
for j in range(1000):
    th=arb.pi()*A(F(2*j+1,1000));n=rad((A(1),A(0)),th);sg=[cross(t,n) for t in ed]
    modes=[ns['sector'][k] for k in range(10) if sg[k]>0 and sg[(k+1)%10]<0]
    if len(modes)==1:
        i,r=modes[0];srcpoints.append(add(true[i],mul(r,n)))
a,b=[lower(basepoints+points) for points in (srcpoints,[refl(x) for x in srcpoints])]
out=dict(count=len(srcpoints),identity_lower=str(a),QA_lower=str(b),display=[float(a),float(b)],gap=str(min(a,b)-F('0.844082046521218581802948589770767704354')))
(D0/'repair-lower.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)

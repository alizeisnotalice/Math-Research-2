from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0.parent))
from inner_grid import *
W0=json.loads((D0/'params.json').read_bytes());z=pt('z');t=pt('t')
u=unit(sub(t,z));nu=J(u)
spur=add(add(z,mul(A(F(W0['r'])),sub(t,z))),mul(A(F(W0['d'])),nu))
apex=peak(F(W0['lambda_Y']))
assert all(dot(v,av(n))<A('.5') for v in [spur,apex] for n in list(dt['n'])+[dt['m'][3],dt['m'][5]])
walls=[]
for row in W0['walls']:
    alpha=A(F(row['degrees']))*arb.pi()/180
    walls.append((rad((A(1),A(0)),alpha),A(F(row['offset']))))
def grid2():
    v,l=grid();return v+[spur],l+['spur']

from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;src=D0.parent;sys.path[:0]=[str(D0),str(src)]
from spur import *
def read(p):return json.loads(p.read_bytes())
sel=W0;V,names=grid2();ids=sel['hull_indices'];assert len(set(ids))==len(ids)
v=[V[i] for i in ids];labels=[names[i] for i in ids];hits=[]
hexnames={('b1','q'):1,('p','f1'):2,('f1','h'):3,('e3','d1'):4,('d1','g'):5,('c3','b1'):0}
nonhex=[]
for i,p in enumerate(v):
    q,r=v[(i+1)%len(v)],v[(i+2)%len(v)];assert cross(p,q)>0 and cross(sub(q,p),sub(r,q))>0
    n=unit(mul(-1,J(sub(q,p))));key=(labels[i],labels[(i+1)%len(v)])
    if key in hexnames:hits.append(hexnames[key]);continue
    nonhex.append((n,dot(n,p),str(key)))
assert sorted(hits)==list(range(6)) and sum(p[1]<0<q[1] and p[0]>0 and q[0]>0 for p,q in zip(v,v[1:]+v[:1]))==1
nonhex += [(n,h,'new '+str(i)) for i,(n,h) in enumerate(walls)]
source=(D/'shared.py').read_text().split('vxlist=[]')[0];old={'__file__':str(D/'shared.py'),'__name__':'historical'}
exec(compile(source.replace("'1.54','2','1'","'1.5497','2','1'"),'local old','exec'),old)
on=old['ns'];oldposes=read(D/'legacy-150-poses.json')['poses']
specs=[(r['index'],F(r['w']),F(r['e'])) for r in oldposes if 'w' in r]+[(150,F('.7982907'),F('.032688')),(151,F('1.2'),F('.08464386'))]
raw=[]
for ident,w,e0 in specs:
    l,t=on['chart'](add(on['z'],mul(A(w),on['D'])));p=on['psi'](l);t-=A(e0)
    vv=[add(on['l0'],mul(l,on['el'])),refl(add(on['l0'],mul(p,on['el']))),refl(on['X'](p,-t)),add(on['mid'],mul(t,on['en'])),on['X'](l,t)]
    raw.append((ident,vv))
raw.extend([(160+i,list(v0)) for i,(v0,_) in enumerate(vxlist)])
def back(j,s,n):return ns['rotate']((n[0],s*n[1]),ns['trig'](A(-60*j)))
nodes={};out=[]
for w,j,s in W0['choices']:
    tag=w if w<117 or w>=160 else w+33
    if w>=160:ident,vv=raw[119+w-160]
    else:ident,vv=raw[w]
    assert tag==ident
    ed=[sub(vv[i],vv[k]) for i,k in ns['orders']]
    assert all(dot(e,e).contains(1) for e in ed) and all(cross(ed[k],ed[(k+1)%10])>0 for k in range(10))
    assert all(dot(sub(vv[i],vv[k]),sub(vv[i],vv[k]))<1 for i in range(5) for k in range(i) if (i,k) not in ns['orders'])
    def modes(n):
        sg=[cross(e,n) for e in ed]
        return [ns['sector'][k] for k in range(10) if not sg[k]<0 and not sg[(k+1)%10]>0]
    for n,m in zip(dt['n'],[(1,1),(3,1),(0,1),(1,0),(3,0),(0,0)]):assert modes(av(n))==[m]
    po=j,s
    if po not in nodes:nodes[po]=[(back(j,s,n),h,label) for n,h,label in nonhex]
    minimum=A(1);weak=None
    for n,h,name in nodes[po]:
        active=modes(n);assert active;g=(h-max((dot(vv[i],n)+r).upper() for i,r in active)).lower();assert g>0,(ident,po,name,g)
        if g<minimum:minimum=g;weak=name
    out.append(dict(id=ident,pose=[60*j,s],minimum=str(minimum),weak=weak))
(D0/'five-inputs.json').write_text(json.dumps(out,indent=2)+'\n');print('pentagons',len(out),min(arb(r['minimum']).lower() for r in out),flush=True)

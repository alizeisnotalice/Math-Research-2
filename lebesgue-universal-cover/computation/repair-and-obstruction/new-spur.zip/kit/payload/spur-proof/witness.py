from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from spur import *
sys.path.insert(0,str(D0/'lenses'));sys.path.insert(0,str(C))
from certify_nonideal_pentagon_pose_library import verify
from deformed_reuleaux_support import body
env=ns.copy();env['n0']=av(dt['n'][0]);aa=(C/'certify_ah_two_line_cap.py').read_text()
exec(compile(aa[aa.index('def F_at('):aa.index('def placement(')],'true F_at','exec'),env)
w,e=F(241,400),-F(22,1125);rw,re=F('.0000001'),F('.00000001')
def run(rw,re):
    root=verify(env,w,e,rw,re)
    verts,sup=body(env,upperbox(w-rw,w+rw),upperbox(e-re,e+re))
    data=[]
    for name,theta,transform in [('I',F('111.6'),lambda v:v),('QA',F(117),refl)]:
        j=next(i for i,s in enumerate(W0['walls']) if F(s['degrees'])==theta);n,h=walls[j]
        excess=(sup(transform(n))-h-A('.00000001')).lower()
        assert excess>0
        data.append(dict(pose=name,normal=str(theta),largest_host_offset=str(F(W0['walls'][j]['offset'])+F('.00000001')),excess_lower=str(excess)))
    return dict(root=root,hard=data)
res=run(rw,re);(D0/'witness.json').write_text(json.dumps(res,indent=2)+'\n')
print(res['hard'],flush=True)

from pathlib import Path
import sys
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from spur import *
source=(D0/'cert_area.py').read_text()
pre,post=source.split('S=10**13')
source=pre+"""
# Maximizing the three independent family parameters supplies the common upper bound.
spur=add(add(z,mul(A('.43'),sub(t,z))),mul(A('.000061'),nu))
apex=peak(F('.0051'))
walls=[(n,b+A('.00000001')) for n,b in walls]
assert all(dot(v,av(n))<A('.5') for v in [spur,apex] for n in list(dt['n'])+[dt['m'][3],dt['m'][5]])
S=10**13"""+post.split('L=[]')[0]+"""
B=F('0.844082046521218581802948589770767704354')
hi=areabound(outer,True);lo=F(json.loads((D0/'area.json').read_text())['area_lower'])
assert lo<hi<B
result=dict(lambda_interval=['.005','.0051'],spur_depth=['.00006','.000061'],common_offset_addition=['0','.00000001'],area_lower=str(lo),area_upper=str(hi),display=[float(lo),float(hi)],B_gap=str(B-hi))
(D0/'family.json').write_text(json.dumps(result,indent=2)+'\\n');print(result['display'],float(B-hi),flush=True)
"""
exec(compile(source,str(D0/'cert_area.py'),'exec'))

from pathlib import Path
import sys,json
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from spur import *
S=10**13
def to_face(n,b,outer):
    x,y=[round(float(v)*S) for v in n];diff=abs(n[0]-A(F(x,S)))+abs(n[1]-A(F(y,S)))
    h=((b+diff)*S).upper().ceil() if outer else ((b-diff)*S).lower().floor()
    return x,y,int(h.unique_fmpz())
def get(k):return refl(ns['points'](A(1))[0][2]) if k=='tp' else pt(k)
outer=[]
def support(n,h):
    h=max(h.upper(),dot(n,spur).upper(),dot(n,apex).upper());outer.append(to_face(n,h,True))
for a,b in [('b1','q'),('t','z'),('p','f1'),('f1','h'),('u','t_eh'),('ip','e3'),('e3','d1'),('d1','g'),('k','c3'),('c3','b1')]:
    p=get(a);n=unit(mul(-1,J(sub(get(b),p))));support(n,dot(n,p))
for a,b,ctr in [('q','y','e3'),('y','t','c'),('tp','p','g'),('h','u','c3'),('t_eh','ip','b3'),('g','k','f3')]:
    c=get(ctr);u,v=sub(get(a),c),sub(get(b),c)
    assert cross(u,v)>0 and dot(u,v)>0
    for i in range(201):
        n=unit(add(u,mul(A(F(i,200)),sub(v,u))));support(n,1+dot(c,n))
for i in range(513):
    p,v=ns['point_jets'](A(F(i,512)));x=refl(p[2]);n=unit(mul(-1,J(refl(v[2]))));support(n,dot(n,x))
outer.extend(to_face(n,h,True) for n,h in walls)
def convex(items,key):
    points=sorted(set(items),key=key)
    def section(p):
        out=[]
        for x in p:
            while len(out)>1:
                a,b=map(key,out[-2:]);c=key(x)
                if (b[0]-a[0])*(c[1]-a[1])>(b[1]-a[1])*(c[0]-a[0]):break
                out.pop()
            out.append(x)
        return out[:-1]
    return section(points)+section(reversed(points))
def areabound(plane,up):
    assert all(r[2]>0 for r in plane)
    polar=convex(plane,lambda r:(F(r[0],r[2]),F(r[1],r[2])))
    v=[]
    for (a,b,c),(d,e,f) in zip(polar,polar[1:]+polar[:1]):
        det=a*e-b*d;assert det>0
        v.append((F(c*e-b*f,det),F(a*f-c*d,det)))
    # Each rational vertex enclosed with common denominator, with explicit determinant error.
    P=10**17
    vv=[(int(x*P),int(y*P)) for x,y in v]
    assert all(abs(x)<1 and abs(y)<1 for x,y in v)
    exact=sum(x[0]*y[1]-x[1]*y[0] for x,y in zip(vv,vv[1:]+vv[:1]))
    # For |x|,|y|<1, rounding both determinants contributes <4/P per edge.
    err=F(2*len(vv),P)
    return F(exact,2*P**2)+(err if up else -err)
L=[]
for p in grid2()[0]:
    q=[round(float(t)*(1-1e-10)*S) for t in p]
    err=sub(tuple(A(F(v,S)) for v in q),mul(A(1)-A(F(1,10**10)),p))
    assert norm(err)<A(F(1,2*10**10))
    L.append(tuple(q))
inside=convex(L,lambda p:p);inner=[]
for p,q in zip(inside,inside[1:]+inside[:1]):
    a=q[1]-p[1];b=p[0]-q[0];c=a*p[0]+b*p[1];inner.append((a*S,b*S,c))
inner.extend(to_face(n,h,False) for n,h in walls)
lo,hi=areabound(inner,False),areabound(outer,True)
B=F('0.844082046521218581802948589770767704354');assert lo<hi<B
out=dict(area_lower=str(lo),area_upper=str(hi),display=[float(lo),float(hi)],B_gap=str(B-hi),supporting_lines=len(outer),inscribed_vertices=len(inside))
(D0/'area.json').write_text(json.dumps(out,indent=2)+'\n');print(out['display'],float(B-hi),flush=True)

from pathlib import Path
import sys,json
D0=Path(__file__).resolve().parent;src=D0.parent;sys.path[:0]=[str(D0),str(src)]
from spur import *
src=D0.parent
oldz=src/'legacy_profiles.py'
g={'__file__':str(oldz)};exec(compile(oldz.read_text().split('out=[]')[0],str(oldz),'exec'),g)
oldposes=json.loads((src/'legacy-150-poses.json').read_bytes())['poses']
profile={r['index']:r for r in json.loads((src/'profile-cert.json').read_bytes())['rows']}
old=[]
for r in oldposes:
    idx=r['index']
    if idx not in profile:continue
    cert=profile[idx]['passed'];po=tuple(cert['pose']) if cert else (240,1)
    if r['source']==g['mirror_source']:h=g['mir' if r['body_index']==0 else 'pol'].support_direction
    else:h=g['Profile'](json.loads((src/'profile-source'/r['source']).read_bytes())[r['body_index']]).support
    gaps=[]
    for n,b in walls:gaps.append((b-h(g['preimage'](*po,n))).lower())
    assert all(t>0 for t in gaps),(idx,min(gaps));old.append((idx,po,str(min(gaps))))
# All selected genuine non-binary bodies have a unique pose inside G since G is universal and G obeys H,m3,m5.
family=src/'extended-sector'
if not family.is_dir():family=src/'force'
sys.path.insert(0,str(family));from strict_profiles import Body
sp=json.loads((family/'strict-seeds.json').read_bytes());br={}
def binary_h(body,theta):
    angle=(theta-body.turn-30+180)%360-180;q=abs(angle);sg=1
    if q>90:q=180-q;sg=-1
    old=body.dir(theta)[0];w=(q*8)%1
    if not w:return old
    rho=body.q[int(q)] + A('.5')
    if rho==0 or rho==1:return old
    step=arb.pi()/1440;t=A(w)*step;m=step/2;v=(rho*m.sin()).asin();left=m-v;right=m+v
    change=-rho*(1-t.cos())
    if t>left:
        end=t if t<right else right
        assert t<right or t>right
        change+=(t-end).cos()-(t-left).cos()
    else:assert t<left
    return old+sg*change
single=src/'forced-sector'/'strict-seeds.json'
groups=[('two',sp),('one',json.loads(single.read_bytes()))]
for familykey,config in groups:
    for k,r in config['profiles'].items():
        body=Body(r);vv=[];vb=[]
        bounds=body.root_check();losses=body.exclude(r['active']);delta=arb.pi()/1440
        assert arb(bounds[0])+3*delta<0 and arb(bounds[1])+3*delta**2/2<0
        assert min(arb(g).lower() for g in losses)>delta**2/2
        for (n,b),row in zip(walls,W0['walls']):
            ang=F(row['degrees'])
            vv.append((b-body.dir(ang)[0]).lower());vb.append((b-binary_h(body,ang)).lower())
        assert min(vv)>0 and min(vb)>0,(familykey,k,min(vv),min(vb))
        br[familykey+'-'+k]=[str(min(vv)),str(min(vb))]
# Mirror19 uses identical normalization and the same 120-degree unique pose as its seven-piece source.
q=src/'mirror-lp'
if not q.is_dir():q=src/'m19'
env={'__file__':str(q/'certify.py')};cs=(q/'certify.py').read_text();exec(compile(cs.split('knots=')[0]+cs[cs.index('def hvec('):cs.index('angles=[]')],str(q/'certify.py'),'exec'),env)
mm=[(b-env['hvec'](env['back'](2,n))).lower() for n,b in walls]
bn={'__file__':str(q/'binary.py')};bb=(q/'binary.py').read_text().split('root=[]')[0];exec(compile(bb,str(q/'binary.py'),'exec'),bn)
bi=[(b-bn['support'](env['back'](2,n))).lower() for n,b in walls]
assert min(mm)>0 and min(bi)>0,(min(mm),min(bi))
out=dict(historical_profiles=old,forced_mirror_continuous_and_binary=br,mirror_seven=str(min(mm)),mirror_Reuleaux19=str(min(bi)))
(D0/'other-inputs.json').write_text(json.dumps(out,indent=2)+'\n');print(len(old),len(br),min(mm),min(bi),flush=True)

from pathlib import Path
import sys,json
D0=Path(__file__).resolve().parent;sys.path.insert(0,str(D0))
from spur import *
comp=C;sub=D0/'lenses';sys.path[:0]=[str(sub),str(comp)]
z=sub/'certify_P_forced_hull_outer.py'
source=z.read_text().split('    # The integer directions')[0]
env={'__file__':str(z)};exec(compile(source+'    return defs,candidates,inside,g\n',str(z),'exec'),env)
defs,cand,inside,g=env['run'](comp,F('1.54'),F('1.54'))
out=[]
for nr,(n,b) in enumerate(walls):
    rec={}
    for name,centers in defs.items():
        vals=[g.dot(n,v).upper() for v in cand[name]]
        for v in centers:
            if inside(g.plus(v,n),centers):vals.append(1+g.dot(n,v).upper())
        margin=(b-max(vals)).lower();assert margin>0,(nr,name,margin);rec[name]=str(margin)
    disk=(b-A('.5')).lower();assert disk>=0;rec['disk']=str(disk);out.append(rec)
(D0/'lenses.json').write_text(json.dumps(out,indent=2)+'\n');print(len(out),'joint lens walls')

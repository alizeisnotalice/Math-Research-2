"""Additional explicit angular-order checks for R276 two-window formulas."""
import sys,json
from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import bind_geometry
sys.path.insert(0,str(P/'result'));import candidate as g
ctx.prec=192;A=g.A;L=A(F('31.54'))*arb.pi()/180;den=g.cross(g.n3,g.m3)
minima=[arb(1)]*4
for j in range(4096):
 lo=F(-1,500)+F(j,250*4096);hi=lo+F(1,250*4096);n=g.rad(g.N,g.upperbox(lo,hi))
 a=g.cross(n,g.m3)/den;b=g.cross(g.n3,n)/den;H=(a+b)/2-g.dot(n,g.M)+A(F('.00094'));x=(b*den).asin();ra=(1-H/a).acos();rb=(1-H/b).acos()
 vals=[L-ra-rb-x,L-2*ra-x,L/2-rb,b*(L-ra).sin()-a*ra.sin()]
 for i,z in enumerate(vals):
  assert z>0,(j,i,str(z));minima[i]=min(minima[i],z.lower())
out={'cells':4096,'same_pair_overlap_after_peak_lower':str(minima[0]),'big_slope_overlap_after_peak_lower':str(minima[1]),'small_slope_rb_below_L_half_lower':str(minima[2]),'big_slope_endpoint_comparison_lower':str(minima[3])}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

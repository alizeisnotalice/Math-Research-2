"""Bind all extracted geometry files used in replay to fixed published archive."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from io import BytesIO
P=Path(__file__).resolve().parent
sha='85f97ce9a5a4a301b9ab1b95ebe7b0fbc853f4d00855c4ae3f691fec5bcdb1a1'
z=P/'base.zip';assert sha256(z.read_bytes()).hexdigest()==sha
with ZipFile(z) as top:
 for name in ('candidate.py','shared.py'):
  assert (P/'result'/name).read_bytes()==top.read('kit/'+name)
 with ZipFile(BytesIO(top.read('kit/obstruction.zip'))) as inner:
  for name in inner.namelist():
   if name.startswith('barrier/comp068/') and not name.endswith('/'):
    assert (P/'result'/Path(name).relative_to('barrier')).read_bytes()==inner.read(name),name

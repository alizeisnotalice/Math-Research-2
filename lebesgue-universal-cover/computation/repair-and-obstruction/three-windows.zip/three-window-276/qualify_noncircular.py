"""Directed obstructions to the previously certified near-disk / near-C3 classes."""
import sys,json
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=192
A=lambda x:arb(F(x).numerator)/F(x).denominator
P=Path(__file__).resolve().parent;coef=list(map(A,['.000070','-.001302','-.000216','.002']))
def det(a,b):return a[0]*b[1]-a[1]*b[0]
U=[];f=[]
for j in (125,238,542):
 theta=arb.pi()*j/360;sn,co=theta.sin_cos();U.append((co,sn))
 s5,c5=(5*theta).sin_cos();s7,c7=(7*theta).sin_cos();f.append(coef[0]*c5+coef[1]*s5+coef[2]*c7+coef[3]*s7)
d=[det(U[1],U[2]),det(U[2],U[0]),det(U[0],U[1])];assert all(z>0 for z in d);S=sum(d);weights=[z/S for z in d];assert all(w>0 for w in weights)
low=(sum(w*z for w,z in zip(weights,f,strict=True))).lower();assert low>A(F(295,100000))
amp5=(coef[0]**2+coef[1]**2).sqrt()/2
amp7=(coef[2]**2+coef[3]**2).sqrt()/2
assert amp5>A(F(179273719,10**12)) and amp7>A(F(179273719,10**12))
out={'directions_degrees':['125/2','119','271'],'weights':[str(w) for w in weights],'distance_to_any_translated_radius_half_disk_lower':str(low),'five_harmonic_amplitude_half_lower':str(amp5.lower()),'seven_harmonic_amplitude_half_lower':str(amp7.lower()),'scope':'lower bounds hold under arbitrary translations and rotations of the comparison disk or Ck symmetric body, respectively'}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

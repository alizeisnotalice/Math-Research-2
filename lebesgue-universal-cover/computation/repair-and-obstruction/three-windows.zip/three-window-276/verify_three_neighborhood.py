"""Three-window conditional bound uniformly over alpha and relative shifts."""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import bind_geometry
sys.path.insert(0,str(P/'result'));import candidate as g
ctx.prec=192;A=g.A;L=A(F('31.54'))*arb.pi()/180;den=g.cross(g.n3,g.m3)
N=4096;M=128;up=F(11,20);du=up/N
left=A(F('-351/1000')).union(A(F('-349/1000')))
right=A(F('349/1000')).union(A(F('351/1000')))
worst=None;maxpair=None;rows=[]
for j in range(M):
 al=F(-1,500)+F(j,250*M);ah=al+F(1,250*M);n=g.rad(g.N,g.upperbox(al,ah))
 a=g.cross(n,g.m3)/den;b=g.cross(g.n3,n)/den
 C=((g.m3[1]-g.n3[1])/(2*den)-g.M[0],(g.n3[0]-g.m3[0])/(2*den)-g.M[1]);H=g.dot(n,C)+A(F('.00094'))
 x=(b*den).asin();assert 0<x<L/2 and a>b>H>0
 pair=L-(1-H/a).acos()-(1-H/b).acos();assert A(F('349/1000'))>pair
 def kbox(t):
  if not (t>0 and t<L):return arb(0)
  return min((a*t.sin()).lower(),(b*(L-t).sin()).lower())
 total=arb(0)
 for i in range(N):
  t=A(i*du).union(A((i+1)*du));kc=kbox(t);ko=(kbox(t-left)+kbox(t-right))/2
  z=min(kc/2,ko/2);assert z>=0;total+=A(du)*z
 margin=(total-H).lower();assert margin>A(F(1,20000)),(j,str(margin))
 worst=margin if worst is None else min(worst,margin);maxpair=pair.upper() if maxpair is None else max(maxpair,pair.upper())
 rows.append({'alpha':[str(al),str(ah)],'margin_lower':str(margin)})
out={'alpha_range':['-1/500','1/500'],'left_shift':['-351/1000','-349/1000'],'right_shift':['349/1000','351/1000'],'weights':['1/4','1/2','1/4'],'alpha_cells':M,'integration_cells':N,'margin_lower':str(worst),'max_two_window_threshold':str(maxpair),'rows':rows,'scope':'conditional three actual same-input Gibbs placements; no compatibility or common-root claim','base_zip_sha256':hashlib.sha256((P/'base.zip').read_bytes()).hexdigest()}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))

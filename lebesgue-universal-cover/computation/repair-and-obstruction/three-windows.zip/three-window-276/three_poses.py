"""Certify three actual Gibbs placements of a non-C3 width-one body."""
import json,sys
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).resolve().parent;sys.path[:0]=[str(P),str(P/'result')]
import bind_geometry
from shared import *
ctx.prec=192
inv=ns['perp'];cross=ns['cross'];one=A(1);half=A(F(1,2));zero=A(0)
def norm(v):return dot(v,v).sqrt()
def unit(v):return mul(1/norm(v),v)
def get(k):return refl(ns['points'](one)[0][2]) if k=='tp' else pt(k)
hexs=list(map(av,dt['n']))
coef=[A(F('0.00000035')),A(F('-0.00000651')),A(F('-0.00000108')),A(F('0.000010'))]
assert sum((n*n-1)*(abs(coef[2*j])+abs(coef[2*j+1])) for j,n in enumerate((5,7)))<half

def harm(U,c,s):
 ux,uy=U;cx=ux*c+uy*s;sy=uy*c-ux*s;z=one;y=zero;f=zero;fp=zero
 for j in range(1,8):
  z,y=z*cx-y*sy,y*cx+z*sy
  if j in (5,7):
   k=0 if j==5 else 2;p,q=coef[k:k+2]
   f+=p*z+q*y;fp+=j*(-p*y+q*z)
 return f,fp

def pose(theta):
 s,c=theta.sin_cos();f0,_=harm(hexs[0],c,s);f1,_=harm(hexs[1],c,s)
 tx=-f0;ty=(-f1-hexs[1][0]*tx)/hexs[1][1];return c,s,(tx,ty)
def h(U,pos):
 c,s,t=pos;f,_=harm(U,c,s);return half+f+dot(t,U)
def hp(U,pos):
 c,s,t=pos;_,fp=harm(U,c,s);return fp+dot(t,inv(U))
def pin(U):return any(all((U[j]-v[j]).contains(0) for j in (0,1)) for v in hexs)
# For harmonics 5 and 7, restrictions to six θ=jπ/3 are first harmonics;
# hence the two imposed equalities analytically force h(n_j)=1/2 for all j.
arcs=[('q','y','e3'),('y','t','c'),('tp','p','g'),('h','u','c3'),('t_eh','ip','b3'),('g','k','f3')]
poses=[-A(F(7,20)),A(F(7,20)),arb.pi()];out=[]
for theta in poses:
 pos=pose(theta);arcminimum=one;pin_count=0
 for first,last,ctr in arcs:
  center=get(ctr);u0=sub(get(first),center);u1=sub(get(last),center)
  assert cross(u0,u1)>0 and dot(u0,u1)>0
  def un(v):return unit(add(u0,mul(v,sub(u1,u0))))
  N=128
  for j in range(N):
   U=un(ns['box'](F(j,N),F(j+1,N)))
   gap=one+dot(center,U)-h(U,pos)
   if gap>0:arcminimum=min(arcminimum,gap.lower());continue
   grad=dot(center,inv(U))-hp(U,pos)
   if grad>0:
    E=un(A(F(j,N))); eg=one+dot(center,E)-h(E,pos)
    if eg>0:arcminimum=min(arcminimum,eg.lower());continue
    if j==0 and pin(E):pin_count+=1;continue
   if grad<0:
    E=un(A(F(j+1,N))); eg=one+dot(center,E)-h(E,pos)
    if eg>0:arcminimum=min(arcminimum,eg.lower());continue
    if j==N-1 and pin(E):pin_count+=1;continue
   raise AssertionError(('arc',str(theta),first,last,j,str(gap),str(grad)))
 # A support bound for every chord of an inscribed polygon proves containment.
 def paired(w):return refl(ns['points'](A(w))[0][2])
 prev=paired(F(0));pairminimum=one
 for j in range(1,1025):
  nxt=paired(F(j,1024));U=unit(mul(-1,inv(sub(nxt,prev))));gap=dot(U,prev)-h(U,pos);assert gap>0,('pair',j,str(gap));pairminimum=min(pairminimum,gap.lower());prev=nxt
 flatminimum=one
 for a,b,kind in [('b1','q','H'),('t','z','n0'),('p','f1','H'),('f1','h','H'),('u','t_eh','EH'),('ip','e3','m3'),('e3','d1','H'),('d1','g','H'),('k','c3','m5'),('c3','b1','H')]:
  v=get(a);U=unit(mul(-1,inv(sub(get(b),v))))
  if kind=='H':assert pin(U);continue
  gap=dot(U,v)-h(U,pos);assert gap>0,('edge',a,b,str(gap));flatminimum=min(flatminimum,gap.lower())
 out.append(dict(angle=str(theta),translation=[str(v) for v in pos[2]],arc_lower=str(arcminimum),hex_pin_intervals=pin_count,paired_chord_lower=str(pairminimum),nonhex_edge_lower=str(flatminimum)))
 print(out[-1],flush=True)
Path(sys.argv[1]).write_text(json.dumps({'coefficients':['0.00000035','-0.00000651','-0.00000108','0.000010'],'support':'1/2 + a5 cos5t + b5 sin5t + a7 cos7t + b7 sin7t','poses':out,'scope':'three actual poses of one non-C3 width-one input in original Gibbs G; no common-root claim'},indent=2)+'\n')

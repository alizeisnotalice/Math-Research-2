"""True Green areas of the released AH vertex and the moved true EH chord."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,subprocess,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from shared import *
ctx.prec=160
A=ns['A'];cross=ns['cross'];J=ns['perp']
def norm(v):return dot(v,v).sqrt()
def unit(v):return mul(1/norm(v),v)
def rad(v,a):return add(mul(a.cos(),v),mul(a.sin(),J(v)))
def line_inter(u,v,h,k):
    z=cross(u,v)
    return ((h*v[1]-k*u[1])/z,(k*u[0]-h*v[0])/z)
def arc(a,b,c,orig):
    v,w=sub(a,c),sub(b,c)
    assert cross(v,w)>0 and dot(v,w)>0
    return cross(sub(c,orig),sub(b,a))+(cross(v,w)/dot(v,w)).atan()
def dec(x,n=22):
    t=(x*A(10**n))
    return [str(F(int(t.lower().floor().unique_fmpz()),10**n)),str(F(int(t.upper().ceil().unique_fmpz()),10**n))]
u,te=pt('u'),pt('t_eh')
M=mul(A(F(1,2)),add(u,te));N=unit(mul(-1,J(sub(te,u))))
n3=av(dt['n'][3]);m3=av(dt['m'][3])
def EH(alpha,eta):
    no=rad(N,alpha);co=dot(no,M)-eta
    a=line_inter(n3,no,A(F(1,2)),co)
    assert pt('h')[1]<a[1]<pt('f1')[1]
    ctr=pt('b3');q=co-dot(no,ctr);y=(1-q*q).sqrt()
    v0,v1=sub(te,ctr),sub(pt('ip'),ctr)
    candidates=[add(ctr,add(mul(q,no),mul(k*y,J(no)))) for k in (-1,1)]
    good=[v for v in candidates if cross(v0,sub(v,ctr))>0 and cross(sub(v,ctr),v1)>0]
    assert len(good)==1; b=good[0]
    cap=(cross(sub(a,M),sub(pt('h'),M))+arc(pt('h'),u,pt('c3'),M)+cross(sub(u,M),sub(te,M))+arc(te,b,ctr,M)+cross(sub(b,M),sub(a,M)))/2
    assert cap>0
    return cap,co,a,b
def triangle_radius(alpha,eta):
    no=rad(N,alpha);b1=A(F(1,2))-dot(n3,M);b2=A(F(1,2))-dot(m3,M)
    dc=cross(n3,m3)
    assert cross(n3,no)/dc>0 and cross(no,m3)/dc>0
    vs=[line_inter(n3,m3,b1,b2),line_inter(n3,no,b1,-eta),line_inter(m3,no,b2,-eta)]
    return max(norm(v).upper() for v in vs)
def upperbox(lo,hi):
    return ns['box'](F(lo),F(hi))
S=pt('y');top=(A(0),1/A(3).sqrt())
def peak(l):return add(S,mul(A(l),sub(top,S)))
# Root and line integral on the two-circle paired arc.  dt has Taylor order 3.
I=dt['I'];Jet=dt['Jet'];DD=dt['direction'];Z=dt['z'];pair=dt['pair'];mulI=dt['mul'];addI=dt['add'];crossI=dt['cross'];subI=dt['sub']
def curve_series(x):
    z=Jet(x);z.c[1]=I(1)
    return pair(addI(tuple(map(Jet,Z)),mulI(z,tuple(map(Jet,DD)))))
def YI(l):
    return (I(0),dt['y'][1]+I(l)*(1/dt['r3']-dt['y'][1]))
def tangent(w,Y):
    jet=curve_series(I(w));p=tuple(t.c[0] for t in jet);v=tuple(t.c[1] for t in jet)
    return crossI(v,subI(Y,p))
def density(w,Y):
    x,y=curve_series(w)
    x.c[0]=x.c[0]-Y[0];y.c[0]=y.c[0]-Y[1]
    return [sum((i+1)*(x.c[k-i]*y.c[i+1]-y.c[k-i]*x.c[i+1]) for i in range(k+1)) for k in (0,1,2)]
def integrate(w,Y):
    out=I(0)
    for k in range(32):
        l,r=w*k/32,w*(k+1)/32
        m=(l+r)/2;dx=r-l
        out+=dx*density(I(m),Y)[0]+I(dx**3/12)*density(I(l,r),Y)[2]
    return out
def release(l):
    Y=peak(l);center=pt('e3');V=sub(Y,center);a=dot(V,V);assert a>1
    vr,vy=sub(pt('q'),center),sub(S,center)
    opts=[add(center,mul(1/a,add(V,mul(k*(a-1).sqrt(),J(V))))) for k in (-1,1)]
    keep=[r for r in opts if cross(vr,sub(r,center))>0 and cross(sub(r,center),vy)>0]
    assert len(keep)==1
    right=keep[0]; y=YI(l);left=F(0);end=F('.1')
    f0,f1=tangent(left,y),tangent(end,y);sign=1 if f0.lo>0 else -1
    assert (sign*f0).lo>0 and (sign*f1).hi<0
    for _ in range(95):
        m=(left+end)/2;v=sign*tangent(m,y)
        if v.lo>0:left=m
        else:assert v.hi<0;end=m
    q=curve_series(I(left,end));pv=tuple(A(a.c[0]) for a in q);vp=tuple(A(a.c[1]) for a in q)
    assert dot(sub(Y,pv),vp)<0
    assert dot(sub(Y,right),J(sub(right,center)))>0
    unknown=(end-left)*density(I(left,end),y)[0]
    total=integrate(left,y)+I(min(F(0),unknown.lo),max(F(0),unknown.hi))
    add_area=-(arc(right,S,center,Y)+arc(S,pt('t'),pt('c'),Y)+cross(sub(pt('t'),Y),sub(pt('z'),Y))+A(total))/2
    assert add_area>0
    # The actual apex must be admitted by the six hexagon and the two Gibbs cap faces.
    assert all(dot(Y,av(n))<A(F(1,2)) for n in list(dt['n'])+[dt['m'][3],dt['m'][5]])
    normal=mul(-1,J(ns['direct']))
    exc=dot(normal,sub(Y,pt('z')))
    assert exc>A('.000018')
    return add_area,exc,dict(w=[str(left),str(end)],add_area=dec(add_area,25),AH_straight_excess=dec(exc,22),right=[str(z) for z in right],left=[str(z) for z in pv])
def run():
    # This proof only needs the fixed universal Gibbs body, not any deep AH result.
    raw=subprocess.check_output([sys.executable,'-E','-B',str(C/'certify_gibbs_area_refined.py'),'1.54','16','64'])
    G=json.loads(raw);assert G['passed'];base=upperbox(*G['area_interval'])
    (D/'gibbs-raw.json').write_bytes(raw)
    alpha=upperbox('-.002','.002');er=upperbox('.00093','.00094')
    baseline_lo=F('.000885');baseline_hi=F('.00099')
    baseline_r=triangle_radius(A(0),A(baseline_lo))
    tilted_r=max(triangle_radius(upperbox(F(-2,1000)+F(k,10000),F(-2,1000)+F(k+1,10000)),er).upper() for k in range(40))
    assert A(baseline_lo)+baseline_r*A('.002')<A('.00093')
    assert A('.00094')+tilted_r*A('.002')<A(baseline_hi)
    release_parameters=['.005','.0065','.008']; rel={};adds={}
    for s in release_parameters:
        add_,ex,rr=release(F(s));rel[s]=rr;adds[s]=add_
    # All removed EH material is located in a small ball about M. The added AH pocket lies above y=.50.
    for s,r in rel.items(): assert arb(r['left'][1])>A('.50') and arb(r['right'][1])>A('.50')
    assert M[1]+tilted_r<0 and M[1]+baseline_r<0
    lo_cap=EH(A(0),A(baseline_lo))[0];hi_cap=EH(A(0),A(baseline_hi))[0]
    B=A('.844082046521218581802948589770767704354')
    lo=base+adds['.005']-hi_cap;hi=base+adds['.008']-lo_cap
    assert hi<B
    specs=[('.005','-.002','.00093'),('.0065','.001','.000935'),('.008','.002','.00094')]
    examples=[]
    for s,a,e in specs:
        cap,height,aa,bb=EH(A(a),A(e));area=base+adds[s]-cap
        examples.append(dict(lam=s,alpha=a,eta=e,area=dec(area,25),height=str(height),EH_area=dec(cap,25),intersections=[[str(x) for x in p] for p in (aa,bb)]))
    output=dict(parameters={'lambda':['.005','.008'],'alpha':['-.002','.002'],'eta':['.00093','.00094']},area_uniform=[dec(lo,24)[0],dec(hi,24)[1]],B_gap_lower=dec(B-hi,22)[0],true_G_area=G['area_interval'],AH_release=rel,EH_sandwich=[str(baseline_lo),str(baseline_hi)],cap_radii=[str(baseline_r),str(tilted_r)],examples=examples)
    (D/'candidate-areas.json').write_text(json.dumps(output,indent=2)+'\n')
    print('uniform',float(lo),float(hi),'gap',float(B-hi),flush=True)
    for r in examples:print(r['lam'],float(F(r['area'][0])),flush=True)
if __name__=='__main__':run()

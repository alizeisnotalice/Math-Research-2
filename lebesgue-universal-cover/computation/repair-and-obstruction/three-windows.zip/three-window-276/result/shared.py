from pathlib import Path
import sys,json,math
from fractions import Fraction as F
D=Path(__file__).resolve().parent
U=D if (D/'comp068').is_dir() else D.parent/'nov19-ah014-015-central-scout';C=U/'comp068';sys.path[:0]=[str(C),str(U)]
from flint import arb,ctx
import ast
ctx.prec=160
base=C/'certify_gibbs_area_refined.py'
oldargv=sys.argv[:]
sys.argv=[str(base),'1.54','2','1']
dt={'__file__':str(base)}
exec(compile(base.read_text().split('width = F(1,cells)')[0],str(base),'exec'),dt)
sys.argv=oldargv
src=(C/'certify_ah_two_line_cap.py').read_text()
ns={'F':F,'arb':arb,'d':dt}
segments=[('def A(q):','for pivot,c in zip'),('def chart(x):','assert dot(direct,sub(z,l0))'),('angle_unit = arb.pi()/180','def F_at(')]
for start,end in segments:
    raw=src[src.index(start):src.index(end)]
    exec(compile(raw,str(C/'certify_ah_two_line_cap.py'),'exec'),ns)
parsed=ast.parse((C/'ah_root_geometry_at_angle.py').read_text())
for k,v in [('order','orders'),('sector_formula','sector')]:
    nodes=[n.value for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==k for t in n.targets)]
    ns[v]=ast.literal_eval(nodes[0])
A=ns['A'];dt=ns['d'];av=ns['av']; add,sub,mul,dot,cc,refl=[ns[k] for k in ('add','sub','mul','dot','cc','reflection')]
def pt(k):
    return av(dt[k])
def fpt(v):
    return tuple(float(p) for p in v)
vxlist=[]
for w,s in [('.3199','.008'),('.429','.00003865'),('.42952','.00000030')]:
    P=ns['points'](A(w))[0];ell,t=ns['chart'](P[4]);t+=A(s);p=ns['psi'](ell);VX=list(P)
    VX[4]=ns['X'](ell,t);VX[2]=refl(ns['X'](p,-t));VX[3]=add(ns['mid'],mul(t,ns['en']))
    V=[refl(v) for v in VX]
    vxlist.append((VX,[sub(VX[i],VX[k]) for i,k in ns['orders']]))

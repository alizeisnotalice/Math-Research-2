import json,sys,math
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from flint import arb,ctx
ctx.prec=160;A=lambda x:arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x);pi=arb.pi();T=512;M=2048
pose=json.load(open('true-best-pose.json'));z=[A(F(x,2**44)) for x in pose['center']];pp=[A(F(x)) for x in pose['point_pose']];angs=[arb(0),z[2],z[5],z[8]];trs=[(z[0],z[1]),(z[3],z[4]),(z[6],z[7]),(z[9],z[10])];raw=json.load(open('finite-point-leaf-input.json'));ps=raw['points'];den=raw['denominator'];pts=[];s,c=pp[2].sin_cos()
for x,y in ps:
 x=A(F(x,den));y=A(F(y,den));pts.append((c*x-s*y+pp[0],s*x+c*y+pp[1]))
N=[];H=[]
for i in range(T):
 theta=2*pi*i/T;s,c=theta.sin_cos();n=(c,s);N.append(n);values=[A(F(1,2))]
 for nverts,a,t in zip((3,5,7,9),angs,trs):
  verts=[]
  R=1/(2*(pi/(2*nverts)).cos())
  for k in range(nverts):
   ss,cc=(a+2*pi*k/nverts).sin_cos();verts.append((t[0]+R*cc,t[1]+R*ss))
  idx=int(round((2*math.pi*i/T-float(a.mid())-math.pi)*nverts/(2*math.pi)));d=theta-a-pi-2*pi*idx/nverts
  if abs(d)<pi/(2*nverts):
   v=verts[idx%nverts];values.append(1+n[0]*v[0]+n[1]*v[1])
  else:
   values.extend(n[0]*x+n[1]*y for x,y in verts)
   if not abs(d)>pi/(2*nverts):
    v=verts[idx%nverts];values.append(1+n[0]*v[0]+n[1]*v[1])
 values.extend(n[0]*x+n[1]*y for x,y in pts);H.append(max(x.upper() for x in values))
V=[[arb(q) for q in v] for v in json.load(open('spur-vertices.json'))];nf=np.array([[float(a.mid()),float(b.mid())] for a,b in N]);hf=np.array([float(a.upper()) for a in H]);vf=np.array([[float(a.mid()),float(b.mid())] for a,b in V]);
def det(x,y):return x[0]*y[1]-x[1]*y[0]
minimum=arb(1);records=[]
for hand in (1,-1):
 for j in range(M):
  a=(2*j+1)*math.pi/M;c,s=math.cos(a),math.sin(a);R=np.array([[c,-hand*s],[s,hand*c]]);ptsf=vf@R.T;h=nf@ptsf.T;idx=h.argmax(axis=1);res=linprog([0,0,1],A_ub=np.c_[nf,-np.ones(T)],b_ub=hf-h.max(axis=1),bounds=[(None,None)]*3,method='highs',options={'primal_feasibility_tolerance':1e-10,'dual_feasibility_tolerance':1e-10});assert res.success
  ids=[int(i) for i in np.flatnonzero(-res.ineqlin.marginals>1e-7)];assert len(ids) in (2,3),(hand,j,ids)
  if len(ids)==2:
   i,k=ids;assert (i-k)%T==T//2;weights=[arb(1),arb(1)]
  else:
   i,k,l=ids;weights=[det(N[k],N[l]),det(N[l],N[i]),det(N[i],N[k])];assert all(w>0 for w in weights),(hand,j,ids,weights)
  angle=(2*pi*j/M).union(2*pi*(j+1)/M);sa,ca=angle.sin_cos();total=arb(0);denom=arb(0);picks=[]
  for i,w in zip(ids,weights):
   k=int(idx[i]);x,y=V[k];y*=hand;xx=ca*x-sa*y;yy=sa*x+ca*y;total+=w*(N[i][0]*xx+N[i][1]*yy-H[i]);denom+=w;picks.append(k)
  gap=total/denom;assert gap>0,(hand,j,ids,picks,gap,res.fun);minimum=min(minimum,gap.lower());records.append([hand,j,ids,picks,str(gap.lower())])
 print('hand',hand,'ok',M,'min',minimum,flush=True)
Path('exclusion.json').write_text(json.dumps({'directions':T,'rotation_cells_per_hand':M,'precision':ctx.prec,'min_weighted_gap':str(minimum),'records':records},separators=(',',':'))+'\n')

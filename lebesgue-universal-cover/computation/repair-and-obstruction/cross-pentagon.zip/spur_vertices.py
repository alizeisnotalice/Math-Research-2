import sys,json
from pathlib import Path
from fractions import Fraction as F
from flint import ctx
ctx.prec=192
p=Path('../luc-astra-a-roots/nov19-two-ear-global/spur-proof/witness.py').resolve();ns={'__file__':str(p),'__name__':'not_main'};src=p.read_text().split('w,e=')[0];exec(compile(src,str(p),'exec'),ns);verts,sup=ns['body'](ns['env'],ns['A'](F(241,400)),ns['A'](-F(22,1125)));print([[str(x) for x in v] for v in verts]);open('spur-vertices.json','w').write(json.dumps([[str(x) for x in v] for v in verts],indent=2))

import json,hashlib
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=192
A=lambda x:arb(F(str(x)).numerator)/F(str(x)).denominator
def cmul(u,v):return (u[0]*v[0]-u[1]*v[1],u[0]*v[1]+u[1]*v[0])
p=Path('degree93.json');assert hashlib.sha256(p.read_bytes()).hexdigest()=='f791b04432770b59ab2e339c548a5d578d897d9816a56908855327aec0e19537';d=json.loads(p.read_text());modes=[(n,A(a),A(b)) for n,a,b in d['curvature_modes']];assert [n for n,a,b in modes]==list(range(3,94,2));sec=sum(n*n*(abs(a)+abs(b)) for n,a,b in modes);N=32768;up=arb(0)
for j in range(N+1):
 sn,cs=(arb.pi()*j/N).sin_cos();u=(cs,sn);u2=cmul(u,u);z=cmul(u2,u);v=arb(0)
 for n,a,b in modes:v+=a*z[0]+b*z[1];z=cmul(z,u2)
 up=max(up,abs(v).upper())
 if j%8192==0:print(j,flush=True)
bound=(up+sec*(arb.pi()/N)**2/8).upper();margin=(A('.5')-bound).lower();assert margin>A('.00002');print('curvature margin',margin,flush=True)

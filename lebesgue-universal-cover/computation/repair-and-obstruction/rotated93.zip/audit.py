from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent;d=json.loads((P/'MANIFEST.json').read_text())
for name,h in d.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
H=json.loads((P/'repair-common-exact.json').read_text());v=H['vertices'];assert len(v)==5469
for i,(x,y) in enumerate(v):
 a,b=v[(i+1)%len(v)];dx=a-x;dy=b-y;assert dx or dy;assert all(dx*(Y-y)-dy*(X-x)>=0 for X,Y in v)
for script in ['check-curvature.py','certify-patch-wide.py']:subprocess.run([sys.executable,'-I','-B',script],cwd=P,check=True)
for name,h in d.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
print('PASS: 93-degree curvature and four-dimensional patch',flush=True)

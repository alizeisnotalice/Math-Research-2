from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
from flint import arb,ctx
ctx.prec=192
A=lambda x:arb(F(str(x)).numerator)/F(str(x)).denominator
def cmul(u,v):return (u[0]*v[0]-u[1]*v[1],u[0]*v[1]+u[1]*v[0])
host=Path('repair-common-exact.json');docp=Path('degree93.json');assert sha256(host.read_bytes()).hexdigest()=='905b83a65ff38acdfde75f6ab68c7eb0ce890d2b688060c70b5913bb70128253';assert sha256(docp.read_bytes()).hexdigest()=='f791b04432770b59ab2e339c548a5d578d897d9816a56908855327aec0e19537';H=json.loads(host.read_text());D=A(H['denominator']);V=H['vertices'];assert len(V)==5469;doc=json.loads(docp.read_text());modes=doc['curvature_modes'];assert [n for n,a,b in modes]==list(range(3,94,2))
phaseq=['-0.040021346995514566','-0.0075001406281641342','0','0.0075001406281641342','0.040021346995514566'];rot=[]
for t in phaseq:
 q=A(t);rot.append(((1-q*q)/(1+q*q),2*q/(1+q*q)))
# w1 and w4 vary ±1e-5, w2 and w3 vary on [0,1e-5], w0 = 1 - sum.
w=[None,arb('.125','.00001'),arb('.000005','.000005'),arb('.000005','.000005'),arb('.625','.00001')];w[0]=1-sum(w[1:]);assert w[0]>0
coeff=[];pows=[cmul(cmul(r,r),r) for r in rot];squares=[cmul(r,r) for r in rot]
for n,ca,cb in modes:
 a=A(ca)/(1-n*n);b=A(cb)/(1-n*n);C=[];S=[]
 for r in pows:
  C.append(a*r[0]-b*r[1]);S.append(a*r[1]+b*r[0])
 coeff.append(list(zip(C,S)))
 pows=[cmul(z,r2) for z,r2 in zip(pows,squares)]
q=A('-.5964817933656967');cs=(1-q*q)/(1+q*q);sn=2*q/(1+q*q);tx=A('.018629406621928843');ty=A('.010688172625986947');low=None
for i,(ax,ay) in enumerate(V):
 bx,by=V[(i+1)%len(V)];nx=A(by-ay)/D;ny=A(ax-bx)/D;L=(nx*nx+ny*ny).sqrt();u=((cs*nx+sn*ny)/L,(-sn*nx+cs*ny)/L);u2=cmul(u,u);z=cmul(u2,u);vals=[A('.5') for _ in range(5)]
 for row in coeff:
  for j,(a,b) in enumerate(row):vals[j]+=a*z[0]+b*z[1]
  z=cmul(z,u2)
 h=vals[0]+sum(w[j]*(vals[j]-vals[0]) for j in range(1,5))
 gap=(nx*(A(ax)/D-tx)+ny*(A(ay)/D-ty))/L-h
 if low is None or gap.lower()<low.lower():low=gap
 if i%1000==0:print('faces',i,flush=True)
print("DEBUG lower",low.lower(),flush=True);assert low>0;out={'host_sha256':sha256(host.read_bytes()).hexdigest(),'source_sha256':sha256(docp.read_bytes()).hexdigest(),'rotation_tan_half':'-.5964817933656967','hand':1,'translation':['.018629406621928843','.010688172625986947'],'parent_rotation_tan_half':phaseq,'weights':'w1 in [.12499,.12501], w2,w3 in [0,.00001], w4 in [.62499,.62501], w0=1-sum','clearance_lower':str(low.lower()),'faces':len(V)};Path('patch-wide-cert.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)

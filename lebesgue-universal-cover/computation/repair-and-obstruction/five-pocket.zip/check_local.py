"""Directed check of a balanced collection of inscribed material polygons in a joint continuous six-body pose box."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,hashlib
from flint import arb,ctx
from local_material import raw
def A(z):z=F(z);return arb(z.numerator)/z.denominator
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def norm(a):return dot(a,a).sqrt()
def check(comp,pose,cert,out):
 ctx.prec=192;z=json.loads(pose.read_bytes());c=json.loads(cert.read_bytes());k=c['k'];r=A(c['width']);rot=r*c['angular_multiplier']
 loc=[];groups=[];sets,den=raw(comp,k)
 assert A(4)*A('0.4')>arb(2).sqrt()
 for n in (3,5,7,9):assert 1-1/(2*(arb.pi()/(2*n)).cos())>A('.4')
 for j,(pts,d) in enumerate(zip(sets,den)):
  for x,y in pts:
   p=(A(F(x,d)),A(F(y,d)));assert norm(p)<A('.6');loc.append(p);groups.append(j)
 val=[A(F(v,2**44)) for v in z['center']]+[A(z['point_pose'][i]) for i in (2,0,1)]
 T=[(arb(0),arb(0)),tuple(val[:2]),tuple(val[3:5]),tuple(val[6:8]),tuple(val[9:11]),tuple(val[12:14])]
 angles=[arb(0),arb(0)]+[val[j] for j in [2,5,8,11]];sc=[a.sin_cos() for a in angles];X=[];V=[]
 for a,j in zip(loc,groups):
  s,cs=sc[j];x,y=a;v=(cs*x-s*y,s*x+cs*y);V.append(v);X.append((v[0]+T[j][0],v[1]+T[j][1]))
 D=arb(2).sqrt()*r+A('.6')*rot;er=A('.3')*rot*rot;offs=arb(0);g0=[arb(0) for _ in range(14)];weights=0
 for w,H in c['terms']:
  assert type(w) is int and w>0 and len(H)==len(set(H)) and all(0<=i<len(X) for i in H)
  weights+=w;area=arb(0);per=arb(0);edgeerr=arb(0);G=[arb(0) for _ in g0]
  for shift in (7,13,19,31,71):
   y=[shift*X[i][1]-X[i][0] for i in H]
   if all(t>0 or t<0 for t in y):break
  else:raise ValueError('choose a transversal ray')
  assert sum(a<0 and b>0 for a,b in zip(y,y[1:]+y[:1]))==1
  for i,j,e in zip(H,H[1:]+H[:1],[H[-1]]+H[:-1]):
   a,b=X[i],X[j];v,u=V[i],V[j];h=groups[i];t=groups[j]
   ss=cross(a,b);area+=ss/2
   if h==t:
    assert cross(loc[i],loc[j])>(norm(T[h])+arb(2).sqrt()*r)*norm(sub(loc[j],loc[i]))
    edgeerr+=rot*norm(sub(u,v))
   else:
    assert ss>D*(norm(a)+norm(b))+D*D
    edgeerr+=2*D
   per+=norm(sub(a,b));pa=X[e];f=((b[1]-pa[1])/2,(pa[0]-b[0])/2)
   if h==1:G[0]+=f[0];G[1]+=f[1]
   if h>1:
    pos=2+3*(h-2);G[pos]+=cross(v,f);G[pos+1]+=f[0];G[pos+2]+=f[1]
  offs+=w*(area-er*per-D*edgeerr/2)
  for j in range(14):g0[j]+=w*G[j]
 lower=(offs-sum(abs(t)*(rot if j in [2,5,8,11] else r) for j,t in enumerate(g0)))/weights
 N=int((lower*10**25).lower().floor().unique_fmpz());result=dict(area_lower=str(F(N,10**25)),decimal=str(lower),translation_halfwidth=c['width'],rotation_halfwidth=str(F(c['width'])*c['angular_multiplier']),weights=weights,polygons=len(c['terms']),pose_sha256=hashlib.sha256(pose.read_bytes()).hexdigest());out.write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for k in ['comp','pose','cert','out']:p.add_argument(k,type=Path)
 a=p.parse_args();check(**vars(a))

from fractions import Fraction as F
from pathlib import Path
import json,sys,numpy as np
from flint import arb,ctx
from scipy.spatial import ConvexHull
from scipy.optimize import linprog
def raw(comp,k):
 sys.path.insert(0,str(comp.resolve()));from certify_nine import arc_body,append_point,S
 ctx.prec=160;pi=arb.pi();sets=[];den=[]
 for n in [0,3,5,7,9]:
  q=[]
  if n:arc_body(q,k,pi,n,arb(0),arb(0),arb(0))
  else:
   for j in range(8*k):
    s,c=(pi*j/(4*k)).sin_cos();append_point(q,c/2,s/2)
  q=list(dict.fromkeys(q));sets.append(q);den.append(S+4)
 p=json.loads((comp/'finite-point-leaf-input.json').read_bytes());sets.append(p['points']);den.append(p['denominator']);return sets,den
def origin():
 p=json.load(open('true-best-pose.json'));return np.array([x/2**44 for x in p['center']]+[float(p['point_pose'][j]) for j in [2,0,1]])
def model(sets,den):
 p=np.vstack([np.array(v)/d for v,d in zip(sets,den)]);g=np.concatenate([np.repeat(i,len(v)) for i,v in enumerate(sets)])
 return p,g
def transform(P,G,z):
 theta=[0.,0.,z[2],z[5],z[8],z[11]];T=np.vstack([[0.,0.],z[:2],z[3:5],z[6:8],z[9:11],z[12:14]])
 c=np.cos(theta)[G];s=np.sin(theta)[G];V=np.column_stack((P[:,0]*c-P[:,1]*s,P[:,0]*s+P[:,1]*c));return V+T[G],V
def row(H,X,V,G,widths):
 g=G[H];p=X[H];n=np.roll(p,-1,axis=0);pr=np.roll(p,1,axis=0);v=V[H]
 a=np.sum(p[:,0]*n[:,1]-p[:,1]*n[:,0])/2;out=np.zeros(14)
 grad=np.c_[n[:,1]-pr[:,1],pr[:,0]-n[:,0]]*.5
 out[:2]=grad[g==1].sum(axis=0)
 for i,j in [(2,2),(3,5),(4,8),(5,11)]:
  E=g==i;out[j]=sum(v[E,0]*grad[E,1]-v[E,1]*grad[E,0]);out[j+1:j+3]=grad[E].sum(axis=0)
 rr=widths[0];rot=widths[2];D=1.415*rr+.6*rot;R=.3*rot**2;per=np.linalg.norm(p-n,axis=1).sum();span=np.linalg.norm(v-np.roll(v,-1,axis=0),axis=1);same=g==np.roll(g,-1)
 e=R*per+.5*D*(2*D*sum(~same)+rot*span[same].sum())
 return a,out,e
def thin(H,X,V,G,rr,rot):
 H=list(H);D=1.415*rr+.6*rot
 for step in range(len(H)):
  p=X[H];v=V[H];g=G[H];next=np.roll(p,-1,axis=0);dg=g!=np.roll(g,-1);d=p[:,0]*next[:,1]-p[:,1]*next[:,0];b=D*(np.linalg.norm(p,axis=1)+np.linalg.norm(next,axis=1))+D**2
  bad=np.where(dg&(d<=b))[0]
  if not len(bad):break
  i=bad[0];j=(i+1)%len(H);k=(i-1)%len(H);l=(i+2)%len(H)
  det=lambda a,b:a[0]*b[1]-a[1]*b[0]
  d0=abs(det(p[i]-p[k],p[j]-p[k]));d1=abs(det(p[j]-p[i],p[l]-p[i]));H.pop(i if d0<d1 else j)
 return H
def optimize(comp,k,rr,scale,out):
 sets,den=raw(comp,k);P,G=model(sets,den);z=origin();X,V=transform(P,G,z);r=np.full(14,rr);r[[2,5,8,11]]=rr*scale;rng=np.random.default_rng(198265)
 rows=[];hs=[];seen=set()
 for j in range(650):
  factor=0 if not j else [0.0003,.003,.03,.3,1,3][j%6]
  x,_=transform(P,G,z+r*rng.uniform(-1,1,14)*factor);h=ConvexHull(x).vertices;h=thin(h,X,V,G,rr,rr*scale);key=tuple(h)
  if key in seen:continue
  seen.add(key);a,g,e=row(h,X,V,G,r);hs.append(h);rows.append([a,g,e])
 A=np.stack([v[1]*r for v in rows]);c=np.array([v[0]-v[2] for v in rows]);sol=linprog([0.]*14+[1.],A_ub=np.c_[A,-np.ones(len(A))],b_ub=-c,bounds=[(-1,1)]*14+[(None,None)],method='highs',options={'primal_feasibility_tolerance':1e-10,'dual_feasibility_tolerance':1e-10});assert sol.success
 w=-sol.ineqlin.marginals;terms=[(int(j),int(round(w[j]*10**12))) for j in np.flatnonzero(w>1e-13) if round(w[j]*10**12)>0];print(rr,scale,len(hs),len(terms),sol.fun,flush=True)
 Path(out).write_text(json.dumps(dict(k=k,width=str(rr),angular_multiplier=scale,terms=[[weight,list(map(int,hs[j]))] for j,weight in terms],estimate=sol.fun),separators=(',',':'))+'\n')
if __name__=='__main__':
 optimize(Path(sys.argv[1]),int(sys.argv[2]),float(sys.argv[3]),int(sys.argv[4]),sys.argv[5])

"""Verify the historical P30 lies strictly inside the best five-curve hull and audit all local materials."""
from fractions import Fraction as F
from pathlib import Path
import json,sys,hashlib
from flint import arb,ctx
from local_material import raw

def q(v):
    v=F(v);return arb(v.numerator)/v.denominator

def main(comp,pose,output):
    sys.path.insert(0,str((comp/'inclusion-minimal-eleven').resolve()))
    from template import build
    from check_local import check
    row=json.loads(pose.read_bytes())
    box=[[v,v] for v in row['center']]
    k=384;H,D=build(comp,False,k,True,box=box);ctx.prec=160
    p=comp/'finite-point-leaf-input.json';hh=hashlib.sha256(p.read_bytes()).hexdigest()
    assert hh=='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
    data=json.loads(p.read_bytes());x,y,theta=map(q,row['point_pose']);s,c=theta.sin_cos();verts=[]
    for a,b in data['points']:
        u=q(F(a,data['denominator']));v=q(F(b,data['denominator']))
        assert u*u+v*v<q('.6')**2
        verts.append(((x+c*u-s*v)*D,(y+s*u+c*v)*D))
    margin=10**12
    for A,B in zip(H,H[1:]+H[:1]):
        X,Y=B[0]-A[0],B[1]-A[1];length=q(X*X+Y*Y).sqrt()
        for px,py in verts:
            clearance=(X*(py-A[1])-Y*(px-A[0]))/(length*D)
            margin=min(margin,int((clearance*10**12).lower().floor().unique_fmpz()))
    assert margin>200000000
    from angle_intersection import hull
    ph=hull(map(tuple,data['points']));den=data['denominator']
    rin=F(4632,10000);rad=F(5322,10000);speed=F(263,1000)
    for a,b in zip(ph,ph[1:]+ph[:1]):
        ex,ey=b[0]-a[0],b[1]-a[1];h=ey*a[0]-ex*a[1]
        assert h>0 and h*h>(ex*ex+ey*ey)*(rin*den)**2
        assert a[0]*a[0]+a[1]*a[1]<(den*rad)**2
    assert rad**2-rin**2<speed**2 and (arb.pi()/10).tan()/2<q('.163')
    drift=2*arb(2).sqrt()*q('.00005')+q('.426')*q('.00015')
    tube_lower=int(((q(F(margin,10**12))-drift)*10**12).lower().floor().unique_fmpz())
    assert tube_lower>8000000
    mats={}
    for tag in ['r24','r2','r1']:
        file=Path('local-'+tag+'.json');certificate=json.loads(file.read_bytes())
        off=sum(map(len,raw(comp,certificate['k'])[0][:5]))
        assert all(all(0<=i<off for i in ids) for _,ids in certificate['terms'])
        check(comp,pose,file,Path('five-pocket-'+tag+'.json'))
        mats[tag]=json.loads(Path('five-pocket-'+tag+'.json').read_bytes())
    out=dict(host_vertices=len(H),k=k,certified_physical_clearance=str(F(margin,10**12)),tube=dict(translation=".00005",rotation=".00015",clearance=str(F(tube_lower,10**12))),material_only='D,B3,B5,B7,B9',area_certificates=mats,input_P30_sha256=hh)
    output.write_text(json.dumps(out,indent=2)+'\n');print(margin,len(H))
if __name__=='__main__':main(*map(Path,sys.argv[1:]))

"""Inscribed common polygon for every orientation in a closed cell of the historical P30."""
from pathlib import Path
import argparse,json,hashlib
from fractions import Fraction as F
from itertools import combinations
from flint import arb,ctx
S=10**7
def ar(x):
 q=F(x);return arb(q.numerator)/q.denominator
def hull(P):
 P=sorted(set(P))
 def half(rows):
  h=[]
  for x,y in rows:
   while len(h)>1 and (h[-1][0]-h[-2][0])*(y-h[-1][1])<=(h[-1][1]-h[-2][1])*(x-h[-1][0]):h.pop()
   h.append((x,y))
  return h[:-1]
 return half(P)+half(reversed(P))
def generate(path,K,out):
 raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc'
 d=json.loads(raw);P=hull(map(tuple,d['points']));assert len(P)==30 and set(P)=={(x,-y) for x,y in P}
 ctx.prec=160;Z=10**15;tan=F(int(((arb.pi()/K).tan()*Z).upper().ceil().unique_fmpz()),Z);p=tan.numerator;q=tan.denominator;rows=[]
 for a,b in zip(P,P[1:]+P[:1]):
  u,v=b[1]-a[1],a[0]-b[0];h=u*a[0]+v*a[1];assert h>0
  for s in (-1,1):rows.append((q*u-s*p*v,q*v+s*p*u,q*h))
 valid=[]
 for (a,b,c),(x,y,z) in combinations(rows,2):
  den=a*y-b*x
  if not den:continue
  X,Y=c*y-b*z,a*z-c*x
  if den<0:X,Y,den=-X,-Y,-den
  if all(m*X+n*Y<=w*den for m,n,w in rows):valid.append((F(X,den*d['denominator']),F(Y,den*d['denominator'])))
 H=hull(valid);assert len(H)>=30
 rr=F(2,5);assert all(w>0 and w*w>(a*a+b*b)*rr*rr*d['denominator']**2 for a,b,w in rows)
 # The rounded polygon remains in the common polytope: its support can increase
 # by at most 1/S, covered by an inward homothety of size 1/(S*r).
 scale=1-F(1,S)/rr;H=[(ar(x*scale*S),ar(y*scale*S)) for x,y in H]
 def rnd(x):return int((x+ar(F(1,2))).floor().unique_fmpz())
 with out.open('w') as f:
  f.write(f'{S} {K}\n')
  for side in [1,-1]:
   for j in range(K):
    s,c=((2*j+1)*arb.pi()/K).sin_cos();v=[(rnd(x*c-side*y*s),rnd(x*s+side*y*c)) for x,y in H];v=hull(v)
    f.write(str(len(v))+' '+' '.join(f'{x} {y}' for x,y in v)+'\n')
 print(K,len(H),sha256(out))
def sha256(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('points',type=Path);p.add_argument('K',type=int);p.add_argument('out',type=Path);a=p.parse_args();generate(a.points,a.K,a.out)

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from certify_poly import Exact,A
ctx.prec=192
def read(s):return json.loads((root/s).read_bytes())
expected=read('receipt.json')
for key,filename in (('input_sha256','degree93.json'),('host_sha256','d2162.json'),('rows_sha256','rows.json'),('plan_sha256','plan.json'),('verifier_sha256','certify_poly.py')):
 assert sha256((root/filename).read_bytes()).hexdigest()==expected[key]
e=Exact(root/'degree93.json',root/'rows.json')
assert list(e.strict_curvature(32768,F('1e-6')))==expected['strict_curvature_interval']
results=e.verify(read('plan.json'),F('1e-8'));assert results==expected['hands']
assert arb(results['1']['weakest'])>A('1.40264855e-8')
assert arb(results['-1']['weakest'])>A('1.47948425e-8')
m=read('degree93.json')['curvature_modes']
for (n,a,b),goal in zip(m[:2],[F(11561921035591135033557139609,5*10**29),F(347387332277331340520448326861,10**30)],strict=True):
 assert F(a)**2+F(b)**2==goal
v=read('d2162.json');p=v['vertices'];area=F(sum(x[0]*y[1]-x[1]*y[0] for x,y in zip(p,p[1:]+p[:1])),2*v['denominator']**2)
assert area==F('.8440818369221730050652525') and e.row_count==30
print((root/'receipt.json').read_text(),end='')

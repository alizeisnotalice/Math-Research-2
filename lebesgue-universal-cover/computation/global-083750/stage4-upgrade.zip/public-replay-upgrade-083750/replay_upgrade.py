"""Replay or audit the complete 3279-leaf budget upgrade at 67/80."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
EXPECTED = {'5': 506, '6': 787, '7': 434}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def verify(a, manifest):
    for name, value in manifest['package_files_sha256'].items():
        assert digest(HERE / name) == value, name
    for name, value in manifest['computation_dependencies_sha256'].items():
        assert digest(a.comp / name) == value, name
    for name, value in manifest['tree_sha256'].items():
        assert digest(a.tree / name) == value, name


def proof_signature(path):
    keys = ('leaf', 'lo', 'hi', 'mode', 'budget', 'stats', 'pending',
            'p_edge_stops', 'q_edge_stops', 'threshold_integer', 'pads')
    return [tuple(row[key] for key in keys)
            for row in map(json.loads, path.read_bytes().splitlines())]


def replay_packet(a, job, frozen):
    name = job['name']
    output = a.work / name
    assert not output.exists()
    tmp = output.with_name(output.name + '.partial')
    command = [sys.executable, '-I', '-B', str(HERE / job['kernel']), str(a.comp),
               str(a.tree), str(a.table), str(a.work / (output.stem + '-kernel')),
               str(a.cache), '--target', '.83750', '--cases-from', str(HERE / job['packet']),
               '--modes', str(job['mode']), '--budget', str(job['budget']), '--depth', '116',
               '--panels', '256', '--share-angles', '--dense', '--share-dense', '--edge-caps']
    if job['mode'] == 1:
        command.append('--q-mesh')
    if 'q_trigger_divisor' in job:
        command += ['--q-trigger-divisor', str(job['q_trigger_divisor'])]
    with tmp.open('x') as out:
        subprocess.run(command, stdout=out, check=True)
    assert proof_signature(tmp) == proof_signature(frozen / name), name
    tmp.rename(output)
    print(name, flush=True)
    return output


def main(a):
    manifest = read(HERE / 'manifest.json')
    verify(a, manifest)
    frozen = HERE / 'frozen'
    jobs = manifest['jobs']
    a.work.mkdir(parents=True, exist_ok=True)
    if a.audit_frozen:
        assert not a.packets
        rows = [frozen / job['name'] for job in jobs]
    else:
        assert digest(a.table) == manifest['table64_sha256']
        if a.packets:
            wanted = set(a.packets)
            assert len(wanted) == len(a.packets) and wanted <= {job['name'] for job in jobs}
            jobs = [job for job in jobs if job['name'] in wanted]
        with ThreadPoolExecutor(a.workers) as pool:
            rows = list(pool.map(lambda job: replay_packet(a, job, frozen), jobs))
    if a.packets:
        return
    audit = a.work / 'audit.json'
    subprocess.run([sys.executable, '-I', '-B', str(HERE / 'audit_whole_batches.py'),
                    str(a.comp), str(a.tree), str(audit), '--scopes',
                    str(HERE / 'scope3279/selection.json'), '--runs', *map(str, rows)], check=True)
    result = read(audit)
    assert result['checked_leaves'] == result['selected'] == 3279 and result['complete_batch']
    assert result['by_family'] == EXPECTED and result['remaining'] == 1552
    assert result['visited_nodes'] == 79825149 and result['visited_attempts'] == 3303
    assert result['Q11_without_P30'] == 434
    subprocess.run([sys.executable, '-I', '-B', str(HERE / 'audit_refined_scope.py'),
                    str(frozen / 'previous-index.json'), str(frozen / 'retained.json'),
                    str(audit), str(a.work / 'joined-index.json')], check=True)
    index = read(a.work / 'joined-index.json')
    previous = read(frozen / 'joined-intermediate-index.json')
    assert index['parts'] == previous['parts']


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    for field in ('comp', 'tree', 'table', 'work', 'cache'):
        cli.add_argument(field, type=Path)
    cli.add_argument('--workers', type=int, default=8)
    cli.add_argument('--audit-frozen', action='store_true')
    cli.add_argument('--packets', nargs='+', help='Replay only these frozen .jsonl packet names.')
    args = cli.parse_args()
    assert args.workers > 0
    main(args)

"""Audit packet receipts, exact unresolved addresses, and cumulative accounting."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path


FAMILIES = {5: 'five', 6: 'P30', 7: 'Q11'}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def audit_paths(row, frontier, depth=116):
    prefixes = {}
    leaves = set()
    root = [list(pair) for pair in zip(row['lo'], row['hi'], strict=True)]
    assert len(frontier) == row['pending']
    for i, node in enumerate(frontier):
        assert node['leaf'] == row['leaf'] and node['label'] == f"{row['leaf']}-{i}"
        assert len(node['steps']) <= depth
        box = [pair.copy() for pair in root]
        prefix = ()
        for step in node['steps']:
            assert type(step) is int and 0 <= step < 22
            axis, side = divmod(step, 2)
            assert prefix not in leaves
            if prefix not in prefixes:
                prefixes[prefix] = (axis, set())
            prior_axis, children = prefixes[prefix]
            assert axis == prior_axis
            children.add(side)
            lo, hi = box[axis]
            assert lo < hi and (lo + hi) % 2 == 0
            box[axis][1-side] = (lo + hi) // 2
            prefix += (step,)
        assert prefix not in prefixes and prefix not in leaves
        assert node['bounds'] == box
        leaves.add(prefix)
    if not row['stats'][0]:
        lo, hi = zip(*frontier[0]['bounds'], strict=True)
        assert list(lo + hi) == row['stats'][11:33]
    terminals = sum(row['stats'][2:6])
    assert sum(2 - len(children) for _, children in prefixes.values()) <= terminals
    return sum(map(len, leaves))


def audit_refined(scope_path, prior_path, results_dir):
    scope = read(scope_path)
    prior = read(prior_path)
    assert digest(prior_path) == scope['source_audit_sha256']
    assert len(prior['unresolved']) == scope['selected']
    jobs, seen, counts = [], set(), Counter()
    for job in scope['jobs']:
        packet_path = scope_path.parent / job['path']
        name = f'refined-{packet_path.stem}'
        result = results_dir / (name + '.jsonl')
        receipt = results_dir / (name + '-receipt.json')
        addresses = results_dir / 'frontiers' / name
        all_frontier_files = set(addresses.glob('*-frontier.json'))
        raw = read(receipt)
        packet = read(packet_path)
        assert len(packet) == len(set(packet)) == job['count'] and seen.isdisjoint(packet)
        assert digest(packet_path) == job['sha256'] == raw['input_sha256']
        assert raw['complete'] and raw['result_sha256'] == digest(result)
        assert raw['checked'] == len(packet)
        assert (raw['mode'], raw['budget']) == (job['mode'], job['budget'])
        rows = [json.loads(line) for line in result.read_bytes().splitlines()]
        assert packet == [row['leaf'] for row in rows]
        assert raw['closed'] == sum(row['stats'][0] for row in rows)
        assert raw['nodes'] == sum(row['stats'][1] for row in rows)
        frontier_hashes = {}
        for row in rows:
            assert (row['mode'], row['budget']) == (job['mode'], job['budget'])
            assert row['shared_angles'] and row['panels'] == 256
            assert row['fan_integral'] and row['coupled_support'] and row['cap_tangent']
            assert row['q_trigger_divisor'] == (12000 if job['mode'] == 1 else 25000)
            slug = row['leaf'].replace('/', '-')
            path = addresses / f"{slug}-mode{row['mode']}-frontier.json"
            all_frontier_files.remove(path)
            frontier = read(path)
            counts['address_steps'] += audit_paths(row, frontier)
            frontier_hashes[path.name] = digest(path)
            counts['frontier_boxes'] += len(frontier)
            counts['nodes'] += row['stats'][1]
            counts['closed'] += row['stats'][0]
            counts['checked'] += 1
            if row['stats'][0]:
                stats = row['stats']
                family = 'Q11' if stats[4] else 'P30' if stats[3] else 'five'
                counts[family] += 1
        assert not all_frontier_files
        seen.update(packet)
        jobs.append(dict(name=name, result_sha256=digest(result), receipt_sha256=digest(receipt),
                         frontier_sha256=frontier_hashes))
    assert set(prior['unresolved']) == seen
    assert not list(results_dir.glob('refined-*.partial'))
    return dict(summary=counts, scope_sha256=digest(scope_path), jobs=jobs)


def cumulative(previous_path, stage4_path, batch_path):
    previous = read(previous_path)
    stage4 = read(stage4_path)
    batch = read(batch_path)
    assert previous['inputs_sha256']['stage4_retained'] == digest(stage4_path)
    assert previous['target'] == batch['goal'] == '67/80' and previous['strict']
    parts = previous['parts']
    assert set(parts) == set(stage4)
    prior_remaining = set()
    for part, states in parts.items():
        fold = [p for family in (*FAMILIES.values(), 'remaining') for p in states[family]]
        assert len(fold) == len(set(fold)) and sorted(fold) == sorted(stage4[part])
        assert set(states['Q11_without_P30']) <= set(states['Q11'])
        prior_remaining.update(f'{part}/{pos}' for pos in states['remaining'])
        states['remaining'] = []
    logs = batch['proof_records']
    accepted = {row['leaf'] for row in logs}
    unresolved = set(batch['unresolved'])
    assert len(accepted) == len(logs) == batch['closed']
    assert len(unresolved) == len(batch['unresolved']) == batch['remaining']
    assert accepted.isdisjoint(unresolved) and accepted | unresolved == prior_remaining
    assert len(prior_remaining) == batch['selected'] == batch['checked_leaves']
    for row in logs:
        part, pos = row['leaf'].split('/')
        family = FAMILIES[row['inputs']]
        parts[part][family].append(int(pos))
        if family == 'Q11' and not row['P30_terminals']:
            parts[part]['Q11_without_P30'].append(int(pos))
    for key in unresolved:
        part, pos = key.split('/')
        parts[part]['remaining'].append(int(pos))
    def count(family):
        return sum(len(p[family]) for p in parts.values())
    for part, states in parts.items():
        fold = [p for family in (*FAMILIES.values(), 'remaining') for p in states[family]]
        assert len(fold) == len(set(fold)) and sorted(fold) == sorted(stage4[part])
        assert set(states['Q11_without_P30']) <= set(states['Q11'])
        for values in states.values():
            values.sort()
    by_family = {family: count(family) for family in FAMILIES.values()}
    original_count = sum(map(len, stage4.values()))
    assert original_count == previous['stage4_retained'] == sum(by_family.values()) + len(unresolved)
    return dict(target='67/80', strict=True, stage4_retained=original_count,
                stage4_retained_parts=len(parts), closed_total=sum(by_family.values()),
                previous_closed=previous['closed_total'], new_closed=len(accepted),
                by_family=by_family, Q11_without_P30=count('Q11_without_P30'),
                unresolved=len(unresolved),
                visited_nodes=previous['visited_new_nodes'] + batch['visited_nodes'],
                visited_attempts=previous['visited_new_attempts'] + batch['visited_attempts'],
                inputs_sha256={p.name: digest(p) for p in (previous_path, stage4_path, batch_path)},
                parts=parts)


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    for key in ('previous', 'stage4', 'batch', 'output'):
        cli.add_argument(key, type=Path)
    cli.add_argument('--frontiers', type=Path, nargs=4,
                     metavar=('SCOPE', 'PRIOR_BATCH', 'RESULTS_DIR', 'FRONTIER_OUTPUT'))
    args = cli.parse_args()
    if args.frontiers:
        *frontier_args, out = args.frontiers
        frontier = audit_refined(*frontier_args)
        out.write_text(json.dumps(frontier, indent=2) + '\n')
        print(json.dumps(frontier['summary']))
    merged = cumulative(args.previous, args.stage4, args.batch)
    args.output.write_text(json.dumps(merged, indent=2) + '\n')
    print(json.dumps({k: v for k, v in merged.items() if k != 'parts'}))

"""Run one whole-leaf task queue using the pinned reusable geometric kernel."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def main(a):
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    raw=json.loads(a.packet.read_bytes())
    assert isinstance(raw,list) and raw and len(raw)==len(set(raw))
    assert all(len(x.split('/'))==2 and all(q.isdecimal() for q in x.split('/')) for x in raw)
    if a.expected_sha256:
        assert digest(a.packet)==a.expected_sha256
    if a.manifest:
        manifest=json.loads(a.manifest.read_bytes())
        assert digest(a.tree/'SHA256SUMS')==manifest['tree_manifest_sha256']
        for name,value in manifest['kernel_files_sha256'].items():
            assert digest(HERE/name)==value
        for name,value in manifest['computation_dependencies_sha256'].items():
            assert digest(a.comp/name)==value
    a.work.mkdir(parents=True,exist_ok=True)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    assert not a.output.exists()
    pending=a.output.with_name(a.output.name+'.partial')
    run=[sys.executable,'-I','-B',str(HERE/'replay_angle_mesh.py'),str(a.comp),str(a.tree),str(a.table),
         str(a.work/'kernel'),str(a.cache),'--target','.83750','--cases-from',str(a.packet),
         '--modes',str(a.mode),'--budget',str(a.budget),'--depth',str(a.depth),
         '--panels',str(a.panels),'--share-angles','--edge-caps','--dense','--share-dense']
    if a.mode==1:
        run+=['--q-mesh']
    with pending.open('x') as receipt:
        subprocess.run(run,stdout=receipt,check=True)
    rows=[json.loads(line) for line in pending.read_bytes().splitlines()]
    assert [x['leaf'] for x in rows]==raw
    assert all(x['mode']==a.mode and x['budget']==a.budget and x['goal']=='67/80' for x in rows)
    assert all(x['edge_caps'] and x['shared_dense'] and x['shared_angles'] for x in rows)
    pending.rename(a.output)
    print(json.dumps(dict(complete=True,task_sha256=digest(a.packet),output_sha256=digest(a.output),
                          visited_leaves=len(rows),closed=sum(x['stats'][0] for x in rows),
                          visited_nodes=sum(x['stats'][1] for x in rows),mode=a.mode,
                          budget=a.budget,depth=a.depth,panels=a.panels)),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','table','work','cache','packet','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--manifest',type=Path)
    p.add_argument('--expected-sha256')
    p.add_argument('--mode',type=int,choices=(0,1,4),default=0)
    p.add_argument('--budget',type=int,default=8191)
    p.add_argument('--depth',type=int,default=116)
    p.add_argument('--panels',type=int,default=128)
    a=p.parse_args()
    assert a.budget>0 and a.depth>0 and a.panels>0
    main(a)

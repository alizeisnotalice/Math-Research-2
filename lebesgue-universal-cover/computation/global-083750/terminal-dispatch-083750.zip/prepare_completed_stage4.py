"""Freeze the disjoint whole-leaf tasks from validated Stage 4 source packets."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

GOAL=120696470013529293
PREVIOUS={(1205,140208),(1205,140080),(180,24225)}


def main(a):
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    exclude=set(PREVIOUS)
    if a.exclude:
        exclude.update(tuple(map(int,x.split('/'))) for x in json.loads(a.exclude.read_bytes()))
    names=[]
    tasks=[]
    for part in a.parts:
        stem=f'part{part:04d}.npz'
        stage4=a.source/'screen'/'stage4'/stem
        stage3=a.source/'screen'/'stage3'/stem
        seed=a.source/'seeds'/stem
        raw=json.loads(stage4.with_suffix('.json').read_bytes())
        assert raw['config']['part']==part and raw['config']['layer']==4
        assert raw['config']['goal']==GOAL and raw['config']['radial_goal']=='67/80'
        assert raw['data_sha256']==digest(stage4)
        assert raw['config']['source_sha256']==digest(stage3)
        with np.load(stage4,allow_pickle=False) as src,np.load(stage3,allow_pickle=False) as older:
            accepted,rest=src['accepted'],src['remaining']
            floor=src['full_floor']
            assert np.array_equal(np.sort(np.r_[accepted,rest]),older['remaining'])
            assert floor.shape==accepted.shape and np.all(floor>=GOAL)
            assert len(accepted)==raw['accepted'] and len(rest)==raw['remaining']
            assert len(accepted)+len(rest)==raw['tested']
            assert np.all(np.diff(rest)>0)
        with np.load(seed,allow_pickle=False) as src:
            base=src['pos']
            assert np.all(np.diff(base)>0)
            ids=np.searchsorted(base,rest)
            assert np.array_equal(base[ids],rest)
            prior=src['score'][ids]
        for pos,score in zip(rest,prior,strict=True):
            key=(part,int(pos))
            if key not in exclude:
                tasks.append(dict(part=part,pos=int(pos),earlier_whole_leaf_score=int(score)))
        names.append(dict(part=part,stage4_remaining=raw['remaining'],stage4_accepted=raw['accepted'],
                          excluded=sum((part,int(x)) in exclude for x in rest),
                          stage4_sha256=digest(stage4),stage3_sha256=digest(stage3),
                          stage4_receipt_sha256=digest(stage4.with_suffix('.json')),
                          seed_sha256=digest(seed)))
    tasks.sort(key=lambda x:(-x['earlier_whole_leaf_score'],x['part'],x['pos']))
    assert len(tasks)==len(set((x['part'],x['pos']) for x in tasks))
    a.bundle.mkdir(parents=True,exist_ok=False)
    subsets={}
    for i in range(a.jobs):
        path=a.bundle/f'job-{i:02}.json'
        chunk=[f"{x['part']}/{x['pos']}" for x in tasks[i::a.jobs]]
        if chunk:
            path.write_text(json.dumps(chunk,separators=(',',':'))+'\n')
            subsets[path.name]=dict(count=len(chunk),sha256=digest(path))
    out=dict(goal='67/80',threshold_integer=GOAL,source_packets=names,selected=len(tasks),
             whole_leaves=True,ordering="descending prior score")
    out.update(task_sha256=subsets,tasks=tasks)
    (a.bundle/'selection.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='tasks'}),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    p.add_argument('bundle',type=Path)
    p.add_argument('--parts',type=int,nargs='+',required=True)
    p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--exclude',type=Path)
    a=p.parse_args()
    assert a.jobs>0 and len(a.parts)==len(set(a.parts))
    main(a)

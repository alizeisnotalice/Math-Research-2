"""Join the new whole-leaf proof ledger to every Stage 4 retained root."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path

PREVIOUS={'1205/140208':5,'1205/140080':5,'180/24225':6}
FAMILIES={5:'five',6:'P30',7:'Q11'}


def main(a):
    raw=json.loads(a.retained.read_bytes())
    universe={f'{part}/{p}' for part,positions in raw.items() for p in positions}
    assert len(universe)==sum(len(pos) for pos in raw.values())==5442
    older=json.loads(a.previous.read_bytes())
    assert older['target']=='67/80' and older['areas']=='strictly greater'
    assert set(older['leaves'])==PREVIOUS.keys()
    for leaf,family in PREVIOUS.items():
        assert older['leaves'][leaf]['complete'] and older['leaves'][leaf]['inputs']==family
    d=json.loads(a.audit.read_bytes())
    assert d['goal']=='67/80' and d['complete_batch']
    chosen={x['leaf']:x for x in d['proof_records']}
    remaining=set(d['unresolved'])
    assert not (chosen.keys()&remaining or chosen.keys()&PREVIOUS.keys() or remaining&PREVIOUS.keys())
    assert universe==chosen.keys()|remaining|PREVIOUS.keys()
    assert len(chosen)==d['closed'] and len(remaining)==d['remaining']
    assert d['selected']==d['checked_leaves']==len(universe)-len(PREVIOUS)
    choice={**PREVIOUS,**{k:v['inputs'] for k,v in chosen.items()}}
    shards=defaultdict(lambda:dict(five=[],P30=[],Q11=[],Q11_without_P30=[],remaining=[]))
    for part,values in raw.items():
        for leaf in values:
            key=f'{part}/{leaf}'
            if key in remaining:
                shards[part]['remaining'].append(leaf)
                continue
            shards[part][FAMILIES[choice[key]]].append(leaf)
            if key in chosen and chosen[key]['inputs']==7 and not chosen[key]['P30_terminals']:
                shards[part]['Q11_without_P30'].append(leaf)
    counts=Counter(FAMILIES[k] for k in choice.values())
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    summary=dict(target='67/80',strict=True,stage4_retained=len(universe),
                 stage4_retained_parts=len(raw),previous=len(PREVIOUS),
                 new_proofs=len(chosen),unresolved=len(remaining),
                 all_stage4_retained_roots_executed=True,
                 closed_total=len(choice),by_family=dict(counts),
                 Q11_without_P30=d['Q11_without_P30'],
                 visited_new_nodes=d['visited_nodes'],visited_new_attempts=d['visited_attempts'],
                 inputs_sha256={'stage4_retained':digest(a.retained),'prior_three':digest(a.previous),
                               'new_proof_audit':digest(a.audit)})
    a.output.write_text(json.dumps({**summary,'parts':dict(shards)},indent=2)+'\n')
    print(json.dumps(summary),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('retained','previous','audit','output'):
        p.add_argument(k,type=Path)
    main(p.parse_args())

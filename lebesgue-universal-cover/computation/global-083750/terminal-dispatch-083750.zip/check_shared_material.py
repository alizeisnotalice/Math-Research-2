"""Cross-check shared dense rows and mesh support on two actual source slices."""
from argparse import ArgumentParser
from bisect import bisect_right
from fractions import Fraction as F
import json
from pathlib import Path
from random import Random
import sys

import numpy as np
from flint import arb,ctx

sys.path.insert(0,str(Path(__file__).resolve().parent))
from replay_angle_mesh import support_mesh


def params(tree,keys,scale):
    return np.array([[int(t*scale) for t in k] for k in tree.leaf(*map(int,keys.split('/')))],np.int64)


def true_support(n,theta,direction,pi,ar):
    x,y,norm=direction
    c=(pi/(2*n)).cos()
    R=1/(2*c)
    vals=[]
    for k in range(n):
        a=ar(theta)+2*pi*k/n
        s,t=a.sin_cos()
        dot=x*t+y*s
        vals.append(R*dot)
        if not dot> -c*norm:
            vals.append(norm+R*dot)
    return vals


def main(a):
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import FINE, Q, U, SourceTree, ceil, load_table
    from certify_nine import ar
    from replay_q11_with_p30 import PointProof
    from tomar_p30_scaled_material import scaled_material
    tree=SourceTree(a.tree)
    spec=json.loads((a.comp/'tomar-six-high-input.json').read_bytes())
    base=load_table(a.table,tree,spec['tables']['64'])
    ctx.prec=160
    pi=arb.pi()
    p=json.loads((a.comp/'finite-point-leaf-input.json').read_bytes())
    p['cells']=json.loads((a.comp/'finite-point-global-input.json').read_bytes())['cells']
    pp=PointProof(p)
    original=np.array([int(F(t)*FINE) for t in tree.root['hi']],np.int64)
    out=[]
    rng=Random(745185)
    for path in a.scopes:
        scope=json.loads(path.read_bytes())
        keys=[f"{x['part']}/{x['pos']}" for x in scope['tasks']]
        chosen=[keys[i] for i in range(0,len(keys),max(1,len(keys)//12))]
        boxes=np.array([params(tree,k,FINE) for k in chosen],np.int64)
        union_lo,union_hi=boxes[:,:,0].min(axis=0),boxes[:,:,1].max(axis=0)
        shared,counts=scaled_material(base,union_lo,union_hi,original)
        knots,values,pads=support_mesh(pp,union_lo,union_hi,128,FINE,Q,U,ceil)
        offsets=np.r_[0,np.cumsum(counts)]
        indices=[0,2,5,8]
        shared=shared.reshape(1025,-1,2)
        knots=knots.reshape(3,129).tolist()
        values=values.reshape(3,129,-1).tolist()
        checks=upper=0
        for box in boxes[::2]:
            local,local_counts=scaled_material(base,box[:,0],box[:,1],original)
            assert np.array_equal(counts,local_counts)
            local=local.reshape(1025,-1,2)
            assert np.array_equal(shared[:, :offsets[2]],local[:, :offsets[2]])
            for b,k in enumerate(indices[1:],2):
                L,H=map(int,box[k])
                top=int(original[k])
                i=(1024*L+top//2)//top
                j=(1024*H+top//2)//top
                assert 0<=i<=j<=1024
                assert np.array_equal(shared[i:j+1,offsets[b]:offsets[b+1]],
                                      local[i:j+1,offsets[b]:offsets[b+1]])
                checks+=j-i+1
                grid=knots[b-2]
                for t in (L,H,rng.randint(L,H)):
                    z=min(127,bisect_right(grid,t)-1)
                    assert grid[z]<=t<=grid[z+1]
                    d=grid[z+1]-grid[z]
                    for normal in rng.sample(range(len(pp.v)),8):
                        a0,c0=values[b-2][z][normal],values[b-2][z+1][normal]
                        num=a0*(grid[z+1]-t)+c0*(t-grid[z])
                        bound=ar(F(-((-num)//d),Q))
                        assert all(u<bound for u in true_support(2*b+1,F(t,FINE),pp.v[normal],pi,ar))
                        upper+=1
        out.append(dict(scope=str(path),sampled_keys=len(chosen),integer_body_rows=checks,
                        arb_support_comparisons=upper,pads=pads))
    a.output.write_text(json.dumps(dict(seed=745185,checks=out),indent=2)+'\n')
    print(json.dumps(out),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','table','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--scopes',nargs='+',type=Path,required=True)
    main(p.parse_args())

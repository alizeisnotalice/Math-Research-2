"""Audit disjoint whole-leaf scope and count only the weakest proved input family."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

THRESHOLD=120696470013529293


def main(a):
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import FINE,SourceTree
    source=SourceTree(a.tree)
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    scopes={}
    hashes={}
    for path in a.scopes:
        value=json.loads(path.read_bytes())
        hashes[str(path)]=digest(path)
        assert value['threshold_integer']==THRESHOLD and value['goal']=='67/80' and value['whole_leaves']
        chosen=[f"{x['part']}/{x['pos']}" for x in value['tasks']]
        assert value['selected']==len(chosen)==len(set(chosen))
        assigned=[]
        for name,desc in value['task_sha256'].items():
            packet=path.parent/name
            assert digest(packet)==desc['sha256']
            chunk=json.loads(packet.read_bytes())
            assert len(chunk)==desc['count']
            assigned.extend(chunk)
        assert len(assigned)==len(set(assigned)) and set(assigned)==set(chosen)
        for x in chosen:
            assert x not in scopes
            scopes[x]=path.name
    oldest={}
    visited=set()
    accepted={}
    attempts=Counter()
    failed=Counter()
    for path in a.runs:
        hashes[str(path)]=digest(path)
        with path.open() as stream:
            for line_number,line in enumerate(stream,1):
                row=json.loads(line)
                key=row['leaf']
                assert key in scopes and row['label']==key
                assert row['goal']=='67/80' and row['threshold_integer']==THRESHOLD
                if key not in oldest:
                    bounds=source.leaf(*map(int,key.split('/')))
                    scaled=[[x*FINE for x in pair] for pair in bounds]
                    assert all(x.denominator==1 for pair in scaled for x in pair)
                    oldest[key]=[list(map(int,x)) for x in zip(*scaled,strict=True)]
                assert oldest[key]==[row['lo'],row['hi']]
                mode=row['mode']
                assert mode in (0,1,4) and not row['guards'] and not row['center_stops']
                stats=row['stats']
                assert len(stats)==35 and stats[5]==0 and all(type(s) is int for s in stats)
                assert stats[0] in (0,1) and 0<stats[1]<=row['budget']
                assert all(s>=0 for s in stats[2:6])
                assert 0<=row['p_edge_stops']<=stats[3] and 0<=row['q_edge_stops']<=stats[4]
                assert not mode&4 or not (stats[3] or stats[4])
                assert mode&1 or stats[4]==0
                attempted=(key,mode,row['budget'],row['edge_caps'])
                assert attempted not in visited
                visited.add(attempted)
                attempts['attempts']+=1
                attempts['nodes']+=stats[1]
                if not stats[0]:
                    assert stats[7] in (1,2,3) and row['pending']>0
                    checked=row.get('pending_visited',int(stats[7]!=1))
                    assert stats[1]==2*sum(stats[2:6])+row['pending']-1+checked
                    failed[str(stats[7])]+=1
                    continue
                assert row['pending']==stats[7]==0 and stats[1]==2*sum(stats[2:6])-1
                family=7 if stats[4] else 6 if stats[3] else 5
                candidate=dict(leaf=key,inputs=family,source_file=path.name,source_line=line_number,
                               nodes=stats[1],five_terminals=stats[2],P30_terminals=stats[3],
                               Q11_terminals=stats[4],P30_long_edge=row['p_edge_stops'],
                               Q11_long_edge=row['q_edge_stops'])
                earlier=accepted.get(key)
                if earlier is None or (family,stats[1])<(earlier['inputs'],earlier['nodes']):
                    accepted[key]=candidate
    checked={x[0] for x in visited}
    counts=Counter(str(x['inputs']) for x in accepted.values())
    remaining=sorted(set(scopes)-set(accepted))
    result=dict(goal='67/80',selected=len(scopes),checked_leaves=len(checked),
                complete_batch=(set(scopes)==checked),all_closed=not remaining,
                closed=len(accepted),by_family={str(j):counts.get(str(j),0) for j in (5,6,7)},
                Q11_without_P30=sum(x['inputs']==7 and x['P30_terminals']==0 for x in accepted.values()),
                visited_attempts=attempts['attempts'],visited_nodes=attempts['nodes'],
                failure_attempts=dict(failed),remaining=len(remaining),
                original_bounds_checked_for=len(oldest),proof_records=[accepted[k] for k in sorted(accepted)],
                unresolved=remaining,input_files_sha256=hashes)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'proof_records','unresolved','input_files_sha256'}}),flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','output'):
        p.add_argument(key,type=Path)
    p.add_argument('--scopes',nargs='+',type=Path,required=True)
    p.add_argument('--runs',nargs='+',type=Path,required=True)
    main(p.parse_args())

# 0.83750 原叶批次终端

每个任务指定一棵 Tomar v9 原始闭叶。固定圆盘中心和三边形方向，端点单位 \(2^{-44}\)，严格面积整数门槛 \(120696470013529293/2^{57}>67/80\)。五体为圆盘及正 Reuleaux 三、五、七、九边形。模式 0 允许同一原三十点 \(P_{30}\)，模式 1 再允许原十一点 \(Q_{11}\)，模式 4 单独核验五体。每个有限点集的转动、反射和平移独立。弦帽判据见 [三叶证明](PROOF.md)。

## 第四层任务清单

prepare_completed_stage4.py 读取某分片已同时落盘的第四层 JSON、NPZ，检查分片号、目标、第三层输入哈希、接受与保留的完整不交分割及面积门槛。历史分数只给任务排序，终端核验从原树真正的整闭叶重新计算。预登记已闭的 1205/140208、1205/140080、180/24225 被排除，可传入额外已闭清单。模式、预算与终端实际结果由回执分别记录。

~~~sh
python -I -B prepare_completed_stage4.py "$SOURCE_STAGE" "$SCOPE" \
    --parts 181 1205 --jobs 4
~~~

任务编号必须从刚生成的 scope 获取。如果已有若干分片在别的批次运行，则保持这两个清单的具体叶号互不重叠。可将任意明确未闭子集另存成 JSON 字符串数组作后续任务，并用原 scope 核对其属于预登记范围。

## 多根共用材料和转角网格

每个任务包先从真实原根重建所有端点。取这些根在各坐标方向的最小下端和最大上端。曲体整数材料在这个联合范围内逐锚生成并重新核验，搜索中每个根只读取其确切要求的锚行。生成的附加物点都位于已定义的缩体中。任何独立重建该根材料时使用的行，使用同样的生成公式与严格成员核验。

共用法向支撑网格对三个活动角度分别覆盖该任务的联合闭范围。以最大相邻格距计算统一二阶插值余量。对每个闭子盒取其真正角端和落在区间内的格点最大值。这样一个经核验的较大覆盖区间，可以供任意多棵根的支撑查询复用。四个首批进程各自只做一次密材料和角网格的联合预处理。

## 可独立执行的终端

COMP 指 Math-Research-2 的 lebesgue-universal-cover/computation。TREE 为解压的 cert11d_08366 树。TABLE64 可用 COMP/tomar_fan_table.py 和 --subdiv 64 现建。WORK 与 CACHE 分别是独有临时目录和共享 Clang 缓存。生成与运行需要 Python、NumPy、python-flint 和带有溢出陷阱的 Clang。

~~~sh
python -I -B run_terminal_packet.py "$COMP" "$TREE" "$TABLE64" \
    "$WORK" "$CACHE" "$PACKET" "$RESULT" --manifest kernel-manifest.json \
    --expected-sha256 "$PACKET_SHA" --mode 0 --budget 8191 --panels 128
~~~

任一机器只运行自己分配的 PACKET，所有输入和代码绑定在同一份清单。RESULT 完成前采用 .partial 文件。终端校验全部访问标识和顺序，与任务包逐一对应后，原子改名为最终文件。程序报告输出 SHA-256 和节点数。各端点和整数终端都在当地重新核验。现有 MacBook 连接保持未用，本批全部在本机 CPU 执行。

合成清算使用已冻结的 disjoint scope 和全部实际运行的结果文件。同一棵原叶若有多个合法成功的证明，先选使用输入最少者，再选节点较少者。只有确实使用 \(P_{30}\) 或 \(Q_{11}\) 终端的完整树才使用对应的六体或七体分类。预算退出的闭根仍保留在候选集。

~~~sh
python -I -B audit_whole_batches.py "$COMP" "$TREE" "$AUDIT" \
    --scopes scope181/selection.json scope1205/selection.json \
    --runs part0181-p30-??.jsonl part0181-q11-??.jsonl part1205-p30-??.jsonl
~~~

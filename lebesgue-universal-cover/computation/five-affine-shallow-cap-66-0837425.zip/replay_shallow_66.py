"""Rebuild and validate the 66 pure five-body original-box proofs for the shallow-cap transfer."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify_five_selected_083740_traces import audit

PRIOR_SELECTION_SHA = 'ff46cfc8461f296703838005746f352ff477f9fd8650e0b946403bfb0a5c2320'


def digest(data):
    return sha256(data).hexdigest()


def main():
    if not __debug__:
        raise SystemExit('Run with assertions enabled.')
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('checkout', 'cert', 'work', 'cache'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--workers', type=int, default=1)
    args = parser.parse_args()
    assert 1 <= args.workers <= 12
    for line in (HERE/'SHA256SUMS').read_text().splitlines():
        h, name = line.split('  ', 1)
        assert digest((HERE/name).read_bytes()) == h
    expected = HERE/'expected'
    prior = (expected/'prior-selection.json').read_bytes()
    assert digest(prior) == PRIOR_SELECTION_SHA
    pairs = {(p,i) for p,i,_ in json.loads(prior)['leaves']}
    selection = json.loads((expected/'selection.json').read_bytes())
    rows = selection['leaves']
    assert len(rows) == len(pairs) == 66 and {(p,i) for p,i,_,_ in rows} == pairs
    assert min(Fraction(t) for _,_,t,_ in rows) == Fraction(selection['threshold']) >= Fraction('.837423')

    def replay(row):
        part, pos, target, budget = row
        stem = f'part{part}-pos{pos}'
        work = args.work/stem
        cmd = [sys.executable, '-I', '-B', HERE/'replay_five_affine_selected.py',
               args.checkout, args.cert, work, args.cache, '--target', target,
               '--part', str(part), '--positions', str(pos), '--budget', str(budget)]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
        raw = (work/(stem+'.json')).read_bytes()
        assert raw == (expected/(stem+'.json')).read_bytes()
        box = json.loads(raw)
        assert (box['part'], box['pos'], box['threshold'], box['budget']) == tuple(row)
        assert box['result']['remaining'] == []
        trace = (work/(stem+'.bin')).read_bytes()
        assert digest(trace) == box['trace_sha256'] and trace == (expected/(stem+'.bin')).read_bytes()
        check = audit(box['root'], trace)
        assert all(box['result'][k] == v for k,v in check.items())
        return check['vis'], sum(check['closed'].values())

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(replay, rows))
    visits, terminals = map(sum, zip(*results))
    assert (visits,terminals) == (selection['visits'],selection['terminals'])
    report = dict(complete=True, threshold=selection['threshold'], boxes=len(pairs),
                  visits=visits, terminals=terminals,
                  selection_sha256=digest((expected/'selection.json').read_bytes()))
    (args.work/'replay-result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()

Whole-box pure five-body area strictly above 0.837425 for all 66 exceptional original boxes in the 0.83742 outer proof. Each reported coordinate box is regenerated directly from its original preorder position and includes every boundary point. The verifier reconstructs each subtree and checks its branch cover again in exact integers.

Required inputs: upstream Git checkout 10af98606c98ca9ffd0d9f402cae1e2efe74b792 (independent/gen8.py and independent/gen11.py), cert11d_08366 (SHA256SUMS, part0000.json and the selected original part JSON/NPY pairs), Python with numpy/scipy/python-flint, clang++, and git.
python -I -B replay_shallow_66.py UPSTREAM CERT WORK CLANG_CACHE --workers 4
Output: WORK/replay-result.json. The 66 identities must exactly equal the frozen list in five-affine-selected-083742-final.zip, whose SHA-256 is 11d1b60886d5724ceb3b8043301c5e90dc25732591ec203d30771a907801db04. The archived prior-selection.json is the exact byte string extracted from that archive.

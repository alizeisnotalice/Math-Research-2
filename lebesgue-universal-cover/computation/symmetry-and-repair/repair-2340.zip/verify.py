"""Reconstruct a rational polygon enclosing two complete curvature profiles and a fixed base."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
from decimal import Decimal, getcontext

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from flint import arb,ctx
from profile_source import Profile

SCALE=10**12
N=16384
PAD=18400
B=F('.844082046521218581802948589770767704354')
sources={'p24-original.json': 'a06d487f7ae9c4e07c541231fdbd503b077fb09f0e50764bb52567d3bb429208', 'p16-original.json': 'cf2d0cbef03f99b1c8b731aa4f533c171a2bfe78c3af487ff3f943abb16fe64e', 'profile16-16206.json': '6418ed327a6635fc6b7e6d5d06e8cc8ee07c0e714d1daa980b0da1fe18a1efb0', 'profile24-33268.json': '77e4797c59ea521f7bb1831d55d3a6cd5578fe1540864094db47e11ec7a760a8', 'profile16-8952.json': '33ee7796aa77951988634e7accfdd2f967c1bfb6871b095977c3eed785a8e2e9', 'profile16-2206.json': 'ebd5721d80c44f1cd1e5cfedb5766385fbe08e5779425dab99c4a8cca5eb4f53'}
def digest(name):
 return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def read(name):return json.loads((ROOT/name).read_bytes())
def decimal(x):return str(Decimal(x.numerator)/Decimal(x.denominator))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def convex(points):
 def side(seq):
  chain=[]
  for p in seq:
   while len(chain)>=2 and cross(chain[-2],chain[-1],p)<=0:chain.pop()
   chain.append(p)
  return chain[:-1]
 ordered=sorted(set(points))
 return side(ordered)+side(reversed(ordered))
def area(points,den=SCALE):
 return F(sum(x*v-y*u for (x,y),(u,v) in zip(points,points[1:]+points[:1])),2*den**2)
def buffered(points,pad):
 return [(x+i*pad,y+j*pad) for x,y in points for i in (-1,1) for j in (-1,1)]
def A(x):x=F(x);return arb(x.numerator)/x.denominator
def rounded(z):
 t=z*SCALE;m,e=map(int,t.mid().man_exp())
 k=round(F(m)*F(2)**e)
 assert abs(t-k)<1
 return k
def material(name,pose):
 assert digest(name)==sources[name]
 spec=read(name);w=Profile(spec.get("profile",spec))
 c=A(pose['q']);sn=2*c/(1+c*c);cs=(1-c*c)/(1+c*c)
 if pose['halfturn']:sn,cs=-sn,-cs
 s=pose['hand'];assert s in (-1,1)
 tx,ty=map(A,[pose['tx'],pose['ty']])
 cloud=[]
 for i in range(N):
  y,d=w.at(2*i,N)
  si,co=(2*arb.pi()*i/N).sin_cos()
  x=(A('.5')+y)*co-d*si
  z=s*((A('.5')+y)*si+d*co)
  cloud.append((rounded(tx+cs*x-sn*z),rounded(ty+sn*x+cs*z)))
 return convex(cloud)
def offsets(radius):
 # Circumscribed integer 32-gon, with every side checked against the entire disk.
 count=32
 R=(arb(radius)+2)/(arb.pi()/count).cos()
 points=[]
 for j in range(count):
  sn,cs=(2*j*arb.pi()/count).sin_cos()
  points.append((rounded(R*cs/SCALE),rounded(R*sn/SCALE)))
 pts=convex(points)
 assert len(pts)==count
 for p,q in zip(pts,pts[1:]+pts[:1]):
  z=cross(p,q,(0,0))
  assert z>0 and z*z>=radius*radius*((p[0]-q[0])**2+(p[1]-q[1])**2)
 return pts
def sum_hull(P,Q):
 # Boundary edge directions of a Minkowski sum are the merged ordered lists.
 def start(p):return min(range(len(p)),key=lambda i:(p[i][1],p[i][0]))
 def ordered(p):
  k=start(p);return p[k:]+p[:k]
 p,q=ordered(P),ordered(Q)
 edges=[]
 for poly in (p,q):
  edges.extend((b[0]-a[0],b[1]-a[1]) for a,b in zip(poly,poly[1:]+poly[:1]))
 from functools import cmp_to_key
 def compare(v,w):
  hv=(v[1]<0 or (v[1]==0 and v[0]<0));hw=(w[1]<0 or (w[1]==0 and w[0]<0))
  if hv!=hw:return 1 if hv else -1
  z=v[0]*w[1]-v[1]*w[0]
  return (z<0)-(z>0)
 x,y=p[0][0]+q[0][0],p[0][1]+q[0][1]
 pts=[(x,y)]
 for dx,dy in sorted(edges,key=cmp_to_key(compare)):
  x+=dx;y+=dy;pts.append((x,y))
 assert pts[-1]==pts[0]
 return convex(pts)
def check_host(poly):
 assert poly==convex(poly)
 assert all(max(map(abs,p))<SCALE for p in poly)
def save(name,poly):
 check_host(poly)
 raw=(json.dumps(dict(denominator=SCALE,vertices=poly),separators=(',',':'))+'\n').encode()
 dst=ROOT/name
 if dst.exists():assert dst.read_bytes()==raw,name
 else:dst.write_bytes(raw)
 return dict(vertices=len(poly),area=decimal(area(poly)),budget_slack=decimal(B-area(poly)),sha256=digest(name))
def data():
 out=[]
 for name,pose in read('six-poses.json').items():
  src=read(name);p=Profile(src.get('profile',src))
  ang=2*A(pose['q']).atan()+int(pose['halfturn'])*arb.pi()
  out.append((name,p,pose['hand'],ang))
 return out
def row(t,objs):
 entries=[]
 for _,p,s,a in objs:
  theta=s*(t*arb.pi()/180-a)
  while theta<0:theta+=2*arb.pi()
  while theta>2*arb.pi():theta-=2*arb.pi()
  neg=theta>arb.pi()
  if neg:theta-=arb.pi()
  j=next(i for i in range(len(p.fs)) if p.knots[i]<theta<p.knots[i+1])
  entries.append(A('.5')+(-1 if neg else 1)*p.fs[j])
 return [x-entries[0] for x in entries[1:]]
def verify_degrees(degs):
 from flint import arb_mat
 ctx.prec=192;objs=data();M=arb_mat([row(d,objs) for d in degs]);D=M.det()
 assert abs(D)>A('.00000001')
 return str(D)
def mark():
 objs=data();name,p,s,a=objs[0]
 assert name=='profile16-8952.json'
 marker=a+s*p.knots[1]
 jump=abs(p.fs[1]-p.fs[0]);assert jump>A('.001')
 gaps=[abs((marker-(b+h*k)).sin()).lower() for label,q,h,b in objs[1:] for k in q.knots[:-1]]
 gap=min(gaps);assert gap>A('1e-12')
 return dict(name=name,internal_knot=1,absolute_jump=str(jump),other_knots_min_abs_sine=str(gap),
             maximum_orthogonal_candidates=2*sum(2*(len(q.bounds)-1) for _,q,_,_ in objs))
def run():
 assert __debug__
 ctx.prec=192;getcontext().prec=80
 assert digest('profile_source.py')=='2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'
 assert digest('base.json')=='32f64cf2d5e2aa180a0a65bde66102bdfc4564c48a2e68fe209a92806bd3e383'
 source=read('base.json');D=source['denominator'];original=[tuple(p) for p in source['vertices']]
 assert len(original)==2335 and set(original)==set(convex(original))
 assert D==SCALE
 base=original
 assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
 conf=read('six-poses.json');assert set(conf)==set(sources)
 joined=convex(p for name in sources for p in material(name,conf[name]))
 def polygon(extra):
  return convex(base+buffered(joined,PAD+extra))
 tight=polygon(0)
 assert area(tight)<F('.84407850')
 result=dict(original_area=decimal(area(original,D)),tight=save('host-tight.json',tight))
 # Choose the largest whole micrometre radius supported by this square-buffered construction.
 step=10**6
 lo,hi=0,32
 assert area(polygon(hi*step))>B
 while hi-lo>1:
  mid=(lo+hi)//2
  if area(polygon(mid*step))<B:lo=mid
  else:hi=mid
 robust=polygon(lo*step)
 assert area(robust)<B and area(polygon((lo+1)*step))>=B and lo>0
 result.update(robust=save('host-robust.json',robust),tube_radius=decimal(F(lo*step,SCALE)),
               first_larger_square_construction_area=decimal(area(polygon(hi*step))),
               new_curves_samples=N,certified_grid_pad=decimal(F(PAD,SCALE)),poses=conf)
 # Search numerically unnecessary here. Every trial uses exact scaled integer polygon area.
 samples_with_pad=convex(buffered(joined,PAD))
 def circ(radius):
  return convex(base+sum_hull(samples_with_pad,offsets(radius)))
 step=10000
 lo,hi=100,1000
 assert area(circ(lo*step))<B<=area(circ(hi*step))
 while hi-lo>1:
  mid=(lo+hi)//2
  if area(circ(mid*step))<B:lo=mid
  else:hi=mid
 final=circ(lo*step)
 # Independent verification of the entire explicit Minkowski sum used in the acceptance.
 offs=offsets(lo*step)
 direct=convex(base+[(x+u,y+v) for x,y in samples_with_pad for u,v in offs])
 assert direct==final and area(final)<B
 result.update(round_tube=save('host-round.json',final),round_tube_radius=decimal(F(lo*step,SCALE)),
               next_tested_round_area=decimal(area(circ(hi*step))))
 ds=[45,121,51,7,175]
 result['affine_independence']=dict(degrees=ds,determinant=verify_degrees(ds),order=[t[0] for t in data()],private_jump=mark())
 return result

if __name__=='__main__':
 out=run()
 if (ROOT/'receipt.json').exists():assert out==read('receipt.json')
 print(json.dumps(out,indent=2))

from flint import arb,ctx
ctx.prec=192
def mirror(a,regular=False):
 L=arb.pi()/6
 c=L.cos();s=L.sin();d=(L-a).cos()
 m=a if regular else ((1+c/d)/2).acos()
 assert 0<m<L and 0<a<L
 if regular:assert (a-arb.pi()/9).contains(0) and ((2*a.cos()-1)*d-c).contains(0)
 else:assert m<a
 def integr(C,P,Q,l,r):
  def prim(x):
   return C*C*x+2*C*(P*x.sin()-Q*x.cos())+(P*P-Q*Q)*(2*x).sin()/2-P*Q*(2*x).cos()
  return prim(r)-prim(l)
 z=arb(0);g=arb(1)/2
 return m,3*(integr(z,g,g*s/c,z,L)+integr(z,g,g*s/c-(L-m).sin()/c,z,m)
             +integr(arb(1),-g*c/d,-g*s/d,m,a)+integr(z,g*c/d,g*s/d,a,L))
if __name__=='__main__':
 for v in [21,24,27,28,28.45,29,29.9]:
  print(v,mirror(arb(str(v))*arb.pi()/180)[1])

"""Reconstruct a rational polygon enclosing two complete curvature profiles and a fixed base."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
from decimal import Decimal, getcontext

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from flint import arb,ctx
from profile_source import Profile

SCALE=10**12
N=16384
PAD=18400
B=F('.844082046521218581802948589770767704354')
sources={'profile-next-16-16601.json':'678e9b6ab849782d89f33cbaa36a060040c5f75a5fe9067107296813652187fd','profile-next-24-3489.json':'9a610c360a0d47bb1af8b1c021e78858e9721b0f9ccffa41d765f5a0f2eb258b'}
def digest(name):
 return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def read(name):return json.loads((ROOT/name).read_bytes())
def decimal(x):return str(Decimal(x.numerator)/Decimal(x.denominator))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def convex(points):
 def side(seq):
  chain=[]
  for p in seq:
   while len(chain)>=2 and cross(chain[-2],chain[-1],p)<=0:chain.pop()
   chain.append(p)
  return chain[:-1]
 ordered=sorted(set(points))
 return side(ordered)+side(reversed(ordered))
def area(points,den=SCALE):
 return F(sum(x*v-y*u for (x,y),(u,v) in zip(points,points[1:]+points[:1])),2*den**2)
def buffered(points,pad):
 return [(x+i*pad,y+j*pad) for x,y in points for i in (-1,1) for j in (-1,1)]
def A(x):x=F(x);return arb(x.numerator)/x.denominator
def rounded(z):
 t=z*SCALE;m,e=map(int,t.mid().man_exp())
 k=round(F(m)*F(2)**e)
 assert abs(t-k)<1
 return k
def material(name,pose):
 assert digest(name)==sources[name]
 w=Profile(read(name))
 c=A(pose['q']);sn=2*c/(1+c*c);cs=(1-c*c)/(1+c*c)
 if pose['halfturn']:sn,cs=-sn,-cs
 s=pose['hand'];assert s in (-1,1)
 tx,ty=map(A,[pose['tx'],pose['ty']])
 cloud=[]
 for i in range(N):
  y,d=w.at(2*i,N)
  si,co=(2*arb.pi()*i/N).sin_cos()
  x=(A('.5')+y)*co-d*si
  z=s*((A('.5')+y)*si+d*co)
  cloud.append((rounded(tx+cs*x-sn*z),rounded(ty+sn*x+cs*z)))
 return convex(cloud)
def offsets(radius):
 # Circumscribed integer 32-gon, with every side checked against the entire disk.
 count=32
 R=(arb(radius)+2)/(arb.pi()/count).cos()
 points=[]
 for j in range(count):
  sn,cs=(2*j*arb.pi()/count).sin_cos()
  points.append((rounded(R*cs/SCALE),rounded(R*sn/SCALE)))
 pts=convex(points)
 assert len(pts)==count
 for p,q in zip(pts,pts[1:]+pts[:1]):
  z=cross(p,q,(0,0))
  assert z>0 and z*z>=radius*radius*((p[0]-q[0])**2+(p[1]-q[1])**2)
 return pts
def sum_hull(P,Q):
 # Boundary edge directions of a Minkowski sum are the merged ordered lists.
 def start(p):return min(range(len(p)),key=lambda i:(p[i][1],p[i][0]))
 def ordered(p):
  k=start(p);return p[k:]+p[:k]
 p,q=ordered(P),ordered(Q)
 edges=[]
 for poly in (p,q):
  edges.extend((b[0]-a[0],b[1]-a[1]) for a,b in zip(poly,poly[1:]+poly[:1]))
 from functools import cmp_to_key
 def compare(v,w):
  hv=(v[1]<0 or (v[1]==0 and v[0]<0));hw=(w[1]<0 or (w[1]==0 and w[0]<0))
  if hv!=hw:return 1 if hv else -1
  z=v[0]*w[1]-v[1]*w[0]
  return (z<0)-(z>0)
 x,y=p[0][0]+q[0][0],p[0][1]+q[0][1]
 pts=[(x,y)]
 for dx,dy in sorted(edges,key=cmp_to_key(compare)):
  x+=dx;y+=dy;pts.append((x,y))
 assert pts[-1]==pts[0]
 return convex(pts)
def check_host(poly):
 assert poly==convex(poly)
 assert all(max(map(abs,p))<SCALE for p in poly)
def ccw(poly):
 ordered=convex(poly);k=poly.index(ordered[0])
 assert poly[k:]+poly[:k]==ordered
 low=min(cross(p,q,r) for p,q,r in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
 assert low>0
 return low
def save(name,poly):
 check_host(poly)
 raw=(json.dumps(dict(denominator=SCALE,vertices=poly),separators=(',',':'))+'\n').encode()
 dst=ROOT/name
 if dst.exists():assert dst.read_bytes()==raw,name
 else:dst.write_bytes(raw)
 return dict(vertices=len(poly),minimum_integer_ccw_turn=ccw(poly),area=decimal(area(poly)),budget_slack=decimal(B-area(poly)),sha256=digest(name))
def certify_cyclic():
 from green_static import bndnormal
 src=read('canonical.json');assert src['denominator']==SCALE
 poly=[tuple(x) for x in src['vertices']]
 assert len(set(poly))==len(poly) and len(convex(poly))==len(poly)
 rows=read("duals.json");assert len(rows)==len(poly)
 assert all(len(row)==2 and all(type(i) is int for i in row) for row in rows)
 margins=[]
 assert all(cross(p,q,r)>0 for p,q,r in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
 for p,q,row in zip(poly,poly[1:]+poly[:1],rows,strict=True):
  n=(q[1]-p[1],p[0]-q[0]);length=arb(n[0]*n[0]+n[1]*n[1]).sqrt()
  H,_=bndnormal(n,row)
  sl=(arb(p[0]*n[0]+p[1]*n[1])/SCALE)/length-H
  assert sl>A('4e-10');margins.append(sl.lower())
 assert F('.83480')<area(poly)<F('.834805')
 return poly,dict(vertices=len(poly),minimum_integer_ccw_turn=ccw(poly),sha256=digest('canonical.json'),area=decimal(area(poly)),min_clearance=str(min(margins)))
def run():
 assert __debug__
 ctx.prec=180;getcontext().prec=80
 assert digest('profile_source.py')=='2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'
 assert digest('host.json')=='8695e92952545902f693ecb4874dc07a2cad673a1c84e76679e1abea85dcee33'
 source=read('host.json');assert source['denominator']==SCALE
 base=[tuple(p) for p in source['vertices']];assert len(base)==2340 and set(base)==set(convex(base))
 c3,record=certify_cyclic()
 assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
 conf=read('poses.json');assert set(conf)==set(sources)
 profiles=convex(buffered(convex(p for name in sources for p in material(name,conf[name])),PAD))
 static=convex(base+profiles)
 tight=convex(static+c3)
 assert area(tight)<B
 lo,hi=100,20000000
 def extra(rad):
  return convex(static+sum_hull(c3,offsets(rad)))
 assert area(extra(lo))<B<area(extra(hi))
 step=10000
 lo,hi=0,2000
 while hi-lo>1:
  k=(lo+hi)//2
  if area(extra(k*step))<B:lo=k
  else:hi=k
 r=lo*step;off=offsets(r);rob=extra(r)
 assert rob==convex(static+[(x+u,y+v) for x,y in c3 for u,v in off])
 assert area(rob)<B
 out=dict(canonical=record,full=save('host-all.json',tight),thick=save('host-thick.json',rob),
          radius=decimal(F(r,SCALE)),near_threefold_hausdorff_defect=decimal(F(3*r,2*SCALE)),
          old_area=decimal(area(base)),poses=conf)
 from mirror_area import mirror
 ctx.prec=192
 d3=mirror(arb.pi()/9,True)[1]
 assert A('.8297484084862655136918149558308608105093757037358171424')<d3<A('.8297484084862655136918149558308608105093757037358171426')
 out['exact_D3_generators_area']=str(d3)
 return out
if __name__=='__main__':
 out=run()
 if (ROOT/'receipt.json').exists():assert out==read('receipt.json')
 print(json.dumps(out,indent=2))

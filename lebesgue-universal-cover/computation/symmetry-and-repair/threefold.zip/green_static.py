from fractions import Fraction as F
from pathlib import Path
from bisect import bisect_left
import json,math
from flint import arb,ctx
ctx.prec=180
pi=arb.pi();T=pi/3;anchor=pi*631/3600
def A(t):
 t=F(t);return arb(t.numerator)/t.denominator
def yx(u,x):
 return (u if u<x else x).sin()*(T-(x if u<x else u)).sin()/T.sin()
def bound(x,pars):
 lam,beta=[arb(v)/10**9 for v in pars];assert lam>=0
 def f(u):return yx(u,x)-lam*yx(u,anchor)-beta*(u-T/2).sin()
 nodes=sorted([arb(0),anchor,x,T],key=float)
 ret=arb(0)
 for l,r in zip(nodes,nodes[1:]):
  d=r-l;u,v=f(l),f(r)
  if u*v<0 and d>0:
   if u<0:u,v=-u,-v
   w=arb.atan2(u*d.sin(),u*d.cos()-v)
   ret+=u*(w/2).tan()-v*((d-w)/2).tan()
  else:
   ret+=(abs(u)+abs(v))*(d/2).tan()
 return ret/2
def bndnormal(n,pars):
 X,Y=n
 if Y==0:return arb(1)/2,(0,0)
 u=arb.atan2(arb(Y),arb(X))
 if u<0:u+=2*pi
 k=int(float(u/T));x=u-k*T
 assert 0<x<T
 if k%2:
  assert x<anchor or x>anchor
  return arb(1)/2+bound(x,pars),pars
 return (x-T/2).cos()/(2*(T/2).cos()),(0,0)

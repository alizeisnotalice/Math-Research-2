# Two exact width-one bodies omitted by the fixed 2335-vertex host

The exact rational host `host.json` has SHA-256 `32f64cf2d5e2aa180a0a65bde66102bdfc4564c48a2e68fe209a92806bd3e383`. It is the predecessor of the 2340-vertex repair.

For either hand and every rotation and translation, the largest Euclidean distance of the 8952 body from this host is greater than (2.43734\times10^{-7}). For the 2206 body the corresponding lower bound is (6.75439\times10^{-8}). The two complete closed angle covers have 102 cells per hand and 105 cells per hand, respectively.

The verifier checks legal width-one curvature and evaluates true material points. Each row balances exact rational weights against exact integer normals. This cancels translation. Support for the host is maximized over its actual rational vertices. Positive sine interpolation of the endpoints proves the strict comparison throughout every closed angle cell. Projection gaps are divided by the directed weighted sum of Euclidean normal lengths.

The original 94 rows gave inconclusive near-zero readings for 2206. A numerical translation program against every actual host face selected additional normals. Twelve further exact rows were formed by integer cross products. The all-angle proof checks those rows independently of the numerical optimizer.

Run with an existing Python and python-flint.

```sh
sha256sum -c SHA256SUMS
PY -I -B certify.py profile16-8952.json plan8952.json OUT8952.json --gap 1.6e-7
PY -I -B certify.py profile16-2206.json plan2206.json OUT2206.json --gap 5e-8
```

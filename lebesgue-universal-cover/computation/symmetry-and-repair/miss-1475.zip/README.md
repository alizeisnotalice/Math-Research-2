# Two exact curvature bodies omitted by the fixed 1475-edge repair

The fixed rational host is `host.json` with SHA-256 `27ad907e5f6ee896d28ca37b28dd04d6d52e14379addc899aeb55758eacebfe9`. It is the enclosure that contains the original 1488-edge polygon, the two finite point groups, and both previously used whole curvature profiles. The two new inputs in this archive use different curvature coefficients.

Both inputs are exact width-one convex bodies. The input lists the knots and constant values of (h+h''-1/2) over a half turn. The source kernel solves the three unspecified coefficients and an initial derivative using the periodic closure and pin equations. The directed calculation checks that the radius of curvature lies between zero and one.

Every possible rotation and translation, including either hand, is excluded for each body. The 16-piece input uses 91 closed angle intervals per hand. The 24-piece input uses 90 and 92. The minimum normalized projection gap is greater than (1.29047\times10^{-6}) and (1.08991\times10^{-6}), respectively.

The 94 candidate rows carry exact integer normals and nonnegative rational weights. The verifier checks zero vector sum in each row and computes the host support in each normal direction from the actual rational vertices. On each recorded interval, the certificate uses four exact profile material points to lower bound the body support. The sum of their rotated projections exceeds the host-side constant at both endpoints. Angular interpolation uses positive sine coefficients whose sum is at least one, so the strict excess holds throughout the interval. Translation cancels exactly in the balanced sum. The normalization makes the gaps also lower bounds for the largest Euclidean distance from the moved body to the host.

The proof concerns containment in the fixed polygon. Convex enlargements have their own area budget.

The two runs below require Python and python-flint. They read the exact closed partitions and do not need NumPy. The optional `--search` flag regenerates a partition using floating-point rankings to choose which rows to test. Acceptance still uses directed computations.

```sh
sha256sum -c SHA256SUMS
PY -I -B certify.py profile16-16206.json plan16.json OUT16.json
PY -I -B certify.py profile24-33268.json plan24.json OUT24.json
```

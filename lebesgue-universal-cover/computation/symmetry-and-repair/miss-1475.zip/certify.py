"""Prove free noncontainment of a true curvature body in the fixed repair."""

import argparse
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb, ctx, __version__ as flint_version

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from profile_source import Profile

HOST_SHA = "27ad907e5f6ee896d28ca37b28dd04d6d52e14379addc899aeb55758eacebfe9"
PROFILE_SHA = "2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646"
THRESHOLD = F("1e-6")


def A(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def data(profile):
    assert digest(HERE/"host.json")==HOST_SHA and digest(HERE/"profile_source.py")==PROFILE_SHA
    doc=read(HERE/"host.json")
    denominator=doc["denominator"]
    host=doc["vertices"]
    assert type(denominator) is int and denominator>0
    assert all(len(p)==2 and all(type(x) is int for x in p) for p in host)
    rows=read(HERE/"balanced-rows.json")
    heights={}

    def height(n):
        if n not in heights:
            nx,ny=n
            heights[n]=F(max(nx*x+ny*y for x,y in host),denominator)
        return heights[n]

    cap=[]
    for row in rows:
        normals=[tuple(n) for n in row["normals"]]
        w=list(map(F,row["weights"]))
        assert len(normals)==len(w)==4 and all(x>=0 for x in w)
        assert all(len(n)==2 and all(type(x) is int for x in n) for n in normals)
        assert all(sum(v*n[k] for v,n in zip(w,normals,strict=True))==0 for k in (0,1))
        assert sum(v*sum(map(abs,n)) for v,n in zip(w,normals,strict=True))==1
        const=sum(v*height(n) for v,n in zip(w,normals,strict=True))
        assert const>0
        coeff=[(A(nx*v),A(ny*v)) for v,(nx,ny) in zip(w,normals,strict=True)]
        cap.append((const,coeff))
    return Profile(read(profile)),rows,cap


def kernel(prof,cap):
    @cache
    def trig(a):
        s,c=(arb.pi()*A(a)/180).sin_cos()
        return c,s

    @cache
    def material(a):
        a=F(a)%360
        v=a/180
        y,d=prof.at(v.numerator,v.denominator)
        c,s=trig(a)
        return (A(".5")+y)*c-d*s,(A(".5")+y)*s+d*c

    def bound(a,b,hand,index,angles):
        const,weights=cap[index]
        rational_angles=list(map(F,angles))
        assert len(rational_angles)==4
        sx=arb(0)
        sy=arb(0)
        for (nx,ny),t in zip(weights,rational_angles,strict=True):
            x,y=material(t)
            y*=hand
            sx+=nx*x+ny*y
            sy+=ny*x-nx*y
        ends=[]
        for t in (a,b):
            c,s=trig(t)
            ends.append((sx*c+sy*s-A(const)).lower())
        return min(ends)

    return bound


def find_plan(prof,rows,cap,bound):
    import numpy as np

    normal=np.array([row["normals"] for row in rows],dtype=float)
    lengths=np.linalg.norm(normal,axis=2)
    angles=np.rad2deg(np.arctan2(normal[:,:,1],normal[:,:,0]))
    weight=lengths*np.array([[float(F(w)) for w in row["weights"]] for row in rows])
    constant=np.array([float(r[0]) for r in cap])
    knots=np.asarray(prof.bounds,dtype=float)*np.pi/prof.grid
    mid=lambda x:float(x.mid())
    f=np.array([mid(x) for x in prof.fs])
    y,v=np.array([[mid(x) for x in s] for s in prof.states[:-1]]).T

    def rank(a,hand):
        angle=np.deg2rad((hand*(angles-float(a)))%360)
        sign=np.where(angle<np.pi,1.,-1.)
        k=np.clip(np.searchsorted(knots,angle%np.pi,side="right")-1,0,len(f)-1)
        step=angle%np.pi-knots[k]
        h=.5+sign*(f[k]+(y[k]-f[k])*np.cos(step)+v[k]*np.sin(step))
        return np.argsort((weight*h).sum(axis=1)-constant)[::-1]

    out={}
    for hand in (1,-1):
        cells=[]
        def visit(a,b,depth):
            m=(a+b)/2
            for j0 in rank(m,hand)[:8]:
                j=int(j0)
                p=[str(F(f"{(hand*(t-float(m)))%360:.9f}")) for t in angles[j]]
                if bound(a,b,hand,j,p)>A(THRESHOLD):
                    cells.append([str(a),str(b),j,p])
                    return
            assert depth<22,(hand,str(a),str(b),[int(x) for x in rank(m,hand)[:4]])
            visit(a,m,depth+1)
            visit(m,b,depth+1)
        for i in range(0,360,5):
            visit(F(i),F(i+5),0)
        out[str(hand)]=cells
    return out


def verify(cap,bound,plan):
    out={}
    for hand in (1,-1):
        right=F(0)
        lows=[]
        count=0
        for a,b,index,angles in plan[str(hand)]:
            a,b=map(F,(a,b))
            assert a==right and 0<b-a<180 and 0<=index<len(cap)
            q=bound(a,b,hand,index,angles)
            assert q>A(THRESHOLD),(hand,str(a),str(b),str(q))
            lows.append(q)
            count+=1
            right=b
        assert right==360 and count>0
        out[str(hand)]=dict(checked_closed_cells=count,minimum_strict_endpoint_gap=str(min(lows)),
                           normals_rows_used=len({r[2] for r in plan[str(hand)]}))
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ("profile","plan","receipt"):
        parser.add_argument(key,type=Path)
    parser.add_argument("--search",action="store_true")
    args=parser.parse_args()
    assert __debug__
    ctx.prec=192
    prof,rows,cap=data(args.profile)
    bound=kernel(prof,cap)
    if args.search:
        plan=find_plan(prof,rows,cap,bound)
        args.plan.write_text(json.dumps(plan,separators=(",",":"))+"\n")
    else:
        plan=read(args.plan)
    hands=verify(cap,bound,plan)
    receipt=dict(complete=True,geometry="Fixed rational curve repair polygon, free rotations/translations and both hands",
                 row_normalization="sum(q_i*norm_1(n_i))=1 and exact sum(q_i*n_i)=0",
                 directed_margin_threshold=str(THRESHOLD),directed_Euclidean_gap_lower=str(THRESHOLD),host_sha256=HOST_SHA,profile_sha256=digest(args.profile),
                 profile_source_sha256=PROFILE_SHA,plan_sha256=digest(args.plan),rows_sha256=digest(HERE/"balanced-rows.json"),
                 verifier_sha256=digest(Path(__file__)),hands=hands,profile_pieces=len(prof.fs),
                 maximum_abs_halfturn_f=str(max(abs(x).upper() for x in prof.fs)),
                 flint=flint_version,precision=ctx.prec)
    args.receipt.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(hands),flush=True)


if __name__=="__main__":
    main()

"""Check all constant-width support trigonometric polynomials of degree at most five."""
from flint import arb,ctx
from fractions import Fraction as F
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
def A(x):
 x=F(x);return arb(x.numerator)/x.denominator
def load(name):return json.loads((ROOT/name).read_bytes())
def main():
 assert __debug__
 ctx.prec=160;pi=arb.pi();T=pi/3;den=10**12
 assert hashlib.sha256((ROOT/'host.json').read_bytes()).hexdigest()=='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'
 src=load('host.json');poly=src['vertices'];assert src['denominator']==den
 H=[((T*(A(1)/2+j)).cos()/arb(3).sqrt(),(T*(A(1)/2+j)).sin()/arb(3).sqrt()) for j in range(6)]
 rows=[[] for _ in range(12)]
 minimum=float('inf');uncut=0;disk=arb(1)
 for p,q in zip(poly,poly[1:]+poly[:1]):
  nx,ny=q[1]-p[1],p[0]-q[0];length=arb(nx*nx+ny*ny).sqrt()
  hp=arb(nx*p[0]+ny*p[1])/den;cap=hp/length-A('.5');assert cap>0
  disk=min(disk,cap.lower())
  if all(nx*x+ny*y<hp for x,y in H):
   uncut+=1;continue
  ang=arb.atan2(arb(ny),arb(nx))
  ss=abs((3*ang).sin());assert ss>0
  k=0
  for s in (1,-1):
   for j in range(6):
    z=s*(ang-j*T);sn=(3*z).sin();assert sn>0 or sn<0
    st,ct=(2*z).sin_cos()
    rows[k].append((1 if sn>0 else -1,st,ct,(cap/ss).lower()));k+=1
 leaves=0;counts=[0]*12;global_min=arb(1);norm_min=arb(1)
 def process(node,p0,p1,q0,q1):
  nonlocal leaves,global_min,norm_min
  act,left,right=node
  if act=='p':
   pm=(p0+p1)/2;process(left,p0,pm,q0,q1);process(right,pm,p1,q0,q1);return
  if act=='q':
   qm=(q0+q1)/2;process(left,p0,p1,q0,qm);process(right,p0,p1,qm,q1);return
  k,j,sg=node;assert 0<=k<12 and 0<=j<144 and sg in (-1,1)
  p=A((p0+p1)/2);ph=pi*(A(q0)+A(q1))
  dp=A(p1-p0)/2;da=pi*A(q1-q0);theta=2*pi*j/144
  M=sg*(p*(3*theta).sin()+(1-p)*(5*theta-ph).cos())-2*dp-(1-A(p0))*da
  assert M>0;norm_min=min(norm_min,M.lower())
  dE=(A(1)/8+A(1)/12)*dp+(1-A(p0))*da/12
  sf,cf=ph.sin_cos()
  # Precompute the phase factors and radial coefficients once per certified rectangle.
  c0=p/8;c1=(1-p)*cf/12;c2=(1-p)*sf/12
  sl=min((2*M*w-s*(c0-c1*st+c2*ct)-dE).lower() for s,st,ct,w in rows[k])
  assert sl>A('1e-9'),(node,str(sl))
  global_min=min(global_min,sl);counts[k]+=1;leaves+=1
 process(load('tree.json'),F(0),F(1),F(0),F(1))
 return dict(leaves=leaves,hand_angle_counts=counts,full_host_faces=len(poly),hexagon_trivial_faces=uncut,remaining_true_faces=len(rows[0]),minimum_scaled_support_margin=str(global_min),minimum_curvature_norm_lower=str(norm_min),disk_margin=str(disk),profile='all real constant-width-one trigonometric supports of degree <= 5')
if __name__=='__main__':
 res=main()
 if (ROOT/'receipt.json').exists():assert res==load('receipt.json')
 print(json.dumps(res,indent=2))

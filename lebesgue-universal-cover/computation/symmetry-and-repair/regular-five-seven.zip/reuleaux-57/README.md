# Two regular Reuleaux bodies in the fixed 1189-edge host

The fixed rational polygon host-all.json is the 1189-edge joint C3 host, SHA-256 a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f. The script certifies that the regular Reuleaux 5-gon and 7-gon each have a fixed rigid placement strictly inside this same polygon. The script does not claim that every C5- or C7-invariant diameter-one body fits.

For odd m=5 or 7 the body is the intersection of unit disks centered at a regular m-gon with circumradius 1/(2 cos(pi/(2m))). Its diameter is one, and it has m-fold rotation symmetry. The actual rotation is specified exactly by the rational tangent of its half-angle and translation by rational coordinates in verify_reuleaux.py.

For each host normal, every possible support maximum of the disk intersection lies either at a stationary point of a circular boundary arc or at a pairwise circle intersection. All pairwise intersections are computed in Arb and an intersection is discarded only if strictly outside another disk; all remaining points provide upper bounds. The same conservative test is applied to circle stationary points. The maximum of the directed upper endpoints is compared with the exact host edge support; all vertices against all edges are verified by integer arithmetic. The minimum certified gaps are >3.84697e-7 (m=5) and >1.89440e-7 (m=7).

Run with Python 3.13.18 / python-flint 0.9.0:

    python -I -B verify_reuleaux.py OUTPUT.json

The polygons were found using floating point optimization; the proof depends only on the exact rational pose and the interval verification.

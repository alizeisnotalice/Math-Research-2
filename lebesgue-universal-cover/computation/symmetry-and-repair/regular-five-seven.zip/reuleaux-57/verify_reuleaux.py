"""Verify two fixed regular Reuleaux placements in the 1189-edge host."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
ctx.prec=192
root=Path(__file__).resolve().parent; raw=(root/'host-all.json').read_bytes();sha='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f';assert sha256(raw).hexdigest()==sha
obj=json.loads(raw);V=obj['vertices'];den=obj['denominator'];assert den==10**12 and len(V)==1189
assert all((V[(i+1)%len(V)][0]-V[i][0])*(V[(i+2)%len(V)][1]-V[(i+1)%len(V)][1])-(V[(i+1)%len(V)][1]-V[i][1])*(V[(i+2)%len(V)][0]-V[(i+1)%len(V)][0])>0 for i in range(len(V)))
def A(x):
 x=F(x);return arb(x.numerator)/x.denominator
def rot(x,y,c,s):return c*x-s*y,s*x+c*y
# Rational tan(θ/2) and translation, independently rounded from floating proposals.
poses={5:('0.1583771603376','-0.00000212278036','0.0263864858'),7:('0.3499198997057','-0.000000934490404','0.0131921958')}
out={}
for m,(k,tx,ty) in poses.items():
 k,tx,ty=map(A,(k,tx,ty));co=(1-k*k)/(1+k*k);sn=2*k/(1+k*k)
 R=1/(2*(arb.pi()/(2*m)).cos());centers=[]
 for j in range(m):
  s,c=(2*j*arb.pi()/m).sin_cos();centers.append(rot(R*c,R*s,co,sn))
 # Every boundary corner of the disk intersection is a pairwise circle intersection.
 corners=[]
 for j in range(m):
  for l in range(j+1,m):
   x,y=centers[j];X,Y=centers[l];dx,dy=X-x,Y-y;d2=dx*dx+dy*dy
   assert d2>0 and d2<4
   fac=(1/d2-arb(1)/4).sqrt()
   for sign in (-1,1):
    c=((x+X)/2-sign*dy*fac,(y+Y)/2+sign*dx*fac)
    if any((c[0]-X0)**2+(c[1]-Y0)**2>1 for X0,Y0 in centers):continue
    corners.append(c)
 assert corners
 least=None;arc_excluded=0
 for i,(x,y) in enumerate(V):
  xx,yy=V[(i+1)%len(V)];nx,ny=yy-y,x-xx;norm=arb(nx*nx+ny*ny).sqrt();ux,uy=arb(nx)/norm,arb(ny)/norm
  assert all(nx*X+ny*Y <= nx*x+ny*y for X,Y in V)
  h=(arb(nx*x+ny*y)/den)/norm-(ux*tx+uy*ty)
  candidates=[ux*cx+uy*cy for cx,cy in corners]
  for cx,cy in centers:
   X,Y=cx+ux,cy+uy
   # If definitely outside any disk this circle point cannot be on the boundary.
   if any((X-dx)**2+(Y-dy)**2>1 for dx,dy in centers):arc_excluded+=1;continue
   candidates.append(ux*cx+uy*cy+1)
  low=(h-max(v.upper() for v in candidates)).lower();assert low>0,(m,i,str(low))
  least=low if least is None else min(least,low)
 out[str(m)]={'margin_lower':str(least),'circle_candidates_excluded':arc_excluded,'tan_half_angle':str(k),'translation':[str(tx),str(ty)]}
print(json.dumps(out,indent=2));Path(sys.argv[1]).write_text(json.dumps({'host_sha256':sha,'placements':out},indent=2)+'\n')

# Two exact width-one bodies omitted by the fixed 2340-vertex host

The fixed rational host is `host.json` with SHA-256 `8695e92952545902f693ecb4874dc07a2cad673a1c84e76679e1abea85dcee33`. Its closed convex hull is taken at the displayed integer coordinates divided by the explicit denominator.

The 16-piece input is `profile-next-16-16601.json`. For every rotation, reflection and translation its largest Euclidean point-to-host distance is strictly greater than (4.28523\times10^{-6}). The 24-piece input `profile-next-24-3489.json` gives a strict lower bound (2.43724\times10^{-6}). These statements concern the fixed host. A convex enlargement changes its support function.

The input lists the knots and constant values of (h+h''-1/2) over a half turn. The source kernel solves three free coefficients and an initial derivative from the periodic closure and pin equations. The directed calculation checks that the curvature radius lies between zero and one.

The 94 candidate rows use integer normals and nonnegative rational weights with zero weighted sum. Host support is computed exactly from its 2340 actual rational vertices. On each closed angle cell, four exact material points certify at each endpoint that the weighted sum of their rotated projections exceeds the weighted host support. Sine interpolation on an interval shorter than a half turn has positive coefficients with sum at least one, so it gives the same strict lower bound throughout that interval. Translation cancels exactly. Dividing by the directed weighted sum of the Euclidean normal lengths gives a lower bound for the largest Euclidean distance of a moved point from the host.

The 16-piece proof covers 105 closed intervals for each hand. The 24-piece proof covers 104 for the proper hand and 105 for the reflected hand. Both proofs cover all angles modulo a complete turn.

With an existing Python and python-flint, run the commands below. The proof reads the exact closed partitions and does not use NumPy. The optional `--search` flag regenerates a partition, using floating-point rankings solely to select which rows to test by interval arithmetic.

```sh
sha256sum -c SHA256SUMS
PY -I -B certify.py profile-next-16-16601.json plan16.json OUT16.json --gap 4.2e-6
PY -I -B certify.py profile-next-24-3489.json plan24.json OUT24.json --gap 2.4e-6
```

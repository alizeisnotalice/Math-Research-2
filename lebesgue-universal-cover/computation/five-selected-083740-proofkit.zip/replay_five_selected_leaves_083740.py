"""Rebuild a pure five-body affine-area proof on selected original 11D boxes at .83740."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import struct
import sys

for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[variable] = "1"

import numpy as np
from flint import ctx
SOURCE = Path(__file__).resolve().parent
sys.path.insert(0, str(SOURCE))
import tomar_dynamic_five as dynamic
from tomar_leaf_box import leaf_box

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def main():
    if not __debug__:
        raise SystemExit("Run with Python assertions enabled.")
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("checkout", "cert", "work", "cache"):
        parser.add_argument(key, type=Path)
    parser.add_argument("--positions", nargs="+", type=int, default=[139716,151617,139730,152529])
    parser.add_argument("--budget", type=int, help="override the archived per-leaf visit budgets")
    args = parser.parse_args()
    args.work.mkdir(parents=True, exist_ok=True)
    up = args.checkout.resolve()
    revision = "10af98606c98ca9ffd0d9f402cae1e2efe74b792"
    for file in ("gen8.py", "gen11.py"):
        path = "independent/" + file
        assert subprocess.check_output(["git", "-C", up, "show", revision + ":" + path]) == (up / path).read_bytes()
    pins = args.cert / "SHA256SUMS"
    assert digest(pins) == "56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410"
    manifest = {n.removeprefix("./"): h for h, n in (row.split() for row in pins.read_text().splitlines())}
    for file in ("part0000.json", "part1205.json", "part1205.npy"):
        assert digest(args.cert / file) == manifest[file]
    part = 1205
    header = json.loads((args.cert / "part1205.json").read_bytes())
    codes = np.load(args.cert / "part1205.npy", allow_pickle=False)
    assert header["part"] == part and header["ns"] == [3, 5, 7, 9]
    prefix = np.r_[1, 1 + np.cumsum(np.where(codes < 11, 1, -1))]
    assert prefix[-1] == 0 and np.min(prefix[:-1]) == 1
    kernel = SOURCE / "tomar_dynamic_affine.cpp"
    library = (args.work / "lib-five-three-leaves.so").resolve()
    flags = ["-O3", "-std=c++17", "-ftrapv", "-shared", "-fPIC", f"-fmodules-cache-path={args.cache}"]
    subprocess.run(["clang++", *flags, kernel, "-o", library], check=True)
    sys.path.insert(0, str(up / "independent"))
    import gen11
    ctx.prec = 144
    target = "0.83740"
    dynamic.configure(up, args.cert, library, target)
    assert dynamic.gen8.placements is gen11.placements
    names = ("tomar_dynamic_five.py", "tomar_dynamic_affine.cpp", "tomar_leaf_box.py")
    identity = {n: digest(SOURCE / n) for n in names}
    complete = True
    original_contract = dynamic.contract
    for pos in args.positions:
        assert codes[pos] >= 11
        center, half = leaf_box(prefix, codes, part, pos, header)
        ends = [(Fraction(v) + sign*Fraction(w)) * 2**44 for sign in (-1,1) for v,w in zip(center,half)]
        assert all(t.denominator == 1 for t in ends)
        root = list(map(int,ends))
        # Each trace contains one flag and the split-axis proposal per visit.
        # On contraction store the new exact endpoints; all remaining box
        # endpoints follow deterministically from the root and split rule.
        trace = bytearray()
        def recorded_contract(lo, hi, samples):
            output = original_contract(lo, hi, samples)
            kind, axis, new_lo, new_hi, cuts = output
            narrowed = kind == 0 and (np.any(new_lo != lo) or np.any(new_hi != hi))
            trace.extend(struct.pack("<Bbb", int(narrowed), int(kind), int(axis)))
            if narrowed:
                trace.extend(struct.pack("<22q", *new_lo.tolist(), *new_hi.tolist()))
            return output
        dynamic.contract = recorded_contract
        budget = args.budget or (16384 if pos == 152529 else 2048)
        result = dynamic.work((pos, "original", root, budget, 160))
        path = args.work / f"part{part}-pos{pos}.bin"
        path.write_bytes(trace)
        assert result["splits"] + 1 == sum(result["closed"].values()) + len(result["remaining"])
        row = dict(part=part, pos=pos, threshold=target, original_header_sha256=manifest["part1205.json"],
                   original_tree_sha256=manifest["part1205.npy"], upstream=revision, sources=identity,
                   root=root, budget=budget, depth=160, trace_sha256=digest(path), result=result)
        (args.work / f"part{part}-pos{pos}.json").write_text(json.dumps(row,indent=2)+"\n")
        print(pos, result["vis"], len(result["remaining"]), result["closed"], flush=True)
        complete &= not result["remaining"]
    if not complete:
        raise SystemExit(2)

if __name__ == "__main__":
    main()

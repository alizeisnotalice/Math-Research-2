Four original 11D boxes in part 1205 have pure five-body hull area strictly above 0.83740. All closed boxes in the respective original trees are included; no canonical, radial, or basin clipping is used.
Prerequisites: Python with numpy, scipy and python-flint, clang++, git, pinned upstream 10af98606c98ca9ffd0d9f402cae1e2efe74b792 and cert11d_08366 from the public supplement.
Run in this directory, using an empty writable WORK and desired compiler cache:
python -I -B replay_five_selected_leaves_083740.py UPSTREAM CERT WORK CLANG_CACHE
python -I -B verify_five_selected_083740_traces.py WORK --expect expected
The second command reconstructs every branch with integer width weights, checks counts and absence of unresolved branches and compares the full recalculated per-leaf metadata and trace digest to the expected ones.

"""Directed comparisons of circular support branches on closed angle intervals."""
from fractions import Fraction as F
from functools import lru_cache

from flint import arb
from local_support import A,Arc,angle,core_vertices,direction,dot,sub


def perp(u):
    return -u[1],u[0]


def visible_parts(core):
    labels,points,centers=core_vertices(core)
    art=[]
    for name,v in zip(labels,points):
        if all(h-dot(n,v)>0 for _,n,h in core['otherEH']):
            art.append([Arc('core:'+name, arb(0), arb(360),v,arb(0))])
    ta=next(x[0] for x in art if x[0].label=='core:Ta')
    assert all(h-dot(n,ta.center)>0 for _,n,h in core['otherEH'])
    inward=angle(sub(points[3],centers[2]))
    tx,ty=sub(points[4],points[3]);outward=angle((ty,-tx))
    assert 90<inward<outward<130
    return art,ta,(inward,outward)


def intersect(a,b,*arcs):
    left=max(a,*(x.lo.lower() for x in arcs))
    right=min(b,*(x.hi.upper() for x in arcs))
    if left<=right:
        return left,right


def possible(arcs,a,b):
    return [x for x in arcs if not (x.lo>b or x.hi<a)]


@lru_cache(maxsize=10000)
def centered_interval(a,b):
    mid=(a+b)/2
    u=direction(mid)
    rad=(b-a)*arb.pi()/360
    assert rad<arb.pi()/2
    co=rad.cos().union(arb(1))
    si=rad.sin()
    return u,co,(-si).union(si)


def gap(p,q,a,b):
    v=sub(p.center,q.center)
    c=p.rho-q.rho
    if a==b:
        return dot(v,direction(a))+c
    # Decompose the common direction before bounding. This preserves coincident arc centers.
    m,co,si=centered_interval(a,b)
    return dot(v,m)*co+dot(v,perp(m))*si+c


def prove_exterior(bodies,X,domains):
    counts={}
    least=arb(1)
    leaves=0
    for lo,hi in domains:
        assert lo<hi
        n=int((hi-lo)//F(1,2))+1
        for j in range(n):
            a=A(lo+(hi-lo)*F(j,n))
            b=A(lo+(hi-lo)*F(j+1,n))
            new=possible(X,a,b)
            assert new
            midpoint=(a+b)/2
            u=direction(midpoint)
            old=[possible(body,a,b) for body in bodies]
            assert all(old)
            # Midpoint priorities only select tests. Every accepted inequality is directed.
            ranking=sorted(range(len(old)),key=lambda k:max(p.height(u).mid() for p in possible(old[k],midpoint,midpoint)),reverse=True)
            for k in ranking:
                comparisons=[gap(q,p,*I) for p in new for q in old[k] if (I:=intersect(a.lower(),b.upper(),p,q))]
                assert comparisons
                margin=min(d.lower() for d in comparisons)
                if margin>0:
                    leaves+=1
                    least=min(least,margin)
                    counts[k]=counts.get(k,0)+1
                    break
            else:
                raise ValueError(f'no exterior witness on [{a},{b}]')
    return dict(leaves=leaves,witness_count=counts,minimum_strict_height_gap=str(least))



def preclip_core(core):
    # The convex preclip boundary consists of the original vertices, their
    # joining line segments, and the six certified short counterclockwise arcs.
    from local_support import periodize

    labels,vertices,centers=core_vertices(core)
    result=[Arc('preclip:'+name,arb(0),arb(360),v,arb(0)) for name,v in zip(labels,vertices)]
    for j,c in centers.items():
        v,w=sub(vertices[j],c),sub(vertices[(j+1)%len(vertices)],c)
        assert dot(v,v).contains(1) and dot(w,w).contains(1)
        assert v[0]*w[1]-v[1]*w[0]>0 and dot(v,w)>0
        a,b=angle(v),angle(w)
        if b<a:b+=360
        assert 0<b-a<90
        result.extend(periodize([Arc('preclip_arc:'+labels[j],a,b,c,arb(1))]))
    return result


def strictly_above(p,q,a,b,depth=0):
    d=gap(p,q,a,b)
    if d>0:
        return d.lower(),1
    if depth>=20 or a==b:
        raise ValueError(f'{p.label} vs {q.label} unresolved [{a},{b}]: {d}')
    mid=((a+b)/2).mid()
    assert a<mid<b
    l,n=strictly_above(p,q,a,mid,depth+1)
    r,m=strictly_above(p,q,mid,b,depth+1)
    return min(l,r),n+m


def bracketed_intersection(p,q,left,right):
    a,b=A(left),A(right)
    v=sub(p.center,q.center)
    c=p.rho-q.rho
    norm=dot(v,v).sqrt()
    assert norm>0 and abs(c)<norm
    alpha=angle(v)
    displ=(-c/norm).acos()*180/arb.pi()
    options=[alpha+s*displ+360*k for s in (1,-1) for k in (-1,0,1)]
    root,=[x for x in options if a<x<b]
    assert (dot(v,direction(root))+c).contains(0)
    return root


def increasing_difference(p,q,a,b):
    derivative=gap(Arc(p.label,p.lo,p.hi,perp(sub(q.center,p.center)),arb(0)),
                   Arc(q.label,q.lo,q.hi,(arb(0),arb(0)),arb(0)),a,b)
    assert derivative>0,(p.label,q.label,str(derivative))
    return derivative.lower()


def with_touch(p,q,a,b,root,right):
    # On the thin window the exact common tangent and the derivative sign give
    # the required closed one-sided inequality. Away from it the gap is strict.
    delta=A('1e-6')
    low=(root-delta).lower()
    high=(root+delta).upper()
    if right:
        d=increasing_difference(p,q,low,high)
        left=max(a,high)
        check=strictly_above(p,q,left,b) if left<=b else (arb(1),0)
    else:
        d=increasing_difference(q,p,low,high)
        end=min(b,low)
        check=strictly_above(p,q,a,end) if a<=end else (arb(1),0)
    return check[0],check[1]+1,d


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def green_piece(p,a,b,origin):
    ca,sa=direction(a)
    cb,sb=direction(b)
    return p.rho*(dot(sub(p.center,origin),(sb-sa,ca-cb))+p.rho*(b-a)*arb.pi()/180)


def green_delta(x,old,angles):
    l,*j,r=angles
    origin=old[0].point(direction(l))
    def at(p,t):return sub(p.point(direction(t)),origin)
    before=sum(green_piece(p,a,b,origin) for p,a,b in zip(old,angles[:-1],angles[1:],strict=True))
    before+=sum(cross(at(p,t),at(q,t)) for p,q,t in zip(old[:-1],old[1:],j,strict=True))
    after=cross(at(old[0],l),at(x,l))+green_piece(x,l,r,origin)+cross(at(x,r),at(old[-1],r))
    return (after-before)/2


def local_change(bodies,new,core):
    a,b=A('112.32'),A('115.26')
    labels=('118:3:-1:1','0:0','149:2:1','113:0')
    selected=[]
    for name in labels:
        row,=[x for x in bodies[int(name.split(':')[0])] if x.label==name and not (x.lo>b or x.hi<a)]
        selected.append(row)
    x,=[y for y in new if y.lo<a and b<y.hi]
    assert x.label=='X:0'
    switches=[bracketed_intersection(p,q,lo,hi) for (p,q),(lo,hi) in zip(zip(selected,selected[1:]),
                  [('112.3315','112.3325'),('113.306','113.307'),('113.954','113.955')],strict=True)]
    zones=list(zip([a,*switches],[*switches,b],strict=True))
    others=[p for body in bodies for p in body]+preclip_core(core)
    margins=[]
    touching=[]
    for i,(p,(l,r)) in enumerate(zip(selected,zones,strict=True)):
        assert p.lo<l and r<p.hi
        margin=arb(1)
        checks=0
        for q in others:
            if q.label==p.label:
                continue
            overlap=intersect(l.lower(),r.upper(),q)
            if overlap:
                if i and q.label==selected[i-1].label:
                    d,k,slope=with_touch(p,q,*overlap,switches[i-1],True)
                    touching.append(str(slope))
                elif i<3 and q.label==selected[i+1].label:
                    d,k,slope=with_touch(p,q,*overlap,switches[i],False)
                    touching.append(str(slope))
                else:
                    d,k=strictly_above(p,q,*overlap)
                margin=min(margin,d);checks+=k
        margins.append(dict(witness=p.label,competitor_strict_margin_lower=str(margin),checked_intervals=checks))
    L=bracketed_intersection(x,selected[0],'112.327','112.328')
    R=bracketed_intersection(x,selected[-1],'115.247','115.248')
    assert a<L<switches[0]<switches[1]<switches[2]<R<b
    _,_,dl=with_touch(selected[0],x,a.lower(),L.upper(),L,False)
    with_touch(x,selected[0],L.lower(),switches[0].upper(),L,True)
    with_touch(x,selected[-1],switches[2].lower(),R.upper(),R,False)
    _,_,dr=with_touch(selected[-1],x,R.lower(),b.upper(),R,True)
    for p,l,r in zip(selected[1:-1],switches[:-1],switches[1:],strict=True):
        strictly_above(x,p,l.lower(),r.upper())
    integral=[]
    for p,l,r in zip(selected,[L,*switches],[*switches,R],strict=True):
        ca,sa=direction(l)
        cb,sb=direction(r)
        d=sub(x.center,p.center)
        value=(x.rho+p.rho)*(dot(d,(sb-sa,ca-cb))+(x.rho-p.rho)*(r-l)*arb.pi()/180)/2
        assert value>=0
        integral.append(value)
    atoms=[]
    atomic_values=[]
    for p,q,t in zip(selected,selected[1:],switches):
        u=direction(t)
        ell=dot(sub(q.center,p.center),perp(u))
        f=x.height(u)-p.height(u)
        assert ell>0 and f>0
        atomic_values.append(f*ell/2)
        atoms.append(dict(angle_degrees=str(t),length=str(ell),gap=str(f),area=str(atomic_values[-1])))
    val=sum(integral)+sum(atomic_values)
    via_green=green_delta(x,selected,[L,*switches,R])
    assert val.overlaps(via_green) and abs(via_green-val)<A('1e-31')
    tangent_rows=[]
    for t,p,q in ((L,selected[0],x),(R,x,selected[-1])):
        u=direction(t)
        start,end=p.point(u),q.point(u)
        length=dot(sub(end,start),perp(u))
        assert length>0 and dot(sub(end,start),u).contains(0)
        tangent_rows.append(dict(angle_degrees=str(t),start=list(map(str,start)),end=list(map(str,end)),length=str(length)))
    return val,dict(local_domain_degrees=['112.32','115.26'],exposure_roots_degrees=[str(L),str(R)],
                    input_piece=x.label,old_pieces=list(labels),switches_degrees=list(map(str,switches)),
                    monotone_old_differences=touching,monotone_exposure_derivatives=[str(dl),str(dr)],
                    envelope=margins,arc_contributions=list(map(str,integral)),atoms=atoms,
                    new_common_tangents=tangent_rows,independent_green_increment=str(via_green),
                    selected_geometry={p.label:{'center':list(map(str,p.center)),'curvature_radius':str(p.rho),
                                               'closed_piece_degrees':[str(p.lo),str(p.hi)]}
                                       for p in [x,*selected]},local_increment=str(val))


def settle_hex_normals(bodies,new):
    """Use equality at the six original hexagon normals and one-sided derivative gaps."""
    delta=F(1,100)
    angles=range(0,361,60)
    ledger=[]
    for a in angles:
        for side in (1,-1):
            if a==0 and side==-1 or a==360 and side==1:
                continue
            z,w=sorted((F(a),F(a)+side*delta))
            lower,upper=A(z),A(w)
            left,right=lower.lower(),upper.upper()
            new_set=possible(new,lower,upper)
            assert new_set
            for n,body in enumerate(bodies):
                old_set=possible(body,lower,upper)
                intervals=[(p,q,I) for p in old_set for q in new_set if (I:=intersect(left,right,p,q))]
                assert intervals
                try:
                    signs=[increasing_difference(p,q,*I) if side==1 else increasing_difference(q,p,*I)
                           for p,q,I in intervals]
                except AssertionError:
                    continue
                pin=arb(a)
                u=direction(pin)
                assert all((p.height(u)-A('1/2')).contains(0) for p in possible(new,pin,pin)+possible(body,pin,pin))
                ledger.append(dict(normal=a,angles=[str(z),str(w)],old_source=n,
                                   derivative_sign_of_old_minus_new=side,strict_derivative_lower=str(min(signs))))
                break
            else:
                raise ValueError(f'no derivative witness at pinned normal {a} side {side}')
    assert len(ledger)==12
    domains=[(F(0)+delta,F(60)-delta),(F(60)+delta,F('112.32')),(F('115.26'),F(120)-delta)]
    domains.extend((F(j)+delta,F(j+60)-delta) for j in (120,180,240,300))
    return domains,ledger

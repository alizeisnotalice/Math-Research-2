"""Reproduce the local R219 area increment from the true circular support geometry."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from importlib.util import source_from_cache
from pathlib import Path
import json
import sys

from flint import arb,ctx,__version__ as flint_version
from local_support import A,load
from verify_geometry import visible_parts,local_change,prove_exterior,settle_hex_normals


def source_manifest(comp):
    paths=set()
    def collect(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)):
            return
        p=Path(args[0].decode() if isinstance(args[0],bytes) else args[0])
        if p.suffix=='.pyc':
            try:
                p=Path(source_from_cache(str(p)))
            except ValueError:
                return
        if p.is_absolute() and p.is_relative_to(comp) and p.is_file() and p.suffix in ('.py','.json'):
            paths.add(p)
    sys.addaudithook(collect)
    return paths


def exact_dyadic(value):
    m,e=map(int,value.man_exp())
    return F(m*2**e) if e>=0 else F(m,2**(-e))


def decimal_outward(lower,upper,digits=39):
    scale=10**digits
    lo=exact_dyadic(lower)*scale
    hi=exact_dyadic(upper)*scale
    results=[lo.numerator//lo.denominator-1,-((-hi.numerator)//hi.denominator)+1]
    return [f'{v//scale}.{v%scale:0{digits}d}' for v in results]


def certify(comp):
    ctx.prec=192
    deps=source_manifest(comp)
    bodies,X,core=load(comp)
    value,local=local_change(bodies,X,core)
    print('local',value,flush=True)
    material,_,_=visible_parts(core)
    original_path=comp/'single-repair'/'single-repair.json'
    original=json.loads(original_path.read_bytes())
    w,e='7982907/10000000','2043/62500'
    assert original['strict_endpoints'] and original['parameters']['w']==w and original['parameters']['e']==e
    assert set(original['poses'])=={'0,1','240,-1'}
    excluded={(a,s) for a,s,_,gap in original['root_cert']['cap_eliminations'] if arb(gap)>0}
    assert excluded=={(a,s) for a in range(0,360,60) for s in (-1,1)}-{(0,1),(240,-1)}
    domains,pins=settle_hex_normals(bodies,X)
    exterior=prove_exterior([*bodies,*material],X,domains)
    lower,upper=value.lower(),value.upper()
    endpoints=decimal_outward(lower,upper)
    old_lo,old_hi=map(F,original['poses']['240,-1']['increase'])
    assert old_lo<F(endpoints[0])<F(endpoints[1])<old_hi<F(original['poses']['0,1']['increase'][0])
    result=dict(complete=True,scope='R219 central fixed input, reflected pose; same allowed two poses',
                python=sys.version.split()[0],flint=flint_version,precision_bits=ctx.prec,
                w=w,e=e,pose=[240,-1],old_sources=150,strict_interval=endpoints,
                local=local,exterior=exterior,pinned_normals=pins,uniform_exterior_positive_part_upper='0',
                exterior_increment_upper='0',
                dependencies={str(p.relative_to(comp)):sha256(p.read_bytes()).hexdigest() for p in sorted(deps)},
                verifier_sha256={n:sha256(Path(__file__).with_name(n).read_bytes()).hexdigest()
                                 for n in ('local_support.py','verify_geometry.py','certify_increment.py')})
    result['certified_numeric_bound']=[str(lower),str(upper)]
    return result


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('computation','output'):p.add_argument(n,type=Path)
    a=p.parse_args()
    d=certify(a.computation.resolve())
    a.output.write_text(json.dumps(d,indent=2)+'\n')
    print(d.get('strict_interval',d.get('local_increment')),flush=True)

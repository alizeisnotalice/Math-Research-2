"""Certify the exact reflected enlargement for the closed R219 input box."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys

from flint import arb,ctx,__version__ as flint_version
from local_support import A,add,sub,mul,dot,direction,pose,load,pentagon
from verify_geometry import possible,visible_parts,preclip_core,local_change,prove_exterior,settle_hex_normals
from certify_increment import source_manifest,decimal_outward

W,E,RW,RE=map(F,('.7982907','.032688','1e-10','1e-11'))
WINDOW=(F('112.32'),F('115.26'))
QA=(240,-1)


def vertex_jets(ns,w,e):
    """Partial derivatives of the five exact circle-coordinate vertices."""
    ref=ns['reflection']
    zz=add(ns['z'],mul(w,ns['D']))
    ell,t=ns['chart'](zz)
    _,gell,gt=ns['points'](w)
    ell_w,t_w=dot(gell,ns['D']),dot(gt,ns['D'])
    p=ns['psi'](ell)
    cp=ns['psi_prime'](add(ns['l0'],mul(ell,ns['el'])))
    p_w=cp*ell_w
    h=t-e
    def checked_pair(l,t):
        x,c,d=ns['chart_bounds'](l,t)
        diff=sub(d,c)
        sq=dot(diff,diff)
        assert 0<sq<4 and ns['cross'](sub(x,c),sub(x,d))<0
        return ns['derivs'](x,c,d)
    x2_l,x2_t=checked_pair(p,-h)
    x4_l,x4_t=checked_pair(ell,h)
    zero=(arb(0),arb(0))
    dw=[mul(ell_w,ns['el']),ref(mul(p_w,ns['el'])),ref(sub(mul(p_w,x2_l),mul(t_w,x2_t))),
        mul(t_w,ns['en']),add(mul(ell_w,x4_l),mul(t_w,x4_t))]
    de=[zero,zero,ref(x2_t),mul(-1,ns['en']),mul(-1,x4_t)]
    return dw,de


def family_corner(ns,family,wbox,ebox):
    a,b=map(A,WINDOW)
    x,=[p for p in family if not(p.lo>b or a>p.hi)]
    assert x.label=='X:0' and x.rho.is_zero() and x.lo<a<b<x.hi
    i,r=ns['sector'][0]
    assert r==0
    dw,de=vertex_jets(ns,wbox,ebox)
    derivatives=[pose(v[i],A(QA[0]),QA[1]) for v in (dw,de)]
    bound=[]
    n=32
    lo,hi=WINDOW
    for j in range(n):
        a,b=A(lo+(hi-lo)*F(j,n)),A(lo+(hi-lo)*F(j+1,n))
        u=direction(a.union(b))
        bound.append([dot(v,u) for v in derivatives])
    summary=[];chosen=[]
    for c,base,rad in zip(zip(*bound,strict=True),(W,E),(RW,RE),strict=True):
        lower=min(d.lower() for d in c);upper=max(d.upper() for d in c)
        print('partial',lower,upper,flush=True)
        assert lower>0 or upper<0
        sign=1 if lower>0 else -1
        chosen.append(base+sign*rad)
        summary.append(dict(sign=sign,lower=str(lower),upper=str(upper)))
    return tuple(chosen),dict(piece=x.label,center_index=i,windows=n,parameter_derivatives=summary,
                             uniform_sector_window=[str(x.lo),str(x.hi)])


def support_enclosure(arcs,t):
    u=direction(t)
    vals=[p.height(u) for p in possible(arcs,t,t)]
    assert vals
    lo=min(x.lower() for x in vals);hi=max(x.upper() for x in vals)
    return lo.union(hi)


def exclude_152(ns,bodies,corner,core):
    from certify_nonideal_pentagon_pose_library import verify

    w,e=F(6,5),F('.08464386')
    poses=verify(ns,w,e,F(0),F(0))
    removed={(a,s) for a,s,_,clearance in poses['cap_eliminations'] if arb(clearance)>0}
    keep={(0,1),QA}
    assert removed=={(a,s) for a in range(0,360,60) for s in (-1,1)}-keep
    cap_loss=min(arb(row[3]).lower() for row in poses['cap_eliminations'])
    old_upper_pieces=[p for body in bodies for p in body]+preclip_core(core)+corner
    witnesses=[]
    for g,t,threshold in (((0,1),'112.32','3.4391e-6'),(QA,'115.24','1.4877e-6')):
        q=A(t)
        u=direction(q)
        arcs,_=pentagon(ns,w,e,*g,'Z')
        target=support_enclosure(arcs,q)
        support=max(((p.height(u).upper(),p.label) for p in possible(old_upper_pieces,q,q)),key=lambda x:x[0])
        bound,feature=support
        gap=target.lower()-bound
        assert gap>A(threshold)
        witnesses.append(dict(pose=g,angle_degrees=t,body_152_support_lower=str(target.lower()),
                              actual_host_support_upper=str(bound),separating_gap_lower=str(gap.lower()),
                              upper_bound_feature=feature))
    return dict(w=str(w),e=str(e),closed_full_pose_certificate=poses,cap_eliminated_count=len(removed),
                minimum_old_cap_violation_lower=str(cap_loss),two_support_witnesses=witnesses)



def run(comp):
    ctx.prec=192
    deps=source_manifest(comp)
    bodies,_,core=load(comp)
    from deformed_reuleaux_support import environment
    from certify_nonideal_pentagon_pose_library import verify
    ns=environment(str(comp),'1.5497')
    wb,eb=ns['box'](W-RW,W+RW),ns['box'](E-RE,E+RE)
    family,_=pentagon(ns,wb,eb,*QA,'X')
    witness,mono=family_corner(ns,family,wb,eb)
    corner,_=pentagon(ns,*witness,*QA,'X')
    print('corner',witness,flush=True)
    value,local=local_change(bodies,corner,core)
    print('area',value,flush=True)
    pins,_,_=visible_parts(core)
    domains,endpoints=settle_hex_normals(bodies,family)
    exterior=prove_exterior([*bodies,*pins],family,domains)
    roots=verify(ns,W,E,RW,RE)
    removed={(k,s) for k,s,_,clearance in roots['cap_eliminations'] if arb(clearance)>0}
    assert removed=={(k,s) for k in range(0,360,60) for s in (-1,1)}-{(0,1),QA}
    caps=[]
    for k in (3,5):
        normal=ns['av'](ns['d']['m'][k]);t=ns['A'](1)/2
        pts=[p.height(normal) for p in possible(family,ns['A'](30+60*k)+ns['A']('1.5497'),ns['A'](30+60*k)+ns['A']('1.5497'))]
        assert pts and all(h<t for h in pts)
        caps.append(str(min((t-h).lower() for h in pts)))
    prior=json.loads((comp/'single-repair'/'single-repair.json').read_bytes())
    assert prior['strict_endpoints']
    assert list(map(F,(prior['parameters'][k] for k in ('w','e','w_radius','e_radius'))))==[W,E,RW,RE]
    B=F(prior['B'])
    dw,de=vertex_jets(ns,wb,eb)
    sens=[max(dot(d,d).sqrt().upper() for d in dd) for dd in (dw,de)]
    eta=A(RW)*sens[0]+A(RE)*sens[1]
    center_identity=A(prior['poses']['0,1']['area'][0])
    identity_gap=center_identity-2*arb(3).sqrt()*eta-arb.pi()*eta**2-A(B)
    assert identity_gap>0
    assert F(prior['each_box_identity_area_lower'])>B
    print('uniform identity gap',identity_gap,flush=True)
    inc=decimal_outward(value.lower(),value.upper())
    lo,hi=map(F,inc)
    a,b=map(F,prior['base_area'])
    assert b+hi<B and b+hi<F(prior['box_reflected_area'][1])
    old_area_lower=F(prior['box_reflected_area'][0])
    improved=[max(a+lo,old_area_lower),b+hi]
    missing=exclude_152(ns,bodies,corner,core)
    return dict(complete=True,closed_parameter_box={'w_center':str(W),'e_center':str(E),'radii':[str(RW),str(RE)]},
                attaining_corner=list(map(str,witness)),monotonicity=mono,retained_reflection_cap_margins=caps,
                poses=roots,local=local,uniform_exterior=exterior,uniform_hex_normals=endpoints,increase_strict=inc,
                identity_B_gap_lower=str(identity_gap.lower()),box_Hausdorff_change_upper=str(eta.upper()),
                total_area_strict_fractions=list(map(str,improved)),remaining_B_budget_lower=str(B-improved[1]),
                B=str(B),obstruction_152=missing,
                python=sys.version.split()[0],flint=flint_version,precision_bits=ctx.prec,
                verifier_sha256={name:sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                                 for name in ('certify_family.py','local_support.py','verify_geometry.py','certify_increment.py')},
                inputs={str(p.relative_to(comp)):sha256(p.read_bytes()).hexdigest() for p in sorted(deps)})


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('computation','output'):p.add_argument(n,type=Path)
    a=p.parse_args(); r=run(a.computation.resolve())
    a.output.write_text(json.dumps(r,indent=2)+'\n')
    print(r['increase_strict'],flush=True)
    print([(z['pose'],z['separating_gap_lower']) for z in r['obstruction_152']['two_support_witnesses']],flush=True)

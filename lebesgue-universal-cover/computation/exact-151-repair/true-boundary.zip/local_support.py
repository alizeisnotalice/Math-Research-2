"""Arb circular-arc support pieces for the R215 frozen sources and R219 input."""
from dataclasses import dataclass
from fractions import Fraction as F
from pathlib import Path
import json
import sys

from flint import arb, ctx


def A(q):
    q=F(q)
    return arb(q.numerator)/q.denominator


def add(u,v):
    return u[0]+v[0],u[1]+v[1]


def sub(u,v):
    return u[0]-v[0],u[1]-v[1]


def mul(s,u):
    return s*u[0],s*u[1]


def dot(u,v):
    return u[0]*v[0]+u[1]*v[1]


def direction(t):
    si,co=(t*arb.pi()/180).sin_cos()
    return (co,si)


def angle(u):
    x,y=u
    if x<0 and y.contains(0):
        return 180+(y/x).atan()*180/arb.pi()
    return arb.atan2(y,x)*180/arb.pi()


def rot(t,u):
    co,si=direction(t)
    x,y=u
    return co*x-si*y,si*x+co*y


def pose(u,t,s):
    x,y=rot(t,u)
    return (x,s*y)


@dataclass(frozen=True)
class Arc:
    label: str
    lo: arb
    hi: arb
    center: tuple
    rho: arb

    def height(self,u):
        return dot(self.center,u)+self.rho

    def point(self,u):
        return add(self.center,mul(self.rho,u))


def arc(label,a,b,center,r,t,s):
    turn=(a+t,b+t) if s==1 else (-b-t,-a-t)
    c=pose(center,t,s)
    return Arc(label,*turn,c,r)


def periodize(arcs):
    result=[]
    for x in arcs:
        k=int(float(x.lo.mid())//360)
        for j in (k-1,k,k+1):
            a,b=x.lo-360*j,x.hi-360*j
            if not (b<0 or a>360):
                result.append(Arc(x.label,a,b,x.center,x.rho))
    return sorted(result,key=lambda a:float(a.lo.mid()))


def pentagon(ns,w,e,t,s,label):
    from deformed_reuleaux_support import body

    vs,h=body(ns,w,e)
    edges=[sub(vs[i],vs[j]) for i,j in ns['orders']]
    aa=[angle(n) for n in edges]
    for i in range(1,len(aa)):
        while aa[i]<aa[i-1]:aa[i]+=360
        assert 0<aa[i]-aa[i-1]<180
    aa.append(aa[0]+360)
    assert 0<aa[-1]-aa[-2]<180
    ps=[arc(f'{label}:{i}',aa[i],aa[i+1],vs[k],arb(r),A(t),s)
        for i,(k,r) in enumerate(ns['sector'])]
    return periodize(ps),h


def profile(p,t,s,label):
    ps=[]
    for i,f in enumerate(p.fs):
        yy,v=p.states[i]; a,b=p.bounds[i:i+2]
        for q in (1,-1):
            shift=0 if q==1 else 180
            center=rot(A(F(180*a,p.grid)),(yy-f,v))
            ps.append(arc(f'{label}:{i}:{q}',A(F(180*a,p.grid)+shift),A(F(180*b,p.grid)+shift),
                          center,A('1/2')+q*f,A(t),s))
    return periodize(ps)


def mirror(p,t,s,label):
    ps=[]
    knots=p.angles if hasattr(p,'angles') else p.breaks
    for i,(a,b) in enumerate(zip(knots,knots[1:])):
        aa,bb=a*180/arb.pi(),b*180/arb.pi()
        x,y,d=p.rows[i]
        for q in (1,-1):
            shift=30 if q==1 else 210
            for j in (1,-1):
                lo,hi=(aa,bb) if j==1 else (-bb,-aa)
                c=rot(arb(shift),(q*x,q*j*y))
                ps.append(arc(f'{label}:{i}:{q}:{j}',lo+shift,hi+shift,c,A('1/2')+q*d,A(t),s))
    return periodize(ps)


def core_vertices(core):
    g,ns=core['g'],core['ns']
    n,m,c3,b3,_,_,_,_,j=g.setup()
    h=A('1/2')
    proj=lambda x,u:add(x,mul(h-dot(u,x),u))
    b1=g.line_pair(n[0],n[1]);f1=g.line_pair(n[2],n[3]);d1=g.line_pair(n[4],n[5])
    e3=g.line_pair(n[4],m[3]);f3=g.line_pair(n[3],m[2]);G=g.circle_line(f3,n[5],1)
    c=(-e3[0],e3[1]);Y=(arb(0),c[1]+(1-c[0]**2).sqrt())
    ta=add(ns['z'],ns['D']);tp=core['q'](arb(1))
    vs=[b1,proj(e3,n[1]),Y,ta,tp,proj(G,n[2]),f1,proj(c3,n[3]),j,proj(b3,m[3]),e3,d1,G,proj(f3,m[5]),c3]
    names=['B1','Q','Y','Ta','Tp','P','F1','H','J','I','E3','D1','G','K','C3']
    centers={1:e3,2:c,4:G,7:c3,8:b3,12:f3}
    return names,vs,centers


def load(comp):
    sys.path.insert(0,str(comp))
    from certify_ah_tapered_minkowski_closure import geometry
    from certify_ah_tapered_mirror_counterexample import Support,Polygon
    from certify_tapered_forced_support import Profile
    from deformed_reuleaux_support import environment

    core,_=geometry(comp)
    ns=environment(str(comp),'1.5497')
    ctx.prec=192
    rows=json.loads((comp/'finite-b-core'/'host-poses.json').read_bytes())['poses']
    assert [x['index'] for x in rows]==list(range(150))
    data={name:json.loads((comp/name).read_bytes()) for name in {r['source'] for r in rows}}
    msrc='ah-tapered-mirror-counterexample-input.json'
    base=Support(data[msrc],arb.pi()); mirrors={'Support':base,'Polygon':Polygon(base)}
    bodies=[]
    for row in rows:
        source=row['source'];k=row['body_index'];t=row['turn'];s=row['reflection'];n=str(row['index'])
        if 'w' in row:
            if source=='nonideal-pentagon-library.json':
                a=data[source]['proofs'][k];w,e=a['w'],a['deformation']
            else:
                assert source=='nonmonotone-pentagon-inputs.json'
                w,e=data[source][k]
            assert (F(w),F(e))==(F(row['w']),F(row['e']))
            pieces=pentagon(ns,F(w),F(e),t,s,n)[0]
        elif source==msrc:
            pieces=mirror(mirrors[row['body_type']],t,s,n)
        else:
            pieces=profile(Profile(data[source][k]),t,s,n)
        bodies.append(pieces)
    new=pentagon(ns,F('.7982907'),F('.032688'),240,-1,'X')[0]
    return bodies,new,core

from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from functools import reduce
from math import gcd
import json,gzip,platform,time
import flint
from flint import arb,ctx
import geom,diam
W=Path(__file__).resolve().parent; ctx.prec=192; geom.S=10**21; geom.farthest=diam.axis_max
G=F(120690705406006259,2**57);S=F(199999999,200000000);A=G/S**2; T=F('.83746');assert A>T
p=(W/'inputs/p128.json').read_bytes();q=(W/'inputs/qrows.json').read_bytes()
assert sha256(p).hexdigest()=='13d9a52243efadcb2281aa60e41282349e3c4c64bc9925f9ad20ece8dab2ecb1'
assert sha256(q).hexdigest()=='4e327bd152d02e4d57f3666fdbfeb31d6b06c801419ad23ed30da2d7e32e9558'
P=json.loads(p);Q=json.loads(q);assert F(Q['scale'])==S
pi=arb.pi(); target=geom.ar(T);ratio=geom.ar(T/A).sqrt()
def val(n):return geom.ar(A)*((pi/n).cos()/(pi/(2*n)).cos())**2
lo,hi=3,5
while val(hi)<target:hi=2*hi+1
while hi-lo>2:
 mid=(lo+hi)//4*2+1
 if val(mid)>target:hi=mid
 else:assert val(mid)<target;lo=mid
N=hi;assert N==27207 and val(N-2)<target<val(N)
rows=[];groups=[];t0=time.monotonic()
for n in (0,3,5,7,9):
 if n==0:k=N;step=2
 else:k=int((pi/(2*n*ratio.acos())).upper().ceil().unique_fmpz());step=1
 while True:
  cloud,sq,den,axis=geom.curve_points(n,k,pi);inner=F((geom.S-2)**2,sq)
  if A*inner>T:break
  k+=step
 sq2,axis2=diam.axis_max(cloud['points']);assert sq2==cloud['denominator']**2
 assert A*inner>T
 rows.append({'shape':cloud['body'],'grid':k,'count':len(cloud['points']),'inner_squared':str(inner),'inner_192':str(geom.ar(inner)),'integer_diameter_squared':str(sq),'integer_axis':axis,'exact_output_squared_diameter':'1','min_area_lower':str(A*inner),'elapsed_seconds':time.monotonic()-t0})
 groups.append(cloud);print('generated',cloud['body'],'k',k,'count',len(cloud['points']),'area',float(A*inner),flush=True)
# Scale actual source clouds by 1/S; preserve all rational coordinates exactly.
def cloud(name,pts,den,scale):
 nums=[[x*scale.numerator,y*scale.numerator] for x,y in pts];d=den*scale.denominator
 g=reduce(gcd,[abs(d)]+[abs(x) for p in nums for x in p]);nums=[[x//g,y//g] for x,y in nums];d//=g
 sq,axis=diam.axis_max(nums);assert sq<d*d
 # The convex hull of this set contains a common c-scale copy about any chosen point.
 return {'body':name,'points':nums,'denominator':d}, {'shape':name,'count':len(nums),'diameter_squared':str(F(sq,d*d)),'strictly_below_one':True,'axis':axis}
pcloud,pr=cloud('P128',P['points'],P['denominator'],F('.999999996296')/S)
qcloud,qr=cloud('Q11-shifted',Q['points'],Q['integer_denominator'],1/S)
groups.extend([pcloud,qcloud]);rows.extend([pr,qr]);inner=min(F(r['inner_squared']) for r in rows[:5]);bound=A*inner;assert bound>T
raw=geom.packed(groups);out=W/'rational-seven-83746.json.gz';out.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
report={'assumption':'seven-row46 seven-input theorem, source e32792d7906a05f245f9246025b33eeee12a74d324435252c75d5140ef802232; requires verified complete upstream','source_q_sha256':sha256(q).hexdigest(),'source_p_sha256':sha256(p).hexdigest(),'G':str(G),'s':str(S),'normalized_area_lower':str(A),'target':str(T),'analytic_first_odd':N,'previous_odd_192':str(val(N-2)),'first_odd_192':str(val(N)),'coordinate_scale':geom.S,'rows':rows,'counts':[len(c['points']) for c in groups],'common_inner_squared':str(inner),'true_area_lower':str(bound),'decimal_down_24':geom.decimal_down(bound,24),'point_file_sha256':sha256(out.read_bytes()).hexdigest(),'precision_bits':ctx.prec,'python':platform.python_version(),'flint':flint.__version__,'seconds':time.monotonic()-t0}
(W/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',report['counts'],report['decimal_down_24'],flush=True)

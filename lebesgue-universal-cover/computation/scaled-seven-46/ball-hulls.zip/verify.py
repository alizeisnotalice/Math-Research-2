"""Replay the four ball hull extensions of the published .83745 area proof."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import zipfile

from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
R254_SHA256 = "2ba777f4cf1922841b3d113b9bd104c980a085a41c4cb8f7af609137219889a3"


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def run(script, *arguments):
    print(script.name, flush=True)
    subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, arguments)], check=True)


def verify(args):
    ctx.prec = 256
    comp, tree, low, high, out = [p.resolve() for p in
        (args.computation, args.tree, args.table32, args.table64, args.output)]
    archive = comp / "translated-triangle/certificate.zip"
    assert __debug__ and digest(archive) == R254_SHA256 and args.workers >= 1
    out.mkdir(parents=True, exist_ok=False)
    upstream = out / "r254-source"
    with zipfile.ZipFile(archive) as packed:
        assert all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in packed.namelist())
        packed.extractall(upstream)
    run(upstream / "verify.py", comp, tree, low, high, out / "r254", "--workers", args.workers)
    assert read(out / "r254/combined.json") == read(upstream / "expected.json")
    source = comp / "six-input-083745"
    run(source / "integrate_native45.py", source / "volumes", comp, tree, out / "integration.json")
    ledger = read(source / "replayed/full-leaf-ledger.json")
    replay = read(source / "replayed/run-complete.json")
    assert replay["full_leaf_ledger_sha256"] == digest(source / "replayed/full-leaf-ledger.json")
    assert ledger["all_terminal_replayed"] and ledger["terminal_nodes_total"] == 1104937301
    assert read(out / "integration.json") == read(source / "records/integration-audit.json")
    run(ROOT / "triangle/verify.py", low, high, out / "r254/materials", out / "triangle")
    orbits = ROOT / "orbits"
    comparison = ROOT / "comparisons"
    run(orbits / "audit_angle_tree.py", comp, tree, orbits / "scopes.json", out / "angles.json")
    run(orbits / "diameter.py", comp, tree, low, high, out / "baseline.json")
    run(orbits / "verify.py", comp, tree, low, high, orbits / "scopes.json", out / "orbits.json",
        "--shift", orbits / "shift7.json", orbits / "shifts59.json")
    run(comparison / "dense_rounding.py", comp, tree, out / "dense.json")
    run(comparison / "radial_new.py", comp, out / "radial.json")
    run(orbits / "check_mixed.py", comp, low, high, out / "baseline.json", out / "orbits.json",
        out / "dense.json", out / "radial.json", out / "mixed.json")
    run(comparison / "interval_ball.py", comp, tree, out / "transfer.json",
        comp / "critical-material-scale/records/points/proof.json")
    mixed, walls, radial = (read(out / p) for p in ["mixed.json", "transfer.json", "radial.json"])
    s, lam, G = map(Fraction, (mixed["scale"], mixed["base"], mixed["G"]))
    assert s == Fraction(".9999990051212") == Fraction(walls["ball_scale"])
    assert lam == Fraction(".999999000058421") == Fraction(radial["inner_scale"]) == Fraction(walls["lower"])
    exact = G / s**2
    assert exact == Fraction(mixed["conditional_area"]) and exact > Fraction(".83745166632498881359008414331127")
    triangle = read(out / "triangle/mixed.json")
    radius = arb(s.numerator)/s.denominator
    assert arb(triangle["minimum_s"]) < radius and arb(triangle["mixed_upper"]) < radius
    assert read(out / "triangle/diameter.json")["counts"]["unordered_pairs"] == 662976
    assert walls["complete"] and walls["native_leaves"] == ledger["stage_four_count"] == 3273
    assert [len(walls[k]) for k in ("direct_wall_margins","clipped_wall_margins")] == [64,41]
    assert len({tuple(z["direction"]) for k in ("direct_wall_margins","clipped_wall_margins")
                for z in walls[k] if arb(z["conservative_margin"]) > 0}) == 105
    assert arb(walls["disk_margin"]) > 0 and all(
        Fraction(row["gap"]) > 0 and row["panel_count"] == 8192 for row in radial["results"])
    assert [r["order"] for r in radial["results"]] == [3,5,7,9]
    cloud = read(out / "r254/fifteen/fifteen-proof.json")
    assert len(cloud["points"]) == 15 and Fraction(cloud["contracted_diameter_squared"]) < s*s
    assert cloud["contracted_minimum_integer_gain"] >= 0
    result = dict(scale=str(s), inner_scale=str(lam), frozen_area=str(G), lower_bound=str(exact),
        strict_floor=".83745166632498881359008414331127", r254_archive_sha256=R254_SHA256,
        checked_direct_walls=64, checked_clipped_walls=41, checked_radial_cells=[8192]*4,
        disk_and_exterior_point_radius=".703", cap_slabs=walls["cap_slabs"],
        dense_extra_points=read(out/"dense.json")["count"], inherited_terminal_nodes=ledger["terminal_nodes_total"],
        terminal_roots=3273, dense_roots=24, rational_input_points=15)
    (out/"combined.json").write_text(json.dumps(result, indent=2)+"\n")
    assert result == read(ROOT / "expected.json")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("computation", "tree", "table32", "table64", "output"):
        parser.add_argument(key, type=Path)
    parser.add_argument("--workers", type=int, default=2)
    verify(parser.parse_args())

"""Check the three ideal inner regular curves at the common ball-hull inner scale on each full radial cutoff."""
from pathlib import Path
from fractions import Fraction as F
from argparse import ArgumentParser
import json
import numpy as np
from scipy.spatial import ConvexHull
from flint import arb,ctx

def ar(x):
    q=F(x);return arb(q.numerator)/q.denominator

def points(n,count,scale,Q):
    pi=arb.pi();R=ar(F(1,2)) if n==0 else 1/(2*(pi/(2*n)).cos())
    vertices=[] if not n else [(R*(2*pi*j/n).cos(),R*(2*pi*j/n).sin()) for j in range(n)]
    out=[]
    for j in range(count):
        t=F(j,count);sn,cs=(2*pi*j/count).sin_cos()
        if n:
            cx,cy=vertices[int((t*n+F(n+1,2)).__floor__())%n];w=cs*cx+sn*cy;r=w+(1-R*R+w*w).sqrt()
        else:r=R
        near=scale*ar(F('.99999997'))
        x=round(float((Q*near*r*cs).mid()));y=round(float((Q*near*r*sn).mid()))
        if n:assert all((arb(x)/Q-scale*v)**2+(arb(y)/Q-scale*w)**2<scale**2 for v,w in vertices)
        else:assert ar(F(4*(x*x+y*y),Q*Q))<scale**2
        out.append((x,y))
    return np.asarray(out,dtype=np.int64)

def run(comp,out):
    ctx.prec=192;Q=2**28;D=F(1,10**8);lam=F('.999999000058421');s=ar(lam);N=8192
    disc=points(0,192,s,Q)
    seed=json.loads((comp/'tomar-083745-future-seed.json').read_bytes());goal=F(120689264254125501,2**57);results=[]
    for n,row in zip([3,5,7,9],seed['radii']):
        assert row['n']==n;vis=points(n,n*64,s,Q);R=F(row['integer_radius'],2**44)-D
        rad=ar(R);pi=arb.pi();pad=rad*pi/(2*n*N)+arb(2)/Q;err=int(float((Q*pad).mid()))+2;assert Q*pad<err<Q//10
        m=None
        for j in range(N):
            sn,cs=(pi*(2*j+1)/(2*n*N)).sin_cos();dx=Q*rad*cs;dy=Q*rad*sn
            x=round(float(dx.mid()));y=round(float(dy.mid()));assert abs(dx-x)<1 and abs(dy-y)<1
            p=np.r_[disc,vis+[x,y]];ix=ConvexHull(p.astype(float)).vertices;v=p[ix];w=np.roll(v,-1,axis=0)
            moving=(ix>=len(disc)).astype(np.int64);nm=np.roll(moving,-1);d=v[:,0]*w[:,1]-v[:,1]*w[:,0]
            a=moving*w[:,1]-nm*v[:,1];b=nm*v[:,0]-moving*w[:,0]
            assert np.max(np.abs(v))<Q and np.min(d-err*(abs(a)+abs(b)))>0 and np.count_nonzero((v[:,1]<=0)&(w[:,1]>0))==1
            val=sum(map(int,d))-err*(abs(int(a.sum()))+abs(int(b.sum())))
            if m is None or val<m:m=val;k=j
        alpha=pi/(2*n);assert pi/4+n*(alpha.tan()-alpha)/4<ar(goal)
        gap=F(m,2*Q**2)-goal;assert gap>0
        results.append(dict(order=n,panel_count=N,disk_points=len(disc),body_points=len(vis),radius=str(R),numerator=m,gap=str(gap),min_panel=k))
        print(n,float(gap),flush=True)
    out.write_text(json.dumps(dict(inner_scale=str(lam),true_to_anchor_distance_bound=str(D),results=results),indent=2)+'\n')
if __name__=='__main__':
    p=ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();run(a.comp,a.out)

"""Replay the original round-to-Q instruction on every possible dense anchor row."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
from flint import arb,ctx

def run(comp,treepath,out):
    ctx.prec=160;sys.path.insert(0,str(comp.resolve()))
    from certify_tomar_six_high import SourceTree,FINE
    src=comp/'tomar_p30_scaled_material.py'
    assert sha256(src.read_bytes()).hexdigest()=='da3fdc4472aaf0b09e020b6a3a7b467f227fe695c84ad0c4f502244e0f20cc2b'
    tree=SourceTree(treepath);q=2**28;pi=arb.pi();factor=1-arb(3)/10**6
    m=[];N=0
    for b,n in enumerate([0,3,5,7,9]):
        total=[96,192,320,448,576][b];added=[1024,384,640,896,1024][b]-total
        rad=arb(1)/2 if not n else 1/(2*(pi/(2*n)).cos())
        corners=[] if not n else [(rad*(2*pi*j/n).cos(),rad*(2*pi*j/n).sin()) for j in range(n)]
        extra=[]
        for k in range(added):
            t=F(2*k+1,2*added) if not n else F(2*(k*total//added)+1,2*total)
            theta=2*pi*t.numerator/t.denominator;u,v=theta.cos(),theta.sin()
            if n:
                i=(t*n+F(n,2)+F(1,2)).__floor__()%n
                cx,cy=corners[i];dot=u*cx+v*cy;radius=dot+(1-rad*rad+dot*dot).sqrt()
            else:radius=rad
            extra.append((u*radius*factor,v*radius*factor))
        top=int(F(tree.root['hi'][3*b-4])*FINE) if b>=2 else 0
        local=arb(0)
        for row in range(1025 if b>=2 else 1):
            theta=(arb(top)/FINE)*row/1024 if b>=2 else arb(0)
            c,s=theta.cos(),theta.sin()
            for x,y in extra:
                xx,yy=c*x-s*y,s*x+c*y
                ix,iy=round(float(xx.mid())*q),round(float(yy.mid())*q)
                err=max(abs(xx*q-ix).upper(),abs(yy*q-iy).upper())
                assert err<1
                if err>local:local=err
        count=(1025 if b>=2 else 1)*added;N+=count
        m.append(dict(n=n,count=count,max_coordinate_error_grid=str(local)))
        print(n,count,local,flush=True)
    # Every allowed ray-boundary vector has norm bounded by the original circumradius <.6.
    # Its factor-scaled copy has depth at least (s-factor)*r_in, then translation and rounding apply.
    small=arb(999999005250)/10**12
    gap=((small-factor)*arb(42)/100-arb(3)/10**10-arb(2).sqrt()/q).lower()
    assert gap>arb(83)/10**8
    out.write_text(json.dumps(dict(source_sha256=sha256(src.read_bytes()).hexdigest(),count=N,rows=m,
                                  depth_lower=str(gap),precision=ctx.prec),indent=2)+'\n')
if __name__=='__main__':
    p=ArgumentParser()
    for k in ['comp','tree','out']:p.add_argument(k,type=Path)
    a=p.parse_args();run(a.comp,a.tree,a.out)

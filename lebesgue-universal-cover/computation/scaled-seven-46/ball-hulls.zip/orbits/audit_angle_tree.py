"""Independently enumerate original and clipped binary angular intervals through one table grid width."""
from fractions import Fraction as F
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json,sys


def run(comp,treepath,fit,out):
    sys.path.insert(0,str(comp.resolve()))
    from certify_tomar_six_high import SourceTree,FINE
    from tomar_d3_mask import CUT
    tree=SourceTree(treepath);pack=json.loads(fit.read_bytes());cut=-(-CUT.numerator*FINE//CUT.denominator)
    scopes=[]
    for b,n in [(2,5),(3,7),(4,9)]:
        H=int(F(tree.root['hi'][3*b-4])*FINE);m=pack['count_per_order'][str(n)]
        bands=[]
        for r in pack['bodies'][str(n)]:
            k=r['sector'];allowed=set()
            for u,v in r['ranges']:allowed.update(range(u,v+1))
            assert 0 in allowed and 512 in allowed and 1024 in allowed
            bands.append((F(H*k,m),min(F(H*(k+1),m),F(cut) if n==5 else F(H)),allowed))
        def nearest(x):return (1024*x/H+F(1,2)).__floor__()
        touched=set();todo=[(0,H//2),(H//2,H)]
        visited=0;micro=0;intersections=0
        while todo:
            l,h=todo.pop()
            if (l,h) in touched:continue
            touched.add((l,h));visited+=1
            overlap=[S for low,high,S in bands if max(low,l)<min(high,h)]
            if not overlap:continue
            if n==5 and l<cut<h:todo.append((l,cut))
            row=nearest(F(l+h,2))
            for S in overlap:assert row in S;intersections+=1
            # At this width an arbitrary descendant has its midpoint among these at most 2 integer indices.
            if (h-l)*1024<=H:
                micro+=1;lrow=nearest(F(l));hrow=nearest(F(h))
                for S in overlap:assert all(j in S for j in range(lrow,hrow+1))
            else:
                mid=(l+h)//2;todo.extend([(l,mid),(mid,h)])
        scopes.append(dict(n=n,enumerated=visited,terminal_angular_intervals=micro,validated_band_intersections=intersections))
    ps=comp/'five_grouped_localization.cpp';txt=ps.read_text()
    assert 'cut=3684498829194' in txt and 'hi[2]=std::min(hi[2],cut)' in txt and 'auto mid=l+(h-l)/2' in txt
    out.write_text(json.dumps(dict(cut=cut,trees=scopes,fit_sha256=sha256(fit.read_bytes()).hexdigest(),clip_source_sha256=sha256(ps.read_bytes()).hexdigest()),indent=2)+'\n')
    print(scopes)
if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ['comp','tree','fit','out']:p.add_argument(k,type=Path)
    a=p.parse_args();run(a.comp,a.tree,a.fit,a.out)

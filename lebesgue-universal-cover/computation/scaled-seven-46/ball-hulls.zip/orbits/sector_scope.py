"""All angle rows reachable from a binary angular interval meeting one specified open true-angle band."""
from fractions import Fraction as F


def admissible(n, index, count, hi, cut):
    # Integer coordinates are physical radians times 2^44. Indices use original H units.
    assert hi.denominator==1;H=int(hi)
    left=F(index*H,count);right=F((index+1)*H,count)
    if n==5:right=min(right,F(cut))
    assert left<right
    selected={0,512,1024}
    layer={(0,H//2),(H//2,H)}
    # Any angle interval may descend first in original dyadic coordinates and then be clipped in the five-body screen.
    selected.add(512)
    seen=set()
    while layer:
        l,h=layer.pop()
        if (l,h) in seen:continue
        seen.add((l,h))
        if max(left,l)>=min(right,h):continue
        if n==5 and l<cut<h:layer.add((l,cut))
        def nearest(x):return (F(1024*x,H)+F(1,2)).__floor__()
        if (left<=l and h<=right) or h-l<=H//1024:
            # Even endpoint choices of every further descendant lie in this range.
            selected.update(range(max(0,nearest(l)-1),min(1024,nearest(h)+1)+1))
            continue
        mid=(l+h)//2
        center=F(l+h,2)
        # 256 integer coordinates on each side cover any shallow midpoint rounding.
        selected.update(range(max(0,nearest(center-256)),min(1024,nearest(center+256))+1))
        layer.update(((l,mid),(mid,h)))
    ranges=[]
    for j in sorted(selected):
        if ranges and ranges[-1][1]+1==j:ranges[-1][1]=j
        else:ranges.append([j,j])
    return ranges

"""Exact integer hulls, certified rotations and directed distance brackets for inverse-rotated material orbits."""
from argparse import ArgumentParser
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
from flint import arb,ctx
import numpy as np


def hull(A):
    # Lexicographic sort with record-number tiebreak. Exact monotone chain on Python integers.
    order=np.lexsort((np.arange(len(A)),A[:,1],A[:,0]))
    pts=[(int(A[i,0]),int(A[i,1]),int(i)) for i in order]
    uniq=[]
    for p in pts:
        if not uniq or p[:2]!=uniq[-1][:2]:uniq.append(p)
    def chain(it):
        q=[]
        for p in it:
            while len(q)>=2:
                a,b=q[-2:];cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
                if cross>0:break
                q.pop()
            q.append(p)
        return q
    lo=chain(uniq);hi=chain(reversed(uniq))
    return np.array([t[2] for t in lo[:-1]+hi[:-1]],dtype=np.int64)


def norm2(a,b):
    return (a[0]-b[0])**2+(a[1]-b[1])**2


def calip(A):
    # Antipodal vertex scan on a CCW strictly convex integer hull; both ends of a plateau are admitted.
    p=[(int(x),int(y)) for x,y in A];m=len(p);j=1;best=-1;pair=None
    for i,a in enumerate(p):
        b=p[(i+1)%m]
        def det(k):
            x,y=p[k%m];return (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])
        while det(j+1)>det(j):j+=1
        for t in ([j,j+1] if det(j+1)==det(j) else [j]):
            for k in [i,(i+1)%m]:
                v=norm2(p[k],p[t%m])
                if v>best:best=v;pair=(k,t%m)
    return best,pair


def ar(q):
    return arb(q.numerator)/q.denominator


def rotate_raw(p,C,S):
    # For signed integers a,b, assemble nearest (a*C+b*S)/2^30 by splitting each trig word at bit 22.
    def one(a,b,c,s):
        hi=a*(c>>22)+b*(s>>22)
        lo=a*(c%(2**22))+b*(s%(2**22))
        return hi//256+((hi%256)*(2**22)+lo+2**29)//2**30
    x=p[:,0].astype(np.int64);y=p[:,1].astype(np.int64)
    return np.stack([one(x,y,C,S),one(y,-x,C,S)],axis=1)


def round_trig(z,den):
    v=round(float(z.mid())*den)
    assert abs(z*den-v)<1
    return v


def run(a):
    assert __debug__
    ctx.prec=192;sys.path.insert(0,str(a.comp.resolve()))
    from certify_polygon_083731 import Q,verified_table
    from certify_tomar_six_high import SourceTree
    T=SourceTree(a.tree)
    src=json.loads((a.comp/'tomar-six-high-input.json').read_bytes());L=2**46;M=2**48
    out=[]
    for b,n in [(2,5),(3,7),(4,9)]:
        records=[];specs=[('full',1025)]
        if n==5:specs.append(('lower-half',513))
        H=F(T.root['hi'][3*b-4]);trig=[]
        for j in range(1025):
            ss,cc=ar(H*j/1024).sin_cos()
            trig.append((round_trig(cc,M),round_trig(ss,M)))
        table_data=[]
        for lev,f in [(32,a.table32),(64,a.table64)]:
            counts,A,raw_hash=verified_table(f,T,lev,src['tables'][str(lev)]);offs=np.r_[0,np.cumsum(counts)]
            p=A[:,offs[b]:offs[b+1]];assert np.max(abs(p.astype(np.int64)))<Q
            # Coordinates times L differ from computed integer vectors by <1 in each axis.
            # trig error <1/M, coordinate magnitudes <1, plus final nearest-integer error <=1/2.
            assert F(2*L,M)+F(1,2)<=1
            row_points=[];single=[]
            for j,r in enumerate(p):
                row_points.append(rotate_raw(r,*trig[j]))
                ix=hull(r);ds,ij=calip(r[ix]);single.append([ds,j,int(ix[ij[0]]),int(ix[ij[1]])])
            table_data.append((lev,np.array(row_points,dtype=np.int64),single))
        for tag,N in specs:
            clouds=[];labels=[];single=[]
            for lev,p,candidates in table_data:
                flat=p[:N].reshape(-1,2);ix=hull(flat)
                clouds.extend(flat[ix]);labels.extend([lev,int(i//p.shape[1]),int(i%p.shape[1])] for i in ix)
                ds,j,i,k=max(candidates[:N]);single.append([ds,lev,j,i,k])
            ids=hull(np.asarray(clouds));P=np.asarray(clouds)[ids];labels=[labels[i] for i in ids]
            orb=[];oids=[];M2=2**48
            for flip in (1,-1):
                for k in range(n):
                    ss,cc=(2*arb.pi()*k/n).sin_cos();C=round_trig(cc,M2);S=round_trig(ss,M2)
                    for z,name in zip(P,labels):
                        x=int(z[0]);y=int(z[1])*flip
                        u=(x*C-y*S+M2//2)//M2;v=(x*S+y*C+M2//2)//M2
                        orb.append([u,v]);oids.append([*name,flip,k])
            # True orbit is within < 2*sqrt(2)/L of the rounded convex hull in Hausdorff distance.
            assert max(max(abs(x),abs(y)) for x,y in orb)<L
            assert max(max(abs(int(x)),abs(int(y))) for x,y in P)<L
            assert F(2*L,M2)+F(1,2)<=1
            orb=np.asarray(orb,dtype=np.int64);ix=hull(orb)
            A=orb[ix];keys=[oids[i] for i in ix];ds,ij=calip(A)
            # A complete quadratic integer check on the final few hundred vertices.
            vertices=[(int(x),int(y)) for x,y in A]
            assert max(norm2(p,q) for i,p in enumerate(vertices) for q in vertices[:i])==ds
            err=4*arb(2).sqrt()/L;guess=arb(ds).sqrt()/L;one=max(single)
            rec=dict(n=n,scope=tag,preorbit_hull_vertices=len(P),orbit_hull_vertices=len(A),diameter_lower=str((guess-err).lower()),diameter_upper=str((guess+err).upper()),
                     maximizing_grid_labels=[keys[i] for i in ij],same_row_max_squared=str(F(one[0],Q**2)),same_row_diameter=str(arb(one[0]).sqrt()/Q),
                     same_row_attainer=one[1:])
            out.append(rec);print(n,tag,rec['diameter_upper'],rec['same_row_diameter'],flush=True)
    a.out.write_text(json.dumps(dict(precision=ctx.prec,grid=L,trig_grid=M,records=out),indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ['comp','tree','table32','table64','out']:p.add_argument(k,type=Path)
    run(p.parse_args())

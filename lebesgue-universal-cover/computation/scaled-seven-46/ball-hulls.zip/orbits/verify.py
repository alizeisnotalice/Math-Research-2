"""Certify the diameter of one fixed, dihedrally symmetric generating cloud for all physical poses of each body."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import sys,json
import numpy as np
from flint import arb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parent))
from diameter import hull,calip,ar,norm2,round_trig,rotate_raw

def run(a):
    ctx.prec=192;assert __debug__
    sys.path[:0]=[str(a.comp.resolve()),str(a.scopes.resolve().parent)]
    from certify_polygon_083731 import Q,verified_table
    from certify_tomar_six_high import SourceTree,FINE
    from tomar_d3_mask import CUT
    from sector_scope import admissible
    T=SourceTree(a.tree);src=json.loads((a.comp/'tomar-six-high-input.json').read_bytes())
    sectors=json.loads(a.scopes.read_bytes());cut=-(-CUT.numerator*FINE//CUT.denominator)
    shifts={}
    for f in a.shift:
        for rec in json.loads(f.read_bytes()):
            assert rec['n'] not in shifts and rec['shift_denominator']==10**15
            shifts[rec['n']]=rec['shifts']
    result=[];L=2**46;M=2**48;U=F('.999999005551341');small=F('.9999990051212');lam=F('.999999000058421')
    assert 0<lam<small<U<1
    for b,n in [(2,5),(3,7),(4,9)]:
        H=F(T.root['hi'][3*b-4]);grids=[];stat=[]
        for lev,f in [(32,a.table32),(64,a.table64)]:
            counts,tab,_=verified_table(f,T,lev,src['tables'][str(lev)]);offs=np.r_[0,np.cumsum(counts)];P=tab[:,offs[b]:offs[b+1]]
            assert np.max(np.abs(P.astype(np.int64)))<Q
            mats=[]
            for j,r in enumerate(P):
                sn,cs=ar(H*j/1024).sin_cos();u=round_trig(cs,M);v=round_trig(sn,M)
                mats.append(rotate_raw(r,u,v))
            grids.append(np.asarray(mats))
        sparse=[];labels=[];maxd=0
        bundle=sectors['bodies'][str(n)]
        assert len(bundle)==len(shifts[n]) and [r['sector'] for r in bundle]==list(range(len(bundle)))
        for row,t in zip(bundle,shifts[n]):
            i=row['sector'];R=admissible(n,i,sectors['count_per_order'][str(n)],H*FINE,cut);assert row['ranges']==R
            indices=[j for k,h in R for j in range(k,h+1)]
            vs=[];keys=[]
            for lev,tab in zip([32,64],grids):
                cloud=tab[indices].reshape(-1,2)
                ii=hull(cloud);vs.extend(cloud[ii]);keys.extend([i,lev,indices[p//tab.shape[1]],int(p%tab.shape[1])] for p in ii)
            vv=np.asarray(vs,dtype=np.int64);ii=hull(vv);tq=np.array([(int(c)*L+10**15//2)//10**15 for c in t],dtype=np.int64)
            assert all(abs(F(int(v),L)-F(z,10**15))<=F(1,2*L) for v,z in zip(tq,t))
            sparse.extend(vv[ii]-tq);labels.extend(keys[j] for j in ii);maxd=max(maxd,sum(z*z for z in t))
        A=np.asarray(sparse);ii=hull(A);A=A[ii];ids=[labels[i] for i in ii];rot=[];rid=[]
        for flip in (1,-1):
            for g in range(n):
                sn,cs=(2*arb.pi()*g/n).sin_cos();c=round_trig(cs,M);s=round_trig(sn,M)
                for (x,y),key in zip(A,ids):
                    x=int(x);y=int(y)*flip
                    rot.append([(x*c-y*s+M//2)//M,(x*s+y*c+M//2)//M]);rid.append([*key,flip,g])
        assert np.max(np.abs(A))<L and F(2*L,M)+F(1,2)<=1
        rot=np.asarray(rot);ii=hull(rot);B=rot[ii];ids=[rid[i] for i in ii]
        ds,ij=calip(B);pts=[(int(x),int(y)) for x,y in B]
        assert ds==max(norm2(x,y) for i,x in enumerate(pts) for y in pts[:i])
        err=5*arb(2).sqrt()/L;v=arb(ds).sqrt()/L;up=(v+err).upper();lo=(v-err).lower()
        assert up<ar(small),(n,up,small)
        extra=arb(maxd).sqrt()/10**15
        # Raw unshifted points lie in U B_n; each generator moves by at most 'extra'.
        circum=1/(2*(arb.pi()/(2*n)).cos())
        mixed=(ar(lam)+ar(U-lam)*circum+extra).upper()
        assert mixed<ar(small)
        res=dict(n=n,cloud_diameter_lower=str(lo),cloud_diameter_upper=str(up),cross_diameter_upper=str(mixed),
            sectors=len(bundle),squared_maximum_pose_shift=str(F(maxd,10**30)),maximizing_labels=[ids[i] for i in ij],
            rounded_hull_vertices=len(B),squared_grid_diameter=ds)
        result.append(res);print(n,up,mixed,flush=True)
    d=dict(scale=str(small),base=str(lam),old_containing_scale=str(U),input_scope_sha256=sha256(a.scopes.read_bytes()).hexdigest(),
        shift_sha256={q.name:sha256(q.read_bytes()).hexdigest() for q in a.shift},records=result,area_floor=str(F(120689264254125501,2**57)/small**2))
    a.out.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ['comp','tree','table32','table64','scopes','out']:p.add_argument(k,type=Path)
    p.add_argument('--shift',type=Path,nargs='+',required=True)
    run(p.parse_args())

"""Assemble orbit diameter, within-row obstruction, radial and finite-material certificates."""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
from flint import arb,ctx
import numpy as np

def read(p):return json.loads(p.read_bytes())
def ar(x):
    q=F(x);return arb(q.numerator)/q.denominator
def run(a):
    ctx.prec=192
    dr=read(a.diameter);sd=read(a.shifted);dense=read(a.dense);du=read(a.comp/'critical-material-scale/records/materials.json')
    assert len(dr['records'])==4 and len(sd['records'])==3 and dense['count']==1247520
    U=F(sd['old_containing_scale']);lam=F(sd['base']);s=F(sd['scale']);G=F(120689264254125501,2**57)
    assert F(du['scale'])<=U and set((x['table'],x['order']) for x in du['results'] if x['order'] in (5,7,9) and x['positive'])=={(t,n) for t in [32,64] for n in (5,7,9)}
    cert_sha=sha256((a.comp/'critical-material-scale/records/materials.json').read_bytes()).hexdigest()
    known=read(a.comp/'critical-material-scale/records/result.json');assert known['hashes']['materials.json']==cert_sha
    assert all(arb(x['max_coordinate_error_grid'])<1 for x in dense['rows'])
    alpha=F('.999997');shift=F(4,10**10);w=F('.42');Q=2**28
    gap=(ar((lam-alpha)*w-shift)-arb(2).sqrt()/Q).lower();assert gap>ar(F('.00000083'))
    # Verify raw integer witnesses of the hard lower individually instead of relying on the hull search.
    hard=[]
    for rec in dr['records']:
        if rec['scope']!='full':continue
        n=rec['n'];lev,j,i,k=rec['same_row_attainer'];assert lev==64
        with np.load(a.table64) as tab:
            b={5:2,7:3,9:4}[n];o=sum(tab['counts'][:b])
            A=list(map(int,tab['points'][j,o+i]));B=list(map(int,tab['points'][j,o+k]))
        d2=F(sum((a-b)**2 for a,b in zip(A,B)),Q**2)
        assert d2==F(rec['same_row_max_squared']);hard.append(dict(order=n,row=j,points=[A,B],ids=[i,k],squared=str(d2)))
    z=next(r for r in hard if r['order']==7);assert F(z['squared'])>F('.9999990049564463')**2
    rr=read(a.radial);assert F(rr['inner_scale'])==lam and all(F(x['gap'])>0 for x in rr['results'])
    for d in sd['records']:
        assert arb(d['cloud_diameter_upper'])<ar(s) and arb(d['cross_diameter_upper'])<ar(s)
        assert F(d['squared_maximum_pose_shift'])<shift**2
    out=dict(scale=str(s),base=str(lam),G=str(G),conditional_area=str(G/s**2),
             dense_extra_margin=str(gap),hard_within_row=hard,confirm_published_material_upper=cert_sha,
             disk_square_radius_margin=None,scope='New fixed testing bodies and original table transfer; ancillary global cap bounds run separately')
    for p in [a.table32,a.table64]:
        with np.load(p) as tab:
            disk=tab['points'][0,:96].astype(np.int64);g=s**2/4-F(int(np.square(disk).sum(axis=1).max()),Q**2)
            assert g>0;out['disk_square_radius_margin']=str(min(g,F(out['disk_square_radius_margin'])) if out['disk_square_radius_margin'] is not None else g)
    a.out.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(z,out['dense_extra_margin'])
if __name__=='__main__':
    a=ArgumentParser()
    for k in ['comp','table32','table64','diameter','shifted','dense','radial','out']:a.add_argument(k,type=Path)
    run(a.parse_args())

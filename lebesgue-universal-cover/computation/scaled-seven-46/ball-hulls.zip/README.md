# 四个固定球凸输入的面积证书

在完整课题资料的基础上，运行以下命令。COMP 是课题仓库中的 computation，TREE 指经 SHA-256 清单认证的 cert11d_08366，TABLE32 与 TABLE64 是发表材料的两张 NPZ 原表，最后的输出目录须为新路径。

~~~sh
python -I -B verify.py "$COMP" "$TREE" "$TABLE32" "$TABLE64" "$OUT" --workers 2
~~~

本次复算环境为 Python 3.13.18、python-flint 0.9.0、NumPy 2.5.5 及 SciPy。原第254轮包在 `$COMP/translated-triangle/certificate.zip`，SHA-256 为 `2ba777f4cf1922841b3d113b9bd104c980a085a41c4cb8f7af609137219889a3`。入口展开后从头运行其原 verify.py，产生 r254/combined.json、15点支撑证明，以及 materials/triangle-extra.json 和24个密根回执。原包自身的 finite-rates.json 只属于旧曲体。新程序读入原表、重建三角材料双极与另三体的可达角行和直径，再算加密舍入、四个8192格的真中心径向、第五个 .703 盘点截断及全部105个逐方向墙。输出 combined.json 与本包 expected.json 比较。

原六输入完整面积树为独立上游。入口重算 six-input-083745/integrate_native45.py 对其压缩包的分支和闭合索引，校验已发表的完整几何复跑账本。账本的1,104,937,301个末端树访问来自此前完整复跑。本入口不重新遍历这些访问。原始复跑程序和细粒度回执在 `$COMP/six-input-083745/replayed/`。本包一次端到端复跑含原 R254 材料验证、662976个三角点对与额外1247520个材料点舍入验证。结论为四个指定球凸体、圆盘和固定15点的任意同宿主摆放，经缩率换算所得的一般下端。证明与整行材料法的局限见 PROOF.md。

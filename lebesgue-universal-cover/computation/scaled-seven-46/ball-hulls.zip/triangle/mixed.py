from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,sys,numpy as np
from flint import arb,ctx
ctx.prec=256;ar=lambda x:arb(x.numerator)/x.denominator;Q=2**28
P32=Path(sys.argv[1]);P64=Path(sys.argv[2]);E=Path(sys.argv[3]);D=Path(sys.argv[4]);O=Path(sys.argv[5]);assert sha256(P32.read_bytes()).hexdigest()=='fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c';assert sha256(P64.read_bytes()).hexdigest()=='0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d';assert sha256(E.read_bytes()).hexdigest()=='209dd844fd308b56257805a58782d158d93217c1769a8e788e292e9967f09203'
with np.load(P32) as z:p32=z['points'][0,96:192].copy()
with np.load(P64) as z:p64=z['points'][0,96:288].copy()
extra=json.loads(E.read_text());d=json.loads(D.read_text());assert d['counts']['unordered_pairs']==662976
R=d['diameter_squared_algebraic'];s=((arb(int(R['integer']))+arb(int(R['sqrt3_integer']))*arb(3).sqrt())/int(R['denominator'])).sqrt(); U=ar(F('.999999005551341'));lam=ar(F('.999999000058421'));r=1/arb(3).sqrt();assert s<U and lam<s and s<1
vs=[(r,arb(0)),(-r/2,arb(1)/2),(-r/2,-arb(1)/2)];stats={}
for name,p in [('table32',p32),('table64',p64),('extra',extra)]:
 vals=[];inner=[]
 for x,y in p:
  X,Y=arb(int(x))/Q,arb(int(y))/Q
  for vx,vy in vs:
   gap=U*U-(X-U*vx)**2-(Y-U*vy)**2;assert gap>0;vals.append(gap.lower())
   if name=='extra':
    gap2=lam*lam-(X-lam*vx)**2-(Y-lam*vy)**2;assert gap2>0;inner.append(gap2.lower())
 stats[name]={'count':len(p),'minimum_U_squared_margin':str(min(vals))}
 if inner:stats[name]['minimum_lambda_squared_margin']=str(min(inner))
cross=lam+(U-lam)*r;assert cross<s
radius=lam*r+s-lam;inside=lam*(1-r);sigma=lam+(s-lam)/(1-r);assert sigma<1;G=arb(120689264254125501)/2**57;area=G/s**2
assert radius<ar(F('.577351')) and inside>ar(F('.42264'))
out={'minimum_s':str(s),'lambda':str(lam),'mixed_upper':str(cross),'mixed_margin':str(s-cross),'outer_radius':str(radius),'inner_radius':str(inside),'outer_homothety_sigma':str(sigma),'area_ratio':str(area),'points':stats};O.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

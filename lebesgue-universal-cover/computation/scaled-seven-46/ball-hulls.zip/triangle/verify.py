from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
if len(sys.argv)!=5:raise SystemExit('usage: verify.py TABLE32 TABLE64 MATERIAL_REPLAY NEW_OUTPUT')
A,B,OLD,OUT=map(lambda x:Path(x).resolve(),sys.argv[1:]);D=Path(__file__).resolve().parent
r=json.loads((OLD/'result.json').read_text());dense=json.loads((OLD/'dense.json').read_text());e=OLD/'triangle-extra.json';assert sha256(e.read_bytes()).hexdigest()=='209dd844fd308b56257805a58782d158d93217c1769a8e788e292e9967f09203';assert sha256((OLD/'dense.json').read_bytes()).hexdigest()==r['output_hashes']['dense.json'];assert r['complete'] and r['triangle_extra_exact_binding'] and r['dense_leaves']==24 and len(dense['leaves'])==24 and all(x['triangle_extra_exact_binding'] and x['original_receipt_closed'] for x in dense['leaves'])
OUT.mkdir(parents=True,exist_ok=False)
for script,args in [('diameter.py',[A,B,e,OUT/'diameter.json']),('mixed.py',[A,B,e,OUT/'diameter.json',OUT/'mixed.json'])]:subprocess.run([sys.executable,'-E','-B',str(D/script),*map(str,args)],check=True)
print('BALL_HULL_R3_COMPLETE')

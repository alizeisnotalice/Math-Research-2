from pathlib import Path
from hashlib import sha256
import numpy as np,json,sys,math
# Each coordinate (a+b sqrt(3))/(2Q); D3 rotations and reflections preserve all entries exactly.
Q=2**28; T32=Path(sys.argv[1]);T64=Path(sys.argv[2]);EX=Path(sys.argv[3]);O=Path(sys.argv[4]);assert sha256(T32.read_bytes()).hexdigest()=='fe5b816060d713642dc44e3f8981f4ae5d1b2b1c1e271b7dff75f031dd75d87c';assert sha256(T64.read_bytes()).hexdigest()=='0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d';assert sha256(EX.read_bytes()).hexdigest()=='209dd844fd308b56257805a58782d158d93217c1769a8e788e292e9967f09203'
with np.load(T32) as z:p32=z['points'][0,96:192].tolist()
with np.load(T64) as z:p64=z['points'][0,96:288].tolist()
extra=json.loads(EX.read_text()); assert (len(p32),len(p64),len(extra))==(96,192,192)
points={}
for kind,data in [('32',p32),('64',p64),('extra',extra)]:
 for i,(x,y0) in enumerate(data):
  for sign in (-1,1):
   y=y0*sign
   for k,(a,b,c,d) in enumerate([(2*x,0,2*y,0),(-x,-y,-y,x),(-x,y,-y,-x)]):
    key=(a,b,c,d);points.setdefault(key,[]).append([kind,i,sign,k])
P=list(points); print('unique',len(P),flush=True)
def norm2(p,q):
 a,b,c,d=(u-v for u,v in zip(p,q));return (a*a+3*b*b+c*c+3*d*d,2*(a*b+c*d))
def sign(a,b):
 if b==0:return (a>0)-(a<0)
 if a==0:return (b>0)-(b<0)
 if (a>0)==(b>0):return 1 if a>0 else -1
 diff=a*a-3*b*b
 return (1 if a>0 else -1)*(1 if diff>0 else -1) if diff else 0
best=(0,0);pair=None;ties=[];count=0
for i,p in enumerate(P):
 for j in range(i):
  z=norm2(p,P[j]);cmp=sign(z[0]-best[0],z[1]-best[1]);count+=1
  if cmp>0:best=z;pair=(i,j);ties=[(i,j)]
  elif cmp==0:ties.append((i,j))
from flint import arb,ctx
ctx.prec=256
val=(arb(best[0])+arb(best[1])*arb(3).sqrt())/(2*Q)**2;di=val.sqrt()
out={'counts':{'32':len(p32),'64':len(p64),'extra':len(extra),'unique_orbit':len(P),'unordered_pairs':count,'maximizing_pairs':len(ties)},'diameter_squared_algebraic':{'integer':str(best[0]),'sqrt3_integer':str(best[1]),'denominator':str((2*Q)**2)},'diameter_squared':str(val),'diameter':str(di),'witnesses':[{'orbit_coordinates':P[k],'source_labels':points[P[k]]} for k in pair]}
O.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

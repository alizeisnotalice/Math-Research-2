"""Reduce the common scale, using true weighted support rather than maximum motion on the alternate Q grid."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json,sys,subprocess
from flint import arb,ctx
BASE=Path(__file__).resolve().parent
def ar(x):
    q=F(x);return arb(q.numerator)/q.denominator
def read(p):return json.loads(p.read_bytes())
def assay(comp,treepath,prior,out):
    ctx.prec=192;sys.path.insert(0,str(comp.resolve()))
    from certify_tomar_six_high import SourceTree
    native=prior/'native-replay/native'
    old=read(prior/'result.json');G=F(120690705406006259,2**57);s=F('.999999995');e=1-s;r=F(1,2)
    tree=SourceTree(treepath);eight=old['eight_baseline_roots'];assert len(eight)==8 and old['native_stage4']==5442
    k=F('.999999996296');D=read(native/'inputs/augmented.json');P=[(F(x,D['denominator']),F(y,D['denominator'])) for x,y in D['points']]
    pd=k*k*max((a-x)**2+(b-y)**2 for (a,b),(x,y) in combinations(P,2))
    pm=(1-k)**2*max(x*x+y*y for x,y in P)
    assert len(P)==128 and pd<s*s and pm<(F('.4464')*e)**2
    q=read(out/'rows.json');assert F(q['scale'])==s and F(q['squared_diameter'])<s*s and F(q['max_point_loss_squared'])<(F('.67')*e)**2
    assert q['closed_rows']==12885 and F('.454')==F(q['rate'])
    dense=ar(F('.9999990055114'))+ar(F('.000000000062')/F('.42'));assert dense<ar(s)
    original_max=F(old['real_triangle_center_sq_max'])
    alt_max=max(sum(max(x*x,y*y) for x,y in tree.leaf(*key)[:2]) for key in eight)
    cap=[];root=ar(s).sqrt();pi=arb.pi()
    for subset,maximum,w,m in [('ordinary',original_max,F('.468'),F('.4464')),('alternate',alt_max,F('.474'),F('.454'))]:
        assert maximum<(r-w)**2 and all(1-1/(2*(pi/(2*n)).cos())>ar(w) for n in (5,7,9))
        z=ar(F(1,4000)).sqrt()/(root*(1+root))+ar((1+s)*r*r-2*m*r+m*m*e)/(4*root*ar(2*r))
        assert (1+s)*r*r-2*m*r+m*m*e>0 and z<ar(w-m)
        cap.append(dict(family=subset,triangle_center_squared_max=str(maximum),wall_rate=str(w),
            projected_loss_rate=str(m),available=str(w-m),required=str(z)))
    for R in [F('.706'),F('.707')]:
        assert ar(R)**2<2*ar(s*r)**2 and (pi-(ar(s*r)/ar(R)).acos())*ar(s*r)**2+ar(s*r)*(ar(R)**2-ar(s*r)**2).sqrt()>ar(G)
    assert (ar(F('.707'))+ar(F('.454')*e))**2<2*ar(r)**2
    d=F('.67')*e;upper=F('.83750')-G-F(22,7)*(2*F('.707')*d+d*d)
    assert upper>0
    ratio=G/s**2;floor=F('.8374600083746000');assert floor<ratio
    result=dict(area=str(G),scale=str(s),bound=str(ratio),strict_floor=str(floor),cap=cap,
        higher_target_remaining=str(upper),P128_factor=str(k),P128_squared_diameter=str(pd),
        P128_maximum_squared_displacement=str(pm),Qavg_source_sha256=q['ordinary_bank_sha256'],
        Qavg_diameter_squared=q['squared_diameter'],Qavg_row_margin=q['minimum_wall_adjusted_row_margin'],
        Qavg_alt_rows=q['closed_rows'],Qavg_standard_rows=2258,Qavg_expanded_rows=3794)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(ratio)
if __name__=='__main__':
    comp,tree,prior,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir(parents=True,exist_ok=False)
    subprocess.run([sys.executable,'-I','-B',str(BASE/'rows.py'),str(prior/'native-replay/native'),str(BASE/'shifts.json'),str(out/'rows.json')],check=True)
    assay(comp,tree,prior,out)

# 闭角格投影替换的七输入下端

使用 Python 3.13、NumPy、python-flint、Apple Clang 与原计算仓。TABLE64 和 TREE 分别为认证64级 NPZ 材料和 cert11d_08366。OUT 须是新的目录。临时卷和模块缓存按宿主现有配置指定。

~~~sh
python -I -B verify.py "$COMP" "$TREE" "$TABLE64" "$OUT" "$CLANG_CACHE"
~~~

包内 base.zip 重算公开 seven-083746.zip 的七输入账本、Qavg接口和独立八原根五体整数核，完整操作与局限见其 README.md 和 PROOF.md。随后脚本从同一公开包读取12885条替代Q行，在384个闭角格上试用和认证新十一点支撑，逐对核其直径，再检查两个墙下移常数和全体有理面积预算。已经生成基本包输出时，可以直接运行下列命令。

~~~sh
python -I -B extend.py "$COMP" "$TREE" "$OLD_OUTPUT" "$NEW_OUTPUT"
~~~

expected-rows.json 的 points 可直接按 integer_denominator 读入。P128 的原点表在公开包 native/inputs/augmented.json，乘 expected.json 的 P128_factor。拟合过程只提供有理点的候选值，证书完全由原积分核、整数与有理判据和 Arb 定向运算承担。

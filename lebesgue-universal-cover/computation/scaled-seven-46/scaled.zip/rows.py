"""Certify a deformed Qavg continuously on the alternate closed angle grid."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import gzip,json,itertools,sys,zipfile
import numpy as np
from flint import arb,ctx
def ar(q):
    q=F(q); return arb(q.numerator)/q.denominator
def read(p):return json.loads(p.read_bytes())
def run(native,moves,out):
    ctx.prec=192
    shift=read(moves);e=F(shift['epsilon']);s=1-e; Z=2**28;U=2**22
    assert e==F(1,200000000)
    data=read(native/'inputs/q11-receipt.json');den=data['denominator'];P=data['points']
    delta=[tuple(F(v,shift['direction_denominator'])*e for v in z) for z in shift['directions']]
    X=[(F(x,den)+a,F(y,den)+b) for (x,y),(a,b) in zip(P,delta,strict=True)]
    assert {(x,-y) for x,y in X}==set(X) and len(X)==11
    d2=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in itertools.combinations(X,2));assert d2<s*s
    loss2=max(x*x+y*y for x,y in delta)
    assert loss2<(F('.67')*e)**2
    normal_min=F(U-2,U);normal_max=F(U+2,U)
    assert F('.67')*e*normal_max-F(1,Z)<F('.4464')*e*normal_min
    m=F('.454');bounds=[];worst=None;rows_out=0
    with zipfile.ZipFile(native/'replay-kits/portable-ordinary46.zip') as packet:
        raw=gzip.decompress(packet.read('ordinary-bank.json.gz'))
    bank=json.loads(raw);dirs=bank['directions'];assert len(dirs)==256 and len(bank['cells'])==768
    assert all((U-2)**2<=u*u+v*v<=(U+2)**2 for u,v in dirs)
    pi=arb.pi();sw,cw=(pi/384).sin_cos()
    Y=np.asarray([[float(x),float(y)] for x,y in X]);V=np.asarray(dirs,float)
    for j,cell in enumerate(bank['cells'][384:]):
        sn,cs=((2*j+1)*pi/384).sin_cos(); a,b=float(cs.mid()),float(sn.mid())
        ids=(V@(Y@np.array([[a,b],[-b,a]])).T).argmax(axis=1)
        cache={}
        for row in cell:
            ix,w,ws,low=row[:3],row[3:6],row[6],row[7];assert min(w)>0 and sum(w)==ws
            assert all(sum(wi*dirs[k][t] for wi,k in zip(w,ix))==0 for t in (0,1))
            for k in ix:
                if k in cache:continue
                vx,vy=dirs[k];px,py=map(ar,X[ids[k]])
                u,b=vx*cs+vy*sn,-vx*sn+vy*cs
                cache[k]=(u*px+b*py,b*px-u*py)
            A=sum(wi*cache[k][0] for wi,k in zip(w,ix));B=sum(wi*cache[k][1] for wi,k in zip(w,ix))
            assert A>0
            # A cos(t)+B sin(t) >= A cos(pi/384)-abs(B)sin(pi/384).
            val=(A*cw-abs(B)*sw)/(ws*U)
            gap=(val+ar(m*e*normal_min-F(low,Z))).lower()
            assert gap>0,(j,ix,gap)
            if worst is None or gap<worst:worst=gap;hit=(j,rows_out)
            rows_out+=1
    assert rows_out==12885
    d=1
    from math import lcm
    d=lcm(*(v.denominator for x in X for v in x))
    result=dict(scale=str(s),rate=str(m),integer_denominator=d,points=[[int(q*d) for q in x] for x in X],
        max_point_loss_squared=str(loss2),squared_diameter=str(d2),closed_rows=rows_out,angles=384,
        minimum_wall_adjusted_row_margin=str(worst),critical_row=hit,ordinary_bank_sha256=sha256(raw).hexdigest())
    out.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':run(*map(Path,sys.argv[1:]))

"""Rebuild the published seven-input tree, eight local material bounds and the projected Q replacement."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json,subprocess,sys,zipfile
D=Path(__file__).resolve().parent
p=ArgumentParser(description=__doc__)
for n in ('comp','tree','table64','work','cache'):p.add_argument(n,type=Path)
a=p.parse_args();comp,tree,table,work,cache=map(Path.resolve,(a.comp,a.tree,a.table64,a.work,a.cache))
assert __debug__ and sha256((D/'base.zip').read_bytes()).hexdigest()=='c27c5e710319fdb9884037435cbeb507761b5887aa56e989e3699231c258e02a'
work.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(D/'base.zip') as z:
    assert all(not Path(f).is_absolute() and '..' not in Path(f).parts for f in z.namelist())
    z.extractall(work/'base-code')
def run(script,*args):subprocess.run([sys.executable,'-I','-B',str(script),*map(str,args)],check=True)
run(work/'base-code/verify.py',comp,tree,table,work/'base',cache)
run(D/'extend.py',comp,tree,work/'base',work/'enhanced')
for f,expected in [('result.json','expected.json'),('rows.json','expected-rows.json')]:
    assert json.loads((work/'enhanced'/f).read_bytes())==json.loads((D/expected).read_bytes())
print('PROJECTED_SEVEN_COMPLETE')

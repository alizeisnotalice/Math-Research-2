Four original leaves of shard 1205 with pure five-body area above 0.837403.
Use the public cert11d_08366 and original upstream checkout at revision
10af98606c98ca9ffd0d9f402cae1e2efe74b792. Python requires NumPy, SciPy and python-flint.
With UPSTREAM, CERT, WORK and CACHE as local paths, run

    python -I -B replay_five_selected_leaves_083743e6.py UPSTREAM CERT WORK CACHE --target .837403 --budget 32768
    python -I -B verify_five_selected_083743e6_traces.py WORK --target .837403 --expect expected

The frozen records verify all four whole-box area bounds and every trace is
accounted for by its original root, exact splits and valid contraction steps.

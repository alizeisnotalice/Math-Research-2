"""Independent schema, source, geometric-identity and interval-coverage checks for the initial derivative."""
import argparse,json
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from flint import arb,ctx

def audit(comp,conf,receipt,physical_area):
    ctx.prec=160
    cfg=json.loads(conf.read_bytes());q=json.loads(receipt.read_bytes());pa=json.loads(physical_area.read_bytes())
    assert q['parameters']==cfg and q['complete'] and q['all_passed']
    physical=json.loads((comp/cfg['physical']).read_bytes())
    assert physical==pa['parameters']==q['physical_parameters']
    assert q['geometry_sha256']==pa['chart']['geometry_sha256']
    base=Path(__file__).parent
    sources=[base/f for f in ('ordered_derivative.py','ordered_state.py','certify_ordered_derivative.py')]+[conf,comp/cfg['physical']]+[comp/f for f in ('certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py','certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py')]
    assert q['source_hashes']=={p.name:sha256(p.read_bytes()).hexdigest() for p in sources}
    assert F(q['EH_tightening']['retreat'])==F(cfg['retreat'])>=0 and q['EH_tightening']['label'].startswith('U1-Te')
    buckets={};blocks={};minima={}
    assert sorted(set(cfg['bins']))==sorted(cfg['bins'])
    for t in q['rows']:
        j=t['bin'];k,tail=t['counts'];side=t['initial_derivative_sign'];ori=t['orientation'];r=t['row']
        assert j in cfg['bins'] and ori in (0,1) and 0<=k<=5 and tail==5-k and side in (-1,1)
        assert r['reference_bin']==j and r['anchor_comparison_sign']==side and F(r['anchor_threshold'])==-F(cfg['cut']) and F(r['anchor_degrees'])==0
        assert list(map(F,r['bracket']))==list(map(F,cfg['brackets'][int(side==1)][:2]))
        a,b=r['subcells'];assert 0<=a<b<=75
        buckets.setdefault((j,ori,k,side),[]).extend(range(a,b))
        blocks.setdefault((j,ori,k,side),[]).append((a,b))
        root,pose=[arb(r[name]).lower() for name in ('root_margin_lower','placement_margin_lower')]
        assert t['positive'] and root>0 and pose>0
        old=minima.get(j,(arb(1),arb(1)))
        minima[j]=min(root,old[0]),min(pose,old[1])
    for j in cfg['bins']:
        rr=pa['chart']['reference_ranges'][str(j)]
        assert rr==q['reachable'][str(j)]
        target=[i for a,b in rr for i in range(a,b)]
        for ori in (0,1):
            for k in range(6):
                for side in (-1,1):
                    assert sorted(buckets[j,ori,k,side])==target
                    assert sorted(blocks[j,ori,k,side])==sorted(blocks[j,ori,0,side])
    return {j:{'root':str(x),'pose':str(y),'retreat':cfg['retreat']} for j,(x,y) in minima.items()}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('comp','conf','receipt','physical_area'):p.add_argument(k,type=Path)
    a=p.parse_args();print(json.dumps(audit(a.comp,a.conf,a.receipt,a.physical_area),indent=2))

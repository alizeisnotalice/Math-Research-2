"""Verify adaptive closed reference ranges using the simultaneous five-contact class."""
import argparse,inspect,json,sys,hashlib
from fractions import Fraction as F
from pathlib import Path

def run(comp,config,out):
    cfg=json.loads(config.read_text())
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from flint import arb
    from ordered_state import support_bound
    from certify_sigma_extended_graph import geometry
    from certify_ah_affine_root_class import validate
    from certify_sigma_reachable_roots import reach
    q=json.loads((comp/cfg['physical']).read_text())
    pivot,turn=map(F,q['line']);far,negative,eps=map(F,q['physical_parameters'])
    n,src,_=geometry(comp,[(pivot,turn)],sigma=q['sigma_degrees'],far=far,negative=negative,eps=eps)
    n['_sharpen_jets']=True
    idx,=[i for i,(label,_,_) in enumerate(n['rows']) if label.startswith('U1-Te')]
    label,vec,c=n['rows'][idx];retreat=F(cfg['retreat'])
    assert retreat>=0 and F(n['eh_depth'])==F('.000555')
    n['rows'][idx]=label,vec,c-n['A'](retreat)
    old='a=r0+i*step;b=a+step';new='a=r0+i*step;b=r0+ns["_end_index"]*step'
    s=inspect.getsource(validate);assert s.count(old)==1
    env={**validate.__globals__,'support_bound':support_bound}
    exec(compile(s.replace(old,new),'physical_state_class','exec'),env)
    ans=[];red=[]
    root_min=pose_min=arb(1)
    def visit(j,a,b,ori,counts,side):
        nonlocal root_min,pose_min
        n['_first_orientation']=ori;n['_class_counts']=counts;n['_end_index']=b
        anchor=F(cfg['anchor'])
        options=(cfg['low_brackets'] if side==-1 else cfg['high_brackets'])
        for l,r,turn in options:
            if side==-1:assert F(r)==anchor
            row=env['validate'](n,j,F(l),F(r),turn,1,1,begin=a,end=a+1,angular=12,depth=cfg['depth'],anchor=anchor,threshold=F(cfg['threshold']),condition_sign=side)
            pos=all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
            if pos:break
        if not pos and b-a>1:
            mid=(a+b)//2
            visit(j,a,mid,ori,counts,side)
            visit(j,mid,b,ori,counts,side)
        else:
            row['subcells']=[a,b]
            item={'bin':j,'orientation':ori,'counts':list(counts),'angle_class':side,'row':row}
            ans.append(item)
            if not pos:red.append(item)
            root_min=min(root_min,arb(row['root_margin_lower']).lower())
            pose_min=min(pose_min,arb(row['placement_margin_lower']).lower())
    inputs={str(j):reach(n,j) for j in cfg['bins']}
    for j in cfg['bins']:
        for ori in (0,1):
            for k in range(6):
                for side in (-1,1):
                    for left,right in inputs[str(j)]:
                        for start in range(left,right,cfg['block']):
                            visit(j,start,min(right,start+cfg['block']),ori,(k,5-k),side)
                print(j,ori,k,len(ans),len(red),str(root_min),str(pose_min),flush=True)
                out.write_text(json.dumps({'complete':False,'rows':ans},indent=1)+'\n')
    for j in cfg['bins']:
        for ori in (0,1):
            for k in range(6):
                for side in (-1,1):
                    intervals=[t['row']['subcells'] for t in ans if (t['bin'],t['orientation'],t['counts'][0],t['angle_class'])==(j,ori,k,side)]
                    assert [i for a,b in intervals for i in range(a,b)]==[i for a,b in inputs[str(j)] for i in range(a,b)]
    hash_file=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    files=[Path(__file__),Path(__file__).with_name('ordered_state.py'),config,comp/cfg['physical'],comp/'certify_ah_affine_root_class.py',comp/'certify_sigma_pinned_fan.py',comp/'certify_sigma_extended_graph.py']
    out.write_text(json.dumps({'complete':True,'all_passed':not red,'parameters':cfg,'physical_parameters':q,'reachable':inputs,'EH_tightening':{'label':label,'retreat':str(retreat)},'root_min':str(root_min),'pose_min':str(pose_min),'source_hashes':{p.name:hash_file(p) for p in files},'geometry_sha256':hashlib.sha256(src.encode()).hexdigest(),'flint':n['flint_version'],'python':sys.version,'rows':ans},indent=1)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for z in ('comp','config','out'):p.add_argument(z,type=Path)
    x=p.parse_args();run(x.comp.resolve(),x.config.resolve(),x.out)

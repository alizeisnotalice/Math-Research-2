"""Verify both initial-slope branches on oriented, stratified physical contact ranges."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import sys,json,argparse


def run(comp,config,target):
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from flint import arb
    from ordered_derivative import validate
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach
    q=json.loads(config.read_bytes());physical=json.loads((comp/q['physical']).read_bytes())
    h,e=map(F,physical['line']);pars=dict(zip(('far','negative','eps'),map(F,physical['physical_parameters'])))
    ns,source,_=geometry(comp,[(h,e)],sigma=physical['sigma_degrees'],**pars)
    ns['_sharpen_jets']=True
    index,=[i for i,(label,_,_) in enumerate(ns['rows']) if label.startswith('U1-Te')]
    label,normal,offset=ns['rows'][index];retreat=F(q['retreat'])
    assert retreat>=0 and F(ns['eh_depth'])==F('.000555')
    ns['rows'][index]=label,normal,offset-ns['A'](retreat)
    ranges={j:reach(ns,j) for j in q['bins']}
    def test(j,a,b,ori,k,side):
        ns['_end_index']=b;ns['_first_orientation']=ori;ns['_class_counts']=(k,5-k)
        l,r,t,s=q['brackets'][int(side==1)]
        row=validate(ns,j,F(l),F(r),t,s,side,cut=F(q['cut']),side=side,begin=a,end=a+1,angular=12,depth=q['depth'])
        passed=all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
        if passed or b-a==1:
            row['subcells']=[a,b]
            return [{'bin':j,'orientation':ori,'counts':[k,5-k],'initial_derivative_sign':side,'row':row,'positive':passed}]
        mid=(a+b)//2
        return test(j,a,mid,ori,k,side)+test(j,mid,b,ori,k,side)
    rows=[]
    for j in q['bins']:
        for ori in (0,1):
            for k in range(6):
                for side in (-1,1):
                    part=[]
                    for l,r in ranges[j]:
                        for i in range(l,r,q['block']):part+=test(j,i,min(r,i+q['block']),ori,k,side)
                    assert [i for t in part for i in range(*t['row']['subcells'])]==[i for a,b in ranges[j] for i in range(a,b)]
                    rows+=part
                print(j,ori,k,len(rows),sum(not t['positive'] for t in rows),flush=True)
                target.write_text(json.dumps({'complete':False,'rows':rows},indent=1)+'\n')
    def digest(p):return sha256(p.read_bytes()).hexdigest()
    paths=[Path(__file__),Path(__file__).with_name('ordered_state.py'),Path(__file__).with_name('ordered_derivative.py'),config,comp/q['physical']]+[comp/f for f in ('certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py','certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py')]
    mins={z:str(min(arb(t['row'][z]).lower() for t in rows)) for z in ('root_margin_lower','placement_margin_lower')}
    target.write_text(json.dumps({'complete':True,'all_passed':all(t['positive'] for t in rows),'parameters':q,'physical_parameters':physical,'reachable':ranges,'EH_tightening':{'label':label,'retreat':str(retreat)},'minima':mins,'flint':ns['flint_version'],'geometry_sha256':sha256(source.encode()).hexdigest(),'source_hashes':{p.name:digest(p) for p in paths},'rows':rows},indent=1)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for arg in ('comp','config','receipt'):p.add_argument(arg,type=Path)
    a=p.parse_args();run(a.comp.resolve(),a.config,a.receipt)

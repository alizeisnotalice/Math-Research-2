"""Regenerate selected raw .011 root and placement receipts from their recorded inputs."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json,shutil,subprocess,sys
KIT=Path(__file__).resolve().parent

def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()

def replay(comp,work,selection,list_only):
    first=KIT/'early';middle=KIT/'middle';roots=(first,middle,comp)
    mid=read(middle/'011-j12-69-composed.json');tail=read(middle/'011-j32-69-composed.json');special=read(middle/'011-j38-41-composed.json')
    files={first/(t+'-certificate.json') for t in ('j0-011','j1-3-011-sync','j4-7-011-sync','j8-11-011-sync')}
    for r in mid['bins']:
        paths=[f for f in (first/r['file'],middle/r['file'],middle/'returned'/r['file']) if f.is_file()]
        assert len(paths)==1;files.add(paths[0])
    for r in special['bins']:files.update(middle/f for f in r['input_sha256'])
    for r in tail['bins']:
        for f in r['files']:
            p=middle/f
            if 'rows' in read(p):files.add(p)
    files=sorted(files,key=lambda q:q.name)
    if selection:
        wanted=set(selection);files=[f for f in files if f.name in wanted]
        assert {p.name for p in files}==wanted
    if list_only:
        for f in files:print(f.name)
        return
    work.mkdir(parents=True,exist_ok=True)
    for p in files:
        q=read(p);hh=q['source_hashes'];cfg=q['parameters']
        runners=('certify_derivative_synchronized.py','certify_ordered_derivative.py','certify_synchronized.py',
                 'certify_ordered_root.py','certify_ordered_direct_mixed.py','certify_ordered_direct.py','certify_sigma_jet_bracket.py')
        fname,=[f for f in runners if f in hh]
        candidates=[d/fname for d in roots]+[middle/'certify_ordered_direct_v1.py']
        runner=next(x for x in candidates if x.is_file() and digest(x)==hh[fname])
        if runner.name!=fname:
            legacy=work/'legacy';legacy.mkdir(exist_ok=True);shutil.copyfile(runner,legacy/fname);runner=legacy/fname
        labels=[f for f in hh if f.endswith('.json') and f!='sigma154-turn011-physical.json']
        if labels:
            label,=labels
            conf=next(d/label for d in roots if (d/label).is_file() and digest(d/label)==hh[label])
        else:
            conf=work/(p.stem+'-input.json');conf.write_text(json.dumps(cfg)+'\n')
        assert read(conf)==cfg
        args=[str(comp)]
        if fname in ('certify_ordered_direct.py','certify_ordered_direct_mixed.py'):args.append(str(middle))
        output=work/p.name
        subprocess.run([sys.executable,'-E','-B',str(runner),*args,str(conf),str(output)],check=True)
        rebuilt=read(output)
        assert rebuilt['rows']==q['rows'] and rebuilt['source_hashes']==hh and rebuilt['parameters']==cfg,p.name
        print('verified',p.name,flush=True)

if __name__=='__main__':
    a=ArgumentParser()
    a.add_argument('comp',type=Path);a.add_argument('work',type=Path);a.add_argument('--only',nargs='+');a.add_argument('--list',action='store_true')
    q=a.parse_args();replay(q.comp.resolve(),q.work.resolve(),q.only,q.list)

"""Check .011 physical layout, synchronized middle placements, and the certified tail."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from flint import arb, ctx

p=ArgumentParser(description=__doc__)
for key in ('work','astra','output'):p.add_argument(key,type=Path)
a=p.parse_args();ctx.prec=160
work=a.work.resolve(); astra=a.astra.resolve()
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
physical=load(work/'011-physical-area.json'); core=physical['parameters']; chart=physical['chart']; geometry=chart['geometry_sha256']
cost=F(next(r['transfer_cost_upper'] for r in physical['geometry']['cases'] if r['label']=='eleven'))
retreat=F('.00000009488'); assert retreat>cost
summary=[]; missing=[]


def test(path,j,kind):
    d=load(path)
    if not(d['complete'] and d['all_passed']):
        return False
    assert d['physical_parameters']==core and d['geometry_sha256']==geometry
    assert d['parameters']['physical']=='sigma154-turn011-physical.json'
    assert F(d['EH_tightening']['retreat'])==retreat
    expected=chart['reference_ranges'][str(j)]
    assert d['reachable'][str(j)]==expected
    field='angle_class' if kind=='compatibility value' else 'initial_derivative_sign'
    selected=[r for r in d['rows'] if r['bin']==j]
    groups={}
    for r in selected:
        o,s=r['orientation'],r[field]
        k,other=r['counts']; assert o in (0,1) and s in (-1,1) and k+other==5 and 0<=k<=5
        cell=r['row']['subcells']
        groups.setdefault((o,s,k),[]).append(cell)
        assert all(arb(r['row'][key])>0 for key in ('root_margin_lower','placement_margin_lower'))
    common={}
    for o in (0,1):
        for s in (-1,1):
            first=groups[(o,s,0)]
            assert all(groups[(o,s,k)]==first for k in range(6))
            assert [i for l,r in first for i in range(l,r)]==[i for l,r in expected for i in range(l,r)]
            common[str((o,s))]=first
    minimum={key:str(min(arb(r['row'][key]).lower() for r in selected)) for key in ('root_margin_lower','placement_margin_lower')}
    summary.append(dict(bin=j,type=kind,file=path.name,sha256=digest(path),minimum=minimum,common_partitions=common,
                        checked_class_blocks=len(selected)))
    return True

for j in range(12,32):
    if j<16:
        choices=[work/f'011-j{j}-angle-sync.json'];kind='compatibility value'
    elif j==23:
        choices=[astra/'j23-011-deriv-certificate.json'];kind='initial derivative'
    elif j==31:
        choices=[work/'011-j31-slope.json'];kind='initial derivative'
    else:
        choices=[work/'returned'/f'011-j{j}-initial-slope-sync-receipt.json'];kind='initial derivative'
        choices+=sorted(work.glob(f'011-j{j}-slope-retry*-receipt.json'))
    if not any(path.exists() and test(path,j,kind) for path in choices):
        missing.append(j)

tail=load(work/'011-j32-69-composed.json')
assert tail['complete'] and tail['all_passed'] and tail['physical']==core and tail['geometry_sha256']==geometry
assert [r['bin'] for r in tail['bins']]==list(range(32,70))
checked=[r['bin'] for r in summary]+list(range(32,70))
assert sorted(checked+missing)==list(range(12,70))
minimum={z:str(min([arb(t['minimum'][z]).lower() for t in summary]+[arb(tail['minima'][z]).lower()]))
         for z in ('root_margin_lower','placement_margin_lower')}
obj=dict(complete=not missing,missing=missing,verified_bins=checked,parameters=core,geometry_sha256=geometry,
         source_sha256=digest(Path(__file__)),physical_sha256=digest(work/'011-physical-area.json'),
         tail_sha256=digest(work/'011-j32-69-composed.json'),minima=minimum,bins=summary,
         ordinary_reference_subcells=sum(sum(r-l for l,r in chart['reference_ranges'][str(j)]) for j in checked))
a.output.write_text(json.dumps(obj,indent=2)+'\n');print(len(checked),missing,minimum)

"""Audit complete .011 reference cells 38 through 41 and their class partitions."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

from flint import arb, ctx

p=ArgumentParser(description=__doc__)
p.add_argument('physical',type=Path);p.add_argument('workspace',type=Path);p.add_argument('output',type=Path)
a=p.parse_args(); ctx.prec=160
work=a.workspace.resolve()
load=lambda q:json.loads(q.read_bytes())
digest=lambda q:sha256(q.read_bytes()).hexdigest()
geom=load(a.physical)
scales_path=work/'011-j38-41-partition-scales.json'
scales=load(scales_path)
assert scales['complete'] and scales['all_v_equals_e'] and scales['all_1_cell_F_upper_below_5_cell_F_upper']
assert scales['physical']==geom['parameters']
geometry=geom['chart']['geometry_sha256']
assert geometry==scales['geometry_sha256']


def blocks(size):
    return [[i,min(i+size,75)] for i in range(0,75,size)]


def check_layout(doc,j,classes):
    assert doc['complete'] and doc['all_passed'] and doc['reachable']=={str(j):[[0,75]]}
    assert doc['physical_parameters']==geom['parameters'] and doc['geometry_sha256']==geometry
    assert Fraction(doc['EH_tightening']['retreat'])==Fraction('.00000009488')
    actual={}
    for item in doc['rows']:
        i,kind,lev,interval,row=(item[f] for f in ('bin','orientation','counts','e_class','row'))
        assert i==row['reference_bin']==j and item['positive']
        assert all(arb(row[z])>0 for z in ('root_margin_lower','placement_margin_lower'))
        assert list(map(Fraction,row['bracket'])) in ([Fraction('.5'),Fraction('6.2')],[Fraction('.5'),Fraction('6.25')])
        actual.setdefault((kind,tuple(lev),tuple(interval)),[]).append(row['subcells'])
    assert actual==classes
    return doc['rows']

summary=[]
for j in range(38,42):
    scale=next(r for r in scales['results'] if r['bin']==j)
    assert arb(scale['min_S_minus_F'])>arb(0)
    easy=work/(f'011-j{j}-11classes.json' if j==39 else f'returned/011-j{j}-11classes.json')
    fin=work/(f'011-j{j}-remaining-mixed.json' if j!=40 else '011-j40-remaining.json')
    coarse=load(easy); fine=load(fin)
    assert coarse['source_hashes']['certify_ordered_direct.py']==digest(work/'certify_ordered_direct_v1.py')
    fine_source='certify_ordered_direct.py' if j==40 else 'certify_ordered_direct_mixed.py'
    assert fine['source_hashes'][fine_source]==digest(work/fine_source)
    assert coarse['source_hashes']['ordered_state.py']==fine['source_hashes']['ordered_state.py']==digest(work/'ordered_state.py')
    common={(ori,(k,5-k),('0','1')):blocks(15) for ori in (0,1) for k in range(6) if (ori,k)!=(0,5)}
    residual={(0,(5,0),('0','1/2')):blocks(5)}
    residual.update({(0,(k,5-k,0,0),('1/2','1')):blocks(5) for k in range(5)})
    if j==40:
        residual.update({(0,(k,5-k,0,0,0,0,0,0),('1/2','1')):blocks(5) for k in range(6)})
    else:
        residual[(0,(5,0,0,0),('1/2','1'))]=blocks(1)
    rows=check_layout(coarse,j,common)+check_layout(fine,j,residual)
    minimum={z:str(min(arb(t['row'][z]).lower() for t in rows)) for z in ('root_margin_lower','placement_margin_lower')}
    summary.append(dict(bin=j,classes=len(common)+len(residual),physical_class_blocks=len(rows),minimum=minimum,
                        input_sha256={str(q.relative_to(work)):digest(q) for q in (easy,fin)}))
    print(j,len(rows),minimum)
result=dict(complete=True,all_passed=True,physical=geom['parameters'],subbins=[38,39,40,41],
            ordinary_reference_subcells=300,geometry_sha256=geometry,EH_retreat='593/6250000000',
            scales_sha256=digest(scales_path),source_sha256=digest(Path(__file__)),bins=summary)
a.output.write_text(json.dumps(result,indent=2)+'\n')

"""Compose all .011 placements for reference cells 32 through 69."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from flint import arb,ctx

p=ArgumentParser(description=__doc__)
p.add_argument('workspace',type=Path);p.add_argument('output',type=Path)
a=p.parse_args();ctx.prec=160
work=a.workspace.resolve();returned=work/'returned'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
physical=load(work/'011-physical-area.json')
geom=physical['chart']['geometry_sha256']
cost=F(next(t['transfer_cost_upper'] for t in physical['geometry']['cases'] if t['label']=='eleven'))
retreat=F('.00000009488')
assert retreat>cost

def ar(x):
    return arb(x.numerator)/x.denominator

def blocks(size):return [[i,min(75,i+size)] for i in range(0,75,size)]

def check_ordered(p,j,classes):
    c=load(p)
    assert c['complete'] and c['all_passed'] and c['physical_parameters']==physical['parameters']
    assert c['geometry_sha256']==geom and c['reachable']=={str(j):[[0,75]]}
    assert F(c['EH_tightening']['retreat'])==retreat
    for fn in ('ordered_state.py','certify_ordered_direct.py','certify_ordered_direct_mixed.py'):
        if fn in c['source_hashes']:
            assert c['source_hashes'][fn]==digest(work/fn)
    actual={}
    for item in c['rows']:
        row=item['row']
        assert item['positive'] and item['bin']==row['reference_bin']==j
        assert all(arb(row[t])>0 for t in ('root_margin_lower','placement_margin_lower'))
        key=(item['orientation'],tuple(item['counts']),tuple(item['e_class']))
        actual.setdefault(key,[]).append(row['subcells'])
    assert actual==classes
    return [t['row'] for t in c['rows']]

special_path=work/'011-j38-41-composed.json'
special=load(special_path)
assert special['complete'] and special['all_passed'] and special['physical']==physical['parameters']
assert special['geometry_sha256']==geom and special['subbins']==[38,39,40,41]
scale_path=work/'011-j32-46-partition-monotone.json'
scale=load(scale_path)
assert scale['complete'] and scale['geometry_sha256']==geom and scale['monotone_F_S_across_nested_blocks']
assert sorted(r['bin'] for r in scale['results'])==[*range(32,38),*range(42,47)]
summary=[]
for j in range(32,48):
    if j in (38,39,40,41):
        old=next(t for t in special['bins'] if t['bin']==j)
        for pth,checksum in old['input_sha256'].items():assert digest(work/pth)==checksum
        summary.append(dict(bin=j,method='audited nested partition',checked_class_blocks=old['physical_class_blocks'],minimum=old['minimum'],files={special_path.name:digest(special_path)}))
        continue
    first=returned/f'011-j{j}-direct-frozen-receipt.json'
    easy={(ori,(k,5-k),('0','1')):blocks(15) for ori in (0,1) for k in range(6) if j==47 or (ori,k)!=(0,5)}
    rows=check_ordered(first,j,easy);sources=[first]
    if j!=47:
        second=returned/f'011-j{j}-remaining-mixed-receipt.json'
        rem={(0,(5,0),('0','1/2')):blocks(5),(0,(5,0,0,0),('1/2','1')):blocks(1)}
        rem.update({(0,(k,5-k,0,0),('1/2','1')):blocks(5) for k in range(5)})
        rows+=check_ordered(second,j,rem);sources.extend((second,scale_path))
    minimum={z:str(min(arb(t[z]).lower() for t in rows)) for z in ('root_margin_lower','placement_margin_lower')}
    summary.append(dict(bin=j,method='ordered contact classes',checked_class_blocks=len(rows),minimum=minimum,
                       files={str(p.relative_to(work)):digest(p) for p in sources}))

for pth in sorted(returned.glob('011-j[0-9][0-9]-[0-9][0-9]-receipt.json')):
    d=load(pth)
    assert d['parameters']['line']==physical['parameters']['line']
    assert d['parameters']['physical_parameters']==physical['parameters']['physical_parameters']
    for row in d['rows']:
        j=row['bin']
        if j<48:continue
        assert row['positive'] and row['reachable']==physical['chart']['reference_ranges'][str(j)]
        c,=row['classes']
        assert c['subcells']==row['reachable'][0]
        lower_root=arb(c['root_margin_lower']).lower()
        lower_pose=(arb(c['placement_margin_lower'])-ar(cost)).lower()
        assert min(lower_root,lower_pose)>0
        summary.append(dict(bin=j,method='ordinary root',checked_class_blocks=1,
            minimum=dict(root_margin_lower=str(lower_root),placement_margin_lower=str(lower_pose)),
            files={str(pth.relative_to(work)):digest(pth)}))
assert [t['bin'] for t in summary]==list(range(32,70))
minimum={z:str(min(arb(t['minimum'][z]).lower() for t in summary)) for z in ('root_margin_lower','placement_margin_lower')}
result=dict(complete=True,all_passed=True,physical=physical['parameters'],geometry_sha256=geom,
            reachable_full_tail=sum(sum(r-l for l,r in physical['chart']['reference_ranges'][str(j)]) for j in range(32,70)),
            EH_transfer_cost_upper=str(cost),EH_retreat=str(retreat),minima=minimum,bins=summary,source_sha256=digest(Path(__file__)))
a.output.write_text(json.dumps(result,indent=2)+'\n'); print(result['reachable_full_tail'],minimum)

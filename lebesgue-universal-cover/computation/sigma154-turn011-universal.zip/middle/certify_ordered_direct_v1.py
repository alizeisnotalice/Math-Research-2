"""Verify a direct root and a common rigid placement in each ordered contact class."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import inspect
import json
from pathlib import Path
import sys


def decode(x):
    return json.loads(x.read_bytes())


def run(comp, ordered_path, config, out):
    sys.path[:0]=[str(ordered_path),str(comp)]
    from flint import arb, __version__ as flint_version
    from ordered_state import support_bound
    from certify_sigma_extended_graph import geometry
    from certify_ah_local_physical_support import validate
    from certify_sigma_reachable_roots import reach

    cfg=decode(config)
    geom_path=comp/cfg['physical']
    physical=decode(geom_path)
    pivot,turn=map(F,physical['line'])
    far,negative,eps=map(F,physical['physical_parameters'])
    ns,src,_=geometry(comp,[(pivot,turn)],sigma=physical['sigma_degrees'],far=far,negative=negative,eps=eps)
    ns['_sharpen_jets']=True
    selected,=[i for i,(label,_,_) in enumerate(ns['rows']) if label.startswith('U1-Te')]
    label, normal, offset=ns['rows'][selected]
    retreat=F(cfg['retreat'])
    assert retreat>=0 and F(ns['eh_depth'])==F('.000555')
    ns['rows'][selected]=label,normal,offset-ns['A'](retreat)

    def block_support(state,j,a,b):
        # The ordinary validator runs one iteration and reports its initial fine index.
        # The callback widens its entire physical input to the selected fine-index block.
        lo,hi=state['knots'][j:j+2]
        step=(hi-lo)/75
        assert b==a+step and a==lo+state['_block'][0]*step
        return support_bound(state,j,a,lo+state['_block'][1]*step)

    env={**validate.__globals__,'support_bound':block_support}
    exec(compile(inspect.getsource(validate),'ordered_direct','exec'),env)
    direct=env['validate']
    ranges={j:reach(ns,j) for j in cfg['bins']}
    rows=[]
    root_min=pose_min=arb(1)

    def visit(j,a,b,entry):
        nonlocal root_min,pose_min
        ns['_block']=(a,b)
        ns['_first_orientation']=entry['orientation']
        ns['_class_counts']=tuple(entry['counts'])
        ns['_e_class']=tuple(map(F,entry.get('e_class',('0','1'))))
        assert sum(ns['_class_counts'])==5 and 0<=ns['_e_class'][0]<=ns['_e_class'][1]<=1
        for l,r,k,s,sign in entry['brackets']:
            row=direct(ns,j,F(l),F(r),k,s,sign,begin=a,end=a+1,angular=12,depth=cfg['depth'])
            rm,pm=(arb(row[k]) for k in ('root_margin_lower','placement_margin_lower'))
            valid=rm>0 and pm>0
            if valid:
                break
        if not valid and b-a>1:
            mid=(a+b)//2
            visit(j,a,mid,entry)
            visit(j,mid,b,entry)
            return
        row['subcells']=[a,b]
        rows.append({'bin':j,'orientation':entry['orientation'],'counts':entry['counts'],
                     'e_class':list(map(str,ns['_e_class'])),'row':row,'positive':valid})
        root_min=min(root_min,rm.lower());pose_min=min(pose_min,pm.lower())

    for j in cfg['bins']:
        for entry in cfg['classes']:
            start_index=len(rows)
            for a,b in ranges[j]:
                for begin in range(a,b,cfg['block']):
                    visit(j,begin,min(b,begin+cfg['block']),entry)
            used=rows[start_index:]
            assert [i for item in used for a,b in [item['row']['subcells']] for i in range(a,b)]==[i for a,b in ranges[j] for i in range(a,b)]
            print(j,entry['orientation'],entry['counts'],len(used),sum(not r['positive'] for r in used),flush=True)
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    sources=(Path(__file__),ordered_path/'ordered_state.py',geom_path,config,
             comp/'certify_ah_local_physical_support.py',comp/'certify_ah_attainable_root.py',
             comp/'certify_ah_pinned_normals.py',comp/'certify_ah_root_pose_choices.py',
             comp/'certify_sigma_pinned_fan.py',comp/'certify_sigma_extended_graph.py')
    obj={'complete':True,'all_passed':all(r['positive'] for r in rows),'parameters':cfg,
         'physical_parameters':physical,'reachable':ranges,'EH_tightening':{'label':label,'retreat':str(retreat)},
         'root_margin_lower':str(root_min),'placement_margin_lower':str(pose_min),
         'source_hashes':{p.name:digest(p) for p in sources},'geometry_sha256':sha256(src.encode()).hexdigest(),
         'flint':flint_version,'python':sys.version,'rows':rows}
    out.write_text(json.dumps(obj,indent=2)+'\n')


if __name__=='__main__':
    assert __debug__
    p=ArgumentParser(description=__doc__)
    for name in ('comp','ordered','config','out'):
        p.add_argument(name,type=Path)
    args=p.parse_args()
    run(args.comp.resolve(),args.ordered.resolve(),args.config.resolve(),args.out.resolve())

"""Rebuild both physical geometry and the full 70-bin same-depth .011 cover."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from flint import arb,ctx

KIT=Path(__file__).resolve().parent
def load(path):return json.loads(path.read_bytes())
def digest(path):return sha256(path.read_bytes()).hexdigest()

def run(comp,work):
    early=KIT/'early';middle=KIT/'middle'
    work.mkdir(parents=True,exist_ok=True)
    assert __debug__ and comp.is_dir()
    sys.path[:0]=[str(early),str(comp)]
    import certify_sigma154_deeper_composition as base
    from audit_ordered_receipt import audit
    registry=load(KIT/'evidence-hashes.json')
    for f,h in registry.items():assert digest(KIT/f)==h,f
    cfg=load(middle/'sigma154-turn011-physical.json')
    assert cfg==load(comp/'sigma154-turn011-physical.json') and list(map(F,cfg['line']))==[F('.429'),F('.011')]
    assert list(map(F,cfg['physical_parameters']))==[F('.313'),F('.353'),F('.0127')] and F(cfg['sigma_degrees'])==F('1.54')
    ctx.prec=160
    chart,row=base.physical_chart(comp,cfg)
    ctx.prec=160
    geom=base.area_geometry(comp,comp,cfg,row)
    physical=load(middle/'011-physical-area.json')
    assert physical['parameters']==cfg
    assert json.loads(json.dumps(chart))==physical['chart'] and geom==physical['geometry']
    ranges={str(j):rr for j,rr in chart['reference_ranges'].items()}
    assert sorted(map(int,ranges))==list(range(70))
    cost=next(F(r['transfer_cost_upper']) for r in geom['cases'] if r['label']=='eleven')
    assert F('.00000009488')>cost
    def recheck(script,args,expected):
        out=work/expected.name
        subprocess.run([sys.executable,'-I','-B',str(middle/script),*[str(p) if p is not None else str(out) for p in args]],check=True,stdout=sys.stderr)
        assert out.read_bytes()==expected.read_bytes(),expected.name
    exact_budget=work/'nested-budget-proof.json'
    subprocess.run([sys.executable,'-I','-B',str(KIT/'check_nested.py'),str(comp),str(exact_budget)],check=True)
    assert exact_budget.read_bytes()==(KIT/'nested-budget-proof.json').read_bytes()
    special=middle/'011-j38-41-partition-scales.json'
    recheck('check_partition_scales.py',[comp,None,38,39,40,41],special)
    general=middle/'011-j32-46-partition-monotone.json'
    recheck('check_partition_monotone.py',[comp,None,*range(32,38),*range(42,47)],general)
    recheck('audit_mid_receipts.py',[middle/'011-physical-area.json',middle,None],middle/'011-j38-41-composed.json')
    recheck('audit_tail.py',[middle,None],middle/'011-j32-69-composed.json')
    recheck('audit_full_mid.py',[middle,early,None],middle/'011-j12-69-composed.json')
    branches={}
    for tag in ('j0-011','j1-3-011-sync','j4-7-011-sync','j8-11-011-sync'):
        conf=early/(tag+'-params.json');receipt=early/(tag+'-certificate.json')
        for j,r in audit(comp,conf,receipt,chart['geometry_sha256'],ranges).items():
            assert j not in branches and F(r['retreat'])>cost
            branches[j]={'root':r['root'],'pose':r['pose'],'bin_certificate':digest(receipt)}
    assert sorted(branches)==list(range(12))
    mid=load(middle/'011-j12-69-composed.json')
    tail=load(middle/'011-j32-69-composed.json')
    for item in mid['bins']:
        j=item['bin']
        candidates=[p for p in (early/item['file'],middle/item['file'],middle/'returned'/item['file']) if p.is_file()]
        assert len(candidates)==1;path=candidates[0];rec=load(path);recipe=rec['parameters']
        for name,h in rec['source_hashes'].items():
            sources=[p for p in (early/name,middle/name,comp/name) if p.is_file()]
            assert any(digest(p)==h for p in sources),name
        assert rec['physical_parameters']==cfg and rec['geometry_sha256']==chart['geometry_sha256']
        assert rec['EH_tightening']['label'].startswith('U1-Te') and F(rec['EH_tightening']['retreat'])>cost
        for x in rec['rows']:
            r=x['row'];assert r['reference_bin']==x['bin']==j
            L,R=map(F,r['bracket'])
            sign=x.get('angle_class',x.get('initial_derivative_sign'));assert r['anchor_comparison_sign']==sign
            bb=recipe.get('brackets')
            opts=[bb[int(sign==1)]] if bb else recipe['low_brackets' if sign==-1 else 'high_brackets']
            assert L<R and any([L,R]==list(map(F,b[:2])) for b in opts)
            if 'cut' in recipe:
                assert F(r['anchor_degrees'])==0 and F(r['anchor_threshold'])==-F(recipe['cut'])
            else:
                assert F(r['anchor_threshold'])==-F(recipe['threshold'])<0 and F(r['anchor_degrees'])==F(recipe['anchor'])
                assert sign==1 or R==F(recipe['anchor'])
        assert j not in branches
        branches[j]=dict(root=item['minimum']['root_margin_lower'],pose=item['minimum']['placement_margin_lower'],bin_certificate=item['sha256'])
    for item in tail['bins']:
        j=item['bin'];assert j not in branches
        branches[j]=dict(root=item['minimum']['root_margin_lower'],pose=item['minimum']['placement_margin_lower'],bin_certificate=item['files'])
    assert sorted(branches)==list(range(70))
    root,j_root=min((arb(r['root']).lower(),j) for j,r in branches.items())
    pose,j_pose=min((arb(r['pose']).lower(),j) for j,r in branches.items())
    assert min(root,pose)>0 and sum(b-a for rr in ranges.values() for a,b in rr)==5182
    for c in geom['cases']:c['universal_cover']=True
    return dict(physical=cfg,geometry=geom,chart=chart,bins=branches,minimum_root=str(root),limiting_root_bin=j_root,
                minimum_retained_pose=str(pose),limiting_pose_bin=j_pose,inputs_sha256=digest(KIT/'evidence-hashes.json'),
                verifier_sha256=digest(Path(__file__)),base_sha256=digest(comp/'certify_sigma154_deeper_composition.py'))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for a in ('comp','work','output'):p.add_argument(a,type=Path)
    a=p.parse_args();out=run(a.comp.resolve(),a.work.resolve())
    a.output.write_text(json.dumps(out,indent=1,sort_keys=True)+'\n')

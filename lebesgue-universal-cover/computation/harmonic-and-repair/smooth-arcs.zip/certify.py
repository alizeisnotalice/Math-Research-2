"""Certify one frozen outer model against all three archived integer hosts."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json
from flint import arb,ctx
ctx.prec=192
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('model',choices=['r203','r270']);p.add_argument('--out',type=Path);a=p.parse_args()
if a.model=='r203':
 model=R/'outer203.json';angle=F(1573,1000000000);t=F(583,1250);poses=[('1189','0.0000002341476','0.0000000234454'),('2172','0.0000002341476','0.0000000234454'),('2230','0.0000002341476','0.0000000234454')];expected=20
else:
 model=R/'outer01350.json';angle=F(17,25000000);t=F(317,12500);poses=[('2172','0.0000005292793','0.0000001881380'),('2230','0.0000005292837','0.0000001881336')];expected=21
D=json.loads(model.read_bytes());rows=[(list(map(F,r['normal'])),F(r['offset'])) for r in D['rows']];vv=set()
for i,(u,alpha) in enumerate(rows):
 for w,beta in rows[i+1:]:
  det=u[0]*w[1]-u[1]*w[0]
  if det:
   z=((alpha*w[1]-u[1]*beta)/det,(u[0]*beta-alpha*w[0])/det)
   if all(x[0]*z[0]+x[1]*z[1]<=y for x,y in rows):vv.add(z)
assert len(vv)==expected
ar=lambda x:arb(F(x).numerator)/F(x).denominator
s,c=ar(angle).sin_cos();points=[(c*ar(x)-s*ar(y),s*ar(x)+c*ar(y)) for x,y in vv]
sha={'1189':'a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f','2172':'6d8b0f7ee55491823f96f58f380c09211e75062e2add8161fa30b1cc5d418a02','2230':'1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4'};results=[]
for name,tx,ty in poses:
 path=R/'hosts'/f'{name}.json';raw=path.read_bytes();assert sha256(raw).hexdigest()==sha[name];data=json.loads(raw);P=data['vertices'];N=len(P);den=data['denominator'];assert N==int(name)
 edges=[(P[(i+1)%N][0]-P[i][0],P[(i+1)%N][1]-P[i][1]) for i in range(N)]
 assert all(dx*edges[(i+1)%N][1]-dy*edges[(i+1)%N][0]>=0 for i,(dx,dy) in enumerate(edges))
 assert all(dy*(v[0]-P[i][0])-dx*(v[1]-P[i][1])<=0 for i,(dx,dy) in enumerate(edges) for v in P)
 minimum=None;worst=None
 for i,(dx,dy) in enumerate(edges):
  nx,ny=ar(F(dy,den)),ar(F(-dx,den));offset=nx*ar(F(P[i][0],den))+ny*ar(F(P[i][1],den));disc=(nx*nx+ny*ny).sqrt()/2
  h=max((nx*x+ny*y).upper() for x,y in points)
  margin=(offset-(1-ar(t))*disc-ar(t)*h-nx*ar(F(tx))-ny*ar(F(ty))).lower();assert margin>0,(name,i,margin)
  unit=(margin/(nx*nx+ny*ny).sqrt()).lower()
  if minimum is None or unit<minimum:minimum=unit;worst=i
 results.append(dict(host=name,sha256=sha[name],facets=N,translation=[tx,ty],min_unit_normal_clearance=str(minimum),critical_face=worst));print(name,'PASS',N,str(minimum),flush=True)
out=dict(model=a.model,scale=str(t),angle_radians=str(angle),outer_vertices=len(vv),outer_sha256=sha256(model.read_bytes()).hexdigest(),results=results)
target=a.out or R/f'containment-{a.model}.json';target.write_text(json.dumps(out,indent=2)+'\n')

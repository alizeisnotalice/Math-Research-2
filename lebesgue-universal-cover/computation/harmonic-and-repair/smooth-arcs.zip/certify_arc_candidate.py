from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
from flint import arb,ctx
ctx.prec=192
R=Path(__file__).resolve().parent;d=json.loads((R/'outer203-arcs.json').read_bytes());rows=[(list(map(F,r['normal'])),F(r['offset'])) for r in d['rows']]
poly=[(F(-1),F(-1)),(F(1),F(-1)),(F(1),F(1)),(F(-1),F(1))]
for normal,b in rows:
 new=[]
 for a,z in zip(poly,poly[1:]+poly[:1]):
  x=normal[0]*a[0]+normal[1]*a[1]-b;y=normal[0]*z[0]+normal[1]*z[1]-b
  if x<=0:new.append(a)
  if (x<0<y) or (y<0<x):
   k=x/(x-y);new.append((a[0]+(z[0]-a[0])*k,a[1]+(z[1]-a[1])*k))
 poly=list(dict.fromkeys(new));assert poly
assert all(n[0]*x+n[1]*y<=b for x,y in poly for n,b in rows)
print('exact vertices',len(poly),flush=True)
ar=lambda x:arb(F(x).numerator)/F(x).denominator
angle=F(-254,10**9);t=F(119,200);s,c=ar(angle).sin_cos();points=[(c*ar(x)-s*ar(y),s*ar(x)+c*ar(y)) for x,y in poly]
H=R/'hosts';res=[]
for name,tx,ty in [('1189','0.0000003560885','0.0000002056862'),('2172','0.0000003563705','0.0000002054117'),('2230','0.0000003563724','0.0000002054099')]:
 raw=(H/f'{name}.json').read_bytes();D=json.loads(raw);P=D['vertices'];N=len(P);den=D['denominator'];assert N==int(name);es=[(P[(i+1)%N][0]-P[i][0],P[(i+1)%N][1]-P[i][1]) for i in range(N)];assert all(dy*(v[0]-P[i][0])-dx*(v[1]-P[i][1])<=0 for i,(dx,dy) in enumerate(es) for v in P)
 least=None;index=None
 for i,(dx,dy) in enumerate(es):
  nx,ny=ar(F(dy,den)),ar(F(-dx,den));b=nx*ar(F(P[i][0],den))+ny*ar(F(P[i][1],den));h=max((nx*x+ny*y).upper() for x,y in points);q=(nx*nx+ny*ny).sqrt();margin=((b-(1-ar(t))*q/2-ar(t)*h-nx*ar(F(tx))-ny*ar(F(ty)))/q).lower();assert margin>0,(name,i,str(margin))
  if least is None or margin<least:least=margin;index=i
 res.append(dict(host=name,sha256=sha256(raw).hexdigest(),faces=N,minimum_unit_clearance=str(least),critical_face=index,translation=[tx,ty]));print(name,'PASS',least,flush=True)
out={'status':'verified given convex pre-cut boundary and R203 inclusion','angle_radians':str(angle),'t':str(t),'vertices':len(poly),'row_count':len(rows),'source_sha256':sha256((R/'outer203-arcs.json').read_bytes()).hexdigest(),'results':res};(R/'containment-arcs.json').write_text(json.dumps(out,indent=2)+'\n')

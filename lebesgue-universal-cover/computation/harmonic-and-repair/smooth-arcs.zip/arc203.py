"""Candidate exact circle tangents on the original R203 boundary arcs."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
from flint import arb,ctx
ctx.prec=192
R=Path(__file__).resolve().parent;comp=Path(sys.argv[1]).resolve();sys.path.insert(0,str(comp))
import audit_optimized_eh_chord as g
import certify_three_sigma_area_budget as area
V=area.setup('1.5497',g);Q,E3,C,Ta,H,U,C3,T,Ip,B3,G,K,F3=[V[x] for x in ['Q','E3','c','Ta','H','U','C3','T','Ip','B3','G','K','F3']]
Y=(arb(0),C[1]+(1-C[0]*C[0]).sqrt())
sub,add,mul,dot=g.minus,g.plus,g.scale,g.dot
# The listed arcs are boundary components, oriented as in the Green formula.
arcs=[('Q-Y',Q,Y,E3),('Y-Ta',Y,Ta,C),('H-U',H,U,C3),('T-I',T,Ip,B3),('G-K',G,K,F3)]
source=json.loads((R/'outer203.json').read_bytes());rows=source['rows'][:]
def upper(x):
 m,e=map(int,x.upper().man_exp());return F(m)*F(2)**e
S=10**15
for name,A,B,C in arcs:
 a,b=sub(A,C),sub(B,C);assert (dot(a,a)-1).contains(0) and (dot(b,b)-1).contains(0)
 assert dot(a,b)>0 and g.cross(a,b)>0
 for j in range(1,51):
  u=F(j,51);r=add(mul(area.exact(1-u),a),mul(area.exact(u),b));n=mul(1/g.norm(r),r);offset=1+dot(n,C)
  q=[F(round(float(c.mid())*S),S) for c in n];err=sum(upper(abs(area.exact(v)-n0)) for v,n0 in zip(q,n));bq=F((S*(upper(offset)+err)).__ceil__(),S)
  assert area.exact(bq)>=offset+sum(abs(area.exact(v)-n0) for v,n0 in zip(q,n))
  rows.append({'label':f'ARC-{name}-{j}', 'normal':[str(x) for x in q],'offset':str(bq)})
source['rows']=rows;source['support_lemma']='True short arcs of convex 1.5497-degree pre-cut body; R203 host is its halfplane intersection.'
(R/'outer203-arcs.json').write_text(json.dumps(source,indent=2)+'\n');print('candidate rows',len(rows))

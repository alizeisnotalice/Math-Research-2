from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
import sys,json
ctx.prec=192
comp=Path(sys.argv[1]).resolve();sys.path.insert(0,str(comp))
import audit_optimized_eh_chord as g
import certify_three_sigma_area_budget as area
source=comp/'certify_gibbs_area_refined.py';raw=source.read_text();parts=raw.split('width = F(1,cells)');assert len(parts)==2
sys.argv=[str(source),'1.5497','2','1'];d={'__file__':str(source),'__name__':'arc_identity'};exec(compile(parts[0],str(source),'exec'),d)
V=area.setup('1.5497',g);Y=(arb(0),V['c'][1]+(1-V['c'][0]**2).sqrt())
checks=[('q','Q'),('e3','E3'),('c','c'),('t','Ta'),('h','H'),('u','U'),('c3','C3'),('t_eh','T'),('ip','Ip'),('b3','B3'),('g','G'),('k','K'),('f3','F3')]
for old,new in checks:
 for a,b in zip(d[old],V[new]):
  lo=area.exact(a.lo);hi=area.exact(a.hi);assert b.overlaps((lo+hi)/2+(hi-lo)/2*arb('0 +/- 1')),(old,new,a,b)
for a,b in zip(d['y'],Y):
 lo=area.exact(a.lo);hi=area.exact(a.hi);assert b.overlaps((lo+hi)/2+(hi-lo)/2*arb('0 +/- 1'))
print('PASS independent original boundary coordinates',len(checks)+1)

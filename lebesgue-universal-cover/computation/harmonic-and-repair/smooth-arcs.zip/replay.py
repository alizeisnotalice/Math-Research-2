from pathlib import Path
from hashlib import sha256
import argparse,subprocess,sys
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('computation',type=Path);args=p.parse_args();comp=args.computation.resolve()
assert __debug__
def check(path,want):assert sha256(path.read_bytes()).hexdigest()==want,path
for name,digest in {
'audit_optimized_eh_chord.py':'dd371b0545a1e1ceef3edefba692623b592a904d4c16d372b715f9ffa6ca9c64',
'certify_three_sigma_area_budget.py':'8b4713c11cb4ad5e22c5f8c85bbb5ee07191ef3cce7b1d120449ca737410562c',
'certify_eh_dual_hinge.py':'b12010f2a2ec5a05763b999a8e771c74fbd33803f253f21dd2a7cb914b91e11d',
'eh-two-line-cover-certificate.json':'10f2f3aff4eb8c60e869053bacf8f569d2db55dec305fc7c0b405cdecf3bddf2',
'eh-upper-chain-parameters.json':'053bdfc3781ec963155ad90807232b8f9d56bb3dd75cbe2f6b683ee41135a6d7',
'fan-0070-final-eleven-eh.json':'f7c768665f02cc985d1e6226ca392a9238c949522cf623d9f9ade57aa5f789e5'}.items():check(comp/name,digest)
for script,arg in [('outer203.py',comp),('outer.py',comp),('certify.py','r203'),('certify.py','r270')]:
 subprocess.run([sys.executable,'-I','-B',str(R/script),str(arg)],check=True)
for name,digest in {'outer203.json':'36662c70f2c59550a4ce1e1033783ffc04239a46314aab5de8e022b59357a0b5','outer01350.json':'c26ea77d53b1875c8600529b8830130de73b5607a6790b4b2340a19290c5cc4d','containment-r203.json':'f9656f2d87ab2793f68bdf73fd25e30491626302b6cf7bd4a515f3ebfc43fe8d','containment-r270.json':'21db6fdc9b735c09c28d2e94894c7f39f949c80a69924f75cd4d131e4a5d1bc8'}.items():check(R/name,digest)
print('ALL_CERTIFICATES_PASS')

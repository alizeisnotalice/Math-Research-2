from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
R=Path(__file__).resolve().parent;comp=Path(sys.argv[1]).resolve()
for file,h in [('certify_splice_connectors.py','42bb1f81a10a3472b2a6d7e553905a06c4b4b93f6d7c805488b61e3b4504be49'),('certify_gibbs_area_refined.py','b3e0c0200e60927ee5a76d157149586fa6195eb2dee550eeddf7902239caa38b')]:assert sha256((comp/file).read_bytes()).hexdigest()==h
subprocess.run([sys.executable,'-I','-B',str(R/'replay.py'),str(comp)],check=True)
env=dict(os.environ,LEBESGUE_SIGMA_DEGREES='1.5497,1.5497')
res=subprocess.run([sys.executable,'-B',str(comp/'certify_splice_connectors.py')],env=env,check=True,stdout=subprocess.PIPE)
d=json.loads(res.stdout);assert d['passed'] and d['sigma_degrees_interval']==['15497/10000']*2
(R/'splice-15497.json').write_bytes(res.stdout)
subprocess.run([sys.executable,'-I','-B',str(R/'verify_arc_identity.py'),str(comp)],check=True)
subprocess.run([sys.executable,'-I','-B',str(R/'arc203.py'),str(comp)],check=True)
subprocess.run([sys.executable,'-I','-B',str(R/'certify_arc_candidate.py')],check=True)
for f,h in [('outer203-arcs.json','b72eec1db219735b61b46d32dfbdf19ecd0380394f786cb36ae67683b7ccbe12'),('containment-arcs.json','9515d24ec68ae0ddb563917e1b9dbc18a3b7d11f460eeeb5b2facfe359fdbf5a')]:assert sha256((R/f).read_bytes()).hexdigest()==h
print('ALL_ARC_CERTIFICATES_PASS')

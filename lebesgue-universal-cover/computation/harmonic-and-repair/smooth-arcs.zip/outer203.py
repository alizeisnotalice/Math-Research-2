"""Outer rational halfplanes of R270's certified .01350 host, at its original coordinate frame."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import sys,json
from flint import arb,ctx
ctx.prec=192
comp=Path(sys.argv[1]).resolve();sys.path.insert(0,str(comp))
import audit_optimized_eh_chord as g
import certify_three_sigma_area_budget as area
from certify_eh_dual_hinge import RELAX
r203=comp/'fan-0070-final-eleven-eh.json';assert sha256(r203.read_bytes()).hexdigest()=='f7c768665f02cc985d1e6226ca392a9238c949522cf623d9f9ade57aa5f789e5'
geo={'chart':{'geometry_sha256':'d0e571ecf1c6882ce238cce4f0936aa0095c1cd2fe64b3127fc5fd496a757189'}}

V=area.setup('1.5497',g);n,m=V['n'],V['m'];rows=[('H-'+str(i),n[i],g.HALF) for i in range(6)]+[('Gibbs-m'+str(i),m[i],g.HALF) for i in (3,5)]
z,Ta=V['z'],V['Ta'];delta=g.minus(Ta,z);base=g.scale(-1/g.norm(delta),delta)
for j,(p,d) in enumerate([(F('.427'),F('.007'))]):
 c,s=g.unit(area.exact(d));direct=g.plus(g.scale(c,base),g.scale(s,g.rot(base)));normal=g.scale(-1,g.rot(direct));anchor=g.plus(z,g.scale(area.exact(p),delta));rows.append((f'AH-{j}',normal,g.dot(normal,anchor)))
old=json.loads((comp/'eh-two-line-cover-certificate.json').read_bytes())['parameters'];params=json.loads((comp/'eh-upper-chain-parameters.json').read_bytes());assert old==['0.000555','0.0005522','0.0075'] and len(params)==9
C3,U,T=V['C3'],V['U'],V['T'];plus,minus,scale,rot,dot=g.plus,g.minus,g.scale,g.rot,g.dot
def moved(d):
 c,s=g.unit(area.exact(d));r=minus(U,C3);return plus(C3,minus(scale(c,r),scale(s,rot(r))))
def hp(a,b):
 e=minus(b,a);u=scale(-1/g.norm(e),rot(e));return u,dot(u,a)
d0,d1,h=map(F,old);u,u1=moved(d0),moved(d1);hinge=plus(u1,scale(area.exact(h),minus(T,u1)));rr=[hp(u,hinge),hp(hinge,T)];X=g.line_pair(*[z[0] for z in rr],*[z[1]-area.exact(d) for z,d in zip(rr,RELAX)])
eh=[hp(u,X),hp(X,T)]
for depth,pivot in params:
 earlier=moved(F(depth));Y=plus(X,scale(area.exact(F(pivot)),minus(u,X)));eh.append(hp(earlier,Y))
assert len(eh)==11
rows += [(f'EH-{i}',v,b) for i,(v,b) in enumerate(eh)]
# A safe rational row has n_q·x <= b_q. Since H implies |x|,|y|<1,
# round n to 1e-15 and add |n_q-n|_1 to the interval upper bound for b.
def upper(x):
 mant,exp=map(int,x.upper().man_exp());return F(mant)*F(2)**exp
scale0=10**15;out=[]
for label,v,b in rows:
 q=[F(round(float(c.mid())*scale0),scale0) for c in v]
 error=sum(upper(abs(area.exact(qi)-vi)) for qi,vi in zip(q,v))
 qb=F((scale0*(upper(b)+error)).__ceil__(),scale0)
 assert area.exact(qb)>=b+sum(abs(area.exact(qi)-vi) for qi,vi in zip(q,v))
 out.append(dict(label=label,normal=[str(t) for t in q],offset=str(qb)))
assert len(out)==20
res=dict(r203_joint_sha256=sha256(r203.read_bytes()).hexdigest(),sigma_degrees='1.5497',ah_pivot='.427',ah_turn_radians='.007',coordinate_frame='R203 standard; sigma = 1.5497 degrees',outer_bound='All 20 outward halfplanes. Curved Sprague/AH boundary is not replaced by inscribed chords.',containment='U subset Q follows from H, the two Gibbs halfplanes, one AH cut and eleven EH cut halfplanes; rounding uses |x|,|y|<1.',rows=out)
Path(__file__).with_name('outer203.json').write_text(json.dumps(res,indent=2)+'\n');print('PASS',len(rows), 'rows')

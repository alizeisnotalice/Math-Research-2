from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
import sys,json,hashlib,itertools
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from verify_caps import A,source,cross
def check():
 ctx.prec=192
 degrees=list(map(F,json.loads((ROOT/'guards.json').read_bytes())))
 assert len(degrees)==25 and degrees==sorted(set(degrees))
 G=[source(d) for d in degrees];n=len(G)
 def adjacent(i,j):return j==i+1 or (i==0 and j==n-1)
 good={}
 for i,j in itertools.combinations(range(n),2):
  delta=(degrees[j]-degrees[i])/180
  if delta.denominator==1:continue
  u,b=G[i];v,c=G[j];det=cross(u,v);assert not det.contains(0)
  point=((b*v[1]-c*u[1])/det,(u[0]*c-v[0]*b)/det)
  slack=[h-point[0]*a[0]-point[1]*a[1] for k,(a,h) in enumerate(G) if k not in (i,j)]
  if adjacent(i,j):
   assert all(val>0 for val in slack)
   good[i if j==i+1 else j]=point
  else:assert any(val<0 for val in slack)
 assert len(good)==25 and all((degrees[(i+1)%n]-degrees[i])%360<180 for i in range(n))
 V=[good[i] for i in range(n)];area=sum(cross(v,w) for v,w in zip(V,V[1:]+V[:1]))/2
 assert arb('.843858541494916')<area<arb('.843858541494919'),area
 raw=(ROOT/'host.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4'
 src=json.loads(raw);P=src['vertices'];S=src['denominator'];low=None
 for a,b in zip(P,P[1:]+P[:1]):
  nx,ny=b[1]-a[1],a[0]-b[0];L=arb(nx*nx+ny*ny).sqrt()
  cap=A(F(nx*a[0]+ny*a[1]-190000*ny,S))
  dist=min(((cap-nx*x-ny*y)/L).lower() for x,y in V)
  low=dist if low is None else min(dist,low)
 assert low>arb('3.54e-8')
 t=A(F(1,2));fs=[(3*t).sin_cos_pi(),(t-A(F(631,3600))).sin_cos_pi(),(t-A(F(3031,3600))).sin_cos_pi()]
 multiplier=[3,1,1];T=fs[0][0]*fs[1][0]*fs[2][0]
 TT=-10*T+2*sum(multiplier[i]*multiplier[j]*fs[i][1]*fs[j][1]*fs[3-i-j][0] for i,j in ((0,1),(0,2),(1,2)))
 # T+T'' = (1-(9+1+1))*T + the three cross terms.
 at_vertical=(100*T-TT)/250-arb(21)/10000
 dist=arb.pi()/8000-arb(1)/10000
 assert at_vertical>arb('.3295') and dist>arb('.00029269')
 return dict(guards=n,area=str(area),host_min_face_clearance=str(low),
             distance_to_every_degree_11_body_lower=str(dist),vertical_curvature_excess_lower=str(at_vertical))
if __name__=='__main__':
 out=check()
 if (ROOT/'sparse-receipt.json').exists():assert out==json.loads((ROOT/'sparse-receipt.json').read_bytes())
 print(json.dumps(out,indent=2))

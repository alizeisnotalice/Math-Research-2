from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,hashlib
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
def A(x):r=F(x);return arb(r.numerator)/r.denominator
def cross(u,v):return u[0]*v[1]-u[1]*v[0]
@lru_cache(None)
def source(deg):
 t=A(deg/180);sn,cs=t.sin_cos_pi()
 val=abs((3*t).sin_pi()*(t-A(F(631,3600))).sin_pi()*(t-A(F(3031,3600))).sin_pi())
 return (cs,sn),arb(1)/2+A(F(8765,100000))*val
def run():
 ctx.prec=192
 raw=(ROOT/'host.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4'
 src=json.loads(raw);p=src['vertices'];S=src['denominator'];pairs=json.loads((ROOT/'pairs.json').read_bytes(),parse_float=F)
 assert len(p)==len(pairs)==2230 and S==10**12
 worst=None
 for i,(v,w,seed) in enumerate(zip(p,p[1:]+p[:1],pairs)):
  nx,ny=w[1]-v[1],v[0]-w[0];N=(nx,ny);L=arb(nx*nx+ny*ny).sqrt()
  choices=[]
  for a,b in [seed,list(reversed(seed))]:
   for da,db in [(0,0),(F(-1,20),0),(0,F(1,20)),(F(-1,20),F(1,20))]:
    u,h0=source(F(a)+da);z,h1=source(F(b)+db);det=cross(u,z)
    if not det>0:continue
    r=cross(N,z)/det;t=cross(u,N)/det
    if r>=0 and t>=0:choices.append((r*h0+t*h1)/L)
  assert choices,(i,seed,nx,ny)
  gap=(A(F(nx*v[0]+ny*v[1]-190000*ny,S))/L-min(h.upper() for h in choices)).lower()
  assert gap>arb('1e-7'),(i,gap)
  if worst is None or gap<worst[0]:worst=gap,i
 return dict(faces=len(p),abs_amplitude='0.08765',normal_zero_degrees=['31.55','151.55'],translation=['0','.00000019'],min_facial_clearance=str(worst[0]),weakest_face=worst[1])
if __name__=='__main__':
 ans=run()
 if (ROOT/'receipt.json').exists():assert ans==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(ans,indent=2))

"""Certify a common pose for the explicit infinite-dimensional support ball."""
import hashlib,json
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
def polygon(name,checksum):
 raw=(ROOT/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==checksum
 data=json.loads(raw);S=data['denominator'];V=data['vertices'];assert S==10**12
 normals=[]
 for u,v in zip(V,V[1:]+V[:1]):
  x,y=v[1]-u[1],u[0]-v[0];normals.append((x,y,x*u[0]+y*u[1]))
 assert all(x*u+y*v<=z for x,y,z in normals for u,v in V)
 return S,V,normals
def run():
 ctx.prec=192
 S,P,H=polygon('host.json','a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f')
 _,_,E=polygon('host-2230.json','1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4')
 assert all(x*u+y*v<=z for x,y,z in E for u,v in P)
 assert 0<F(1,192)-F(1,200)-F(1,5000)<F(1,192)+F(1,200)+F(1,5000)<F(1,48)
 assert 24*F(1,192)+72*F(1,200)+F(38,5000)==F('.4926')
 lower=arb.pi()/1600-arb(2)/5000;spread=3*arb.pi()/40-arb(38)/5000
 assert lower>arb('.00156349') and spread>arb('.228019')
 walls=[]
 for x,y,z in H:
  adjusted=z-190000*y
  assert adjusted>0 and 4*adjusted**2>S**2*(x*x+y*y)
  L=arb(x*x+y*y).sqrt();walls.append((arb.atan2(arb(y),arb(x)),arb(adjusted)/(S*L)))
 rows=[]
 for s in (1,-1):
  for k in range(6):
   vals=[]
   for th,h in walls:
    z=s*(th-k*arb.pi()/3);gap=h-arb(1)/2-((5*z).sin()+z.sin())/48
    vals.append(gap.lower())
   worse=min(vals)
   if worse>0:rows.append(dict(hand=s,rotation_degrees=60*k,min_slack=str(worse)))
 assert rows
 return dict(host_faces=len(H),inherited_host_faces=len(E),parent_common_poses=rows,translation=['0','.00000019'],
             tube_distance_gt=str(lower),curvature_deviation_gt=str(spread),curvature_upper='.9926',curvature_lower='.0074')
if __name__=='__main__':
 assert __debug__
 ans=run()
 if (ROOT/'receipt.json').exists():assert ans==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(ans,indent=2))

from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent;d=json.loads((P/'MANIFEST.json').read_text())
for f,h in d.items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h,f
v=json.loads((P/'host.json').read_text())['vertices'];assert len(v)==2162
for i,(x,y) in enumerate(v):
 a,b=v[(i+1)%len(v)];dx=a-x;dy=b-y;assert dx or dy;assert all(dx*(Y-y)-dy*(X-x)>=0 for X,Y in v)
subprocess.run([sys.executable,'-I','-B','certify-seven.py'],cwd=P,check=True)
for f,h in d.items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h,f
print('PASS seven-parent closed simplex',flush=True)

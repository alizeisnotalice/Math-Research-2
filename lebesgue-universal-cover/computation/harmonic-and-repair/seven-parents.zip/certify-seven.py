from pathlib import Path
import json,hashlib
from fractions import Fraction
from flint import arb,ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from profile_source import Profile
ctx.prec=192
F=lambda x:arb(Fraction(str(x)).numerator)/Fraction(str(x)).denominator
assert hashlib.sha256(Path('host.json').read_bytes()).hexdigest()=='51e8d5f9a3bd748bf1ddb5c08e1c18d115bfe9db5ccd2072a59403dd62d6555f'
P=[Profile(json.loads(Path('parent-'+k+'.json').read_text())) for k in 'abcdefg'];host=json.loads(Path('host.json').read_text());den=F(host['denominator']);V=[tuple(F(z)/den for z in x) for x in host['vertices']]
q=F('0.0000036117246');cs=-(1-q*q)/(1+q*q);sn=-2*q/(1+q*q);hand=-1
trans=[('0.000001708095939','-0.000001429317204'),('0.000000844453436','0.000000067130089'),('0.000001478170648','-0.00000014195364'),('0.000001608632736','-0.000000184716424'),('0.000000849438946','0.000000067336746'),('0.00000104420061','-0.000000350488574'),('0.000001929756919','-0.000000273861492')];mins=[None]*7
for i,v in enumerate(V):
 w=V[(i+1)%len(V)];nx=w[1]-v[1];ny=v[0]-w[0];L=(nx*nx+ny*ny).sqrt();u=((cs*nx+sn*ny)/L,hand*(-sn*nx+cs*ny)/L);b=nx*v[0]+ny*v[1]
 for j,(p,(tx,ty)) in enumerate(zip(P,trans)):
  m=(b-nx*F(tx)-ny*F(ty))/L-p.support(u)
  if mins[j] is None or m.lower()<mins[j].lower():mins[j]=m
 if i%500==0:print(i,flush=True)
for name,m in zip('abcdefg',mins):print(name,m,flush=True);assert m>0
out={'host_sha256':hashlib.sha256(Path('host.json').read_bytes()).hexdigest(),'inputs':{name:hashlib.sha256(Path('parent-'+name+'.json').read_bytes()).hexdigest() for name in 'abcdefg'},'q':'0.0000036117246','halfturn':True,'hand':-1,'translations':trans,'minimum_clearances':[str(m) for m in mins],'reason':'same orthogonal map, interpolate translations and support functions for all seven weights'};Path('seven-receipt.json').write_text(json.dumps(out,indent=2))

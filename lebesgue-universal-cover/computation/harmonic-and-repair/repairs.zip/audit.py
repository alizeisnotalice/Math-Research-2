from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
manifest=json.loads((P/'MANIFEST.json').read_text())
for f,h in manifest.items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h,f
for script in ('build-host.py','build-five.py'):
 subprocess.run([sys.executable,'-I','-B',script],cwd=P,check=True)
for f,h in manifest.items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h,f
print('PASS: both successive host constructions match exact saved hashes',flush=True)

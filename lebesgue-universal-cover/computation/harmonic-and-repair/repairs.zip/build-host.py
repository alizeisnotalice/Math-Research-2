from fractions import Fraction as F
from pathlib import Path
from decimal import getcontext
import json,hashlib
from flint import arb,ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from profile_source import Profile
from host_build_base import A,rounded,convex,buffered,area,decimal,SCALE,N,PAD,B
ctx.prec=192;getcontext().prec=80
sources={'host-two.json':'1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4','parent-a.json':'1cbc3e46182f65f8e6da58a58f468b8ec88fabf8988c2756c6b7808e45b52dd7','parent-e.json':'6418ed327a6635fc6b7e6d5d06e8cc8ee07c0e714d1daa980b0da1fe18a1efb0','profile_source.py':'2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'}
for name,d in sources.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==d
H=json.loads(Path('host-two.json').read_text());assert H['denominator']==SCALE;V=list(map(tuple,H['vertices']));assert convex(V)==V[V.index(min(V)):]+V[:V.index(min(V))];assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
P=[Profile(json.loads(Path('parent-'+k+'.json').read_text())) for k in 'ae'];q=A('0.0000036117246');sn=-2*q/(1+q*q);cs=-(1-q*q)/(1+q*q);tx=A('.0000008444584');ty=A('.00000006694147');cloud=[]
for i in range(N):
 a,b=[p.at(2*i,N) for p in P];si,co=(2*arb.pi()*i/N).sin_cos()
 for w in [A('.8499999'),A('.8500001')]:
  y=w*a[0]+(1-w)*b[0];d=w*a[1]+(1-w)*b[1];x=(A('.5')+y)*co-d*si;z=-((A('.5')+y)*si+d*co);cloud.append((rounded(tx+cs*x-sn*z),rounded(ty+sn*x+cs*z)))
 if i%16384==0:print(i,flush=True)
p=convex(V+buffered(convex(cloud),PAD));new=area(p);old=area(V);assert new<B
raw=(json.dumps({'denominator':SCALE,'vertices':p},separators=(',',':'))+'\n').encode();Path('host-band.json').write_bytes(raw);r={'source_host_sha':sources['host-two.json'],'host_sha':hashlib.sha256(raw).hexdigest(),'vertices':len(p),'area':decimal(new),'increase':decimal(new-old),'budget_slack':decimal(B-new),'samples':N,'pad':PAD,'pose':{'q':'0.0000036117246','halfturn':True,'hand':-1,'tx':'.0000008444584','ty':'.00000006694147'},'weights':['.8499999','.8500001']};Path('host-band-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)

from fractions import Fraction as F
from pathlib import Path
from decimal import getcontext
import json,hashlib
from flint import arb,ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from profile_source import Profile
from host_build_base import A,rounded,convex,buffered,area,decimal,SCALE,N,PAD,B
ctx.prec=192;getcontext().prec=80
src={'host-band.json':'cc1b048f93c198a778caa9f236ad6deddd44b24821c94b985a405e421fce1265','parent-a.json':'1cbc3e46182f65f8e6da58a58f468b8ec88fabf8988c2756c6b7808e45b52dd7','parent-b.json':'678e9b6ab849782d89f33cbaa36a060040c5f75a5fe9067107296813652187fd','parent-c.json':'9a610c360a0d47bb1af8b1c021e78858e9721b0f9ccffa41d765f5a0f2eb258b','parent-d.json':'77e4797c59ea521f7bb1831d55d3a6cd5578fe1540864094db47e11ec7a760a8','parent-e.json':'6418ed327a6635fc6b7e6d5d06e8cc8ee07c0e714d1daa980b0da1fe18a1efb0','profile_source.py':'2cb253f3eddf195dbb05c65a84d9a9c40d17e8101f8962348f1e27e80de6d646'}
for name,d in src.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==d
H=json.loads(Path('host-band.json').read_text());assert H['denominator']==SCALE;V=list(map(tuple,H['vertices']));assert convex(V)==V[V.index(min(V)):]+V[:V.index(min(V))];assert arb.pi()**2/(2*N**2)+arb(2).sqrt()/SCALE<A(F(PAD,SCALE))
P=[Profile(json.loads(Path('parent-'+k+'.json').read_text())) for k in 'abcde'];trans=[('0.000001708095939','-0.000001429317204'),('0.000000844453436','0.000000067130089'),('0.000001478170648','-0.00000014195364'),('0.000001608632736','-0.000000184716424'),('0.000000849438946','0.000000067336746')];q=A('0.0000036117246');sn=-2*q/(1+q*q);cs=-(1-q*q)/(1+q*q);cloud=[]
for i in range(N):
 si,co=(2*arb.pi()*i/N).sin_cos()
 for p,(xt,yt) in zip(P,trans):
  y,d=p.at(2*i,N);x=(A('.5')+y)*co-d*si;z=-((A('.5')+y)*si+d*co);cloud.append((rounded(A(xt)+cs*x-sn*z),rounded(A(yt)+sn*x+cs*z)))
 if i%16384==0:print(i,flush=True)
p=convex(V+buffered(convex(cloud),PAD));new=area(p);old=area(V);assert new<B
raw=(json.dumps({'denominator':SCALE,'vertices':p},separators=(',',':'))+'\n').encode();Path('host-five.json').write_bytes(raw);r={'source_host_sha':src['host-band.json'],'host_sha':hashlib.sha256(raw).hexdigest(),'vertices':len(p),'area':decimal(new),'increase':decimal(new-old),'budget_slack':decimal(B-new),'samples':N,'pad':PAD,'pose':{'q':'0.0000036117246','halfturn':True,'hand':-1,'translations':trans},'simplex':'all nonnegative weights summing to 1 for all five parents'};Path('host-five-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)

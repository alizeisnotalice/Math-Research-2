"""Replay the standalone finite-spectrum obstructions to the fixed 1189-side host."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys
from flint import ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from certify_poly import Exact, HOST_SHA, read, sha


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('out',type=Path)
    args=p.parse_args()
    assert __debug__
    ctx.prec=192
    records=[]
    touched={'verify_release.py','certify_poly.py','profile_source.py','host.json'}
    cases=read(HERE/'cases.json')
    touched.add('cases.json')
    for case in cases:
        spec,rows,plan=[HERE/case[i] for i in ('input','rows','plan')]
        x=Exact(spec,rows)
        d=case['degree']
        assert x.src['degree']==d
        gap,curvature=F(case['gap']),F(case['radius_margin'])
        ns=case.get('convolution_source')
        if ns:
            radius=x.smoothing_curvature(HERE/ns,curvature)
            touched.add(ns)
        else:
            radius=x.strict_curvature(case['radius_grid'],curvature)
        result=dict(degree=d,verified_euclidean_gap=str(gap),strict_radius_interval=radius,
                    hands=x.verify(read(plan),gap))
        records.append(result)
        print(json.dumps(result),flush=True)
        touched.update(p.name for p in (spec,rows,plan))
    receipt=dict(complete=True,host_sha256=HOST_SHA,profiles=records,
                 files={name:sha(HERE/name) for name in sorted(touched)},
                 precision=ctx.prec,python=platform.python_version(),flint=flint_version)
    args.out.write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
    main()

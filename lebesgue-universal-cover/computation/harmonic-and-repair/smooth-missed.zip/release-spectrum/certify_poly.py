"""Verify width, strict curvature, and full-pose separation of an odd trigonometric support."""
import argparse
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
import json
from pathlib import Path
import sys
from flint import arb, ctx, __version__ as flint_version

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
HOST_SHA='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'


def A(q):
    q=F(q)
    return arb(q.numerator)/q.denominator


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def cmul(u,v):
    x,y=u
    a,b=v
    return x*a-y*b,x*b+y*a


class Exact:
    def __init__(self,input_file,rows_file):
        assert sha(HERE/'host.json')==HOST_SHA
        h=read(HERE/'host.json')
        P=h['vertices']
        d=h['denominator']
        assert len(P)==1189 and d==10**12
        self.src=read(input_file)
        degree=self.src['degree']
        self.n=tuple(k for k,_,_ in self.src['curvature_modes'])
        assert self.n==tuple(range(3,degree+1,2)) and degree%2==1
        self.f=[(A(a),A(b)) for _,a,b in self.src['curvature_modes']]
        assert any(F(v) for v in self.src['curvature_modes'][-1][1:])
        self.h=[(a/(1-k*k),b/(1-k*k)) for k,(a,b) in zip(self.n,self.f,strict=True)]
        rows=read(rows_file)
        self.const=[]
        self.c={1:[],-1:[]}
        self.sec={1:[],-1:[]}
        self.row_count=len(rows)
        for row in rows:
            dirs=[tuple(v) for v in row['normals']]
            coeff=list(map(F,row['weights']))
            assert len(dirs)==len(coeff) and len(dirs)>=3
            assert all(w>=0 for w in coeff)
            assert all(sum(w*n[j] for w,n in zip(coeff,dirs,strict=True))==0 for j in (0,1))
            assert sum(coeff)>0
            norm=[arb(x*x+y*y).sqrt() for x,y in dirs]
            assert all(x>0 for x in norm)
            weights=[A(w)*v for w,v in zip(coeff,norm,strict=True)]
            scale=sum(weights)
            hx=sum(w*F(max(x*u+y*v for u,v in P),d) for w,(x,y) in zip(coeff,dirs,strict=True))
            self.const.append(A('.5')-A(hx)/scale)
            moments={k:[arb(0),arb(0)] for k in self.n}
            for (x,y),v,w in zip(dirs,norm,weights,strict=True):
                u=(arb(x)/v,arb(y)/v)
                p=u
                u2=cmul(u,u)
                for k in self.n:
                    p=cmul(p,u2)
                    moments[k][0]+=w*p[0]/scale
                    moments[k][1]+=w*p[1]/scale
            for s in (1,-1):
                pair=[]
                for k,(a,b) in zip(self.n,self.h,strict=True):
                    # u denotes arg n; evaluate h(s*(u-theta)).
                    c,e=moments[k]
                    pair.append((a*c+s*b*e,a*e-s*b*c))
                self.c[s].append(pair)
                self.sec[s].append(sum(k*k*(abs(a)+abs(b)) for k,(a,b) in zip(self.n,pair,strict=True)))
        self.f_sec=sum(k*k*(abs(a)+abs(b)) for k,(a,b) in zip(self.n,self.f,strict=True))

    @cache
    def trig(self,t):
        q=arb.pi()*A(2*t)
        return [(k*q).sin_cos() for k in self.n]

    def at(self,coeff,t):
        return sum(a*c+b*s for (a,b),(s,c) in zip(coeff,self.trig(t),strict=True))

    def row_lower(self,i,hand,left,right):
        c=self.c[hand][i]
        d=self.sec[hand][i]
        width=arb.pi()*A(2*(right-left))
        values=[self.const[i]+self.at(c,t) for t in (left,right)]
        return (min(x.lower() for x in values)-d*width**2/8).lower()

    def strict_curvature(self,grid,threshold):
        assert type(grid) is int and grid>0
        upper=max(abs(self.at(self.f,F(j,2*grid))).upper() for j in range(grid+1))
        bound=(upper+self.f_sec*(arb.pi()/grid)**2/8).upper()
        assert bound<A('.5')-A(threshold),(bound,threshold)
        return str((A('.5')-bound).lower()),str((A('.5')+bound).upper())

    def smoothing_curvature(self,path,threshold):
        from profile_source import Profile

        source=Profile(read(path))
        d=self.n[-1]
        alpha=arb.pi()/(d+2)
        fac=A("0.99999999")
        integral_scale=2/arb.pi()
        total=arb(0)
        for i,k in enumerate(self.n):
            sines=[]
            cosines=[]
            for knot in source.knots:
                sn,cs=(k*knot).sin_cos()
                sines.append(sn)
                cosines.append(cs)
            raw_a=integral_scale*sum(f*(y-x) for f,x,y in zip(source.fs,sines,sines[1:]))/k
            raw_b=integral_scale*sum(f*(x-y) for f,x,y in zip(source.fs,cosines,cosines[1:]))/k
            c=((d+1-k)*(k*alpha).cos()+((k+1)*alpha).sin()/alpha.sin())/(d+2)
            a,b=self.f[i]
            total+=abs(a-fac*c*raw_a)+abs(b-fac*c*raw_b)
        bound=((1-fac)/2-total).lower()
        assert bound>A(threshold),(bound,total)
        return (str(bound),str((1-bound).upper()))

    def make_plan(self,level):
        import numpy as np
        moment={s:np.asarray([[tuple(float(z.mid()) for z in p) for p in c] for c in self.c[s]]) for s in (1,-1)}
        base=np.asarray([float(x.mid()) for x in self.const])
        n=np.asarray(self.n)
        result={}
        for hand in (1,-1):
            cells=[]
            def visit(l,h,depth):
                a=float((l+h)/2)*2*np.pi*n
                c=moment[hand]
                vals=base+c[:,:,0]@np.cos(a)+c[:,:,1]@np.sin(a)
                for i in np.argsort(-vals)[:5]:
                    if self.row_lower(int(i),hand,l,h)>A(level):
                        cells.append([str(l),str(h),int(i)])
                        return
                assert depth<21,(hand,float(l)*360,float(h)*360,float(vals.max()))
                m=(l+h)/2
                visit(l,m,depth+1)
                visit(m,h,depth+1)
            for j in range(72):visit(F(j,72),F(j+1,72),0)
            result[str(hand)]=cells
        return result

    def verify(self,cover,level):
        outcome={}
        for hand in (1,-1):
            prior=F(0)
            vals=[]
            row_ids=set()
            for a,b,i in cover[str(hand)]:
                l,r=F(a),F(b)
                assert l==prior and l<r and type(i) is int and 0<=i<self.row_count
                prior=r
                q=self.row_lower(i,hand,l,r)
                assert q>A(level),(hand,a,b,i,q)
                vals.append(q)
                row_ids.add(i)
            assert prior==1
            outcome[str(hand)]=dict(closed_cells=len(vals),weakest=str(min(vals)),rows_used=len(row_ids))
        return outcome


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('input','rows','plan','receipt'):p.add_argument(n,type=Path)
    p.add_argument('--make-plan',action='store_true')
    p.add_argument('--gap',type=F,default=F('1e-7'))
    p.add_argument('--rho',type=F,default=F('1e-6'))
    p.add_argument('--curv-grid',type=int,default=16384)
    p.add_argument('--convolution-source',type=Path)
    args=p.parse_args()
    assert __debug__ and args.gap>0 and args.rho>0
    ctx.prec=192
    e=Exact(args.input,args.rows)
    path=args.convolution_source
    rho=e.smoothing_curvature(path,args.rho) if path else e.strict_curvature(args.curv_grid,args.rho)
    print('strict curvature range',rho,flush=True)
    if args.make_plan:
        cover=e.make_plan(args.gap)
        args.plan.write_text(json.dumps(cover,separators=(',',':'))+'\n')
    else:
        cover=read(args.plan)
    result=dict(complete=True,degree=e.src['degree'],scope='both hands, all angles, all common translations',
        strict_curvature_interval=rho,checked_curvature_grid=None if path else args.curv_grid,
        convolution_source_sha256=sha(path) if path else None,curvature_margin_target=str(args.rho),
        verified_euclidean_gap=str(args.gap),hands=e.verify(cover,args.gap),host_sha256=HOST_SHA,
        input_sha256=sha(args.input),rows_sha256=sha(args.rows),plan_sha256=sha(args.plan),
        verifier_sha256=sha(Path(__file__)),precision=ctx.prec,flint=flint_version)
    args.receipt.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    main()

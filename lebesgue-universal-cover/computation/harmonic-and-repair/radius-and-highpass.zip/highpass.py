from flint import arb,arb_mat,ctx
from fractions import Fraction as F
def A(v):q=F(v);return arb(q.numerator)/q.denominator
def green(t):
 sn,cs=t.sin_cos()
 return -cs/2+(arb.pi()/2-t)*sn
def kernel(m,N=2048):
 freq=list(range(1,m,2));angles=[(2*j+1)*arb.pi()/(2*m) for j in range(len(freq))]
 mat=arb_mat([[(t*k).cos() for k in freq] for t in angles]);assert not mat.det().contains(0)
 xs=mat.solve(arb_mat([[green(t)] for t in angles]));c=[xs[j,0] for j in range(len(freq))]
 curvature=arb(3)+arb.pi()/2+sum(k*k*abs(v) for k,v in zip(freq,c))
 gap=arb.pi()/(2*N)
 def residual(j):
  t=gap*j;return abs(green(t)-sum(cc*(k*t).cos() for cc,k in zip(c,freq)))
 tr=sum(residual(j) for j in range(1,N))+(residual(0)+residual(N))/2
 limit=tr/N+curvature*gap**2/8
 return limit,c
if __name__=='__main__':
 ctx.prec=192
 for m in [9,11,13,15,17,19]:
  lim,c=kernel(m)
  print(m,str(lim),[round(float(x),9) for x in c],flush=True)

import hashlib,json,sys
from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from highpass import kernel,A
def dot(x,y):return x[0]*y[0]+x[1]*y[1]
def cross(x,y):return x[0]*y[1]-x[1]*y[0]
def plus(a,b):return [x+y for x,y in zip(a,b)]
def scale(a,q):return [x*q for x in a]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def point_segment_squared(p,a,b):
 d=sub(b,a);v=sub(p,a);t=dot(v,d);ds=dot(d,d)
 assert ds>0
 if t<0:return dot(v,v)
 if t>ds:
  w=sub(p,b);return dot(w,w)
 return cross(d,v)**2/ds
def directions(sigma):
 def u(d):
  s,c=A(d/180).sin_cos_pi();return c,s
 return [u(F(i)) for i in [0,60,120,180,210+sigma,240,300,330+sigma]]
def threshold(N,sigma,rlo,rhi,elo,ehi,expected):
 U=directions(sigma)
 UV=[scale(plus(u,v),1/(2*(1+dot(u,v)))) for u,v in zip(U,U[1:]+U[:1])]
 wscale=2*A(elo)
 small=[scale(x,wscale) for x in UV];seg=list(zip(small,small[1:]+small[:1]))
 positive=[];radbad=[];ebad=[]
 for i,(n,h) in enumerate(N):
  j=(-n[1],n[0]);lo=[];hi=[];outside=False
  for u in U:
   d=dot(u,j);c=arb(1)/2-h*dot(u,n)
   if d>0:hi.append(c/d)
   elif d<0:lo.append(c/d)
   else:
    assert d.is_zero()
    if c<0:outside=True;break
    assert c>=0
  if outside:continue
  l=max(lo);r=min(hi)
  if l>r:continue
  assert l<r and any(dot(n,v)>h for v in UV)
  a=plus(scale(n,h),scale(j,l));b=plus(scale(n,h),scale(j,r))
  # The closed host boundary line segment inside P lies outside the near-disk models.
  q=point_segment_squared([arb(0),arb(0)],a,b);assert q>A(rlo)**2,(i,q)
  if q<A(rhi)**2:radbad.append(i)
  sq=[point_segment_squared(v,a,b) for v in small]
  for v,z in seg:
   sq.extend([point_segment_squared(a,v,z),point_segment_squared(b,v,z)])
  assert all(v>A(F(1,2)+elo)**2 for v in sq),(i,min(sq))
  for endpoint in (a,b):
   for v in UV:
    delta=sub(endpoint,scale(v,2*A(ehi)))
    if dot(delta,delta)<A(F(1,2)+ehi)**2:ebad.append(i)
  positive.append(i)
 assert expected[0] in radbad and expected[1] in ebad,(radbad,ebad)
 return dict(sigma=str(sigma),crossing_faces=len(positive),truncated_radius=[str(rlo),str(rhi)],radial_upper_faces=sorted(set(radbad)),
             near_disk_excess=[str(elo),str(ehi)],offset_upper_faces=sorted(set(ebad)))
def run():
 ctx.prec=192
 raw=(ROOT/'host.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'
 src=json.loads(raw);p=src['vertices'];S=src['denominator'];assert S==10**12 and len(p)==1189
 N=[]
 for a,b in zip(p,p[1:]+p[:1]):
  nx,ny=b[1]-a[1],a[0]-b[0];L=arb(nx*nx+ny*ny).sqrt()
  N.append(((arb(nx)/L,arb(ny)/L),A(F(nx*a[0]+ny*a[1]-190000*ny,S))/L))
 a=threshold(N,F('1.55'),F('.51185530137014'),F('.51185530137016'),F('.00582747911997'),F('.00582747911999'),(31,19))
 b=threshold(N,F('1.549894'),F('.5031768725'),F('.5031768727'),F('.0015710779'),F('.0015710781'),(24,24))
 lim,c=kernel(11);assert lim<A('.010284102') and lim/2<A('.0058274')
 lo=[abs(v).upper()/2 for v in c[1:]]
 rounded=[F('.121367'),F('.037590'),F('.015983'),F('.006360')]
 assert all(x<A(y) for x,y in zip(lo,rounded,strict=True))
 assert lim/2+A('.0006854')<A('.00582747911997')
 return dict(radial_models=[a,b],green_L1_upper=str(lim),steiner_radius_excess_upper=str(lim/2),
             low_curvature_harmonics=[3,5,7,9],low_amplitude_weights=list(map(str,rounded)),weighted_admissible_sum='.0006854')
if __name__=='__main__':
 ans=run()
 if (ROOT/'receipt.json').exists():assert ans==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(ans,indent=2))

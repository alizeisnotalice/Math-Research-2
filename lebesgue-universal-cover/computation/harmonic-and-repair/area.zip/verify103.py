"""Replay exact-depth chords and balanced mixed-area rows without optimization."""
import sys,json,hashlib
from functools import reduce
from pathlib import Path
from flint import arb
sys.path.insert(0,str(Path(__file__).resolve().parent));sys.argv=[sys.argv[0],'1.03e-8'];exec(compile(Path(__file__).with_name('chord_test.py').read_text().split('report={}')[0],str(Path(__file__).with_name('chord_test.py')),'exec'))
p=Path(__file__).resolve().parent;cert=json.loads((p/'hybrid103-result.json').read_bytes());assert cert['complete'] and F(cert['area_threshold'])==T
E=[(v[0]-u[0],v[1]-u[1]) for u,v in zip(V,V[1:]+V[:1])]
assert all((dx or dy) and all(dx*(Y-y)-dy*(X-x)>=0 for X,Y in V) for (x,y),(dx,dy) in zip(V,E))
N=[(dy,-dx) for dx,dy in E]
@cache
def mat(t):
 t=F(t)%360;x,y=profile.at((t/180).numerator,(t/180).denominator);sn,cs=(arb.pi()*A(t)/180).sin_cos();return (A('.5')+x)*cs-y*sn,(A('.5')+x)*sn+y*cs

def verify_mixed(c):
 lo,hi=F(c['lo']),F(c['hi']);terms=[(int(i),F(q),F(t)) for i,q,t in c['terms']];assert 0<hi-lo<180 and len({i for i,_,_ in terms})==len(terms) and all(0<=i<len(V) and 0<=q<=1 for i,q,t in terms)
 assert all(sum(q*N[i][k] for i,q,_ in terms)==0 for k in (0,1))
 xs=ys=arb(0);host=F(0)
 for i,q,t in terms:
  nx,ny=N[i];x,y=mat(t);y=-y;xs+=A(q)*(nx*x+ny*y)/D;ys+=A(q)*(ny*x-nx*y)/D;host+=q*(nx*V[i][0]+ny*V[i][1])/(D*D)
 vals=[]
 for t in (lo,hi):
  sn,cs=(arb.pi()*A(t)/180).sin_cos();value=xs*cs+ys*sn;assert value>0;vals.append(((value-A(host))/2).lower())
 v=reduce(arb.min,vals).lower();assert v>A(T),(lo,hi,str(v));return v

checks={1:[],-1:[]};ms=[];cs=[]
for c in cert['mixed_cells']:
 lo,hi=F(c['lo']),F(c['hi']);q=verify_mixed(c);ms.append(q);checks[-1].append((lo,hi))
for hand,lo,hi,i,angles,_ in cert['chord_cells']:
 h=int(hand);lo,hi=F(lo),F(hi);assert h in checks and 0<hi-lo<180 and 0<=i<len(rows)
 q=(bound(lo,hi,h,i,angles)-allowance(i)).lower();assert q>0,(h,lo,hi,str(q));cs.append(q);checks[h].append((lo,hi))
for h in checks:
 prev=F(0)
 for lo,hi in sorted(checks[h]):assert lo==prev,(h,lo,prev);prev=hi
 assert prev==360
area=F(sum(x*v-y*u for (x,y),(u,v) in zip(V,V[1:]+V[:1])),2*D*D);assert area==F('0.8440813573601329863574445')
result={'host_area':str(area),'combined_strict_floor':str(area+T),'complete':True,'threshold':str(T),'weight_interval':['8499999/10000000','8500001/10000000'],'host_sha256':hashlib.sha256((p/'host.json').read_bytes()).hexdigest(),'chord_cells':len(cs),'mixed_cells':len(ms),'minimum_mixed_area':str(reduce(arb.min,ms).lower()),'minimum_chord_slack':str(reduce(arb.min,cs).lower()),'directions':permit.cache_info().currsize}
(p/'hybrid103-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

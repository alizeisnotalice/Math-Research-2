from pathlib import Path
from fractions import Fraction as F
from functools import cache
from flint import arb,ctx
import json,sys
from certify_band import data,kernel,A
ctx.prec=192
P=Path(__file__).resolve().parent;doc=json.loads((P/'host.json').read_text());V=doc['vertices'];D=doc['denominator'];T=F(sys.argv[1]);profile,rows,caps=data(None);bound=kernel(profile,caps);plan=json.loads((P/'plan.json').read_bytes());DEPTH=list(map(F,['.0000001','.00000025','.0000005','.000001','.000002','.000005','.00001','.00002','.00005','.0001','.0002','.0005','.001','.002','.005','.01','.02','.05']))
@cache
def permit(n):
 nx,ny=n; hs=[nx*x+ny*y for x,y in V];ts=[-ny*x+nx*y for x,y in V];mx=max(hs);length=arb(nx*nx+ny*ny).sqrt();best=None
 for dep in DEPTH:
  shift=dep*D*max(abs(nx),abs(ny));num=mx*shift.denominator-shift.numerator;den=shift.denominator; ends=[]
  for h,k,p,q in zip(hs,hs[1:]+hs[:1],ts,ts[1:]+ts[:1]):
   a=h*den-num;b=k*den-num
   if a==0:ends.append(F(p))
   elif a*b<0:ends.append(F(p*(a-b)+(q-p)*a,a-b))
  if len(ends)<2:continue
  ll=A((max(ends)-min(ends))/D)/length;dd=A(shift/D)/length
  if not ll>0:continue
  v=A(T)/ll;q=(v+(v*v+2*v*dd).sqrt()).upper()
  if best is None or q<best:best=q
 assert best is not None
 return best
@cache
def allowance(r):
 row=rows[r];return (sum((A(q)*arb(x*x+y*y).sqrt()*permit((x,y)) for (x,y),q in zip(row['normals'],row['weights']) if F(q)),arb(0))/caps[r][2]).upper()
report={};minimum=None;bad=[]
for hand,cells in plan.items():
 prev=F(0)
 for lo,hi,i,angs in cells:
  lo,hi=F(lo),F(hi);assert lo==prev and lo<hi<lo+180;prev=hi
  gap=(bound(lo,hi,int(hand),i,angs)-allowance(i)).lower()
  if not gap>0:bad.append([hand,str(lo),str(hi),i,str(gap)])
  if minimum is None or gap<minimum:minimum=gap
 assert prev==360
report={'threshold':str(T),'hands':{h:len(c) for h,c in plan.items()},'min_gap':str(minimum),'failures':bad,'normal_count':permit.cache_info().currsize,'scope':'w=0.85 +/- 1e-7, 360 degrees, both hands','depths':[str(x) for x in DEPTH]}
(P/'chord-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

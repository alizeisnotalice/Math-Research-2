# Fixed 2230-face host: global true-area lower bound

Let C be the rational 2230-vertex polygon in host.json, with exact area 0.8440813573601329863574445. Let A,E be the unit-width curvature profiles in parent-a.json and parent-e.json, and K_w=wA+(1−w)E. For every w in [0.8499999,0.8500001], every orthogonal map (both hands), and every translation t,

    area(conv(C ∪ (O K_w+t))) − area(C) > 0.0000000103.

Hence the combined area is strictly greater than 0.8440813676601329863574445. This result concerns this particular fixed host and one independently movable additional input; it is not a lower bound for all possible universal covers or for replacing C. All mixed-area and chord tests use true body points obtained from the profile ODE with 192-bit Arb enclosures, not sample polygon points. Profile initialization verifies the defining linear system and curvature constraints, and the positive weighted mixture remains a unit-width body.

Verification uses 212 closed angle cells with the deep-chord method and 7 with an exact balanced mixed-area dual. The cells join exactly to [0,360] in both hands. Chord cells use 59 directions: if total added area≤T, for any host chord at depth d and length L behind an old support line, its placed material point has support excess at most T/L+sqrt((T/L)^2+2Td/L). The verifier computes intersections with every rational polygon edge for 18 exact depths, uses the best available bound, and balances the four normal coefficients to eliminate translation. It checks the true material projection against that bound on both angular endpoints; positive sinusoidal interpolation covers each cell. Host convexity is checked exactly, including all vertices against every edge.

For each mixed-area cell, each chosen old host edge i has integer outward normal n_i and rational weight 0≤q_i≤1. The code verifies Σq_i n_i=0 exactly. Convexity and monotonicity of mixed area give

    area(conv(C ∪ placed K_w))−area(C)
    ≥ 1/2 Σ_i q_i (n_i·placed p_i − h_C(n_i)),

with normals interpreted in physical units. The same stored true point p_i is used throughout the angular cell, and exact balance removes t. All its point coordinates are evaluated for the entire weight interval; both angular endpoint nonconstant terms are positive, so positive sine interpolation makes the smaller endpoint a valid uniform lower bound. The minimum interval-certified mixed-area value is >1.03215046884846e−8, while every chord cell has a strictly positive budget margin.

Run `python -I -B verify103.py` from this directory, with Python and python-flint installed. This verifier reads the fixed certificate and does not run SciPy or any optimizer. It rebuilds all profile values and chord intersections; verifies exact support balance, all 2230-edge convexity constraints, and full angular coverage; and writes hybrid103-verification.json. Host and profile hashes are verified by certify_band.py. Input plan.json is retained because chord_test.py loads it; the actual final angular partition and exact duals are hybrid103-result.json. Python 3.13.18, python-flint 0.9.0 was used for the recorded run. The root search / LP that proposed the certificate is not part of its proof.

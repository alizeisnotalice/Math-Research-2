from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,hashlib
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
def A(x):r=F(x);return arb(r.numerator)/r.denominator
def cross(u,v):return u[0]*v[1]-u[1]*v[0]
@lru_cache(None)
def source(deg):
 deg%=360
 t=A(deg/180);sn,cs=t.sin_cos_pi()
 terms=[]
 # For each actual anchor .5u+v Ju, |v|<=tol, the source is in its unit disk.
 for direction,radius in [(F('31.55'),F('.0308')),(F(240),F('.036')),(F(120),F('.036')),(F(300),F('.036'))]:
  ss,cc=A((deg-direction)/180).sin_cos_pi()
  terms.append(arb(1)+cc/2+A(radius)*abs(ss))
 if deg%60==0 or deg==F('331.55'):terms.append(arb(1)/2)
 return (cs,sn),min(x.upper() for x in terms)
def run():
 ctx.prec=192
 raw=(ROOT/'host.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4'
 src=json.loads(raw);p=src['vertices'];S=src['denominator'];pairs=json.loads((ROOT/'minimal-pairs.json').read_bytes(),parse_float=F)
 assert len(p)==len(pairs)==2230 and S==10**12
 worst=None
 for i,(v,w,seed) in enumerate(zip(p,p[1:]+p[:1],pairs)):
  nx,ny=w[1]-v[1],v[0]-w[0];N=(nx,ny);L=arb(nx*nx+ny*ny).sqrt()
  choices=[]
  for a,b in [seed,list(reversed(seed))]:
   for da,db in [(0,0),(F(-1,20),0),(0,F(1,20)),(F(-1,20),F(1,20))]:
    u,h0=source(F(a)+da);z,h1=source(F(b)+db);det=cross(u,z)
    if not det>0:continue
    r=cross(N,z)/det;t=cross(u,N)/det
    if r>=0 and t>=0:choices.append((r*h0+t*h1)/L)
  assert choices,(i,seed,nx,ny)
  gap=(A(F(nx*v[0]+ny*v[1]-190000*ny,S))/L-min(h.upper() for h in choices)).lower()
  assert gap>arb('1e-7'),(i,gap)
  if worst is None or gap<worst[0]:worst=gap,i
 return dict(faces=len(p),fixed_strip_angles=[0,60,120],single_cap='331.55',
             anchor_angles=['31.55','240','120','300'],tangent_radii=['.0308','.036','.036','.036'],
             translation=['0','.00000019'],min_facial_clearance=str(worst[0]),weakest_face=worst[1])
if __name__=='__main__':
 ans=run()
 if (ROOT/'receipt.json').exists():assert ans==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(ans,indent=2))

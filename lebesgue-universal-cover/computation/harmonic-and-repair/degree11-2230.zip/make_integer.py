from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from flint import arb,ctx
Q=10**9
def rnd(x):
 x=x*Q
 m,e=map(int,x.mid().man_exp())
 if e<0:k=(m+(1<<(-e-1)))>>(-e)
 else:k=m<<e
 assert abs(x-k)<1
 return k
def build():
 ctx.prec=160;pi=arb.pi();T=pi/3
 src=Path(__file__).with_name('host.json').read_bytes()
 assert sha256(src).hexdigest()=='1c42350d7989548d52208b6d2c695e7eb759a3ed4fee84e8af6eb5024c98d8d4'
 dat=json.loads(src);den=dat['denominator'];P=dat['vertices']
 H=[(a.cos()/arb(3).sqrt(),a.sin()/arb(3).sqrt()) for a in [T*(arb(1)/2+j) for j in range(6)]]
 rows=[[] for _ in range(12)];ub=[]
 for v,u in zip(P,P[1:]+P[:1]):
  X,Y=u[1]-v[1],v[0]-u[0];L=arb(X*X+Y*Y).sqrt();b=arb(X*v[0]+Y*v[1])/den-arb(Y)*19/100000000
  assert b/L>arb(1)/2
  if all(X*x+Y*y<b for x,y in H):continue
  th=arb.atan2(arb(Y),arb(X));st=abs((3*th).sin());assert st>0
  w=(b/L-arb(1)/2)/st
  cap=rnd(w)-10;assert cap+9<Q*w and 0<=cap<Q
  ub.append(cap)
  for k in range(12):
   z=(1 if k<6 else -1)*(th-(k%6)*T);sn=(3*z).sin();s=1 if sn>0 else -1;assert s*sn>0
   f=[arb(s)/8,s*(1+2*(6*z).cos())/80,-s*(6*z).sin()/40,-s*(2*z).sin()/12,s*(2*z).cos()/12,-s*(4*z).sin()/24,s*(4*z).cos()/24,-s*(3*z).cos()*(5*z).sin()/30,s*(3*z).cos()*(5*z).cos()/30]
   direct=[(3*z).sin()/8,(9*z).sin()/80,((9*z).cos()-(3*z).cos())/80,
           ((5*z).cos()-z.cos())/24,((5*z).sin()+z.sin())/24,
           ((7*z).cos()-z.cos())/48,((7*z).sin()-z.sin())/48,
           ((11*z).cos()-z.cos())/120,((11*z).sin()+z.sin())/120]
   assert all((v-st*l).contains(0) for v,l in zip(direct,f,strict=True))
   rows[k].append([rnd(x) for x in f])
 M=[]
 for j in range(72):
  t=2*pi*j/72
  M.append([rnd(z) for z in [(3*t).sin(),(9*t).sin(),(9*t).cos()-(3*t).cos()/10,(5*t).cos(),(5*t).sin(),(7*t).cos(),(7*t).sin(),(11*t).cos(),(11*t).sin()]])
 assert len(ub)==2218
 return np.array(rows,dtype=np.int64),np.array(ub,dtype=np.int64),M

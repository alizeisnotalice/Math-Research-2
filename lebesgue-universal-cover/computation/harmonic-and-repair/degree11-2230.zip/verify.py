import sys,time,json
from pathlib import Path
from itertools import combinations,product
from collections import defaultdict,Counter
from functools import lru_cache
from math import gcd
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from make_integer import build,Q
from flint import fmpz_mat
C,B,phys=build()
M=len(phys);N=len(B);dim=9
planes=[tuple(t)+(-Q//2-9,) for t in phys]
planes+=[(-1,0,0,0,0,0,0,0,0,0),(0,0,0,-578,1000,0,0,0,0,0),(0,0,0,-578,-1000,0,0,0,0,0)]
BOX=len(planes)
for i in range(dim):
 for sign in (-1,1):planes.append(tuple(sign if k==i else 0 for k in range(dim))+(-1,))
CUT=len(planes)
planes += [tuple(map(int,c))+(-int(b)+32,) for rs in C for c,b in zip(rs,B)]
def dot(a,b):
 return sum(i*j for i,j in zip(a,b))
def primitive(v):
 g=gcd(*v);g=g if v[-1]>0 else -g
 return tuple(x//g for x in v)
@lru_cache(maxsize=250000)
def independent(*labels):
 assert len(labels)==dim-1
 return fmpz_mat([list(planes[i][:-1]) for i in labels]).rank()==dim-1
def split(P,cut,j,both):
 nu=planes[cut];pos={};neg={};val={};zeros={}
 for v,ac in P.items():
  d=dot(nu,v);val[v]=d
  if d>0:pos[v]=ac
  elif d<0:neg[v]=ac
  else:zeros[v]=ac|{cut}
 if not pos:return dict(neg|zeros), dict(zeros) if both else {}
 if not neg:return dict(zeros),dict(pos|zeros) if both else {}
 # Enumerate all edges crossing this plane. Edge endpoints have seven
 # independent common active normals, in addition to the root equality.
 groups=defaultdict(list)
 for v,ac in neg.items():
  for t in combinations(sorted(ac),dim-2):
   if independent(j,*t):groups[t].append(v)
 for w,ac in pos.items():
  touched=set()
  for t in combinations(sorted(ac),dim-2):touched.update(groups.get(t,()))
  for v in touched:
   a,b=val[w],-val[v];z=primitive(tuple(a*i+b*k for i,k in zip(v,w)))
   active=(neg[v]&ac)|{cut}
   if z in zeros:zeros[z]|=active
   else:zeros[z]=active
 return neg|zeros,(pos|zeros) if both else {}
def initial(j):
 a=planes[j];p=max(range(dim),key=lambda k:abs(a[k]));f=[k for k in range(dim) if k!=p];P={}
 for signs in product((-1,1),repeat=dim-1):
  v=[0]*dim
  for i,s in zip(f,signs):v[i]=s*a[p]
  v[p]=-a[-1]-sum(a[i]*s for i,s in zip(f,signs))
  ac=frozenset(BOX+2*i+(s>0) for i,s in zip(f,signs))
  P[primitive(tuple(v)+(a[p],))]=ac
 for n in [BOX+2*p,BOX+2*p+1,M,M+1,M+2]+[i for i in range(M) if i!=j]:
  if not P:break
  P=split(P,n,j,False)[0]
 return P
# A rational vertex has |x_i|<=1. Cache directed-integer lower tests for every
# pose, measured in Q^{-2} units, after flooring all nine coefficients.
@lru_cache(maxsize=130000)
def support(v):
 X=np.array([x*Q//v[-1] for x in v[:-1]],dtype=np.int64)
 assert np.max(abs(X))<=Q
 # Every dot is safely within 2^63: each |C_i|<=Q/8+1 and |X_i|<=Q.
 g=B*Q-C@X
 return g.min(axis=1)
def verify_node(P,j,tree,stats,counts):
 if not P:
  assert tree==-1
  return
 if isinstance(tree,int):
  assert 0<=tree<12
  smallest=min(int(support(v)[tree]) for v in P)
  assert smallest>=4*Q,(j,tree,smallest)
  stats["lowest_integer_margin"]=min(stats["lowest_integer_margin"],smallest)
  stats["closed_cells"]+=1;counts[tree]+=1
  return
 cut,left,right=tree
 assert isinstance(cut,int) and CUT<=cut<len(planes)
 P0,P1=split(P,cut,j,True)
 stats["exact_splits"]+=1
 verify_node(P0,j,left,stats,counts)
 verify_node(P1,j,right,stats,counts)

def facet(j,tree):
 assert __debug__ and C.shape==(12,2218,9) and np.max(abs(C))<=Q//8+1
 assert planes[M:M+3]==[(-1,0,0,0,0,0,0,0,0,0),(0,0,0,-578,1000,0,0,0,0,0),(0,0,0,-578,-1000,0,0,0,0,0)]
 stats={'closed_cells':0,'exact_splits':0,'lowest_integer_margin':10**30};counts=[0]*12
 P=initial(j);verify_node(P,j,tree,stats,counts)
 return dict(vertices=len(P),poses=counts,**stats)
def run():
 from concurrent.futures import ProcessPoolExecutor
 from multiprocessing import get_context
 import argparse
 from fractions import Fraction as F
 from flint import arb,ctx
 from decimal import Decimal,getcontext
 p=argparse.ArgumentParser();p.add_argument('--jobs',type=int,default=1);args=p.parse_args()
 trees=json.loads((ROOT/'cells.json').read_bytes());assert len(trees)==72
 if args.jobs==1:rows=[facet(j,t) for j,t in enumerate(trees)]
 else:
  with ProcessPoolExecutor(max_workers=args.jobs,mp_context=get_context('spawn')) as ex:
   rows=list(ex.map(facet,range(72),trees))
 v=json.loads((ROOT/'host.json').read_bytes());S=v['denominator'];pts=v['vertices']
 assert len(pts)==2230
 a=F(sum(x*b-y*a for (x,y),(a,b) in zip(pts,pts[1:]+pts[:1])),2*S**2)
 assert a==F('.8440813573601329863574445') and all((x1-x0)*(y-y0)>=(y1-y0)*(x-x0) for (x0,y0),(x1,y1) in zip(pts,pts[1:]+pts[:1]) for x,y in pts)
 ctx.prec=160;getcontext().prec=70
 left=F('.844082046521218581802948589770767704354')-a
 length=sum(arb((x-u)**2+(y-v)**2).sqrt() for (x,y),(u,v) in zip(pts,pts[1:]+pts[:1]))/S
 rad=(arb(left.numerator)/left.denominator)*2/(length+(length*length+4*arb.pi()*arb(left.numerator)/left.denominator).sqrt())
 return dict(degree=11,physical_coordinates=9,material_faces=2218,host_faces=2230,translation=['0','.00000019'],vertices=sum(r['vertices'] for r in rows),cells=sum(r['closed_cells'] for r in rows),cuts=sum(r['exact_splits'] for r in rows),min_integer_margin=min(r['lowest_integer_margin'] for r in rows),poses=[sum(r['poses'][k] for r in rows) for k in range(12)],host_area=str(Decimal(a.numerator)/Decimal(a.denominator)),radius_to_budget=str(rad),facets=rows)
if __name__=='__main__':
 ans=run()
 if (ROOT/'receipt.json').exists():assert ans==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(ans,indent=2))

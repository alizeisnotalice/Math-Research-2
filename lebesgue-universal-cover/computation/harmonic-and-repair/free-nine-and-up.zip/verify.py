import json,hashlib,sys
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
def A(x):v=F(x);return arb(v.numerator)/v.denominator
def run():
 ctx.prec=160
 raw=(ROOT/'host.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'
 src=json.loads(raw);v=src['vertices'];S=src['denominator'];rows=json.loads((ROOT/'rows.json').read_bytes())
 pi=arb.pi();angles=[A(F(str(j))/180)*pi for j in (0,60,120,180,211.55,240,300,331.55,360)]
 zero=arb(0);one=arb(1);least=None;weak=None;easy=0;excess=arb(1);individual=[arb(1)]*3
 for i,(p,q,row) in enumerate(zip(v,v[1:]+v[:1],rows,strict=True)):
  nx,ny=q[1]-p[1],p[0]-q[0];D=arb(nx*nx+ny*ny).sqrt()
  rhs=A(F(nx*p[0]+ny*p[1]-190000*ny,S))/D-one/2;assert rhs>0
  t=arb.atan2(arb(ny),arb(nx))
  if t<0:t+=2*pi
  arcs=[(a,b) for a,b in zip(angles,angles[1:]) if not(t<a or t>b)]
  assert arcs
  a,b=arcs[0];L=b-a;x=t-a;sl=L.sin();sx=x.sin();sy=(L-x).sin()
  if (sx+sy)/sl/2-one/2<rhs:easy+=1;continue
  assert len(row)==8
  d=(sx+sy-abs(sx-sy))/2;assert d>0
  cs=[arb(z)/10**6 for z in row]
  norms=[(cs[k]**2+cs[k+1]**2).sqrt() for k in range(0,8,2)]
  curv=1+sum(n*n*val for n,val in zip((1,3,5,7),norms))
  def bound(subs):
   bound=arb(0)
   for lo,hi,form in ((zero,x,0),(x,L,1),(L,pi,2)):
    width=hi-lo
    if width.is_zero():continue
    n=max(1,int(float(width/pi)*subs)+1);dz=width/n
    cg=[(k*lo).sin_cos() for k in (1,3,5,7)];steps=[(k*dz).sin_cos() for k in (1,3,5,7)]
    # sin(L-z) can be recovered from cos z, sin z with constant coefficients.
    weight=zero
    for j in range(n+1):
     sn,co=cg[0]
     g=(sn*sy/(sl*d) if form==0 else ((sl*co-L.cos()*sn)*sx/(sl*d) if form==1 else zero))
     h=g-sum(cg[k][1]*cs[2*k]+cg[k][0]*cs[2*k+1] for k in range(4))
     weight+=abs(h)*(one/2 if j in (0,n) else one)
     if j<n:
      cg=[(u*b0+v*a0,v*b0-u*a0) for (u,v),(a0,b0) in zip(cg,steps)]
    bound+=weight*dz+width*curv*dz**2/12
   return bound
  scaled=rhs/d-bound(96)/2
  if not scaled>A('.003'):scaled=rhs/d-bound(384)/2
  assert scaled>A('.003'),(i,scaled)
  if least is None or scaled.lower()<least:least=scaled.lower();weak=i
  # One common budget on the sum of the 3,5,7-mode curvature amplitudes.
  z=(scaled/(pi/2*max(n.upper() for n in norms[1:]))).lower()
  excess=min(excess,z)
  for r,norm in enumerate(norms[1:]):
   if norm>0:individual[r]=min(individual[r],(scaled/(pi/2*norm)).lower())
 return dict(host_edges=len(v),gibbs_sigma='1.55',translation=['0','.00000019'],geometric_only_faces=easy,
        green_rows=len(v)-easy,first_unrestricted_frequency=9,lowest_scaled_margin=str(least),weakest_face=weak,
        admissible_sum_three_five_seven=str(excess),individual_intercepts=list(map(str,individual)))
if __name__=='__main__':
 result=run()
 if (ROOT/'receipt.json').exists():assert result==json.loads((ROOT/'receipt.json').read_bytes())
 print(json.dumps(result,indent=2))

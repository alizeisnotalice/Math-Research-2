"""Reconstruct every selected five-body proof at target 0.83741."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify_five_selected_083740_traces import audit

def main():
    if not __debug__:
        raise SystemExit("Run with Python assertions enabled.")
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("checkout","cert","work","cache"):
        parser.add_argument(name,type=Path)
    parser.add_argument("--expected",type=Path,default=HERE/"expected")
    parser.add_argument("--workers",type=int,default=1)
    args=parser.parse_args()
    assert 1<=args.workers<=12
    selection=json.loads((args.expected/"selection.json").read_bytes())
    rows=selection["leaves"]
    assert len(rows)==len({(p,i) for p,i,b in rows})
    def one(row):
        p,i,budget=row
        stem=f"part{p}-pos{i}"
        work=args.work/stem
        subprocess.run([sys.executable,"-I","-B",HERE/"replay_five_affine_selected.py",
                         args.checkout,args.cert,work,args.cache,"--target","0.83741",
                         "--part",str(p),"--positions",str(i),"--budget",str(budget)],check=True,
                         stdout=subprocess.DEVNULL)
        path=work/(stem+".json")
        expected=(args.expected/path.name).read_bytes()
        assert path.read_bytes()==expected
        record=json.loads(expected)
        trace=(work/(stem+".bin")).read_bytes()
        assert sha256(trace).hexdigest()==record["trace_sha256"]
        checked=audit(record["root"],trace)
        assert checked=={k:record["result"][k] for k in checked}
        return checked["vis"],sum(checked["closed"].values())
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        result=list(pool.map(one,rows))
    assert [sum(v) for v in zip(*result)]==[selection["visits"],selection["terminals"]]
    print(json.dumps(dict(complete=True,threshold="0.83741",leaves=len(rows),visits=selection["visits"],terminals=selection["terminals"])))

if __name__=="__main__":
    main()

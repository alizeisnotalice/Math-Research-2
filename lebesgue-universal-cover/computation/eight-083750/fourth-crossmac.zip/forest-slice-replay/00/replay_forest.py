"""Audit original domains, exact bisection restarts, input usage and optionally all native kernel calls."""
import argparse,gzip,importlib,json,sys
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
from pathlib import Path
from proof_forest import summarize

def rd(p):return json.loads(p.read_bytes())
def endpoints(bounds,steps):
    b=[v.copy() for v in bounds]
    for i in steps:
        k,side=divmod(i,2);l,h=b[k];assert 0<=k<11 and l<h and not (l+h)%2;b[k][1-side]=(l+h)//2
    return b
def audit(a,raw):
    plan=defaultdict(lambda:defaultdict(list));prefixes=defaultdict(lambda:defaultdict(list))
    def check(k,n,box,depth):
        assert n['box']==box
        r=n['r'];st=r['out'];assert r['leaf'][:2]==list(map(int,k.split('/'))) and st[3]==sum(r[v] for v in ['P128','oldQ','newQ','P15'])
        assert n['mode'] in ['control','affine','curve','slice'];target=Fraction(r['target']);assert Fraction('.83746')<target<=Fraction('.83750')
        cap=n['cap'] if not st[0] else 4194303
        plan[n['mode'],r['target'],cap,depth][k].append(n)
        if st[0]:
            assert not n['children'] and st[1]==2*(st[2]+st[3])-1 and r['front'] is None
            return target
        assert st[1]==cap==2*(st[2]+st[3])+len(n['children'])-1 and n['children']
        t=box['steps'];prefixes[n['mode'],r['target'],cap,depth][k].append(n)
        for j,c in enumerate(n['children']):
            x=c['box'];assert x['leaf']==k and x['label']==box['label']+'-restart-'+str(j) and x['steps'][:len(t)]==t and endpoints(box['bounds'],x['steps'][len(t):])==x['bounds']
        assert n['children'][0]['box']['bounds']==list(map(list,zip(r['front'][:11],r['front'][11:])))
        # A preorder traversal has the first unvisited descendant and exactly
        # the unvisited right sibling of each lower-child move leading to it.
        tail=n['children'][0]['box']['steps'][len(t):];expect=[t+tail]+[t+tail[:j]+[s+1] for j,s in reversed(list(enumerate(tail))) if not s%2]
        assert expect==[v['box']['steps'] for v in n['children']]
        return min(target,*(check(k,c,c['box'],depth+1) for c in n['children']))
    for k,e in raw.items():
        p=e['packet'];f=a.r2/e['r248_path'];assert sha256(f.read_bytes()).hexdigest()==e['r248_sha256'];par=json.loads(f.read_text().splitlines()[e['line']-1]);assert par==e['prefix'] and par['leaf']==p['leaf']==k and Fraction(par['goal'])==Fraction('.83750')
        src=a.r2/'refined/frontiers'/p['source'];assert sha256(src.read_bytes()).hexdigest()==p['digest'] and rd(src)==p['regions']
        st=par['stats'];assert st[0]==st[5]==0 and len(e['forest'])==len(p['regions'])==par['pending'] and st[1]==2*sum(st[2:6])+par['pending']-1
        for u,v in combinations(p['regions'],2):
            j=next(i for i,(m,n) in enumerate(zip(u['steps'],v['steps'])) if m!=n);assert u['steps'][j]//2==v['steps'][j]//2
        for b in p['regions']:assert endpoints(list(map(list,zip(par['lo'],par['hi'],strict=True))),b['steps'])==b['bounds']
        assert Fraction(e['target'])==min(check(k,n,b,0) for n,b in zip(e['forest'],p['regions'],strict=True))
    return plan,prefixes

def replay(a):
    main=Path(__file__).resolve().parent;raw=json.loads(gzip.decompress((main/'forest.json.gz').read_bytes()));assert summarize(raw)==rd(main/'scope.json');plan,pres=audit(a,raw)
    if not a.native and not a.trace:print('complete roots',len(raw));return
    a.scratch.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(a.kit.resolve()));from recover import trace
    for i,((mode,target,cap,depth),roots) in enumerate(plan.items()):
        if mode != 'slice':
            continue
        driver,lib,bank={'control':('run_nine',a.control,'nine-bank.json'),'affine':('run_shared',a.affine,'angular-bank.json'),'curve':('run_curved',a.curve,'angular-bank.json'),'slice':('run_slice',a.slice,'angular-bank.json')}[mode]
        valid=[dict(r['r'],leaf=[*r['r']['leaf'][:2],j]) for k,regions in roots.items() for j,r in enumerate(regions)]
        pp=a.scratch/f'packet-{i}.json';pp.write_text(json.dumps([dict(leaf=k,regions=[v['box'] for v in regions]) for k,regions in roots.items()]));out=a.scratch/f'out-{i}.jsonl'
        if a.native:
            if mode=='slice':sys.path.insert(0,str(a.slice_kit.resolve()))
            importlib.import_module(driver).run(argparse.Namespace(comp=a.comp,tree=a.tree,table=a.table,lib=lib,bank=a.banks/bank,output=out,caps=True,mesh=True,target=target,cap=cap,workers=a.workers,index=None,only=','.join(roots),resume=None,precontract=0,frontiers=pp))
            assert list(map(json.loads,out.read_text().splitlines()))==valid
        else:out.write_text(''.join(json.dumps(v)+'\n' for v in valid))
        if (mode,target,cap,depth) in pres:
            fr=a.scratch/f'recovered-{i}.json';trace(a.comp,a.tree,a.table,a.axial,pp,out,fr,cap)
            want=[dict(leaf=k,regions=[z['box'] for n in ns for z in n['children']]) for k,ns in pres[mode,target,cap,depth].items()]
            assert rd(fr)==want
    print('verified',len(raw))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('r2',type=Path)
    for n in ['kit','banks','comp','tree','table','control','affine','curve','axial','scratch','slice','slice-kit']:p.add_argument('--'+n,type=Path)
    p.add_argument('--native',action='store_true');p.add_argument('--trace',action='store_true');p.add_argument('--workers',type=int,default=4);assert __debug__;replay(p.parse_args())

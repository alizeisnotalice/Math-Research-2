"""Join higher-target successful nodes and authentic incomplete preorder prefixes into complete original-root trees."""
import argparse,gzip,hashlib,json,shutil,zipfile
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
def rd(p):return json.loads(p.read_bytes())
def lines(p):return list(map(json.loads,p.read_text().splitlines()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def boxkey(x):return x['leaf'],tuple(x['steps'])
def rect(r):return r['bounds'],r['steps']
class Ledger:
    def __init__(self):self.candidates=defaultdict(list);self.frontiers={};self.base={};self.known={}
    def stage(self,name,pack,output,mode,cap,anc=None,base=False):
        if not Path(output).exists():return
        p=rd(Path(pack));ks={v['leaf']:v for v in p}
        if base:self.base.update(ks)
        records=lines(Path(output));mapping={}
        for r in records:
            k='/'.join(map(str,r['leaf'][:2]));b=ks[k]['regions'][r['leaf'][2]];key=boxkey(b);z=dict(box=b,mode=mode,cap=cap,r=r);assert b['leaf']==k
            self.candidates[key].append(z);self.known[key]=b;mapping[b['label']]=z
        if anc:
            pos=rd(Path(anc).with_suffix('.map.json'));pending={v['leaf']:v['regions'] for v in rd(Path(anc))}
            for lab,e in pos.items():
                if lab not in mapping:continue
                z=mapping[lab];k=z['box']['leaf'];assert z['r']['out'][0]==0 and z['cap']==e['nodes']
                chunk=pending[k][e['location']:e['location']+e['count']];assert len(chunk)==e['count']
                self.frontiers[id(z)]=chunk
    def collect(self,r2):
        @lru_cache(None)
        def best(key):
            options=[]
            for z in self.candidates[key]:
                q=z['r'];t=Fraction(q['target']);children=[]
                if not q['out'][0]:
                    sub=self.frontiers.get(id(z))
                    if not sub:continue
                    proofs=[best(boxkey(b)) for b in sub]
                    if any(a is None for a in proofs):continue
                    children=[b for _,b in proofs];t=min(t,*(a for a,_ in proofs))
                n={**z,'children':children};used={v for v in ['P128','oldQ','newQ','P15'] if q[v]};more=sum(len(c['children']) for c in children)
                options.append((t,-len(used),-len(children)-more,n))
            if not options:return None
            winner=max(options,key=lambda v:v[:3]);return winner[0],winner[3]
        accepted={};gaps={}
        for k,p in self.base.items():
            picked=[best(boxkey(b)) for b in p['regions']]
            if any(x is None for x in picked):
                gaps[k]=[j for j,x in enumerate(picked) if x is None];continue
            f=r2/'refined'/(p['source'].split('/')[0]+'.jsonl');line,root=next((i,x) for i,x in enumerate(lines(f),1) if x['leaf']==k)
            accepted[k]=dict(packet=p,r248_path=f.relative_to(r2).as_posix(),r248_sha256=sha(f),line=line,prefix=root,target=str(min(t for t,_ in picked)),forest=[z for _,z in picked])
        return accepted,gaps

def current():
    z=Ledger()
    z.stage('base','free.json','free48.jsonl','control',16383,base=True)
    for front in ['hard-backlog.json','hard-B.json']:
        if Path(front).exists():z.stage('aff','redo48.json','shared48.jsonl','affine',131071,front)
    z.stage('side','side47.json','side47.jsonl','affine',131071,'next-S.json' if Path('next-S.json').exists() else None,True)
    z.stage('A','hard-backlog.json','curved47.jsonl','curve',131071,'next-A.json' if Path('next-A.json').exists() else None)
    z.stage('B','hard-B.json','hard-B47.jsonl','curve',131071,'next-B.json' if Path('next-B.json').exists() else None)
    z.stage('AS','next-AS.json','next-AS.jsonl','curve',262143,'next-deep.json' if Path('next-deep.json').exists() else None)
    z.stage('mac','mac-low.json','mac-low47.jsonl','curve',131071,'next-mac.json' if Path('next-mac.json').exists() else None,True)
    for oid, packet, output, child in [
        ('thirdAS','next-deep.json','third-AS47.jsonl','fourth-AS.json'),
        ('thirdB','needed-B.json','third-B47.jsonl','fourth-B-front.json'),
        ('thirdBL','needed-B.json','third-B47.jsonl','fourth-B-late.json')]:
        if Path(packet).exists():z.stage(oid,packet,output,'curve',524287,child if Path(child).exists() else None)
    for tag, cap in [('AS',262143),('B-front',524287),('B-late',524287)]:
        packet,output,child=f'fourth-{tag}.json',f'fourth-{tag}47.jsonl',f'fifth-{tag}.json'
        if Path(packet).exists(): z.stage('fourth'+tag,packet,output,'slice',cap,child if Path(child).exists() else None)
    if Path('new48.json').exists():z.stage('higher48','new48.json','new48.jsonl','curve',131071,'more48.json' if Path('more48.json').exists() else None)
    if Path('third.json').exists():z.stage('third','third.json','third47.jsonl','curve',524287,'fourth.json' if Path('fourth.json').exists() else None)
    if Path('fourth.json').exists():z.stage('fourth','fourth.json','fourth47.jsonl','curve',1048575)
    return z

def walk(children):
    for n in children:yield n;yield from walk(n['children'])
def summarize(data):
    summary={}
    for k,e in data.items():
        count={x:0 for x in ['P128','oldQ','newQ','P15']};count['P128']=e['prefix']['stats'][3];count['oldQ']=e['prefix']['stats'][4];nodes=pure=failed=geom=0
        for n in walk(e['forest']):
            r=n['r'];v=r['out'];geom+=1;nodes+=v[1];pure+=v[2];failed+=int(v[0]==0)
            for x in count:count[x]+=r[x]
        summary[k]=dict(target=e['target'],new_geometric_runs=geom,new_visits=nodes,new_five=pure,prefix_resumes=failed,point_terminals_with_r248_prefix=count)
    return summary
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('r2',type=Path);a.add_argument('out',type=Path);a.add_argument('--publish',action='store_true');args=a.parse_args();d,g=current().collect(args.r2);args.out.mkdir(exist_ok=True)
    (args.out/'forest.json.gz').write_bytes(gzip.compress(json.dumps(d,separators=(',',':')).encode(),compresslevel=9,mtime=0));(args.out/'gaps.json').write_text(json.dumps(g,indent=2)+'\n');ss=summarize(d);(args.out/'scope.json').write_text(json.dumps(ss,indent=2)+'\n')
    print('covered',len(d),'lower',sum(Fraction(v['target'])==Fraction('.83747') for v in d.values()),'gaps',len(g),'nodes',sum(v['new_visits'] for v in ss.values()),'44',sum(not (v['point_terminals_with_r248_prefix']['newQ'] or v['point_terminals_with_r248_prefix']['P15']) for v in ss.values()))
    if args.publish:
        for n in ['replay_forest.py','FOREST.md','proof_forest.py']:shutil.copyfile(n,args.out/n)
        f=args.out.with_suffix('.zip')
        with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for q in sorted(args.out.iterdir()):
                if q.name!='gaps.json':z.write(q,q.name)
        print(f,f.stat().st_size,sha(f))

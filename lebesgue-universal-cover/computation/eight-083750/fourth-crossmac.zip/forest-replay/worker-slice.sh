#!/bin/bash
set -u
i="$1"; B="$HOME/CodexRemoteMath/luc-forest4-audit-20261119"; P="$HOME/CodexRemoteMath/luc-083750-cpu181-20261119"; PY="$HOME/CodexRemoteMath/lebesgue-tomar-v3-20261118/terminal-083741-sol/pure-venv/bin/python"; TABLE="$HOME/CodexRemoteMath/lebesgue-tomar-v3-20261118/replay-p30-083735-sol/table/table64.npz"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 TMPDIR="$B/tmp"
echo "$$" > "$B/results-slice/pid-$i"
"$PY" -B "$B/shards-slice/$i/replay_forest.py" "$P/r2" --native --kit "$B/kit" --banks "$B/banks" --comp "$P/comp" --tree "$P/tree" --table "$TABLE" --control "$B/libs/nine.dylib" --affine "$B/libs/shared.dylib" --curve "$B/libs/curved.dylib" --slice "$B/libs/slice.dylib" --slice-kit "$B/slice" --axial "$B/libs/frontier-path.dylib" --scratch "$B/work-slice/$i" --workers 1 > "$B/results-slice/log-$i" 2>&1
printf '%s\n' "$?" > "$B/results-slice/exit-$i"

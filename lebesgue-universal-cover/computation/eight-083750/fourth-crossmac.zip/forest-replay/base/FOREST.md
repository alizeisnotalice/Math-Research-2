# Complete original leaves with authenticated preorder restarts

Each entry in scope.json is a complete R248 original leaf. The target is the weakest threshold among all actually used prefixes and complete terminal subtrees. The four point usage counts include the original higher prefix and every accepted new terminal, including successful terminals inside incomplete intermediate searches. The original P30 support rows transfer to P128 by the frozen 2,493-row dominance result. The physical old Q, distinct eleven points, P128 and P152's fifteen interior points have independent rotations, reflections and translations. A zero count allows that point input to be omitted on the stated original leaf.

A terminal run either covers its whole closed dyadic rectangle or supplies an exact higher-target prefix and the entire pending complement. The five-body tester chooses a deterministic axis from the closed rectangle itself; the visited DFS always visits the lower half first. Follow the exact axis sequence down to the recorded first unvisited rectangle. The remaining closed cover is precisely this rectangle and the right siblings of its lower-child moves along the path. Each such rectangle has its own verified child proof. The integer tree identity is enforced separately for every partial or complete run. Intermediate prefix targets can exceed a leaf's final reported target.

Use nine-replay-kit.zip, prepare its banks, and build the three checked geometry libraries and the deterministic frontier axis library. For runs marked slice, also supply the independently frozen reuleaux-slice-kit.zip using --slice-kit DIR --slice LIBRARY. It provides the defining-disk chord sections. Use R248's public-replay-r2-083750 directory. Run the first command for the exact structural check; --trace additionally recomputes every adaptive split axis leading to a first unvisited box; --native also evaluates every geometry call with the actual recorded threshold and compares every resulting tree statistic.

```sh
python -B replay_forest.py "$R248"
python -B replay_forest.py "$R248" --native --kit "$KIT" --banks "$BANKS" --comp "$COMP" --tree "$TREE" --table "$TABLE" --control "$CONTROL" --affine "$AFFINE" --curve "$CURVE" --axial "$AXIAL" --scratch "$SCRATCH"
```

# 第四森林 MacBook 原生交叉复演

基于原 forest-fourth.zip 的180原叶，按完整叶分成互不重叠12片。forest-replay/sharding-manifest.json 固定每片根及哈希；分片原始对象合并与原冻结forest.json.gz逐对象相等。每片保留原 replay_forest.py 的结构审计与实际几何对照，只跳过另一组几何模式：forest-replay 重跑 control/affine/curve，forest-slice-replay 重跑 slice。每次均使用真实阈值、原预算、原二分盒和点库；未完成前缀另重演DFS补集。每组脚本比较重跑每项几何统计与冻结回执。

非slice实跑123组6150项、83,797,452节点；slice实跑7组108项、1,632,966节点。两组各12/12退出0，所有冻结回执一致。各子目录remote保存Mac原生输出、回执、路径、日志和退出码。包含原森林、分片、经调整的模式选择脚本及冻结九体/切片源包；原R248、Tomar树、认证64表、computation及编译器为外部依赖。两种方法完成证明范围的解释仍须结合R248及原全局账本。

MacBook Apple M5 Pro、15逻辑CPU、macOS 27.3、Python 3.12.13、NumPy 2.5.4、python-flint 0.9.0、Apple clang 21.0.0。每片1 worker，峰值12片并行。几何库以 -O3 -std=c++17 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error -shared -fPIC 独立编译。Mac上执行 kit/prepare.py 独立重建银行，退出0；angular-bank.json SHA256 d0b523be89a12f97c0716575f66e2010832498a642e55af45f9c0263475ea999，nine-bank.json SHA256 bb47fd5efbb653dae5c25d4abb6f940b5d0b776b5d4bf8ef79d61b7b7bc3660d，与源银行完全一致。无随机数。

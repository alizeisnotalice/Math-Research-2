"""Reuse the five independently wall-verified rational hulls and append exactly four physical clouds."""
import argparse,gzip,hashlib,importlib.util,json,zipfile
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
from flint import arb,ctx
def main():
    p=argparse.ArgumentParser()
    for n in ['comp','nine','work','out']:p.add_argument(n,type=Path)
    a=p.parse_args();a.work.mkdir(exist_ok=True);a.out.mkdir(exist_ok=True)
    ctx.prec=192;folder=a.comp/'scaled-seven-46'
    with zipfile.ZipFile(folder/'rational.zip') as z:
        for name in ['rational-seven-83746.json.gz','report.json']:(a.work/name).write_bytes(z.read(name))
    script=folder/'check-finite.py'
    sp=importlib.util.spec_from_file_location('public_wall_verifier',script);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
    result=m.check(a.work);assert result==json.loads((folder/'check-finite.json').read_bytes())
    groups=json.loads(gzip.decompress((a.work/'rational-seven-83746.json.gz').read_bytes()))[:5]
    fs=min(F((10**21-2)**2,int(v['integer_diameter_squared'])) for v in result['shapes'])
    actual=[];pin={'p128':'d2be06dcd7aa9500e7fe48c5cd3a0c39b9d18358b8f5047c02faad4c32398620','physical-q':'7c656ce6491d23e0619e7aa78527fa5b17f6dc011b6f3034981413fa0cb80d93','distinct-q':'f13bf7699231a325d939de7892a9be8e661937e9c9fe146152a34b27b96df8a5','p15':'d5374aa909dc6bb8c4e6db3edc069c05f68795a1977a6adbd9807049798d5145'}
    for n,ct in zip(pin,[128,11,11,15],strict=True):
        buf=(a.nine/(n+'.json')).read_bytes();assert hashlib.sha256(buf).hexdigest()==pin[n];g=json.loads(buf);P=g['points'];d=g.get('denominator',g.get('point_denominator'))
        assert len(P)==len({tuple(z) for z in P})==ct
        sq=max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(P,2))
        assert sq<d*d;groups.append(dict(body=n,denominator=d,points=P));actual.append(dict(body=n,count=ct,diameter_squared=str(F(sq,d*d))))
    G=F(120696470013529293,2**57);bound=G*fs;assert fs<1 and bound>F('.83749999')
    buf=(json.dumps(groups,separators=(',',':'))+'\n').encode();(a.out/'rational-nine.json.gz').write_bytes(gzip.compress(buf,compresslevel=9,mtime=0))
    rec=dict(area_lower=str(bound),area_display=str(arb(bound.numerator)/bound.denominator),common_squared_inner_factor=str(fs),groups=[len(g['points']) for g in groups],points_total=sum(len(g['points']) for g in groups),r260_walls=result['walls'],finite_physical=actual,uncompressed_sha256=hashlib.sha256(buf).hexdigest())
    (a.out/'practical-audit.json').write_text(json.dumps(rec,indent=2)+'\n');print(rec['area_display'],rec['groups'],rec['points_total'])
if __name__=='__main__':
    assert __debug__;main()

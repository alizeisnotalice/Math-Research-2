"""Explicit rational vertices of a finite witness with at most 1,009,783,569 vertices per body."""
from fractions import Fraction as F
from math import factorial
from functools import lru_cache
from pathlib import Path
import argparse,json
from flint import arb,ctx
N=1009783569
M=10**48
S=1-F(1,10**40)
PI=F('3.141592653589793238462643383279502884197169399375105820974944592307816406')
SHAPES=(0,3,5,7,9)
G=F(120692146557887018,2**57)
def ar(x):
    x=F(x);return arb(x.numerator)/x.denominator
@lru_cache(200)
def sc(turn):
    # Choose a nearest quarter turn. Taylor then runs within pi/4.
    q=(4*turn+F(1,2)).__floor__();z=2*PI*(turn-F(q,4));zz=z*z
    s=term_s=z;c=term_c=F(1)
    for j in range(1,28):
        term_s=-term_s*zz/((2*j)*(2*j+1));s+=term_s
        term_c=-term_c*zz/((2*j-1)*(2*j));c+=term_c
    return [(s,c),(c,-s),(-s,-c),(-c,s)][q%4]
def count(n):
    return N if n==0 else n*((N-n)//n+1)
def point(n,k):
    assert n in SHAPES and 0<=k<count(n)
    if not n:
        y,x=sc(F(k,N));r=1/(2*sc(F(1,4*N))[1]);x*=r;y*=r
    else:
        m=(N-n)//n;j,h=divmod(k,m+1)
        cy,cx=sc(F(j,n));radius=1/(2*sc(F(1,4*n))[1])
        vy,vx=sc(F(j,n)+F(1,2)-F(1,4*n)+F(h,2*n*m))
        x=radius*cx+vx;y=radius*cy+vy
    return [(S*z*M).__floor__() for z in [x,y]]
def ideal_lower(n):
    x=arb.pi()/n
    return ar(G)*(x.cos()/(x/2).cos())**2

def first_odd(target):
    low,high=3,4
    while ideal_lower(2*high+1)<=ar(target):high*=2
    while low<high:
        m=(low+high)//2
        if ideal_lower(2*m+1)>ar(target):high=m
        else:
            assert ideal_lower(2*m+1)<ar(target)
            low=m+1
    n=2*low+1;assert ideal_lower(n-2)<ar(target)<ideal_lower(n);return n

def certify(goal,target):
    global N,G
    G=F((goal*2**57).__floor__()+1,2**57)
    assert G>goal
    ctx.prec=288
    N=first_odd(target)
    ctx.prec=288
    assert abs(arb.pi()-ar(PI))<ar(F(1,10**71)) and PI/4<1
    assert F(1,factorial(56))<F(1,10**70)
    # The uniform trig coordinate error is <1e-69 (Lipschitz angle + Taylor).
    # All denominators 2*cos(pi/(2n)) and the corresponding approximants are >1.
    # The vertex error in each coordinate is thus <1e-67 before final flooring.
    assert sc(F(0))[1]==1 and F(3,M)>2*(F(1,M)+F(1,10**67))
    delta=F(3,M);assert S+2*delta<1
    pi=arb.pi();ratio=ar(S)*(pi/N).cos()/(pi/(2*N)).cos()-ar(2*delta)
    alpha=F(int((ratio*10**47).lower().floor().unique_fmpz()),10**47)
    assert ratio>ar(alpha)
    for n in SHAPES[1:]:
        m=(N-n)//n
        assert count(n)<=N and 1-1/(2*(pi/(2*n)).cos())>ar(F(2,5))
        sag=F(22,7)**2/(8*n*n*m*m)
        assert S-(S*sag+delta)*F(5,2)>alpha
    assert G*alpha**2>target
    return dict(input_goal=str(goal),output_target=str(target),grid_lower=str(G),max_per_input=N,counts=[count(n) for n in SHAPES]+[128,11,11,15],coordinate_denominator=M,
        shrink=str(S),euclidean_rounding_error=str(delta),inner_factor=str(alpha),area_lower=str(G*alpha**2),
        area_display=str(ar(G*alpha**2)),enumerated=False)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--index',nargs=2,type=int,metavar=('ORDER','INDEX'));p.add_argument('--output',type=Path)
    p.add_argument('--goal',type=F,default=F('.83750'));p.add_argument('--target',type=F,default=F('.83750'))
    a=p.parse_args();d=certify(a.goal,a.target)
    if a.index:print(json.dumps(point(*a.index)))
    else:
        d['sample_points']={f'{n}/{k}':point(n,k) for n in SHAPES for k in [0,count(n)//3,count(n)-1]}
        if a.output:a.output.write_text(json.dumps(d,indent=2)+'\n')
        print(d['max_per_input'],d['area_display'])

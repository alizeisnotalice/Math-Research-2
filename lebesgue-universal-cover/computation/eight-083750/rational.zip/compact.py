"""Materialize and verify a small indexed physical nine-input witness above .83749."""
import argparse,gzip,hashlib,json,sys
from fractions import Fraction as F
from pathlib import Path
import indexed
def main():
    p=argparse.ArgumentParser();p.add_argument('full_coordinates',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
    raw=gzip.decompress(a.full_coordinates.read_bytes());assert hashlib.sha256(raw).hexdigest()=='84faf8cdfe72cd222b3cd47f182895e9282a481058e69dcdd927a6627624a5c4'
    proof=indexed.certify(F('.83750'),F('.83749'));clouds=[]
    for n in indexed.SHAPES:
        pts=list(dict.fromkeys(tuple(indexed.point(n,j)) for j in range(indexed.count(n))))
        sq=max((x-u)**2+(y-v)**2 for j,(x,y) in enumerate(pts) for u,v in pts[j+1:]);assert sq<=indexed.M**2
        clouds.append(dict(body=n,denominator=indexed.M,points=pts))
    clouds+=json.loads(raw)[5:]
    a.out.mkdir(exist_ok=True);out=(json.dumps(clouds,separators=(',',':'))+'\n').encode();(a.out/'compact-nine.json.gz').write_bytes(gzip.compress(out,compresslevel=9,mtime=0))
    proof.update(enumerated=True,counts=[len(c['points']) for c in clouds],total=sum(len(c['points']) for c in clouds),uncompressed_sha256=hashlib.sha256(out).hexdigest())
    (a.out/'compact-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['total'],proof['area_display'])
if __name__=='__main__':main()

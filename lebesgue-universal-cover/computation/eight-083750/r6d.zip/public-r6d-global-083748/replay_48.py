"""Reproduce the closed 0.83748 ledger from R6c and its new deltas."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import os
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
PINS={
    'r248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'r4plus':'3ecfcebdfcab476b2250927d07432c37c45f66a325feb35d193f51831a6f7b90',
    'r5':'e06073af59738402181b27aa8214c210a20100b651b35c35809d0d393bab0562',
    'r597':'eb2dec682d277c423e834a9f4443afc5cd11067fed5990dd80af4a9b02ced094',
    'r6':'ba9d943114016e17be388cdad2505b3f341f6ca0cdceba7008a423dff5fb0510',
    'r6c':'be111f57ac6af334e73476ce036e206499911224bde914e24ae8e56062ff22fd',
    'kit':'19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467',
    'slice':'e1c5b2c5bfdbb11fd0ad7b73360715a9893bebc9ea9b9199c56ace9f67c4ec8d',
}


def extract(path,pin,root):
    assert sha256(path.read_bytes()).hexdigest()==pin,path
    with ZipFile(path) as z:
        names=z.namelist()
        assert len(names)==len(set(names)) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(root)


def run(*args,env=None):
    subprocess.run(list(map(str,args)),check=True,env=env)


def main():
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','r4plus','r5','r597','r6','r6c','work'):
        p.add_argument(n,type=Path)
    p.add_argument('--native',action='store_true')
    p.add_argument('--table',type=Path)
    p.add_argument('--cache',type=Path)
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args()
    for n,v in vars(a).items():
        if isinstance(v,Path):
            setattr(a,n,v.resolve())
    w=a.work
    w.mkdir(parents=True,exist_ok=False)
    for n in ('r248','r4plus','r5','r597','r6','r6c'):
        extract(getattr(a,n),PINS[n],w/n)
    r248=w/'r248/public-replay-r2-083750'
    r4plus=w/'r4plus/public-r4-followup-083750/frozen/ledger.json'
    r5=w/'r5/public-r5-083750/frozen/wave-ledger.json'
    r597=w/'r597/public-r5-pool-first97/frozen/ledger.json'
    r6=w/'r6/public-r6-three-thresholds'
    r6c=w/'r6c/public-r6c-global-083747'
    extract_dir=w/'delta-sources'
    rows=w/'rows-63.json'
    ledger=w/'ledger-63.json'
    theorem=w/'theorem-48.json'
    run(sys.executable,'-B',HERE/'collect_overlay.py',a.comp,a.tree,r248,r6,r6c,HERE/'sources',extract_dir,rows)
    run(sys.executable,'-B',HERE/'integrate.py',r4plus,r5,r597,rows,r6/'frozen/rows-ordinary.json',ledger)
    run(sys.executable,'-I','-B',HERE/'raise_theorem.py',r6c/'frozen/global-theorem.json',
        r6c/'frozen/ledger-r6c-68.json',ledger,theorem,'--target','.83748')
    for path in (rows,ledger,theorem):
        assert path.read_bytes()==(HERE/'frozen'/path.name).read_bytes(),path.name
    if a.native:
        assert a.table and a.cache
        kit=w/'kit'
        skit=w/'slice-kit'
        banks=w/'banks'
        extract(r6/'frozen-sources/nine-replay-kit.zip',PINS['kit'],kit)
        extract(r6c/'sources/reuleaux-slice-kit.zip',PINS['slice'],skit)
        run(sys.executable,'-B',kit/'prepare.py',kit,banks)
        chosen={}
        for flag,source in [('control',kit/'nine.cpp'),('affine',kit/'shared.cpp'),
                            ('slice',skit/'slice.cpp'),('axial',kit/'frontier-path.cpp')]:
            lib=w/(flag+'.dylib')
            run('clang++','-O3','-std=c++17','-fsanitize=signed-integer-overflow',
                '-fsanitize-undefined-trap-on-error','-shared','-fPIC',f'-fmodules-cache-path={a.cache}',
                '-I',kit,'-I',a.comp/'three-leaf-083750',source,'-o',lib,env=dict(os.environ,TMPDIR=str(w)))
            chosen[flag]=lib
        run(sys.executable,'-B',extract_dir/'forest-fifth-seven/replay_forest.py',r248,'--native','--trace',
            '--kit',kit,'--banks',banks,'--comp',a.comp,'--tree',a.tree,'--table',a.table,
            '--control',chosen['control'],'--affine',chosen['affine'],'--slice',chosen['slice'],'--slice-kit',skit,
            '--axial',chosen['axial'],'--scratch',w/'native-seven','--workers',a.workers)
    print('reproduced the 0.83748 global theorem and its three-threshold ledger',flush=True)


if __name__=='__main__':
    main()

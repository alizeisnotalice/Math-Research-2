"""Rational open neighborhoods of point inputs whose convex hulls contain translates of the witnesses."""
import argparse,json,hashlib
from fractions import Fraction as F
from math import isqrt
from itertools import combinations
from pathlib import Path

def cross(p,q,r):return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
def hull(p):
    def chain(z):
        a=[]
        for v in z:
            while len(a)>=2 and cross(a[-2],a[-1],v)<=0:a.pop()
            a.append(v)
        return a[:-1]
    nodes=sorted(set(p));return chain(nodes)+chain(reversed(nodes))
def ceil_sqrt(v,S):
    z=isqrt(v.numerator*S*S//v.denominator)
    return F(z+int(z*z*v.denominator<S*S*v.numerator),S)
def key(n,kit,expected):
    raw=(kit/(n+'.json')).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
    a=json.loads(raw);p=[tuple(z) for z in a['points']];d=a.get('denominator',a.get('point_denominator'));h=hull(p);c=tuple(F(sum(v[i] for v in h),len(h)) for i in [0,1])
    # Lower inradius by checking distances from a rational center to every edge.
    dist=[];diam=F(max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(p,2)),d*d)
    for a,b in zip(h,h[1:]+h[:1],strict=True):
        w=cross(a,b,c);assert w>0;dist.append(w*w/(d*d*((b[0]-a[0])**2+(b[1]-a[1])**2)))
    r2=min(dist);S=10**20;r=F(isqrt((r2*S*S).__floor__()),S);du=ceil_sqrt(diam,S);assert 0<r and r*r<=r2 and du<1
    # A positive strict slack for the diameter and the support containment.
    s=(1-du)/(du+2*r);delta=F((r*s*10**19).__floor__(),10**19)
    assert delta>0 and r*s>=delta and du*(1+s)+2*delta<=1
    return dict(npoints=len(p),hull_vertices=len(h),center=[str(x/d) for x in c],inradius_lower=str(r),diameter_upper=str(du),
        expand_fraction=str(s),uniform_vertex_radius=str(delta),radius_decimal=f'{float(delta):.16g}',diameter_slack_lower=str(1-du*(1+s)-2*delta),support_slack_lower=str(s*r-delta))
def main():
    a=argparse.ArgumentParser();a.add_argument('kit',type=Path);a.add_argument('output',type=Path);a=a.parse_args()
    pin=json.loads((a.kit/'sources.json').read_bytes())['artifacts'];names=['p128','physical-q','distinct-q','p15']
    rows={n:key(n,a.kit,pin[n+'.json']) for n in names}
    proof={'eight_dimension':2*sum(rows[n]['npoints'] for n in names[:3]),'nine_dimension':2*sum(r['npoints'] for r in rows.values()),'rows':rows}
    a.output.write_text(json.dumps(proof,indent=2)+'\n');print(proof['eight_dimension'],proof['nine_dimension'],{n:v['radius_decimal'] for n,v in rows.items()})
if __name__=='__main__':
    assert __debug__;main()

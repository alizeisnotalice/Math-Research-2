"""Bind the two P152-free native proofs to their exact high-threshold R248 roots."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

from audit_wave import Roots,load

PIN='9e9b8f6d96de1597a191680f179cdf0736fe4bebb85091d9ed9ae26c2051e04b'


def main():
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','raw','previous','output','stage'):
        p.add_argument(n,type=Path)
    a=p.parse_args()
    assert sha256(a.raw.read_bytes()).hexdigest()==PIN
    with ZipFile(a.raw) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={'eight50.json','eight50.jsonl','eight-scope.json','replay_eight.py','reduced_bank.py'}
        z.extractall(a.stage)
    p=load(a.stage/'eight50.json')
    result=load(a.stage/'eight-scope.json')
    lines=[json.loads(s)for s in (a.stage/'eight50.jsonl').read_bytes().splitlines()]
    assert len(lines)==16 and {q['leaf']for q in p}==set(result)=={'1201/62085','1201/67150'}
    proof=Roots(a)
    out=load(a.previous)
    extra=[]
    per_leaf={}
    for p0 in p:
        leaf=p0['leaf']
        link,root=proof.verify(p0)
        r0=root['stats']
        assert root['goal']=='67/80' and r0[3]==0 and r0[4]>0
        nodes=[r for r in lines if r['leaf'][:2]==list(map(int,leaf.split('/')))]
        count=Counter(five=r0[2],oldQ=r0[4])
        sum_nodes=0
        info={}
        for i,row in enumerate(nodes):
            assert row['leaf'][2]==i and Fraction(row['target'])==Fraction(67,80)
            x=row['out']
            assert x[0]==1 and x[1]==2*(x[2]+x[3])-1 and row['front'] is None
            assert row['P15']==row['P128']==0 and x[3]==row['oldQ']+row['newQ']
            count.update(five=x[2],oldQ=row['oldQ'],newQ=row['newQ'])
            sum_nodes+=x[1]
        assert len(nodes)==len(p0['regions'])
        assert r0[1]+sum_nodes==2*sum(count.values())-1
        before=result[leaf]
        assert dict(parent_five=r0[2],parent_P30=0,parent_oldQ=r0[4],new_nodes=sum_nodes,P128=0,
                    oldQ=count['oldQ']-r0[4],newQ=count['newQ'],P15=0)==before
        inputs=['physical_old_Q11']+(['new_Q11']if count['newQ'] else [])
        link['parent_source']=link.pop('source')
        extra.append(dict(leaf=leaf,source=a.raw.name,target='67/80',parent_target='67/80',
            suffix_minimum_target='67/80',inputs=inputs,avg_transfer=False,archive_sha256=PIN,
            nodes=r0[1]+sum_nodes,native_nodes=sum_nodes,terminals=dict(count),
            **link))
        per_leaf[leaf]=nodes
    out['direct']['proved'].extend(extra)
    out['direct']['packages'][a.raw.name]=dict(sha256=PIN,counts={'67/80':2},
        leaves=[r['leaf']for r in extra])
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print('two authentic original roots audited without P152 and P128',flush=True)


if __name__=='__main__':
    main()

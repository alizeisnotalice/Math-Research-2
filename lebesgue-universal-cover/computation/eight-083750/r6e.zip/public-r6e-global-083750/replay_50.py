"""Verify the final three roots and the 0.83750 eight-input global theorem."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
PINS={
    'r248':'4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d',
    'r4plus':'3ecfcebdfcab476b2250927d07432c37c45f66a325feb35d193f51831a6f7b90',
    'r5':'e06073af59738402181b27aa8214c210a20100b651b35c35809d0d393bab0562',
    'r597':'eb2dec682d277c423e834a9f4443afc5cd11067fed5990dd80af4a9b02ced094',
    'r6':'ba9d943114016e17be388cdad2505b3f341f6ca0cdceba7008a423dff5fb0510',
    'r6c':'be111f57ac6af334e73476ce036e206499911224bde914e24ae8e56062ff22fd',
    'r6d':'c04b6e9474c13b1f8735421e49a7ccd6d59a30c0694c7f0b4dc930cfdd1692ee',
    'kit':'19a797eacda201a214c8e1f51a4eded6ae4afa78a7cde6711b37bd7bcdbbc467',
    'slice':'e1c5b2c5bfdbb11fd0ad7b73360715a9893bebc9ea9b9199c56ace9f67c4ec8d',
}


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def unpack(src,pin,out):
    assert sha(src)==pin,src
    with ZipFile(src) as z:
        names=z.namelist()
        assert len(names)==len(set(names)) and z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(out)


def run(*a,env=None):
    subprocess.run(list(map(str,a)),check=True,env=env)


def main():
    p=ArgumentParser(description=__doc__)
    for n in ('comp','tree','r248','r4plus','r5','r597','r6','r6c','r6d','work'):
        p.add_argument(n,type=Path)
    p.add_argument('--native-last-two',action='store_true')
    p.add_argument('--table',type=Path)
    p.add_argument('--cache',type=Path)
    a=p.parse_args()
    for n,v in vars(a).items():
        if isinstance(v,Path):
            setattr(a,n,v.resolve())
    w=a.work
    w.mkdir(parents=True,exist_ok=False)
    for n in ('r248','r4plus','r5','r597','r6','r6c','r6d'):
        unpack(getattr(a,n),PINS[n],w/n)
    r248=w/'r248/public-replay-r2-083750'
    r4plus=w/'r4plus/public-r4-followup-083750/frozen/ledger.json'
    r5=w/'r5/public-r5-083750/frozen/wave-ledger.json'
    r597=w/'r597/public-r5-pool-first97/frozen/ledger.json'
    r6=w/'r6/public-r6-three-thresholds'
    r6c=w/'r6c/public-r6c-global-083747'
    r6d=w/'r6d/public-r6d-global-083748'
    source=HERE/'sources'
    rows=w/'rows-64.json'
    extra=w/'rows-eight.json'
    ledger=w/'ledger-eight.json'
    eight=w/'eight-proof'
    run(sys.executable,'-B',HERE/'collect_overlay.py',a.comp,a.tree,r248,r6,r6d,source,w/'delta-mac',rows)
    run(sys.executable,'-B',HERE/'collect_eight.py',a.comp,a.tree,r248,source/'two-physical-eight-50.zip',rows,extra,eight)
    run(sys.executable,'-B',HERE/'integrate.py',r4plus,r5,r597,extra,r6/'frozen/rows-ordinary.json',ledger)
    for name,option in (('theorem-eight-50.json',['--eight']),('theorem-nine-50.json',[])):
        run(sys.executable,'-I','-B',HERE/'raise_theorem.py',r6c/'frozen/global-theorem.json',
            r6d/'frozen/ledger-63.json',ledger,w/name,'--target','.83750',*option)
    run(sys.executable,'-I','-B',HERE/'finite_gain.py',r6c,w/'finite-next-targets.json')
    frozen=HERE/'frozen'
    expected=json.loads((frozen/'derived-sha256.json').read_bytes())
    for name,digest in expected.items():
        assert sha(w/name)==digest,name
    for name in ('theorem-eight-50.json','theorem-nine-50.json','finite-next-targets.json'):
        assert (w/name).read_bytes()==(frozen/name).read_bytes(),name
    if a.native_last_two:
        assert a.table and a.cache
        kit=w/'kit'
        skit=w/'slice-kit'
        banks=w/'banks'
        unpack(r6/'frozen-sources/nine-replay-kit.zip',PINS['kit'],kit)
        unpack(r6c/'sources/reuleaux-slice-kit.zip',PINS['slice'],skit)
        run(sys.executable,'-B',kit/'prepare.py',kit,banks)
        lib=w/'slice.dylib'
        run('clang++','-O3','-std=c++17','-fsanitize=signed-integer-overflow',
            '-fsanitize-undefined-trap-on-error','-shared','-fPIC',f'-fmodules-cache-path={a.cache}',
            '-I',kit,'-I',a.comp/'three-leaf-083750',skit/'slice.cpp','-o',lib,env=dict(os.environ,TMPDIR=str(w)))
        run(sys.executable,'-I','-B',eight/'replay_eight.py',r248,kit,skit,banks/'angular-bank.json',
            a.comp,a.tree,a.table,lib,w/'native-two')
    print('reproduced the global 0.83750 eight-input theorem and actual per-leaf ledger',flush=True)


if __name__=='__main__':
    main()

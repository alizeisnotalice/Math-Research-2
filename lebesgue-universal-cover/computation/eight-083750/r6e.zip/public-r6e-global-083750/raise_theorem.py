"""Raise the global nine-input theorem by an authenticated closed-core overlay."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

MODEL='nine_P128_physical_Q_new_Q_P152'
PHYSICAL=['augmented_P128','physical_old_Q11','new_Q11','P152_interior15']
LEGACY={'original_P30','replacement_P30','reduced_P66'}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    p=ArgumentParser(description=__doc__)
    for name in ('anchor_theorem','previous_ledger','ledger','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--target',choices=('.83748','.83750'),required=True)
    p.add_argument('--eight',action='store_true')
    a=p.parse_args()
    earlier=read(a.anchor_theorem)
    prior=read(a.previous_ledger)
    ledger=read(a.ledger)
    assert earlier['strict'] and prior['strict'] and ledger['strict']
    assert ledger['original_leaves']==prior['original_leaves']==earlier['core_full_originals']==5442
    assert earlier['canonical_leaves']==6710314 and earlier['exterior_high_certified']==6704872
    assert earlier['finite_inputs']==PHYSICAL
    model='eight_P128_physical_Q_new_Q' if a.eight else MODEL
    physical=PHYSICAL[:-1] if a.eight else PHYSICAL
    assert prior['focal'][model]['inputs']==ledger['focal'][model]['inputs']==physical
    goal=Fraction(a.target)
    assert Fraction(earlier['threshold'])<goal<=Fraction(67,80)
    row=ledger['focal'][model]['thresholds'][a.target]
    assert row['closed']==5442 and row['remaining']==0 and row['unresolved']==[]
    needed=prior['focal'][model]['thresholds'][a.target]['unresolved']
    assert len(needed)>0 and len(needed)==len(set(needed))
    accepted={}
    for key in needed:
        options=[z for z in ledger['receipts_by_leaf'][key]
                 if Fraction(z['target'])>=goal and set(z['inputs'])<=set(physical)|LEGACY]
        assert options,key
        z=max(options,key=lambda r:Fraction(r['target']))
        accepted[key]={k:z[k]for k in ('target','source','parent_source','frontier',
            'frontier_sha256','archive_sha256','inputs')}
    dan=2**57
    num=(goal*dan).__floor__()+1
    g=Fraction(num,dan)
    assert g>goal
    result=dict(strict=True,threshold=str(goal),integer_area_numerator=num,
        integer_area_denominator=dan,lower_bound=str(g),strict_rational_margin=str(g-goal),
        true_disk_and_reuleaux_orders=[3,5,7,9],finite_inputs=physical,
        original_tree_manifest_sha256=earlier['original_tree_manifest_sha256'],
        canonical_leaves=6710314,exterior_high_certified=6704872,core_full_originals=5442,
        new_id_count=len(accepted),new_core_proofs=accepted,
        anchor_theorem_sha256=digest(a.anchor_theorem),prior_ledger_sha256=digest(a.previous_ledger),
        ledger_sha256=digest(a.ledger))
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(f'{len(physical)+5} independent inputs prove |hull| >= {num}/{dan} > {goal} on 6710314 canonical leaves',flush=True)


if __name__=='__main__':
    main()

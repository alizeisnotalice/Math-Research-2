"""Compute the ideal finite-arc discretization counts for the two higher theorems."""
from argparse import ArgumentParser
from fractions import Fraction
from importlib.util import module_from_spec,spec_from_file_location
import json
from pathlib import Path


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('r6c',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    spec=spec_from_file_location('mesh_proof',a.r6c/'finite_decision.py')
    m=module_from_spec(spec)
    spec.loader.exec_module(m)
    m.ctx.prec=256
    rows={}
    for top in ('.83748','.83750'):
        t=Fraction(top)
        m.G=Fraction((t*m.S).__floor__()+1,m.S)
        rows[top]={'exact_fraction':str(m.G),'strict_margin':str(m.G-t),'bounds':{}}
        for goal in dict.fromkeys(('.83747','.83748','.83749','.8374999',top)):
            if Fraction(goal)<=t:
                n,lo=m.count(Fraction(goal))
                rows[top]['bounds'][goal]={'first_odd_n':n,'area_lower_interval':lo}
    a.output.write_text(json.dumps(rows,indent=2)+'\n')


if __name__=='__main__':
    main()

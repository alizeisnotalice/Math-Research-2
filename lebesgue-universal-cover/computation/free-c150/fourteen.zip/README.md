# Fourteen rational points rule out planar enlargement of the fixed C150 at B

Let `C150` be the exact convex hull of the retained core and the 150 specified poses in the public R253 `computation/exact-151-repair/true-boundary.zip`. The archive SHA-256 is `d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf`.

Let (X) consist of the fourteen ordered integer pairs in `input.json`, divided by (10^{16}). The verifier checks by integer arithmetic that the diameter of (X) is strictly less than one.

**Every closed convex plane set (C) that contains the actual fixed `C150` and any rigid copy of (X) has area greater than `.844082125`.** The lower bound exceeds B by about (7.85\times10^{-8}). The enlarged host may extend arbitrarily in any direction.

### Area bounds at the retained exposed chords

The verifier reconstructs nine supporting chords of `C150`. These are the six old regular-hexagon faces, the two old oblique cap chords, and the old AH tangent between the indicated circular support branches. The face and cap endpoints are given by exact line intersections, orthogonal projections, or one circle-line intersection. Their membership in the retained core is checked against all additional cuts. The AH tangent is verified by directed support comparisons with all old inputs and the preclip outer core.

If a convex enlargement has area at most (T), then for every one of these old chords with outward unit normal (n), old support (h_0), and length (L), its support is at most (h_0+2(T-A_0)/L), where (A_0) is the frozen lower area bound for `C150`. Any point of larger support would make an exterior triangle above the chord and exceed the area ceiling.

### Closed angles and elimination of translation

These six face support bounds give necessary inequalities along each alternating triple of old hexagon normals. On the five closed middle angle cells, three specified points of (X) violate the balanced sum inequality at each cell endpoint. Positive sine interpolation gives the violation between the endpoints. The two endpoint intervals use the six designated rational pin points. The appropriate sum exceeds (3/2-3\cdot10^{-12}) at the endpoint and its inward derivative is greater than (.222) per radian. An allowed orientation must therefore lie in one of the small angular windows of the twelve rotation and reflection slots.

For each slot the certificate gives one old chord and two of the old hexagon faces whose outward normals balance positively. The two pin points and one designated tip of (X) are evaluated after the same rotation and reflection. The common translation cancels in that balanced sum. The proof bounds the combined sine and cosine terms throughout each angular window. All twelve balanced sums strictly exceed their area-derived support ceilings.

The released coordinates and incidence lists suffice for this proof. They were found using a 16-interval constant-curvature profile but the verifier does not reconstruct it.

Run with an existing Python supporting python-flint. `WORK` is a writable directory on the data volume.

```sh
sha256sum -c SHA256SUMS
PY -I -B verify.py R253.zip input.json OUT.json WORK
```

"""Independently verify rational points excluding every B-area enlargement of fixed C150."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from flint import arb, ctx, __version__ as flint_version

sys.path.insert(0,str(Path(__file__).resolve().parent))
from old_exposed_chords import SOURCE, exact_chords


def run(frozen,data):
    chords,base,B=exact_chords(frozen)
    from local_support import A, direction, dot, mul, pose
    from verify_geometry import cross,perp

    ctx.prec=192
    budget=F(data["excluded_area_ceiling"])
    assert base<B<budget
    wall={j:(q["height"]+A(2*(budget-base))/q["length"]).upper()
          for j,q in chords.items()}
    eta=max((wall[f"n{j}"]-A(".5")).upper() for j in range(6))

    coords=data["points"]
    scale=data["denominator"]
    assert type(scale) is int and scale>0
    assert len(coords)==data["count"] and len(set(map(tuple,coords)))==len(coords)
    assert all(len(q)==2 and all(type(x) is int for x in q) for q in coords)
    diameter=max(sum((a-b)**2 for a,b in zip(p,q)) for p,q in combinations(coords,2))
    assert diameter<scale**2
    P=[tuple(A(F(x,scale)) for x in q) for q in coords]

    pins={int(k):i for k,i in data["pin_indices"].items()}
    t0=F(data["endpoint_interval_degrees"])
    E=F(data["pin_support_error_upper"])
    D=F(data["derivative_lower"])
    assert 0<t0<30 and 0<E and D>0 and set(pins)==set(range(0,360,60))
    normal=[chords[f"n{j}"]["normal"] for j in range(6)]
    assert all(dot(normal[j],P[pins[60*j]])>A(F(1,2)-E) for j in range(6))
    eps=A(t0)*arb.pi()/180
    alpha=(3*(eta+A(E))/A(D)).upper()
    assert 0<alpha<eps
    ends=[]
    offsets=(60,180,300)
    for k,sgn in ((0,1),(60,-1)):
        aa=[((k+a)%360)//60 for a in offsets]
        val=sum(dot(normal[j],P[pins[60*j]]) for j in aa)
        grd=sgn*sum(dot(perp(normal[j]),P[pins[60*j]]) for j in aa)
        assert val>A(F(3,2)-3*E) and grd>0
        deriv=grd*eps.cos()-val*eps.sin()
        assert deriv>A(D)
        ends.append(dict(endpoint=k,inward_derivative_lower=str(deriv.lower()),
                         three_supports_lower=str(val.lower()),hex_normals=aa))

    cells=[]
    inp=[(F(a),F(b),list(ids)) for a,b,ids in data["middle_phase_cells"]]
    assert inp[0][0]==t0 and inp[-1][1]==60-t0
    assert all(a[1]==b[0] for a,b in zip(inp,inp[1:]))
    for a,b,ids in inp:
        assert 0<b-a<180 and len(ids)==3
        vals=[sum(dot(P[i],direction(A(t+off))) for i,off in zip(ids,offsets,strict=True))
              for t in (a,b)]
        gap=min(v.lower() for v in vals)-(A(F(3,2))+3*eta)
        assert gap>0
        cells.append(dict(a=str(a),b=str(b),point_ids=ids,strict_gap=str(gap.lower())))

    poses=[]
    checked=set()
    for row in data["posed_witnesses"]:
        k,s=row["pose"]
        assert (k,s) not in checked and k in range(0,360,60) and s in (1,-1)
        checked.add((k,s))
        j,m=row["hex_faces"]
        assert j!=m and 0<=j<6 and 0<=m<6
        ch=row["chord"]
        assert ch in ("AH","m3","m5")
        i=row["tip"]
        assert 0<=i<len(P)
        u=chords[ch]["normal"]
        a,b=normal[j],normal[m]
        determinant=cross(a,b)
        assert not determinant.contains(0)
        inv=mul(-1,u)
        alpha1,alpha2=cross(inv,b)/determinant,cross(a,inv)/determinant
        assert alpha1>0 and alpha2>0
        pj=pins[(s*60*j-k)%360]
        pm=pins[(s*60*m-k)%360]
        mapped=[pose(P[v],A(k),s) for v in (i,pj,pm)]
        vv=[u,a,b]
        weights=[arb(1),alpha1,alpha2]
        c=sum(l*dot(r,x) for l,r,x in zip(weights,vv,mapped,strict=True))
        d=s*sum(l*dot(r,perp(x)) for l,r,x in zip(weights,vv,mapped,strict=True))
        rhs=wall[ch]+alpha1*wall[f"n{j}"]+alpha2*wall[f"n{m}"]
        gap=(c-abs(c)*alpha**2/2-abs(d)*alpha-rhs).lower()
        assert gap>0,(k,s,str(gap))
        poses.append(dict(pose=[k,s],tip=i,chord=ch,hex_faces=[j,m],pin_indices=[pj,pm],
                          balancing_weights=[str(a) for a in weights],cost_upper=str(rhs.upper()),
                          cosine=str(c),sine=str(d),strict_gap=str(gap)))
    assert checked=={(k,s) for k in range(0,360,60) for s in (1,-1)}
    return dict(complete=True,point_count=len(P),denominator=scale,diameter_integer_sq=diameter,
                excluded_area_at_or_below=str(budget),strict_improvement_over_B=str(budget-B),
                old_area_lower=str(base),budget_support_enclosures={k:str(v) for k,v in wall.items()},
                hex_support_relaxation_upper=str(eta),phase_rad_upper=str(alpha),
                closed_middle_cells=cells,end_checks=ends,poses=poses,
                least_strict_gap=str(min(arb(z["strict_gap"]).lower() for z in poses)))


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    for a in ("archive","input","output","work"):
        ap.add_argument(a,type=Path)
    a=ap.parse_args()
    if not __debug__:
        raise SystemExit("Assertions must be enabled.")
    assert sha256(a.archive.read_bytes()).hexdigest()==SOURCE
    with TemporaryDirectory(dir=a.work.resolve()) as f:
        folder=Path(f)
        with ZipFile(a.archive) as z:
            z.extractall(folder)
        payload=a.input.read_bytes()
        result=run(folder,json.loads(payload))
    result.update(source_sha=SOURCE,input_sha=sha256(payload).hexdigest(),
                  verifier_sha=sha256(Path(__file__).read_bytes()).hexdigest(),
                  helper_sha=sha256(Path(__file__).with_name("old_exposed_chords.py").read_bytes()).hexdigest(),
                  python=sys.version.split()[0],flint=flint_version,precision=ctx.prec)
    a.output.write_text(json.dumps(result,indent=2)+"\n")
    print(result["point_count"],"points; strict area >",result["excluded_area_at_or_below"],
          "with strict gap",result["least_strict_gap"],flush=True)

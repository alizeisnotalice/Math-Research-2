"""Return exact exposed chords of the frozen C150 as Arb objects."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from flint import ctx


SOURCE="d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf"
HEX_AND_CAPS=(
    ("n0","0","C3","B1","C3 = n0 intersect m5; B1 = n0 intersect n1"),
    ("n1","60","B1","Q","B1 = n0 intersect n1; Q = projection of E3 onto n1"),
    ("n2","120","P","F1","P = projection of G onto n2; F1 = n2 intersect n3"),
    ("n3","180","F1","H","F1 = n2 intersect n3; H = projection of C3 onto n3"),
    ("n4","240","E3","D1","E3 = n4 intersect m3; D1 = n4 intersect n5"),
    ("n5","300","D1","G","D1 = n4 intersect n5; G = radius-one circle intersect n5"),
    ("m3","211.5497","I","E3","I = projection of b3 onto m3; E3 = n4 intersect m3"),
    ("m5","331.5497","K","C3","K = projection of f3 onto m5; C3 = n0 intersect m5"),
)


def exact_chords(frozen):
    """Return (records, old area lower, B); records carry exact Arb enclosures.

    frozen is an extracted R253 true-boundary archive root. Each record
    contains normal, height, endpoints, length and support-angle enclosures.
    """
    frozen=Path(frozen).resolve()
    comp=frozen/"computation"
    sys.path[:0]=[str(frozen),str(comp)]
    from local_support import A, core_vertices, direction, dot, load, sub
    from verify_geometry import bracketed_intersection, perp, possible, preclip_core, visible_parts

    ctx.prec=192
    bodies,_,core=load(comp)
    ctx.prec=192
    assert len(bodies)==150
    old = json.loads((comp/"single-repair"/"single-repair.json").read_bytes())
    assert old["strict_endpoints"]
    area,limit=F(old["base_area"][0]),F(old["B"])
    names,raw,_=core_vertices(core)
    points=dict(zip(names,raw,strict=True))
    vertices,_,_=visible_parts(core)
    present={row[0].label for row in vertices}
    records={}
    for name,angles,lab1,lab2,formula in HEX_AND_CAPS:
        assert all("core:"+lab in present for lab in (lab1,lab2))
        phi=A(angles)
        n=direction(phi)
        p,q=points[lab1],points[lab2]
        h=A(".5")
        margin=min((b-dot(u,v)).lower() for v in (p,q) for _,u,b in core["otherEH"])
        assert margin>0
        assert all((dot(v,n)-h).contains(0) for v in (p,q))
        length=dot(sub(q,p),perp(n))
        if length<0:
            length=-length
            p,q=q,p
            lab1,lab2=lab2,lab1
        assert length>0 and dot(sub(q,p),n).contains(0)
        records[name]=dict(normal=n,height=h,left=p,right=q,length=length,angle=phi,
                           features=[lab1,lab2],strict_competitor_margin=margin,
                           upstream=formula)
    active=[p for row in bodies for p in row]+preclip_core(core)
    names=("118:3:-1:1","0:0")
    marks=("112.3315","112.3325")
    left,right=A(marks[0]),A(marks[1])
    p,q=(next(z for z in possible(active,left,right) if z.label==name) for name in names)
    phi=bracketed_intersection(p,q,*map(F,marks))
    assert all(x.lo<phi<x.hi for x in (p,q))
    n=direction(phi)
    height=p.height(n)
    competitors=[(height-z.height(n)).lower() for z in possible(active,phi,phi) if z not in (p,q)]
    margin=min(competitors)
    assert margin>0
    v,w=p.point(n),q.point(n)
    length=dot(sub(w,v),perp(n))
    assert length>0 and dot(sub(w,v),n).contains(0)
    records["AH"]=dict(normal=n,height=height,left=v,right=w,length=length,angle=phi,
                       features=list(names),strict_competitor_margin=margin,
                       upstream="Public R253 circular support branches, bracketed common tangent")
    for row in records.values():
        row["B_cap_overrun_upper"]=(A(2*(limit-area))/row["length"]).upper()
    return records,area,limit


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    for key in ("archive","output","work"):
        ap.add_argument(key,type=Path)
    args=ap.parse_args()
    assert sha256(args.archive.read_bytes()).hexdigest()==SOURCE
    with TemporaryDirectory(dir=args.work.resolve()) as path:
        folder=Path(path)
        with ZipFile(args.archive) as z:
            z.extractall(folder)
        records,area,B=exact_chords(folder)
    def fmt(v):
        if isinstance(v,(list,tuple)):
            return [fmt(z) for z in v]
        return str(v)
    out=dict(source_sha256=SOURCE,old_area_lower=str(area),B=str(B),
             chords={label:{n:fmt(v) for n,v in row.items()} for label,row in records.items()})
    args.output.write_text(json.dumps(out,indent=2)+"\n")
    for k,v in records.items():
        print(k,v["features"],v["length"],"B overrun",v["B_cap_overrun_upper"],flush=True)

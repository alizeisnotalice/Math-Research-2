"""Upper-check the nine-chord functional at a fixed pose, and a stability implication."""
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from hashlib import sha256
import argparse
import sys
import json
from flint import arb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_free import SOURCE, IDS, BASE, ar, read_points, exact_chords

def check(archive,work):
    assert sha256(archive.read_bytes()).hexdigest()==SOURCE
    with TemporaryDirectory(dir=work) as tmp:
        with ZipFile(archive) as z:
            z.extractall(tmp)
        faces,base,B=exact_chords(Path(tmp))
    ctx.prec=192
    pts,_=read_points(BASE/'points.json')
    deg=F(119999532982881,10**12)
    tx,ty=F(-25827427469,25000000000000000),F(178937574259,10**17)
    si,co=(ar(deg)*arb.pi()/180).sin_cos()
    total=arb(0)
    for label in IDS:
        face=faces[label]
        nx,ny=face['normal']
        heights=[nx*(ar(tx)+x*co+y*si)+ny*(ar(ty)+x*si-y*co)-face['height'] for x,y in pts]
        total+=face['length']*max([arb(0)]+[h.upper() for h in heights])/2
    assert total < ar('.000000210290690')
    eta=F('0.0000000232')
    area_ceiling=F('.844082125')
    parallel_body_area=B+2*eta*B/(F(1,2)-eta)+F(22,7)*eta**2
    assert parallel_body_area < area_ceiling
    return dict(free_pose_degrees=str(deg),reflection=True,translation=[str(tx),str(ty)],
                nine_chord_functional_upper=str(total.upper()),approximation_distance=str(eta),
                max_area_of_parallel_body=str(parallel_body_area),fourteen_point_threshold=str(area_ceiling),
                stability_margin=str(area_ceiling-parallel_body_area),old_base_lower=str(base))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('archive','work','output'):p.add_argument(arg,type=Path)
    a=p.parse_args()
    out=check(a.archive,a.work)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(out['nine_chord_functional_upper'],out['stability_margin'])

"""Certify the half-disk inside the polygon of retained R253 core vertices."""
from pathlib import Path
from hashlib import sha256
import json,sys
from zipfile import ZipFile
from flint import arb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parent))

from exposed import exact_chords,SOURCE
r=Path(sys.argv[1]).resolve()
z=Path(sys.argv[2]);assert sha256(z.read_bytes()).hexdigest()==SOURCE
with ZipFile(z) as archive:
 assert archive.testzip() is None
 for name in archive.namelist():
  if not name.endswith('/'):
   assert (r/name).read_bytes()==archive.read(name),name
sys.path[:0]=[str(r),str(r/'computation')]
from local_support import load
from verify_geometry import visible_parts
ctx.prec=192
rows,_,_=exact_chords(r)
_,_,core=load(r/'computation');ctx.prec=192
v,_,_=visible_parts(core)
pts=[(a[0].label.removeprefix('core:'),a[0].center) for a in v]
assert [n for n,_ in pts]==['B1','Q','Y','Ta','Tp','P','F1','H','I','E3','D1','G','K','C3']
tangents={frozenset(x['features']):k for k,x in rows.items() if k!='AH'}
strict=[]; tangent=[]
for (n,p),(m,q) in zip(pts,pts[1:]+pts[:1]):
 d=[q[i]-p[i] for i in (0,1)]; cr=p[0]*q[1]-p[1]*q[0]
 assert cr>0
 residual=4*cr*cr-sum(x*x for x in d)
 if frozenset((n,m)) in tangents:
  name=tangents[frozenset((n,m))]; face=rows[name]
  assert (face['height']-arb(1)/2).contains(0)
  assert all((sum(x*y for x,y in zip(face['normal'],t))-arb(1)/2).contains(0) for t in (p,q))
  assert residual.contains(0)
  tangent.append([n,m,name])
 else:
  assert residual>0,(n,m,str(residual))
  strict.append([n,m,str(residual.lower())])
assert len(tangent)==8 and len(strict)==6
out={'r253_sha256':SOURCE,'precision_bits':ctx.prec,'vertex_count':len(pts),'tangent_edges':tangent,'strict_edges':strict,'conclusion':'the retained-core vertex polygon contains the origin-centered closed radius-1/2 disk; tangent identities follow from the exact line/intersection constructions in R253','proof_scope':'requires the retained core to be included in the fixed C150'}
Path(sys.argv[3]).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

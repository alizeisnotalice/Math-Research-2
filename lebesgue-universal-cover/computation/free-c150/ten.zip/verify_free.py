"""Directed certificate for free placements of ten rational points over the frozen C150."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import argparse
import json
from flint import arb, ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from exposed import exact_chords, SOURCE

BASE = Path(__file__).resolve().parent
IDS = ['n0','n1','n2','n3','n4','n5','m3','m5','AH']
Q = 10**15

def ar(q):
    q = F(q)
    return arb(q.numerator)/q.denominator

def det(a,b):
    return a[0]*b[1]-a[1]*b[0]

def exact_weights(rows, fixed):
    assert len(fixed)==7 and all(type(i) is int and i>=0 for i in fixed)
    ns = [r['normal'] for r in rows]
    ws = [ar(F(x,Q)) for x in fixed]
    v = [-sum(w*n[j] for w,n in zip(ws,ns[2:],strict=True)) for j in (0,1)]
    d = det(ns[0],ns[1])
    assert d>0
    weights = [det(v,ns[1])/d,det(ns[0],v)/d,*ws]
    assert all(w>0 and 2*w <r['length'] for w,r in zip(weights,rows,strict=True))
    return weights

def lower(rows, points, hand, left, right, fixed, selected):
    assert hand in (-1,1) and 0 <right-left<180
    assert len(selected)==len(rows) and all(type(i) is int and 0<=i<len(points) for i in selected)
    weights=exact_weights(rows,fixed)
    c,s,h = arb(0),arb(0),arb(0)
    for r,w,i in zip(rows,weights,selected,strict=True):
        x,y=points[i]
        y*=hand
        nx,ny=r['normal']
        c+=w*(x*nx+y*ny)
        s+=w*(-y*nx+x*ny)
        h+=w*r['height']
    assert h>0
    vals=[]
    for edge in (left,right):
        si,co=(ar(edge)*arb.pi()/180).sin_cos()
        vals.append((c*co+s*si-h).lower())
    return min(vals)

def read_points(path):
    data=json.loads(path.read_bytes())
    integers=data['points']
    d=data['denominator']
    assert d==10**16 and len(integers)==10 and len(set(map(tuple,integers)))==10
    assert all(type(x) is int for p in integers for x in p)
    diameter=max((x-u)**2+(y-v)**2 for x,y in integers for u,v in integers)
    assert diameter<d*d
    return [[ar(F(x,d)),ar(F(y,d))] for x,y in integers],F(diameter,d*d)

def verify(upstream, target, work, output):
    assert __debug__ and sha256(upstream.read_bytes()).hexdigest()==SOURCE
    data=json.loads(target.read_bytes())
    points,diameter=read_points(BASE/'points.json')
    assert data['q']==Q and data['faces']==IDS and data['point_sha256']==sha256((BASE/'points.json').read_bytes()).hexdigest()
    threshold=F(data['target'])
    with TemporaryDirectory(dir=work) as tmp:
        with ZipFile(upstream) as archive:
            archive.extractall(tmp)
        records,area,budget=exact_chords(Path(tmp))
        ctx.prec=192
        rows=[records[k] for k in IDS]
        assert area+threshold>budget
        summary={}
        for hand in (1,-1):
            end=F(0);worst=None; where=None; leaves=data['hands'][str(hand)]
            for block in leaves:
                left,right=map(F,block['degrees'])
                assert left==end<=right
                end=right
                margin=lower(rows,points,hand,left,right,block['weights'],block['point_ids'])
                assert margin>ar(threshold),(hand,left,right,str(margin))
                if worst is None or margin<worst:
                    worst,where=margin,[str(left),str(right)]
            assert end==360
            summary[str(hand)]={'intervals':len(leaves),'least_endpoint_lower':str(worst),'interval':where}
    result={'minimum_added_area_strictly_above':str(threshold),'base_area_lower':str(area),
            'total_area_strictly_above':str(area+threshold),'excess_over_B':str(area+threshold-budget),
            'point_diameter_squared':str(diameter),'hands':summary,'unrestricted_translation_rotation_reflection':True,
            'source':SOURCE,'ledger_sha256':sha256(target.read_bytes()).hexdigest(),'precision':ctx.prec}
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('r253','ledger','work','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    ctx.prec=192
    verify(args.r253,args.ledger,args.work,args.output)

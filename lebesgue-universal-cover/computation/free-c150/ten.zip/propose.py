"""Choose dual multipliers and angular intervals. Every retained proposal is verified with Arb."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
import argparse
import json
import numpy as np
from flint import ctx
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_free import BASE,IDS,Q,ar,lower,exact_chords,read_points,sha256

def vertices(ns,caps):
    verts=[]
    for i,j in combinations(range(len(caps)),2):
        b=ns[[i,j]].T
        if abs(np.linalg.det(b))<1e-10:continue
        rest=[t for t in range(len(caps)) if t not in (i,j)]
        for mask in product((0,1),repeat=len(rest)):
            x=np.zeros(len(caps))
            x[rest]=caps[rest]*mask
            y=np.linalg.solve(b,-x@ns)
            if np.all(y>=-1e-12) and np.all(y<=caps[[i,j]]+1e-12):
                x[[i,j]]=y
                verts.append(x)
    return np.unique(np.round(verts,14),axis=0)

def propose(frozen, output, target):
    records,_,_=exact_chords(frozen)
    ctx.prec=192
    material,_=read_points(BASE/'points.json')
    rows=[records[k] for k in IDS]
    ns=np.array([[float(x.mid()) for x in row['normal']] for row in rows])
    bs=np.array([float(row['height'].mid()) for row in rows])
    caps=np.array([float(row['length'].mid())/2 for row in rows])
    dual=vertices(ns,caps)
    # A strict feasible balanced vector allows rounding seven coordinates while solving the last two exactly.
    middle=np.array([.05]*6+[.001]*3)
    middle[:2]=np.linalg.solve(ns[:2].T,-middle[2:]@ns[2:])
    assert np.all(middle>0) and np.all(middle<caps)
    dual=(1-1e-9)*dual+1e-9*middle
    exact_points=np.array([[float(x.mid()) for x in p] for p in material])
    hands={}
    for hand in (1,-1):
        cloud=exact_points.copy();cloud[:,1]*=hand
        active=[(F(x),F(x+15)) for x in reversed(range(0,360,15))]
        leaves=[]
        while active:
            a,b=active.pop()
            mid=(a+b)/2
            angle=float(mid)*np.pi/180
            rot=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
            dots=ns@rot@cloud.T
            ids=np.argmax(dots,axis=1)
            heights=np.max(dots,axis=1)-bs
            w=dual[np.argmax(dual@heights)]
            fixed=[int(round(x*Q)) for x in w[2:]]
            selected=[int(x) for x in ids]
            if lower(rows,material,hand,a,b,fixed,selected)>ar(target):
                leaves.append({'degrees':[str(a),str(b)],'weights':fixed,'point_ids':selected})
            else:
                if b-a<F(1,2**34):raise ArithmeticError((hand,float(mid),float(np.max(dual@heights)),str(target)))
                active.extend([(mid,b),(a,mid)])
        hands[str(hand)]=leaves
        print(hand,len(leaves),'blocks',flush=True)
    out={'q':Q,'faces':IDS,'target':str(target),'hands':hands,
         'point_sha256':sha256((BASE/'points.json').read_bytes()).hexdigest()}
    output.write_text(json.dumps(out,separators=(',',':'))+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('frozen',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--target',default='0.000000210')
    a=p.parse_args();propose(a.frozen,a.output,F(a.target))

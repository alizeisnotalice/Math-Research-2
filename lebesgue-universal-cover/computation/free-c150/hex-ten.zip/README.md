# Ten rational points exclude fixed-host repair

Let (H_eta=\{x:n_j\cdot x\le 1/2+\eta\ (j=0,\ldots,5)\}), with (n_j\) at (60j^\circ). A separate increase of up to (\eta) on each original face is covered by this definition. Let `C150` be the fixed true convex hull of the retained core and 150 specified poses from the public R253 `computation/exact-151-repair/true-boundary.zip`. Its SHA-256 is `d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf`.

The ten ordered integer pairs in `input.json`, divided by (10^{16}), give an explicit planar set of diameter strictly less than one. The verifier checks all squared distances by exact integer arithmetic. The set was obtained from boundary material of the 24-interval width-one witness and then reduced, but the proof below uses the ten rational points directly.

Every convex (C) with (C150\subseteq C\subseteq H_\eta) that contains any rigid copy of the ten points satisfies these strict area bounds.

| Maximum face increase (\eta) | Area increment above fixed `C150` | Area of (C) |
| ---: | ---: | ---: |
| (0) | `3.5414e-7` | `.8440822126896314790` |
| `1.5e-7` | `1.995e-7` | `.8440820580496314790` |
| `1.6e-7` | `1.89e-7` | `.8440820475496314790` |

The largest certified face increase still gives over `1.0284e-9` above B. The old oblique caps only establish two exposed chords of the retained host. The candidate enlargement may cross them.

### Closed angular and area comparison

For the three preimage normals at angles (t+60^\circ,t+180^\circ,t+300^\circ), translation cancels because the normals sum to zero. Feasibility requires the three projected points to have sum at most (3/2+3\eta). On six closed middle intervals the same three designated points give a larger value at each interval endpoint. The positive sine interpolation formula transfers both endpoint inequalities to the whole interval. On the two endpoint intervals, the selected rational pin contacts give a sum above (3/2-3\cdot10^{-12}) at the sector endpoint and an inward derivative above (.119) per radian. Consequently any feasible orientation is within (3(\eta+10^{-12})/.119) radians of the corresponding rigid angular slot. Both hands are included.

For each slot, take a support-tip point and one of three actual exposed chords of the old host. Two neighboring hexagon normals with positive weights sum to the negative of that chord normal. Summing the two hexagon inequalities with the tip projection removes their common translation. The three evaluated points use the same angular error. The verifier bounds their combined sine and cosine terms over the whole angular window and then certifies the exterior triangle from its chord length and directed height lower bound. The six hexagon face increases need no common movement.

Run with an existing Python supporting python-flint. `WORK` is a writable directory on the data volume.

```sh
sha256sum -c SHA256SUMS
PY -I -B verify.py R253.zip input.json OUT.json WORK
```

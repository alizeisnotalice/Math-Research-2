"""Verify a finite rational witness using its points and the old true geometry."""
import argparse
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from flint import arb, ctx, __version__ as flint_version


SOURCE="d157cf032736c2b0144badb705c3995b4f380c05dd5e8dae18e7e8cd62a6b4bf"


def run(frozen, data):
    from local_support import A, core_vertices, direction, dot, load, mul, pose, sub
    from verify_geometry import bracketed_intersection, cross, perp, possible, preclip_core

    ctx.prec=192
    comp=frozen/"computation"
    old,_,core=load(comp)
    ctx.prec=192
    assert len(old)==150
    previous=json.loads((comp/"single-repair"/"single-repair.json").read_bytes())
    assert previous["strict_endpoints"]
    base=F(previous["base_area"][0])
    B=F(previous["B"])
    R=F(".58")
    grid=data["denominator"]
    integer=data["points"]
    assert isinstance(grid,int) and grid>0
    assert all(len(p)==2 and all(type(x) is int for x in p) for p in integer)
    assert len(set(map(tuple,integer)))==len(integer)==data["expected_count"] and len(integer)<=14
    dsq=max(sum((x-y)**2 for x,y in zip(a,b,strict=True)) for a,b in combinations(integer,2))
    rsq=max(sum(x*x for x in p) for p in integer)
    assert dsq<grid**2 and F(rsq,grid**2)<R**2
    pts=[tuple(A(F(x,grid)) for x in p) for p in integer]
    pins={int(k):v for k,v in data["hex_pin_indices"].items()}
    n=[direction(A(t)) for t in range(0,360,60)]
    shift=F(data["endpoint_radius_degrees"])
    delta=arb.pi()/180*A(shift)
    e=F(data["anchor_contact_loss"])
    d=F(data["endpoint_derivative_floor_per_rad"])
    arange=range(0,360,60)
    assert set(pins)==set(arange) and 0<shift<30
    for k in arange:
        assert dot(pts[pins[k]],n[k//60])>A(F(1,2)-e)
    end=[]
    offsets={60,180,300}
    for s,t in ((1,0),(-1,60)):
        degs=sorted((a+t)%360 for a in offsets)
        center=sum(dot(pts[pins[deg]],n[deg//60]) for deg in degs)
        slope=s*sum(dot(pts[pins[deg]],perp(n[deg//60])) for deg in degs)
        assert center>A(F(3,2)-3*e) and slope>0
        derivative=slope*delta.cos()-center*delta.sin()
        assert derivative>A(d)
        end.append(dict(at=t,point_ids=[pins[x] for x in degs],
                        lower_value=str(center.lower()),inward_lower=str(derivative.lower())))

    cells=[]
    intervals=[(F(a),F(b),ids) for a,b,ids in data["middle_intervals"]]
    assert intervals[0][0]==shift and intervals[-1][1]==60-shift
    assert all(l[1]==r[0] for l,r in zip(intervals,intervals[1:]))
    eta_max=F(data["largest_tested_H_relaxation"])
    assert A(3*(e+eta_max)/d)<delta
    for a,b,ids in intervals:
        assert 0<b-a<180 and len(ids)==3
        values=[sum(dot(pts[i],direction(A(t+angle))) for i,angle in zip(ids,sorted(offsets),strict=True))
                for t in (a,b)]
        low=min(v.lower() for v in values)
        assert low>A(F(3,2)+3*eta_max)
        cells.append(dict(lo=str(a),hi=str(b),witnesses=ids,endpoint_sum_lower=str(low)))

    labels,verts,_=core_vertices(core)
    chords={}
    for name,ends,t in (("m3",("I","E3"),"211.5497"),("m5",("K","C3"),"331.5497")):
        a,b=(verts[labels.index(z)] for z in ends)
        u=direction(A(t))
        assert all((dot(p,u)-A(".5")).contains(0) for p in (a,b))
        available=min((h-dot(v,p)).lower() for _,v,h in core["otherEH"] for p in (a,b))
        assert available>0
        L=dot(sub(b,a),sub(b,a)).sqrt()
        assert L>arb(".2535")
        chords[name]=(u,A(".5"),L,ends,str(available))
    label1,label2,a,b=data["AH_face"]
    assert all(l.split(":")[0].isdigit() for l in (label1,label2))
    old_parts=[p for ps in old for p in ps]+preclip_core(core)
    p,=[z for z in possible(old_parts,A(a),A(b)) if z.label==label1]
    q,=[z for z in possible(old_parts,A(a),A(b)) if z.label==label2]
    hit=bracketed_intersection(p,q,F(a),F(b))
    assert all(z.lo<hit<z.hi for z in (p,q))
    u=direction(hit)
    H=p.height(u)
    projected=[(H-z.height(u)).lower() for z in possible(old_parts,hit,hit) if z not in (p,q)]
    assert projected and min(projected)>0
    L=dot(sub(q.point(u),p.point(u)),perp(u))
    assert L>0
    chords["AH"]=(u,H,L,(label1,label2),str(min(projected)))

    def balance(u):
        opposite=mul(-1,u)
        for j,(v,w) in enumerate(zip(n,n[1:]+n[:1])):
            det=cross(v,w)
            a,b=cross(opposite,w)/det,cross(v,opposite)/det
            if a>0 and b>0:
                return (j,(j+1)%6),(a,b)
        raise ValueError("no nonnegative balancing pair")

    def rows_for(k,s):
        posed=[pose(p,A(k),s) for p in pts]
        result=[]
        for chord,(u,h,L,ends,clearance) in chords.items():
            js,weights=balance(u)
            idx=[pins[(s*(60*j)-k)%360] for j in js]
            a0=sum(w*dot(n[j],posed[i]) for j,w,i in zip(js,weights,idx,strict=True))
            b0=s*sum(w*dot(n[j],perp(posed[i])) for j,w,i in zip(js,weights,idx,strict=True))
            for i,p in enumerate(posed):
                a=a0+dot(u,p)
                b=b0+s*dot(u,perp(p))
                result.append((chord,i,a,b,sum(weights),js,weights,idx,h,L,ends,clearance))
        return result

    pre={(k,s):rows_for(k,s) for s in (1,-1) for k in arange}
    def directed_row(row,eta,amax):
        chord,i,co,si,coef,js,weights,idx,h,L,ends,clearance=row
        tip=co-abs(co)*amax**2/2-abs(si)*amax-coef*A(F(1,2)+eta)-h
        return (L*tip/2).lower(),tip

    def evaluate(eta):

        amax=A(3*(eta+e)/d)
        strict=[]
        for (k,s),rows in pre.items():
            ranked=[]
            for row in rows:
                chord,i,co,si,coef,js,weights,idx,h,L,ends,clearance=row
                area,tip=directed_row(row,eta,amax)
                ranked.append((area,row,tip))
            winner=max(ranked,key=lambda z:z[0])
            area,row,tip=winner
            chord,i,co,si,coef,js,weights,idx,h,L,ends,clearance=row
            strict.append((area,dict(pose=[k,s],chord=chord,tip_index=i,balancing_h_faces=list(js),
                balancing_coefficients=[str(w) for w in weights],balancing_pin_indices=idx,
                area_lower=str(area),nominal_cosine_coefficient=str(co),nominal_sine_coefficient=str(si),
                exterior_height_lower=str(tip.lower()),old_features=list(ends),old_competitor_margin=clearance)))
        return min(v for v,_ in strict),[x for _,x in strict],amax

    outcomes={}
    cover_sets=[]
    for title,case in data["strict_cases"].items():
        eta,gain=map(F,case)
        assert 0<=eta<=eta_max and base+gain>B
        strict,poses,rad=evaluate(eta)
        assert strict>A(gain),(title,str(strict),str(gain))
        for rows in pre.values():
            room={row[1] for row in rows if directed_row(row,eta,rad)[0]>A(gain)}
            assert room
            cover_sets.append(room)
        outcomes[title]=dict(six_face_support_relaxation=str(eta),phase_distance_rad_upper=str(rad.upper()),
            minimum_directed_area_increment=str(strict),strict_area_increment=str(gain),
            strict_total_lower=str(base+gain),strict_B_overshoot=str(base+gain-B),all_12_poses=poses)
    required=set(pins.values())|{i for _,_,ix in intervals for i in ix}
    choices=sorted(set(range(len(pts)))-required)
    minimum=None
    for k in range(len(choices)+1):
        for bits in combinations(choices,k):
            elems=required|set(bits)
            if all(elems & c for c in cover_sets):
                minimum=sorted(elems)
                break
        if minimum is not None:
            break
    assert minimum is not None

    # A finite one-dimensional survey is advisory only. The fixed cases above
    # carry the theorem; the survey is used to select a better exact eta.
    survey=[]
    for e0 in data.get("survey",[]):
        eps=F(e0)
        assert 0<=eps<=eta_max
        z,_,_=evaluate(eps)
        survey.append([str(eps),str(z),z>A(B-base)])
    return dict(complete=True,point_count=len(pts),denominator=grid,integer_diameter_sq=dsq,
                integer_radius_sq=rsq,closed_middle_angle_cells=cells,end_slopes=end,
                source_B=str(B),old_area_lower=str(base),conclusions=outcomes,survey=survey,
                subset_retaining_listed_middle_and_all_area_tests=minimum)


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    for arg in ("archive","input","output","work"):
        ap.add_argument(arg,type=Path)
    a=ap.parse_args()
    if not __debug__:
        raise SystemExit("Assertions must be enabled.")
    assert sha256(a.archive.read_bytes()).hexdigest()==SOURCE
    with TemporaryDirectory(dir=a.work.resolve()) as work:
        folder=Path(work)
        with ZipFile(a.archive) as z:
            z.extractall(folder)
        sys.path[:0]=[str(folder),str(folder/"computation")]
        payload=a.input.read_bytes()
        result=run(folder,json.loads(payload))
    result.update(source_sha=SOURCE,input_sha=sha256(payload).hexdigest(),
                  verifier_sha=sha256(Path(__file__).read_bytes()).hexdigest(),
                  python=sys.version.split()[0],flint=flint_version,precision=ctx.prec)
    a.output.write_text(json.dumps(result,indent=2)+"\n")
    print(result["point_count"],"points",len(result["closed_middle_angle_cells"]),"middle cells")
    for k,r in result["conclusions"].items():
        print(k,r["minimum_directed_area_increment"],r["strict_total_lower"],flush=True)
    print("survey",result["survey"],flush=True)

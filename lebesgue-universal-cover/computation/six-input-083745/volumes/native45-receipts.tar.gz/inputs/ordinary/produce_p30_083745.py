"""Produce complete .83745 weighted point-tree receipts for a selected disjoint list of original roots."""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import ctypes, hashlib, json, shutil, subprocess, sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from flint import ctx
p=argparse.ArgumentParser(description=__doc__)
for n in ("comp","tree","table32","table64","work","cache","selection"):
    p.add_argument(n,type=Path)
p.add_argument("--workers",type=int,default=2)
a=p.parse_args()
assert __debug__ and 1<=a.workers<=32
sys.path.insert(0,str(a.comp.resolve()))
from certify_tomar_six_high import FINE,Q,SourceTree,build_kernel,ceil,load_table
from replay_finite_point_083732 import PointProof
ctx.prec=160
def read(name):
    return json.loads((a.comp/name).read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def scaled(xs):
    values=[F(x)*FINE for x in xs]
    assert all(v.denominator==1 for v in values)
    return np.asarray([int(v) for v in values],dtype=np.int64)
base=read("tomar-six-high-input.json")
assert sha(Path(__file__).with_name("finite-point-lift-083744.json"))=="af6e8b2bff8b52408351fa1e0558358311b4ac64ff6fb0c0f3dc619243a54a6e"
last=json.loads(Path(__file__).with_name("finite-point-lift-083744.json").read_bytes())
for k,n in (("point_sha256","finite-point-leaf-input.json"),("bank_sha256","finite-point-global-input.json"),("base_sha256","tomar-six-high-input.json"),("weighted_sha256","tomar_six_083730_guard.cpp")):
    assert last[k]==sha(a.comp/n)
bank=PointProof(read("finite-point-leaf-input.json"),read("finite-point-global-input.json")["cells"],100000000008865717121)
prior={tuple(r[:2]):r for r in last["rows"]}
selection=json.loads(a.selection.read_bytes())
assert selection['target']=='.83745'
keys=[tuple(k) for k in selection['leaves']]
assert len(set(keys))==len(keys) and keys
tree=SourceTree(a.tree)
tables={n:load_table(getattr(a,f'table{n}'),tree,base['tables'][str(n)]) for n in (32,64)}
work=a.work.resolve(); cache=a.cache.resolve()
assert not work.exists()
build_kernel(work,base,cache)
lib=work/'weighted.so'
clang=shutil.which('clang++');assert clang
subprocess.run([clang,'-O3','-std=c++17','-ftrapv','-shared','-fPIC',f'-fmodules-cache-path={cache}','-I',str(work),str(a.comp/'tomar_six_083730_guard.cpp'),'-o',str(lib)],check=True)
guard=ctypes.CDLL(str(lib)).lift_guard_run
v=lambda t:np.ctypeslib.ndpointer(dtype=t,ndim=1,flags='C_CONTIGUOUS')
i64,i32=v(np.int64),v(np.int32)
guard.argtypes=[i64,i64,i64,i32,i32,ctypes.c_int64,ctypes.c_int,ctypes.c_int,i64,i64,i64,i64,i64,ctypes.c_int,ctypes.c_int,ctypes.c_int,i64]
guard.restype=ctypes.c_int
root=scaled(tree.root['hi']);goal=ceil(2*Q*Q*F('.83745'))
assert goal==120689264254125501
def run(k,box):
    lo,hi=(scaled(v) for v in zip(*box,strict=True))
    support=bank.presolve(box);old=prior.get(k)
    budget=65535 if old is None else min(1073741823,(1<<max(16,(4*old[3]).bit_length()))-1)
    if old and old[3]>=2000000:budget=max(budget,268435455)
    stages=[]
    if not old or (old[2]==32 and old[3]<=65000):
        stages.append((32,min(budget,1048575)))
    stages.append((64,max(262143,budget)))
    for cap in (16777215,268435455,1073741823):
        if stages[-1][1]<cap:stages.append((64,cap))
    for level,calls in stages:
        out=np.zeros(30,dtype=np.int64)
        assert guard(lo,hi,root,*tables[level],goal,135,calls,*support,len(support[1]),len(support[3])-1,2,out)==0
        if out[0] or out[5]!=1:break
    d=dict(part=k[0],pos=k[1],level=level,cap=calls,depth=135,stat=out.tolist())
    fn=work/f'part{k[0]:04}-{k[1]}.json'
    temp=fn.with_suffix('.working');temp.write_text(json.dumps(d)+'\n');temp.replace(fn)
    return d
keys.sort(key=lambda k:-(prior[k][3] if k in prior else 0))
with ThreadPoolExecutor(a.workers) as ex:
    futures=[ex.submit(run,k,tree.leaf(*k)) for k in keys]
    output=[z.result() for z in as_completed(futures)]
failed=[(d['part'],d['pos']) for d in output if not d['stat'][0]]
print(json.dumps(dict(trees=len(output),failed=failed,selection_sha256=sha(a.selection))),flush=True)

"""Run disjoint original five-body proof trees to the shallow-cap threshold."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from verify_five_selected_083740_traces import audit

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for x in ('up','cert','work','cache','selection'):ap.add_argument(x,type=Path)
    ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
    rows=json.loads(args.selection.read_bytes())['leaves']
    assert len(rows)==len(set(map(tuple,rows)))
    args.work.mkdir(exist_ok=True,parents=True)
    def one(pair):
        p,i=pair;stem=f'part{p}-pos{i}'
        for t,b in [('0.837455',32768),('0.837453',65536),('0.83745',131072)]:
            d=args.work/t/stem
            out=d/(stem+'.json')
            if not out.exists():
                r=subprocess.run([sys.executable,'-B',HERE/'replay_five_affine_selected.py',args.up,args.cert,d,args.cache,
                  '--target',t,'--part',str(p),'--positions',str(i),'--budget',str(b)],capture_output=True,text=True)
                if r.returncode not in (0,2):raise RuntimeError(r.stderr)
            doc=json.loads(out.read_bytes());assert doc['part']==p and doc['pos']==i and doc['threshold']==t and doc['budget']==b
            if doc['result']['remaining']:
                print('unresolved',p,i,t,len(doc['result']['remaining']),flush=True);continue
            trace=out.with_suffix('.bin').read_bytes()
            assert sha256(trace).hexdigest()==doc['trace_sha256']
            geometric=audit(doc['root'],trace);assert all(geometric[k]==doc['result'][k]for k in geometric)
            print('closed',p,i,t,geometric['vis'],flush=True)
            return [p,i,t,b,geometric['vis'],sum(geometric['closed'].values())]
        return [p,i,None]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:result=list(pool.map(one,rows))
    assert all(len(x)==6 for x in result)
    (args.work/'result.json').write_text(json.dumps(dict(complete=True,leaves=result,selection_sha256=sha256(args.selection.read_bytes()).hexdigest()),separators=(',',':'))+'\n')
if __name__=='__main__':main()

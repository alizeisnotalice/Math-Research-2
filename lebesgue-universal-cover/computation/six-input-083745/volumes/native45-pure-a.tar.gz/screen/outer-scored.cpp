// Integer fan-area lower bound on whole 11D dyadic boxes; coordinates in units 2^-28.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <vector>
using L=std::int64_t;using W=__int128_t;
constexpr L Q=L(1)<<28,Fine=L(1)<<44,ratio=Fine/Q;
struct P { L x,y,a,b; int body; };
struct V { L x,y; };
using Box=std::array<L,11>;
W det(L ax,L ay,L bx,L by){return W(ax)*by-W(ay)*bx;}
W area(const P& a,const P& b,const P& c){return det(b.x-a.x,b.y-a.y,c.x-a.x,c.y-a.y);}
// A piecewise linear upper bound on Euclidean length. For t=min/max,
// convexity of sqrt(1+t*t) permits the two secants through the rational
// upper ordinates 1024/1024, 1145/1024, 1449/1024 at t=0,1/2,1.
L norm(L x,L y){
    x=std::abs(x);y=std::abs(y);
    L hi=std::max(x,y),lo=std::min(x,y);
    if(2*lo<=hi)return hi+(242*lo+1023)/1024;
    return (841*hi+608*lo+1023)/1024;
}
W up(W a,L b){
    if(a<0 || b<=0) std::abort();
    return (a+b-1)/b;
}
L small(W a){
    if(a<0 || a>std::numeric_limits<L>::max()) std::abort();
    return static_cast<L>(a);
}
W ab(W x){return x<0?-x:x;}
bool clip_domain(Box& lo,Box& hi,const L* r){
    constexpr L cut=3684498829194;
    hi[2]=std::min(hi[2],cut); if(lo[2]>hi[2])return false;
    auto minabs=[](L a,L b){return a>0?a:(b<0?-b:0);};
    auto ceilroot=[](W q){
        L x=L(__builtin_sqrtl((long double)q));
        while(W(x)*x<q)++x;
        while(x && W(x-1)*(x-1)>=q)--x;
        return x;
    };
    for(int j=0;j<4;++j){
        int k=3*j;L x=minabs(lo[k],hi[k]), y=minabs(lo[k+1],hi[k+1]);
        W rr=W(r[j])*r[j]; if(W(x)*x+W(y)*y>rr)return false;
        L X=ceilroot(rr-W(y)*y),Y=ceilroot(rr-W(x)*x);
        lo[k]=std::max(lo[k],-X);hi[k]=std::min(hi[k],X);
        lo[k+1]=std::max(lo[k+1],-Y);hi[k+1]=std::min(hi[k+1],Y);
    }
    return true;
}
struct Tester {
    const std::int32_t* table;const std::int32_t* sizes;const L* original_hi;
    L goal,current_floor=0;int total=0;int split_axis=0;
    std::vector<P> pts,hull,conv,merged;
    std::array<std::vector<int>,5*1025> sort_order;
    static bool before(const P& a,const P& b){
        return a.x!=b.x?a.x<b.x:(a.y!=b.y?a.y<b.y:a.body<b.body);
    }
    L hx[5]{},hy[5]{},theta[5]{},tn[5]{},tw[5]{},rad[5]{};
    Tester(const std::int32_t* p,const std::int32_t* n,const L* h,L t):table(p),sizes(n),original_hi(h),goal(t){
        for(int k=0;k<5;++k){if(sizes[k]<3 || sizes[k]>1024)std::abort();total+=sizes[k];}
        if(total>4096)std::abort();
        for(int k=0;k<11;++k)if(h[k]<=-Fine || h[k]>=Fine)std::abort();
        for(int k: {2,5,8})if(h[k]<=0)std::abort();
        merged.resize(total);pts.reserve(total);hull.reserve(2*total);conv.reserve(total);
    }
    L perturb(const P& p) const {int b=p.body;return small(W(tw[b])+up(W(norm(p.a,p.b))*theta[b],Q));}
    bool oriented(const P& a,const P& b) const {
        W z=det(a.x,a.y,b.x,b.y);
        if(z<=0)return false;
        if(a.body==b.body){
            int i=a.body;L chord=norm(a.a-b.a,a.b-b.b);
            return z>W(tw[i])*chord+W(tn[i])*up(W(chord)*theta[i],Q);
        }
        L da=perturb(a),db=perturb(b);
        return z>W(norm(a.x,a.y))*db+W(norm(b.x,b.y))*da+W(da)*db;
    }
    W curved_gain(const P& a,const P& b) const {
        if(a.body!=b.body)return 0;
        W cross=det(a.x,a.y,b.x,b.y);
        if(!a.body){
            // The actual radius-one-half disk contains the entire radial sector.
            // For 0<alpha<pi, alpha >= sin(alpha)+sin(alpha)^3/6.
            // Both fractional radii are below 1/2, so 4*cross/Q^2 <= sin(alpha).
            W sine=(4*cross)/Q;
            return (sine*sine*sine)/(24*Q);
        }
        L vx=b.a-a.a,vy=b.b-a.b,chord=norm(vx,vy);
        if(!chord)return 0;
        W length_sq=W(vx)*vx+W(vy)*vy;
        // The floating guess is used only to recover the exact integer square root.
        L length=static_cast<L>(std::sqrt(static_cast<double>(length_sq)));
        while(W(length)*length>length_sq)--length;
        while(W(length+1)*(length+1)<=length_sq)++length;
        int body=a.body;
        W zlo=cross-W(tw[body])*chord-W(tn[body])*up(W(chord)*theta[body],Q);
        if(zlo<=0)return 0;
        L radius_limit=std::max(norm(a.x,a.y)+perturb(a),norm(b.x,b.y)+perturb(b));
        if(!radius_limit)return 0;
        // The strip x_s-u*J(b-a), 0<=u<=kappa*s*(1-s), lies in all defining unit disks.
        // The determinant bound places the whole parabolic strip in this angular wedge.
        W kappa=std::min<W>(length/2,(zlo*Q)/(W(radius_limit)*chord));
        return (kappa*length_sq)/(3*Q);
    }
    int check(const Box& lo,const Box& hi){
        L negative_angle[5]{},positive_angle[5]{},cos_width[5]{};
        pts.clear();hull.clear();conv.clear();int off=0,ends[5]{};
        for(int b=0;b<5;++b){
            int idx=b?3*(b-1):0;L tx=0,ty=0;int row=0;
            if(b){
                tx=(lo[idx]+hi[idx])/(2*ratio);ty=(lo[idx+1]+hi[idx+1])/(2*ratio);
                // Nominal translations are rounded to Q. Enlarge their half-widths exactly.
                hx[b]=small(up(std::max(std::abs(lo[idx]-tx*ratio),std::abs(hi[idx]-tx*ratio)),ratio));
                hy[b]=small(up(std::max(std::abs(lo[idx+1]-ty*ratio),std::abs(hi[idx+1]-ty*ratio)),ratio));
                if(b>1){
                    int k=idx-1;L num=(lo[k]+hi[k])*512;
                    row=int((num+original_hi[k]/2)/original_hi[k]);if(row<0 || row>1024)return -1;
                    L anchor=L(row)*original_hi[k];
                    theta[b]=small(up(std::max(std::abs(1024*lo[k]-anchor),std::abs(1024*hi[k]-anchor)),1024*ratio));
                    negative_angle[b]=small(up(std::max<L>(0,anchor-1024*lo[k]),1024*ratio));
                    positive_angle[b]=small(up(std::max<L>(0,1024*hi[k]-anchor),1024*ratio));
                    cos_width[b]=small(up(W(theta[b])*theta[b],2*Q));
                }
            }
            tw[b]=norm(hx[b],hy[b]);tn[b]=norm(tx,ty);
            const auto* block=table+2*(row*total+off);
            auto& order=sort_order[1025*b+row];
            if(order.empty()){
                order.resize(sizes[b]);
                for(int j=0;j<sizes[b];++j) order[j]=j;
                std::sort(order.begin(),order.end(),[&](int u,int v){
                    auto x=block+2*u,y=block+2*v;
                    return x[0]!=y[0]?x[0]<y[0]:x[1]<y[1];
                });
            }
            for(int j:order){
                L a=block[2*j],c=block[2*j+1];
                L x=tx+a,y=ty+c;
                // Keeping any subset of valid witnesses is always sound. This
                // threshold removes points well inside the fixed disk-sample hull.
                constexpr L cut=Q*499/1000;
                if(b && x*x+y*y<cut*cut)continue;
                pts.push_back(P{x,y,a,c,b});
            }
            off+=sizes[b];ends[b]=int(pts.size());
        }
        // Translation preserves each body's lexicographic ordering. Merge its
        // nominal angle row with the other four exactly sorted lists.
        merged.resize(pts.size());auto a=pts.begin(),b=merged.begin();
        int j1=ends[0],j2=ends[1],j3=ends[2],j4=ends[3],npts=ends[4];
        std::merge(a,a+j1,a+j1,a+j2,b,before);
        std::merge(a+j2,a+j3,a+j3,a+j4,b+j2,before);
        
        std::merge(b,b+j2,b+j2,b+j4,a,before);
        std::merge(a,a+j4,a+j4,a+npts,b,before);
        pts.swap(merged);
        pts.erase(std::unique(pts.begin(),pts.end(),[](const P&a,const P&b){return a.x==b.x && a.y==b.y;}),pts.end());
        for(auto& p:pts){
            while(hull.size()>=2 && area(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();
            hull.push_back(p);
        }
        auto lower=hull.size();
        for(int i=int(pts.size())-2;i>=0;--i){
            while(hull.size()>lower && area(hull[hull.size()-2],hull.back(),pts[i])<=0)hull.pop_back();
            hull.push_back(pts[i]);
        }
        hull.pop_back();conv=hull;
        // Delete a candidate only when it is cheaper than the other endpoint of the bad edge.
        bool done=false;
        while(!done && conv.size()>=3){
            done=true;auto n=conv.size();
            for(unsigned i=0;i<n;++i){
                unsigned j=(i+1)%n;
                if(oriented(conv[i],conv[j]))continue;
                auto pre=(i+n-1)%n,post=(j+1)%n;
                auto loss_i=area(conv[pre],conv[i],conv[j]),loss_j=area(conv[i],conv[j],conv[post]);
                conv.erase(conv.begin()+(loss_i<loss_j?i:j));done=false;break;
            }
        }
        if(conv.size()<3){
            split_axis=0;for(int k=1;k<11;++k)if(hi[k]-lo[k]>hi[split_axis]-lo[split_axis])split_axis=k;
            return 0;
        }
        W rotation_remainder=0,twice=0,error=0,grot[5]{},cosine[5]{},cross_sum[5][5]{},dot_sum[5][5]{};
        V g[5]{},mixed[5][5]{};
        int translation_pairs[5][5]{};
        auto n=conv.size();
        for(unsigned i=0;i<n;++i){
            const P& a=conv[i];const P& next=conv[(i+1)%n];const P& prev=conv[(i+n-1)%n];
            L dx=next.x-prev.x,dy=next.y-prev.y;
            twice+=det(a.x,a.y,next.x,next.y);
            twice+=curved_gain(a,next);
            int k=a.body;g[k].x+=dx;g[k].y+=dy;
            grot[k]-=W(a.a)*dx+W(a.b)*dy;
            int j=next.body;
            cosine[k]+=det(a.a,a.b,dx,dy);
            mixed[k][j].x+=next.a;mixed[k][j].y+=next.b;
            mixed[j][k].x-=a.a;mixed[j][k].y-=a.b;
            W cross=det(a.a,a.b,next.a,next.b);
            if(k==j){
                // det((R-I)a,(R-I)b)=2(1-cos(alpha))*det(a,b).
                cosine[k]-=2*cross;
            }else{
                int first=std::min(k,j),last=std::max(k,j),sign=k<j?1:-1;
                translation_pairs[first][last]+=sign;
                cross_sum[first][last]+=cross;
                dot_sum[first][last]+=sign*(W(a.a)*next.a+W(a.b)*next.b);
            }
        }
        for(int k=1;k<5;++k){
            error+=W(std::abs(g[k].y))*hx[k]+W(std::abs(g[k].x))*hy[k];
            error+=up(ab(grot[k])*theta[k],Q);
            if(cosine[k]>0)error+=up(up(cosine[k]*theta[k],Q)*theta[k],2*Q);
            for(int j=2;j<5;++j){
                auto v=mixed[k][j];
                if(!v.x&&!v.y)continue;
                W cs=W(hx[k])*std::abs(v.y)+W(hy[k])*std::abs(v.x);
                W sn=W(hx[k])*std::abs(v.x)+W(hy[k])*std::abs(v.y);
                W component=up(sn*theta[j],Q)+up(up(cs*theta[j],Q)*theta[j],2*Q);
                W radial=W(tw[k])*up(W(norm(v.x,v.y))*theta[j],Q);
                error+=std::min(component,radial);
            }
            for(int j=k+1;j<5;++j){
                W box_det=W(hx[k])*hy[j]+W(hy[k])*hx[j];
                error+=std::abs(translation_pairs[k][j])*std::min(box_det,W(tw[k])*tw[j]);
                if(!theta[k] || !theta[j])continue;
                W cross=up(up(ab(cross_sum[k][j])*theta[k],Q)*theta[j],Q);
                W dot=up(up(ab(dot_sum[k][j])*theta[k],Q)*theta[j],Q);
                error+=cross+std::min(dot,up(dot*(theta[k]+theta[j]),2*Q));
                rotation_remainder+=cross+std::min(dot,up(dot*(theta[k]+theta[j]),2*Q));
            }
        }
        // The signed area of this fixed material chain is separately affine
        // in all eight translations when all three angles are fixed.
        // Prove monotonicity first, then only enumerate undecided endpoints.
        if (twice-error < goal) {
            L tx[5]{},ty[5]{};
            int type[8]{},body[8]{},free_count=0;
            for (int k=1;k<=4;++k) {
                W variation_x=0,variation_y=0;
                for (int j=1;j<=4;++j) {
                    int pair=std::abs(translation_pairs[std::min(k,j)][std::max(k,j)]);
                    variation_x+=W(pair)*hy[j];
                    variation_y+=W(pair)*hx[j];
                }
                for (int j=2;j<=4;++j) {
                    const V v=mixed[k][j];
                    variation_x+=up(W(std::abs(v.x))*theta[j]+W(std::abs(v.y))*cos_width[j],Q);
                    variation_y+=up(W(std::abs(v.y))*theta[j]+W(std::abs(v.x))*cos_width[j],Q);
                }
                auto fix=[&](int which,L gradient,W variation,L width,L& out) {
                    if (gradient>=variation) out=-width;
                    else if (gradient<=-variation) out=width;
                    else {type[free_count]=which;body[free_count++]=k;}
                };
                fix(0,g[k].y,variation_x,hx[k],tx[k]);
                fix(1,-g[k].x,variation_y,hy[k],ty[k]);
            }
            if (free_count <= 4) {
                W worst=0;
                for (int bits=0;bits<(1<<free_count);++bits) {
                    for(int i=0;i<free_count;++i) {
                        const int k=body[i],sign=((bits>>i)&1)?1:-1;
                        if(type[i])ty[k]=sign*hy[k];else tx[k]=sign*hx[k];
                    }
                    W value=twice-rotation_remainder,sg[5]{},cs[5]{};
                    for(int j=2;j<=4;++j) {sg[j]=grot[j];cs[j]=cosine[j];}
                    for(int k=1;k<=4;++k) {
                        value+=W(tx[k])*g[k].y-W(ty[k])*g[k].x;
                        for(int j=k+1;j<=4;++j)
                            value+=W(translation_pairs[k][j])*det(tx[k],ty[k],tx[j],ty[j]);
                        for(int j=2;j<=4;++j) {
                            auto v=mixed[k][j];
                            sg[j]+=W(tx[k])*v.x+W(ty[k])*v.y;
                            cs[j]+=det(tx[k],ty[k],v.x,v.y);
                        }
                    }
                    for(int j=2;j<=4;++j) {
                        value-=up(ab(sg[j])*(sg[j]>=0?negative_angle[j]:positive_angle[j]),Q);
                        if(cs[j]>0)value-=up(cs[j]*cos_width[j],Q);
                    }
                    if(bits==0 || value<worst)worst=value;
                }
                if(worst>twice-error)error=twice-worst;
            }
        }

        W best=-1;
        for(int b=1;b<5;++b){
            int k=3*(b-1);
            auto consider=[&](int index,W score){if(score>best){split_axis=index;best=score;}};
            consider(k,W(hx[b])*(std::abs(g[b].y)+Q/30));
            consider(k+1,W(hy[b])*(std::abs(g[b].x)+Q/30));
            if(b>1)consider(k-1,W(theta[b])*(ab(grot[b])/Q+Q/100));
        }
        if(twice-error<goal)return 0;
        current_floor=small(twice-error);return 1;
    }
};
struct ScoredTraversal {
    Tester& fan;
    const std::uint8_t* codes;
    const std::vector<int>& stop;
    const std::vector<int>& prefix;
    const L* radii;
    const L* radial_floors;
    std::uint8_t* pending;
    L* raw_scores;
    L* local_scores;
    L* sums;
    int max_depth, max_nodes;

    bool probe(Box& lo, Box& hi, int depth, L& nodes, L& minimum) {
        if(nodes==max_nodes)return false;
        ++nodes;
        sums[1]=std::max(sums[1],L(depth));
        if(fan.check(lo,hi)==1){
            minimum=std::min(minimum,fan.current_floor);
            ++sums[4];
            return true;
        }
        if(depth==max_depth)return false;
        const int k=fan.split_axis;
        const L l=lo[k],h=hi[k];
        if(h-l<2)return false;
        const L m=l+(h-l)/2;
        hi[k]=m;
        const bool left=probe(lo,hi,depth+1,nodes,minimum);
        hi[k]=h;
        if(!left)return false;
        lo[k]=m;
        const bool right=probe(lo,hi,depth+1,nodes,minimum);
        lo[k]=l;
        return right;
    }

    L exterior_cap(const Box& lo,const Box& hi,const Box& clipped_lo,const Box& clipped_hi) const{
        L ans=std::numeric_limits<L>::max();
        for(int b=0;b<4;++b){
            const int j=3*b;
            for(int k=j;k<=j+1;++k)
                if(lo[k]!=clipped_lo[k] || hi[k]!=clipped_hi[k])
                    ans=std::min(ans,radial_floors[b]);
        }
        return ans;
    }

    void emit(int at,int count,L inside,L exterior){
        const L full=inside?std::min(inside,exterior):exterior;
        if(full<fan.goal)std::abort();
        for(int j=at;j<stop[at];++j){
            if(prefix[j+1]>prefix[j]){
                raw_scores[j]=full;
                local_scores[j]=inside;
            }
        }
        sums[2]+=count;
    }

    bool walk(int at,Box& lo,Box& hi,int depth){
        if(depth>256)return false;
        const int count=prefix[stop[at]]-prefix[at];
        if(!count)return true;
        const int code=codes[at];
        if(code>=253 || (count>=64 && depth%5==0)){
            Box l=lo,h=hi;
            if(!clip_domain(l,h,radii)){
                emit(at,count,0,*std::min_element(radial_floors,radial_floors+4));
                return true;
            }
            if(code>=253){
                L minimum=std::numeric_limits<L>::max();
                L visits=0;
                const bool ok=probe(l,h,0,visits,minimum);
                sums[0]+=visits;
                if(ok)emit(at,1,minimum,exterior_cap(lo,hi,l,h));
                else{
                    pending[at]=1;
                    ++sums[3];
                    sums[5]+=(visits==max_nodes);
                }
                return true;
            }
            ++sums[0];
            if(fan.check(l,h)==1){
                emit(at,count,fan.current_floor,exterior_cap(lo,hi,l,h));
                return true;
            }
        }

        const L a=lo[code], b=hi[code];
        if((a+b)%2)return false;
        const L m=(a+b)/2;
        hi[code]=m;
        if(!walk(at+1,lo,hi,depth+1))return false;
        hi[code]=b;lo[code]=m;
        if(!walk(stop[at+1],lo,hi,depth+1))return false;
        lo[code]=a;
        return true;
    }
};

extern "C" int adaptive_scored_trim(
    const std::uint8_t* codes,int n,const L* lower,const L* upper,const L* orig_hi,
    const std::uint8_t* active,std::uint8_t* pending,L* stats,const std::int32_t* table,
    const std::int32_t* sizes,L goal,int depth,int calls,const L* radii,
    const L* radial_floors,L* raw_scores,L* local_scores){
    if(n<1 || n>(1<<29) || depth<0 || depth>64 || calls<1 || calls>(1<<24))return 1;
    for(int j=0;j<11;++j)
        if(lower[j]<=-Fine || upper[j]>=Fine || lower[j]>=upper[j])return 2;
    for(int j=0;j<4;++j)
        if(radii[j]<=0 || radial_floors[j]<goal)return 3;
    std::vector<int> prefix(n+1),stop(n);
    for(int j=0;j<n;++j){
        if(active[j]>1 || (active[j] && codes[j]<253))return 4;
        prefix[j+1]=prefix[j]+active[j];
    }
    for(int j=n-1;j>=0;--j){
        if(codes[j]>=253)stop[j]=j+1;
        else{
            if(codes[j]>=11 || j+1>=n || stop[j+1]>=n)return 5;
            stop[j]=stop[stop[j+1]];
        }
    }
    if(stop[0]!=n)return 6;
    Tester fan(table,sizes,orig_hi,goal);
    ScoredTraversal r{fan,codes,stop,prefix,radii,radial_floors,pending,raw_scores,local_scores,
                      stats,depth,calls};
    Box lo,hi;
    std::copy(lower,lower+11,lo.begin()); std::copy(upper,upper+11,hi.begin());
    return r.walk(0,lo,hi,0)?0:7;
}

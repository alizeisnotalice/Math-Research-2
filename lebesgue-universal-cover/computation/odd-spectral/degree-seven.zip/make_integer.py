from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from flint import arb,ctx
Q=10**9
def rnd(x):
 x=x*Q
 m,e=map(int,x.mid().man_exp())
 if e<0:k=(m+(1<<(-e-1)))>>(-e)
 else:k=m<<e
 assert abs(x-k)<1
 return k
def build():
 ctx.prec=160;pi=arb.pi();T=pi/3
 src=Path(__file__).with_name('host.json').read_bytes()
 assert sha256(src).hexdigest()=='a69bf398326ebc2e785cdecbcf0386853dd8b0622eea5d6ac06e09b259f0194f'
 dat=json.loads(src);den=dat['denominator'];P=dat['vertices']
 H=[(a.cos()/arb(3).sqrt(),a.sin()/arb(3).sqrt()) for a in [T*(arb(1)/2+j) for j in range(6)]]
 rows=[[] for _ in range(12)];ub=[]
 for v,u in zip(P,P[1:]+P[:1]):
  X,Y=u[1]-v[1],v[0]-u[0];L=arb(X*X+Y*Y).sqrt();b=arb(X*v[0]+Y*v[1])/den
  assert b/L>arb(1)/2
  if all(X*x+Y*y<b for x,y in H):continue
  th=arb.atan2(arb(Y),arb(X));st=abs((3*th).sin());assert st>0
  w=(b/L-arb(1)/2)/st
  cap=rnd(w)-8;assert cap+7<Q*w and 0<=cap<Q
  ub.append(cap)
  for k in range(12):
   z=(1 if k<6 else -1)*(th-(k%6)*T);sn=(3*z).sin();s=1 if sn>0 else -1;assert s*sn>0
   f=[arb(s)/8,-s*(2*z).sin()/12,s*(2*z).cos()/12,-s*(4*z).sin()/24,s*(4*z).cos()/24]
   rows[k].append([rnd(x) for x in f])
 M=[]
 for j in range(72):
  t=2*pi*j/72
  M.append([rnd(z) for z in [(3*t).sin(),(5*t).cos(),(5*t).sin(),(7*t).cos(),(7*t).sin()]])
 assert len(ub)==1179
 return np.array(rows,dtype=np.int64),np.array(ub,dtype=np.int64),M

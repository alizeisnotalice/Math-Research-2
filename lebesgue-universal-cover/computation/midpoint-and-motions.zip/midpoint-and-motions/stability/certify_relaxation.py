"""Bound five-body stability under outer hexagon slack and one-sided loss of W."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from importlib.util import source_from_cache
from itertools import product
from pathlib import Path
import json
import sys

from flint import arb,ctx,__version__ as flint_version
from geometry import S,area,host,hull,source,tran,true_samples

IDS=(20,14,28,6,33)
NEAR=((0,1),(4,-1))
B=F('.844082046521218581802948589770767704354')


def A(q):
    q=F(q)
    return arb(q.numerator)/q.denominator


def add(p,q):return p[0]+q[0],p[1]+q[1]
def sub(p,q):return p[0]-q[0],p[1]-q[1]
def mul(c,p):return c*p[0],c*p[1]
def dot(p,q):return p[0]*q[0]+p[1]*q[1]
def cross(p,q):return p[0]*q[1]-p[1]*q[0]
def perp(p):return -p[1],p[0]
def norm(p):return dot(p,p).sqrt()


def direction(t):
    s,c=(A(t)*arb.pi()/180).sin_cos()
    return c,s


def integer_poly_lower(wfile):
    inner,outer=host(wfile)
    src=json.loads(wfile.read_bytes())
    old=src['full_W_outer_vertices'];scale=src['full_W_polygon_scale']
    disk=F(49,100)
    rows=[]
    for p,q in zip(old,old[1:]+old[:1],strict=True):
        dx,dy=sub(q,p);n=(dy,-dx);b=dot(n,p)
        assert all(dot(n,z)<=b for z in old)
        rows.append((n,b))
    normals=[direction(x) for x in (*range(0,360,60),'211.54','331.54')]
    for p in inner:
        assert all(scale*dot(n,p)<=S*b for n,b in rows)
        coords=tuple(A(F(x,S)) for x in p)
        assert all(dot(n,coords)<A('1/2') for n in normals)
    for p,q in zip(inner,inner[1:]+inner[:1],strict=True):
        width=cross(p,q)
        assert width>0 and width**2>(S*disk)**2*dot(sub(p,q),sub(p,q))
    return inner,outer


def material_points(pts):
    """Exact verified rounding inside conv(W_in union the true points)."""
    shrink=A(F(4,S)); radius=shrink*A('.49')
    output=[]
    for p in pts:
        mid=tuple(round(float(x*S)) for x in p)
        assert all(abs(x*S-k)<A('.52') for x,k in zip(p,mid,strict=True))
        grid=tuple(round(F(k)*(1-F(4,S))) for k in mid)
        error=sub(tuple(A(F(x,S)) for x in grid),mul(1-shrink,p))
        assert dot(error,error)<radius**2
        output.append(grid)
    return hull(output)


def selected_shape(ns,v):
    e=[ns['sub'](v[i],v[j]) for i,j in ns['orders']]
    normals=[tuple(map(ns['A'],p)) for p in ns['d']['n']]
    assert len(normals)==6
    zero=arb(0);one=arb(1)
    k=[]
    for j,n in enumerate(normals):
        hn=ns['supports'](v,e,(one,zero),n)
        assert hn.contains(A('1/2'))
        if j<3:k.append(ns['supports'](v,e,(one,zero),n,True))
    translation_vector=mul(A('2/3'),tuple(sum(kj*n[a] for kj,n in zip(k,normals[:3],strict=True)) for a in range(2)))
    R=1/arb(3).sqrt()
    linmax=arb(0)
    sector_vals=[]
    for j,(i,r) in enumerate(ns['sector']):
        a,b=e[j],e[(j+1)%len(e)]
        assert cross(a,b)>0 and dot(a,a).contains(1) and dot(b,b).contains(1)
        chi=sub(mul(-1,perp(v[i])),translation_vector)
        rr=norm(chi)
        extremums=[abs(dot(chi,d)).upper() for d in (a,b)]
        for u in (chi,mul(-1,chi)):
            if not(cross(a,u)<0 or cross(u,b)<0):extremums.append(rr.upper())
        mx=max(extremums)
        sector_vals.append(str(mx))
        linmax=max(linmax,mx)
    return dict(T=translation_vector,L=linmax,k=k,sectors=sector_vals,R=R)


def source_manifest(comp):
    seen=set()
    def hook(ev,arg):
        if ev!='open' or not isinstance(arg[0],(str,bytes)):return
        p=Path(arg[0].decode() if isinstance(arg[0],bytes) else arg[0])
        if p.suffix=='.pyc':
            try:p=Path(source_from_cache(str(p)))
            except ValueError:return
        if p.is_absolute() and p.is_relative_to(comp) and p.is_file() and p.suffix in ('.py','.json'):
            seen.add(p)
    sys.addaudithook(hook)
    return seen


def sha(p):return sha256(p.read_bytes()).hexdigest()


def run(computations,wfile,prior):
    comp=computations
    track=source_manifest(comp)
    raw=json.loads(prior.read_bytes())
    assert list(IDS)==raw['selected'] and raw['selected_combinations']==32
    inner,outer=integer_poly_lower(wfile)
    finite=[];params=[];minimum_other=F(1)
    for index in IDS:
        ns,v,_,cfg,pr=source(comp,index)
        upstream=raw['root_and_separated_branches'][str(index)]
        root=pr()
        assert F(upstream['w'])==F(cfg['w']) and F(upstream['e'])==F(cfg['e'])
        assert all(root[key]==upstream[label] for key,label in [('interior_cells','root_boxes'),('interior_margin','root_floor'),('endpoint_margin','endpoint')])
        shape=selected_shape(ns,v)
        sv=shape['L']; m=arb(root['endpoint_margin']).lower(); M=arb(root['interior_margin']).lower()
        print(index,'L',sv,'m',m,'L/m',sv/m,flush=True)
        far=[];near=[]
        pcs,_=true_samples(ns,v,256)
        for j,sgn in product(range(6),(-1,1)):
            T=lambda p:tran(p,arb.pi()*j/3,sgn)
            if (j,sgn) not in NEAR:
                verts=material_points(list(map(T,v)))
                val=area(hull(inner+verts));assert val>F('.84412')
                far.append(((j,sgn),val))
            else:
                p=material_points(list(map(T,pcs)))
                near.append(((j,sgn),p))
        assert len(far)==10 and len(near)==2
        minfar=min(v for _,v in far)
        minimum_other=min(minimum_other,minfar)
        finite.append(near)
        params.append(dict(index=index,w=root['w'],e=root['deformation'],root=root,shape=shape,m=m,M=M,
                           far=[dict(pose=[i*60,s],area_floor=str(a)) for ((i,s),a) in far]))
    area_rows=[]
    for cases in product(*finite):
        v=area(hull(inner+sum([p for _,p in cases],[])))
        area_rows.append(dict(poses=[[j*60,s] for ((j,s),_) in cases],area_floor=str(v)))
    lower=min(minimum_other,min(F(d['area_floor']) for d in area_rows))
    upstream=F(raw['lower']['exact'])
    assert lower>=upstream>B
    print('floor',lower,'gap',float(lower-B),flush=True)

    examples=[]
    for delta_text,rho_text in (('2.45e-9','9e-8'),('2e-9','8e-8')):
        delta,rho=A(delta_text),A(rho_text)
        R=1/arb(3).sqrt()
        end=(arb.pi()/18000).sin()
        drift=[]
        for param in params:
            assert 3*delta<param['M']
            pred=3*delta/param['m']
            assert pred<end
            deficit=pred**2/(1+(1-pred**2).sqrt())
            radius=4*delta/3+param['shape']['L']*pred+(R+A('2/3'))*deficit
            drift.append(dict(index=param['index'],sin_rotation_upper=str(pred.upper()),
                              rotation_degrees_upper=str((180*pred.asin()/arb.pi()).upper()),
                              Hausdorff_upper=str(radius.upper())))
        assert all(rho>arb(x['Hausdorff_upper']) for x in drift)
        perimeter=2*arb(3).sqrt()*(1+2*delta)
        loss=perimeter*rho+arb.pi()*rho**2
        surplus=A(lower-B)-loss
        assert surplus>0
        if delta_text=='2.45e-9':assert surplus>A('2.96e-10')
        else:assert surplus>A('3.49e-8')
        examples.append(dict(parallel_halfplane_slack=delta_text,one_sided_W_inner_radius=rho_text,
                             perturbed_body_placement=drift,perimeter_upper=str(perimeter.upper()),
                             maximum_Steiner_payment=str(loss.upper()),area_above_B_lower=str(surplus.lower()),
                             area_lower=str((A(lower)-loss).lower())))
    eta=A('2.5e-9'); shift=A('1e-9')
    radius=(A('1/2')+shift)/(arb.pi()/6+eta).cos()
    tilted_slack=shift+2*radius*(eta/2).sin()
    assert tilted_slack<A('2.45e-9')
    body_log=[]
    for p in params:
        st=p['shape']
        body_log.append(dict(index=p['index'],w=p['w'],e=p['e'],root=p['root'],
                             hex_support_derivatives=list(map(str,st['k'])),
                             compensating_translation_vector=list(map(str,st['T'])),
                             support_drift_coefficient_upper=str(st['L']),
                             coefficient_ten_sector_bounds=st['sectors'],other_D6_cases=p['far']))
    return dict(complete=True,scope='W inner vertices near C; C obeys relaxed six hexagon halfplanes and contains all five actual bodies',
                B=str(B),canonical_area_lower=str(lower),canonical_gap_over_B=str(lower-B),
                selected_source_indices=list(IDS),all_body_certificates=body_log,canonical_combination_areas=area_rows,
                rational_W_inner_grid=S,rational_W_inner_vertices=inner,W_inradius='49/100',
                explicit_relaxations=examples,independent_tilted_halfplane_example=dict(
                    maximum_normal_error_radians='2.5e-9',maximum_offset='1e-9',
                    radius_upper=str(radius.upper()),implied_parallel_slack_upper=str(tilted_slack.upper())),
                sources=dict(W_receipt_sha256=sha(wfile),multi_receipt_sha256=sha(prior),
                             verifier_sha256=sha(Path(__file__)),geometry_sha256=sha(Path(__file__).with_name('geometry.py')),
                             computation_files={str(p.relative_to(comp)):sha(p) for p in sorted(track)}),
                python=sys.version.split()[0],flint=flint_version,precision_bits=ctx.prec)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('comp','W_receipt','multi_receipt','out'):p.add_argument(n,type=Path)
    a=p.parse_args()
    result=run(a.comp.resolve(),a.W_receipt.resolve(),a.multi_receipt.resolve())
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print('done',[(x['parallel_halfplane_slack'],x['one_sided_W_inner_radius'],x['area_above_B_lower']) for x in result['explicit_relaxations']],flush=True)

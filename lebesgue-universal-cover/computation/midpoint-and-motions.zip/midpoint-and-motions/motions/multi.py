from pathlib import Path
import sys,json,itertools,math
sys.path.insert(0,str(Path(__file__).resolve().parent))
from geometry import *
from certify import pack
B=F('.844082046521218581802948589770767704354')
IDS=[20,36,14,28,1,23,44,17,6,33]
def setup(comp,w):
 inn,out=host(w); ids=[];other={};details={}
 for i in IDS:
  ns,v,_,c,root=source(comp,i)
  r=root();q,gap=true_samples(ns,v,256)
  cases=[];bad=[]
  for j in range(6):
   for s in [-1,1]:
    T=lambda a:tran(a,R.pi()*j/3,s)
    verts=outer_inner(list(map(T,v)))[0]
    floor=area(hull(inn+verts))
    if floor>F('.84412'):bad.append(floor);continue
    low,_=outer_inner(list(map(T,q)),gap/256)
    H=hull(inn+low)
    cases.append(((j,s),[p for p in H if p not in inn],area(H)))
  assert len(cases)>=1
  other[i]=min(bad) if bad else F(1)
  ids.append((i,cases))
  details[i]=dict(w=c['w'],e=c['e'],root_boxes=r['interior_cells'],root_floor=r['interior_margin'],endpoint=r['endpoint_margin'],other=pack(other[i]),near=[[j*60,s] for (j,s),_,_ in cases])
 return inn,out,ids,other,details
def evaluate(inn,items):
 states=[(tuple(inn),())]
 for i,cases in items:
  states=[(tuple(hull(list(p)+q)),b+(z,)) for p,b in states for z,q,_ in cases]
 return min((area(list(p)),b) for p,b in states)
def run(comp,w):
 inn,out,items,other,detail=setup(comp,w)
 allfloor,ab=evaluate(inn,items)
 print('allfloor',float(allfloor),file=sys.stderr,flush=True)
 selected=items[:]
 for i in reversed(IDS):
  rest=[a for a in selected if a[0]!=i]
  v,_=evaluate(inn,rest)
  if v>B+F('.00000001'):selected=rest
 value,b=evaluate(inn,selected);floor=min(value,min(other[i] for i,g in selected))
 assert floor>B
 return dict(all_input_ids=IDS,root_and_separated_branches=detail,all_selected_combinations=math.prod(len(g) for i,g in items),ten_lower=pack(min(allfloor,min(other.values()))),selected=[i for i,g in selected],selected_combinations=math.prod(len(g) for _,g in selected),lower=pack(floor),gap_over_B=pack(floor-B),gain_from_W=pack(floor-area(out)),lowest_near_branches=b)
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve()),indent=2))

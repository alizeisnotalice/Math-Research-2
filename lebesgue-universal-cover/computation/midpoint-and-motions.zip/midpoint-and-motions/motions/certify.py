from pathlib import Path
import json,sys,hashlib,itertools
sys.path.insert(0,str(Path(__file__).resolve().parent))
from geometry import *
def pack(x):return {'exact':str(x),'approx':float(x)}
def one(comp,wfile,i,count=1024):
 ns,v,f,cfg,root=source(comp,i);roots=root()
 inn,out=host(wfile)
 pts,width=true_samples(ns,v,count)
 cases=[];angles=[]
 for j in range(6):
  for s in [1,-1]:
   t=R.pi()*j/3
   points=[tran(z,t,s) for z in v]
   def gap(a,b):
    n=(b[1]-a[1],a[0]-b[0]);l=R(n[0]**2+n[1]**2).sqrt()
    return max(((z[0]-R(a[0])/S)*n[0]+(z[1]-R(a[1])/S)*n[1]).lower()/l for z in points)
   gap0,edge=max((gap(a,b).lower(),k) for k,(a,b) in enumerate(zip(out,out[1:]+out[:1])))
   assert gap0>R('.0001')
   lo=area(hull(inn+outer_inner(points)[0]))
   cases.append(dict(turn=60*j,reflection=s,vertex_witness_gap=str(gap0),outer_edge=edge,lower=pack(lo)))
   angles.append((lo,j,s))
 best=min(angles)
 for entry in cases:
  if entry['lower']['approx']<float(best[0])+.000005:
   t=R.pi()*entry['turn']/180;s=entry['reflection']
   low,high=outer_inner([tran(p,t,s) for p in pts],width/count)
   entry['lower']=pack(area(hull(inn+low)));entry['upper']=pack(area(hull(out+high)))
 floor=min(F(x['lower']['exact']) for x in cases);ceil=min(F(x['upper']['exact']) for x in cases if 'upper' in x)
 return dict(input_id=i,samples_per_arc=count,source=cfg,w_hash=hashlib.sha256(wfile.read_bytes()).hexdigest(),source_chart_sigma='1.5497',host_sigma='1.54',root_certificate=roots,full_hexagon_cases=cases,old_area=[pack(area(inn)),pack(area(out))],fixed_hexagon_minimum=[pack(floor),pack(ceil)],fixed_hexagon_area_gain=[pack(floor-area(out)),pack(ceil-area(inn))])
if __name__=='__main__':
 print(json.dumps(one(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve(),int(sys.argv[3]),int(sys.argv[4]) if len(sys.argv)>4 else 1024),indent=2))

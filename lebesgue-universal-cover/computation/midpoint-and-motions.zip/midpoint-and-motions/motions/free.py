from pathlib import Path
from fractions import Fraction as F
import sys,math,json,itertools,hashlib
import numpy as np
from scipy.optimize import linprog
sys.path.insert(0,str(Path(__file__).resolve().parent))
from geometry import *
def arbq(x):return R(x.numerator)/x.denominator
def run(wpath,inputfile,comp,floor):
 ctx.prec=160
 inn,out=host(wpath);d=json.loads(inputfile.read_bytes());Q=d['scale'];qs=d['points']
 assert len(qs)>=3
 diam=max((q[0]-p[0])**2+(q[1]-p[1])**2 for i,q in enumerate(qs) for p in qs[:i])
 assert diam<Q*Q
 ns,v,*_=source(comp,24)
 margin=min((1-(R(x)/Q-a)**2-(R(y)/Q-b)**2).lower() for x,y in qs for a,b in v)
 assert margin>0
 N=[(y[1]-x[1],x[0]-y[0]) for x,y in zip(inn,inn[1:]+inn[:1])]
 H=[x*a+y*b for (x,y),(a,b) in zip(N,inn)]
 W=np.array(N,dtype='float64')/S;P=np.array(qs)/Q;off=np.array(H,dtype='float64')/(S*S)
 det=lambda a,b:a[0]*b[1]-a[1]*b[0]
 a,b=max(itertools.combinations(range(len(N)),2),key=lambda pair:abs(det(N[pair[0]],N[pair[1]])))
 delta=det(N[a],N[b])
 def section(lo,hi,side):
  mid=(lo+hi)/2
  th=float(mid)*math.pi/180;cs,sn=math.cos(th),math.sin(th)
  U=W@np.array([[cs,-sn],[side*sn,side*cs]])
  vals=U@P.T;idx=np.argmax(vals,axis=1)
  g=vals[np.arange(len(N)),idx]-off
  z=linprog(-g,A_eq=W.T,b_eq=[0,0],bounds=(0,1),method='highs-ds',options={'dual_feasibility_tolerance':1e-10,'primal_feasibility_tolerance':1e-10})
  assert z.success
  scale=10**14
  weights=[F(round(scale*((1-2e-10)*x+1e-10)),scale) for x in z.x]
  rx=-sum(w*n[0] for w,n in zip(weights,N));ry=-sum(w*n[1] for w,n in zip(weights,N))
  weights[a]+=det((rx,ry),N[b])/delta
  weights[b]+=det(N[a],(rx,ry))/delta
  assert all(0<=w<=1 for w in weights)
  assert all(sum(w*n[j] for w,n in zip(weights,N))==0 for j in [0,1])
  p=[qs[i] for i in idx]
  A=arbq(sum(w*(x*q[0]+side*y*q[1]) for w,(x,y),q in zip(weights,N,p))/(2*S*Q))
  B=arbq(sum(w*(-x*q[1]+side*y*q[0]) for w,(x,y),q in zip(weights,N,p))/(2*S*Q))
  C=arbq(-sum(w*h for w,h in zip(weights,H))/(2*S*S))
  angle=arbq(mid)*R.pi()/180;cs=angle.cos();sn=angle.sin();r=arbq(hi-lo)*R.pi()/360
  bound=(A*cs+B*sn+C-abs(B*cs-A*sn)*r-(abs(A)+abs(B))*r*r/2).lower()
  return bound
 res=[]
 for side in [1,-1]:
  stack=[(F(t),F(t+5)) for t in range(0,360,5)]
  accepted=[];mind=100
  while stack:
   a0,b0=stack.pop()
   val=section(a0,b0,side)
   if val>arbq(floor):
    accepted.append(val);mind=min(mind,b0-a0)
   else:
    assert b0-a0>F(1,10**9),(side,a0,b0,val)
    mid=(a0+b0)/2;stack.extend([(a0,mid),(mid,b0)])
  res.append(dict(reflection=side,closed_intervals=len(accepted),smallest_interval_degrees=str(mind),minimum_enclosed_gain=str(min(accepted))))
 gain=floor-(area(out)-area(inn))
 return dict(w_hash=hashlib.sha256(wpath.read_bytes()).hexdigest(),finite_points=len(qs),diameter_squared_exact=str(F(diam,Q*Q)),pentagon_containment_margin=str(margin),curvature_mixed_margin=str(floor),actual_W_free_area_gain_lower=str(gain),free_augmented_area_lower=str(area(inn)+floor),intervals=res)
if __name__=='__main__':print(json.dumps(run(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve(),Path(sys.argv[3]).resolve(),F(sys.argv[4])),indent=2))

# W 的真实漏装与增广代价

proof.md 给出处于参考原点的明确坐标、两种宿主量词与面积证明。COMP 是原项目 computation，W 是上一包 eight-area/certificate/receipt.json。运行环境 Python 3.13.18、python-flint 0.9.0、SciPy 1.18.1、NumPy 2.5.5。在本目录执行：

~~~sh
python -I -B certify.py "$COMP" "$W" 24 16384
python -I -B free.py "$W" small-input.json "$COMP" .00000639490
python -I -B free.py "$W" compact-input.json "$COMP" .00000365
python -I -B multi.py "$COMP" "$W"
~~~

输出依次对应 sharp24.json、free-sharp.json、compact-sharp.json、multi.json。19点用于锐面积下端，14点是更紧凑的独立反例，直径平方为 \(999999998000000001/10^{18}<1\)，任意全平面位姿的必要净增面积仍大于 \(3.64999977\cdot10^{-6}\)。两种有限证书全部以真实有理点直接扫完角圆和两手，允许任意平移。工作中没有更改冻结宿主的顶点。脚本首先检查归档 W 的真实几何与内外包；回执输出给出其输入哈希。

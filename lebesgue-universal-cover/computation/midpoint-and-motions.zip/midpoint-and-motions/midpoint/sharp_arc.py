from flint import arb as R,ctx
import json,itertools
ctx.prec=160
pi=R.pi();deg=pi/180;sqrt3=R(3).sqrt()
def unit(t):return (t.cos(),t.sin())
def dot(p,q):return p[0]*q[0]+p[1]*q[1]
def sub(p,q):return (p[0]-q[0],p[1]-q[1])
def refl(p):return ((-p[0]+sqrt3*p[1])/2,(sqrt3*p[0]+p[1])/2)
def support(P,v):return max(dot(p,v).lower() for p in P)
def run(cloud):
 d=next(x for x in json.loads(cloud.read_text()) if x['beta']==116)
 s=1-sqrt3/2;k=[s,R(d['pins'][1]),-s]
 n=[unit(i*pi/3) for i in range(3)]
 pp=[(x/2-k0*y,y/2+k0*x) for k0,(x,y) in zip(k,n)]
 A=pp+[sub(p,u) for p,u in zip(pp,n)]
 z=((sqrt3-1)/2,(1-sqrt3)/2)
 p=(z[0]+(116*deg).cos(),z[1]+(116*deg).sin())
 A+=[p,refl(p)]
 A += [(R('.99999')*R(x),R('.99999')*R(y)) for x,y in d['points'][2:]]
 exact={(0,3),(1,4),(2,5),(3,5),(5,6),(3,7)}
 diam=max(dot(sub(A[i],A[j]),sub(A[i],A[j])).upper() for i,j in itertools.combinations(range(len(A)),2) if (i,j) not in exact)
 assert diam<1
 slope=k[0]-k[1]+k[2]
 assert slope*(deg/5).cos()-R('1.5')*(deg/5).sin()>R('.04')
 den=2**22;stack=[(0,den)];count=0;floor=R(10)
 while stack:
  l,r=stack.pop();t=(R(1)/5+(R(l).union(R(r))/den)*(R(298)/5))*deg
  f=sum(support(A,unit(t+i*pi*2/3)) for i in range(3))-R('1.5')
  if f>R('.00001'):
   floor=min(floor,f.lower());count+=1
  else:
   assert r-l>=2
   mid=(l+r)//2;stack.extend([(l,mid),(mid,r)])
 G=min(support(L,unit((R(30+60*i)+R('1.50').union(R('1.54')))*deg))-R('.5') for i in range(3) for L in [A,list(map(refl,A))])
 assert G>R('.002')
 return dict(anchors=len(A),strict_diameter_upper=str(diam),middle_angle_boxes=count,middle_root_floor=str(floor),cap_guard=str(G),endpoint_slope=str(slope),analytic_height_at_116=str(1+dot(z,unit(116*deg))))
if __name__=='__main__':
 from pathlib import Path
 import sys
 print(json.dumps(run(Path(sys.argv[1])),indent=2))

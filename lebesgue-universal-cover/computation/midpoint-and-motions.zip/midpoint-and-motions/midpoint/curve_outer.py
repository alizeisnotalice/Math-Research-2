from flint import arb as R
from itertools import combinations,product
from fractions import Fraction as F
def core_upper(defs,inner,S,hull):
    import audit_optimized_eh_chord as g
    def possible(p,cs):return all(not (g.dot(g.minus(p,c),g.minus(p,c))>1) for c in cs)
    V={}
    for k,cs in defs.items():
        v=[]
        for a,b in combinations(cs,2):
            for sign in [-1,1]:
                p=g.circle_pair(a,b,sign)
                assert all(c.is_finite() for c in p)
                if possible(p,cs):v.append(p)
        V[k]=v
    emax=0
    for p,q in zip(inner,inner[1:]+inner[:1]):
        n=(q[1]-p[1],p[0]-q[0])
        b=n[0]*p[0]+n[1]*p[1]
        assert b>0
        length=R(n[0]**2+n[1]**2).sqrt()
        u=(R(n[0])/length,R(n[1])/length)
        best=length/2
        for k,cs in defs.items():
            hh=[g.dot(n,z).upper() for z in V[k]]
            for c in cs:
                z=g.plus(c,u)
                if possible(z,cs):hh.append((g.dot(n,c)+length).upper())
            if hh:best=max(best,max(hh))
        scale=int(((best*S/b-1)*S).upper().ceil().unique_fmpz())
        emax=max(emax,scale)
    scale=F(S+emax,S)
    out=hull([(round(x*scale)+a,round(y*scale)+b) for x,y in inner for a,b in product([-1,1],repeat=2)])
    return out,emax

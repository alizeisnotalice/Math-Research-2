"""Verify dual upper bounds on every support sample of the unrestricted 60-deg symmetric hexagon rotor."""
import json,math,sys
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
from flint import arb,ctx
ctx.prec=120
S=10**12
Q=10**9
N=180   # d=.5 deg
def index(k):
 k=(k+2*N)%(4*N)-2*N
 a=abs(k)
 return (a,1) if a<=N else (2*N-a,-1)
def row(terms):
 a={}
 for i,c in terms:
  j,sg=index(i);a[j]=a.get(j,0)+sg*c
 return {j:v for j,v in a.items() if v}
def construct(axis=60,phase=0,guards=(0,1,2)):
 d=arb.pi()/(2*N);c=round(math.cos(math.pi/(2*N))*S)
 assert abs(d.cos()-arb(c)/S) < arb(1)/S
 rows=[];rhs=[]
 def put(a,b):rows.append(a);rhs.append(b)
 def eq(a):put(a,0);put({i:-v for i,v in a.items()},0)
 for k in range(N+1):
  a=row([(k-1,S),(k,-2*c),(k+1,S)])
  for s in [-1,1]:put({j:s*v for j,v in a.items()},S-c+2)
 for k in [N]+[(i-axis)*N//90 for i in [0,60,120]]:eq(row([(k,S)]))
 for k in range(2*N//3+1):
  j=k-axis*N//90
  a=row([(j,S),(j+4*N//3,S),(j+8*N//3,S)])
  if phase==0:eq(a)
  elif phase in [-1,1]:put({i:-phase*v for i,v in a.items()},0)
 # m_i lies .04 degree from the .5 grid direction: two exact adjacent normals
 for i in guards:
  theta=F(3154,100)+60*i-axis
  a=math.floor(theta*N/90)
  x=arb(theta.numerator)/theta.denominator*arb.pi()/180-a*d
  w0=(d-x).sin()/d.sin();w1=x.sin()/d.sin()
  A=round(float(w0)*S);B=round(float(w1)*S)
  assert abs(w0-arb(A)/S)<arb(1)/S and abs(w1-arb(B)/S)<arb(1)/S
  # .5 <= w0*h0+w1*h1, each h <=1/sqrt(3)<1
  put(row([(a,-A),(a+1,-B)]),(A+B-S+1)//2+2)
 return rows,rhs
def solve(axis=60,phase=0,guards=(0,1,2)):
 rows,rhs=construct(axis,phase,guards)
 sparse=csr_matrix(([v/S for r in rows for v in r.values()],[j for r in rows for j in r],np.cumsum([0]+[len(r) for r in rows])),shape=(len(rows),N+1))
 data=[]
 for i in range(N+1):
  for sign in [-1,1]:
   obj=np.zeros(N+1);obj[i]=-sign
   z=linprog(obj,A_ub=sparse,b_ub=np.array(rhs)/S,bounds=[(-.08,.08)]*(N+1),method='highs')
   assert z.success
   data.append([[j,int(round(w*Q))] for j,w in enumerate(-z.ineqlin.marginals) if round(w*Q)>0])
 return data
def verify(data,axis=60,phase=0,guards=(0,1,2)):
 rows,rhs=construct(axis,phase,guards)
 assert len(data)==2*(N+1)
 out=[]
 for j,ys in enumerate(data):
  sign=j%2*2-1;i=j//2;y=dict(ys)
  assert len(y)==len(ys) and all(isinstance(k,int) and 0<=k<len(rows) and isinstance(v,int) and v>=0 for k,v in ys)
  r=[0]*(N+1);r[i]=sign*S*Q
  m=0
  for k,v in ys:
   m+=rhs[k]*v
   for k1,a in rows[k].items():r[k1]-=a*v
  scaled=100*m+8*sum(map(abs,r))
  h=(scaled+(100*S*Q//10**12)-1)//(100*S*Q//10**12)
  out.append(h)
 return out
if __name__=='__main__':
 from pathlib import Path
 p=Path(__file__).with_name('rotor-dual.json')
 if '--produce' in sys.argv:p.write_text(json.dumps(solve(),separators=(',',':')))
 v=verify(json.loads(p.read_text()))
 print(len(v),min(v),max(v))

# 八面中的全体输入中点与强制双弧

完整研究结论见 quantifiers.md、arc-area.md。前者固定 1.54°，给出单一面积小于 B 的中点宿主，覆盖全体直径一输入的全部非负支撑测量。后者在整个 [1.50°,1.54°] 证明强制双圆弧，另在 1.54° 计算共同材料的精确有理面积上下端。

最小重放使用本包、原题归档 computation 目录、Python 3.13.18、python-flint 0.9.0、NumPy 2.5.5、SciPy 1.18.1。将下面的 COMP 设置为题目原 computation 目录。从本包运行，命令只向标准输出写结果。

~~~sh
python -I -B verify_clouds.py
python -I -B certify.py "$COMP"
~~~

输出分别与 cloud-receipt.json、receipt.json 相同。upstream-sha256.json 列出重建原镜片圆心实际加载的项目脚本。duals-two-180.json.gz 包含六条反射轴各362个整数对偶，共2172个。rotor-dual.json 另含362个具有零根和等式的对偶，只用于指定对称转子族。material.json 的所有坐标各除 (10^{12})；cloud-input.json 中小数均是精确有理数。证书复查不运行优化器，半平面活跃集的数值选择会由精确有理线段复核。最终多边形的60个有理顶点以 receipt.json 的 full_W_outer_vertices 和 full_W_polygon_scale 给出。

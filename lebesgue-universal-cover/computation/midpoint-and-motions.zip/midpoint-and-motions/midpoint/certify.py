"""Recheck the true-curve area interval; COMP is the published project computation directory."""
from pathlib import Path
import argparse,sys,json,math,itertools
from fractions import Fraction as F
from hashlib import sha256
from flint import arb as R,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import init
from rotor_dual import verify,index,N
from curve_outer import core_upper
from sharp_arc import run as arc_certificate, unit, refl
from scipy.spatial import HalfspaceIntersection
import numpy as np
S=10**12
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(pts):
    pts=sorted(set(map(tuple,pts)))
    def half(seq):
        ret=[]
        for p in seq:
            while len(ret)>=2 and cross(ret[-2],ret[-1],p)<=0:ret.pop()
            ret.append(p)
        return ret[:-1]
    return half(pts)+half(pts[::-1])
def area(p):
    return F(sum(x*b-y*a for (x,y),(a,b) in zip(p,p[1:]+p[:1])),2*S*S)
def directed(P):
    # The numeric choice only selects a subset of valid enclosing halfplanes.
    poly=HalfspaceIntersection(np.array([[a/b,c/b,-1] for a,c,b in P]),np.zeros(2))
    act={i for s in poly.dual_facets for i in s}
    rows=sorted([P[i] for i in act],key=lambda a:math.atan2(a[1],a[0]))
    V=[]
    for (x,y,h),(a,b,k) in zip(rows,rows[1:]+rows[:1]):
        det=x*b-y*a
        assert det>0
        V.append((F(h*b-k*y,det),F(x*k-a*h,det)))
    # Vertices turn left and the origin is left of each edge; the convex polygon
    # is precisely the intersection of the selected cyclically ordered halfplanes.
    assert all((V[i][0]-V[i-1][0])*(-rows[i][1])+(V[i][1]-V[i-1][1])*rows[i][0]>=0 for i in range(len(rows)))
    assert all(cross(V[i-2],V[i-1],V[i])>=0 for i in range(len(V)))
    assert all(rows[i][0]*V[i][0]+rows[i][1]*V[i][1]==rows[i][2] for i in range(len(V)))
    return hull([(round(p[0]*S)+dx,round(p[1]*S)+dy) for p in V for dx,dy in itertools.product([-1,1],repeat=2)])
def inside(p,cs):
    x,y=p
    return all((x-a)**2+(y-b)**2<1 for a,b in cs)
def rot(p):x,y=p;return ((-x+R(3).sqrt()*y)/2,(R(3).sqrt()*x+y)/2)
def near(x):
    i=int(round(float(x*S)))
    assert abs(x*S-i)<R('.501')
    return i
def bounds(atoms):
    z=[(near(x),near(y)) for x,y in atoms]
    # Inner round after homothety, with inradius 1/2 supplied by the common disk.
    inn=[(round(F(x)*(1-F(1,10**10))),round(F(y)*(1-F(1,10**10)))) for x,y in z]
    out=[(x+dx,y+dy) for x,y in z for dx,dy in itertools.product([-1,1],repeat=2)]
    return hull(inn),hull(out)
def pack(x):return str(float(x)),str(x)
def main(comp,cloud,rote):
    defs,conditions=init(comp)
    mat=json.loads((HERE/'material.json').read_text());assert mat['scale']==S
    core=[]
    for k,x,y in mat['core']:
        q=(R(x)/S,R(y)/S)
        assert (4*(x*x+y*y)<S*S) if k=='disk' else inside(q,defs[k])
        core.append((x,y))
    c0=hull(core)
    oldpoly,emax=core_upper(defs,c0,S,hull)
    dual=verify(json.loads(rote.read_text()))
    def envelope(du,axis,guards):
        rows=[]
        for k in range(4*N):
            t=R(k)*R.pi()/(2*N)
            x=near(t.cos());y=near(t.sin());i,sign=index(k-axis*N//90)
            rows.append((x,y,S//2+du[2*i+(sign==1)]+2))
        for i in guards:
            b=R('211.54')+60*i
            for t in [b,2*axis-b]:
                th=t*R.pi()/180
                rows.append((near(th.cos()),near(th.sin()),S//2+2))
        return directed(rows)
    rotor=envelope(dual,60,(0,1,2))
    import gzip
    extra_polys={}
    raw=json.loads(gzip.decompress((HERE/'duals-two-180.json.gz').read_bytes()))
    assert [(a,s,n) for a,s,n,v in raw]==[(a,2,180) for a in range(0,180,30)]
    for a,s,n,v in raw:
        extra_polys[a]=envelope(verify(v,a,s,(0,2)),a,(0,2))
    all_polys=hull([v for a in extra_polys for v in extra_polys[a]])
    relaxed_upper={a:area(hull(oldpoly+extra_polys[a])) for a in extra_polys}
    relaxed_upper['all']=area(hull(oldpoly+all_polys))
    arc_data=arc_certificate(cloud)
    z=((R(3).sqrt()-1)/2,(1-R(3).sqrt())/2)
    def translated(v):return (z[0]+v[0],z[1]+v[1])
    intervals=680
    start=116*R.pi()/180
    step=R(34)*R.pi()/(180*intervals)
    endpoints=[translated(unit(start+k*step)) for k in range(intervals+1)]
    tips=[]
    for k in range(intervals):
        u=unit(start+(R(k)+R(1)/2)*step)
        tips.append(translated((u[0]/(step/2).cos(),u[1]/(step/2).cos())))
    inner_arc=bounds(endpoints+list(map(refl,endpoints)))[0]
    outside_arc=endpoints+tips
    outer_arc=bounds(outside_arc+list(map(refl,outside_arc)))[1]
    names=[];groups=[]
    for k,pts in mat['extra'].items():
        cs=conditions[k];q=[(R(x)/S,R(y)/S) for x,y in pts]
        assert all(inside(v,cs) for v in q)
        assert all((x-a)**2+(y-b)**2<S*S for i,(x,y) in enumerate(pts) for a,b in pts[:i])
        names.append(k);groups.append([bounds(q),bounds(list(map(rot,q)))])
    for c in json.loads(cloud.read_text()):
        pins=list(map(R,c['pins']))
        n=[((R(i)*R.pi()/3).cos(),(R(i)*R.pi()/3).sin()) for i in range(3)]
        pp=[(x/2-k*y,y/2+k*x) for k,(x,y) in zip(pins,n)]
        q=pp+[(a-x,b-y) for (a,b),(x,y) in zip(pp,n)]+[tuple(map(R,p)) for p in c['points']]
        if c['beta']==117:q=[(R('.998')*x,R('.998')*y) for x,y in q]
        names.append(str(c['beta']));groups.append([bounds(q),bounds(list(map(rot,q)))])
    baseline=area(c0)
    # All exact closed branch hulls contain the disk; thus each inner rounded vertex is in each corresponding true hull.
    lo=[];hi=[];hi_free=[]
    for bits in itertools.product(range(2),repeat=len(groups)):
        p=hull(c0+inner_arc+[v for g,b in zip(groups,bits) for v in g[b][0]])
        lo.append((area(p),bits))
    for _,bits in lo: # Each closed branch also has a provable upper bound.
        ps=[v for g,b in zip(groups,bits) for v in g[b][1]]
        hi.append((area(hull(oldpoly+outer_arc+rotor+ps)),bits))
        hi_free.append((area(hull(oldpoly+all_polys+ps)),bits))
    L,LB=min(lo);U,UB=min(hi)
    B=F('.844082046521218581802948589770767704354')
    return dict(scale=S,groups=names,choices_verified=len(lo),lower=pack(L),upper=pack(U),
                lower_branch=LB,upper_branch=UB,universal_B_minus_material_interval=[pack(B-U),pack(B-L)],
                relaxed_core_upper={a:pack(v) for a,v in relaxed_upper.items()},all_symmetry_plus_optional_upper=pack(min(hi_free)[0]),sharp_arc=arc_data,with_sharp_arc_lower=pack(area(hull(c0+inner_arc))),with_sharp_arc_upper=pack(area(hull(oldpoly+outer_arc))),core_inner=pack(baseline),core_outer=pack(area(oldpoly)),core_with_rotors_outer=pack(area(hull(oldpoly+rotor))),
                rotor_support_upper={str(i):str(F(1,2)+F(dual[2*index((i-60)*N//90)[0]+(index((i-60)*N//90)[1]==1)],S)) for i in range(113,118)},
                core_homothety_extra_over_scale=emax,core_points=len(c0),rotor_outer_vertices=len(rotor),full_W_polygon_scale=S,full_W_outer_vertices=hull(oldpoly+all_polys),cloud_source_hash=sha256(cloud.read_bytes()).hexdigest())
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('comp',type=Path);p.add_argument('cloud',type=Path,nargs='?',default=HERE/'cloud-input.json')
    a=p.parse_args();print(json.dumps(main(a.comp.resolve(),a.cloud.resolve(),HERE/'rotor-dual.json'),indent=2))

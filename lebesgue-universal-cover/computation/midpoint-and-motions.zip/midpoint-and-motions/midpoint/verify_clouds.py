"""Usage: python -I -B verify.py > receipt.json (python-flint 0.9)."""
import json
from pathlib import Path
import platform
import flint
from flint import arb as R,ctx
ctx.prec=160
pi=R.pi()
deg=pi/180
half=R(1)/2
sqrt3=R(3).sqrt()
six_eps=R('0.000001')
slope=R('.025')
angle=3*six_eps/slope
support_loss=(2*six_eps+angle/2)/sqrt3
def un(t): return (t.cos(),t.sin())
def dot(a,b): return a[0]*b[0]+a[1]*b[1]
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def reflect(a): return ((-a[0]+sqrt3*a[1])/2,(sqrt3*a[0]+a[1])/2)
def support(A,u): return max(dot(a,u).lower() for a in A)
def string(a): return str(a)
def cloud(d):
    lam=R('.002') if d['beta']==117 else R(0)
    k=list(map(R,d['pins']))
    n=[un(i*pi/3) for i in range(3)]
    p=[(x/2-k0*y,y/2+k0*x) for k0,(x,y) in zip(k,n)]
    A=p+[sub(z,u) for z,u in zip(p,n)]+[tuple(map(R,z)) for z in d['points']]
    diam=max(dot(sub(a,b),sub(a,b)).upper() for i,a in enumerate(A) for j,b in enumerate(A[:i]) if (j,i) not in [(0,3),(1,4),(2,5)])
    assert diam < 1
    JA=list(map(reflect,A))
    s=k[0]-k[1]+k[2]
    # endpoint lower F >= s sin(t)-1.5(1-cos t)
    assert (1-lam)*(s*(deg/5).cos()-R(3)/2*(deg/5).sin())>slope
    # Integer 0..2^26 parametrizes the complete middle interval, no omitted boundaries.
    den=2**26
    stack=[(0,den)]
    panels=0
    mid_floor=R(1)
    while stack:
        lo,hi=stack.pop()
        t=(R(1)/5+(R(lo).union(R(hi))/den)*(R(298)/5))*deg
        gap=sum(support(A,un(t+120*i*deg)) for i in range(3))-3*half
        gap=(1-lam)*gap+lam*(sqrt3*(t-pi/6).cos()-3*half)
        if gap>3*six_eps:
            panels+=1
            mid_floor=min(mid_floor,gap.lower())
        else:
            assert hi-lo>=2,(d["beta"],lo,hi,t,gap)
            mid=(lo+hi)//2
            stack.extend([(lo,mid),(mid,hi)])
    # Each sigma subinterval is closed; evaluate every query for both surviving chiralities.
    guard=R(1)
    for j in range(16):
        sigma=(R('1.50')+R(j).union(R(j+1))/400)*deg
        for i in range(3):
            m=un((30+60*i)*deg+sigma)
            for points in [A,JA]:
                guard=min(guard,((1-lam)*support(points,m)+lam*(1-1/sqrt3)-half).lower())
    assert guard>R('.001')+support_loss
    u=un(d['beta']*deg)
    forcing=(1-lam)*min(support(A,u),support(JA,u))+lam*(1-1/sqrt3)
    close=sub(A[6],JA[7])
    separation=dot(close,close).sqrt()
    return dict(beta=d['beta'],anchors=len(A),triangle_weight=string(lam),nonopposite_maximum_sq_upper=string(diam),
             endpoint_contact_slope=string(s),middle_panels=panels,middle_floor=string(mid_floor),
             cap_guard=string(guard),ideal_support_floor=string(forcing),perturbed_support_floor=string(forcing-support_loss),
             reflected_point_separation=string(separation))
A=R('.84408411985664068202565411425225501127180755')
B=R('.844082046521218581802948589770767704354')
hshift=R('.0000005')
htilt=R('.00004')*deg
cshift=R('.0008')
ctilt=R('.015')*deg
radius=(half+hshift)/(30*deg+htilt).cos()
assert hshift+2*radius*(htilt/2).sin()<six_eps
assert cshift+2*radius*(ctilt/2).sin()<R('.001')
ratio=(B/A).sqrt()
near_threshold=(1-ratio)/(2*(1+ratio))
c=(sqrt3-3*half)/(pi/6)
lam=R('.00355')
maximal_radius_difference=2/sqrt3-1
family_loss=lam*maximal_radius_difference+(2*six_eps+3*six_eps/(2*c*lam))/sqrt3
rotor_guard=R(1)
for j in range(16):
    for i in range(3):
        x=(R(30+60*i-60)+R('1.50')+R(j).union(R(j+1))/400)*deg
        guard=R('.49')*(x.cos()-(5*x).cos())/24-R('.001')/24
        rotor_guard=min(rotor_guard,guard.lower())
assert family_loss<R('.00111') and rotor_guard>R('.000952')+family_loss,(rotor_guard,family_loss)
res=dict(affine_hausdorff_threshold=string(near_threshold),family_root_slope=string(c),
      family_guard=string(rotor_guard),family_loss=string(family_loss),python=platform.python_version(),python_flint=flint.__version__,precision_bits=ctx.prec,
     threshold_equal_corresponding_faces=string(((A/B).sqrt()-1)/2),nominal_excision_lower=string(A-B),
     excision_lower_at_face_shift_5e_7=string(A-B*(1+2*hshift)**2),shear_excision_at_condition_1_001=string(A-B*4/(3*R('1.001')+1/R('1.001'))),
     effective_hex_face_slack=string(hshift+2*radius*(htilt/2).sin()),
     effective_cap_slack=string(cshift+2*radius*(ctilt/2).sin()),near_pose_angle_bound=string(angle),
     support_loss=string(support_loss),
     clouds=[cloud(d) for d in json.loads(Path(__file__).with_name('cloud-input.json').read_text())])
print(json.dumps(res,indent=2))

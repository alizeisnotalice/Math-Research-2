"""Certify a common diameter-one witness against both translations into the frozen W."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json
import sys

from flint import arb,ctx,__version__ as flint_version


def A(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def add(u,v):
    return u[0]+v[0],u[1]+v[1]


def mul(k,v):
    return k*v[0],k*v[1]


def sub(u,v):
    return u[0]-v[0],u[1]-v[1]


def perp(v):
    return -v[1],v[0]


def dot(u,v):
    return u[0]*v[0]+u[1]*v[1]


def cross(u,v):
    return u[0]*v[1]-u[1]*v[0]


def unit(t):
    si,co=(A(t)*arb.pi()/180).sin_cos()
    return co,si



def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def certify(wfile,witnessfile):
    ctx.prec=192
    witness=json.loads(witnessfile.read_bytes())
    wsha=digest(wfile)
    assert wsha==witness['W_receipt_sha256']=='4b129d3aa5a199400ee426f1e4bd12396dddc657e5f355a7e601a152a1cd2add'
    source=json.loads(wfile.read_bytes())
    V=source['full_W_outer_vertices']
    scale=source['full_W_polygon_scale']
    assert len(V)==60 and scale==10**12
    cyclic=list(zip(V,V[1:]+V[:1],strict=True))
    edges=[sub(w,v) for v,w in cyclic]
    assert all(cross(a,b)>0 for a,b in zip(edges,edges[1:]+edges[:1],strict=True))
    polygon_rows=[]
    for (x,y),edge in zip(cyclic,edges,strict=True):
        N=(edge[1],-edge[0])
        b=dot(N,x)
        assert dot(N,y)==b and all(dot(N,z)<=b for z in V)
        polygon_rows.append((N,b))
    area=F(sum(cross(v,w) for v,w in cyclic),2*scale**2)
    B=F('.844082046521218581802948589770767704354')
    assert area==F(source['all_symmetry_plus_optional_upper'][1]) and area<B

    half=A('1/2')
    rs=arb(3).sqrt()/2
    base=[(arb(1),arb(0)),(half,rs),(-half,rs)]
    hex_normals=base+[mul(-1,n) for n in base]

    def J(v):
        x,y=v
        return -half*x+rs*y,rs*x+half*y

    cuts=[F(r['degrees']) for r in witness['caps']]
    assert cuts==list(map(F,('211.54','331.54','268.46','148.46')))
    assert [(120-t)%360 for t in cuts[:2]]==cuts[2:]
    cap_normals=[unit(t) for t in cuts]
    P=hex_normals+cap_normals[:2]
    for i,u in enumerate(hex_normals):
        contact=mul(half,u)
        assert all(A(F(b,scale))>dot(N,contact) for N,b in polygon_rows)
        assert all(half>dot(v,contact) for j,v in enumerate(P) if i!=j)
        assert (dot(u,contact)-half).contains(0)
    for n,nprime in zip(cap_normals[:2],cap_normals[2:],strict=True):
        assert all(d.contains(0) for d in sub(J(n),nprime))
    for i,n in enumerate(hex_normals):
        assert all(d.contains(0) for d in sub(J(n),hex_normals[(2-i)%6]))

    offsets=list(map(A,witness['hexagon_tangent_offsets']))
    positive=[add(mul(half,n),mul(k,perp(n))) for n,k in zip(base,offsets,strict=True)]
    points=positive+[sub(p,n) for p,n in zip(positive,base,strict=True)]
    for row,u in zip(witness['caps'],cap_normals,strict=True):
        delta=A(row['depth'])
        assert delta>=0
        y=add(mul(-half-delta,u),mul(A(row['tangent']),perp(u)))
        assert (dot(u,y)+half+delta).contains(0)
        points.append(y)
    for row in witness['support_witnesses']:
        points.append(tuple(map(A,row['point'])))
    assert len(points)==12

    antipodes={(i,i+3) for i in range(3)}
    worst=arb(0)
    distances=[]
    for i,j in combinations(range(len(points)),2):
        z=sub(points[i],points[j])
        d=dot(z,z)
        if (i,j) in antipodes:
            assert all(x.contains(0) for x in sub(z,hex_normals[i])) and d.contains(1)
        else:
            assert d<1,(i,j,d)
            worst=max(worst,d.upper())
            distances.append(dict(pair=[i,j],square_upper=str(d.upper())))
    assert len(distances)==63 and 1-worst>A('2.67e-6')

    guards=[]
    for i,u in enumerate(hex_normals+cap_normals):
        k=(i+3)%6 if i<6 else i
        penalty=F(0) if i<6 else F(witness['caps'][i-6]['depth'])
        assert (dot(u,points[k])+half+A(penalty)).contains(0)
        guards.append(dict(normal_degrees=str(60*i if i<6 else cuts[i-6]),point=k,
                           exact_projection=str(-F('1/2')-penalty)))

    rows=[]
    for k,entry in enumerate(witness['support_witnesses']):
        i=entry['W_face_index']
        v,w=cyclic[i]
        N,b_integer=polygon_rows[i]
        edges=[tuple(A(F(t,scale)) for t in q) for q in (v,w)]
        cap_clearance=min((half-dot(u,z)).lower() for u in P for z in edges)
        assert cap_clearance>A('.004')
        # Both original endpoints survive clipping by P, hence this bound is genuine W support.
        ell=arb(dot(N,N)).sqrt()
        u=tuple(arb(d)/ell for d in N)
        h=A(F(b_integer,scale))/ell
        index=10+k
        turn=entry['pose']
        assert turn in ('I','J60')
        p=points[index] if turn=='I' else J(points[index])
        excess=dot(u,p)-h
        assert excess>A('4.89e-5')
        opposite=mul(-1,u)
        l,=[i for i,z in enumerate(hex_normals) if cross(z,opposite)>0
            and cross(opposite,hex_normals[(i+1)%6])>0]
        r=(l+1)%6
        polar1,polar2=hex_normals[l],hex_normals[r]
        determinant=cross(polar1,polar2)
        assert determinant>0
        weights=[arb(1),cross(opposite,polar2)/determinant,cross(polar1,opposite)/determinant]
        assert all(a>0 for a in weights)
        balance=add(u,add(mul(weights[1],polar1),mul(weights[2],polar2)))
        assert all(z.contains(0) for z in balance)
        indices=[l,r] if turn=='I' else [(2-l)%6,(2-r)%6]
        for j,n in zip(indices,(polar1,polar2),strict=True):
            w=points[j] if turn=='I' else J(points[j])
            assert (dot(n,w)-half).contains(0)
        gain=excess/sum(weights)
        assert gain>A('2.32e-5')
        rows.append(dict(pose=turn,face_index=i,W_edge_integer=[v,V[(i+1)%len(V)]],
                         integer_outward_normal=list(N),unnormalized_support=str(F(b_integer,scale)),
                         exact_supporting_hex_normals_degrees=[60*l,60*r],cloud_support_points=[index,*indices],
                         face_survival_P_margin_lower=str(cap_clearance),
                         balanced_unit_normal_weights=list(map(str,weights)),
                         W_facet_height_gap_lower=str(excess.lower()),weighted_normalized_gain_lower=str(gain.lower())))
    assert [x['pose'] for x in rows]==['I','J60']
    return dict(complete=True,scope='Every diameter-one completion of this cloud lies in G; both prescribed orientations fail for every translation in W.',
                W_receipt_sha256=wsha,witness_sha256=digest(witnessfile),verifier_sha256=digest(Path(__file__)),
                python=sys.version.split()[0],flint=flint_version,precision_bits=ctx.prec,
                certified_W_area_upper=str(area),B_minus_W_lower=str(B-area),all_six_W_hexagon_supports_exact='1/2',
                point_coordinates_balls=[list(map(str,p)) for p in points],
                antipodal_pairs=sorted(antipodes),non_antipodal_squared_distance_upper=str(worst),
                diameter_slack_lower=str((1-worst).lower()),all_non_antipodal_pairs=distances,
                G_halfplane_guards=guards,balanced_violations=rows)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for n in ('W_receipt','witness','out'):parser.add_argument(n,type=Path)
    a=parser.parse_args()
    d=certify(a.W_receipt,a.witness)
    a.out.write_text(json.dumps(d,indent=2)+'\n')
    print(d['diameter_slack_lower'])
    print([(r['pose'],r['W_facet_height_gap_lower'],r['weighted_normalized_gain_lower']) for r in d['balanced_violations']])

"""Replay the midpoint envelope, the free-motion obstructions, and the six-face stability bound."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMP, OUT = (Path(x).resolve() for x in sys.argv[1:])
OUT.mkdir(parents=True, exist_ok=True)
mid = ROOT / "midpoint"
motions = ROOT / "motions"
two = ROOT / "two"
slack = ROOT / "stability"

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def compare(actual, expected):
    if actual.read_bytes() != expected.read_bytes():
        raise ValueError(f"Recomputed output differs from {expected.name}")

def replay(script, args, name, expected):
    path = OUT / name
    with path.open("w") as stream:
        subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)],
                       cwd=script.parent, check=True, stdout=stream)
    compare(path, expected)
    return path

for filename, expected in json.loads((ROOT / "manifest.json").read_bytes()).items():
    if digest(ROOT / filename) != expected:
        raise ValueError(f"Certificate input differs: {filename}")
for filename, expected in json.loads((mid / "upstream-sha256.json").read_bytes()).items():
    if digest(COMP / filename) != expected:
        raise ValueError(f"Archived upstream input differs: {filename}")
clouds = replay(mid / "verify_clouds.py", [], "clouds.json", mid / "cloud-receipt.json")
envelope = replay(mid / "certify.py", [COMP], "envelope.json", mid / "receipt.json")
subprocess.run([sys.executable, "-I", "-B", str(two / "verify_witness.py"),
                str(envelope), str(two / "witness.json"), str(OUT / "two-poses.json")], check=True)
compare(OUT / "two-poses.json", two / "verified.json")
replay(motions / "certify.py", [COMP, envelope, 24, 16384], "arc24.json", motions / "sharp24.json")
for size, inp, value, expected in [(19, "small-input.json", ".00000639490", "free-sharp.json"),
                                   (14, "compact-input.json", ".00000365", "compact-sharp.json")]:
    replay(motions / "free.py", [envelope, motions / inp, COMP, value],
           f"points{size}.json", motions / expected)
multi = replay(motions / "multi.py", [COMP, envelope], "five-and-ten.json", motions / "multi.json")
# This unmodified upstream kernel imports its sibling geometry.py.
subprocess.run([sys.executable, "-B", str(slack / "certify_relaxation.py"), str(COMP),
                str(envelope), str(multi), str(OUT / "relaxed.json")], cwd=slack, check=True)
compare(OUT / "relaxed.json", slack / "relaxed.json")
print("All eight geometry outputs match the frozen certificates.")

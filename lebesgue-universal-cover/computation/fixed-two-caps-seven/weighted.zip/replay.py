from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from argparse import ArgumentParser
import subprocess,sys,json,shutil
here=Path(__file__).resolve().parent
def sha(p):return sha256(p.read_bytes()).hexdigest()
def check(d):
    for n,h in json.loads((d/'files.json').read_text()).items():assert sha(d/n)==h,n
def run(p,*opts):subprocess.run([sys.executable,'-I','-B',str(p),*map(str,opts)],cwd=p.parent,check=True)
a=ArgumentParser();a.add_argument('work',type=Path);a.add_argument('--all',action='store_true',help='also replay all inherited positive and obstruction certificates');q=a.parse_args();assert __debug__
check(here);assert sha(here/'seven.zip')=='291406710f1016985b8356b7283a0b2602e30ee5bca45640320f951f71aa8250'
w=q.work.resolve();w.mkdir(parents=True,exist_ok=True);assert not any(w.iterdir());s=w/'seven'
with ZipFile(here/'seven.zip') as z:z.extractall(s)
check(s);old=w/'previous';run(s/'replay.py',old,*(['--all'] if q.all else []))
cp=old/'matched/kit/compulsory-pair';sc=old/'kit/compulsory-pair'
shutil.copyfile(sc/'r7-external-area.json',cp/'r7-external-area.json')
for n in ['r7_weighted_verify.py','r7-weighted.json.gz']:shutil.copyfile(here/n,cp/n)
# The current weighted proof needs the compulsory polygon itself, independently of the old roof matching.
for script,n in [('check_lenses.py','lens-base-cert.json'),('closure_exact.py','closure-certified.json')]:
    h=sha(cp/n);run(cp/script);assert h==sha(cp/n),n
run(cp/'r7_weighted_verify.py')
assert sha(cp/'r7-weighted-result.json')==sha(here/'r7-weighted-result.json')
print('Verified the fixed two-cap lower bound .844081708998457665703960.',flush=True)

from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,gzip
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
import flow_verify as v
q=json.load(gzip.open(D/'r7-weighted.json.gz','rt'));unit=F(q['unit'])*v.S
assert unit.denominator==1 and unit>0
for key in q['keys']:v.roots[key]=v.proof(key)
P=v.hull(json.loads((D/'closure-certified.json').read_text())['vertices']);roof=v.Roof(P);ys=[roof.at(x) for x in v.X];base=v.doubled(P)
seen=defaultdict(list);needed=defaultdict(dict);N=0
for i,s,j,lo,k,lo2,c in q['rows']:
    assert 0<=i<len(q['keys']) and s in [0,1] and c>0
    for h,lab,col,b in [(0,s,j,lo),(1,1-s,k,lo2)]:
        assert 0<col<len(v.X)-1 and b>=0
        tet=needed[q['keys'][i],lab];tet[col]=max(tet.get(col,0),b+c)
        seen[h,col].append((b,b+c))
    N+=c
for ls in seen.values():
    ls.sort();assert all(a[1]<=b[0] for a,b in zip(ls,ls[1:]))
for (key,s),ht in needed.items():
    r=v.Roof(v.hull(P+v.cloud(key,s)))
    for col,y in ht.items():assert r.at(v.X[col])>=ys[col]+unit*y,(key,s,col,y)
L=F(base-roof.loss()+N*unit*(v.X[1]-v.X[0]),2*v.S*v.S)
ext=json.loads((D/'r7-external-area.json').read_text());gain=min(F(g) for pp,g in ext['all']);lo=L+gain
floor=lambda x:str(x.numerator*10**24//x.denominator)+'e-24'
out=dict(roof_lower=floor(L),with_seven=floor(lo),root_profiles=len(q['keys']),layer_pairs=len(q['rows']),weighted_units=N,unit=q['unit'])
print(out,flush=True);(D/'r7-weighted-result.json').write_text(json.dumps(out,indent=1)+'\n')

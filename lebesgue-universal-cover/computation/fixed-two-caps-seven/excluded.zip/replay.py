from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json,shutil,subprocess,sys
from flint import arb
here=Path(__file__).resolve().parent
def digest(p):return sha256(p.read_bytes()).hexdigest()
def run(p,*opts):
    subprocess.run([sys.executable,'-I','-B',str(p),*map(str,opts)],cwd=p.parent,check=True)
def check(d):
    for n,h in json.loads((d/'files.json').read_text()).items():assert digest(d/n)==h,n
args=ArgumentParser();args.add_argument('work',type=Path);args.add_argument('--all',action='store_true',help='also verify historical upper-bound surveys and predecessor matching')
q=args.parse_args();assert __debug__;w=q.work.resolve();w.mkdir(parents=True,exist_ok=True);assert not any(w.iterdir());check(here)
assert digest(here/'seven.zip')=='291406710f1016985b8356b7283a0b2602e30ee5bca45640320f951f71aa8250';s=w/'seven'
with ZipFile(here/'seven.zip') as z:z.extractall(s)
check(s);old=w/'previous';run(s/'replay.py',old,*(['--all'] if q.all else []))
cp=old/'matched/kit/compulsory-pair';sc=old/'kit/compulsory-pair'
for script,n in [('check_lenses.py','lens-base-cert.json'),('closure_exact.py','closure-certified.json')]:
    h=digest(cp/n);run(cp/script);assert h==digest(cp/n),n
shutil.copyfile(sc/'r7-external-area.json',cp/'r7-external-area.json')
for n in ['r7_pan_verify.py','r7-all-domain.json.gz']:shutil.copyfile(here/n,cp/n)
run(cp/'r7_pan_verify.py');assert digest(cp/'r7-all-domain-result.json')==digest(here/'r7-all-domain-result.json')
for n in ['r7-all-domain.json.gz','r7-all-domain-result.json','closure-plan.json','common-points.json','closure-certified.json']:shutil.copyfile(cp/n,sc/n)
for script,out in [('r7_pan_wall_slack.py','r7-pan-wall-slack.json'),('r7_relaxed_anchors.py','r7-relaxed-anchors.json'),('r7_cap_budget.py','r7-cap-budget.json')]:
    shutil.copyfile(here/script,sc/script);run(sc/script);assert digest(sc/out)==digest(here/out),out
L=json.loads((cp/'r7-all-domain-result.json').read_text());B=F('.844082046521218581802948589770767704354')
assert F(L['with_seven'])>B
cap=json.loads((sc/'r7-cap-budget.json').read_text());assert arb(cap['excess_at_delta'])>0
print('Strict fixed-cap exclusion and the independent outward allowance 1.04e-7 both verified.',flush=True)

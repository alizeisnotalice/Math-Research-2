from pathlib import Path
import sys,json
from fractions import Fraction as F
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from centers import defs,g
from positive_exact import A,arb,av,ns,dt,add,mul,sub,dot
from certify_sigma_mandatory_arcs import anchors,degree
from certify_compulsory_C3 import EXTRA
g.SIGMA=degree(F('1.54'));g.PI=arb.pi();N,M,*_=g.setup();w=A('.000045');delta=A('.0000028');half=A('.5')
cc=g.line_pair(N[0],M[5]);v=add(mul(half,N[1]),mul(A('-.04'),g.rot(N[1])))
cp={'C':cc,'L':sub(cc,M[5]),'V':v,'W':sub(v,N[1]),'A':(arb(0),A('.501'))}
cp.update({f'k{i}':tuple(A(x) for x in p) for i,p in enumerate(EXTRA)})
cp.update({'J'+k:(-p[0],p[1]) for k,p in list(cp.items()) if k!='A'})
out={};weak=w*(3*g.SIGMA).cos()/16;assert weak>delta
for label in ('TI','GK','QY','C3'):
    if label=='C3':pts,phase,tr,guard=cp,1,('JC','JW','V'),(0,1)
    else:
        pts,_,phase,tr,raw=anchors(label);guard=[j for j,_ in raw]
    assert all(j%2==0 for j in set([0,1,2])-set(guard))
    cap=min(((1-w)*max((dot(M[j],p)-half).lower() for p in pts.values())-w/16).lower() for j in guard);assert cap>delta
    def dirs(a,b):return [g.unit(phase*g.PI+degree(a).union(degree(b))+2*j*g.PI/3) for j in range(3)]
    B=sum(dot(g.rot(u),pts[k]) for u,k in zip(dirs(F(0),F(0)),tr));slope=((1-w)*(B*degree(F(1)).cos()-3*half*degree(F(1)).sin())-9*w/16).lower();assert slope>0
    nodes=0;small=A(1);todo=[(F(1),F(30))]
    while todo:
        a,b=todo.pop();lo=sum(max(dot(u,p).lower() for p in pts.values()) for u in dirs(a,b))-3*half
        margin=((1-w)*lo-3*w/16).lower()
        if margin>0:small=min(small,margin);nodes+=1;continue
        assert b-a>F(1,10**7);m=(a+b)/2;todo.extend(((a,m),(m,b)))
    out[label]=dict(strong_cap=str(cap),first_degree_slope=str(slope),minimum_interval=str(small),panels=nodes)
(D/'r7-relaxed-anchors.json').write_text(json.dumps(dict(weak=str(weak),models=out),indent=1)+'\n');print('all four harmonic root checks',sum(v['panels'] for v in out.values()),flush=True)

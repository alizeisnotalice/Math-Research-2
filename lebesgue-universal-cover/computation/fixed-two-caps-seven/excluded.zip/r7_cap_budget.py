from pathlib import Path
from fractions import Fraction as F
import sys,json
from flint import arb,fmpq,ctx
ctx.prec=224
D=Path(__file__).resolve().parent
def load(n):return json.loads((D/n).read_text())
def A(x):
    p=F(x);return arb(fmpq(p.numerator,p.denominator))
L=A(load('r7-all-domain-result.json')['with_seven']);stats=load('r7-pan-wall-slack.json');V=arb(stats['mixed_area_lower']).lower();B=A('.844082046521218581802948589770767704354');u=15*arb.pi()/64
def bound(delta):
    l=A(F(45,2800)*1000)*delta
    return (1-l)**2*L+2*l*(1-l)*V+l*l*u
# lambda0/delta0=(45e-6)/(2.8e-6)=225/14.
assert A(F(45,2800)*1000).contains(A(F(225,14)))
off=A('.0000001');best=A('.000000104')
assert arb(stats['least_pentagon_cap'])>best and all(arb(v)>best for v in stats['seven_r7'].values())
out=load('r7-relaxed-anchors.json');assert arb(out['weak'])>A('.0000028')
for v in out['models'].values():assert arb(v['strong_cap'])>A('.0000028')
assert bound(best)>B and bound(off)>B
# Area expression decreases on this interval: V<L and L-2V+u<0.
assert L>V and L-2*V+u<0
rr=dict(unrelaxed=str(L),delta='0.000000104',lower_at_delta=str(bound(best)),excess_at_delta=str((bound(best)-B).lower()),round_offset='0.0000001',lower_at_round_offset=str(bound(off)),excess_at_round_offset=str((bound(off)-B).lower()),pure_angle_threshold_degrees=str((2*(best*A(3).sqrt()/2).asin()*180/arb.pi()).lower()),weight_ratio='225/14')
(D/'r7-cap-budget.json').write_text(json.dumps(rr,indent=1)+'\n');print(rr,flush=True)

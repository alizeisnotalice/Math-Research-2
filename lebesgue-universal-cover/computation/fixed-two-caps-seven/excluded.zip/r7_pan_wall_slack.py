from pathlib import Path
from fractions import Fraction as F
import sys,json,gzip
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from analytic_root import proof
from r7_fourth import A,arb,model,support,dt,av,load
from r7_repair import recover,S
from flint import ctx
ctx.prec=192
ks=set(json.load(gzip.open(D/'r7-all-domain.json.gz','rt'))['keys'])
for part in load('closure-plan.json'):
    for k,x,y in part:ks.add(k)
for r in load('common-points.json'):
    ix=F(r['w'])*1000;iy=F(r['e'])*10000;k=f'{int(ix)},{int(iy)}'
    try:proof(k)
    except (ArithmeticError,AssertionError,ValueError):continue
    ks.add(k)
cap=A(1);lim=None
for key in sorted(ks):
    v=arb(proof(key)['cap_exclusion']).lower()
    if v<cap:cap,lim=v,key
lims={};rmay=[]
for k in load('r7-external-area.json')['order']:
    g=model(k);extras=[]
    for j in range(6):
        for s in (-1,1):
            if (j,s) in [(1,-1),(5,1)]:continue
            h=support(g,j,s);v=[(h(av(dt['m'][i]))-A('.5')).lower() for i in (3,5)]
            extras.append(max(v));rmay.append((v,k,j,s))
    lims[k]=str(min(extras))
# Mixed area of the compulsory rational polygon D with the harmonic U.
# Curvature dS_U=(1-sin(3t))/2 dt. Lower step support on each angular box via the maximizing midpoint point.
p=load('closure-certified.json')['vertices'];R=1/A(3).sqrt();n=16384;z=arb.pi()/n;VV=[av([F(x,S),F(y,S)]) for x,y in p];sum0=A(0)
import math
for j in range(n):
    l=j*2*z;m=l+z;r=l+2*z;co,si=m.cos(),m.sin()
    i=max(range(len(p)),key=lambda i:float(co)*p[i][0]+float(si)*p[i][1])
    pt=VV[i]
    # Exact integral on [l,r] for this single point: cos(t), sin(t), cos(t)sin(3t), sin(t)sin(3t).
    def prim(t):
        x,y=pt
        return (x*t.sin()-y*t.cos()+x*((4*t).cos()/8+(2*t).cos()/4)-y*((2*t).sin()/4-(4*t).sin()/8))/4
    sum0+=prim(r)-prim(l)
v=(sum0.lower());assert v>A('.822')
out=dict(pentagons=len(ks),least_pentagon_cap=str(cap),limiting_profile=lim,seven_r7=lims,mixed_area_lower=str(v),common_outward_radius_upper='2.8e-6 at lambda=.000045',U_area='15*pi/64')
(D/'r7-pan-wall-slack.json').write_text(json.dumps(out,indent=1)+'\n');print(out,flush=True)

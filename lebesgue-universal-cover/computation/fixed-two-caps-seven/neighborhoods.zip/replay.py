from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import shutil,subprocess,sys,json
D=Path(__file__).resolve().parent
def sha(p):return sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((D/'files.json').read_text()).items():assert sha(D/n)==h
assert sha(D/'five.zip')=='f0ceb3743f35e105e6ca536a2b3aea7fae11421edf47a0ee7ce5c1cf5f8f6ca9'
w=Path(sys.argv[1]).resolve();w.mkdir(parents=True,exist_ok=True);assert not any(w.iterdir())
with ZipFile(D/'five.zip') as z:z.extractall(w/'previous')
subprocess.run([sys.executable,'-I','-B',str(w/'previous/replay.py'),str(w/'run')],check=True)
c=w/'run/kit/compulsory-pair';shutil.copyfile(D/'r7_neighborhoods.py',c/'r7_neighborhoods.py')
subprocess.run([sys.executable,'-I','-B',str(c/'r7_neighborhoods.py')],cwd=c,check=True)
for n in ['r7-open-host.json','r7-open.json']:assert sha(c/n)==sha(D/n)
print('Verified the five general width-one Hausdorff neighborhoods and their 403-vertex B-budget polygon.')

from pathlib import Path
from fractions import Fraction as F
import sys,json
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
from r7_fourth import A,arb,ns,av,dt,dot,model,support,load,S
from r7_true_area import calc
sc=F(100000065,100000000);spec=load('r7-reshape-five.json')
# Change wall normals to retain exact integer offsets at the original lattice scale.
scaled={**spec,'facets':[[a*sc.denominator,b*sc.denominator,c*sc.numerator] for a,b,c in spec['facets']]}
(D/'r7-open-host.json').write_text(json.dumps(scaled,separators=(',',':'))+'\n')
area=calc('r7-open-host.json');alpha=A('.000000105');mind=A(1);results={}
for name in spec['R7_poses']:
    g=model(name);T=g['T'];r=g['roots'][0];h=g['h'];pol=g['polar']
    def compat(t):return h(pol(t))-h(pol(t+T))+h(pol(t+2*T))-A('.5')
    l,u=compat(r-alpha),compat(r+alpha);assert (l<0 and u>0) or (l>0 and u<0)
    m=min(abs(l).lower(),abs(u).lower());p=support(g,*spec['R7_poses'][name])
    cap=min((A('.5')-p(av(dt['m'][j]))).lower() for j in (3,5))
    generic=A(F(sc-1,2));assert all((A(F(c,S))**2)*4 >= A(a*a+b*b) for a,b,c in spec['facets'])
    # Placed K' lies within 3(delta+alpha) of the original pinned placement.
    delta=min((m/3).lower(),(min(generic,cap)/3-alpha).lower());assert delta>0
    mind=min(mind,delta);results[name]=dict(left=str(l),right=str(u),cap=str(cap),distance_lower=str(delta))
print('delta',mind,'area',area,flush=True)
(D/'r7-open.json').write_text(json.dumps(dict(root_window=str(alpha),circumradius_about_origin='1',uniform_Hausdorff_distance_lower=str(mind),generic_dilation=str(sc),true_polygon=area,bodies=results),indent=1)+'\n')

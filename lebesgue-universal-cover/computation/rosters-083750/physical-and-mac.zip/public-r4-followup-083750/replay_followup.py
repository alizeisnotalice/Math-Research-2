"""Reproduce the physical-Q 67/80 census, source bindings and closed-frontier coverage."""
from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
PIN248='4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d'
PIN251='84f8de1fed4a4e116601ff511a212de04f586767e935a77161401f13fa5ba169'
PIN_R4='49ee0eb63126b08733e88d5aa921aea2e51ca2eb0f4d7152e2d5711e508b9f86'
PHYSICAL='2486b4ae79866e86d219173b7c49b3672bbecb48885d88e1e5308a2e2d971aba'
MAC=(
    ('181',55,'mac-181-replay.zip','f5da6f62a624c2febb3550780217ccf3cf65e2ea6d7fdbbfccbd1c8efaa6a18a'),
    ('120x',14,'mac-1201-1205-replay.zip','54e51a92d14a8a03496fb5e1017b647e275430f8eafe1c8738f2ad8346b3e77f'),
    ('120x-02',24,'mac-1201-1205-replay-02.zip','511896cc1946ac062237022de8688c7de5d4d20300c15bb4303cbd889cedf817'),
)


def extract(path,pin,root):
    assert sha256(path.read_bytes()).hexdigest()==pin,path
    with ZipFile(path) as bundle:
        names=bundle.namelist()
        assert len(set(names))==len(names) and bundle.testzip() is None
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names)
        bundle.extractall(root)


def run(script,*args):
    subprocess.run([sys.executable,'-I','-B',str(script),*map(str,args)],check=True)


def same(result,expected):
    assert result.read_bytes()==expected.read_bytes(),result.name


def main(a):
    work=a.work.resolve()
    work.mkdir(parents=True,exist_ok=False)
    extract(a.r248,PIN248,work/'dependencies-248')
    extract(a.r251,PIN251,work/'dependencies-251')
    extract(a.r4,PIN_R4,work/'dependencies-r4')
    r248=work/'dependencies-248/public-replay-r2-083750'
    r251=work/'dependencies-251/public-replay-r3-083750'
    r4=work/'dependencies-r4/public-replay-r4-083750'
    comp=a.comp.resolve()
    evidence=r4/'evidence'
    expected=HERE/'frozen'

    physical_dir=work/'physical-shards-source'
    extract(HERE/'evidence/physical-shards-confirmed.zip',PHYSICAL,physical_dir)
    avg=evidence/'p128/ordinary-bank.json.gz'
    physical=evidence/'physical-q-bank/physical-bank.json.gz'
    avg_json=work/'average-bank.json'
    avg_json.write_bytes(decompress(avg.read_bytes()))
    physical_json=work/'physical-bank.json'
    run(evidence/'physical-q-bank/physical_rows.py',avg_json,comp/'multi-host-points.json',
        physical_json,work/'physical-bank-audit.json','--subdivisions',4)
    assert physical_json.read_bytes()==decompress(physical.read_bytes())
    same(work/'physical-bank-audit.json',evidence/'physical-q-bank/physical-check.json')
    row_audit=work/'audited-physical-shards.json'
    run(HERE/'audit_physical_shards.py',evidence/'shards15',physical_dir,avg,physical,row_audit)
    same(row_audit,expected/row_audit.name)

    reports=[]
    for family,count,archive,pin in MAC:
        source=work/('mac-source-'+family)
        extract(HERE/'evidence'/archive,pin,source)
        out=work/f'mac-{count}-audit.json'
        run(HERE/'audit_mac_full.py',comp,a.tree.resolve(),r248,source,out,'--phase-family',family)
        same(out,expected/out.name)
        reports.append(out)

    ledger=work/'ledger.json'
    run(HERE/'merge_models.py',r248,r251,r4/'frozen/shape-bank-audit.json',
        r4/'frozen/audited-increment.json',ledger,'--physical',row_audit,'--mac',*reports)
    same(ledger,expected/'ledger.json')

    prior=json.loads((r4/'frozen/ledger.json').read_bytes())
    current=json.loads(ledger.read_bytes())
    p=prior['model_census']['all_archived_inputs']
    q=current['model_census']['all_archived_inputs']
    assert current['scope']==5442 and len(current['all_256_model_counts'])==256
    assert (p['remaining'],q['remaining'])==(587,519)
    assert set(q['unresolved']) < set(p['unresolved'])
    print('verified 93 exact R248 roots, the 15 physical-Q shards and all 256 fixed-input models',
          flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for key in ('comp','tree','r248','r251','r4','work'):
        parser.add_argument(key,type=Path)
    main(parser.parse_args())

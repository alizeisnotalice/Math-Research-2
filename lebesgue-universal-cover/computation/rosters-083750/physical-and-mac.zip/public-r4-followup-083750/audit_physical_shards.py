"""Match each physical-Q run to the exact P128/Qavg frozen original frontier."""
from argparse import ArgumentParser
from collections import Counter
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path

def read(p):return json.loads(p.read_bytes())
def raw(p):return decompress(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()

def main(a):
    s=json.loads(raw(a.shards/'shards.json.gz'))
    summary=read(a.physical/'summary.json')
    corrected=raw(a.bank)
    assert sha256(corrected).hexdigest()==summary['physical_bank']=='97d2d0c35d74dedb0577ac4d9311e1bf9cdb0cd827fdadae07a86d70438f0223'
    x=json.loads(corrected)
    avg=json.loads(raw(a.avg_bank))
    assert x['directions']==avg['directions'] and x['knots']==avg['knots']==384
    assert x['cells'][:384]==avg['cells'][:384]
    d=[]
    for actual,old in zip(x['cells'][384:],avg['cells'][384:],strict=True):
        for row,former in zip(actual,old,strict=True):
            assert row[:7]==former[:7]
            d.append(former[7]-row[7])
    assert len(d)==12885 and Counter(d)=={0:12786,1:99}
    actual=[json.loads(line) for line in raw(a.physical/'receipts.jsonl.gz').splitlines()]
    used=[]
    by_key={}
    for key,record in s['entries'].items():
        part=key.split('/')[0]
        if s['parts'][part]['transfer']=='P128':
            assert all(y['oldQ']==0 for y in record['subtrees'])
            continue
        needed=record['subtrees']
        used.extend(needed)
        q=sum(y['oldQ']for y in needed)
        if q:
            by_key[key]=dict(physical_old_Q11_terminals=q,frontiers=len(needed))
    assert actual==used and len(actual)==summary['physical_subtrees']==2432
    total=Counter()
    for row in actual:
        r=row['out']
        assert r[0]==1 and r[1]==2*(r[2]+r[3])-1 and row['target']=='67/80'
        assert row['front'] is None and not row['paired'] and r[3]==row['P128']+row['oldQ']
        total['visits']+=r[1];total['five']+=r[2]
        total['p128']+=row['P128'];total['physical_old_Q11']+=row['oldQ']
    assert [total['visits'],total['five'],total['p128']+total['physical_old_Q11']]==summary['physical_totals']
    assert total['p128']==summary['physical_p'] and total['physical_old_Q11']==summary['physical_q']
    assert sum(len(v['subtrees'])for v in s['entries'].values())-len(actual)==104
    assert len(s['pure_replacements'])==2 and len(s['parts'])==15
    out=dict(target='67/80',strict=True,rechecked_physical_boxes=len(actual),
        permitted_average_Q_terminations_with_separate_physical_proof=by_key,
        corrected_physical_bank_sha256=summary['physical_bank'],integer_row_reductions=dict(Counter(d)),
        packed_physical_counts=total,shards_sha256=digest(a.shards/'shards.json.gz'),
        physical_receipts_sha256=digest(a.physical/'receipts.jsonl.gz'))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(len(by_key),len(actual),dict(total),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('shards','physical','avg_bank','bank','output'):
        p.add_argument(n,type=Path)
    main(p.parse_args())

"""Compute exact fixed-input model censuses from R248, R251 and newer 67/80 evidence."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path

P,R,Q,A,N,C,D,W=(
    'original_P30','replacement_P30','physical_old_Q11','average_Q11',
    'new_Q11','reduced_P66','augmented_P128','P152_interior15')
ORDER=(P,R,Q,A,N,C,D,W)
BIT={name:1<<i for i,name in enumerate(ORDER)}
MASK=sum(BIT.values())

def read(p):
    return json.loads(p.read_bytes())

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def numerical(ids):
    return sorted(ids,key=lambda k:tuple(map(int,k.split('/'))))

def mask(seq):
    return sum(BIT[k] for k in set(seq))

def implication(allowed):
    # Entailments concern these archived support predicates, not equality of
    # geometrical inputs. Qavg has precisely the material points used after
    # reflected averaging, with one integer unit available from the old bound.
    if allowed&BIT[D]:
        allowed |= BIT[C]|BIT[R]
    if allowed&BIT[C]:
        allowed |= BIT[R]
    if allowed&BIT[R]:
        allowed |= BIT[P]
    if allowed&BIT[A]:
        allowed |= BIT[Q]
    return allowed

def residuals(raw,inputs):
    available=implication(mask(inputs))
    return set(key for key,qs in raw.items() if not any(m&~available==0 for m,_ in qs))

def baseline(r248,r251):
    old=r248/'joined-r2-plus-five-index.json'
    old_obj=read(old)
    stage=read(r248/'stage4-retained.json')
    assert sha(old)=='65b4ab38358276aed105897686075377468b4443bd6d74556b272d28df973966'
    assert sha(r248/'stage4-retained.json')=='06c7b4202f85d404c5e04cd53d19f4e4bd51a81da8e355e85f1f05a2913dcbc0'
    assert old_obj['target']=='67/80' and old_obj['strict'] and old_obj['stage4_retained']==5442
    out={}
    for part,z in old_obj['parts'].items():
        check=[n for family in ('five','P30','Q11','remaining') for n in z[family]]
        assert len(check)==len(set(check)) and sorted(check)==stage[part]
        for label in ('five','P30','Q11','remaining'):
            for n in z[label]:
                tags=() if label=='five' else (P,) if label=='P30' else (
                     (Q,) if n in z['Q11_without_P30'] else (P,Q))
                key=f'{part}/{n}';assert key not in out
                out[key]=[] if label=='remaining' else [(mask(tags),'R248/wave2')]
    assert len(out)==5442
    new=read(r248/'new-p30/joined-ab.json')
    assert new['target']=='67/80' and new['strict'] and new['point_set_sha256']==sha(r248/'new-p30/points.json')
    additions=new['certified_in_originally_unclosed']
    assert len(additions)==len(set(additions))==10
    for k in additions:
        out[k].append((BIT[R],'R248/new-P30'))
    rename={'P30':P,'newP30':R,'oldQ11':Q,'newQ11':N}
    q=read(r251/'new-q-package/joint-manifest.json')
    assert q['target']=='67/80' and q['strict'] and q['incremental']==len(q['leaves'])==59
    for k,record in q['leaves'].items():
        out[k].append((mask(rename[x] for x in record['whole']['extra_inputs']),'R248/join59'))
    tail=read(r251/'integrated-additions.json')
    assert tail['target']=='67/80' and tail['strict'] and len(tail['proved'])==39
    for v in tail['proved']:
        out[v['leaf']].append((mask(rename[x] for x in v['extra_inputs']),'R251/refinement39'))
    old_ledger=r251/'final-ledger.json'
    assert sha(old_ledger)=='19daf305bec5529d5ed24ec6141fec573a18e8df585abf7ec878e06825d8fadf'
    anch=read(old_ledger)
    assert anch['target']=='67/80' and anch['strict'] and anch['scope']==len(out)
    for name,row in anch['models'].items():
        assert residuals(out,[rename[x] for x in row['inputs']])==set(row['unresolved']),name
    return out,stage,anch

FOCAL={
    'five_curves':(),
    'original_P30':(P,),
    'original_P30_old_Q11':(P,Q),
    'original_P30_old_and_new_Q11':(P,Q,N),
    'replacement_P30':(R,),
    'replacement_P30_old_Q11':(R,Q),
    'replacement_P30_old_and_new_Q11':(R,Q,N),
    'physical_old_Q11':(Q,),
    'average_Q11':(A,),
    'reduced_P66':(C,),
    'reduced_P66_old_Q11':(C,Q),
    'reduced_P66_Qavg':(C,A),
    'reduced_P66_Qavg_new_Q11':(C,A,N),
    'augmented_P128':(D,),
    'augmented_P128_old_Q11':(D,Q),
    'augmented_P128_old_and_new_Q11':(D,Q,N),
    'augmented_P128_Qavg':(D,A),
    'augmented_P128_Qavg_new_Q11':(D,A,N),
    'augmented_P128_Qavg_old_and_new_Q11':(D,A,Q,N),
    'P152_only':(W,),
    'P152_old_Q11':(W,Q),
    'P152_with_replacement_P30_old_and_new_Q11':(W,R,Q,N),
    'P152_with_P128_old_Q11':(W,D,Q),
    'P152_with_P128_Qavg':(W,D,A),
    'P152_with_P128_Qavg_new_Q11':(W,D,A,N),
    'all_archived_inputs':ORDER,
}

def main(a):
    base,stage,anchor=baseline(a.r248,a.r251)
    bank=read(a.shapes)
    assert bank['target']=='67/80' and bank['legacy_rows']==2493
    assert bank['minimum_p66_minus_replacement_ticks']>=0 and bank['p66_subset_p128']
    assert bank['replacement_p30_subset_p128'] and bank['old_q_legacy_penalty_ticks']==1
    assert bank['p66_using_128_shard_rows']['impossible_rows_with_exact_endpoint_witness']
    assert all(x['impossible_rows_with_exact_endpoint_witness'] for x in bank['physical_q_using_average_rows'])
    v=read(a.delta)
    assert v['target']=='67/80' and v['strict']
    roots=set(base)
    added={k:set(v[k]) for k in ('shards','neighbors','p152')}
    assert len(added['shards'])==167 and len(added['neighbors'])==12 and len(added['p152'])==2
    first11=set(v['shards11_keys'])
    pure={k for k,e in v['shards'].items() if e['source']=='shards.json.gz/pure_replacements'}
    assert len(first11)==53 and len(pure)==2 and not pure&first11
    assert roots.issuperset(set.union(*added.values()))
    def stage_ledger(f):
        out={k:v.copy() for k,v in base.items()}
        for source,indices in f:
            for k in indices:
                row=v[source][k]
                out[k].append((mask(row['inputs']),source))
        return out
    after11=stage_ledger([('neighbors',added['neighbors']),('shards',first11|pure)])
    after15=stage_ledger([('neighbors',added['neighbors']),('shards',added['shards'])])
    without_mac=stage_ledger([('neighbors',added['neighbors']),('shards',added['shards']),('p152',added['p152'])])
    final={k:rows.copy() for k,rows in without_mac.items()}
    physical_keys=set()
    if a.physical:
        physical=read(a.physical)
        assert physical['target']=='67/80' and physical['strict']
        assert physical['shards_sha256']==v['source_sha256']['shards15']
        assert physical['rechecked_physical_boxes']==2432
        assert physical['integer_row_reductions']=={'0':12786,'1':99}
        extra=physical['permitted_average_Q_terminations_with_separate_physical_proof']
        physical_keys=set(extra)
        assert physical_keys=={k for k,row in v['shards'].items() if A in row['inputs']}
        for key,record in extra.items():
            row=v['shards'][key]
            assert row['support_terminal_counts'][A]==record['physical_old_Q11_terminals']>0
            actual=[Q if tag==A else tag for tag in row['inputs']]
            final[key].append((mask(actual),'shards/physical-Q-rerun'))
    mac_keys=set()
    for packet_no,p in enumerate(a.mac,1):
        report=read(p)
        assert report['target']=='67/80' and report['strict']
        ids=set(report['proved'])
        assert ids.isdisjoint(mac_keys) and ids<=residuals(final,(D,A,N,W))
        for leaf,row in report['proved'].items():
            assert row['inputs']==[Q]
            final[leaf].append((BIT[Q],f'mac-physical-Q-{packet_no:02}'))
        mac_keys.update(ids)
    def counts(raw):
        return {k:len(residuals(raw,inputs)) for k,inputs in FOCAL.items()}
    models={}
    opens={}
    for k,inputs in FOCAL.items():
        g=residuals(final,inputs)
        opens[k]=g
        models[k]=dict(inputs=list(inputs),closed=len(roots)-len(g),remaining=len(g),unresolved=numerical(g))
    full_parts={}
    for part,z in sorted(v['full_shard_audit'].items(),key=lambda pair:int(pair[0])):
        members={f'{part}/{n}' for n in stage[part]}
        assert len(members)==z['stage4']
        allowed=(D,) if z['family']=='P128' else (D,A)
        name='augmented_P128' if len(allowed)==1 else 'augmented_P128_Qavg'
        assert not members&opens[name]
        full_parts[part]=dict(scope=len(members),actual_family=list(allowed))
        if a.physical and A in allowed:
            assert not members&opens['augmented_P128_old_Q11']
            full_parts[part]['independently_replayed_family']=[D,Q]
    @lru_cache(maxsize=None)
    def digest_residual(available):
        items=numerical(key for key,qs in final.items() if not any(u&~available==0 for u,_ in qs))
        return len(items),sha256(('\n'.join(items)+'\n').encode()).hexdigest()
    census={}
    for i in range(MASK+1):
        n,h=digest_residual(implication(i))
        census[f'{i:02x}']=dict(allowed=[p for p in ORDER if i&BIT[p]],closed=5442-n,remaining=n,
                               unresolved_sha256=h)
    order=['original_P30_old_and_new_Q11','replacement_P30_old_and_new_Q11',
           'augmented_P128_old_and_new_Q11','augmented_P128_Qavg_new_Q11',
           'P152_with_P128_Qavg_new_Q11']
    cells=defaultdict(list)
    for key in numerical(roots):
        bits=''.join('1' if key in opens[k] else '0' for k in order)
        cells[bits].append(key)
    assert sum(map(len,cells.values()))==5442
    both={'original':set(anchor['models']['original_with_both_Q']['unresolved']),
          'replacement':set(anchor['models']['replacement_with_both_Q']['unresolved'])}
    overlap={name:{'neighbors':numerical(source&added['neighbors']),
                   'shards11':numerical(source&first11),
                   'shards15':numerical(source&(added['shards']-pure)),
                   'p152':numerical(source&added['p152']),
                   'mac_physical_old_Q':numerical(source&mac_keys)} for name,source in both.items()}
    def desc(raw):
        return {name:dict(closed=5442-n,remaining=n) for name,n in counts(raw).items()}
    data=dict(target='67/80',strict=True,scope=5442,bit_order=list(ORDER),baseline_round=251,
              support_transfer_rules={P:[R,C,D],R:[C,D],C:[D],Q:[A]},
              model_census=models,all_256_model_counts=census,
              snapshot_counts={'R251':desc(base),'neighbors_and_11_shards':desc(after11),
                               'neighbors_and_15_shards':desc(after15),'also_P152':desc(without_mac),'current':desc(final)},
              exact_overlap_with_R251_residual=overlap,complete_source_shards=full_parts,
              residual_joint_cells={'order':order,'membership':dict(sorted(cells.items()))},
              proof_masks_by_leaf={k:[dict(required=[x for x in ORDER if m&BIT[x]],source=name)
                                      for m,name in final[k]] for k in numerical(roots)},
              source_sha256={'R248_index':sha(a.r248/'joined-r2-plus-five-index.json'),
                             'R251_index':sha(a.r251/'final-ledger.json'),
                             'verified_additions':sha(a.delta),'fixed_input_comparison':sha(a.shapes),
                             'mac_attachments':[sha(p) for p in a.mac]})
    if a.physical:
        data['source_sha256']['physical_shards']=sha(a.physical)
        data['independent_physical_shard_alternatives']=numerical(physical_keys)
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:v['remaining'] for k,v in models.items()}),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('r248','r251','shapes','delta','output'):
        p.add_argument(k,type=Path)
    p.add_argument('--mac',type=Path,nargs='*',default=[])
    p.add_argument('--physical',type=Path)
    main(p.parse_args())

# Two fixed-family feasibility certificates

Both models contain the unit-diameter disk and regular Reuleaux 3, 5, 7 and 9 bodies, each independently moved. Eight adds replacement P30, physical old Q11 and new Q11. Nine adds P128, reflected-average Q11, new Q11 and the P152 fifteen-point subset. Point sets, integer denominators and original source SHA-256 values are in `inputs.json` and the relative `inputs/` files. Each verifier run checks the hashes, point coordinates, denominators and exact point-pair diameter inequalities.

For the recorded decimal-rational poses, a rigorous 160-bit Arb computation and rational outer hull error give the following upper bounds for the areas of the common convex hulls:

* Eight: 9798324352516701514114732844486155871483/11694053485707264000000000000000000000000, approximately 0.8378894764328242.
* Nine: 9803750195878670138614247856388342392059/11694053485707264000000000000000000000000, approximately 0.8383534595477125.

Each is an upper bound on the minimum for its fixed finite family. Neither is below 67/80; neither is an upper bound for the universal covering problem. The point-cloud frame uses raw coordinates, and a y-reflection precedes rotation. Circular arcs are enclosed using 16384 segments per unit arc and an explicit rational area remainder. The audits retain exact bounds, verifier hashes and run versions.

Replay from this directory using Python 3 with python-flint (the recorded run used Python 3.12.14 and python-flint 0.9.0):

```sh
python3 exact_area.py verifier inputs/replacement.json eight/recipe-cpufit.json eight/replay.json
python3 exact_area.py verifier inputs/replacement.json nine/recipe-gpucpufit.json nine/replay.json
```

Each output has exact rational endpoints. These commands create only the two replay JSON files and Python bytecode cache. Verify supplied file hashes with `python3 verify_manifest.py`. `hardware.json` and the nine small GPU logs distinguish the initial and subsequent batches and count each only once. GPU float32 and CPU float64 search values were proposals; the strict output does not depend on GPU rounding. A previous different nine-body model supplied one starting pose; its GPU search is explicitly listed separately in the hardware record.

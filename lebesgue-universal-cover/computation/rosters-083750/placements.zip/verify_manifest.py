from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
for k,v in json.loads((r/'SHA256.json').read_text()).items():
 assert hashlib.sha256((r/k).read_bytes()).hexdigest()==v,k
print('verified')

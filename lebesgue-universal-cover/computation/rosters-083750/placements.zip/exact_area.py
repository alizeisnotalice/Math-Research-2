"""Strict area and containment for exact rational poses of five curved bodies and named clouds."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
import platform
import sys

from flint import arb,ctx
import flint

def data(comp, ignored):
    root=Path(__file__).resolve().parent
    table=json.loads((root/'inputs.json').read_text())['clouds']
    out={}
    for name,r in table.items():
        raw=(root/r['source']).read_bytes()
        assert sha256(raw).hexdigest()==r['sha256']
        den=r['denominator'];pts=r['points']
        source=json.loads(raw)
        assert pts==source['points'] and den==source.get('denominator',source.get('point_denominator'))
        diam=max(sum((x-y)**2 for x,y in zip(a,b)) for a in pts for b in pts)
        assert diam<=den*den
        out[name]={'points':[[F(x,den) for x in p] for p in pts], 'center':[F(0),F(0)], 'sha256':r['sha256'], 'diameter_square':F(diam,den*den)}
    return out

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def placed(group,pose,ar):
    a,tx,ty,sg=map(F,pose)
    assert sg in (1,-1)
    sn,cs=ar(a).sin_cos()
    cx,cy=map(ar,group['center'])
    xx,yy=ar(tx),ar(ty)
    out=[]
    for x,y in group['points']:
        dx,dy=ar(x)-cx,(ar(y)-cy)*int(sg)
        out.append((xx+cs*dx-sn*dy,yy+sn*dx+cs*dy))
    return out

def main(args):
    sys.path.insert(0,str(args.comp.resolve()))
    from certify_nine import S, append_point, ar, arc_body, hull
    ctx.prec=160
    pi=arb.pi()
    pip=F(22,7)
    assert pi<ar(pip)
    inputs=data(args.comp,args.new_cloud)
    cases=json.loads(args.recipe.read_bytes())
    out={}
    for name,r in cases.items():
        p=r['host']
        k=r.get('degree',args.degree)
        assert type(k) is int and k>=64
        vals=list(map(ar,p['five']))
        assert len(vals)==11
        nodes=[]
        for i in range(8*k):
            t=i*pi/(4*k)
            append_point(nodes,t.cos()/2,t.sin()/2)
        arc_body(nodes,k,pi,3,arb(0),*vals[:2])
        for n,i in ((5,2),(7,5),(9,8)):
            arc_body(nodes,k,pi,n,*vals[i:i+3])
        for label,where in p.get('add',{}).items():
            for x,y in placed(inputs[label],where,ar):
                append_point(nodes,x,y)
        poly=hull(nodes)
        edges=[]
        perim=0
        cross=0
        for (x,y),(v,w) in zip(poly,poly[1:]+poly[:1],strict=True):
            nx,ny=w-y,x-v
            square=nx*nx+ny*ny
            d=isqrt(square)
            perim+=d+(d*d<square)
            cross+=x*w-y*v
            edges.append((nx,ny,ar(F(nx*x+ny*y,S+4)),arb(square).sqrt()))
        # The rounded inner hull H' = S/(S+4) H lies inside the true hull
        # by its contained radius-half disk, since the node error is < 2/S.
        eps=F(2,S)+pip**2/(72*k*k)
        low=F(cross,2*(S+4)**2)
        up=F(cross,2*S**2)+F(perim,S)*eps+pip*eps*eps
        radius=F(59,100)
        if not all(F(x*x+y*y,S*S)<(radius-eps)**2 for x,y in poly):
            radius=F(7,10)
            assert all(F(x*x+y*y,S*S)<(radius-eps)**2 for x,y in poly)
        assert 0<low<up
        if 'target_area' in r:
            assert up<F(r['target_area']),(name,float(up))
        results={}
        for label,spec in r.get('inside',{}).items():
            clearance=F(spec['clearance'])
            assert clearance>=0
            pts=placed(inputs[label],spec['pose'],ar)
            least=arb(1)
            for nx,ny,b,l in edges:
                candidate=(b-max((nx*x+ny*y).upper() for x,y in pts))/l
                least=min(least,candidate.lower())
            assert least>ar(clearance),(name,label,least,clearance)
            results[label]={'pose':spec['pose'],'clearance_strict_lower':str(clearance),'arb_lowest':str(least)}
        out[name]={'host':p,'fixed':r.get('fixed'),'degree':k,'sample_count':len(nodes),'grid_hull_vertices':len(poly),
                   'area_lower':str(low),'area_upper':str(up),'display':[float(low),float(up)],'fit':results,
                   'radius_upper':str(radius),'grid_hull_sha256':sha256(json.dumps(poly,separators=(',',':')).encode()).hexdigest()}
        print(name,float(low),float(up),[(k,x['arb_lowest']) for k,x in results.items()],flush=True)
    refs={'certify_nine.py':digest(args.comp/'certify_nine.py')}
    args.out.write_text(json.dumps({'recipe_sha256':digest(args.recipe),'verifier_sha256':digest(Path(__file__)),
        'pose_source_sha256':refs,'cloud_sha256':{k:r['sha256']for k,r in inputs.items()},
        'cloud_diameter_square':{k:str(r['diameter_square'])for k,r in inputs.items()},
        'frame':'all clouds raw; rotation is in radians; y reflection precedes rotation',
        'python':platform.python_version(),'flint':flint.__version__,'prec':ctx.prec,'cases':out},indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('comp','new_cloud','recipe','out'):p.add_argument(k,type=Path)
    p.add_argument('--degree',type=int,default=4096)
    main(p.parse_args())

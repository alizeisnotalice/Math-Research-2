"""Check physical-old-Q-only MacBook child results against the exact R248 frontier."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
from importlib.util import spec_from_file_location,module_from_spec
import json
from pathlib import Path
import sys

def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(line) for line in p.read_bytes().splitlines()]

def main(a):
    src=a.mac
    assert digest(src/'q-original-angles.json')=='c956e535ab0ed2bdc0a289c388ce88cf7a26132a356b6adb2076b36d508ef93a'
    assert digest(a.comp/'multi-host-points.json')=='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
    packet=read(src/'packet.json')
    keys=read(src/'keys.json')
    assert keys==[x['leaf'] for x in packet] and len(set(keys))==len(keys)
    assert [b for x in packet for b in x['regions']]==read(src/'subboxes.json')
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import SourceTree,FINE
    tree=SourceTree(a.tree)
    sp=spec_from_file_location('r248_paths',a.r248/'audit_refined_scope.py');auth=module_from_spec(sp);sp.loader.exec_module(auth)
    data={};attempted={};stats=Counter()
    inputs={name:digest(src/name) for name in ('keys.json','subboxes.json','packet.json','q-original-angles.json','run_neighbors.py')}
    for i,x in enumerate(packet):
        key=keys[i]
        output=src/f'result-{i:02}.jsonl'
        assert (src/f'exit-{i:02}').read_text().strip()=='0'
        names=x['source'].split('/')
        p=a.r248/'refined'/f'{names[0]}.jsonl'
        assert digest(p)==read(p.with_name(p.stem+'-receipt.json'))['result_sha256']
        sourceid,r=next((i,y) for i,y in enumerate(rows(p),1) if y['leaf']==key)
        assert r['goal']=='67/80' and r['threshold_integer']==120696470013529293
        assert not (r['stats'][0] or r['stats'][3] or r['stats'][5] or r['guards'] or r['pending_visited'])
        assert r['stats'][7]==1 and r['stats'][4]>0
        ref=tree.leaf(*map(int,key.split('/')))
        assert all(a*FINE==l and b*FINE==h for (a,b),(l,h) in zip(ref,zip(r['lo'],r['hi'],strict=True),strict=True))
        f=a.r248/'refined/frontiers'/x['source']
        assert digest(f)==x['frontier_sha256'] and read(f)==x['regions']
        assert auth.audit_paths(r,x['regions'])>0
        ny=rows(output)
        assert len(ny)==r['pending']==len(x['regions'])
        assert r['stats'][1]==2*sum(r['stats'][2:6])+len(ny)-1
        n,t,q=r['stats'][1],r['stats'][2],r['stats'][4]
        pending=[]
        for child,y in zip(x['regions'],ny,strict=True):
            assert y['leaf']==key and y['label']==child['label']
            assert child['bounds']==[list(x) for x in zip(y['lo'],y['hi'],strict=True)]
            assert y['goal']=='67/80' and y['threshold_integer']==120696470013529293
            assert y['mode']==1 and not (y['stats'][3] or y['stats'][5] or y['guards'] or y['center_stops'])
            assert y['q_mesh'] and y['panels']==256 and y['q_trigger_divisor']==4000 and y['shared_angles']
            v,node,nf,_,nq,_=y['stats'][:6]
            assert v in (0,1) and 1<=node<=y['budget']
            stats['closed_boxes']+=v;stats['boxes']+=1;stats['nodes']+=node
            if not v:
                pending.append(y['label'])
                continue
            assert node==2*(nf+nq)-1 and y['pending']==0
            n+=node;t+=nf;q+=nq
        attempted[key]=pending
        inputs[output.name]=digest(output)
        if not pending:
            assert n==2*(t+q)-1 and q>0
            data[key]=dict(inputs=['physical_old_Q11'],nodes=n,five_terminals=t,old_q_terminals=q,
                           source=p.name,source_line=sourceid,frontier=x['source'],
                           frontier_sha256=x['frontier_sha256'],mac_receipt=output.name)
    a.out.write_text(json.dumps(dict(target='67/80',strict=True,proved=data,exact_counts=stats,
              remaining_subboxes_by_leaf=attempted,source_sha256=inputs),indent=2)+'\n')
    print(dict(scope=len(keys),whole=len(data),counts=stats,proved=list(data)),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','mac','out'):
        p.add_argument(name,type=Path)
    main(p.parse_args())

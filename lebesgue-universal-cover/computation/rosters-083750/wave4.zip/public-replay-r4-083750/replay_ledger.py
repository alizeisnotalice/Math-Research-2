"""Rebuild the strict 67/80 census directly from the two published base archives."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
PIN248='4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d'
PIN251='84f8de1fed4a4e116601ff511a212de04f586767e935a77161401f13fa5ba169'
 
def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def extract(path,pin,root):
    assert digest(path)==pin
    with ZipFile(path) as z:
        assert z.testzip() is None
        assert all(not Path(s).is_absolute() and '..' not in Path(s).parts for s in z.namelist())
        z.extractall(root)

def same(left,right):
    assert left.read_bytes()==right.read_bytes(),left.name

def main(a):
    w=a.work.resolve()
    w.mkdir(parents=True,exist_ok=False)
    extract(a.r248,PIN248,w/'dependencies-248')
    extract(a.r251,PIN251,w/'dependencies-251')
    r248=w/'dependencies-248/public-replay-r2-083750'
    r251=w/'dependencies-251/public-replay-r3-083750'
    comp,tree=a.comp.resolve(),a.tree.resolve()
    evid=HERE/'evidence'
    frozen=HERE/'frozen'
    def run(script,*args,stdout=None):
        subprocess.run([sys.executable,'-I','-B',str(HERE/script),*map(str,args)],
                       cwd=HERE,check=True,stdout=stdout)
    with (w/'qavg-transfer.json').open('w') as out:
        run('evidence/p66/verify_qavg_transfer.py',comp,evid/'p128',
            evid/'neighbors/targeted/q-original-angles.json',stdout=out)
    same(w/'qavg-transfer.json',frozen/'qavg-transfer.json')
    run('audit_shape_banks.py',comp,r248,evid/'p128',evid/'p66/reduced66.json',
        w/'qavg11.json',w/'shape-bank-audit.json')
    for name in ('qavg11.json','shape-bank-audit.json'):
        same(w/name,frozen/name)
    run('audit_increment.py',comp,tree,r248,r251,evid/'shards11',evid/'shards15',
        evid/'neighbors',evid/'p152',w/'audited-increment.json')
    same(w/'audited-increment.json',frozen/'audited-increment.json')
    mac_reports=[]
    for i in (1,2):
        name=f'mac-{i:02}'
        out=w/(name+'-audit.json')
        run('audit_mac.py',comp,tree,r248,evid/name,out)
        same(out,frozen/out.name)
        mac_reports.append(out)
    run('merge_models.py',r248,r251,w/'shape-bank-audit.json',w/'audited-increment.json',
        w/'ledger.json','--mac',*mac_reports)
    same(w/'ledger.json',frozen/'ledger.json')
    final=json.loads((w/'ledger.json').read_bytes())
    assert final['scope']==5442 and len(final['all_256_model_counts'])==256
    print('all 256 fixed-input models replayed, exact per-leaf census reproduced',flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r248','r251','work'):
        p.add_argument(name,type=Path)
    main(p.parse_args())

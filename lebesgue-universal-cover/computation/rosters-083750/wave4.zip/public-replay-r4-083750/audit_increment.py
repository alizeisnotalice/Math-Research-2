"""Bind each new proof to the strict target, exact original root and its actual input."""
from argparse import ArgumentParser
from collections import Counter
from gzip import decompress
from hashlib import sha256
from importlib.util import spec_from_file_location,module_from_spec
import json
from pathlib import Path
import sys

GOAL='67/80'
LIMIT=120696470013529293
QRAW='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
FROZEN='65b4ab38358276aed105897686075377468b4443bd6d74556b272d28df973966'
BASE251='19daf305bec5529d5ed24ec6141fec573a18e8df585abf7ec878e06825d8fadf'
P152='fd28a8fb8beb00f3b30daa4b62fedc30753fb153a4143867d792cab66cba21c4'

def read(p):
    return json.loads(p.read_bytes())

def zread(p):
    return json.loads(decompress(p.read_bytes()))

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def lines(p):
    return [json.loads(x) for x in p.read_bytes().splitlines()]

def module(name,path):
    spec=spec_from_file_location(name,path)
    m=module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def verify_sums(directory):
    index=directory/'SHA256SUMS'
    for line in index.read_text().splitlines():
        h,p=line.split('  ')
        assert sha(directory/p)==h

def exact_root(t,fine,row,key):
    assert row['leaf']==row['label']==key
    assert row['target']==GOAL if 'target' in row else row['goal']==GOAL
    assert row['threshold_integer']==LIMIT
    expected=t.leaf(*map(int,key.split('/')))
    assert all(x*fine==l and y*fine==h for (x,y),(l,h) in
               zip(expected,zip(row['lo'],row['hi'],strict=True),strict=True))

def shards(a,t,fine,paths):
    r=a.r2
    archive=a.shards15/'shards.json.gz'
    bigger=zread(archive)
    smaller=zread(a.shards11/'shards.json.gz')
    for directory in (a.shards11,a.shards15):
        verify_sums(directory)
    assert bigger['source_prefix_index_sha256']==smaller['source_prefix_index_sha256']==FROZEN
    assert len(bigger['entries'])==165 and len(smaller['entries'])==53
    assert bigger['parts'].keys()>=smaller['parts'].keys()
    assert all(bigger['entries'][k]==v for k,v in smaller['entries'].items())
    assert all(bigger['parts'][k]==v for k,v in smaller['parts'].items())
    assert smaller['pure_replacements']==bigger['pure_replacements']
    shard_audit=module('shard_audit',a.shards15/'audit_shards.py').audit(a.shards15,r)
    assert len(shard_audit)==15 and sum(y['new_boxes'] for y in shard_audit.values())==2536
    by_path={}
    data={}
    for key,x in bigger['entries'].items():
        packet=x['packet']
        assert packet['leaf']==key
        result=r/x['source']
        if result not in by_path:
            by_path[result]=(sha(result),lines(result))
        h,rr=by_path[result]
        row=rr[x['line']-1]
        assert h==x['sha256'] and row==x['prefix']
        exact_root(t,fine,row,key)
        assert not row['stats'][0] and row['stats'][7]==1
        assert not (row['stats'][5] or row['guards'] or row['pending_visited'] or row['center_stops'])
        assert paths(row,packet['regions'])>0
        oldnodes,five,p30,qraw=row['stats'][1:5]
        nodes=fv=aug=qavg=0
        for i,z in enumerate(x['subtrees']):
            assert z['leaf']==[*map(int,key.split('/')),i] and z['target']==GOAL
            yes,n,f,u,_=z['out']
            assert yes==1 and z['front'] is None and not z['paired']
            assert n==2*(f+u)-1 and u==z['P128']+z['oldQ']
            nodes+=n;fv+=f;aug+=z['P128'];qavg+=z['oldQ']
        assert oldnodes+nodes==2*(five+fv+p30+qraw+aug+qavg)-1
        counts={'original_P30':p30,'physical_old_Q11':qraw,'augmented_P128':aug,'average_Q11':qavg}
        data[key]=dict(inputs=sorted(k for k,n in counts.items() if n),support_terminal_counts=counts,
            source=x['source'],source_line=x['line'],frontier=packet['source'],frontier_sha256=packet['digest'],
            five_terminals=five+fv,nodes=oldnodes+nodes)
    for row in bigger['pure_replacements']:
        key='/'.join(map(str,row['leaf']))
        assert key not in data and row['target']==GOAL
        s,n,f,m,_=row['out']
        assert s==1 and n==2*f-1 and row['front'] is None and not (m or row['P128'] or row['oldQ'] or row['paired'])
        assert all(l<h for l,h in t.leaf(*row['leaf']))
        data[key]=dict(inputs=[],support_terminal_counts={},five_terminals=f,nodes=n,
                       source='shards.json.gz/pure_replacements')
    return data,shard_audit,sorted(smaller['entries']),sha(archive)

def neighbors(a,t,fine,paths):
    d=a.neighbors
    merged=read(d/'neighbor-merged.json')
    native=read(d/'targeted/neighbor-old-q.json')
    assert merged['physical_cloud_sha256']==native['physical_cloud_sha256']==QRAW
    assert merged['bank_sha256']==native['bank_sha256']==sha(d/'targeted/q-original-angles.json')
    assert merged['upstream_audit_sha256']==sha(a.r2/'audit_refined_scope.py')
    assert native['native_ticks']==1
    def common(row):
        assert row['mode']==1 and not (
            row['stats'][3] or row['stats'][5] or row['guards'] or row['center_calls'])
        assert row['goal']==GOAL and row['threshold_integer']==LIMIT
        assert row['q_mesh'] and row['shared_dense'] and row['shared_angles'] and row['q_trigger_divisor']==4000
    data={}
    direct={}
    for group in range(4):
        packet=d/'neighbor-keys'/f'group-{group}.json'
        result=d/'old-neighbor-receipts'/f'group-{group}.jsonl'
        ys=lines(result)
        assert [x['leaf'] for x in ys]==read(packet)
        assert sha(result)==native['receipts_sha256'][result.name]
        for i,row in enumerate(ys,1):
            leaf=row['leaf'];assert leaf not in direct
            direct[leaf]=(row,i,group)
            exact_root(t,fine,row,leaf)
            common(row)
            s=row['stats']
            expected=native['roots'][leaf]
            assert (bool(s[0]),s[1],s[2],s[3],s[4])==tuple(
                expected[k] for k in ('whole','nodes','five','p30','q11'))
            if not s[0]:
                assert row['pending']>0
                continue
            assert s[1]==2*(s[2]+s[4])-1 and not row['pending'] and s[4]>0
            data[leaf]=dict(inputs=['physical_old_Q11'],nodes=s[1],five_terminals=s[2],
                            old_q_terminals=s[4],source=f'old-neighbor-receipts/{result.name}',source_line=i)
    assert set(data)==set(merged['original_nine']) and len(data)==9
    for key,rr in merged['continued'].items():
        assert key not in data and rr['closed'] and not rr['unresolved']
        row,index,g=direct[key]
        for path,h in rr['inputs'].items():
            assert sha(d/path)==h
        slug=key.replace('/','-')
        frontier=read(d/'old-neighbor-receipts'/f'group-{g}-frontier'/(slug+'-mode1-frontier.json'))
        assert len(frontier)==rr['source_pending'] and paths(row,frontier)>0
        short=lines(d/'neighbor-continued'/(slug+'.jsonl'))
        p=d/'neighbor-final'/(slug+'.jsonl')
        replacement={y['label']:y for y in lines(p)} if p.exists() else {}
        assert list(replacement)==[row['label'] for row in short if not row['stats'][0]]
        v,f,_,q,_=row['stats'][1:6]
        assert not row['pending_visited']
        for child,s in zip(frontier,short,strict=True):
            label=s['label']
            y=replacement.get(label,s)
            assert child['label']==label==y['label'] and y['leaf']==key
            assert child['bounds']==[list(b) for b in zip(y['lo'],y['hi'],strict=True)]
            common(s);common(y)
            a1,n,h,_,o,_=y['stats'][:6]
            assert a1==1 and not y['pending'] and n==2*(h+o)-1
            v+=n;f+=h;q+=o
        assert v==2*(f+q)-1 and q>0
        assert (v,f,0,q,0)==tuple(rr['counts_nodes_five_P30_Q11_mixed'])
        data[key]=dict(inputs=['physical_old_Q11'],nodes=v,five_terminals=f,old_q_terminals=q,
                       source=f'neighbor-merged.json/continued/{key}')
    assert len(data)==12
    return data,sha(d/'neighbor-merged.json')

def p152(a,t,fine,paths):
    origin=a.p152/'verified-whole.json'
    frozen=read(origin)
    assert frozen['target']==GOAL and frozen['original_scope']==5442 and frozen['strict']
    assert frozen['original_baseline_sha256']==sha(a.r251/'final-ledger.json')==BASE251
    assert set(frozen['accepted'])=={'1201/62085','1201/67150'}
    physical=a.p152/'points-greedy15.json'
    assert sha(physical)==P152 and len(read(physical)['points'])==15
    data={}
    for case in read(a.p152/'replay-cases.json'):
        key=case['leaf']
        point_file=a.p152/case['points']
        proof,=frozen['accepted'][key]
        assert proof['point_input_sha256']==sha(point_file)==P152
        assert sha(a.p152/case['bank'])==proof['point_bank_sha256']
        raw=a.p152/case['result']
        assert sha(raw)==proof['output_sha256']
        packet,=read(a.p152/case['packet'])
        assert key==packet['leaf']
        parent_name=packet['source'].split('/')[0]+'.jsonl'
        parent_file=a.r2/'refined'/parent_name
        assert sha(parent_file)==packet['verified_parent_sha256']
        row=lines(parent_file)[packet['verified_parent_line']-1]
        exact_root(t,fine,row,key)
        assert row['stats'][0]==0 and row['stats'][7]==1 and row['stats'][3]==row['stats'][5]==0
        assert not row['pending_visited'] and row['stats'][4]>0
        upstream=a.r2/'refined/frontiers'/packet['source']
        assert sha(upstream)==packet['digest'] and read(upstream)==packet['regions']
        assert paths(row,packet['regions'])>0 and row['stats'][2:5]==packet['prefix_terminal_counts']
        v,five,_,q=row['stats'][1:5]
        count=0
        for j,y in enumerate(lines(raw)):
            s,n,f,c,_=y['out']
            assert y['leaf']==[*map(int,key.split('/')),j] and y['target']==GOAL
            assert s==1 and y['front'] is None and n==2*(f+c)-1
            v+=n;five+=f;count+=c
        assert count>0 and len(lines(raw))==len(packet['regions'])==proof['residual_boxes']
        assert v==2*(five+q+count)-1 and v==proof['whole_visited']
        data[key]=dict(inputs=['physical_old_Q11','P152_interior15'],nodes=v,five_terminals=five,
                       old_q_terminals=q,p152_terminals=count,source=f'verified-whole.json/accepted/{key}')
    assert set(data)==set(frozen['accepted'])
    return data,sha(origin)

def main(a):
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import SourceTree,FINE
    t=SourceTree(a.tree)
    paths=module('r248_audit',a.r2/'audit_refined_scope.py').audit_paths
    s,by_part,first11,s_sha=shards(a,t,FINE,paths)
    n,n_sha=neighbors(a,t,FINE,paths)
    w,w_sha=p152(a,t,FINE,paths)
    assert set(s).isdisjoint(n) and set(s).isdisjoint(w) and set(n).isdisjoint(w)
    u=read(a.r251/'final-ledger.json')['models']
    both={m:set(u[m]['unresolved']) for m in ('original_with_both_Q','replacement_with_both_Q')}
    by_model={model:dict(shards11=len(s0&set(first11)),shards15=len(s0&set(s)),
                neighbors=len(s0&set(n)),p152=len(s0&set(w))) for model,s0 in both.items()}
    counts=dict(Counter('+'.join(z['inputs']) if z['inputs'] else 'five' for z in s.values()))
    data=dict(target=GOAL,strict=True,shards=s,neighbors=n,p152=w,shards11_keys=first11,
              full_shard_audit=by_part,overlap_with_R251_residual=by_model,shards_by_actual_inputs=counts,
              source_sha256=dict(shards15=s_sha,neighbors=n_sha,p152=w_sha))
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(dict(sources=[len(s),len(n),len(w)],overlap_with_R251=by_model,
                           shards_by_actual_inputs=counts)),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','r2','r251','shards11','shards15','neighbors','p152','output'):
        p.add_argument(key,type=Path)
    main(p.parse_args())

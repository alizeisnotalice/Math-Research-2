"""Verify all independent ordinary-seven point support rows and mask geometry with integer and Arb arithmetic."""
import argparse,json,hashlib
from itertools import combinations
from pathlib import Path
import numpy as np
from flint import arb,ctx
from ordinary_bank import grid,U,Z
def read(p):return json.loads(p.read_bytes())
def run(native,comp,bank):
    ctx.prec=192;P=read(native/'inputs/augmented.json');Q=read(native/'inputs/q11-receipt.json');b=read(bank);G=grid()
    assert list(map(list,G))==b['directions'] and len(b['cells'])==768 and b['knots']==384
    assert Q['input_points_sha256']==hashlib.sha256((comp/'multi-host-points.json').read_bytes()).hexdigest()
    dat=read(comp/'multi-host-points.json');assert all(isinstance(x,dict) for x in [dat])
    import sys
    sys.path.insert(0,str(comp.resolve()));from build_q11_leaf_bank import reflected_average
    raw,dd=reflected_average(dat);assert raw==Q['points'] and dd==Q['denominator']
    pi=arb.pi();sw,cw=(pi/384).sin_cos();total=[]
    assert 2*707107**2>10**12 and 2*706**2<1000**2
    for i in range(16):
        for z in [7,8,9]:
            a=[G[(16*i+h)%256] for h in range(-23,24)]
            c=[G[(16*(i+z)+h)%256] for h in range(-23,24)]
            assert all(x*u+y*v<0 for x,y in a for u,v in c)
    for k,d in enumerate([P,Q]):
        pts=d['points'];den=d['denominator'];assert set(map(tuple,pts))=={(x,-y) for x,y in pts}
        assert len(pts)==[128,11][k] and max((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(pts,2))<den**2
        X=np.array(pts,dtype=float);V=np.array(G,dtype=float);checked=0
        for j in range(384):
            sn,cs=((2*j+1)*pi/384).sin_cos();s,c=float(sn.mid()),float(cs.mid())
            ids=(V@(X@np.array([[c,s],[-s,c]])).T).argmax(axis=1);cache={}
            for row in b['cells'][384*k+j]:
                ns=row[:3];weights=row[3:6];ws,low=row[6:];assert all(type(x) is int for x in row) and min(weights)>0 and sum(weights)==ws
                assert all(sum(w*G[i][axis] for w,i in zip(weights,ns))==0 for axis in (0,1))
                for i in ns:
                    if i not in cache:
                        x,y=pts[ids[i]];a,bb=G[i]
                        cache[i]=((a*cs+bb*sn)*x+(-a*sn+bb*cs)*y,(-a*sn+bb*cs)*x-(a*cs+bb*sn)*y)
                A=sum(w*cache[i][0] for i,w in zip(ns,weights));B=sum(w*cache[i][1] for i,w in zip(ns,weights))
                assert A>0 and (A*cw-abs(B)*sw)*Z>=low*ws*den*U;checked+=1
        total.append(checked)
    return total
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('comp',type=Path);p.add_argument('bank',type=Path);a=p.parse_args();print(run(a.native,a.comp,a.bank))

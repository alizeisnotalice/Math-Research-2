"""Reselect and exactly certify factored positive normal triples on a common uniform grid."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json,math,sys
import numpy as np
from flint import arb,ctx
U=2**22;Z=2**28
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def grid():return [(round(U*math.cos(2*math.pi*j/256)),round(U*math.sin(2*math.pi*j/256))) for j in range(256)]
def build(raw,template,extras):
    p=raw['points'];den=raw['denominator'];G=grid();K=384;ctx.prec=160;pi=arb.pi()
    assert set(map(tuple,p))=={(x,-y) for x,y in p}
    assert max((a-x)**2+(b-y)**2 for a,b in p for x,y in p)<=den**2 and len(template['cells'])==K
    nearest=[round(256*math.atan2(y,x)/(2*math.pi))%256 for x,y in template['directions']]
    cosp=(pi/K).cos();sinp=(pi/K).sin();cells=[];P=np.asarray(p,dtype=float);V=np.asarray(G,dtype=float);total=0
    for j in range(K):
        sn,cs=((2*j+1)*pi/K).sin_cos();s,c=float(sn.mid()),float(cs.mid())
        xy=P@np.array([[c,s],[-s,c]]);mat=(V@xy.T).argmax(axis=1)
        cache={};rows=[];seen=set()
        templates=[tuple(nearest[k] for k in row[:3]) for row in template['cells'][j]]
        for z in extras[j]:templates.append(tuple(z[:3]))
        for a in templates:
            variations=[a]
            for i in range(3):
                for k in (-1,1):variations.append(tuple((v+(k if h==i else 0))%256 for h,v in enumerate(a)))
            for ids0 in variations:
                ids=tuple(sorted(ids0))
                if ids in seen:continue
                seen.add(ids);u,v,w=[G[i] for i in ids]
                weights=[det(v,w),det(w,u),det(u,v)]
                if max(weights)<0:weights=[-v for v in weights]
                if min(weights)<=0:continue
                assert all(sum(t*G[i][k] for t,i in zip(weights,ids))==0 for k in (0,1))
                for i in ids:
                    if i in cache:continue
                    x,y=p[int(mat[i])];a,b=G[i];nx,ny=a*cs+b*sn,-a*sn+b*cs;cache[i]=nx*x+ny*y,ny*x-nx*y
                A=sum(t*cache[i][0] for t,i in zip(weights,ids));B=sum(t*cache[i][1] for t,i in zip(weights,ids));assert A>0
                sw=sum(weights);low=int(((A*cosp-abs(B)*sinp)*Z/(sw*den*U)).lower().floor().unique_fmpz())
                rows.append([*ids,*weights,sw,low])
        assert rows;total+=len(rows);cells.append(rows)
    print(len(p),total,flush=True);return cells
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('comp',type=Path);p.add_argument('out',type=Path);p.add_argument('--extras',type=Path);a=p.parse_args()
    read=lambda f:json.loads(f.read_bytes())
    A=read(a.native/'inputs/augmented.json');Q=read(a.native/'inputs/q11-receipt.json');QT=read(a.comp/'q11-leaf-bank.json')
    assert sha256((a.comp/'q11-leaf-bank.json').read_bytes()).hexdigest()==Q['angle_bank_sha256']
    ex=read(a.extras)['cells'][:384] if a.extras else [[] for _ in range(384)]
    bb=[build(A,A,ex),build(Q,QT,ex)];out=dict(directions=grid(),knots=384,cells=bb[0]+bb[1],clouds=['P128','oldQ']);a.out.write_text(json.dumps(out,separators=(',',':'))+'\n')

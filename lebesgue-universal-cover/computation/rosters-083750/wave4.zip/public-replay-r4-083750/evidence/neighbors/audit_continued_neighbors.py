"""Assemble exact retained prefixes and homogeneous old-Q subtrees for the three hard roots."""
from argparse import ArgumentParser
from hashlib import sha256
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import json,sys


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def lines(p):
    return [json.loads(row) for row in p.read_bytes().splitlines()]


def verify(a):
    assert __debug__
    base=a.root.resolve()
    sys.path.insert(0,str(a.comp.resolve()))
    from certify_tomar_six_high import SourceTree
    tree=SourceTree(a.tree)
    audit_source=a.pack/'audit_refined_scope.py';sp=spec_from_file_location('upstream_scope',audit_source)
    mod=module_from_spec(sp);sp.loader.exec_module(mod)
    native=json.loads((base/'targeted/neighbor-old-q.json').read_bytes())
    assert native['native_table_sha256']=='c6aab0486609dd898dc17f5a491a1a3323b3e4e32b77758f6e47903fdea29cea'
    def valid(d):
        assert d['mode']==1 and d['stats'][3]==d['stats'][5]==d['guards']==d['center_calls']==0
        assert d['panels']==256 and d['goal']=='67/80' and d['threshold_integer']==120696470013529293
        assert d['q_trigger_divisor']==4000 and all(d[t] for t in ['edge_caps','shared_dense','shared_angles','q_mesh'])
        assert d['p_edge_stops']==0
        if d['stats'][0]:
            assert d['pending']==0 and d['stats'][1]==2*sum(d['stats'][2:6])-1
    result={}
    members=['audit_continued_neighbors.py','continue_neighbors.py','finish_neighbors.py',
             'run_neighbors.py','old-q-replay.md','targeted/q-original-angles.json','targeted/neighbor-old-q.json']
    for g,root in [(1,'1201/73325'),(2,'1205/154840'),(3,'1201/73285')]:
        leaf=root.replace('/','-')
        parentfile=base/'old-neighbor-receipts'/f'group-{g}.jsonl'
        assert digest(parentfile)==native['receipts_sha256'][parentfile.name]
        parent=next(z for z in lines(parentfile) if z['leaf']==root)
        valid(parent);assert parent['stats'][0]==0 and parent['label']==root
        assert list(zip(parent['lo'],parent['hi']))==[(int(l*2**44),int(h*2**44)) for l,h in tree.leaf(*map(int,root.split('/')))]
        frontier=base/'old-neighbor-receipts'/f'group-{g}-frontier'/(leaf+'-mode1-frontier.json')
        pending=json.loads(frontier.read_bytes());mod.audit_paths(parent,pending,116)
        short=base/'neighbor-continued'/(leaf+'.jsonl');dshort=lines(short)
        assert [r['label'] for r in dshort]==[sub['label'] for sub in pending]
        parent_names=[parentfile,frontier,short,base/'neighbor-keys'/f'group-{g}.json']
        long=base/'neighbor-final'/(leaf+'.jsonl')
        repl={}
        if long.exists():
            dl=lines(long);repl={r['label']:r for r in dl}
            need=[r['label'] for r in dshort if not r['stats'][0]]
            assert list(repl)==need
            parent_names.append(long)
        sums=parent['stats'][1:6].copy()
        edge=parent['q_edge_stops']
        missing=[]; selected={}
        for node,r0 in zip(pending,dshort):
            item=node['label'];valid(r0);r=repl.get(item,r0);valid(r)
            assert r['label']==r0['label']==item and r['leaf']==r0['leaf']==root
            assert list(map(list,zip(r['lo'],r['hi'])))==list(map(list,zip(r0['lo'],r0['hi'])))==node['bounds']
            if not r['stats'][0]:missing.append(item)
            selected[item]=('long' if item in repl else 'short')
            for i,n in enumerate(r['stats'][1:6]):sums[i]+=n
            edge+=r['q_edge_stops']
        if not missing:assert sums[0]==2*sum(sums[1:])-1
        result[root]=dict(closed=not missing,unresolved=missing,source_pending=len(pending),counts_nodes_five_P30_Q11_mixed=sums,
                          q11_edges=edge,selected=selected,inputs={str(f.relative_to(base)):digest(f) for f in parent_names})
        members.extend(str(f.relative_to(base)) for f in parent_names)
    final=dict(original_nine=native['closed'],continued=result,physical_cloud_sha256=native['physical_cloud_sha256'],
               bank_sha256=native['bank_sha256'],upstream_audit_sha256=digest(audit_source))
    a.out.write_text(json.dumps(final,sort_keys=True,indent=2)+'\n')
    members.append(str(a.out.resolve().relative_to(base)))
    if a.zip:
        with ZipFile(a.zip,'w') as s:
            for name in sorted(set(members)):
                header=ZipInfo(name,(2026,11,19,0,0,0));header.compress_type=ZIP_DEFLATED
                s.writestr(header,(base/name).read_bytes(),compresslevel=9)
        with ZipFile(a.zip) as s:assert s.testzip() is None
    print([(k,t['closed'],t['source_pending'],t['counts_nodes_five_P30_Q11_mixed']) for k,t in result.items()])


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ['comp','pack','tree','root','out']:p.add_argument(k,type=Path)
    p.add_argument('--zip',type=Path)
    verify(p.parse_args())

"""Retry precisely those saved first-level subboxes still open at the smaller budget."""
from argparse import ArgumentParser
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,subprocess
p=ArgumentParser()
for k in ['comp','package','tree','table','work','cache','out']:p.add_argument(k,type=Path)
p.add_argument('--budget',type=int,default=524287)
a=p.parse_args();base=Path(__file__).resolve().parent;a.out.mkdir(parents=True,exist_ok=True)
def run(z):
    group,leaf=z
    rows=list(map(json.loads,(base/'neighbor-continued'/(leaf+'.jsonl')).read_bytes().splitlines()))
    front=json.loads((base/'old-neighbor-receipts'/f'group-{group}-frontier'/(leaf+'-mode1-frontier.json')).read_bytes())
    assert [x['label'] for x in rows]==[x['label'] for x in front]
    sub=[x for x,r in zip(front,rows) if not r['stats'][0]]
    if not sub:return
    boxes=a.out/(leaf+'-keys.json');boxes.write_text(json.dumps(sub,separators=(',',':'))+'\n')
    cmd=[sys.executable,'-I','-B',str(base/'run_neighbors.py'),str(a.comp),str(a.package),str(a.tree),str(a.table),str(a.work/leaf),str(a.cache),str(base/'targeted'),str(base/'neighbor-keys'/f'group-{group}.json'),'--mode','expanded-original','--budget',str(a.budget),'--subboxes',str(boxes)]
    f=a.out/(leaf+'.jsonl')
    with f.open('w') as dst:subprocess.run(cmd,stdout=dst,check=True)
    d=list(map(json.loads,f.read_bytes().splitlines()))
    print(leaf,len(d),sum(x['stats'][0] for x in d),flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,[(2,'1205-154840'),(3,'1201-73285')]))

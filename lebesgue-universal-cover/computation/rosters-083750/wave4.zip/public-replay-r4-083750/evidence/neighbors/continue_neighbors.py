"""Continue the three still open old-Q roots on every certified unresolved subbox."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,subprocess,sys
p=ArgumentParser()
for k in ['comp','package','tree','table','work','cache','out']:p.add_argument(k,type=Path)
p.add_argument('--budget',type=int,default=65535)
a=p.parse_args();base=Path(__file__).resolve().parent
def run(t):
    group,leaf=t
    old=base/'old-neighbor-receipts'/f'group-{group}-frontier'/(leaf+'-mode1-frontier.json')
    a.out.mkdir(parents=True,exist_ok=True)
    dst=a.out/(leaf+'.jsonl')
    argv=[sys.executable,'-I','-B',str(base/'run_neighbors.py'),str(a.comp),str(a.package),str(a.tree),str(a.table),str(a.work/leaf),str(a.cache),str(base/'targeted'),str(base/'neighbor-keys'/f'group-{group}.json'),'--mode','expanded-original','--budget',str(a.budget),'--subboxes',str(old),'--frontier',str(a.out/(leaf+'-frontiers'))]
    with dst.open('w') as f:subprocess.run(argv,stdout=f,check=True)
    d=[json.loads(z) for z in dst.read_bytes().splitlines()]
    print(leaf,len(d),sum(x['stats'][0] for x in d),flush=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(run,[(1,'1201-73325'),(2,'1205-154840'),(3,'1201-73285')]))

# 实际原十一点的增强角表

物理输入固定为主仓 computation/multi-host-points.json 的原11个有理点。原 replay_angle_mesh.py 从该表取 reflected_average，再以原 EPS=$10^{-9}$ 创建 PointProof。此处只更新角库，原本的对称化点号、坐标、分母、近似误差照用。对每种手性，每个真实点有对应母表点，距离严格小于 EPS；正平衡三墙的加权方向范数小于 $(U+2)/U$。因此在 $2^{28}$ 尺度上需扣 $\lceil2^{28}(U+2)\,10^{-9}/U\rceil=1$ 格。audit_family.py 对3794个原生槽逐一复算扣减值。原三十点所有行分数置零，其终端总数为零。

新库取369个整数方向和384个闭角格。保留原2258个候选槽的方向、权重和最后的整数下端。每格再附4个候选，共1536个槽；按格内六元组去重，再扣掉同格旧行，有847个相异新组合，分布于383格。前四枚成功原根 1205/151326、1201/73319、1205/154836、1201/73279 的节点数为104367、129859、356455、39157。每枚均独立给出五个未缩原曲体和实际原十一点宿主面积严格大于 $67/80$。

~~~sh
python -I -B audit_expanded.py "$COMP" targeted/q-original-angles.json "$WORK/expanded-audit.json"
python -I -B run_neighbors.py "$COMP" "$PACK" "$TREE" "$TABLE" "$WORK/build" "$CACHE" targeted targeted/q-keys.json --mode expanded-original --budget 1048575 > "$WORK/old-q.jsonl"
python -I -B audit_family.py "$COMP" "$TREE" "$WORK/fixed-q.json" --mode old-q --bank targeted/q-original-angles.json --keys targeted/q-keys.json --receipt "$WORK/old-q.jsonl"
~~~

替换 keys 可换任意原叶号列表，追加 --subboxes 与 --frontier 可将原核用于指定未闭子盒。四个根在同一次共享角表和密材料包中复跑。冻结公开包提供源码 kernels-tangent/replay_angle_mesh.py。主源 comp、原树 TREE、64级表 TABLE 的签名和所有依赖见 source-audit.json；Clang 模块缓存传入 CACHE。

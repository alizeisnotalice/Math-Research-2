"""Validate a single material's native slots, original-box identities and homogeneous terminal counts."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, sys


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return sha256(p.read_bytes()).hexdigest()


def run(a):
    assert __debug__
    sys.path.insert(0,str(a.comp.resolve()))
    from flint import ctx
    from certify_tomar_six_high import SourceTree
    from replay_q11_with_p30 import PointProof
    from certify_finite_point_leaf import U, Q
    from build_q11_leaf_bank import reflected_average, EPS
    ctx.prec=192
    tree=SourceTree(a.tree)
    if a.mode=='old-p':
        cloud=a.comp/'finite-point-leaf-input.json';bank=a.comp/'finite-point-global-input.json'
        pf=PointProof({**read(cloud),'cells':read(bank)['cells']})
        table_hash='658b2f88b4ecb46697951d1cec328e12a21b67d093b6dc5d247c36dc1ac520b1'
        penalty=0
    elif a.mode=='old-q':
        cloud=a.comp/'multi-host-points.json';bank=a.bank
        p,D=reflected_average(read(cloud))
        data={**read(bank),'points':p,'denominator':D,'direction_scale':U}
        raw=PointProof(data);pf=PointProof(data,EPS)
        scale=Q*F(U+2,U)*EPS
        penalty=-(-scale.numerator//scale.denominator)
        assert penalty==1 and (raw.triples[7::8]-pf.triples[7::8]==1).all()
        table_hash='c6aab0486609dd898dc17f5a491a1a3323b3e4e32b77758f6e47903fdea29cea'
    else:
        cloud=bank=a.bank
        assert sha(cloud)=='b2785d4632735e1f15bbc1eb6a5059551b70e7115618443dffd309b6d8cdeba1'
        pf=PointProof(read(cloud));table_hash=None;penalty=0
    t=sha256(pf.triples.astype('<i8').tobytes()).hexdigest()
    assert table_hash is None or t==table_hash
    receipts={};records={}
    assert len(a.keys)==len(a.receipt)
    for keys,receipt in zip(a.keys,a.receipt):
        data=[json.loads(z) for z in receipt.read_bytes().splitlines()]
        assert [d['leaf'] for d in data]==read(keys)
        receipts[receipt.name]=sha(receipt)
        for d in data:
            k=d['leaf'];assert k not in records and d['label']==k
            geom=tree.leaf(*map(int,k.split('/')))
            bounds=[(int(l*2**44),int(h*2**44)) for l,h in geom]
            assert list(zip(d['lo'],d['hi']))==bounds
            assert d['mode']==int(a.mode!='old-p') and d['threshold_integer']==120696470013529293 and d['goal']=='67/80'
            assert d['center_calls']==d['guards']==0 and d['q_trigger_divisor']==4000 and d['panels']==256
            assert d['edge_caps'] and d['shared_dense'] and d['shared_angles']
            s=d['stats']
            assert s[3 if d['mode']==1 else 4]==s[5]==0
            closed=bool(s[0]);pending=d['pending']
            if closed:assert pending==0 and s[1]==2*sum(s[2:5])-1
            else:assert pending>0
            records[k]=dict(whole=closed,pending=pending,nodes=s[1],five=s[2],p30=s[3],q11=s[4],edge=d['p_edge_stops']+d['q_edge_stops'])
    result=dict(mode=a.mode,native_ticks=penalty,physical_cloud_sha256=sha(cloud),bank_sha256=sha(bank),native_table_sha256=t,
                roots=records,closed=[k for k,d in records.items() if d['whole']],receipts_sha256=receipts)
    a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(a.mode,len(result['closed']),len(records),t)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ['comp','tree','out']:p.add_argument(k,type=Path)
    p.add_argument('--mode',required=True,choices=['old-p','old-q','adapted-q'])
    p.add_argument('--bank',type=Path)
    p.add_argument('--keys',nargs='+',required=True,type=Path);p.add_argument('--receipt',nargs='+',required=True,type=Path)
    run(p.parse_args())

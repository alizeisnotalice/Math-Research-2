"""Propose and prove balanced rows for both independent rigid hands."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import itertools
import json
from math import cos, sin, pi, gcd
from pathlib import Path
import sys
import time

from flint import arb,ctx
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
U=2**22
Z=2**28
NS=256
S=2**44

def read(p):
    return json.loads(p.read_bytes())

def dig(p):
    return sha256(p.read_bytes()).hexdigest()

def ar(x):
    v=F(x)
    return arb(v.numerator)/v.denominator

def grid():
    d=[(round(U*cos(2*pi*j/NS)),round(U*sin(2*pi*j/NS)))for j in range(NS)]
    assert all((U-2)**2<x*x+y*y<(U+2)**2 for x,y in d)
    return d

def det(a,b):
    return a[0]*b[1]-a[1]*b[0]

@lru_cache(None)
def weights(ids):
    a,b,c=(grid_data[t]for t in ids)
    w=[det(b,c),det(c,a),det(a,b)]
    if max(w)<0:
        w=[-v for v in w]
    if min(w)<=0:
        return None
    g=gcd(gcd(w[0],w[1]),w[2])
    w=tuple(v//g for v in w)
    assert all(sum(v*grid_data[i][k]for v,i in zip(w,ids,strict=True))==0 for k in (0,1))
    return w

grid_data=grid()

def authenticated_centers(comp,tree,keys):
    sys.path.insert(0,str(comp.resolve()))
    from tomar_leaf_box import leaf_box
    from verify_tomar_fan_table import PINNED_MANIFEST
    rows={}
    manifest=tree/'SHA256SUMS'
    assert dig(manifest)==PINNED_MANIFEST
    pins={n.removeprefix('./'):h for h,n in map(str.split,manifest.read_text().splitlines())}
    for part in sorted({p for p,i in keys}):
        hf=tree/f'part{part:04}.json'
        tf=hf.with_suffix('.npy')
        assert dig(hf)==pins[hf.name] and dig(tf)==pins[tf.name]
        meta=read(hf)
        codes=np.load(tf,allow_pickle=False)
        extent=np.r_[1,1+np.cumsum(np.where(codes<11,1,-1))]
        for p,i in keys:
            if p!=part:
                continue
            center,half=leaf_box(extent,codes,p,i,meta)
            bounds=[[F(x)-F(h),F(x)+F(h)]for x,h in zip(center,half,strict=True)]
            assert all((t*S).denominator==1 for v in bounds for t in v)
            rows[(p,i)]=(np.array(list(map(float,center))),[[int(t*S)for t in v]for v in bounds])
    assert set(rows)==set(keys)
    return rows

def host_table(ax,params):
    theta=np.arctan2(ax[:,1],ax[:,0])
    norm=np.linalg.norm(ax,axis=1)
    h=np.full(len(theta),.5)
    for i,n in enumerate((3,5,7,9)):
        phase=2*pi/n
        angle,x,y=(0.,*params[:2]) if i==0 else params[3*i-1:3*i+2]
        u=theta-angle
        delta=np.abs(u-np.rint(u/phase)*phase)
        r=.5/cos(phase/4)
        h=np.maximum(h,np.where(delta<=phase/4,r*np.cos(delta),1-r*np.cos(phase/2-delta))+(ax@np.array([x,y]))/norm)
    return h*norm

def materials(raw):
    p=raw['points']
    d=raw['denominator']
    assert type(d) is int and d>0 and len(p)==len({tuple(x)for x in p})
    assert 5<=len(p)<=30
    assert all(len(x)==2 and all(type(y) is int for y in x)for x in p)
    d2=max((x-a)**2+(y-b)**2 for x,y in p for a,b in p)
    assert d2<=d*d
    return np.asarray(p,dtype=float)/d,np.asarray(p,dtype=np.int64),d,d2

def support_point(theta,hand,points):
    cs,sn=cos(theta),sin(theta)
    axes=np.asarray(grid_data,dtype=float)/U
    dx,dy=axes.T
    n=np.c_[dx*cs+dy*sn,hand*(dy*cs-dx*sn)]
    return n@points.T

def candidate_triples(T,ax,cached):
    discovered={(0,85,171),(42,127,213)}
    options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9}
    for h in T:
        lp=linprog([0,0,1],A_ub=cached,b_ub=h,bounds=[(None,None)]*3,method='highs',options=options)
        assert lp.success
        ids=tuple(int(k)for k in np.flatnonzero(-lp.ineqlin.marginals>1e-9))
        if len(ids)==3 and weights(ids):
            discovered.add(ids)
            for i in range(3):
                for shift in (-2,-1,1,2):
                    alt=tuple(sorted(ids[:i]+((ids[i]+shift)%NS,)+ids[i+1:]))
                    if weights(alt):
                        discovered.add(alt)
        elif len(ids)==2:
            for i,d in enumerate(ids):
                for shift in (-1,1):
                    alt=tuple(sorted((ids[i],(d+shift)%NS,ids[1-i])))
                    if weights(alt):
                        discovered.add(alt)
        else:
            assert len(ids) in (2,3),ids
    return sorted(discovered)

def exact_row(ids,p,den,j,k,hand,cache):
    ws=weights(ids)
    assert ws is not None
    if j not in cache:
        cache[j]=[(arb.pi()*(2*j+1)/k).sin_cos(),(arb.pi()/k).sin_cos(),{}]
    (sn,cs),(half_s,half_c),known=cache[j]
    for i in ids:
        if i not in known:
            a,b=grid_data[i];u,v=a*cs+b*sn,-a*sn+b*cs
            values=[(u*int(x)+v*hand*int(y),v*int(x)-u*hand*int(y))for x,y in p]
            known[i]=[
                max(range(len(values)),key=lambda ix:float(values[ix][0]*half_c+sg*values[ix][1]*half_s))
                for sg in (0,-1,1)
            ],values
    options=[tuple(dict.fromkeys(known[i][0]))for i in ids]
    total=sum(ws)
    exacts=[]
    for picks in itertools.product(*options):
        column=[known[i][1][q]for i,q in zip(ids,picks,strict=True)]
        A=sum(w*a for w,(a,b) in zip(ws,column,strict=True))
        B=sum(w*b for w,(a,b) in zip(ws,column,strict=True))
        if A>0:
            exacts.append(((A*half_c-abs(B)*half_s)*Z/(den*total*U),picks))
    assert exacts
    lb,mat=max(exacts,key=lambda x:x[0].lower())
    val=int(lb.lower().floor().unique_fmpz())
    assert lb>val>0
    return [*ids,*ws,total,val],list(mat)

def propose(a,points,exact,den):
    chosen=read(a.train)
    keys=[tuple(map(int,n.split('/')))for n in chosen['selected']]
    centers=authenticated_centers(a.comp,a.tree,keys)
    H=np.array(list(centers[q][0]for q in keys))
    archive=read(a.comp/'free-p30-reoptimized-pose.json')
    H=np.concatenate([H,[list(map(float,archive[:11]))]])
    axes=np.array(grid_data,dtype=float)/U
    T=np.array([host_table(axes,h) for h in H])
    lp_mat=np.c_[axes,-np.ones(NS)]
    options=[]
    A=2*pi/a.knots
    cells=[]
    materials=[]
    for hand in (1,-1):
        cache={}
        for j in range(a.knots):
            phase=(j+.5)*A
            M=support_point(phase,hand,points)
            V=M.max(axis=1)
            lows=[support_point(phase+sg*A/2,hand,points).max(axis=1) for sg in (-1,1)]
            H0=T-V
            proposed=candidate_triples(H0,axes,lp_mat)
            if j%2==0:
                proposed=sorted(set(proposed+candidate_triples(T-min(lows,key=np.mean),axes,lp_mat)))
            rankings=[]
            for ids in proposed:
                w=np.array(weights(ids),dtype=float)
                rank=-(H0[:,ids]@w)/w.sum()
                rankings.append(rank)
            ranks=np.array(rankings)
            selected=set()
            for h in range(len(H0)):
                selected.update(np.argsort(-ranks[:,h])[:a.top])
            selected=sorted(selected,key=lambda i:-np.mean(ranks[i]))
            saved=[exact_row(proposed[i],exact,den,j,a.knots,hand,cache)for i in selected]
            cells.append([z[0]for z in saved]);materials.append([z[1]for z in saved])
        print('hand',hand,'rows',sum(map(len,cells)),flush=True)
    return cells,materials

def verification(points,bank,material):
    raw=read(points)
    _,P,den,d2=materials(raw)
    b=read(bank);m=read(material)
    assert b['directions']==list(map(list,grid_data))
    assert m['point_sha256']==dig(points) and m['bank_sha256']==dig(bank)
    k=b['knots']
    assert type(k) is int and k>=12 and len(b['cells'])==len(m['material_indices'])==2*k
    half_s,half_c=(arb.pi()/k).sin_cos()
    mins=[];count=0
    for j,(rows,selected) in enumerate(zip(b['cells'],m['material_indices'],strict=True)):
        hand=1 if j<k else -1
        s,c=(arb.pi()*(2*(j%k)+1)/k).sin_cos()
        assert rows
        for r,ix in zip(rows,selected,strict=True):
            ids=r[:3];ws=r[3:6];total,lower=r[6:]
            assert len(set(ids))==3 and len(ix)==3 and all(type(q) is int for q in r+ix)
            assert all(0<=i<NS for i in ids) and all(0<=p<len(P) for p in ix)
            assert ws==list(weights(tuple(ids))) and sum(ws)==total and min(ws)>0
            assert all(sum(w*grid_data[i][k]for i,w in zip(ids,ws,strict=True))==0 for k in (0,1))
            A=B=arb(0)
            for i,wi,q in zip(ids,ws,ix,strict=True):
                vx,vy=grid_data[i];x,y=map(int,P[q])
                u,v=vx*c+vy*s,-vx*s+vy*c
                A+=wi*(u*x+v*hand*y)
                B+=wi*(v*x-u*hand*y)
            l=(A*half_c-abs(B)*half_s)*Z/(den*total*U)
            assert A>0 and l>lower>0,(j,r,ix,l)
            mins.append((l-lower).lower());count+=1
    return dict(input_sha256=dig(points),bank_sha256=dig(bank),material_index_sha256=dig(material),
        diameter_sq=[d2,den*den],rows=count,exact_min_rounding_slack=str(min(mins)),both_hands_closed_cells=2*k)

def main(a):
    ctx.prec=160
    start=time.monotonic()
    b,m,report=a.out
    if not a.check:
        points,exact,den,_=materials(read(a.points))
        if a.template:
            old=read(a.template)
            assert old['directions']==list(map(list,grid_data))
            a.knots=old['knots']
            data=[]
            for hand,offset in ((1,0),(-1,a.knots)):
                cache={}
                for j in range(a.knots):
                    data.append([exact_row(tuple(r[:3]),exact,den,j,a.knots,hand,cache)for r in old['cells'][offset+j]])
            cells=[[z[0]for z in v]for v in data];mats=[[z[1]for z in v]for v in data]
        else:
            cells,mats=propose(a,points,exact,den)
        b.write_text(json.dumps(dict(directions=grid_data,cells=cells,knots=a.knots),separators=(',',':'))+'\n')
        m.write_text(json.dumps(dict(point_sha256=dig(a.points),bank_sha256=dig(b),material_indices=mats),separators=(',',':'))+'\n')
    r=verification(a.points,b,m)
    r['verifier_sha256']=dig(Path(__file__))
    report.write_text(json.dumps(r,indent=2)+'\n')
    print(r,'elapsed',time.monotonic()-start,flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','points','train'):
        p.add_argument(key,type=Path)
    p.add_argument('out',type=Path,nargs=3)
    p.add_argument('--knots',type=int,default=384)
    p.add_argument('--top',type=int,default=3)
    p.add_argument('--check',action='store_true')
    p.add_argument('--template',type=Path)
    main(p.parse_args())

"""Extract selected public R248 inputs and replay the same shared range."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

R2ROOT='public-replay-r2-083750'
PREFIX_MEMBERS={
    'kernels-tangent/angle_mesh.hpp':'6be067e2c673163ecadb163ce15ae292888c82437f225dd2142df81a897fc6d6',
    'kernels-tangent/angle_mesh_leaf_guard.cpp':'fd2db4281edc2d08b0a0aaffaef616f2a388fccd6823987134c7f73c3c10ca6f',
    'kernels-tangent/cap_tangent.hpp':'47bbfe98ce8836361d2f47ffb4b5407875843e8bb8f4eb988925672112ef36ad',
    'kernels-tangent/coupled_support.hpp':'3eacb885147150e179241e27c3b471b4922c5d8f24a967b15e54b00e70fc7332',
    'kernels-tangent/long_edge_support.hpp':'ad010f7a4cefbdfade8476f7b1c460c16f8b3e8d84cee928198e80764c46556b',
    'kernels-tangent/replay_angle_mesh.py':'6c148f8ab27fed6a0ae8f6dcc349d756c70a53292d712fcc83bb48a10749717c',
    'refined/refined-m1-b65535-01.jsonl':'d0fc5e050610496f7a1f764039e959a8f4d397f31fec9816e390b65a633180d1',
    'refined/refined-m1-b65535-02.jsonl':'feb4a550e0dd357586ebb8739ed0bb616b9933bb8cf92b35ae60986dbc180048',
    'refined/refined-m1-b65535-01-receipt.json':'ce86050e6d1626c80971cea06614191af074ee4de627cef4a5eea139ba426c23',
    'refined/refined-m1-b65535-02-receipt.json':'ce00afb85e38c738fa3accf50881c67f3609fbfbbfdc79e68a36c27e23873298',
    'refined/frontiers/refined-m1-b65535-01/1201-62085-mode1-frontier.json':'e1b92eb5bf529c69d42c678fd9b1901ed89f58e363b0a78a1bd99f08dc717abf',
    'refined/frontiers/refined-m1-b65535-02/1201-67150-mode1-frontier.json':'b0b6bb359d42f2d7cb64efe29ad91950f80d110c5ea3beba9320dacde780d7db',
}

PREFIXES=(('1201/62085','01',52),('1201/67150','02',37))
R2_ARCHIVE='whole-leaves-083750-second/wave2.zip'
R2_SHA='4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d'

def digest(raw):
    return sha256(raw).hexdigest()

def checked_member(archive,name,expected):
    data=archive.read(name)
    assert digest(data)==expected,name
    return data

def extract(comp,out):
    path=comp/R2_ARCHIVE
    assert digest(path.read_bytes())==R2_SHA
    with ZipFile(path) as archive:
        for name,h in PREFIX_MEMBERS.items():
            target=out/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(checked_member(archive,f'{R2ROOT}/{name}',h))
        for label,part,line in PREFIXES:
            stem=f'm1-b65535-{part}'
            src=f'refined/refined-{stem}'
            receipt=json.loads((out/(src+'-receipt.json')).read_bytes())
            original_rows=(out/(src+'.jsonl')).read_bytes().splitlines()
            original=checked_member(archive,f'{R2ROOT}/scope-refined/{stem}.json',receipt['input_sha256'])
            cohort=json.loads(original)
            assert cohort==[json.loads(x)['leaf']for x in original_rows]
            assert cohort[line-1]==label
            (out/f'cohort-{part}.json').write_bytes(original)
    p=out/'kernels-tangent/replay_angle_mesh.py'
    source=p.read_text()
    # Retain the original full-batch enclosing box for its certified shared
    # dense and support arrays. The driver still visits only the requested root.
    line="    common_d1=common_d2=common_dense=common_mesh=None"
    new="""    import os
    prep_root=json.loads(Path(os.environ['P152_PREFIX_COHORT']).read_bytes())
    assert set(a.cases)<=set(prep_root)
    prep={key:tree.leaf(*map(int,key.split('/'))) for key in prep_root}
"""
    assert source.count(line)==1
    source=source.replace(line,new+line)
    for how in ('min','max'):
        start=0 if how=='min' else 1
        old=f"{how}(source_boxes[k][j][{start}] for k in a.cases)"
        assert source.count(old)==1
        source=source.replace(old,f"{how}(endpoints[j][{start}] for endpoints in prep.values())")
    new_script=p.with_name('replay_two_roots.py')
    new_script.write_text(source)
    return new_script

if __name__=='__main__':
    import sys
    extract(*map(Path,sys.argv[1:]))

"""Exact true material arcs of the three project inputs and exact sampled points."""
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

from flint import arb,ctx

def ar(v):
    q=F(v)
    return arb(q.numerator)/q.denominator

def unit(t):
    s,c=t.sin_cos()
    return c,s

def add(p,q):
    return tuple(x+y for x,y in zip(p,q,strict=True))

def sub(p,q):
    return tuple(x-y for x,y in zip(p,q,strict=True))

def scale(k,p):
    return tuple(k*x for x in p)

def dot(p,q):
    return sum(x*y for x,y in zip(p,q,strict=True))

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

SOURCES={
    'released-hexagon/chain-153-input.json':'cabba57c196b0c17f1a1abffb1423b3774752e7bf46799025d73211b16697e63',
    'finite-arc-reduction/five-arc-band.json':'369d19d3be6c5cbcff4a34e9a395539deeac06cc2fa8c960488f2366bf0c725f',
    'finite-arc-reduction/certify_five_arc_band.py':'f30f63192bd2aebaccaeb9df2ab2d1e5e2fb6531ad4882f162e5b2a786b5d98c',
    'deformed_reuleaux_support.py':'ff884b874884090aa004d9a70cbf5048aab233dd44b07f8252a5f9b98a012297',
}

class Profile:
    def __init__(self,fan):
        self.fan=fan
        self.runs=[(a,b,c) for a,b,r,c in fan if r]
        assert len(self.runs)>=1 and all(0<b-a<arb.pi() for a,b,c in self.runs)
        self.unit_alt=[(unit(a),unit(b))for a,b,c in self.runs]

    def support(self,u):
        # Full unit arcs. The extremum is an endpoint unless the direction
        # lies between the endpoint radius vectors counterclockwise.
        def det(x,y):
            return x[0]*y[1]-x[1]*y[0]
        values=[]
        norm=dot(u,u).sqrt()
        for (a,b,c),(x,y) in zip(self.runs,self.unit_alt,strict=True):
            center=dot(c,u)
            values.extend((center+dot(x,u),center+dot(y,u)))
            if not det(x,u)<0 and not det(u,y)<0:
                values.append(center+norm)
        # Candidate interior terms when not strictly known may be upper only.
        return max(z.upper() for z in values)

    def samples(self,k):
        return [add(c,unit(a+(b-a)*ar(F(j,k))))for a,b,c in self.runs for j in range(k+1)]

def input216(p,X):
    pi=arb.pi()
    L=pi/3
    x2=X*pi/2880
    x1=L-((L-x2).cos()-ar(F(1,2))+L.cos()/2-p*L.sin()).acos()
    x5=2*L+(ar(F(3,4))+p*L.sin()).acos()
    D=sub(sub(unit(x2),unit(x1)),unit(x5))
    z=arb.atan2(D[0],-D[1])
    s=(dot(D,D).sqrt()/2).asin()
    xs=[arb(0),x1,x2,z-s,z+s,x5,pi]
    assert xs[2]<L<xs[3] and xs[4]<2*L<xs[5]
    assert all(a<b for a,b in zip(xs,xs[1:]))
    start=(ar(F(1,2)),p)
    point=start
    half=[]
    for i,(a,b) in enumerate(zip(xs,xs[1:])):
        r=int(i%2==0)
        c=sub(point,scale(r,unit(a)))
        half.append((a,b,r,c))
        point=add(c,scale(r,unit(b)))
    assert all(x.contains(0) for x in sub(point,sub(start,unit(arb(0)))))
    return Profile(half+[(a+pi,b+pi,1-r,c)for a,b,r,c in half])

def input_deformed(ns,vertices):
    tau=2*arb.pi()
    directions=[sub(vertices[i],vertices[j])for i,j in ns['orders']]
    angles=[]
    for u in directions:
        a=arb.atan2(u[1],u[0])
        if angles:
            a+=tau*(math.floor(float((angles[-1]-a)/tau))+1)
            assert 0<a-angles[-1]<tau/2
        angles.append(a)
    angles.append(angles[0]+tau)
    assert 0<angles[-1]-angles[-2]<tau/2
    fan=[(a,b,r,vertices[k])for a,b,(k,r)in zip(angles[:-1],angles[1:],ns['sector'],strict=True)]
    assert len(fan)==10 and sum(r for a,b,r,c in fan)==5
    return Profile(fan)

def profiles(comp):
    sys.path.insert(0,str(comp.resolve()))
    from deformed_reuleaux_support import body,environment
    for name,want in SOURCES.items():
        assert digest(comp/name)==want,name
    ctx.prec=192
    ns=environment(str(comp.resolve()),'1.5497')
    ctx.prec=192
    recipe=json.loads((comp/'released-hexagon/chain-153-input.json').read_bytes())
    bundle=json.loads((comp/'finite-arc-reduction/five-arc-band.json').read_bytes())
    keys={'P151':tuple(recipe['bodies'][0][:2]),'P152':tuple(recipe['bodies'][1][:2])}
    assert keys=={'P151':('.7982907','.032688'),'P152':('1.2','.08464386')}
    out={}
    for name,(w,e) in keys.items():
        v,h=body(ns,F(w),F(e))
        result=input_deformed(ns,v)
        for j in range(48):
            u=unit(j*arb.pi()/24)
            assert abs(result.support(u)-h(u))<ar(F(1,10**28)),(name,j,result.support(u),h(u))
        out[name]=result
    out['R216']=input216(ar(bundle['parameter_p']),ar(bundle['x2_in_pi_over_2880']))
    return out

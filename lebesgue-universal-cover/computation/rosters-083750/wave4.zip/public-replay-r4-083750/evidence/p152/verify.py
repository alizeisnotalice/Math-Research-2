"""Replay the two published old prefixes and all sixteen P152 suffixes."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from prepare_prefix import PREFIXES, R2_SHA, checked_member, extract

META_FIELDS={'shared_prep_cpu','prep_cpu','search_cpu','bank_cpu'}

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def checked_members():
    for line in (HERE/'SHA256SUMS').read_text().splitlines():
        h,name=line.split('  ',1)
        assert digest(HERE/name)==h,name

def canonical(row):
    return {k:v for k,v in row.items() if k not in META_FIELDS}

def serialized(rows):
    return (json.dumps(rows,indent=2,sort_keys=True)+'\n').encode()

def old_reference(archive,part,line):
    parent=f'refined-m1-b65535-{part}'
    parent_file=archive/'refined'/(parent+'.jsonl')
    row=json.loads(parent_file.read_bytes().splitlines()[line-1])
    leaf=row['leaf'].replace('/','-')
    frontier=archive/'refined'/'frontiers'/parent/(leaf+'-mode1-frontier.json')
    return row,frontier

def main(a):
    checked_members()
    comp,tree,table,out=(f.resolve()for f in (a.comp,a.tree,a.table,a.out))
    assert out!=HERE and a.workers>0
    out.mkdir(parents=True,exist_ok=False)
    cache=a.cache.resolve() if a.cache else out/'clang-cache'
    cache.mkdir(parents=True,exist_ok=True)
    fixed=read(HERE/'public-fingerprints.json')
    assert digest(table)==fixed['table64']
    for directory,tags in ((comp,fixed['comp']),(tree,fixed['tree'])):
        for name,h in tags.items():
            assert digest(directory/name)==h,name
    r3=fixed['r3']
    path=comp/r3['archive']
    assert digest(path)==r3['archive_sha256']
    with ZipFile(path) as f:
        item=r3['ledger']
        ledger=out/'final-ledger.json'
        ledger.write_bytes(checked_member(f,item['member'],item['sha256']))
        for name,node in r3['kernel_members'].items():
            assert checked_member(f,node['member'],node['sha256'])==(HERE/'new-kernel'/name).read_bytes()
    old=out/'R248'
    prefix_script=extract(comp,old)
    tmp=out/'tmp'
    tmp.mkdir()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp))
    def run(script,*args,capture=False,add_env=None,isolated=True):
        flags=['-I','-B'] if isolated else ['-B']
        e=env|add_env if add_env else env
        return subprocess.run([sys.executable,*flags,str(script),*map(str,args)],env=e,cwd=HERE,
            check=True,stdout=subprocess.PIPE if capture else None).stdout
    def replay_prefix(row):
        leaf,part,line=row
        expected,frontier=old_reference(old,part,line)
        assert expected['leaf']==leaf and expected['q_mesh']
        identifier=leaf.replace('/','-')
        front_out=out/'fresh-prefix'/identifier
        text=run(prefix_script,comp,tree,table,out/('old-native-'+identifier),cache,
            '--target','.83750','--modes',1,'--budget',65535,'--depth',116,
            '--dense','--share-dense','--panels',256,'--share-angles','--edge-caps','--fan-integral',
            '--coupled-support','--cap-tangent','--q-mesh','--q-trigger-divisor',12000,
            '--frontier-out',front_out,'--cases',leaf,capture=True,
            add_env={'P152_PREFIX_COHORT':str(old/f'cohort-{part}.json')})
        actual=json.loads(text)
        assert canonical(actual)==canonical(expected),leaf
        fresh=front_out/frontier.name
        assert fresh.read_bytes()==frontier.read_bytes(),leaf
        assert actual['stats'][2:5]==expected['stats'][2:5] and actual['pending']==8
        (out/('prefix-'+identifier+'.json')).write_bytes(serialized(canonical(actual)))
        print('R248 prefix',leaf,'65535 visits and 8 exact frontier boxes',flush=True)
        return dict(leaf=leaf,normalized_prefix_sha256=sha256(serialized(canonical(actual))).hexdigest(),
            frontier_sha256=digest(fresh),terminal_counts=actual['stats'][2:5])
    def replay_geometry():
        run(HERE/'make_points.py',comp,out)
        for n in ('points-15.json','points-30.json'):
            assert (out/n).read_bytes()==(HERE/n).read_bytes(),n
        original=read(out/'points-30.json')
        points=HERE/'points-greedy15.json'
        one=read(points)
        assert one['denominator']==original['denominator']
        assert one['recipe']['greedy_source_sha256']==digest(out/'points-30.json')
        ids=one['recipe']['indices']
        assert len(ids)==len(set(ids))==15
        assert one['points']==[original['points'][i]for i in ids]
    with ThreadPoolExecutor(max_workers=3) as pool:
        proofs=[pool.submit(replay_prefix,row) for row in PREFIXES]
        check=pool.submit(replay_geometry)
        prefixes=[job.result()for job in proofs]
        check.result()
    import bank as point_bank
    from flint import ctx
    ctx.prec=160
    profile=HERE/'points-greedy15.json'
    bank=HERE/'bank-greedy15.json'
    receipt=out/'bank-greedy15-audit.json'
    r=point_bank.verification(profile,bank,HERE/'materials-greedy15.json')
    r['verifier_sha256']=digest(HERE/'bank.py')
    receipt.write_text(json.dumps(r,indent=2)+'\n')
    assert receipt.read_bytes()==(HERE/receipt.name).read_bytes()
    print('P152',r['rows'],'balanced rows',r['both_hands_closed_cells'],'closed hand-angle cells',flush=True)
    kernel=HERE/'new-kernel'
    library=out/'p152-suffix.so'
    subprocess.run(['clang++',*fixed['native_compile_flags'],
        f'-fmodules-cache-path={cache}',
        str(kernel/'cap_joint.cpp'),'-o',str(library)],
        env=env,cwd=HERE,check=True)
    cases=read(HERE/'replay-cases.json')
    assert [v['leaf']for v in cases]==[q[0]for q in PREFIXES]
    commands=[]
    hashes={}
    for case in cases:
        selected=HERE/case['packet']
        expected=HERE/case['result']
        assert [x['leaf']for x in read(selected)]==[case['leaf']]
        actual=out/expected.name
        run(kernel/'run_fronts.py',comp,tree,table,library,bank,actual,
            '--target','.83750','--workers',a.workers,'--cap',case['cap'],'--caps','--mesh',
            '--only',case['leaf'],'--frontiers',selected,isolated=False)
        assert actual.read_bytes()==expected.read_bytes(),case['leaf']
        hashes[case['leaf']]=digest(actual)
        commands.extend(('--case',bank,profile,receipt,selected,actual))
    whole=out/'verified-whole.json'
    run(HERE/'compose.py',ledger,old/'refined',whole,*commands)
    assert whole.read_bytes()==(HERE/whole.name).read_bytes()
    final=dict(old_prefixes=prefixes,suffixes=hashes,true_points_sha256=digest(profile),
        whole_sha256=digest(whole),certified_angle_bank_sha256=digest(bank),table64_sha256=digest(table),
        public_R248_sha256=R2_SHA,public_R251_sha256=r3['archive_sha256'])
    final_raw=serialized(final)
    assert final_raw==(HERE/'expected-replay.json').read_bytes()
    (out/'verification.json').write_bytes(final_raw)
    print('Both independent kernels replayed. All 16 suffix boxes close.',flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','tree','table','out'):
        p.add_argument(key,type=Path)
    p.add_argument('--cache',type=Path)
    p.add_argument('--workers',type=int,default=3)
    main(p.parse_args())

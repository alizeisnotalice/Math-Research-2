"""Count complete original-root proofs, preserving input and phase scope."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

def read(p):
    return json.loads(p.read_bytes())

def dig(p):
    return sha256(p.read_bytes()).hexdigest()

def ancestors(path,pack):
    filename=pack['source'].split('/')[0]
    p=path/(filename+'.jsonl')
    l=p.read_bytes().splitlines()
    receipt=read(p.with_name(p.stem+'-receipt.json'))
    h=dig(p)
    assert receipt['complete'] and receipt['result_sha256']==h==pack['verified_parent_sha256']
    j=pack['verified_parent_line']
    parent=json.loads(l[j-1])
    assert parent['goal']=='67/80' and parent['leaf']==pack['leaf']
    assert parent['stats'][7]==1 and parent['stats'][5]==0 and parent['stats'][0]==0
    assert parent['pending']==len(pack['regions']) and pack['regions']
    assert not parent['guard_uses'] and parent['guards']==0
    f=path/'frontiers'/pack['source']
    assert read(f)==pack['regions'] and dig(f)==pack['digest']
    assert parent['stats'][1]==pack['prefix_visited']==2*sum(pack['prefix_terminal_counts'])+len(pack['regions'])-1
    assert parent['stats'][2:5]==pack['prefix_terminal_counts']
    ancestors=[]
    for row in pack['regions']:
        q=[list(v)for v in zip(parent['lo'],parent['hi'],strict=True)]
        for step in row['steps']:
            k,s=divmod(step,2)
            a,b=q[k]
            assert 0<=k<11 and (a+b)%2==0 and a<b
            q[k][1-s]=(a+b)//2
        assert q==row['bounds']
        now=tuple(row['steps'])
        for pre in ancestors:
            distinct=[t for t in range(min(len(pre),len(now)))if pre[t]!=now[t]]
            assert distinct and pre[distinct[0]]//2==now[distinct[0]]//2
        ancestors.append(now)
    return dict(source=f.name,parent=p.name,parent_sha256=h,parent_line=j,frontier_sha256=dig(f))

def closed_rows(p):
    rows={}
    for line in p.read_bytes().splitlines():
        v=json.loads(line)
        x=tuple(v['leaf'])
        assert x not in rows and F(v['target'])==F(67,80)
        a,b,c,d,e=v['out']
        if a:
            assert a==1 and v['front'] is None and b==2*(c+d)-1
        else:
            assert len(v['front'])==22
        rows[x]=v
    return rows

def main(a):
    ledger=read(a.ledger)
    exact=set(ledger['models']['original_with_both_Q']['unresolved']) & set(ledger['models']['replacement_with_both_Q']['unresolved'])
    assert F(ledger['target'])==F(67,80) and ledger['strict'] and ledger['scope']==5442
    accepted={}
    stats={}
    for bank,points,receipt,packet,result in a.case:
        bank,points,receipt,packet,result=map(Path,(bank,points,receipt,packet,result))
        b=read(receipt)
        assert b['bank_sha256']==dig(bank) and b['input_sha256']==dig(points)
        assert b['both_hands_closed_cells']==2*read(bank)['knots']
        assert b['rows']==sum(map(len,read(bank)['cells']))
        pp=read(points)['points']
        assert isinstance(pp,list)
        num=len(pp)
        rows=closed_rows(result)
        if str(packet)!='-':
            roots=read(packet)
            assert len(rows)==sum(len(t['regions'])for t in roots)
        else:
            roots=[dict(leaf='/'.join(map(str,x)))for x in rows]
            assert all(len(x)==2 for x in rows)
        complete=0
        for r in roots:
            label=r['leaf']
            assert label in exact
            R=tuple(map(int,label.split('/')))
            parts=r.get('regions')
            records=[rows[(*R,i)]for i in range(len(parts))] if parts is not None else [rows[R]]
            if not all(q['out'][0]for q in records):
                continue
            actual=ancestors(a.refined,r) if parts is not None else {}
            prefix=r.get('prefix_terminal_counts',[0,0,0])
            visited,old5,arc=sum(c['out'][1]for c in records),sum(c['out'][2]for c in records),sum(c['out'][3]for c in records)
            V=int(r.get('prefix_visited',0))+visited
            terminals=sum(prefix)+old5+arc
            assert V==2*terminals-1
            models=[k for k,c in zip(('P30','oldQ11','P152-interior-'+str(num)),(*prefix[1:],arc),strict=True)if c]
            proof=dict(task_source=label,prefix=actual,residual_boxes=len(records),
                output_sha256=dig(result),geometry_whole=True,archived_prefix_terminals=prefix,
                current=dict(visited=visited,five=old5,P152=arc),whole_visited=V,
                point_bank_sha256=dig(bank),point_input_sha256=dig(points),actual_extra_inputs=models)
            accepted.setdefault(label,[]).append(proof)
            complete+=1
        stats[result.name]=dict(original_roots=len(roots),fully_closed_original_roots=complete,
            native_boxes=len(rows),passed_boxes=sum(x['out'][0]for x in rows.values()),visits=sum(x['out'][1]for x in rows.values()),
            new_P152_nodes=sum(x['out'][3]for x in rows.values()),source_sha256=dig(result))
        print(result.name,stats[result.name],flush=True)
    a.out.write_text(json.dumps(dict(target='67/80',strict=True,shared_old_failed_count=len(exact),original_scope=5442,
        original_baseline_sha256=dig(a.ledger),runs=stats,accepted=accepted),indent=2)+'\n')
    print('complete original roots',sorted(accepted),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('ledger','refined','out'):
        p.add_argument(k,type=Path)
    p.add_argument('--case',action='append',nargs=5,required=True,metavar=('BANK','POINTS','RECEIPT','PACKET','NATIVE'))
    main(p.parse_args())

"""Strict rational interior samples of the R219 P152 Reuleaux pentagon."""
from argparse import ArgumentParser
from fractions import Fraction as F
import json
from pathlib import Path
import sys

from flint import arb

HERE=Path(__file__).resolve().parent
PROFILE=HERE
sys.path.insert(0,str(PROFILE))
from bodies import ar,dot,sub,digest,profiles,SOURCES

def main(a):
    p=profiles(a.comp.resolve())['P152']
    centers=[c for l,r,c in p.runs]
    assert len(centers)==5
    assert max(dot(c,c).upper()for c in centers)<ar(F('.6')**2)
    den=10**10
    contraction=ar(F(999999,10**6))
    full=[]
    for index, v in enumerate(p.samples(6)):
        if index%7==6:
            continue
        z=tuple(round(float(contraction*x)*den)for x in v)
        assert all(abs(ar(F(c,den))-contraction*x)<ar(F(1,den)) for c,x in zip(z,v,strict=True))
        full.append(z)
    assert len(set(full))==30
    a.out.mkdir(exist_ok=True)
    for pts in (full[::2],full):
        raw=[tuple(ar(F(i,den))for i in z)for z in pts]
        diameter=max((x-u)**2+(y-v)**2 for x,y in pts for u,v in pts)
        gap=min((1-dot(sub(p,c),sub(p,c))).lower()for p in raw for c in centers)
        assert 0<diameter<den*den and gap>0
        report=dict(denominator=den,points=pts,recipe=dict(body='P152',parameters=['6/5','.08464386'],
           exact_contraction='999999/1000000',arcs=[5,6],indices=list(range(0,30,30//len(pts)))),
           source_sha256=SOURCES,profile_verifier_sha256=digest(PROFILE/'bodies.py'),
           diameter_sq_numerator=diameter,diameter_sq_denominator=den*den,strict_interior_slack=str(gap))
        path=a.out/f'points-{len(pts)}.json'
        path.write_text(json.dumps(report,indent=2)+'\n')
        print(path.name,digest(path),diameter,str(gap),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('out',type=Path)
    main(p.parse_args())

# P152 内部 15 点的两枚完整原叶证书

严格门槛为 $67/80=0.83750$。两枚 Tomar v9 原叶使用同一组七个独立输入。五个曲体为半径一半的圆盘和正 Reuleaux 三、五、七、九边形，另有原旧 $Q_{11}$ 和 P152 的固定 15 个内部有理点。各输入允许独立平移、旋转和反射。

| 原叶 | R248 前缀访问 | 前缀终端 五体／旧 Q11 | P152 后缀访问 | 后缀终端 五体／15 点 | 整叶访问 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1201/62085 | 65,535 | 26,859／5,905 | 372,872 | 136,079／50,361 | 438,407 |
| 1201/67150 | 65,535 | 29,077／3,687 | 861,140 | 410,303／20,271 | 926,675 |

每枚旧前缀的八个待证闭盒均由重新编译的新核排除。旧前缀重跑中使用原批次的包含盒生成共享区间数据，访问节点只属于这两枚原叶。复核原根、闭中分面、全部余盒地址和完整二叉计数。原 P30、替换 P30 和新 Q11 在这两枚证明中的终端计数均为零。两枚在 R251 的两种旧八输入冻结账本中仍列为未决。全域 $0.83750$ 仍需闭合其余原叶。

## 几何和严格角表

P152 为 R219 的 $P(6/5,.08464386)$。从真五边形五段单位弧得到 30 个候选，乘 $999999/1000000$ 后取 $10^{-10}$ 格点，以定向 Arb 验证它们全部严格位于定义五边形的五个真单位圆盘内。活动材料贪心选出的固定 15 个点是该集合的有理子集，平方直径为 $99999800014270493885/10^{20}<1$，点集 SHA-256 为 fd28a8fb8beb00f3b30daa4b62fedc30753fb153a4143867d792cab66cba21c4。

相位库的整数倍率为 $2^{28}$。256 个有理法向、两手各 384 个闭角格及 21,528 条正平衡三元行逐条重算。精确平衡消去同一二维平移。三元行以实际材料点的加权余弦、正弦系数 $A,B$ 在半格宽 $s$ 上使用严格下端 $A\cos s-|B|\sin s$。面积核使用已认证的五曲体材料、整盒支撑、圆盘帽和长弦帽。阈值为 $120696470013529293/2^{57}>67/80$。

## 公共来源与单入口

COMP 指项目的 lebesgue-universal-cover/computation。TREE 是官方 Tomar v9 的 cert11d_08366 解压目录，TABLE64 是已冻结的 64 级 .npz 材料表。OUT 是新建输出目录，CACHE 可指既有 Clang 模块缓存。需要 Clang C++17、Python、NumPy、SciPy 与 python-flint。

~~~sh
PY -I -B verify.py COMP TREE TABLE64 OUT --cache CACHE
~~~

入口自动从 COMP/whole-leaves-083750-second/wave2.zip 抽取必要的公开 R248 材料。两个旧前缀分别在卷内 public-replay-r2-083750/refined/refined-m1-b65535-01.jsonl 第 52 行和 public-replay-r2-083750/refined/refined-m1-b65535-02.jsonl 第 37 行。对应余盒位于同目录下 frontiers/refined-m1-b65535-01/1201-62085-mode1-frontier.json 和 frontiers/refined-m1-b65535-02/1201-67150-mode1-frontier.json。只重放这两枚原叶，保留公开原批次的共享几何预处理范围。旧回执的比较去除四个 CPU 计时字段，全部数学字段与余盒文件一起核对。

new-kernel 包含 R251 COMP/lower-083750-refinement/wave3.zip 所发布的 q-curvature 源码、帽头文件及调用驱动，入口核验副本与公开卷逐字节一致。公开 R248、R251 卷、原树、材料表和固定输入的精确哈希在 prepare_prefix.py 和 public-fingerprints.json。全部 16 个余盒、原材料点号、旧前缀引用和预期整叶回执包含在本包中。

完成后 OUT/verification.json 与 expected-replay.json 字节相等，OUT/verified-whole.json 与同名冻结回执字节相等。成功终讯为 Both independent kernels replayed. All 16 suffix boxes close.

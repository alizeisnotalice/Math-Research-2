"""Certify the original asymmetric eleven-point set on both handed angle circles."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from flint import arb,ctx
def run(bank,source,out,report,n):
    ctx.prec=192
    B=json.loads(bank.read_bytes());d=json.loads(source.read_bytes())
    assert hashlib.sha256(source.read_bytes()).hexdigest()=='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
    pts=d['points'];den=d['point_denominator'];G=B['directions'];g=np.array(G);U=2**22;Z=2**28;K=B['knots'];pi=arb.pi()
    assert max((x-a)**2+(y-b)**2 for x,y in pts for a,b in pts)<den**2
    stats={};changes={};sw,cw=(pi/(K*n)).sin_cos()
    for k,cell in enumerate(B['cells'][K:]):
        certified=[None]*len(cell)
        for sign in [1,-1]:
            P=[(x,y*sign) for x,y in pts];X=np.asarray(P)
            for h in range(n):
                sn,cs=((2*(k*n+h)+1)*pi/(K*n)).sin_cos()
                s=float(sn.mid());c=float(cs.mid())
                selected=(g@(X@np.asarray([[c,s],[-s,c]])).T).argmax(axis=1)
                cache={}
                for j,r in enumerate(cell):
                    ids=r[:3];weights=r[3:6];ws=r[6]
                    for i in ids:
                        if i not in cache:
                            x,y=P[selected[i]];a,b=G[i];u=a*cs+b*sn;v=-a*sn+b*cs
                            cache[i]=(u*x+v*y,v*x-u*y)
                    A=sum(w*cache[i][0] for w,i in zip(weights,ids));B1=sum(w*cache[i][1] for w,i in zip(weights,ids))
                    assert A>0
                    lo=int(((A*cw-abs(B1)*sw)*Z/(ws*den*U)).lower().floor().unique_fmpz())
                    certified[j]=lo if certified[j] is None else min(lo,certified[j])
        for j,(r,lo) in enumerate(zip(cell,certified)):
            loss=max(r[7]-lo,0);stats[loss]=stats.get(loss,0)+1
            if loss:changes[f'{k}/{j}']=loss;r[7]=lo
    out.write_text(json.dumps(B,separators=(',',':'))+'\n')
    result=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),old_bank=hashlib.sha256(bank.read_bytes()).hexdigest(),new_bank=hashlib.sha256(out.read_bytes()).hexdigest(),verified_rows=stats,changed=changes,subdivisions=n)
    report.write_text(json.dumps(result,indent=2)+'\n');print(stats,flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for s in ['bank','source','out','report']:parser.add_argument(s,type=Path)
    parser.add_argument('--subdivisions',type=int,default=2);a=parser.parse_args();run(a.bank,a.source,a.out,a.report,a.subdivisions)

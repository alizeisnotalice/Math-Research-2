# Original eleven physical points on both handed orientation circles

The physical input is the original eleven-point rational cloud in COMP/multi-host-points.json (SHA256 9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282). The previous ordinary bank takes the reflected average of this cloud, whose denominators are doubled. Its unconstrained finite input is a different, exactly symmetric configuration. The statements for the reflected average and the physical cloud can be tracked separately.

For each of the 12,885 Q rows of the old 384-cell bank, use the physical coordinates and their reflection across the horizontal axis as two independent cases. Split each angular interval into four closed subintervals. In any one subinterval the same material vertex can be used for each normal over the whole interval. A floating-point maximization chooses these vertices at the midpoint. The 192-bit Arb evaluation then uses their original integer coordinates, its exact positive balanced weights, and the exact rational normals. The weighted projection at offset t is A cos(t)+B sin(t). Since A>0, its lower bound on |t|≤w is A cos(w)−|B|sin(w). This verifies all real orientations without requiring the numerical choices to be maximizers. The minimum over the eight checks gives a row integer valid for both physical hands. Relative to the symmetric bank, 12,786 rows retain their integer score and 99 are decreased by one. The unchanged P128 half still uses the original Arb verifier.

With ORDINARY extracted from portable-ordinary46, decompress ORDINARY/ordinary-bank.json.gz to ordinary-bank.json, then run

```sh
python -B physical_rows.py ordinary-bank.json "$COMP/multi-host-points.json" physical-bank.json checked.json --subdivisions 4
```

The expected new bank SHA256 is 97d2d0c35d74dedb0577ac4d9311e1bf9cdb0cd827fdadae07a86d70438f0223. The archive's physical-check.json contains every changed row. Supplying physical-bank.json to the same integral geometry kernel certifies the physical input directly. The unchanged 183 shard only uses P128 or pure five-body certificates.

The physical_replay.py program accepts low (old-Q-only), shards (P128 plus old Q), and focused (0.83748) ledgers. An independent recomputation checks that every requested subbox closes and records any changed tree statistics. For example, with FIFTEEN the extracted fifteen-shards.zip and SIX, ONE the extracted six-oldq-tails.zip and single-154818.zip, run

```sh
python -B physical_replay.py "$ORDINARY" "$COMP" "$TREE" "$TABLE" "$BOTH" physical-bank.json "$WORK50" shards "$FIFTEEN/shards.json.gz"
python -B physical_replay.py "$ORDINARY" "$COMP" "$TREE" "$TABLE" "$Q_ONLY" physical-bank.json "$WORK46" low "$SIX/tails.json.gz" "$ONE/tails.json.gz"
```

"""Evaluate exact physical asymmetric Q11 using a two-handed certified score bank."""
from pathlib import Path
import argparse,gzip,json,sys

def read(p):return json.loads(gzip.decompress(p.read_bytes()))
def run(a):
    sys.path.insert(0,str(a.ordinary.resolve()))
    from run_native import run as calculate
    packets=[];before=[]
    for p in a.ledgers:
        v=read(p)
        if a.kind=='shards':seq=[x for k,x in v['entries'].items() if v['parts'][k.split('/')[0]]['transfer']!='P128']
        else:seq=v
        packets.extend(x['packet'] for x in seq)
        before.extend(r for x in seq for r in x['receipts' if a.kind=='low' else 'subtrees'])
    assert len(set(p['leaf'] for p in packets))==len(packets)
    a.scratch.mkdir(exist_ok=True);pf=a.scratch/'packets.json';pf.write_text(json.dumps(packets))
    out=a.scratch/'receipt.jsonl'
    calculate(argparse.Namespace(comp=a.comp,tree=a.tree,table=a.table,lib=a.kernel,bank=a.bank,output=out,caps=True,mesh=True,target={'shards':'.83750','low':'.83746','focused':'.83748'}[a.kind],cap=4194303,workers=a.workers,index=None,only=','.join(p['leaf'] for p in packets),resume=None,precontract=0,frontiers=pf))
    after=list(map(json.loads,out.read_text().splitlines()));assert len(before)==len(after)
    diff=[(x,y) for x,y in zip(before,after,strict=True) if x!=y]
    print('subtrees',len(before),'identical',len(before)-len(diff),'unclosed',sum(not r['out'][0] for r in after),flush=True)
    assert all(x['leaf']==y['leaf'] and x['target']==y['target'] for x,y in zip(before,after))
    (a.scratch/'differences.json').write_text(json.dumps(diff,indent=2)+'\n')
    assert all(r['out'][0] for r in after)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ['ordinary','comp','tree','table','kernel','bank','scratch']:p.add_argument(n,type=Path)
    p.add_argument('kind',choices=['low','shards','focused']);p.add_argument('ledgers',nargs='+',type=Path);p.add_argument('--workers',type=int,default=4);run(p.parse_args())

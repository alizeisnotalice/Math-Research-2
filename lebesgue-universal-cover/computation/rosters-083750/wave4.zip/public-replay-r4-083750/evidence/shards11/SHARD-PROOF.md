# Whole original shards at the target 67/80

For each shard in `shards.json.gz`, every normalized canonical five-body pose in that entire shard, and every independent rigid placement of the finite inputs named in its transfer field, yields hull area strictly above 0.83750. The prior R2 exterior certifies the complementary raw-tree leaves until its stage-4 list. The 873-leaf R2 index authenticates all previously successful stage-4 members. Its original 30-point projection inequalities transfer to the fixed augmented P128 since all 2,493 positive balanced rows retain their normals and weights and improve by at least 74,526 integer units. The old Q11 is the exact symmetric rational set of the same R2 rows. These prior geometric claims and the higher-target exterior are the inherited inputs to the present proof.

On the remaining stage-4 leaves of each listed shard, the old R2 forward search supplied actual closed terminals and a complete dyadic frontier at exactly 67/80. The new ordinary angular bank certifies every rectangle of each such frontier. A one-input designation additionally requires all historical prefix stops on the unresolved leaves to exclude uses of the other finite set. In shard 183, we also eliminate the historical old-Q-only certificates on 183/66124 and 183/88516 by pure-five checks on their full original roots. The remaining historical successes involve 23 pure-five roots and 73 supported by original P30 rows. Thus the complete original shard 183 uses only the five curves and the augmented P128. Other listed shards with the ordinary designation allow both independent inputs. An original root can still use fewer inputs than the entire shard.

The exact high prefix, source file, line and hash, every original dyadic address, and every new geometry count are frozen for each newly completed leaf. The verifier reconstructs the original-root subboxes, checks all input hashes and reruns the whole new search. The ordinary control library disables cross-input cap logic; every positive point terminal here is a valid single-input obstruction.

Use the portable-ordinary46 package for ORDINARY; its complete proof and reproduction commands define COMP, TREE, TABLE and the P-only library. For BOTH compile its ordinary-control.cpp with `-DNO_SPLIT_MASK` and neither single-input macro. R2 is the frozen public-replay-r2-083750 package. Run
```sh
python -B audit_shards.py "$R2"
python -B replay_shards.py "$ORDINARY" "$COMP" "$TREE" "$TABLE" "$P_ONLY" "$BOTH" "$R2" "$SCRATCH" --workers 4
```
The symbolic R2 inclusion and support-row comparison apply at the same high target to the certified complete shards. No claim about shards missing from the manifest is implied.

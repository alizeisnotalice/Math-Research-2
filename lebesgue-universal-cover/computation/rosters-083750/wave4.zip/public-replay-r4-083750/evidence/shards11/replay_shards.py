from pathlib import Path
import argparse,json,gzip,sys
from audit_shards import audit
def run(ordinary,comp,tree,table,p_only,both,r2,scratch,workers):
    root=Path(__file__).resolve().parent;sys.path.insert(0,str(ordinary.resolve()));scratch.mkdir(parents=True,exist_ok=True)
    from run_native import run as calculate
    from verify_ordinary import run as check
    from hashlib import sha256
    for folder in (ordinary,root):
        for rec in (folder/'SHA256SUMS').read_text().splitlines():
            h,n=rec.split('  ');assert sha256((folder/n).read_bytes()).hexdigest()==h
    source=json.loads(gzip.decompress((root/'shards.json.gz').read_bytes()))
    bank=scratch/'bank.json';bank.write_bytes(gzip.decompress((ordinary/'ordinary-bank.json.gz').read_bytes()));assert check(ordinary,comp,bank)==[9934,12885]
    def batch(name,lib,ks,pk,want):
        front=None
        if pk is not None:front=scratch/(name+'-frontiers.json');front.write_text(json.dumps(pk,separators=(',',':')))
        out=scratch/(name+'.jsonl')
        calculate(argparse.Namespace(comp=comp,tree=tree,table=table,lib=lib,bank=bank,output=out,caps=True,mesh=True,target='.83750',cap=4194303,workers=workers,index=None,only=','.join(ks),resume=None,precontract=0,frontiers=front))
        got=list(map(json.loads,out.read_text().splitlines()));assert got==want,(name,len(got))
    for family,lib,name in [('P128',p_only,'single'),('P128+oldQ11',both,'ordinary')]:
        ks=[k for v in source['parts'].values() if v['transfer']==family for k in v['keys']]
        if ks:batch(name,lib,ks,[source['entries'][k]['packet'] for k in ks],[r for k in ks for r in source['entries'][k]['subtrees']])
    rs=source['pure_replacements']
    if rs:batch('replacements',p_only,['/'.join(map(str,r['leaf'])) for r in rs],None,rs)
    return audit(root,r2)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ['ordinary','comp','tree','table','p_only','both','r2','scratch']:p.add_argument(n,type=Path)
    p.add_argument('--workers',type=int,default=4);a=p.parse_args();assert __debug__;print(run(**vars(a)))

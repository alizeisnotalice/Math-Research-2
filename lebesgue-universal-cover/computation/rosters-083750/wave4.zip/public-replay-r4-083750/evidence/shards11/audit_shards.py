from pathlib import Path
from fractions import Fraction as F
import json,gzip,hashlib,sys
from itertools import combinations
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(root,r2):
    ledger=json.loads(gzip.decompress((root/'shards.json.gz').read_bytes()));ix=r2/'joined-r2-plus-five-index.json';sf=r2/'stage4-retained.json';assert sha(ix)==ledger['source_prefix_index_sha256'] and sha(sf)==ledger['stage4_sha256']
    idx=read(ix);stage=read(sf);assert idx['unresolved']==873 and idx['stage4_retained']==5442
    stats={}
    for p,z in ledger['parts'].items():
        b=idx['parts'][p];assert z['baseline']==b and z['stage4']==stage[p] and set(stage[p])==set(b['remaining']+b['five']+b['P30']+b['Q11'])
        assert z['keys']==[f'{p}/{j}' for j in b['remaining']];six=z['transfer']=='P128'
        if six:
            rr=[r for r in ledger['pure_replacements'] if r['leaf'][0]==int(p)];assert set(b['Q11'])=={r['leaf'][1] for r in rr} and all(F(r['target'])==F(67,80) and r['out'][0] and r['out'][3]==0 for r in rr)
        nodes=pt=qt=ft=boxes=0
        for k in z['keys']:
            rec=ledger['entries'][k];q=rec['packet'];f=r2/rec['source'];assert sha(f)==rec['sha256'];r=json.loads(f.read_text().splitlines()[rec['line']-1]);assert r==rec['prefix'] and not r['stats'][0] and r['leaf']==k and F(r['goal'])==F(67,80)
            front=r2/'refined/frontiers'/q['source'];assert sha(front)==q['digest'] and read(front)==q['regions'] and len(q['regions'])==len(rec['subtrees'])==r['pending']
            assert r['stats'][1]==2*sum(r['stats'][2:6])+r['pending']-1
            if six:assert r['stats'][4]==0
            for j,(sub,box) in enumerate(zip(rec['subtrees'],q['regions'],strict=True)):
                assert sub['leaf']==[*map(int,k.split('/')),j] and F(sub['target'])==F(67,80)
                a=sub['out'];assert a[0]==1 and a[1]==2*(a[2]+a[3])-1 and a[3]==sub['P128']+sub['oldQ'] and sub['paired']==0 and sub['front'] is None
                if six:assert sub['oldQ']==0
                measured=[list(v) for v in zip(r['lo'],r['hi'])]
                for step in box['steps']:
                    i,s=divmod(step,2);l,h=measured[i];assert 0<=i<11 and l<h and (l+h)%2==0;measured[i][1-s]=(l+h)//2
                assert measured==box['bounds'];nodes+=a[1];pt+=sub['P128'];qt+=sub['oldQ'];ft+=a[2];boxes+=1
            for a,bx in combinations(q['regions'],2):
                a0,b0=a['steps'],bx['steps'];j=next(j for j in range(min(len(a0),len(b0))) if a0[j]!=b0[j]);assert a0[j]//2==b0[j]//2
        stats[p]=dict(stage4=len(stage[p]),inherited=len(stage[p])-len(z['keys']),previously_open=len(z['keys']),new_boxes=boxes,new_visits=nodes,new_five=ft,new_p128=pt,new_oldq=qt,family=z['transfer'])
    return stats
if __name__=='__main__':print(json.dumps(audit(Path(__file__).resolve().parent,Path(sys.argv[1])),indent=2))

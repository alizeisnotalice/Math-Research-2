# 逐份几何复算

以下从本目录执行。R248 指 wave2.zip 中 public-replay-r2-083750 解包目录。其它输入和环境与主说明同。所有产物路径应指向新鲜的可写临时位置。

## 分片的两组原生形体

P_ONLY 与 BOTH 对应同一份整盒几何核。冻结组合中 BOTH 的第二点集是精确 $Q_{\rm avg}$。

~~~sh
clang++ -O3 -std=c++17 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error \
    -shared -fPIC "-fmodules-cache-path=$CACHE" -I "$COMP/three-leaf-083750" \
    -DNO_SPLIT_MASK -DP128_ONLY evidence/p128/ordinary-control.cpp -o "$P_ONLY"
clang++ -O3 -std=c++17 -fsanitize=signed-integer-overflow -fsanitize-undefined-trap-on-error \
    -shared -fPIC "-fmodules-cache-path=$CACHE" -I "$COMP/three-leaf-083750" \
    -DNO_SPLIT_MASK evidence/p128/ordinary-control.cpp -o "$BOTH"

python -B evidence/shards15/replay_shards.py evidence/p128 "$COMP" "$TREE" "$TABLE64" \
    "$P_ONLY" "$BOTH" "$R248" "$WORK/shards" --workers 4
~~~

将 shards15 换成 shards11 可复现前一步 11 分片。15 分片脚本核全部新增子盒和两枚纯五重证，逐条与冻结回执比对。两点组的端点不足已由 replay_ledger.py 独立验证。

## 保持原物理旧十一点

MacBook 的两批输入按原叶独立运行。以 JOB=01 或 02 和两位分片编号 INDEX 指定工作。先从 keys.json 取第 INDEX 项作为唯一键的新数组，再从 subboxes.json 筛选所有 leaf 等于该键的项。原有的 steps、bounds、label 保持原值。取与相应冻结结果中 budget 相同的数。

~~~sh
python -I -B "evidence/mac-$JOB/run_neighbors.py" "$COMP" "$R248" "$TREE" "$TABLE64" \
    "$WORK/mac-$JOB-$INDEX" "$CACHE" "evidence/mac-$JOB" "$KEYS" \
    --mode expanded-original --budget "$BUDGET" --subboxes "$SUBBOXES" \
    --frontier "$NEW_FRONTIER" > "$RESULT"
~~~

12 邻叶的冻结文件和脚本在 evidence/neighbors。该目录的 old-q-replay.md 包含原根重跑、未闭子盒续算和预算升级的命令；audit_continued_neighbors.py 检查三枚续算树，audit_family.py 检查其余九枚原根。直接运行主包的 replay_ledger.py 亦重建全部 12 枚的原确切端点。

以实际物理旧十一点重制分片使用的行表和运行高靶的后续分片模式。冻结的物理银行核验 SHA 为 97d2d0c35d74dedb0577ac4d9311e1bf9cdb0cd827fdadae07a86d70438f0223。

~~~sh
gzip -dc evidence/p128/ordinary-bank.json.gz > "$WORK/average-bank.json"
python -B evidence/physical-q-bank/physical_rows.py "$WORK/average-bank.json" \
    "$COMP/multi-host-points.json" "$WORK/physical-bank.json" "$WORK/bank-report.json" \
    --subdivisions 4
python -B evidence/physical-q-bank/physical_replay.py evidence/p128 "$COMP" "$TREE" \
    "$TABLE64" "$BOTH" "$WORK/physical-bank.json" "$WORK/physical-shards" \
    shards evidence/shards15/shards.json.gz
~~~

该物理银行及失败行证明已经核验，按该表重算的新整叶需以新实际执行证明另计。

## P152 的两枚整叶

~~~sh
python -I -B evidence/p152/verify.py "$COMP" "$TREE" "$TABLE64" "$WORK/p152" \
    --cache "$CACHE"
~~~

该入口重算 15 个真实内部点、完整双手闭格，复跑 R248 两段原前缀及 16 个待闭盒。其公开源和原材料校验规则见 evidence/p152/README.md。

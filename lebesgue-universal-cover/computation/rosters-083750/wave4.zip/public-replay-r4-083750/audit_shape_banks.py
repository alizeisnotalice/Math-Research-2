"""Compare anchored 2493-row supports and the distinct 256-normal shard bank."""
from argparse import ArgumentParser
from fractions import Fraction as F
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb, ctx
import numpy as np

def obj(p):
    return json.loads(p.read_bytes())

def dig(p):
    return sha256(p.read_bytes()).hexdigest()

def xy(d):
    return {(F(x,d['denominator']),F(y,d['denominator'])) for x,y in d['points']}

def coarse_projections(grid,dots,theta):
    V=np.asarray(grid,dtype=float)
    X=np.asarray(dots,dtype=float)
    s,c=np.sin(theta),np.cos(theta)
    return V@((X@np.array([[c,s],[-s,c]])).T)

def inspect_binding(dots,den,directions,cells):
    # The midpoint support point is a search choice. Arb verifies the whole
    # row and, where necessary, optimizes each wall exactly at a closed end.
    U=2**22;Z=2**28
    pi=arb.pi()
    sw,cw=(pi/384).sin_cos()
    passed=total=0
    witnesses=[]
    first_undecided=None
    for j,cell in enumerate(cells):
        angle=(2*j+1)*pi/384
        sn,cs=angle.sin_cos()
        pick=coarse_projections(directions,dots,float(angle.mid())).argmax(axis=1)
        terms={}
        ends={}
        def linear_coeff(i):
            if i not in terms:
                a,b=directions[i]
                x,y=dots[pick[i]]
                v=a*cs+b*sn
                w=-a*sn+b*cs
                terms[i]=(v*x+w*y,w*x-v*y)
            return terms[i]
        def endpoint_upper(i,e):
            if (i,e) not in ends:
                a,b=directions[i]
                t=(2*j+2*e)*pi/384
                s,c=t.sin_cos()
                u,v=a*c+b*s,-a*s+b*c
                points=[(u*x+v*y).upper() for x,y in dots]
                ends[i,e]=max(points)
            return ends[i,e]
        for k,row in enumerate(cell):
            d=row[:3];w=row[3:6];weight,stored=row[6:]
            A=sum(a*linear_coeff(i)[0] for i,a in zip(d,w,strict=True))
            B=sum(a*linear_coeff(i)[1] for i,a in zip(d,w,strict=True))
            assert A>0
            rhs=stored*weight*den*U
            total+=1
            if (A*cw-abs(B)*sw)*Z>=rhs:
                passed+=1
                continue
            if first_undecided is None:
                first_undecided=(j,k)
            if len(witnesses)>=6:
                continue
            for e in (0,1):
                high=sum(a*endpoint_upper(i,e) for i,a in zip(d,w,strict=True))*Z
                if high<rhs:
                    diff=(high-rhs)/(weight*den*U)
                    assert diff<0
                    witnesses.append(dict(cell=j,row=k,endpoint_numerator=2*j+2*e,
                         endpoint_denominator=384,stored_ticks=stored,
                         maximum_minus_stored_ticks_upper=str(diff.upper())))
                    break
    return dict(rows=total,certified_with_midpoint_labels=passed,
                failed_whole_row_checks=total-passed,first_not_recertified=first_undecided,
                impossible_rows_with_exact_endpoint_witness=witnesses)

def main(a):
    path128=a.p128/'inputs/augmented.json'
    archive=a.p128/'ordinary-bank.json.gz'
    p128=obj(path128);p66=obj(a.p66);new=obj(a.r2/'new-p30/points.json')
    assert (len(xy(p128)),len(xy(p66)),len(xy(new)))==(128,66,30)
    assert xy(p66)<=xy(p128) and xy(new)<=xy(p128)
    assert not xy(new)<=xy(p66)
    sys.path.insert(0,str(a.comp))
    from replay_q11_with_p30 import PointProof
    from build_q11_leaf_bank import reflected_average, EPS
    from certify_tomar_six_high import U
    from certify_tomar_six_high import Q as SCALE
    ctx.prec=192
    legacy=obj(a.comp/'finite-point-global-input.json')['cells']
    raw30=obj(a.comp/'finite-point-leaf-input.json')
    banks=[]
    for d in ({**raw30,'cells':legacy},{**new,'cells':legacy},p66,p128):
        proof=PointProof(d)
        banks.append(proof)
    reference=banks[0].triples.reshape(-1,8)
    all_tables=[v.triples.reshape(-1,8) for v in banks]
    assert reference.shape==(2493,8)
    assert all(np.array_equal(banks[0].pointers,q.pointers) for q in banks[1:])
    assert all(np.array_equal(reference[:,:7],q[:,:7]) for q in all_tables[1:])
    oldr,newr,r66,r128=[q[:,7] for q in all_tables]
    assert np.array_equal(r66,r128) and (r66>=newr).all() and (newr>=oldr).all()
    bank=json.loads(decompress(archive.read_bytes()))
    q_original=obj(a.comp/'multi-host-points.json')
    qavg=obj(a.p128/'inputs/q11-receipt.json')
    p,q=reflected_average(q_original)
    assert p==qavg['points'] and q==qavg['denominator']
    q_physical={'points':q_original['points'],'denominator':q_original['point_denominator']}
    assert xy(q_physical)!=xy(qavg)
    # Recheck all 128 and averaged-Q source rows using the donor's public
    # exact verifier, independently of the pre-existing long-tree runs.
    sys.path.insert(0,str(a.p128))
    from verify_ordinary import run
    class BytesBank:
        def read_bytes(self): return decompress(archive.read_bytes())
    checked=run(a.p128,a.comp,BytesBank())
    assert checked==[9934,12885]
    p_bound=inspect_binding(p66['points'],p66['denominator'],bank['directions'],bank['cells'][:384])
    q_bounds=[inspect_binding([(x,sign*y) for x,y in q_physical['points']],
                    q_physical['denominator'],bank['directions'],bank['cells'][384:]) for sign in (1,-1)]
    assert p_bound['impossible_rows_with_exact_endpoint_witness']
    assert any(k['impossible_rows_with_exact_endpoint_witness'] for k in q_bounds)
    penalty=(SCALE*F(U+2,U)*EPS).__ceil__()
    assert penalty==1
    qavg_cloud={k:qavg[k] for k in ('points','denominator')}
    a.qavg.write_text(json.dumps(qavg_cloud,sort_keys=True,separators=(',',':'))+'\n')
    out=dict(target='67/80',original_q_input_sha256=dig(a.comp/'multi-host-points.json'),
        average_q_cloud_sha256=dig(a.qavg),point_count_qavg=len(xy(qavg)),qavg_receipt_sha256=dig(a.p128/'inputs/q11-receipt.json'),
        p128_input_sha256=dig(path128),p66_input_sha256=dig(a.p66),
        replacement_p30_input_sha256=dig(a.r2/'new-p30/points.json'),
        p66_subset_p128=True,replacement_p30_subset_p128=True,replacement_p30_subset_p66=False,
        legacy_rows=2493,minimum_p66_minus_replacement_ticks=int((r66-newr).min()),
        minimum_p66_minus_original_ticks=int((r66-oldr).min()),
        p128_and_66_identical_legacy_table=True,old_q_legacy_penalty_ticks=penalty,
        shard_bank_sha256=dig(archive),rechecked_128_and_average_Q_rows=checked,
        p66_using_128_shard_rows=p_bound,physical_q_using_average_rows=q_bounds)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('physical_q_using_average_rows','p66_using_128_shard_rows')}),flush=True)
    print('failed physical transfers',p_bound['failed_whole_row_checks'],[x['failed_whole_row_checks']for x in q_bounds],flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('comp','r2','p128','p66','qavg','output'):
        p.add_argument(n,type=Path)
    main(p.parse_args())

"""Certify the exact optimum of the frozen two-handed P30 row system."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json
from flint import arb, arb_mat, ctx


def ar(n):
    q = F(n)
    return arb(q.numerator) / q.denominator


def dot(x,y):
    return sum(a*b for a,b in zip(x,y))


def cross(x,y):
    return x[0]*y[1]-x[1]*y[0]


def add(x,y):
    return [a+b for a,b in zip(x,y)]


def sub(x,y):
    return [a-b for a,b in zip(x,y)]


def scale(x,t):
    return [v*t for v in x]


def norm(x):
    return dot(x,x).sqrt()


def read(p, sha):
    assert sha256(p.read_bytes()).hexdigest()==sha
    return json.loads(p.read_bytes())


def run(comp, sharp, out):
    assert __debug__
    ctx.prec=320
    src=read(comp/'finite-point-leaf-input.json','b99b3bf66adf904b8b99ba1e1c7f8e75abc1ea6d8e00728b9553c20b961ffebc')
    bank=read(comp/'finite-point-global-input.json','348f983e915e77a50b55d627d3d2728a99377f7283dd67848896b0bcfff5469f')['cells']
    witness=read(sharp,'0ec2eaa6ba4ea6d2a14c5980aa2114c83444a9fcd5d48a75ae29221551f3167c')
    p=src['points']; U=src['direction_scale']; v=src['directions']
    P=[scale(z,ar(F(1,src['denominator']))) for z in p]
    X=[scale(z,ar(F(1,witness['denominator']))) for z in witness['points']]
    perm=[p.index([x,-y]) for x,y in p]
    assert all(witness['points'][j] == [witness['points'][i][0],-witness['points'][i][1]] for i,j in enumerate(perm))
    angles=[(arb.pi()*j/192).sin_cos() for j in range(385)]
    picked={(115,3,1),(128,2,1),(130,1,1),(194,6,1)}
    rows={}
    for c,cell in enumerate(bank):
        for r,row in enumerate(cell):
            vs=[v[i] for i in row[:3]]
            w=[cross(vs[(i+1)%3],vs[(i+2)%3]) for i in range(3)]
            if max(w)<0:w=[-j for j in w]
            assert min(w)>0 and all(sum(t*z[k] for t,z in zip(w,vs))==0 for k in range(2))
            for side,(sn,cs) in enumerate(angles[c:c+2]):
                rows[c,r,side]=[(j,scale([x*cs+y*sn,-x*sn+y*cs],ar(F(t,sum(w)*U))))
                                for j,(x,y),t in zip(row[3:],vs,w)]
    assert len(rows)==4986
    ids=[3,7,13,26]
    E=[]; L=[]; totals=[]
    for key in sorted(picked):
        f=[[arb(0),arb(0)] for _ in ids]
        base=arb(0)
        for j,force in rows[key]:
            base+=dot(force,P[j])
            i=j if j in ids else perm[j]
            k=ids.index(i)
            f[k]=add(f[k], [force[0],force[1] if i==j else -force[1]])
        E.append([f[0], f[1], add(add(f[0],f[1]),f[3])])
        sy=sum(z[1] for z in f)
        totals.append(sy)
        L.append(-base-sy/2)
    # lambda_4 = 1 - sum lambda_i. Grad H equals the three pairwise score differences.
    dE=[[sub(E[i][k],E[3][k]) for k in range(3)] for i in range(3)]
    dL=[L[j]-L[3] for j in range(3)]
    def eval_h(w):
        w4=list(w)+[1-sum(w)]
        sy=dot(w4,totals)
        assert sy<0 and all(x>0 for x in w4)
        e=[[sum(w4[j]*E[j][k][t] for j in range(4)) for t in range(2)] for k in range(3)]
        lengths=[norm(z) for z in e]
        assert all(l>0 for l in lengths)
        unit=[scale(z,1/l) for z,l in zip(e,lengths)]
        g=[dL[i]+sum(dot(unit[k],dE[i][k]) for k in range(3)) for i in range(3)]
        h=arb_mat([[sum(cross(e[k],dE[i][k])*cross(e[k],dE[j][k])/lengths[k]**3 for k in range(3)) for j in range(3)] for i in range(3)])
        return arb_mat([[z] for z in g]), h, sum(lengths)+dot(w4,L), unit, sy
    cen=list(map(ar,['.007172','.585667','.2618585']))
    for _ in range(7):
        g,h,*_=eval_h(cen)
        step=h.solve(g)
        cen=[(z-step[i,0]).mid() for i,z in enumerate(cen)]
    den=10**65
    nums=[int((z*den).floor().unique_fmpz()) for z in cen]
    cen=[ar(F(i,den)) for i in nums]
    radius=ar(F(1,10**56))
    ball=[v+arb(0,radius) for v in cen]
    g0,J0,*_=eval_h(cen)
    R=J0.inv()
    R=arb_mat([[R[i,j].mid() for j in range(3)] for i in range(3)])
    _,J,G,units,sy=eval_h(ball)
    I=arb_mat([[int(i==j) for j in range(3)] for i in range(3)])
    D=I-R*J
    q=max(sum(abs(D[i,j]) for j in range(3)).upper() for i in range(3))
    correction=R*g0
    shift=max(abs(correction[i,0]).upper() for i in range(3))
    assert not R.det().contains(0) and q<ar('1e-45') and shift+radius*q<radius
    # Banach fixes a root in the cube of radius 1e-56 centered at cen.
    X[13]=[X[13][0],ar(F(-1,2))]
    X[26]=add(X[13],units[2])
    X[3]=add(X[26],units[0]); X[7]=add(X[26],units[1])
    for j in ids:X[perm[j]]=[X[j][0],-X[j][1]]
    contacts={tuple(sorted(e)) for e in [(3,26),(7,26),(13,26),(13,14)]}
    contacts.update(tuple(sorted((perm[i],perm[j]))) for i,j in list(contacts))
    others=[dot(sub(X[i],X[j]),sub(X[i],X[j])) for i,j in combinations(range(30),2) if (i,j) not in contacts]
    assert len(contacts)==7 and len(others)==428 and max(z.upper() for z in others)<ar('.999976')
    rest=[]; z=[sub(a,b) for a,b in zip(X,P)]
    for key,terms in rows.items():
        g=sum(dot(z[j],n) for j,n in terms)
        if key in picked:assert (g-G).contains(0)
        else:rest.append(g.lower())
    assert min(rest)>ar('.00027623') and G>0 and len(rest)==4982
    # Rigorous fixed decimal output.
    places=50; bot=int((G*10**places).floor().unique_fmpz())
    assert ar(F(bot,10**places))<G and G<ar(F(bot+1,10**places))
    res=dict(complete=True,precision_bits=ctx.prec,center_denominator=den,center_numerators=nums,
             cube_radius='1e-56',max_contraction=str(q),newton_shift_bound=str(shift),
             gain_lower=f'{bot:0{places+1}d}'[:-places]+'.'+f'{bot:0{places+1}d}'[-places:],
             gain_upper='0.'+f'{bot+1:0{places}d}',active_endpoints=sorted(picked),active_pairs=sorted(contacts),
             others_squared_diameter_upper=str(max(z.upper() for z in others)),other_endpoints_lower=str(min(rest)),
             projection_sum_y=str(sy),max_noncontact_pairs=len(others),other_endpoints=len(rest),
             optimal_materials={str(j):[str(t) for t in X[j]] for j in ids})
    out.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
    print(res['gain_lower'],res['gain_upper'],len(rest),len(others))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for key in ['comp','sharp','out']:parser.add_argument(key,type=Path)
    a=parser.parse_args();run(a.comp,a.sharp,a.out)

# 运行固定标签精确极值证书

解压后在包根目录运行：

~~~sh
python -I -B active-p/certify.py inputs p-sharp.json local-result.json
~~~

仅需 Python 与 python-flint，本次实际运行使用 Python 3.13.18、python-flint 0.9.0。两份 inputs 文件就是 computation 中原三十点与全2493行的冻结文件，脚本检查逐字节 SHA-256。p-sharp.json 提供非活跃标签的有理坐标。输出的50位十进制严格夹逼、4982端点、428点对、根隔离盒与导数上下界应与 active-p/verified.json 一致。证明全文见 active-p/PROOF.md，双手性定义及四个关键行的原、反手物理标签在 two-hands.md，非对称云的取等性在 active-p/nonsymmetric-equality.md。

"""Rational finite witnesses transferred from the seven-body area theorem."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import gzip
import json
from pathlib import Path
from flint import arb, ctx

G = F(120690705406006259, 2**57)
FILENAMES = {
    'reduced66.json': '92aca7f3c93ab146de3b4cdd60565773eb11ca38ed272e7e101cd38868334ceb',
    'q11-receipt.json': 'dde1a3e389ea2f48325c2dfe29f032d359366afff255485890e323694fb3e313',
}

def library(file, name, pin):
    assert sha256(file.read_bytes()).hexdigest() == pin
    spec = importlib.util.spec_from_file_location(name, file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def first_odd(target):
    def val(n):
        return arb(G.numerator)/G.denominator * ((arb.pi()/n).cos()/(arb.pi()/(2*n)).cos())**2
    t = arb(target.numerator)/target.denominator
    a, b = 49, 50
    while not val(2*b+1)>t:
        assert val(2*b+1)<t
        b *= 2
    while a+1<b:
        mid=(a+b)//2
        value=val(2*mid+1)
        if value>t:b=mid
        else:
            assert value<t
            a=mid
    n=2*b+1
    assert val(n-2)<t<val(n)
    return {'first_odd': n, 'previous': str(val(n-2)), 'value': str(val(n))}

def main(comp, inputs, out):
    ctx.prec=224
    geom=library(comp/'projected-cap-transfer/certify_sparse_witness.py','geom',
                 'fb7624a306c8842dfcec7a0ad23995268c3527655819a271e267eacbe047c506')
    diam=library(comp/'deformed-point-transfer/finite_witness.py','diam',
                 '647e823d559cd3fb780717fb7b82df52a241509acfbc92db4fb6a78b553d67d4')
    geom.S=10**21
    geom.farthest=diam.axis_max
    out.mkdir(exist_ok=True,parents=True)
    poles=[]
    for (label,(name,pin)) in zip(('P66','Qavg'),FILENAMES.items(),strict=True):
        body=(inputs/name).read_bytes()
        assert sha256(body).hexdigest()==pin
        cloud=json.loads(body)
        sq,axis=diam.axis_max(cloud['points'])
        assert sq<cloud['denominator']**2
        exact=geom.exact_unit_cloud(label,cloud['points'],sq,axis)
        assert diam.axis_max(exact['points'])[0]==exact['denominator']**2
        poles.append(exact)
    report={'threshold': str(G), 'odd_bounds': {}, 'rational_examples': {}}
    for raw in ('.83745','.8374516664','.837459','.8374599','.83746'):
        report['odd_bounds'][raw]=first_odd(F(raw))
    for raw in ('.83745','.837459'):
        target=F(raw)
        n0=report['odd_bounds'][raw]['first_odd']
        clouds=[]; records=[]; inner=F(1)
        ratio=geom.ar(target/G).sqrt()
        for m in (0,3,5,7,9):
            k=n0 if m==0 else int((arb.pi()/(2*m*ratio.acos())).upper().ceil().unique_fmpz())
            while True:
                group, sq, _, axis=geom.curve_points(m,k,arb.pi())
                factor=F((geom.S-2)**2,sq)
                if factor*G>target:break
                k += 1 if m else 2
            assert diam.axis_max(group['points'])[0]==group['denominator']**2
            clouds.append(group)
            inner=min(inner,factor)
            records.append({'shape': group['body'],'grid': k,'integer_diameter_squared': sq,
                            'axis': axis, 'inner_squared': str(factor)})
        clouds.extend(poles)
        lo=G*inner
        assert target<lo<G and max(len(a['points']) for a in clouds)==n0
        name='rational-'+raw[1:]+'.json.gz'
        packet=gzip.compress(geom.packed(clouds),compresslevel=9,mtime=0)
        (out/name).write_bytes(packet)
        report['rational_examples'][raw]={'counts':[len(a['points']) for a in clouds],
            'true_rational_lower': str(lo), 'decimal_lower': geom.decimal_down(lo,24),
            'file': name, 'sha256': sha256(packet).hexdigest(), 'curves': records}
    (out/'finite.json').write_text(json.dumps(report,indent=2)+'\n')
    print({k:v['first_odd'] for k,v in report['odd_bounds'].items()})
    print({k:(v['counts'],v['decimal_lower']) for k,v in report['rational_examples'].items()})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('comp','inputs','out'):parser.add_argument(name,type=Path)
    args=parser.parse_args()
    main(args.comp,args.inputs,args.out)

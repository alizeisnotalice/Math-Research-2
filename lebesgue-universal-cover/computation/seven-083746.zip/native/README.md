# .83746 七个固定输入的原叶证书

固定输入为直径一的圆盘和正 Reuleaux 三、五、七、九边形，以及两个可各自刚体移动的有理点组。主证明采用 128 点及真实对称平均的 11 点 `Qavg`。完整坐标分别在 `inputs/augmented.json` 和 `inputs/q11-receipt.json`。`inputs/reduced66.json` 保存一个原角库等价的 66 点子集。原叶面积门槛为 `120690705406006259/2^57 > 41873/50000`。量词、七输入模型与高靶外域继承见 [PROOF.md](PROOF.md)。

## 源树和工具

- `COMP` 指项目检出的 `lebesgue-universal-cover/computation`。外域的原档和重跑入口见 `COMP/global-083750/README.md`。
- `TREE` 指 Tomar 公开树 `cert11d_08366` 的解包目录。`TREE/SHA256SUMS` 的 SHA-256 为 `56cbe5dfdadc6b5aa07cf6ec9acf4f637a3c4fa78db54df0ae2d78916d292410`。每个被访问的分片依清单核验，再按 `2^-44` 的整数网格恢复其闭盒端点。
- `TABLE` 是认证过的 64 扇区材料表。用 `"$PY" "$COMP/tomar_fan_table.py" "$TREE" "$TABLE" --subdiv 64` 构造。实际使用容器的 SHA-256 为 `0913f79e54bfcb804c8c4a4c0bbd7962d42d461591175ab037739b3562c6016d`。
- 实际软件为 Python 3.13.18、NumPy 2.5.5、python-flint 0.9.0 与 Apple Clang 21.0.0。整数核编译开启 `-O3 -std=c++17 -ftrapv`。Python 保留断言。

## 逐级覆盖核验

将 `volumes/*.zip` 分别解压到本目录。`inherited-high-seven.zip` 在原位由核验器读取。下列命令把每个独立续算目录交给核验器。

```sh
"$PY" -B "$PACKAGE/verify_interfaces.py" "$COMP" "$PACKAGE"
"$PY" -B "$PACKAGE/reduce_augmented.py" "$COMP" "$PACKAGE/inputs/augmented.json" "$FRESH66"
"$PY" -B "$PACKAGE/verify_qavg_transfer.py" "$COMP" "$PACKAGE" "$PACKAGE/inputs/q11-expanded-angles.json"
set -- --partner "$PACKAGE/partner"
for t in "$PACKAGE"/detached/*; do set -- "$@" --detached-tail "$t"; done
for t in "$PACKAGE"/old-q-tail*; do set -- "$@" --old-q-tail "$t"; done
"$PY" -B "$PACKAGE/audit_current.py" "$COMP" "$TREE" "$PACKAGE" "$AUDIT" "$@"
"$PY" -B "$PACKAGE/audit_p66_routes.py" "$PACKAGE" "$PACKAGE"/old-q-tail*
```

核验器检查全部 5,442 个末端原叶的分割，检查 4,569 枚高靶继承记录的原树端点、阈值与完整树计数，并从真实前沿重建其余原叶的闭盒覆盖。相同原叶的多份证书只计一次。继续阶段的访问次数按实际工作分开统计。两遍前缀可以相交，故累计访问数不代表一棵互不相交的完整证明树。

## 重新运行几何核

本工位每个原始包、交集包和尾部包都可独立重跑。`FRESH` 为尚未存在的新目录，`CACHE` 是 Clang 模块缓存。此命令实际匹配 6 个闭盒和 194,652 次整数核访问。

```sh
"$PY" -B "$PACKAGE/replay_packet.py" "$COMP" "$TREE" "$TABLE" "$FRESH" "$CACHE" \
  "$PACKAGE/results/tail0/tail-01.jsonl"
```

逐行核对除 CPU 计时外的全部字段，并逐字节比较完整未决前沿。相同入口也接受 `partner/` 及 `detached/` 内的原生回执行。替代法向核的独立后缀见 `replay-kits/`，其重跑禁用多输入混合和无关的输入通道。替代表以 `Qavg` 直接核过全部 12,885 条 Q 行。采用物理原 Q 双手性扣减的后缀表只有 99 行少一格，亦由同一 `Qavg` 下端支配。高靶外围、基础高靶末叶及补充 Q 的重跑入口见各上游计算包。哈希绑定实际输入与回执。全域结论同时依赖几何核的解析正确性及高靶到原尺度的包含。

"""Regenerate one archived terminal packet and check its structural receipt."""
from argparse import ArgumentParser
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys


TIMINGS = {'prep_cpu', 'search_cpu', 'bank_cpu', 'shared_prep_cpu'}


def read_rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def static_fields(row):
    return {k: v for k, v in row.items() if k not in TIMINGS}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ('comp', 'tree', 'table', 'scratch', 'cache', 'packet'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--depth', type=int)
    a = parser.parse_args()
    root = Path(__file__).resolve().parent
    batch = a.packet.resolve()
    tag = batch.stem
    tier = batch.relative_to(root).parts[0]
    assert tier in ('results', 'partner', 'detached')
    stored = read_rows(batch)
    assert stored
    first = stored[0]
    settings = ('goal', 'mode', 'q_mesh', 'budget', 'panels', 'q_trigger_divisor',
                'reanchor_level', 'reanchor_stride', 'sweep_limit', 'p30_family', 'p30_sha256')
    assert all(all(row[k] == first[k] for k in settings) for row in stored)
    subboxes = None
    if tier == 'detached':
        kernel = 'kernel-continue'
        folder = batch.parent / 'inputs'
        scope = folder / (tag + '-roots.json')
        subboxes = folder / (tag + '.json')
        source_frontier = batch.parent / 'frontiers' / tag
    elif tier == 'partner' and not tag.startswith('seven-'):
        kernel = 'kernel-continue'
        folder = batch.parent / 'inputs'
        scope = folder / (tag + '-leaves.json')
        subboxes = folder / (tag + '-subboxes.json')
        source_frontier = batch.parent / 'frontiers' / tag
    elif tag.startswith('packet-'):
        kernel = 'kernel' if first['p30_family'] == 'new_p30' else 'kernel-augmented'
        scope = root / 'scope' / (tag + '.json')
        source_frontier = batch.parent / 'frontiers' / tag
    elif tag.startswith('seven-'):
        kernel = 'kernel-seven'
        scope = root / 'scope-seven' / (tag + '.json')
        source_frontier = batch.parent / 'frontiers' / tag
    else:
        kernel = 'kernel-continue'
        folder = root / batch.parent.name
        scope = folder / (tag + '-roots.json')
        subboxes = folder / (tag + '.json')
        source_frontier = batch.parent / 'frontiers' / tag
    points = root / 'inputs' / ('new30.json' if first['p30_family'] == 'new_p30' else 'augmented.json')
    a.scratch.mkdir()
    if tier == 'partner' and subboxes and not scope.exists():
        tasks = json.loads(subboxes.read_bytes())
        scope = a.scratch / 'roots.json'
        scope.write_text(json.dumps(sorted({r['leaf'] for r in tasks}))+'\n')
    work = a.scratch / 'geometry'
    frontier = a.scratch / 'frontiers'
    regenerated = a.scratch / 'replayed.jsonl'
    target = str(float(Fraction(first['goal'])))
    assert Fraction(target) == Fraction(first['goal'])
    cmd = [sys.executable, '-I', '-B', str(root / kernel / 'replay_angle_mesh.py'),
           *map(str, (a.comp.resolve(), a.tree.resolve(), a.table.resolve(), work, a.cache.resolve())),
           '--target', target, '--cases-from', str(scope), '--modes', str(first['mode']),
           '--depth', str(a.depth or (135 if subboxes else 116)), '--p30-points', str(points),
           '--frontier-out', str(frontier), '--share-angles', '--dense', '--share-dense',
           '--edge-caps', '--fan-integral', '--coupled-support', '--cap-tangent']
    for field in ('budget', 'panels', 'q_trigger_divisor', 'reanchor_level', 'reanchor_stride', 'sweep_limit'):
        cmd += ['--' + field.replace('_', '-'), str(first[field])]
    if first['q_mesh']:
        cmd += ['--q-mesh']
    if subboxes:
        cmd += ['--subboxes', str(subboxes)]
    with regenerated.open('x') as f:
        subprocess.run(cmd, stdout=f, check=True)
    fresh = read_rows(regenerated)
    for old, new in zip(stored, fresh, strict=True):
        assert static_fields(old) == static_fields(new), old['label']
        name = old['label'].replace('/', '-') + f"-mode{old['mode']}-frontier.json"
        original = source_frontier / name
        again = frontier / name
        if original.is_file():
            assert original.read_bytes() == again.read_bytes(), old['label']
        else:
            assert not old['pending'] and json.loads(again.read_bytes()) == [], old['label']
    print(json.dumps({'packet': batch.relative_to(root).as_posix(), 'matched': len(fresh),
                      'visited': sum(r['stats'][1] for r in fresh)}))


if __name__ == '__main__':
    assert __debug__
    main()

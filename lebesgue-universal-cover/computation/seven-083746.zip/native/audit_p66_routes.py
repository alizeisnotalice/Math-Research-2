"""Match every alternate terminal to a proof that has no P input channel."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

from audit_current import lines, old_q_tails, read


def key(task):
    return task['leaf'],tuple(map(tuple,task['bounds'])),tuple(task['steps'])


def shape_free_receipt(row):
    return {**row,'leaf':row['leaf'][:2]}


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('work',type=Path)
    p.add_argument('alternate',nargs=5,type=Path)
    a=p.parse_args()
    before={}
    for folder in a.alternate[:4]:
        for _,items in old_q_tails(folder).values():
            for rect,r in items:
                k=key(rect)
                assert k not in before
                before[k]=shape_free_receipt(r)
    controls=a.work/'p66-controls'
    jobs=read(controls/'packets.json')
    repeated=lines(controls/'receipt.jsonl')
    assert len(before)==len(repeated)==174
    i=0
    for record in jobs:
        rkey=list(map(int,record['leaf'].split('/')))
        for rindex,rectangle in enumerate(record['regions']):
            seen=repeated[i]
            assert seen['leaf']==[*rkey,rindex]
            assert before.pop(key(rectangle))==shape_free_receipt(seen)
            i+=1
    assert not before and i==174
    deep=old_q_tails(a.alternate[4])
    assert len(deep)==1
    count=sum(len(rows) for _,rows in deep.values())
    assert count==24
    print(json.dumps({'standard_bank_rows':2493,'standard_bank_reduced_cloud_points':66,
                      'Q_only_independent_replay_rows':i,'Q_only_deep_rows':count,
                      'alternate_p128_terminals':0,'alternate_mixed_terminals':0,
                      'control_output_sha256':sha256((controls/'receipt.jsonl').read_bytes()).hexdigest()},indent=2))


if __name__=='__main__':
    assert __debug__
    main()

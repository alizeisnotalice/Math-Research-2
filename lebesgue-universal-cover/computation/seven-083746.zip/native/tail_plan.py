"""Use the precise native frontiers of unsuccessful second-pass boxes."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

from freeze_inherited import closure_prefix


def rows(path):
    data=path.read_bytes()
    if path.suffix=='.partial' and not data.endswith(b'\n'):
        data=data[:data.rfind(b'\n')+1]
    return [json.loads(line) for line in data.splitlines()]


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument("root",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--completed",nargs="+",type=Path,required=True)
    p.add_argument("--exclude",nargs="*",type=Path,default=[])
    p.add_argument("--skip-label",nargs="*",default=[])
    p.add_argument("--skip-from",type=Path)
    p.add_argument("--only-label",nargs="*")
    a=p.parse_args()
    checked=set(a.skip_label)
    if a.skip_from:
        checked.update(json.loads(a.skip_from.read_bytes()))
    for path in a.exclude:
        data=json.loads((path/"scope.json").read_bytes())
        checked.update(data["parent_labels"])
    a.output.mkdir()
    boxlist=[]
    parents={}
    for path in a.completed:
        scope=path.parent.name
        selected=json.loads((a.root/scope/(path.stem+".json")).read_bytes())
        actual=rows(path)
        if path.suffix=='.partial':
            assert len(actual)<=len(selected)
            selected=selected[:len(actual)]
        for task,r in zip(selected,actual,strict=True):
            assert task["leaf"]==r["leaf"] and task["label"]==r["label"]
            assert [list(q) for q in zip(r["lo"],r["hi"],strict=True)]==task["bounds"]
            if r["stats"][0] or task["label"] in checked:
                continue
            if a.only_label is not None and task['label'] not in a.only_label:
                continue
            assert task["label"] not in parents
            fp=path.parent/"frontiers"/path.stem/(task["label"].replace("/","-")+"-mode1-frontier.json")
            raw=fp.read_bytes()
            data=json.loads(raw)
            prefix=task["steps"]
            local=[]
            for i,part in enumerate(data):
                full=part["steps"]
                assert full[:len(prefix)]==prefix
                local.append({**part,"steps":full[len(prefix):]})
                boxlist.append({"leaf":task["leaf"],"label":f"{task['label']}-tail-{i:02}",
                                "bounds":part["bounds"],"steps":full,"parent_label":task["label"]})
            closure_prefix(task["bounds"],local,r)
            parents[task["label"]]={"low_parent":r,"prefix":task,
                "descendant_count":len(data),"frontier_sha256":sha256(raw).hexdigest()}
    names=[]
    for i in range(0,len(boxlist),48):
        packet=boxlist[i:i+48]
        stem=f'tail-{i//48:02}'
        boxes=a.output/(stem+'.json')
        roots=a.output/(stem+'-roots.json')
        boxes.write_text(json.dumps(packet,separators=(',',':'))+'\n')
        roots.write_text(json.dumps(sorted({r["leaf"] for r in packet}),separators=(',',':'))+"\n")
        names.append({"boxes":boxes.name,"roots":roots.name,"count":len(packet),
                      "box_sha256":sha256(boxes.read_bytes()).hexdigest(),
                      "root_sha256":sha256(roots.read_bytes()).hexdigest()})
    data={"parent_labels":sorted(parents),"parent_count":len(parents),
          "pending_boxes":len(boxlist),"packets":names}
    (a.output/"scope.json").write_text(json.dumps(data,indent=2)+"\n")
    (a.output/"tail-parents.json").write_text(json.dumps(parents,separators=(',',':'))+"\n")
    print({k:v for k,v in data.items() if k not in ("parent_labels","packets")})


if __name__=="__main__":
    assert __debug__
    main()

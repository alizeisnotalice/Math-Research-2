"""Freeze the complete, independently checkable native terminal ledger."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import shutil
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_zip(target, sources):
    items = sorted(sources, key=lambda pair: pair[1])
    assert len(items) == len({name for _, name in items})
    with ZipFile(target, 'x', ZIP_DEFLATED, compresslevel=9) as package:
        for source, name in items:
            entry = ZipInfo(name)
            entry.compress_type = ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            package.writestr(entry, source.read_bytes(), compresslevel=9)
    assert target.stat().st_size < 10 * 1024**2, target


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('status', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--partner', type=Path, required=True)
    parser.add_argument('--detached-tail', type=Path, action='append', default=[])
    parser.add_argument('--old-q-tail', type=Path, action='append', required=True)
    parser.add_argument('--replay-kit', type=Path, action='append', default=[])
    a = parser.parse_args()
    root = Path(__file__).resolve().parent
    status = json.loads(a.status.read_bytes())
    assert status['complete_stage4'] and status['total_closed'] == 5442
    assert status['inherited_count'] == 4569 and not status['remaining_original_roots']
    out = a.destination
    out.mkdir()
    volumes = out / 'volumes'
    volumes.mkdir()

    def relative(path):
        return path.relative_to(root).as_posix()

    core = ('PROOF.md', 'README.md', 'audit_current.py', 'continue_plan.py', 'freeze_inherited.py',
            'replay_packet.py', 'verify_interfaces.py', 'freeze_portable.py', 'prepare_seven.py',
            'reduce_augmented.py', 'inputs/reduced66.json', 'reduced66-receipt.json',
            'verify_qavg_transfer.py', 'qavg-transfer-receipt.json', 'inputs/q11-expanded-angles.json',
            'audit_p66_routes.py', 'p66-routes-receipt.json',
            'p66-controls/packets.json', 'p66-controls/receipt.jsonl',
            'augment_cloud.py', 'tail_plan.py', 'inherited-high-seven.zip',
            'inherited-high-seven-receipt.json', 'interface-receipt.json',
            'scope/seven-audit.json', 'inputs/augmented.json', 'inputs/new30.json',
            'inputs/verified.json', 'inputs/verify_bank.py', 'inputs/q11-receipt.json',
            'inputs/stage4-retained.json', 'inputs/prior-three.json', 'inputs/supplemental-old-q.jsonl',
            'inputs/supplemental-neighbor-direct.jsonl', 'inputs/supplemental-neighbors.zip')
    compiled = [relative(p) for d in root.glob('kernel*')
                for p in d.iterdir() if p.is_file() and p.suffix in ('.cpp', '.hpp', '.py')]
    for name in (*core, *compiled):
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = (root / name).read_bytes()
        if (root / name).suffix in ('.json', '.jsonl'):
            assert b'/Users/' not in data and b'/Volumes/' not in data, name
        target.write_bytes(data)

    status_file = out / 'terminal-coverage.json'
    status_file.write_text(json.dumps(status, indent=2) + '\n')

    result = root / 'results'
    for prefix, scope in (('packet-', 'scope'), ('seven-', 'scope-seven')):
        paths = []
        for row in sorted(result.glob(prefix + '*.jsonl')):
            paths.extend((row, root / scope / (row.stem + '.json')))
            paths.extend((result / 'frontiers' / row.stem).glob('*.json'))
        if scope == 'scope-seven':
            paths.extend(root / scope / f'seven-{i:02}.json' for i in (8, 9))
        write_zip(volumes / (scope + '.zip'), [(p, relative(p)) for p in paths])

    for scope in sorted([*root.glob('continuation*'), *root.glob('tail*')]):
        if not scope.is_dir() or not (scope / 'scope.json').exists():
            continue
        done = result / scope.name
        inputs = list(scope.glob('*.json'))
        receipts = list(done.glob('*.jsonl'))
        frontier = list((done / 'frontiers').glob('*/*.json'))
        write_zip(volumes / (scope.name + '.zip'), [(p, relative(p)) for p in inputs + receipts + frontier])

    exact_partners = [(a.partner / name.removeprefix('partner/'), name)
                      for name in status['uses'] if name.startswith('partner/')]
    assert all(digest(p)==status['uses'][name] for p,name in exact_partners)
    write_zip(volumes / 'seven-08-09.zip', exact_partners)
    for home in a.detached_tail:
        source = home/'inputs'
        index = source/'scope.json'
        files = [index,source/'tail-parents.json']
        for item in json.loads(index.read_bytes())['packets']:
            stem=Path(item['boxes']).stem
            files.extend((source/item['boxes'],source/item['roots']))
            result0=home/(stem+'.jsonl')
            if result0.exists():
                files.append(result0)
            files.extend((home/'frontiers'/stem).glob('*.json'))
        write_zip(volumes / (home.name + '.zip'),
                  [(p, 'detached/' + home.name + '/' + p.relative_to(home).as_posix()) for p in files])
    filenames = ('assigned-prefix.json', 'assigned-five.json', 'assigned-paired46.jsonl',
                 'assigned-last-one.json', 'assigned-last46.jsonl')
    for i, home in enumerate(a.old_q_tail, 1):
        tag = f'old-q-tail{i}'
        assert all((home/n).is_file() for n in filenames[:3])
        write_zip(volumes / (tag + '.zip'), [(home / n, tag + '/' + n) for n in filenames if (home/n).is_file()])
    if a.replay_kit:
        kits=out/'replay-kits'
        kits.mkdir()
        for p in a.replay_kit:
            assert p.stat().st_size<10*1024**2
            with ZipFile(p) as package:
                assert package.testzip() is None
            destination=kits/p.name
            assert not destination.exists()
            shutil.copyfile(p,destination)
    manifest = [(digest(p), p.relative_to(out).as_posix()) for p in sorted(out.rglob('*')) if p.is_file()]
    (out / 'SHA256SUMS').write_text(''.join(f'{h}  {n}\n' for h, n in manifest))
    print(json.dumps({'files': len(manifest), 'volumes': len(list(volumes.iterdir())),
                      'certified_original_leaves': status['total_closed']}))


if __name__ == '__main__':
    assert __debug__
    main()

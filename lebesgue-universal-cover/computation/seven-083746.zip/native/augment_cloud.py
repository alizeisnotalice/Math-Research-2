"""Propose additional diameter-one material and stronger inherited angle rows."""
from fractions import Fraction as F
from hashlib import sha256
import argparse
from itertools import combinations,product
import json
from pathlib import Path
import sys

from flint import arb,ctx
import numpy as np
from scipy.spatial import ConvexHull


def offer(points,scale):
    active=points[ConvexHull(points).vertices]/scale
    # All candidates are exact-checked after a numerical proposal.
    i,j=np.triu_indices(len(active),1)
    diff=active[j]-active[i]
    dist=np.linalg.norm(diff,axis=1)
    perp=diff[:,[1,0]]*np.array([-1,1])/dist[:,None]
    delta=np.sqrt(1-(dist/2)**2)[:,None]*perp
    center=(active[i]+active[j])/2
    t=np.arange(257)*np.pi/256
    unit=np.stack((np.cos(t),np.sin(t)),axis=1)
    tangent=np.concatenate([center+delta,center-delta,
                            (active[:,None,:]+unit[None,:,:]).reshape(-1,2)],axis=0)
    strip=[]
    for h in (0,.5):
        k=np.sqrt(1-(h-active[:,1])**2)
        for direction in (-1,1):
            strip.append(np.stack((active[:,0]+direction*k,np.full(len(active),h)),axis=1))
    proposed=np.concatenate([tangent,*strip],axis=0)
    proposed=proposed[(proposed[:,1]>=-1e-10)&(proposed[:,1]<=.5+1e-10)]
    close=np.ones(len(proposed),dtype=bool)
    for p in active:
        close&=(np.sum((proposed-p)**2,axis=1)<1+1e-10)
    proposed=proposed[close]
    h=np.max(active@unit.T,axis=0)
    gains=np.max(proposed@unit.T-h,axis=1)
    original={tuple(map(int,p)) for p in points}
    for k in np.argsort(-gains)[:256]:
        if gains[k]<1e-7:
            return None
        x,y=tuple(map(int,np.rint(proposed[k]*(scale-4))))
        if y<0 or 2*y>scale or (x,y) in original:
            continue
        if all((x-X)**2+(y-Y)**2<=scale**2 for X,Y in original):
            return (x,y),float(gains[k])
    return None


def relabel(comp,base,new):
    sys.path.insert(0,str(comp))
    from replay_q11_with_p30 import PointProof
    from certify_nine import ar
    from certify_tomar_six_high import Q,U
    cells=json.loads((comp/'finite-point-global-input.json').read_bytes())['cells']
    original=PointProof({**base,"cells":cells})
    result=[]
    points=np.array(new['points'],dtype=float)/new["denominator"]
    exact=[tuple(ar(F(q,new["denominator"])) for q in p) for p in new["points"]]
    directions=np.array(new['directions'],dtype=float)/U
    pi=arb.pi()
    width=pi/len(cells)
    sinw,cosw=width.sin_cos()
    prior=original.triples.reshape(-1,8)
    directions_exact=[tuple(arb(q) for q in p) for p in new["directions"]]
    count=0
    for j,rows in enumerate(cells):
        angle=(2*j+1)*float(width)
        sin,cos=np.sin(angle),np.cos(angle)
        half=float(width)
        mid=np.array([[cos,-sin],[sin,cos]])
        rot=directions@mid
        p_matrix=rot@points.T
        beta=np.stack((rot[:,1],-rot[:,0]),axis=1)@points.T
        left=np.cos(half)*p_matrix-np.sin(half)*beta
        right=np.cos(half)*p_matrix+np.sin(half)*beta
        choose=np.stack([np.argmax(x,axis=1) for x in
                        (p_matrix,left,right,np.minimum(left,right))],axis=1)
        sn,cs=((2*j+1)*width).sin_cos()
        out=[]
        for source in rows:
            ids,mats=source[:3],source[3:]
            w_q=prior[count,3:6].tolist()
            w=np.array(w_q,dtype=float)/sum(w_q)
            to_try=list(product(*(sorted({x,*choose[i].tolist()}) for i,x in zip(ids,mats,strict=True))))
            def rank(choice):
                val=sum(z*p_matrix[i,m] for z,i,m in zip(w,ids,choice,strict=True))
                derivative=sum(z*beta[i,m] for z,i,m in zip(w,ids,choice,strict=True))
                return val*np.cos(half)-abs(derivative)*np.sin(half)
            to_try=sorted(to_try,key=rank,reverse=True)[:3]
            best=int(prior[count,7])
            choice=mats
            coords=[directions_exact[i] for i in ids]
            rots=[(a*cs+b*sn,-a*sn+b*cs) for a,b in coords]
            for try_ids in to_try:
                if list(try_ids)==mats:
                    continue
                a=b=arb(0)
                for z,(x,y),p in zip(w_q,rots,try_ids,strict=True):
                    u,v=exact[p]
                    a=a+z*(x*u+y*v)
                    b=b+z*(y*u-x*v)
                assert a>0
                value=(a*cosw-abs(b)*sinw)*Q/(sum(w_q)*U)
                score=int(value.lower().floor().unique_fmpz())
                if score>best:
                    best=score
                    choice=list(try_ids)
            out.append(ids+choice)
            count+=1
        result.append(out)
    new["cells"]=result
    pp=PointProof(new)
    after=pp.triples.reshape(-1,8)
    assert np.array_equal(prior[:,:7],after[:,:7])
    gain=after[:,7]-prior[:,7]
    assert (gain>=0).all()
    return {
        "min_gain":int(gain.min()),"max_gain":int(gain.max()),"rows_improved":int((gain>0).sum()),
        "cells_improved":sum(bool((gain[pp.pointers[j]:pp.pointers[j+1]]>0).any())
                             for j in range(len(cells)))
    }


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("comp","base","output","receipt"):
        p.add_argument(name,type=Path)
    p.add_argument("--rounds",type=int,default=49)
    a=p.parse_args()
    assert __debug__
    ctx.prec=160
    raw=a.base.read_bytes()
    base=json.loads(raw)
    shape=list(map(tuple,base["points"]))
    proposals=[]
    for _ in range(a.rounds):
        got=offer(np.array(shape,dtype=np.int64),base["denominator"])
        if got is None:
            break
        (x,y),gap=got
        shape.extend([(x,y),(x,-y)] if y else [(x,y)])
        proposals.append(gap)
    d2=max((u-x)**2+(v-y)**2 for (u,v),(x,y) in combinations(shape,2))
    assert d2<=base["denominator"]**2
    assert base["points"]==list(map(list,shape[:len(base["points"])]))
    assert len(shape)==len(set(shape)) and set(shape)=={(x,-y) for x,y in shape}
    new={**base,"points":list(map(list,shape))}
    checks=relabel(a.comp,base,new)
    a.output.write_text(json.dumps(new,separators=(",",":"))+"\n")
    checks.update(points=len(shape),diameter_squared=str(F(d2,base["denominator"]**2)),
        augmentation_rounds=len(proposals),last_numerical_gap=proposals[-1],
        base_sha256=sha256(raw).hexdigest(),out_sha256=sha256(a.output.read_bytes()).hexdigest())
    a.receipt.write_text(json.dumps(checks,indent=2)+"\n")
    print(json.dumps(checks,indent=2))


if __name__=="__main__":
    main()

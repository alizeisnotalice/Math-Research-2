"""Intersect lower- and higher-target proven-prefix complements exactly."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from math import prod
import json
from pathlib import Path

from freeze_inherited import closure_prefix

T=F(".83746")
HIGH=F(".83750")


def read(path):
    return json.loads(path.read_bytes())


def records(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def volume(box):
    return prod(b-a for a,b in box)


def meet(x,y):
    r=[[max(a,c),min(b,d)] for (a,b),(c,d) in zip(x,y,strict=True)]
    return r if all(a<b for a,b in r) else None


def code(parent,child):
    path=[]
    for axis,((lo,hi),(a,b)) in enumerate(zip(parent,child,strict=True)):
        while (lo,hi)!=(a,b):
            assert lo<=a<b<=hi and (lo+hi)%2==0
            mid=(lo+hi)//2
            assert b<=mid or a>=mid
            right=a>=mid
            path.append(2*axis+int(right))
            if right:
                lo=mid
            else:
                hi=mid
    return path


def prefix(row,frontpath,target):
    assert F(row['goal'])==target and row['threshold_integer']==(target*2**57).__ceil__()
    z=row["stats"]
    assert not z[0] and z[7] in (1,2,3) and not z[5] and row["pending"]
    assert z[1]==2*sum(z[2:5])+row["pending"]-1+row["pending_visited"]
    bounds=[list(t) for t in zip(row["lo"],row["hi"],strict=True)]
    front=read(frontpath)
    closure_prefix(bounds,front,row)
    return bounds,front


def high_choices(root,needed,pins):
    options={}
    for path in sorted((root/"refined").glob("refined-*.jsonl")):
        raw=path.read_bytes()
        rel=str(path.relative_to(root))
        if rel not in pins:
            continue
        assert sha256(raw).hexdigest()==pins[rel]
        for row in (json.loads(x) for x in raw.splitlines()):
            key=row["leaf"]
            if key not in needed or row["stats"][0]:
                continue
            assert row.get("p30_family","original_p30")=="original_p30"
            saved=root/"refined"/"frontiers"/path.stem/(key.replace("/","-")+f"-mode{row['mode']}-frontier.json")
            assert saved.is_file()
            bounds,front=prefix(row,saved,HIGH)
            v=sum(volume(box["bounds"]) for box in front)
            earlier=options.get(key)
            if earlier is None or v<earlier[0]:
                options[key]=(v,bounds,front,row,pins[rel],sha256(saved.read_bytes()).hexdigest())
    return options


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument("work",type=Path)
    p.add_argument("old_high",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--completed-packets",nargs="+",type=Path,required=True)
    p.add_argument("--exclude",nargs="*",type=Path,default=[])
    a=p.parse_args()
    assert __debug__
    work=a.work
    low_root=work/'results'
    stage=read(work/'scope/seven-audit.json')
    needed={f"{i}/{j}" for i,j in stage["selected"]}
    for p in a.exclude:
        need=set(read(p)["roots"])
        assert need<=needed
        needed-=need
    low={}
    for path in a.completed_packets:
        scope=work/("scope-seven" if path.stem.startswith("seven-") else "scope")
        files=read(scope/(path.stem+".json"))
        actual=records(path)
        assert [row["leaf"] for row in actual]==files
        for row in actual:
            key=row["leaf"]
            if key not in needed or row["stats"][0]:
                continue
            assert key not in low
            data=low_root/"frontiers"/path.stem/(key.replace("/","-")+f"-mode{row['mode']}-frontier.json")
            box,fr=prefix(row,data,T)
            low[key]=(box,fr,row,sha256(data.read_bytes()).hexdigest())
    audit=read(work/'inputs/later-all-audit.json')
    high=high_choices(a.old_high,set(low),audit["input_files_sha256"])
    total_reduction=F(0)
    local=[]
    assembled={}
    for key,(box,front,parent,attachment) in sorted(low.items()):
        direct=[x["bounds"] for x in front]
        before=sum(volume(b) for b in direct)
        assert before<=volume(box)
        paths=dict(low_parent=parent,low_frontier=front,low_frontier_sha256=attachment)
        if key in high:
            _,old_box,old_front,old_parent,old_source,old_dir=high[key]
            assert box==old_box
            work_boxes=[r for p in front for q in old_front if (r:=meet(p["bounds"],q["bounds"]))]
            paths.update(high_parent=old_parent,high_frontier=old_front,
                         high_result_sha256=old_source,high_frontier_sha256=old_dir)
        else:
            work_boxes=direct
        past=set()
        for r in work_boxes:
            enc=tuple(tuple(t) for t in r)
            assert enc not in past
            name=f"{key}-join-{len(past):03d}"
            past.add(enc)
            local.append({"leaf":key,"label":name,"bounds":r,"steps":code(box,r)})
        v=sum(volume(b) for b in work_boxes)
        assert v<=before
        assembled[key]={**paths,"old_fraction":str(F(before,volume(box))),
                         "joined_fraction":str(F(v,volume(box))),"new_boxes":len(work_boxes)}
        total_reduction+=F(before-v,volume(box))
    a.output.mkdir()
    (a.output/'frontiers.json').write_text(json.dumps(assembled,separators=(',',':'))+'\n')
    report={"roots":sorted(low),"roots_count":len(low),"combined_with_high":len(high),
            "sum_relative_volume_gain":str(total_reduction),
            "empty_intersections":sorted(k for k,v in assembled.items() if v["new_boxes"]==0),
            "pending_boxes":len(local)}
    # Keep successive subboxes of one source root together when possible.
    exec_inputs=[]
    for idx in range(0,len(local),48):
        tasks=local[idx:idx+48]
        names=sorted({z['leaf'] for z in tasks})
        p=a.output/f'seed-{idx//48:02}.json'
        c=a.output/f'seed-{idx//48:02}-roots.json'
        p.write_text(json.dumps(tasks,separators=(',',':'))+'\n')
        c.write_text(json.dumps(names,separators=(',',':'))+'\n')
        exec_inputs.append({"boxes":p.name,"roots":c.name,"count":len(tasks),
                            "box_sha256":sha256(p.read_bytes()).hexdigest(),
                            "root_sha256":sha256(c.read_bytes()).hexdigest()})
    report["packets"]=exec_inputs
    (a.output/'scope.json').write_text(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k not in ('roots','packets')})


if __name__=="__main__":
    main()

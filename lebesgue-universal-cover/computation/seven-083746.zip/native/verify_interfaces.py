"""Check radial, diameter, and frozen high-screen interfaces at the selected target."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys

from flint import arb,ctx


def load(p):
    return json.loads(p.read_bytes())


def main():
    comp=Path(sys.argv[1])
    root=Path(sys.argv[2])
    ctx.prec=160
    ar=lambda x:arb(x.numerator)/x.denominator
    target=F(".83746")
    Q=2**28
    G=(target*2*Q**2).__ceil__()
    high=F(".83750")
    strict=F(G,2*Q**2)
    assert target<strict<high
    R=F(".707")
    assert R*R<F(1,2)
    r=ar(R)
    radial=(arb.pi()-(1/(2*r)).acos())/4+(r*r-ar(F(1,4))).sqrt()/2
    assert radial>ar(strict)
    P=load(root/'inputs/augmented.json')
    stock=load(root/'inputs/new30.json')
    C=load(root/'inputs/q11-receipt.json')
    assert P['points'][:30]==stock['points']
    diameter2={}
    for name,cloud in (("augmented",P),("q11",C)):
        points=cloud['points']; den=cloud['denominator']
        assert len(set(map(tuple,points)))==len(points)
        assert set(map(tuple,points))=={(x,-y) for x,y in points}
        d=max((x-X)**2+(y-Y)**2 for (x,y),(X,Y) in combinations(points,2))
        assert d<den**2
        diameter2[name]=str(F(d,den**2))
    a=comp/'global-083750'/'records'/'retained.json'
    b=root/'inputs/stage4-retained.json'
    A=load(a);B=load(b)
    assert {int(k):tuple(v) for k,v in A.items()}=={int(k):tuple(v) for k,v in B.items()}
    assert sum(map(len,A.values()))==5442
    print(json.dumps({"target":str(target),"integer_squared_scale":G,
                      "integer_exact_area_lower_if_all_leaves_close":str(strict),
                      "higher_screen":str(high),"radial_cut":str(R),
                      "radial_area_interval":str(radial),"diameters_squared":diameter2,
                      "screen_key_sha256":sha256(a.read_bytes()).hexdigest(),
                      "high_outer_needs_only_five_curves":True},indent=2))


if __name__=="__main__":
    assert __debug__
    main()

"""Remove all augmented points that are unnecessary for its exact angular bank."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys

from flint import ctx
import numpy as np


def read(path):
    return json.loads(path.read_bytes())


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument('comp', type=Path)
    p.add_argument('source', type=Path)
    p.add_argument('destination', type=Path)
    a = p.parse_args()
    sys.path.insert(0, str(a.comp))
    from replay_q11_with_p30 import PointProof
    from certify_tomar_six_high import Q
    ctx.prec = 160

    full = read(a.source)
    stock = read(a.source.with_name('new30.json'))
    cloud = [tuple(p) for p in full['points']]
    indices = {p: i for i, p in enumerate(cloud)}
    assert len(indices) == len(cloud) == 128
    material = {j for cell in full['cells'] for row in cell for j in row[3:]}
    mirrored = {indices[cloud[j][0], -cloud[j][1]] for j in material}
    keep = sorted(material | mirrored)
    remap = {j: k for k, j in enumerate(keep)}
    sparse = {**full, 'points': [cloud[j] for j in keep],
              'cells': [[row[:3] + [remap[j] for j in row[3:]] for row in cell] for cell in full['cells']]}
    points = sparse['points']
    assert len(points) == 66 and set(points) == {(x, -y) for x, y in points}
    diameter2 = max((x-a0)**2+(y-b0)**2 for (x,y),(a0,b0) in combinations(points,2))
    assert diameter2 < full['denominator']**2

    original = PointProof(full)
    reduced = PointProof(sparse)
    for label in ('directions', 'disk', 'pointers', 'triples'):
        assert np.array_equal(getattr(original, label), getattr(reduced, label))
    rows = read(a.comp / 'finite-point-global-input.json')['cells']
    earlier = PointProof({**stock, 'cells': rows})
    q0 = earlier.triples.reshape(-1, 8)
    q1 = reduced.triples.reshape(-1, 8)
    assert np.array_equal(q0[:, :7], q1[:, :7])
    assert np.array_equal(earlier.pointers, reduced.pointers)
    assert np.array_equal(earlier.directions, reduced.directions)
    assert np.array_equal(earlier.disk, reduced.disk)
    gain = q1[:, 7] - q0[:, 7]
    assert len(gain) == 2493 and int(gain.min()) >= 0
    a.destination.write_text(json.dumps(sparse, separators=(',', ':')) + '\n')
    profile = {
        'points': len(points), 'superset_count': len(cloud), 'distinct_material_labels': len(material),
        'original_indices': keep, 'denominator': full['denominator'],
        'diameter_squared': str(Fraction(diameter2, full['denominator']**2)),
        'rows': len(gain), 'cells': len(reduced.pointers)-1,
        'reduction_rows_identical': True, 'minimum_gain_over_new30': int(gain.min()),
        'minimum_exact_gain_over_new30': str(Fraction(int(gain.min()),Q)),
        'table_sha256': sha256(q1.astype('<i8').tobytes()).hexdigest(),
        'full_source_sha256': sha256(a.source.read_bytes()).hexdigest(),
        'reduced_source_sha256': sha256(a.destination.read_bytes()).hexdigest(),
    }
    print(json.dumps(profile, indent=2))


if __name__ == '__main__':
    assert __debug__
    main()

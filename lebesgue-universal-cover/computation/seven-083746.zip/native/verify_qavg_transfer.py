"""Check the exact symmetric Q input and the direction of each projection deduction."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import sys

from flint import ctx
import numpy as np


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def d2(points,denominator):
    return F(max((x-a)**2+(y-b)**2 for (x,y),(a,b) in combinations(points,2)),denominator**2)


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('work',type=Path)
    p.add_argument('expanded',type=Path)
    p.add_argument('--ordinary-bank',type=Path)
    p.add_argument('--ordinary-verifier',type=Path)
    p.add_argument('--physical-bank',type=Path)
    a=p.parse_args()
    assert bool(a.ordinary_bank)==bool(a.ordinary_verifier)
    assert not a.physical_bank or a.ordinary_bank
    sys.path.insert(0,str(a.comp.resolve()))
    from build_q11_leaf_bank import EPS,reflected_average
    from certify_tomar_six_high import Q,U
    from replay_q11_with_p30 import PointProof
    ctx.prec=192

    raw_source=a.comp/'multi-host-points.json'
    raw=read(raw_source)
    q,den=reflected_average(raw)
    pinned=read(a.work/'inputs/q11-receipt.json')
    assert q==pinned['points'] and den==pinned['denominator']
    assert digest(raw_source)==pinned['input_points_sha256']
    assert set(map(tuple,q))=={(x,-y) for x,y in q}
    assert d2(q,den)<1 and d2(raw['points'],raw['point_denominator'])<1
    assert den==2*raw['point_denominator']
    shifts=[F((x-2*u)**2+(y-2*v)**2,den**2)
            for (x,y),(u,v) in zip(q,raw['points'],strict=True)]
    assert 0<max(shifts)<EPS**2
    assert set(map(tuple,q))!={(2*x,2*y) for x,y in raw['points']}

    ticks=(Q*F(U+2,U)*EPS).__ceil__()
    assert ticks==1
    banks={}
    for name,path,length in (('standard',a.comp/'q11-leaf-bank.json',2258),('expanded',a.expanded,3794)):
        datum={**read(path),'points':q,'denominator':den,'direction_scale':U}
        strong=PointProof(datum,F(0))
        used=PointProof(datum,EPS)
        u=used.triples.reshape(-1,8)
        v=strong.triples.reshape(-1,8)
        assert len(u)==length and len(used.pointers)==385
        for field in ('directions','disk','pointers'):
            assert np.array_equal(getattr(used,field),getattr(strong,field))
        assert np.array_equal(u[:,:7],v[:,:7]) and np.all(v[:,7]-u[:,7]==ticks)
        banks[name]={'input_sha256':digest(path),'rows':length,'native_deduction_ticks':ticks,
                     'used_native_sha256':sha256(u.astype('<i8').tobytes()).hexdigest(),
                     'qavg_without_deduction_sha256':sha256(v.astype('<i8').tobytes()).hexdigest()}
    assert banks['standard']['input_sha256']==pinned['angle_bank_sha256']
    if a.ordinary_bank:
        sys.path.insert(0,str(a.ordinary_verifier.resolve()))
        from verify_ordinary import run
        p_count,q_count=run(a.work,a.comp,a.ordinary_bank)
        banks['ordinary']={'table_sha256':digest(a.ordinary_bank),'rows':q_count,
                           'all_rows_checked':[p_count,q_count],'native_deduction_ticks':0}
    if a.physical_bank:
        symmetric=read(a.ordinary_bank)
        physical=read(a.physical_bank)
        assert symmetric['directions']==physical['directions'] and symmetric['knots']==physical['knots']==384
        assert symmetric['cells'][:384]==physical['cells'][:384]
        gaps=[]
        for x,y in zip(symmetric['cells'][384:],physical['cells'][384:],strict=True):
            for u,v in zip(x,y,strict=True):
                assert u[:7]==v[:7]
                gaps.append(u[7]-v[7])
        assert len(gaps)==q_count and set(gaps)=={0,1} and gaps.count(1)==99
        banks['ordinary_physical']={'table_sha256':digest(a.physical_bank),'qavg_supported_rows':len(gaps),
                                    'decreased_q_rows':gaps.count(1),'maximum_decrease_ticks':max(gaps)}
    print(json.dumps({'physical_input':'Qavg','points':len(q),'diameter_squared':str(d2(q,den)),
                      'qraw_distinct':True,'qraw_max_paired_squared_displacement':str(max(shifts)),
                      'projection_error':str(EPS),'banks':banks},indent=2))


if __name__=='__main__':
    assert __debug__
    main()

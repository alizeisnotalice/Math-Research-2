"""Reconstruct inherited original-size whole roots and their exact closed subsets."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

HIGH=F(".83750")
G_HIGH=(HIGH*2**57).__ceil__()


def read(p):
    return json.loads(p.read_bytes())


@lru_cache(maxsize=None)
def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def raw_key(pair):
    return f"{pair[0]}/{pair[1]}"


def assert_area_row(row, kind, threshold=HIGH, allow_q=False):
    assert F(row["goal"])==threshold and row["threshold_integer"]==(threshold*2**57).__ceil__()
    family=row.get("p30_family","original_p30")
    if family!="original_p30":
        assert family=="new_p30" and row["p30_sha256"]=="1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58"
        assert not (row["stats"][3] or row["stats"][4])
    assert not row["guards"] and not row["center_stops"]
    stat=row["stats"]
    assert len(stat)==35 and not stat[5] and (allow_q or not stat[4])
    assert all(type(v) is int for v in stat)
    assert 0<stat[1]<=row["budget"]
    assert all(0<=row.get(key,0)<=stat[3] for key in
               ("p_edge_stops","p_coupled_stops","p_tangent_stops"))
    if kind=="complete":
        assert stat[0]==1 and row["pending"]==0 and stat[7]==0
        assert stat[1]==2*(sum(stat[2:5]))-1
    else:
        assert stat[0]==0 and row["pending"]>0
        assert stat[1]==2*(sum(stat[2:5]))+row["pending"]-1+row["pending_visited"]


def closure_prefix(box,frontier,row):
    """Check original addresses and count the pending/visited partition."""
    assert len(frontier)==row["pending"]
    axes={}
    seen=set()
    for child in frontier:
        code=tuple(child["steps"])
        assert code not in seen
        seen.add(code)
        result=[list(v) for v in box]
        for depth,step in enumerate(code):
            assert type(step) is int and 0<=step<22
            k,side=divmod(step,2)
            parent=code[:depth]
            assert axes.setdefault(parent,k)==k
            l,h=result[k]
            assert l<h and (l+h)%2==0
            result[k][1-side]=(l+h)//2
        assert result==child["bounds"]
    assert not (seen & axes.keys())
    assert len({x["label"] for x in frontier})==len(frontier)


@lru_cache(maxsize=64)
def rows(p):
    return [json.loads(line) for line in p.read_bytes().splitlines()]


def locate(root, audit, rec):
    label=rec["source_file"]
    choices=[]
    for entry,checksum in audit["input_files_sha256"].items():
        source=Path(entry)
        if source.name==label:
            p=(root/source).resolve()
            assert p.is_file() and digest(p)==checksum
            choices.append((p,checksum))
    assert choices and len(set(choices))==1,(label,choices)
    return choices[0]


def main():
    p=ArgumentParser(description=__doc__)
    for name in ("comp","tree","first","later","work","output"):
        p.add_argument(name,type=Path)
    p.add_argument("--include-q11",action="store_true")
    args=p.parse_args()
    assert __debug__
    sys.path.insert(0,str(args.comp))
    from certify_tomar_six_high import SourceTree,FINE
    tree=SourceTree(args.tree)
    scope=read(args.work/("scope/seven-audit.json" if args.include_q11 else "scope/audit.json"))
    inherited=scope["inherited_rows"]
    assert len(inherited)==(4569 if args.include_q11 else 3633)
    root_proofs=read(args.work/"inputs/prior-three.json")["leaves"]
    earliest=read(args.first/"audit-all-stage4-retained.json")
    latest=read(args.work/("inputs/later-all-audit.json" if args.include_q11 else "inputs/later-audit.json"))
    assert earliest["goal"]==latest["goal"]=="67/80"
    source=(earliest,latest)
    lookup=[{row["leaf"]:row for row in a["proof_records"]} for a in source]
    extroot="extensions/final-old-plus-five.json" if args.include_q11 else "extensions/confirmed-old-inputs.json"
    p=args.later/extroot
    assert digest(p)==latest["input_files_sha256"][extroot]
    extensions={row["leaf"]:row for row in read(p)}
    package=[]
    categories=Counter()
    seen=set()
    for rid in inherited:
        chunk,leaf,stage,kind,*meta=rid
        name=raw_key((chunk,leaf))
        assert name not in seen
        seen.add(name)
        original=tree.leaf(chunk,leaf)
        assert all((v*FINE).denominator==1 for bounds in original for v in bounds)
        root=[[int(v*FINE) for v in bounds] for bounds in original]
        k={"five":5,"P30":6,"Q11":7}[kind]
        assert args.include_q11 or k in (5,6)
        if name in root_proofs:
            r=root_proofs[name]
            assert r["complete"] and r["inputs"]==k and stage=="first"
            assert r["nodes"]==2*(r["five_terminals"]+r.get("P30_terminals",0))-1
            package.append({"leaf":name,"bounds":root,"type":"published-r229","proof":r})
            categories["published-r229"]+=1
            continue
        i=int(stage=="later")
        audit=source[i]
        proof=lookup[i][name]
        assert proof["inputs"]==k and (k==7)==(proof["Q11_terminals"]>0)
        if meta:
            assert meta==[proof["source_file"],proof["source_line"]]
        path,pin=locate((args.first,args.later)[i],audit,proof)
        row=rows(path)[proof["source_line"]-1]
        assert row["leaf"]==row["label"]==name
        assert root==[list(pair) for pair in zip(row["lo"],row["hi"],strict=True)]
        out={"leaf":name,"bounds":root,"type":"whole-high","parent":row,
             "parent_source":{"basename":path.name,"line":proof["source_line"],"file_sha256":pin}}
        counts=row["stats"][2:5]
        nodes=row["stats"][1]
        if "extended_frontier" in proof:
            assert i==1
            ext=extensions[name]
            assert ext["parent_line"]==proof["source_line"]
            assert_area_row(row,"prefix",allow_q=args.include_q11)
            files={}
            for typ in ("parent","frontier","child"):
                f=(p.parent/ext[typ]).resolve()
                assert f.is_relative_to(args.later.resolve()) and digest(f)==ext["sha256"][typ]
                files[typ]=f
            assert files["parent"]==path
            front=read(files["frontier"])
            closure_prefix(root,front,row)
            children=rows(files["child"])
            for task,child in zip(front,children,strict=True):
                assert_area_row(child,"complete",allow_q=args.include_q11)
                assert child["leaf"]==name and child["label"]==task["label"]
                assert [list(q) for q in zip(child["lo"],child["hi"],strict=True)]==task["bounds"]
                counts=[a+b for a,b in zip(counts,child["stats"][2:5],strict=True)]
            nodes+=sum(z["stats"][1] for z in children)-row["pending_visited"]
            assert nodes==2*sum(counts)-1
            out.update(type="extended-high",frontier=front,children=children,
                       extension_manifest_sha256=ext["sha256"])
        else:
            assert_area_row(row,"complete",allow_q=args.include_q11)
        assert nodes==proof["nodes"] and counts==[proof["five_terminals"],proof["P30_terminals"],proof["Q11_terminals"]]
        assert k==(7 if counts[2] else 6 if counts[1] else 5)
        categories[out["type"]]+=1
        package.append(out)
    assert len({r["leaf"] for r in package})==len(package)==len(inherited)
    with ZipFile(args.output,"w",compression=ZIP_DEFLATED,compresslevel=9) as packed:
        for k in sorted(categories):
            data=[row for row in package if row["type"]==k]
            packed.writestr(k+".jsonl","".join(json.dumps(r,separators=(",",":"))+"\n" for r in data))
    print(json.dumps({"covered":len(package),"category":dict(categories),
                      "archive_sha256":digest(args.output)},indent=2))


if __name__=="__main__":
    main()

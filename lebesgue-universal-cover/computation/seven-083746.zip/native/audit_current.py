"""Audit the current exact stage-four cover, including resolved frontier subtrees."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

from continue_plan import HIGH,T,code,meet
from freeze_inherited import assert_area_row, closure_prefix

NEW_SHA="1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58"
AUG_SHA="13d9a52243efadcb2281aa60e41282349e3c4c64bc9925f9ad20ece8dab2ecb1"


def read(p):
    return json.loads(p.read_bytes())


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def lines(path,live=False):
    whole=path.read_bytes()
    if live and not whole.endswith(b"\n"):
        whole=whole[:whole.rfind(b"\n")+1]
    return [json.loads(z) for z in whole.splitlines()]


def receipt(path,live_result=False):
    """Read one immutable result or a coherent snapshot of its append-only prefix."""
    pending=path.with_suffix('.partial')
    for candidate in (path,pending,path):
        try:
            blob=candidate.read_bytes()
        except FileNotFoundError:
            continue
        if (candidate==pending or live_result) and not blob.endswith(b'\n'):
            blob=blob[:blob.rfind(b'\n')+1]
        return [json.loads(z) for z in blob.splitlines()],candidate,sha256(blob).hexdigest()
    return [],None,None


def endpoints(row):
    return [list(z) for z in zip(row['lo'],row['hi'],strict=True)]


def actual_row(row):
    assert F(row["goal"])==T and row["threshold_integer"]==(T*2**57).__ceil__()
    fam=row["p30_family"]
    assert fam in ("new_p30","augmented_p30")
    assert row["p30_sha256"]==(NEW_SHA if fam=="new_p30" else AUG_SHA)
    assert row["mode"] in (0,1) and row["stats"][5]==0
    assert row["mode"] or row["stats"][4]==0
    assert not row["mode"] or row["q_mesh"]
    assert not row["guards"] and not row["center_stops"]
    z=row["stats"]
    assert len(z)==35 and z[0] in (0,1) and 0<z[1]<=row["budget"]
    assert z[1]==2*sum(z[2:5])+row["pending"]-1+row["pending_visited"]
    if z[0]:
        assert row["pending"]==row["pending_visited"]==z[7]==0
    else:
        assert row["pending"]>0 and z[7] in (1,2,3)


def subtree_front(root,task,row,path):
    assert endpoints(row)==task["bounds"]
    try:
        choices=read(path)
    except (FileNotFoundError,json.JSONDecodeError):
        return None
    prefix_steps=task["steps"]
    assert len(choices)==row["pending"]
    local=[]
    for q in choices:
        st=q["steps"]
        assert st[:len(prefix_steps)]==prefix_steps
        local.append({**q,"steps":st[len(prefix_steps):]})
        assert code(root,q["bounds"])
    closure_prefix(task["bounds"],local,row)
    return choices


def old_q_tails(home):
    """Read exact independently closed old-Q descendant tasks."""
    meta=read(home/'assigned-prefix.json')
    bank={r['leaf']:r['regions'] for r in read(home/'assigned-five.json')}
    receipts=lines(home/'assigned-paired46.jsonl')
    data={tuple(r['leaf']):r for r in receipts}
    assert len(data)==len(receipts)
    last_path=home/'assigned-last-one.json'
    if last_path.exists():
        replacement,=read(last_path)
        last,=replacement['regions']
        result,=lines(home/'assigned-last46.jsonl')
        root=tuple(map(int,replacement['leaf'].split('/')))
        assert tuple(result['leaf'])==(*root,0)
        index=bank[last['leaf']].index(last)
        assert not data[(*root,index)]['out'][0]
        data[(*root,index)]=result
    grouped={}
    for label,pin in meta.items():
        key=pin['leaf']
        root=tuple(map(int,key.split('/')))
        group=[]
        for i in range(pin['begin'],pin['begin']+pin['count']):
            task=bank[key][i]
            row=data.pop((*root,i))
            s,n,five,q11,depth=row['out']
            assert s==1 and depth>=0 and n==2*(five+q11)-1
            assert row['P128']==row['paired']==0 and row['oldQ']==q11
            assert row['front'] is None and F(row['target'])==T
            assert task['leaf']==key and task['label']==f"{label}-{i-pin['begin']}"
            group.append((task,row))
        grouped[label]=(pin,group)
    assert not data
    return grouped


def supplemental_neighbors(archive,source):
    accepted=[]
    with ZipFile(archive) as packed:
        index=json.loads(packed.read('neighbor-merged.json'))
        assert index['physical_cloud_sha256']=='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
        assert index['bank_sha256']=='c956e535ab0ed2bdc0a289c388ce88cf7a26132a356b6adb2076b36d508ef93a'
        for k,cert in index['continued'].items():
            assert cert['closed'] and not cert['unresolved']
            raw={name:packed.read(name) for name in cert['inputs']}
            assert {name:sha256(v).hexdigest() for name,v in raw.items()}==cert['inputs']
            def get(prefix,suffix):
                payload,=[z for n,z in raw.items() if n.startswith(prefix) and n.endswith(suffix)]
                return payload
            row,=[z for line in get('old-neighbor-receipts/','.jsonl').splitlines()
                  if (z:=json.loads(line))['leaf']==k]
            assert_area_row(row,'prefix',allow_q=True)
            assert row['label']==k and endpoints(row)==source(k)
            assert row['mode']==1 and row['q_mesh'] and row['stats'][3]==0
            pending=json.loads(get('old-neighbor-receipts/','-frontier.json'))
            closure_prefix(source(k),pending,row)
            short=[json.loads(z) for z in get('neighbor-continued/','.jsonl').splitlines()]
            long=[json.loads(z) for n,b in raw.items() if n.startswith('neighbor-final/') for z in b.splitlines()]
            repl={z['label']:z for z in long}
            assert set(repl)=={z['label'] for z in short if not z['stats'][0]}
            nodes=row['stats'][1]-row['pending_visited']
            five,p30,q11,mixed=row['stats'][2:6]
            for task,r0 in zip(pending,short,strict=True):
                assert r0['label']==task['label'] and endpoints(r0)==task['bounds']
                r=repl.get(r0['label'],r0)
                assert_area_row(r,'complete',allow_q=True)
                assert r['label']==task['label'] and endpoints(r)==task['bounds'] and r['leaf']==k
                assert r['mode']==1 and r['q_mesh'] and r['stats'][3]==0
                nodes+=r['stats'][1]
                five+=r['stats'][2]
                q11+=r['stats'][4]
            assert [nodes,five,p30,q11,mixed]==cert['counts_nodes_five_P30_Q11_mixed']
            assert nodes==2*(five+q11)-1
            accepted.append(k)
    return accepted


def main():
    p=ArgumentParser(description=__doc__)
    for name in ("comp","tree","work","output"):
        p.add_argument(name,type=Path)
    p.add_argument("--partner",type=Path)
    p.add_argument("--detached-tail",type=Path,action='append',default=[])
    p.add_argument("--old-q-tail",type=Path,action='append',default=[])
    a=p.parse_args()
    for home in a.detached_tail:
        assert (home/'inputs/scope.json').is_file(), home
    for home in a.old_q_tail:
        assert (home/'assigned-prefix.json').is_file(), home
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import FINE,SourceTree
    reader=SourceTree(a.tree)
    work=a.work
    current=read(work/"scope/seven-audit.json")
    need={f"{i}/{j}" for i,j in current["selected"]}
    yes={f"{v[0]}/{v[1]}":v[3] for v in current["inherited_rows"]}
    stage={f"{p}/{j}" for p,row in read(work/"inputs/stage4-retained.json").items() for j in row}
    assert not need & yes.keys()
    assert len(need)==873 and len(yes)==4569 and need|yes.keys()==stage
    frozen=read(work/"inherited-high-seven-receipt.json")
    high_archive=work/"inherited-high-seven.zip"
    assert digest(high_archive)==frozen["archive_sha256"]
    originals={}
    def source(key):
        if key not in originals:
            box=reader.leaf(*map(int,key.split("/")))
            assert all((F(v)*FINE).denominator==1 for q in box for v in q)
            originals[key]=[[int(v*FINE) for v in q] for q in box]
        return originals[key]

    high_expected=Counter(frozen['category'])
    high_seen=set()
    high_categories=Counter()
    high_geometries=Counter()
    with ZipFile(high_archive) as packed:
        for n in packed.namelist():
            for line in packed.read(n).splitlines():
                cert=json.loads(line)
                k=cert['leaf']
                typ=cert['type']
                assert k in yes and k not in high_seen and n==typ+'.jsonl'
                assert cert['bounds']==source(k)
                high_categories[typ]+=1
                high_seen.add(k)
                if typ=='published-r229':
                    row=cert['proof']
                    assert row['complete'] and row['nodes']==2*(row['five_terminals']+row.get('P30_terminals',0))-1
                    family='P30' if row.get('P30_terminals',0) else 'five'
                else:
                    row=cert['parent']
                    assert row['leaf']==row['label']==k and endpoints(row)==source(k)
                    if typ=='extended-high':
                        assert_area_row(row,'prefix',allow_q=True)
                        front=cert['frontier']
                        closure_prefix(source(k),front,row)
                        children=cert['children']
                        for task,child in zip(front,children,strict=True):
                            assert_area_row(child,'complete',allow_q=True)
                            assert child['leaf']==k and child['label']==task['label'] and endpoints(child)==task['bounds']
                    else:
                        assert typ=='whole-high'
                        assert_area_row(row,'complete',allow_q=True)
                        children=[]
                    five,p30,q11=(sum(z['stats'][i] for z in [row,*children]) for i in range(2,5))
                    family='Q11' if q11 else 'P30' if p30 else 'five'
                assert family==yes[k]
                high_geometries[family]+=1
    assert high_seen==yes.keys() and high_categories==high_expected
    assert high_geometries==Counter(current['by_geometry'])

    visited={}
    used={}
    direct={}
    totals=Counter()
    paths={path.with_suffix('.jsonl') for prefix0 in ('packet-','seven-')
           for path in (work/'results').glob(prefix0+'*') if path.suffix in ('.jsonl','.partial')}
    for path in sorted(paths):
        pack=work/('scope-seven' if path.stem.startswith('seven-') else 'scope')/(path.stem+".json")
        names=read(pack)
        raw,file,checksum=receipt(path)
        assert [r['leaf'] for r in raw]==names[:len(raw)]
        if file==path:
            assert len(raw)==len(names)
        if file:
            used[file.relative_to(work).as_posix()]=checksum
        totals['native_whole_rows']+=len(raw)
        totals['native_whole_nodes']+=sum(r['stats'][1] for r in raw)
        for row in raw:
            key=row['leaf']
            if key not in need:
                continue
            assert key not in visited and row['label']==key
            actual_row(row)
            assert source(key)==endpoints(row)
            visited[key]=row
            if row['stats'][0]:
                direct[key]='seven' if row['stats'][4] else 'six' if row['stats'][3] else 'five'

    joined={}
    totals['native_whole_relevant_rows']=len(visited)
    totals['native_whole_relevant_nodes']=sum(r['stats'][1] for r in visited.values())
    remaining={}
    tails={}
    tailspec=[(path,work/'results'/path.name,'results/'+path.name) for path in sorted(work.glob('tail*'))
              if path.is_dir() and (path/'scope.json').exists()]
    tailspec.extend((home/'inputs',home,'detached/'+home.name) for home in a.detached_tail)
    for scope,output,record_name in tailspec:
        live_result=record_name.startswith('detached/')
        defs=read(scope/"scope.json")
        parents=read(scope/"tail-parents.json")
        assert set(defs['parent_labels'])==parents.keys() and not tails.keys()&parents.keys()
        children={k:[] for k in parents}
        for item in defs['packets']:
            path=scope/item['boxes']
            assert digest(path)==item['box_sha256']
            result=output/(path.stem+'.jsonl')
            tasks=read(path)
            assert len(tasks)==item['count']
            tried,file,checksum=receipt(result,live_result)
            if file==result and not live_result:
                assert len(tried)==len(tasks)
            if file:
                used[record_name+'/'+file.name]=checksum
            assert len(tried)<=len(tasks)
            for j,t in enumerate(tasks):
                r=tried[j] if j<len(tried) else None
                if r:
                    actual_row(r)
                    assert r['leaf']==t['leaf'] and r['label']==t['label']
                    assert endpoints(r)==t['bounds']
                native=result.parent/'frontiers'/path.stem/(t['label'].replace('/','-')+'-mode1-frontier.json')
                children[t['parent_label']].append((t,r,native))
        tails.update({k:(parent,children[k]) for k,parent in parents.items()})

    used_tails=set()
    old_q={}
    for home in a.old_q_tail:
        group=old_q_tails(home)
        assert not old_q.keys()&group.keys()
        old_q.update(group)
    used_old_q=set()
    def resolve(task,row,native):
        if row is None:
            return None
        if row['stats'][0]:
            return True
        choices=subtree_front(source(task['leaf']),task,row,native)
        if choices is not None and task['label'] in old_q:
            pin,children=old_q[task['label']]
            assert pin['leaf']==task['leaf'] and len(children)==len(choices)
            assert digest(native)==pin['frontier_sha256']
            parent=work/pin['parent_file']
            assert digest(parent)==pin['native_parent_sha256']
            assert lines(parent)[pin['parent_line']-1]==row
            assert row['stats'][:len(pin['stats'])]==pin['stats']
            box_source=work/pin['assigned_box_source']
            assert digest(box_source)==pin['assigned_box_source_sha256'] and task in read(box_source)
            for t,(child,receipt0) in zip(choices,children,strict=True):
                assert t['bounds']==child['bounds'] and t['steps']==child['steps']
                totals['external_old_q_boxes']+=1
                totals['external_old_q_nodes']+=receipt0['out'][1]
            used_old_q.add(task['label'])
            return True
        if choices is None or task['label'] not in tails:
            return choices
        assert task['label'] not in used_tails
        used_tails.add(task['label'])
        parent,children=tails[task['label']]
        assert parent['low_parent']==row and parent['prefix']==task
        assert parent['descendant_count']==len(children)==len(choices)
        assert digest(native)==parent['frontier_sha256']
        pending=[]
        by_bounds={tuple(map(tuple,child['bounds'])):(child,r,path) for child,r,path in children}
        assert len(by_bounds)==len(choices)
        assert len({child['label'] for child,_,_ in children})==len(choices)
        for part in choices:
            child,r,path=by_bounds[tuple(map(tuple,part['bounds']))]
            assert child['leaf']==task['leaf'] and child['parent_label']==task['label']
            assert child['bounds']==part['bounds'] and child['steps']==part['steps']
            st=resolve(child,r,path)
            if r:
                totals['tail_attempted']+=1
                totals['tail_nodes']+=r['stats'][1]
                if r['stats'][0]:
                    totals['tail_closed']+=1
            if st is None:
                pending.append(child)
            elif st is not True:
                pending.extend(st)
        return pending or True

    for scope in sorted(work.glob("continuation*")):
        if not scope.is_dir() or not (scope/"scope.json").exists():
            continue
        defs=read(scope/"scope.json")
        table=read(scope/"frontiers.json")
        assert set(table)==set(defs["roots"])
        assert not set(table)&(direct.keys()|joined.keys())
        tests={}
        for item in defs["packets"]:
            path=scope/item["boxes"]
            assert digest(path)==item["box_sha256"]
            tasks=read(path)
            result=work/"results"/scope.name/(path.stem+".jsonl")
            tried,file,checksum=receipt(result)
            if file==result:
                assert len(tried)==len(tasks)
            if file:
                used[file.relative_to(work).as_posix()]=checksum
            assert len(tried)<=len(tasks)
            for j,t in enumerate(tasks):
                key=t['leaf']
                assert key in table and code(source(key),t['bounds'])==t['steps']
                rec=tests.setdefault(key,{})
                bound=tuple(map(tuple,t['bounds']))
                assert bound not in rec
                row=tried[j] if j<len(tried) else None
                if not row:
                    rec[bound]=None
                    continue
                actual_row(row)
                assert row['leaf']==key and row['label']==t['label']
                assert endpoints(row)==t['bounds']
                totals['desc_attempted']+=1
                totals['desc_nodes']+=row['stats'][1]
                if row['stats'][0]:
                    rec[bound]=True
                    totals['desc_closed']+=1
                else:
                    dest=work/"results"/scope.name/"frontiers"/path.stem/(row['label'].replace('/','-')+'-mode1-frontier.json')
                    rec[bound]=resolve(t,row,dest)
        for key,g in table.items():
            low=g["low_parent"]
            old=g["low_frontier"]
            assert key in visited and low==visited[key]
            closure_prefix(source(key),old,low)
            if "high_parent" in g:
                oldhigh=g["high_parent"];hi=g["high_frontier"]
                assert endpoints(oldhigh)==source(key) and F(oldhigh["goal"])==HIGH and not oldhigh["stats"][0]
                assert oldhigh['leaf']==oldhigh['label']==key
                assert_area_row(oldhigh,'prefix',allow_q=True)
                closure_prefix(source(key),hi,oldhigh)
                unknown=[r for a0 in old for b0 in hi if (r:=meet(a0["bounds"],b0["bounds"]))]
            else:
                unknown=[z['bounds'] for z in old]
            result=tests.get(key,{})
            assert {tuple(map(tuple,r)) for r in unknown}==result.keys()
            pending=[]
            for b0 in unknown:
                x=result[tuple(map(tuple,b0))]
                if x is None:
                    pending.append(b0)
                elif x is not True:
                    pending.extend([z['bounds'] for z in x])
            if pending:
                remaining[key]=pending
            else:
                joined[key]=scope.name
    assert used_tails==tails.keys()
    assert used_old_q==old_q.keys()

    partner={}
    partner_started=set()
    if a.partner:
        for number in ('08','09'):
            n=f'seven-{number}'
            root_receipt=a.partner/(n+'.jsonl')
            if not root_receipt.exists():
                continue
            parent=lines(root_receipt,live=True)
            tasks=read(work/'scope-seven'/(n+'.json'))
            assert [r['leaf'] for r in parent]==tasks[:len(parent)]
            used['partner/'+root_receipt.name]=digest(root_receipt)
            totals['external_whole_rows']+=len(parent)
            totals['external_whole_nodes']+=sum(r['stats'][1] for r in parent)
            consumed={}
            for jobs in sorted((a.partner/'inputs').glob(f'*{number}*-subboxes.json')):
                rescue=jobs.name.removesuffix('-subboxes.json')
                result=a.partner/(rescue+'.jsonl')
                if not result.exists():
                    continue
                child=lines(result,live=True)
                req=read(jobs)
                assert len(child)<=len(req)
                used['partner/'+result.name]=digest(result)
                used['partner/inputs/'+jobs.name]=digest(jobs)
                for task,row in zip(req[:len(child)],child,strict=True):
                    actual_row(row)
                    assert row['leaf']==task['leaf'] and row['label']==task['label']
                    assert endpoints(row)==task['bounds']
                    assert row['label'] not in consumed
                    consumed[row['label']]=(task,row,rescue)
                totals['external_desc_attempted']+=len(child)
                totals['external_desc_nodes']+=sum(x['stats'][1] for x in child)

            accessed=set()
            def visit_partner(task,row,folder):
                if row['stats'][0]:
                    return []
                k=task['leaf']
                name=row['label'].replace('/','-')+'-mode1-frontier.json'
                native=a.partner/'frontiers'/folder/name
                if not native.exists():
                    return [task['bounds']]
                front=subtree_front(source(k),task,row,native)
                if front is None:
                    return [task['bounds']]
                used['partner/'+native.relative_to(a.partner).as_posix()]=digest(native)
                unresolved=[]
                for x in front:
                    if x['label'] not in consumed:
                        unresolved.append(x['bounds'])
                        continue
                    child,result,rescue=consumed[x['label']]
                    assert x['label'] not in accessed
                    accessed.add(x['label'])
                    assert child['leaf']==k and child['bounds']==x['bounds'] and child['steps']==x['steps']
                    unresolved.extend(visit_partner(child,result,rescue))
                return unresolved

            for r in parent:
                k=r['leaf']
                actual_row(r)
                assert r['label']==k
                assert endpoints(r)==source(k) and k not in visited and k not in partner_started
                partner_started.add(k)
                task={'leaf':k,'label':k,'bounds':source(k),'steps':[]}
                unresolved=visit_partner(task,r,n)
                if unresolved:
                    remaining[k]=unresolved
                else:
                    partner[k]=n
            assert accessed==consumed.keys()

    supplemental={}
    def accept_extra(k,tag):
        assert k in stage
        if k in need and k not in direct and k not in joined and k not in partner:
            assert k not in supplemental
            supplemental[k]=tag
            remaining.pop(k,None)

    for name,sha in (
        ('supplemental-old-q.jsonl','c39e7c215b16f39bdcd3a29fe057009e134abd9314a830b3c942c3dab2798add'),
        ('supplemental-neighbor-direct.jsonl','5b0f929a4ca0e7fb1ac0669d4bdd9f96d9ccfd85daa9360bf401018d45e00149'),
    ):
        file=work/'inputs'/name
        if file.exists():
            assert digest(file)==sha
            used[file.relative_to(work).as_posix()]=sha
            for r in lines(file):
                k=r['leaf']
                assert r['label']==k and endpoints(r)==source(k)
                assert_area_row(r,'complete',allow_q=True)
                assert r['mode']==1 and r['q_mesh'] and r['stats'][3]==0 and r['stats'][4]>0
                accept_extra(k,'higher-old-q')
    neighbors=work/'inputs/supplemental-neighbors.zip'
    if neighbors.exists():
        assert digest(neighbors)=='66d09574caf6d713ceab854b2cdc36d37d88ef5f1ceefd0a44ad15ff391987b3'
        used[neighbors.relative_to(work).as_posix()]=digest(neighbors)
        for k in supplemental_neighbors(neighbors,source):
            accept_extra(k,'higher-old-q-continued')
    finished=set(direct)|set(joined)|set(partner)|set(supplemental)
    assert len(finished)==len(direct)+len(joined)+len(partner)+len(supplemental)
    assert finished<=need
    rest=need-finished
    out={
        "fixed_inputs":{"curves":["disk",3,5,7,9],"P":"P128","Q":"Qavg"},
        "stage4_count":len(stage),"inherited_count":len(yes),"new_whole":len(direct),
        "inherited_by_geometry":dict(high_geometries),"new_whole_by_geometry":dict(Counter(direct.values())),
        "new_joined":len(joined),"partner_closed":len(partner),"total_closed":len(yes)+len(finished),
        "additional_high_old_q":len(supplemental),
        "active_and_missing_original_roots":len(need-set(visited)-partner_started),
        "remaining_original_roots":sorted(rest,key=lambda k:tuple(map(int,k.split('/')))),
        "detail":{"direct":direct,"joined":joined,"partner":partner,"supplemental":supplemental,
                  "remaining_after_some_continuations":remaining},
        "counts":dict(totals),"uses":used,
        "complete_stage4":not rest,
    }
    a.output.write_text(json.dumps(out,indent=2)+"\n")
    print({k:v for k,v in out.items() if k not in ("remaining_original_roots","detail","uses")})


if __name__=="__main__":
    assert __debug__
    main()

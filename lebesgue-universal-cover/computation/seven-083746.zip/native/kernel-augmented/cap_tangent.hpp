// A rational affine upper bound on the height allowed by a cap area a.
// For the long chord, use the inverse of
//      (1023/1024) ell r^2/(r+f)
// in rescaled twice-area units. The disk fallback uses the quadratic bound
// from the already verified individual depth at total gap e.
struct CapTangent {
    static constexpr L Scale=L(1)<<40;
    static W ceildiv(W a,W b) { return (a+b-1)/b; }

    struct Line { W intercept; W slope; };

    static Line line(W e,L weight,L depth,const std::array<L,6>& widths,double share) {
        const double a=double(e)*share;
        double proposed=double(depth)*std::sqrt(share);
        L length=0,height=0;
        for(std::size_t i=0;i<widths.size();++i) {
            if(widths[i]<Q/1000)continue;
            const double c=double(widths[i])*(1023./1024.);
            const L f=LongEdgeSupport::band[i];
            const double r=(a+std::sqrt(a*a+4*a*c*f))/(2*c);
            if(r<proposed){
                proposed=r;length=widths[i];height=f;
            }
        }
        // Floating selection affects efficiency only. Reconstructed tangents
        // are exact for every positive r0 and all nonnegative cap areas.
        const L r0=std::min(depth,std::max<L>(1,L(std::ceil(proposed))));
        if(!length) {
            return {ceildiv(W(weight)*r0,2),
                    W(weight)*ceildiv(W(depth)*depth*Scale,2*e*r0)};
        }
        const W den=W(r0)+2*height;
        return {ceildiv(W(weight)*r0*height,den),
            W(weight)*ceildiv(W(1024)*(r0+height)*(r0+height)*Scale,
                             W(1023)*length*r0*den)};
    }

    static bool exceeds(W margin,W e,const L* row,const std::array<int,2>& overlap,
                        const L* depths,const std::vector<std::array<L,6>>& bands) {
        std::array<int,3> groups{0,1,2};
        if(overlap[0]>=0)groups[overlap[1]]=overlap[0];
        double totals[3]{};
        for(int i=0;i<3;++i)totals[groups[i]]+=double(row[3+i])*depths[i];
        const double den=totals[0]*totals[0]+totals[1]*totals[1]+totals[2]*totals[2];
        if(den<=0)return false;
        W constant=0;
        W slopes[3]{};
        for(int i=0;i<3;++i) {
            const double u=totals[groups[i]];
            const double share=std::max(1e-12,u*u/den);
            const auto local=line(e,row[3+i],depths[i],bands[row[i]],share);
            constant+=local.intercept;
            slopes[groups[i]]+=local.slope;
        }
        const W slope=std::max({slopes[0],slopes[1],slopes[2]});
        // Check the scale before multiplication, since ineffectively steep
        // tangents need not be considered.
        if(slope>(W(1)<<78))return false;
        return margin>constant+ceildiv(e*slope,Scale);
    }
};

// Upper bound on a balanced weighted sum of supports. The chosen body can
// differ with direction. Translation and angle are shared by all directions
// assigned to the same body.
struct CoupledSupport {
    static constexpr L U=L(1)<<22;
    const Box& lo;
    const Box& hi;
    const L* directions;
    const AngleMesh& mesh;
    int normals;
    const std::vector<std::array<L,5>>& angle_only;
    const std::vector<std::array<L,5>>& independently_shifted;

    static W ceildiv(W a,L b) {
        return a>=0 ? (a+b-1)/b : a/b;
    }

    W value(int body,const L* row,const std::array<int,3>& owner) const {
        W cx=0,cy=0,old_angle=0;
        std::array<int,3> subset{};
        int count=0;
        for(int j=0;j<3;++j) {
            if(owner[j]!=body) continue;
            const L i=row[j],w=row[3+j];
            subset[count++]=j;
            old_angle+=W(w)*angle_only[i][body];
            cx+=W(w)*directions[2*i];
            cy+=W(w)*directions[2*i+1];
        }
        if(!count)return 0;
        if(count==1 || !body) {
            W sum=0;
            for(int j=0;j<count;++j)
                sum+=W(row[subset[j]+3])*independently_shifted[row[subset[j]]][body];
            return sum;
        }
        const int index=3*(body-1);
        W shift=ceildiv(cx*(cx>=0 ? hi[index]:lo[index])
            +cy*(cy>=0 ? hi[index+1]:lo[index+1]),(Fine/Q)*U);
        if(body==1 || !mesh.panels)return old_angle+shift;
        const int count_knots=mesh.panels+1;
        const L* knots=mesh.knots+(body-2)*count_knots;
        const L* values=mesh.values+(body-2)*count_knots*normals;
        const L a=lo[index-1],b=hi[index-1];
        if(a<knots[0] || b>knots[count_knots-1] || a>b)std::abort();
        const auto at=[&](int k) {
            W accum=0;
            for(int l=0;l<count;++l) {
                const int i=subset[l];
                accum+=W(row[i+3])*values[k*normals+row[i]];
            }
            return accum;
        };
        const auto panel=[&](L x) {
            return std::min(count_knots-2,
                int(std::upper_bound(knots,knots+count_knots,x)-knots)-1);
        };
        const auto at_end=[&](L x,int k) {
            return ceildiv(at(k)*(knots[k+1]-x)+at(k+1)*(x-knots[k]),knots[k+1]-knots[k]);
        };
        const int left=panel(a),right=panel(b);
        W high=std::max(at_end(a,left),at_end(b,right));
        for(int j=left+1;j<=right;++j)high=std::max(high,at(j));
        return std::min(old_angle,high)+shift;
    }

    W upper(const L* row) const {
        std::array<int,3> owner;
        std::array<std::array<W,5>,3> level;
        W independent=0;
        for(int i=0;i<3;++i) {
            const auto& entry=independently_shifted[row[i]];
            const auto it=std::max_element(entry.begin(),entry.end());
            owner[i]=int(it-entry.begin());
            for(int b=0;b<5;++b)level[i][b]=W(row[i+3])*entry[b];
            independent+=level[i][owner[i]];
        }
        bool common=false;
        for(int i=0;i<3;++i)
            for(int j=0;j<i;++j)
                if(owner[i]>0 && owner[i]==owner[j])common=true;
        if(!common)return independent;
        W best=0;
        for(int b=0;b<5;++b)best+=value(b,row,owner);
        for(int i=0;i<5;++i)for(int j=0;j<5;++j)for(int k=0;k<5;++k) {
            const W bound=level[0][i]+level[1][j]+level[2][k];
            if(bound<=best)continue;
            std::array<int,3> assigned{i,j,k};
            W term=0;
            for(int b=0;b<5;++b)term+=value(b,row,assigned);
            best=std::max(best,std::min(bound,term));
            if(best>=independent)return independent;
        }
        return std::min(best,independent);
    }
};

"""Freeze the additional old independent Q11 terminal evidence."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys


def read(path):
    return json.loads(path.read_bytes())


def main():
    comp=Path(sys.argv[1])
    sys.path.insert(0,str(comp))
    from certify_tomar_six_high import U
    from replay_q11_with_p30 import PointProof
    from build_q11_leaf_bank import EPS, reflected_average
    from flint import ctx
    ctx.prec=160
    old=comp/'multi-host-points.json'
    bank=comp/'q11-leaf-bank.json'
    q,d=reflected_average(read(old))
    assert set(map(tuple,q))=={(x,-y) for x,y in q} and len(set(map(tuple,q)))==11
    d2=max((x-X)**2+(y-Y)**2 for x,y in q for X,Y in q)
    assert d2<d*d
    point=PointProof({**read(bank),"points":q,"denominator":d,"direction_scale":U},EPS)
    qrec={"input_points_sha256":sha256(old.read_bytes()).hexdigest(),
          "angle_bank_sha256":sha256(bank.read_bytes()).hexdigest(),"points":q,
          "denominator":d,"diameter_squared_numerator":d2,"cells":len(point.pointers)-1,
          "rows":len(point.triples)//8,"projection_error":str(EPS)}
    Path('inputs/q11-receipt.json').write_text(json.dumps(qrec,indent=2)+'\n')
    first=read(Path('inputs/first-index.json'))
    later=read(Path('inputs/later-all-audit.json'))
    stage={(int(p),i) for p,v in read(Path('inputs/stage4-retained.json')).items() for i in v}
    inherited={}
    for p,row in first['parts'].items():
        for group in ("five","P30","Q11"):
            for k in row[group]:
                assert (int(p),k) not in inherited
                inherited[int(p),k]=['first',group]
    assert len(inherited)==2163
    for row in later['proof_records']:
        key=tuple(map(int,row['leaf'].split('/')))
        assert key not in inherited
        group={5:'five',6:'P30',7:'Q11'}[row['inputs']]
        inherited[key]=['later',group,row['source_file'],row['source_line']]
    assert inherited.keys()<=stage and len(inherited)==4569
    out={"scope":len(stage),"inherited":len(inherited),
        "by_geometry":dict(Counter(x[1] for x in inherited.values())),
        "pending":len(stage-inherited.keys()),
        "inherited_rows":[[*k,*inherited[k]] for k in sorted(inherited)],
        "selected":[list(k) for k in sorted(stage-inherited.keys())]}
    assert out['by_geometry']=={'five':1080,'P30':2567,'Q11':922}
    Path("scope/seven-audit.json").write_text(json.dumps(out,indent=2)+"\n")
    print({k:out[k] for k in ('inherited','pending','by_geometry')})
    print('Q11 exact receipt',qrec)


if __name__=='__main__':
    assert __debug__
    main()

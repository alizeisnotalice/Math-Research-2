"""Rebuild the closed-leaf ledger, two finite point witnesses and their angle interfaces."""
from argparse import ArgumentParser
from hashlib import sha256
import gzip
import json
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile

BASE = Path(__file__).resolve().parent
R2 = '4c10e16ce608ce3ad11e6ee2a91eee50dad36b2b68da82349537fccb52da162d'
MANIFEST = '0426d3c85b07e39bd843cd61a858b5b3dff3a0fee89d3db9011b55c7d3fc44d2'

def hashfile(p):
    return sha256(p.read_bytes()).hexdigest()

def check(a):
    comp, tree, out = (q.resolve() for q in (a.comp, a.tree, a.out))
    out.mkdir(parents=True, exist_ok=False)
    native = out / 'native'
    shutil.copytree(BASE / 'native', native)
    high = comp / 'whole-leaves-083750-second/wave2.zip'
    assert hashfile(high) == R2
    shutil.copyfile(high, native/'replay-kits/public-replay-r2-083750.zip')
    sums = native/'SHA256SUMS'
    assert hashfile(sums) == MANIFEST
    for line in sums.read_text().splitlines():
        digest, n = line.split('  ',1)
        assert hashfile(native/n) == digest, n
    for archive in sorted((native/'volumes').glob('*.zip')):
        with ZipFile(archive) as z:
            assert z.testzip() is None
            assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
            z.extractall(native)
    def run(path,*args):
        subprocess.run([sys.executable,'-B',str(path),*map(str,args)],check=True)
    run(native/'verify_interfaces.py',comp,native)
    run(native/'reduce_augmented.py',comp,native/'inputs/augmented.json',out/'p66')
    run(native/'verify_qavg_transfer.py',comp,native,native/'inputs/q11-expanded-angles.json')
    args=['--partner',native/'partner']
    for path in sorted((native/'detached').iterdir()):
        args.extend(['--detached-tail',path])
    tails=sorted(native.glob('old-q-tail*'))
    for path in tails: args.extend(['--old-q-tail',path])
    ledger=out/'ledger.json'
    run(native/'audit_current.py',comp,tree,native,ledger,*args)
    fields=json.loads(ledger.read_bytes())
    assert fields==json.loads((native/'terminal-coverage.json').read_bytes())
    assert fields['complete_stage4'] and fields['total_closed']==5442 and not fields['remaining_original_roots']
    run(native/'audit_p66_routes.py',native,*tails)
    run(BASE/'finite_seven.py',comp,native/'inputs',out/'finite')
    actual=json.loads((out/'finite/finite.json').read_bytes())
    expect=json.loads((BASE/'finite/finite.json').read_bytes())
    for k,rec in actual['rational_examples'].items():
        n=rec['file']
        assert gzip.decompress((out/'finite'/n).read_bytes()) == gzip.decompress((BASE/'finite'/n).read_bytes())
        rec['sha256']=expect['rational_examples'][k]['sha256']
    assert actual==expect
    print('5442 closed original leaves; two explicit seven-family rational witnesses', flush=True)

if __name__=='__main__':
    assert __debug__
    parser=ArgumentParser(description=__doc__)
    for key in ('comp','tree','out'):parser.add_argument(key,type=Path)
    check(parser.parse_args())

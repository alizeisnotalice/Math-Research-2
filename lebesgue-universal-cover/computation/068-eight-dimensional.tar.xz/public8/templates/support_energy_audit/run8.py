import concurrent.futures, fractions, hashlib, json, math, os, pathlib, subprocess, sys, time
base=pathlib.Path('@LB8_ROOT@/support_energy_audit')
out=base/'pilot8';data=pathlib.Path('@LB8_ROOT@/reference/046-full-replay.json')
reference=json.loads(data.read_text()); assert len(reference['parts'])==24
delta=fractions.Fraction(1,10000)
accepted=[];todo=[]
for x in reference['parts']:
    v=x['min_margin'];assert x['ok'] and x['fails']==0 and v is not None
    pred=math.nextafter(v,-math.inf)
    if fractions.Fraction.from_float(pred)>delta:accepted.append(x['part'])
    else:todo.append(x['part'])
print('accepted',accepted,'recompute',todo,flush=True)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
py=sys.executable
def work(part):
    dst=out/f'part{part}.json'
    if dst.exists():
        r=json.loads(dst.read_text())
        assert r['part']==part and r['threshold']=='0.8361' and len(r['all_failing_leaves'])==r['result']['fails']
        return part,'existing',r['result']['fails']
    r=subprocess.run([py,'-B',str(base/'pilot8.py'),str(part)],env=env,capture_output=True,text=True)
    (out/f'part{part}.stdout').write_text(r.stdout)
    (out/f'part{part}.stderr').write_text(r.stderr)
    if r.returncode:raise RuntimeError((part,r.returncode,r.stderr))
    row=json.loads(dst.read_text());return part,'completed',row['result']['fails']
start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures={pool.submit(work,p):p for p in todo}
    for f in concurrent.futures.as_completed(futures):print('result',f.result(),flush=True)
summary={'threshold':'0.8361','margin_increment':'1/10000','reference_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),'inherited':accepted,'recomputed':todo,'elapsed':time.monotonic()-start}
(out/'screen.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)

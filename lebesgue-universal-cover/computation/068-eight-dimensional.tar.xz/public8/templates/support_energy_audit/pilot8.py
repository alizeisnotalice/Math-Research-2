import importlib.util, json, os, pathlib, sys, time, hashlib, platform
import numpy as np
import flint
from flint import arb
part=int(sys.argv[1]) if len(sys.argv)>1 else 4

root=pathlib.Path('@LB8_ROOT@')
src=root/'v9/checker/lbcheck.py'
orig=root/'tomar62/cert8d_0836'
out=pathlib.Path('@LB8_ROOT@/support_energy_audit/pilot8')
out.mkdir(exist_ok=True)
cert=out/'cert';cert.mkdir(exist_ok=True)
for p in orig.glob('part*'):
    dest=cert/p.name
    if p.suffix=='.json':
        d=json.loads(p.read_text());d['tau']=0.8361
        if not dest.exists():
            tmp=dest.with_suffix('.partial');tmp.write_text(json.dumps(d));tmp.replace(dest)
        else: assert json.loads(dest.read_text())==d
    elif not dest.exists():dest.symlink_to(p)
spec=importlib.util.spec_from_file_location('checker',src)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
orig_check=module.check_root
root_evidence=[]
def new_root(meta):
    errs=orig_check(meta)
    unexpected=[e for e in errs if not (e.startswith('translation range of body ') and e.endswith(' too small'))]
    for i,n in enumerate(meta['ns']):
        a,b=(0,1) if i==0 else (2+3*(i-1)+1,2+3*(i-1)+2)
        w=min(-meta['lo'][a],meta['hi'][a],-meta['lo'][b],meta['hi'][b])
        if w<=0:unexpected.append('invalid width');continue
        r=1-module.Rn_arb(n)
        if not r>0:unexpected.append('invalid inradius');continue
        lower=module.PI*(arb(1)/4+r*r)/2+arb(w)*(arb(1)/2+r)
        root_evidence.append({'n':n,'w':w,'area_lower':lower.str(18),'passed':bool(lower>arb('0.8361'))})
        if not lower>arb('0.8361'):unexpected.append('inball root fails')
    return unexpected
module.check_root=new_root
failures=[]
old_bound=module.Checker.check_bound_leaf
def bound(self,c,h):
    ok,msg=old_bound(self,c,h)
    if not ok:failures.append({'center':c.tolist(),'halfwidth':h.tolist(),'reason':msg})
    return ok,msg
module.Checker.check_bound_leaf=bound
start=time.monotonic(); result=module.check_part(str(cert),part);elapsed=time.monotonic()-start
assert result.get('fails')==len(failures)
payload={'part':part,'threshold':'0.8361','python':platform.python_version(),'numpy':np.__version__,'flint':flint.__version__,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'part_sha256':hashlib.sha256((orig/f'part{part:04d}.npy').read_bytes()).hexdigest(),'seconds':elapsed,'result':result,'root_evidence':root_evidence,'all_failing_leaves':failures}
tmp=out/f'part{part}.partial';tmp.write_text(json.dumps(payload,indent=2));tmp.replace(out/f'part{part}.json')
print(json.dumps({k:v for k,v in payload.items() if k!='all_failing_leaves'},indent=2))

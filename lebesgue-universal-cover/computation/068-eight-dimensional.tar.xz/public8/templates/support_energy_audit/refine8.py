import importlib.util, json, math, os, pathlib, sys, time
import numpy as np
from fractions import Fraction as F
base=pathlib.Path('@LB8_ROOT@/support_energy_audit/pilot8')
src='@LB8_ROOT@/v9/checker/lbcheck.py'
spec=importlib.util.spec_from_file_location('checker',src);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
part=int(sys.argv[1]);depth=int(sys.argv[2]) if len(sys.argv)>2 else 12
limit=int(sys.argv[3]) if len(sys.argv)>3 else None
data=json.loads((base/f'part{part}.json').read_text());meta=json.loads((base/'cert'/f'part{part:04d}.json').read_text()); assert data['result']['fails']==len(data['all_failing_leaves'])
rootwidth=np.array(meta['hi'])-np.array(meta['lo']);check=m.Checker(meta['ns'],0.8361,meta['N'],meta['eps'])
fan=pathlib.Path(f'@LB8_ROOT@/integer8-pilot/fanpart{part}.json')
fan_data=json.loads(fan.read_text());indices=[r[0] for r in fan_data['unclosed']]
positions={r[0]:r[1] for r in fan_data['unclosed']}
assert len(indices)==fan_data['remaining']
if limit is not None:indices=indices[:limit]
ledger=base/f'refine-fan{part}.jsonl';finished=[]
if ledger.exists():
    for line in ledger.read_text().splitlines():finished.append(json.loads(line))
    assert all(row['index']==i for row,i in zip(finished,indices))
start=time.monotonic()
for k,i in enumerate(indices):
    if k<len(finished):continue
    item=data['all_failing_leaves'][i]
    stack=[(np.array(item['center']),np.array(item['halfwidth']),0,'')];leaves=0;splits=0;maxdepth=0;fail=[]
    while stack:
        c,h,d,path=stack.pop();maxdepth=max(maxdepth,d)
        ok,msg=check.check_bound_leaf(c,h)
        if ok:leaves+=1;continue
        if d==depth:
            fail.append({'center':c.tolist(),'halfwidth':h.tolist(),'path':path,'reason':msg});continue
        k=int(np.argmax(h/rootwidth));hh=h.copy();hh[k]*=.5;c1=c.copy();c2=c.copy();c1[k]-=hh[k];c2[k]+=hh[k]
        assert F(float(c1[k]))-F(float(hh[k]))==F(float(c[k]))-F(float(h[k]))
        assert F(float(c1[k]))+F(float(hh[k]))==F(float(c[k]))
        assert F(float(c2[k]))-F(float(hh[k]))==F(float(c[k]))
        assert F(float(c2[k]))+F(float(hh[k]))==F(float(c[k]))+F(float(h[k]))
        stack.extend([(c2,hh.copy(),d+1,path+'1'),(c1,hh.copy(),d+1,path+'0')]);splits+=1
    row={'index':i,'leaf_position':positions[i],'closed':not fail,'certified_leaves':leaves,'splits':splits,'maximum_depth':maxdepth,'unresolved':fail}
    assert splits+1==leaves+len(fail)
    with ledger.open('a') as f:
        f.write(json.dumps(row,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
    finished.append(row)
    if i%100==0 or fail: print('part',part,'failure',i,'closed',not fail,'splits',splits,'remaining',len(fail),flush=True)
print('complete',part,len(finished),'seconds',time.monotonic()-start,'remaining',sum(not x['closed'] for x in finished),flush=True)

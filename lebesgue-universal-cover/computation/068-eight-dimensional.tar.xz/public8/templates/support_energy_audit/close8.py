import importlib.util,json,os,pathlib,sys,time
import numpy as np
from fractions import Fraction as F
base=pathlib.Path('@LB8_ROOT@/support_energy_audit/pilot8')
src='@LB8_ROOT@/v9/checker/lbcheck.py'
sp=importlib.util.spec_from_file_location('check',src);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
part=int(sys.argv[1]);maxdepth=int(sys.argv[2]) if len(sys.argv)>2 else 10
meta=json.loads((base/'cert'/f'part{part:04d}.json').read_text());ch=m.Checker(meta['ns'],0.8361,meta['N'],meta['eps']);rootw=np.array(meta['hi'])-np.array(meta['lo'])
rows=[json.loads(x) for x in (base/f'multi-fan{part}.jsonl').read_text().splitlines()];jobs=[r for r in rows if not r['passed']]
ledger=base/f'close-fan{part}.jsonl';done=[]
if ledger.exists():done=[json.loads(x) for x in ledger.read_text().splitlines()]
start=time.monotonic()
for i,item in enumerate(jobs):
 if i<len(done):
  assert done[i]['index']==item['index'] and done[i]['path']==item['path'];continue
 stack=[(np.array(item['center']),np.array(item['halfwidth']),0,'')];passed=0;splits=0;failed=[];usedmulti=0
 while stack:
  c,h,d,path=stack.pop();ok,msg=ch.check_bound_leaf(c,h)
  if not ok:
   for axis in range(8):
    a=np.zeros(8);a[axis]=1
    try:ok,msg=ch.check_multi_leaf(c,h,[a,-a],[1,1])
    except Exception:ok=False
    if ok:usedmulti+=1;break
  if ok:passed+=1;continue
  if d==maxdepth:
   failed.append({'center':c.tolist(),'halfwidth':h.tolist(),'subpath':path});continue
  k=int(np.argmax(h/rootw));hh=h.copy();hh[k]*=.5;c1=c.copy();c2=c.copy();c1[k]-=hh[k];c2[k]+=hh[k]
  assert F(float(c1[k]))-F(float(hh[k]))==F(float(c[k]))-F(float(h[k]))
  assert F(float(c1[k]))+F(float(hh[k]))==F(float(c[k]))==F(float(c2[k]))-F(float(hh[k]))
  assert F(float(c2[k]))+F(float(hh[k]))==F(float(c[k]))+F(float(h[k]))
  stack.extend([(c2,hh.copy(),d+1,path+'1'),(c1,hh.copy(),d+1,path+'0')]);splits+=1
 assert splits+1==passed+len(failed)
 row={'index':item['index'],'leaf_position':item['leaf_position'],'path':item['path'],'passed':not failed,'closed_subboxes':passed,'multifan':usedmulti,'splits':splits,'unresolved':failed}
 with ledger.open('a') as f:f.write(json.dumps(row,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
 done.append(row);print('item',i,'of',len(jobs),'passed',not failed,'splits',splits,'remaining',len(failed),flush=True)
print('complete',len(done),'remaining',sum(not x['passed'] for x in done),'elapsed',time.monotonic()-start,flush=True)

import importlib.util,json,os,pathlib,sys,time
import numpy as np
from fractions import Fraction as F
base=pathlib.Path('@LB8_ROOT@/support_energy_audit/pilot8')
src='@LB8_ROOT@/v9/checker/lbcheck.py'
sp=importlib.util.spec_from_file_location('check',src);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
part=int(sys.argv[1]);meta=json.loads((base/'cert'/f'part{part:04d}.json').read_text());checker=m.Checker(meta['ns'],0.8361,meta['N'],meta['eps'])
rows=[json.loads(x) for x in (base/f'refine-fan{part}.jsonl').read_text().splitlines()]
jobs=[(row['index'],row['leaf_position'],box) for row in rows for box in row['unresolved']]
ledger=base/f'multi-fan{part}.jsonl';done=[]
if ledger.exists():done=[json.loads(x) for x in ledger.read_text().splitlines()]
start=time.monotonic()
for i,(index,pos,box) in enumerate(jobs):
 if i<len(done):
  assert done[i]['index']==index and done[i]['path']==box['path'];continue
 c=np.array(box['center']);h=np.array(box['halfwidth']);best=None
 for axis in range(8):
  a=np.zeros(8);a[axis]=1
  try:ok,msg=checker.check_multi_leaf(c,h,[a,-a],[1,1])
  except Exception as e:ok=False;msg=f'{type(e).__name__}: {e}'
  if ok:best={'axis':axis,'message':msg};break
 row={'index':index,'leaf_position':pos,'path':box['path'],'passed':best is not None,'witness':best,'center':box['center'],'halfwidth':box['halfwidth']}
 with ledger.open('a') as f:f.write(json.dumps(row,separators=(',',':'))+'\n');f.flush();os.fsync(f.fileno())
 done.append(row)
 if i%25==0:print('checked',i+1,'of',len(jobs),'passed',sum(x['passed'] for x in done),flush=True)
print('complete',len(done),'passed',sum(x['passed'] for x in done),'elapsed',time.monotonic()-start,flush=True)

"""Audit 0.8361 receipt lineage, exact residual paths and closure counts (not a replay)."""
import hashlib,importlib.util,json,math,pathlib
from fractions import Fraction as F
import numpy as np
P=pathlib.Path('@LB8_ROOT@/support_energy_audit/pilot8')
G=pathlib.Path('@LB8_ROOT@/integer8-pilot')
R=pathlib.Path('@LB8_ROOT@/reference/046-full-replay.json')
source=pathlib.Path('@LB8_ROOT@/v9/checker/lbcheck.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sp=importlib.util.spec_from_file_location('frozencheck',source);checker=importlib.util.module_from_spec(sp);sp.loader.exec_module(checker)
ref=json.loads(R.read_text());screen=json.loads((P/'screen.json').read_text());assert sha(R)==screen['reference_sha256']
assert sorted(screen['inherited']+screen['recomputed'])==list(range(24));by={x['part']:x for x in ref['parts']}
for part in screen['inherited']:
 x=by[part];assert x['ok'] and x['fails']==0 and F.from_float(math.nextafter(x['min_margin'],-math.inf))>F(1,10000)
def lines(p):return [json.loads(x) for x in p.read_text().splitlines()]
def exact(v):return tuple(F.from_float(float(x)) for x in v)
def descend(c,h,path,rootw):
 c=np.array(c);h=np.array(h)
 for bit in path:
  assert bit in '01';k=int(np.argmax(h/rootw));hh=h[k]/2
  oldc=F.from_float(float(c[k]));oldh=F.from_float(float(h[k]));h[k]=hh;c[k]+=(-hh if bit=='0' else hh)
  assert F.from_float(float(h[k]))*2==oldh
  assert F.from_float(float(c[k]))==oldc+(-F.from_float(float(hh)) if bit=='0' else F.from_float(float(hh)))
 return exact(c),exact(h)
parts=[]
for part in screen['recomputed']:
 ip=P/f'part{part}.json';a=json.loads(ip.read_text());bpath=G/f'bind{part}.json';b=json.loads(bpath.read_text());fpath=G/f'fanpart{part}.json';f=json.loads(fpath.read_text())
 assert a['part']==b['part']==f['part']==part and a['threshold']=='0.8361'
 assert a['source_sha256']==sha(source) and a['part_sha256']==b['codes_sha256']
 assert sha(ip)==b['input_sha256']==f['input_sha256'] and sha(bpath)==f['binding_sha256']
 assert sha(G/'fan8.cpp')==f['source_sha256'] and f['library_sha256']=='cf56c051facdd89fed31f972a6584dd45f9e2bb61f79f7c1de3081ecf9356b57'
 assert sha(pathlib.Path('@LB8_ROOT@/tomar62/fan-table8-v2.npz'))==f['table_sha256']
 assert len(a['all_failing_leaves'])==a['result']['fails']==len(b['leaf_positions'])==f['old_failures']
 assert len(set(b['leaf_positions']))==len(b['leaf_positions']) and [r[0] for r in f['rows']]==b['leaf_positions']
 assert f['fan_passed']==sum(r[-1] for r in f['rows']) and f['remaining']==len(f['unclosed'])
 assert f['unclosed']==[[i,*row] for i,row in enumerate(f['rows']) if not row[-1]]
 assert len(f['rows'])==f['old_failures'] and f['old_passed']+f['old_failures']==a['result']['leaves']==by[part]['leaves']
 assert all(z['passed'] for z in a['root_evidence']) and len(a['root_evidence'])==3
 meta=json.loads((P/'cert'/f'part{part:04d}.json').read_text())
 rooterr=checker.check_root(meta)
 assert all(e.startswith('translation range of body ') and e.endswith(' too small') for e in rooterr),rooterr
 for i,n in enumerate(meta['ns']):
  j=0 if i==0 else 3*i
  w=min(-F(meta['lo'][j]),F(meta['hi'][j]),-F(meta['lo'][j+1]),F(meta['hi'][j+1]))
  coslo=1-(F(22,7)/(2*n))**2/2;r=1-1/(2*coslo)
  assert w>0 and r>0 and F(314,100)*(F(1,4)+r*r)/2+w*(F(1,2)+r)>F(8361,10000)
 if f['remaining']:
  v=lines(P/f'refine-fan{part}.jsonl');assert len(v)==f['remaining']
  assert [(x['index'],x['leaf_position']) for x in v]==[(x[0],x[1]) for x in f['unclosed']]
  rootw=np.array(meta['hi'])-np.array(meta['lo'])
  target={}
  for row in v:
   assert row['splits']+1==row['certified_leaves']+len(row['unresolved'])
   assert row['closed']==(not row['unresolved'])
   orig=a['all_failing_leaves'][row['index']]
   for item in row['unresolved']:
    key=(row['index'],item['path']);assert key not in target
    assert descend(orig['center'],orig['halfwidth'],item['path'],rootw)==(exact(item['center']),exact(item['halfwidth']))
    target[key]=item
  if target:
   w=lines(P/f'multi-fan{part}.jsonl');assert len(w)==len(target)
   seen=set();pending={}
   for row in w:
    key=(row['index'],row['path']);assert key in target and key not in seen;seen.add(key)
    assert row['leaf_position']==b['leaf_positions'][row['index']]
    assert exact(row['center'])==exact(target[key]['center']) and exact(row['halfwidth'])==exact(target[key]['halfwidth'])
    if not row['passed']:pending[key]=row
   if pending:
    q=lines(P/f'close-fan{part}.jsonl');assert len(q)==len(pending)
    for row in q:
     key=(row['index'],row['path']);assert key in pending
     assert row['leaf_position']==pending[key]['leaf_position'] and row['passed'] and not row['unresolved']
     assert row['splits']+1==row['closed_subboxes'];del pending[key]
    assert not pending
 parts.append({'part':part,'leaves':a['result']['leaves'],'old_failed':f['old_failures'],'integer_passed':f['fan_passed'],'post_fan_original_leaves':f['remaining']})
assert sum(x['leaves'] for x in parts)+sum(by[p]['leaves'] for p in screen['inherited'])==808905
result={'target':'0.8361','inherited':screen['inherited'],'parts':parts,'all_paths_and_counts_passed':True,'scope':'receipt, exact residual path and coverage-count audit; no recomputation of successful Arb/fan arithmetic','reference_sha256':sha(R),'checker_sha256':sha(source)}
(P/'audit8.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

from flint import arb,ctx
import numpy as np, json,hashlib,sys,time
from fractions import Fraction as F
from pathlib import Path
ctx.prec=128; root=Path('@LB8_ROOT@/tomar62'); path=root/'fan-table8-v2.npz'; header=json.loads((root/'cert8d_0836/part0000.json').read_text()); t=time.monotonic()
with np.load(path,allow_pickle=False) as z:
 Q=int(z['scale']);grid=int(z['grid']); counts=z['counts']; points=z['points']; orig=z['original_hi']; assert Q==2**28 and grid==1024 and counts.tolist()[:4]==[96,24,40,56]
 assert all(F.from_float(header['hi'][k])==F(int(orig[k]),2**44) for k in [2,5])
 assert points.dtype==np.int32 and points.shape==(1025,288,2) and np.max(np.abs(points[:,:216].astype(np.int64)))<Q
 start=0; checks=0
 for body,(n,count) in enumerate(zip((0,3,5,7),counts[:4])):
  for j in range(1 if body<2 else 1025):
   theta=F(0) if body<2 else F.from_float(header['hi'][3*body-4])*j/1024
   th=arb(theta.numerator)/theta.denominator
   if n:
    r=1/(2*(arb.pi()/(2*n)).cos()); centers=[(r*(th+2*arb.pi()*k/n).cos(),r*(th+2*arb.pi()*k/n).sin()) for k in range(n)]
   for xx,yy in points[j,start:start+count]:
    x=arb(int(xx))/Q;y=arb(int(yy))/Q
    assert x*x+y*y<arb(1)/4 if not n else all((x-a)**2+(y-b)**2<1 for a,b in centers)
    checks+=1
  if body<2: assert (points[:,start:start+count]==points[0,start:start+count]).all()
  start+=int(count)
out={'checks':checks,'seconds':time.monotonic()-t,'prec':ctx.prec,'scale':Q,'grid':grid,'table_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'header_sha256':hashlib.sha256((root/'cert8d_0836/part0000.json').read_bytes()).hexdigest(),'verified':True}
Path('@LB8_ROOT@/integer8-pilot/table-verification.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out))

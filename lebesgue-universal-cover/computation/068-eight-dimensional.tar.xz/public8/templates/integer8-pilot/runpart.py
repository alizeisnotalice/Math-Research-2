import ctypes,json,numpy as np,time,hashlib,sys,platform
from fractions import Fraction as F
from pathlib import Path
part=int(sys.argv[1]);base=Path('@LB8_ROOT@/tomar62'); out=Path('@LB8_ROOT@/integer8-pilot'); infile=Path(f'@LB8_ROOT@/support_energy_audit/pilot8/part{part}.json'); inp=json.loads(infile.read_text()); bind=json.loads((out/f'bind{part}.json').read_text()); assert hashlib.sha256(infile.read_bytes()).hexdigest()==bind['input_sha256']; leaves=inp['all_failing_leaves']; assert len(leaves)==len(bind['leaf_positions'])
with np.load(base/'fan-table8-v2.npz') as f:
 counts=f['counts'].copy();m=int(sum(counts[:4]));table=np.ascontiguousarray(f['points'][:,:m,:]);orig=f['original_hi'].copy()
counts[4]=0
lib=ctypes.CDLL(str(out/'fan8.dylib'));vec=lambda t:np.ctypeslib.ndpointer(dtype=t,ndim=1,flags='C_CONTIGUOUS');lib.fan_probe.argtypes=[ctypes.c_int,vec(np.int64),vec(np.int64),vec(np.int64),vec(np.int32),vec(np.int32),ctypes.c_int64,ctypes.c_int,ctypes.c_int,vec(np.int64)]
S=2**44;q=2**28;goal=-(-(2*F('0.8361')*q*q).numerator//(2*F('0.8361')*q*q).denominator); lo=[];hi=[]
for v in leaves:
 l=[];h=[]
 for c,w in zip(v['center'],v['halfwidth']):
  x=(F.from_float(c)-F.from_float(w))*S;y=(F.from_float(c)+F.from_float(w))*S;l.append(x.numerator//x.denominator);h.append(-(-y.numerator//y.denominator))
 lo.extend(l+[0,0,0]);hi.extend(h+[0,0,0])
lo=np.asarray(lo,dtype=np.int64);hi=np.asarray(hi,dtype=np.int64);res=np.zeros((len(leaves),4),dtype=np.int64);t=time.monotonic();rc=lib.fan_probe(len(leaves),lo,hi,orig,table.ravel(),counts,goal,24,4095,res.ravel());dt=time.monotonic()-t;assert rc==0
rows=[[int(pos),*map(int,x)] for pos,x in zip(bind['leaf_positions'],res)]; unclosed=[[i,*row] for i,row in enumerate(rows) if not row[-1]]
r={'part':part,'target':'0.8361','old_checked':inp['result']['leaves'],'old_passed':inp['result']['leaves']-inp['result']['fails'],'old_failures':len(leaves),'fan_passed':int(res[:,3].sum()),'remaining':len(unclosed),'checks':int(res[:,0].sum()),'fan_seconds':dt,'depth':24,'call_limit':4095,'input_sha256':bind['input_sha256'],'binding_sha256':hashlib.sha256((out/f'bind{part}.json').read_bytes()).hexdigest(),'table_sha256':hashlib.sha256((base/'fan-table8-v2.npz').read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((out/'fan8.dylib').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((out/'fan8.cpp').read_bytes()).hexdigest(),'schema':['leaf_position','checks','depth','closed_subboxes','passed'],'rows':rows,'unclosed_schema':['input_index','leaf_position','checks','depth','closed_subboxes','passed'],'unclosed':unclosed}
(out/f'fanpart{part}.json').write_text(json.dumps(r));print(json.dumps({k:v for k,v in r.items() if k not in ('rows','unclosed')}),flush=True)

import numpy as np,json,hashlib,itertools,time,sys
from pathlib import Path
from fractions import Fraction as F
base=Path('@LB8_ROOT@/tomar62/cert8d_0836'); old=Path('@LB8_ROOT@/support_energy_audit/pilot8'); dst=Path('@LB8_ROOT@/integer8-pilot'); part=int(sys.argv[1]); start=time.monotonic();p=old/f'part{part}.json'; d=json.loads(p.read_text()); meta_path=base/f'part{part:04d}.json';meta=json.loads(meta_path.read_text()); fn=base/f'part{part:04d}.npy'; codes=np.load(fn); assert hashlib.sha256(fn.read_bytes()).hexdigest()==d['part_sha256']; assert d['threshold']=='0.8361' and d['result']['fails']==len(d['all_failing_leaves']); assert d['result']['leaves']>0
leaves=d['all_failing_leaves']; wanted={tuple(x['center']+x['halfwidth']):i for i,x in enumerate(leaves)}; assert len(wanted)==len(leaves)
lo=np.array(meta['lo']);hi=np.array(meta['hi']);s0=np.array(meta['split0']);found=[None]*len(leaves); pos=0;nleaf=0
for cell in list(np.ndindex(*meta['split0']))[part::meta['nparts']]:
 l=lo+(hi-lo)*np.array(cell)/s0;h=lo+(hi-lo)*(np.array(cell)+1)/s0;stack=[(l,h)]
 while stack:
  l,h=stack.pop(); code=int(codes[pos]); at=pos;pos+=1
  if code>=253:
   nleaf+=1
   if code!=254:continue
   c=0.5*(l+h);w=0.5*(h-l);i=wanted.get(tuple(c.tolist()+w.tolist()))
   if i is not None:
    assert found[i] is None
    assert all(F.from_float(float(c[k]))-F.from_float(float(w[k]))==F.from_float(float(l[k])) and F.from_float(float(c[k]))+F.from_float(float(w[k]))==F.from_float(float(h[k])) for k in range(8))
    found[i]=at
  else:
   assert 0<=code<8
   m=0.5*(l[code]+h[code]);l2=l.copy();h1=h.copy();l2[code]=m;h1[code]=m;stack.append((l2,h.copy()));stack.append((l.copy(),h1))
assert pos==len(codes) and nleaf==d['result']['leaves'] and all(x is not None for x in found)
out={'part':part,'leaf_positions':found,'count':len(found),'node_count':pos,'nleaf':nleaf,'seconds':time.monotonic()-start,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'codes_sha256':d['part_sha256'],'meta_sha256':hashlib.sha256(meta_path.read_bytes()).hexdigest()}
(dst/f'bind{part}.json').write_text(json.dumps(out));print(json.dumps({k:v for k,v in out.items() if k!='leaf_positions'}),flush=True)

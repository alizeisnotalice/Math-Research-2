import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
data=json.loads((root/'MANIFEST.json').read_text())
for name,expected in data.items():
 p=root/name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected, name
print('verified',len(data),'files')

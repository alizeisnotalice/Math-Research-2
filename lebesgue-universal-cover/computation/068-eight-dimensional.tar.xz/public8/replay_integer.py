"""Rebuild integer verifier, replay all failed-leaf fans and compare exact rows."""
import json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent;p=root/'integer8-pilot'
src=p/'fan8.cpp';lib=p/'fan8.dylib'
args=['clang++','-std=c++17','-O1','-ftrapv','-fsanitize=undefined']
args+=['-dynamiclib'] if sys.platform=='darwin' else ['-shared','-fPIC']
subprocess.run(args+[str(src),'-o',str(lib)],check=True)
subprocess.run([sys.executable,'-B',str(p/'verify8.py')],check=True)
run=(p/'runpart.py').read_text();old="(out/f'fanpart{part}.json').write_text(json.dumps(r))";new="(out/f'replay{part}.json').write_text(json.dumps(r))"
assert old in run;tmp=p/'runpart-replay.py';tmp.write_text(run.replace(old,new))
parts=json.loads((root/'support_energy_audit/pilot8/screen.json').read_text())['recomputed']
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
for part in parts:
 subprocess.run([sys.executable,'-B',str(tmp),str(part)],check=True,env=env,stdout=subprocess.DEVNULL)
 a=json.loads((p/f'fanpart{part}.json').read_text());b=json.loads((p/f'replay{part}.json').read_text())
 for key in ['part','target','old_checked','old_passed','old_failures','fan_passed','remaining','checks','depth','call_limit','input_sha256','binding_sha256','table_sha256','source_sha256','rows','unclosed']:
  assert a[key]==b[key],(part,key)
 print('replayed',part,flush=True)
print('all integer-fan rows reproduced')

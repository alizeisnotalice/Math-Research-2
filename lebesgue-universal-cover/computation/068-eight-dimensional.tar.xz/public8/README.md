# 0.8361 eight-dimensional certificate

This package contains project-generated verifier code, computed witness points and receipts. It does not distribute the upstream checker, certificate tree, or a compiled library. Upstream is [tejasvi/lebesgue-cover-bound](https://github.com/tejasvi/lebesgue-cover-bound), revision `10af98606c98ca9ffd0d9f402cae1e2efe74b792`; its repository declares the Apache License 2.0. `UPSTREAM.json` records the revision and SHA-256 hashes of the archive, both checker files and every one of the 48 original tree files. The output and verifier code in this package were developed for this project. No separate open-source license is declared here for this project's files.

Prerequisites: a checkout of that exact upstream revision, Python 3.13.18, NumPy 2.5.5, python-flint 0.9.0 and clang++. Work on a disposable copy. Run:

```sh
python3 -B verify_manifest.py
python3 -B configure.py /path/to/upstream-checkout
python3 -B support_energy_audit/audit8.py
python3 -B replay_integer.py
python3 -B replay_residual.py
```

Configuration verifies and extracts the separately acquired upstream archive, checks all 48 tree-file hashes, and instantiates local paths from templates. The audit checks inherited margins, root bounds, original-leaf bindings, all retained residual paths and closure counts. `replay_integer.py` rebuilds the integer verifier using overflow and undefined-behavior instrumentation, verifies all 98,520 material points in 128-bit Arb and replays all 18 fan receipts, comparing every output row to the stored result. `replay_residual.py` independently recomputes all post-integer Arb subboxes, at most three processes at a time, and compares their logs byte for byte. A rebuilt binary is local output and is not distributed.

The residual Arb receipts can be fully recalculated in a separate copy. After configuration, delete only `refine-fan*.jsonl`, `multi-fan*.jsonl`, `close-fan*.jsonl` in `support_energy_audit/pilot8`, then run `support_energy_audit/refine8.py N 12` for N = 1,5,6,9,13,14,17,21,22. Where unresolved subboxes exist, run `multi8.py N`, then if necessary `close8.py N 10`. The input fan receipts and original failed boxes remain intact. Run `audit8.py` afterwards. Set `OMP_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1` and `VECLIB_MAXIMUM_THREADS=1`; use at most three concurrent compute processes.

To reproduce the 18 full original-Arb scans, remove their `partN.json` receipts in a separate copy and run `support_energy_audit/run8.py`. Re-run `integer8-pilot/bind.py N` and `integer8-pilot/runpart.py N` for all 18 N listed by `run8.py`, then the residual steps above. Timings affect receipt hashes, so the binding and fan receipts must be regenerated in that order. The six inherited slices additionally rely on the stored round-46 full replay and conservative predecessor-margin argument. The audit alone does not rerun successful Arb operations; the integer replay does not independently prove the verifier algorithm.

"""Configure a fresh local run from the separately acquired fixed upstream checkout."""
import hashlib,json,pathlib,shutil,subprocess,sys,tarfile
root=pathlib.Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('usage: python configure.py UPSTREAM_GIT_CHECKOUT')
up=pathlib.Path(sys.argv[1]).resolve(); data=json.loads((root/'UPSTREAM.json').read_text())
rev=subprocess.check_output(['git','-C',str(up),'rev-parse','HEAD'],text=True).strip()
assert rev==data['revision'],rev
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(up/data['archive'])==data['archive_sha256']
for name in ['lbcheck','treecheck']:
 assert sha(up/'checker'/f'{name}.py')==data[f'checker_{name}_sha256']
dest=root/'tomar62/cert8d_0836';dest.mkdir(parents=True,exist_ok=True)
with tarfile.open(up/data['archive'],'r:xz') as tar:
 for name,h in data['tree_files'].items():
  member=tar.getmember('cert8d_0836/'+name);assert member.isfile()
  f=tar.extractfile(member);content=f.read();assert hashlib.sha256(content).hexdigest()==h
  (dest/name).write_bytes(content)
(root/'v9/checker').mkdir(parents=True,exist_ok=True)
shutil.copy2(up/'checker/lbcheck.py',root/'v9/checker/lbcheck.py')
cert=root/'support_energy_audit/pilot8/cert';cert.mkdir(parents=True,exist_ok=True)
for i in range(24):
 d=json.loads((dest/f'part{i:04}.json').read_text());d['tau']=0.8361
 (cert/f'part{i:04}.json').write_text(json.dumps(d))
for p in (root/'templates').rglob('*.py'):
 q=root/p.relative_to(root/'templates');q.parent.mkdir(parents=True,exist_ok=True)
 q.write_text(p.read_text().replace('@LB8_ROOT@',str(root)))
print('configured',len(data['tree_files']),'verified upstream tree files')

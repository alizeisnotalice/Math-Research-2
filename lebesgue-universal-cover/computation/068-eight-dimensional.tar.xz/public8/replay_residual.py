"""Replay residual Arb split and multifan logs in a disposable configured copy."""
import concurrent.futures,hashlib,json,os,pathlib,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parent;p=root/'support_energy_audit/pilot8'
parts=[1,5,6,9,13,14,17,21,22];backup=root/'replay-backup';backup.mkdir(exist_ok=False)
old=list(p.glob('refine-fan*.jsonl'))+list(p.glob('multi-fan*.jsonl'))+list(p.glob('close-fan*.jsonl'))
for f in old:shutil.move(f,backup/f.name)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
def call(args):subprocess.run([sys.executable,'-B',*map(str,args)],check=True,env=env,stdout=subprocess.DEVNULL)
def run(part):
 call([root/'support_energy_audit/refine8.py',part,12])
 rows=[json.loads(x) for x in (p/f'refine-fan{part}.jsonl').read_text().splitlines()]
 if any(row['unresolved'] for row in rows):
  call([root/'support_energy_audit/multi8.py',part])
  rows=[json.loads(x) for x in (p/f'multi-fan{part}.jsonl').read_text().splitlines()]
  if any(not row['passed'] for row in rows):call([root/'support_energy_audit/close8.py',part,10])
 print('replayed residual',part,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,parts))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for prev in backup.iterdir():
 curr=p/prev.name;assert curr.exists() and sha(curr)==sha(prev),prev.name
assert set(x.name for x in backup.iterdir())==set(x.name for x in p.glob('*-fan*.jsonl'))
print('all residual Arb logs reproduced')

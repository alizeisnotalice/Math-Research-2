"""Independently bind closed root classes to actual partner exclusion cells."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import defaultdict
import json,sys
from flint import arb,ctx
D=Path(__file__).resolve().parent;C=D/'j32-33/comp012';R=D/'j32-33';S=D/'partner-scout';j=int(sys.argv[1]);assert j in range(35,40)
G='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9';sha=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes());ctx.prec=160
raw=load(S/'result.json');aud=load(S/'audit.json');nested=load(D/'nested32-39.json');data=load(R/f'join-j{j}.json');q=load(R/'physical-0125.json');cfg=load(R/f'config-j{j}.json')
assert data['complete'] and data['all_passed'] and data['synchronized'] and data['tighten_first'] and data['parameters']==cfg
assert cfg['bins']==[j] and F(cfg['cut'])==F('-.012') and F(cfg['retreat'])==F(593,6250000000)
assert set(data['source_hashes'])=={'certify_partner_join.py','ordered_state.py','sharp_first_hit.py','ordered_derivative.py',f'config-j{j}.json','physical-0125.json','certify_ah_affine_root_class.py','certify_sigma_derivative_classes.py','certify_ah_pinned_normals.py','certify_sigma_pinned_fan.py','certify_sigma_extended_graph.py'}
assert q=={'sigma_degrees':'1.54','line':['.429','.01250'],'physical_parameters':['.327','.372','.0165']} and data['physical_parameters']==raw['physical_parameters']==aud['parameters']==nested['parameters']==q
assert data['geometry_sha256']==raw['geometry_sha256']==aud['geometry_sha256']==nested['geometry_sha256']==G
assert data['reachable']=={str(j):[[0,75]]} and data['EH_tightening']=={'label':'U1-Te-0','retreat':'593/6250000000'}
assert data['partner_raw_sha256']==aud['raw_sha256']==sha(S/'result.json') and data['partner_audit_sha256']==sha(S/'audit.json') and aud['auditor_sha256']==sha(S/'audit_partner_01250.py')
assert aud['complete'] and aud['orientation']==raw['orientation']==0 and raw['only_positive_deficit'] and aud['physical_subcells']==375
case,=[x for x in aud['cases'] if x['bin']==j];assert case['closed_cells']==75 and F(case['proven_y4_upper'])==F(3,8) and arb(case['AH_retaining_lower'])>0 and arb(case['negative_cross_lower'])>0
nest,=[x for x in nested['bins'] if x['bin']==j];assert nest['exact_budget_pairs']==95 and nest['S_less_than_F_blocks']==0 and all(F(x['min_F_gap'])>=0 and F(x['min_S_gap'])>=0 for x in nest['transitions'])
for n,h in data['source_hashes'].items():
 p=R/n
 if not p.is_file():p=C/n
 assert p.is_file() and sha(p)==h,n
sys.path[:0]=[str(R),str(C)]
from certify_sigma_extended_graph import geometry
from certify_ah_local_physical_support import local_budgets
from sharp_first_hit import first_budget
ns,src,_=geometry(C,[(F('.429'),F('.01250'))],sigma='1.54',far=F('.327'),negative=F('.372'),eps=F('.0165'));assert sha256(src.encode()).hexdigest()==G
ns['_first_orientation']=0;lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
w={(x['bin'],x['index']):x for x in raw['rows']};assert len(w)==375
allgroups=defaultdict(dict);excluded=[];placed=0;mins=[arb(1),arb(1)]
for t in data['rows']:
 o=t['orientation'];side=t['initial_derivative_sign'];counts=tuple(t['counts']);e=tuple(map(F,t['e_class']));r=t['row'];assert t['bin']==j and o in (0,1) and side in (-1,1) and t['positive']
 a,b=r['subcells'];assert 0<=a<b<=75;key=(counts,e);allgroups[o,side].setdefault(key,[]).append([a,b])
 if t.get('excluded',False):
  assert (o,side,counts,e)==(0,-1,(5,0,0,0),(F(3,4),F(1)))
  f,s=local_budgets(ns,lo+a*step,lo+b*step)[0];f0,s0=ns['two_hit_budgets'][j][0];f=first_budget(ns,lo+a*step,lo+b*step,min(f,f0));s=min(s,s0)
  assert str(f)==r['parent_first'] and str(s)==r['parent_second'] and s>f>0
  assert r['raw_sha256']==sha(S/'result.json') and r['audit_sha256']==sha(S/'audit.json') and r['excluded_cells']==list(range(a,b))
  for i in range(a,b):
   z=w[j,i];assert list(map(F,z['closed_w']))==[lo+i*step,lo+(i+1)*step]
   lev,=[x for x in z['levels'] if F(x['y4_max'])==F(3,8) and F(x['e_over_sharp_F_min'])==0]
   assert lev['positive'] and all(arb(x)>0 for x in lev['margins']) and arb(z['S_old'])>arb(z['F_sharp'])>0
   excluded.append(i)
 else:
  assert r['reference_bin']==j and r['anchor_comparison_sign']==side and F(r['anchor_degrees'])==0 and F(r['anchor_threshold'])==F(3,250)
  opts=cfg['low_brackets' if side==-1 else 'high_brackets'];assert list(map(F,r['bracket'])) in [list(map(F,x[:2])) for x in opts]
  assert all(type(v) is int and v>=0 for v in r['pose_counts'].values()) and r['placed_leaves']==sum(r['pose_counts'].values())
  for k,n in enumerate(('root_margin_lower','placement_margin_lower')):assert arb(r[n])>0;mins[k]=min(mins[k],arb(r[n]).lower())
  placed+=r['placed_leaves']
assert sorted(excluded)==list(range(75))
for o in (0,1):
 for side in (-1,1):
  expected={((k,5-k),(F(0),F(1))) for k in range(6)}
  if (o,side)==(0,-1):
   expected.remove(((5,0),(F(0),F(1))));expected.update(((5,0),(F(k,4),F(k+1,4))) for k in range(3));expected.update(((k,5-k,0,0),(F(3,4),F(1))) for k in range(6))
  actual=allgroups[o,side];assert set(actual)==expected
  parts=data['partitions'][f'{j},{o},{side}'];assert all(a<b for a,b in parts) and [i for a,b in parts for i in range(a,b)]==list(range(75)) and all(x==parts for x in actual.values())
out={'bin':j,'geometry_sha256':G,'closed_rows':len(data['rows']),'excluded_singletons':len(excluded),'physical_cells':75,'root_lower':str(mins[0]),'pose_lower':str(mins[1]),'placed_leaves':placed,'receipt_sha256':sha(R/f'join-j{j}.json'),'partner_audit_sha256':sha(S/'audit.json'),'nested_sha256':sha(D/'nested32-39.json')}
(Path(sys.argv[2]) if len(sys.argv)>2 else D/f'join-audit-{j}.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

"""Summarize conservative minima from a completed verify01250 scratch directory."""
from pathlib import Path
from flint import arb,ctx
import json,sys
ctx.prec=160;W=Path(sys.argv[1]);dst=Path(sys.argv[2]);load=lambda p:json.loads(p.read_bytes());G='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
cover=load(W/'cover-result.json');assert cover['complete'] and cover['geometry_sha256']==G and cover['bins']==70
x=load(W/'early/audit.json');assert x['geometry_sha256']==G and x['all_requested'];values=[(str(j),arb(v['root_lower']).lower(),arb(v['placement_lower']).lower()) for j,v in x['bins'].items()]
for j in range(32,35):
 x=load(W/f'audit-j{j}.json');assert x['all_passed'] and not x['failed'];values.append((str(j),arb(x['root_lower']).lower(),arb(x['pose_lower']).lower()))
for j in range(35,40):
 x=load(W/f'join-audit-{j}.json');assert x['geometry_sha256']==G and x['bin']==j and x['excluded_singletons']==75;values.append((str(j),arb(x['root_lower']).lower(),arb(x['pose_lower']).lower()))
t=load(W/'tail.json');assert t['geometry_sha256']==G and t['complete_tail']
for label,x in t['branches'].items():values.append(('tail-'+label,arb(x['root_lower']).lower(),arb(x['placement_lower']).lower()))
assert len(values)==42 and all(min(r,p)>0 for _,r,p in values)
r=min(values,key=lambda x:x[1]);p=min(values,key=lambda x:x[2]);out={'geometry_sha256':G,'global_root_lower':str(r[1]),'global_root_source':r[0],'global_pose_lower':str(p[2]),'global_pose_source':p[0],'early_closed_classes':6348,'middle_closed_classes':4207,'tail_physical_blocks':437,'tail_separately_verified_branches':2,'excluded_partner_singletons':375};dst.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

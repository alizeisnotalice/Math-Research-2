"""Close both zero-deficit and all-depth tail branches of the AH .01250 graph."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import inspect
import json
from pathlib import Path
import sys

from flint import arb
HERE=Path(__file__).resolve().parent
GEOMETRY='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
RETREAT=F('.00000009488')
BRACKETS=tuple((l,r) for l,r in (('.5','6.2'),('.5','6.15'),('.5','6.25'),
    ('.5','6.3'),('.5','6.10'),('.5','6.4'),('.5','6.0'),('.5','6.5'),
    ('.5','6.6'),('.5','6.8'),('.25','6.20'),('.25','7.0'),('.1','8.0')))
MARGINS=('root_margin_lower','placement_margin_lower')

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def load(a):
    sys.path[:0]=[str(HERE),str(a.comp.resolve())]
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach
    from certify_ah_local_physical_support import validate
    from ordered_state import support_bound
    cfg=read(HERE/'physical-0125.json')
    assert cfg==dict(sigma_degrees='1.54',line=['.429','.01250'],
        physical_parameters=['.327','.372','.0165'])
    p,d=map(F,cfg['line'])
    far,negative,eps=map(F,cfg['physical_parameters'])
    ns,src,_=geometry(a.comp.resolve(),[(p,d)],sigma=cfg['sigma_degrees'],
        far=far,negative=negative,eps=eps)
    assert sha256(src.encode()).hexdigest()==GEOMETRY
    assert F(ns['eh_depth'])==F('.000555')
    assert ns['cuts'][-1]==(p,d)
    assert all(0<x<p and 0<y<d for x,y in ns['cuts'][:-1])
    area=read(HERE/'area-0125.json')
    assert area['parameters']==cfg and area['chart']['geometry_sha256']==GEOMETRY
    # The EH retreat belongs to the original transfer. Verify its own true
    # rational cost instead of inheriting a numerical offset.
    eh=a.main_comp/'sigma154-ah429-eh-chain997-composition.json'
    assert digest(eh)=='d7a2c66a83d64f0afd64ea89ebee6e4ad6c4f1bde292eae286249d00ef8b12ee'
    assert read(eh)['sigma']=='1.54'
    cost=F(read(eh)['transfer_cost']['exact'][1])
    assert 0<cost<RETREAT
    return ns,cfg,reach,validate,support_bound,eh,cost

def partner_rows(ns,path):
    r=read(path)
    assert r['geometry_sha256']==GEOMETRY and r['physical_parameters']==read(HERE/'physical-0125.json')
    assert r['verifier_sha256']==digest(HERE/'certify_zero_ordered_budget.py')
    assert r['cut_rows']==[f'AH-line:{j}'for j in range(4)]
    assert r['scope']==dict(bins=list(range(40,70)),orientation=0,max_y='1',e_low='0',e_high='1')
    witnessed={}
    for row in r['cases']:
        j,i=row['j'],row['i']
        assert 40<=j<70 and 0<=i<75 and (j,i) not in witnessed
        a,b=ns['knots'][j:j+2]
        step=(b-a)/75
        assert row['w']==[str(a+k*step)for k in (i,i+1)]
        vals=[arb(x)for x in row['all_AH_slacks']]
        assert len(vals)==4 and row['positive']==all(x>0 for x in vals)
        witnessed[(j,i)]=min(vals)
    assert len(witnessed)==2250 and r['complete']
    return witnessed

def build(ns,validate,support):
    code=inspect.getsource(support)
    mark="    first,second=n['two_hit_budgets'][j][ori]\n"
    assert code.count(mark)==1
    code=code.replace(mark,mark+"    assert ori==0\n    second=zero\n")
    ev=dict(support.__globals__)
    exec(compile(code,'ah01250_true_zero_partner','exec'),ev)
    kernel=ev['support_bound']
    sel,=[i for i,(name,_,_)in enumerate(ns['rows']) if name.startswith('U1-Te')]
    name,n,h=ns['rows'][sel]
    ns['rows'][sel]=name,n,h-ns['A'](RETREAT)
    ns.update(_sharpen_jets=True,_tighten_first=True,_first_orientation=0,_class_counts=(5,))
    def block_support(state,j,a,b):
        lo,hi=state['knots'][j:j+2]
        k,l=state['_physical_block']
        step=(hi-lo)/75
        assert a==lo+step*k and b==a+step and k<l
        return kernel(state,j,a,lo+step*l)
    ev={**validate.__globals__,'support_bound':block_support}
    exec(compile(inspect.getsource(validate),'ah01250_pinned_root','exec'),ev)
    return ev['validate'],sha256(code.encode()).hexdigest()

def run(a):
    assert 40<=a.start<=a.finish<=69 and __debug__
    ns,cfg,reach,validate,support,eh,cost=load(a)
    partner=partner_rows(ns,a.partner)
    direct,code_sha=build(ns,validate,support)
    out=[]
    def trial(j,lo,hi,level,brackets,depth):
        ns['_physical_block']=lo,hi
        ns['_e_class']=level
        best=None;best_score=None
        for left,right in brackets:
            row=direct(ns,j,F(left),F(right),0,1,-1,begin=lo,end=lo+1,angular=12,depth=depth)
            row['physical_block']=[lo,hi]
            root,pose=[arb(row[k])for k in MARGINS]
            score=min(root,pose)
            if best_score is None or score>best_score:
                best_score,best=score,row
            if root>0 and pose>0 and row['placed_leaves']>0:
                assert row['placed_leaves']==sum(row['verified_dihedral_pose_counts'].values())
                return True,row
        return False,best
    def visit(j,lo,hi):
        retained=all(partner[j,i]>0 for i in range(lo,hi))
        if not retained and hi-lo>1:
            mid=(lo+hi)//2
            return visit(j,lo,mid)+visit(j,mid,hi)
        # Explicit strict root existence and a single full pose on each
        # possible closed angular leaf at e=0, even if the positive class remains open.
        zero,rz=trial(j,lo,hi,(F(0),F(0)),BRACKETS,5)
        if retained:
            favored=tuple(str(F(q)) for q in rz['bracket'])
            choices=[favored]+[x for x in BRACKETS if tuple(map(F,x))!=tuple(map(F,favored))]
            positive,rp=trial(j,lo,hi,(F(0),F(1)),choices,4)
        else:
            positive,rp=False,None
        if (not zero or not positive) and hi-lo>1:
            mid=(lo+hi)//2
            return visit(j,lo,mid)+visit(j,mid,hi)
        return [dict(block=[lo,hi],partner_retained=retained,zero_pass=zero,zero=rz,
            all_e_pass=positive,all_e=rp)]
    for j in range(a.start,a.finish+1):
        ranges=reach(ns,j)
        assert ranges
        assert ns['labelled_deficits'][1][j].is_zero(),(j,ns['labelled_deficits'][1][j])
        tests=[row for x,y in ranges for i in range(x,y,5) for row in visit(j,i,min(i+5,y))]
        assert [k for row in tests for k in range(*row['block'])]==[i for x,y in ranges for i in range(x,y)]
        out.append(dict(j=j,reach=ranges,cells=sum(y-x for x,y in ranges),rows=tests))
        print(j,ranges,len(tests),sum(x['zero_pass'] for x in tests),sum(x['all_e_pass']for x in tests),
            'holdout',[x['block'] for x in tests if not(x['zero_pass'] and x['all_e_pass'])],flush=True)
    a.out.write_text(json.dumps(dict(geometry_sha256=GEOMETRY,params=cfg,EH_retreat=str(RETREAT),
        EH_cost_upper=str(cost),EH_source_sha256=digest(eh),coverage=out,
        source_sha256={p.name:digest(p)for p in (Path(__file__),HERE/'ordered_state.py',HERE/'sharp_first_hit.py',
            HERE/'certify_zero_ordered_budget.py',HERE/'physical-0125.json',HERE/'area-0125.json',a.partner)},
        zero_partner_kernel_sha256=code_sha,
        all_zero=all(x['zero_pass'] for j in out for x in j['rows']),
        all_depths=all(x['all_e_pass'] for j in out for x in j['rows'])),indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('comp','main_comp','partner','out'):
        p.add_argument(n,type=Path)
    p.add_argument('start',type=int)
    p.add_argument('finish',type=int)
    run(p.parse_args())

"""Independent three-vertex checks of two true partners and the closed chart tubes."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

from flint import arb
HERE=Path(__file__).resolve().parent

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def run(a):
    sys.path[:0]=[str(HERE),str(a.comp.resolve())]
    from certify_ah_local_physical_support import local_budgets
    from certify_ah_single_contact_chain import local_slope
    from certify_sigma_extended_graph import geometry
    from certify_sigma_reachable_roots import reach
    from sharp_first_hit import first_budget
    ph=HERE/'physical-0125.json'
    p=read(ph)
    pivot,turn=map(F,p['line'])
    params=dict(zip(('far','negative','eps'),map(F,p['physical_parameters']),strict=True))
    ns,src,_=geometry(a.comp.resolve(),[(pivot,turn)],sigma=p['sigma_degrees'],**params)
    true_graph=sha256(src.encode()).hexdigest()
    area=read(HERE/'area-0125.json')
    assert p==area['parameters'] and true_graph==area['chart']['geometry_sha256']
    A,add,sub,scale,dot,cross,ref=(ns[k] for k in ('A','add','sub','mul','dot','cross','reflection'))
    z=A(0)
    zero=lambda x: all(d.contains(0) for d in x)
    cuts=[(name,n,h)for name,n,h in ns['rows'] if name.startswith('AH-line:')]
    assert len(cuts)==4 and ns['cuts'][-1]==(pivot,turn) and len(ns['cuts'])==len(cuts)
    for (_,n,h),anchor,edge in zip(cuts,ns['pivot_set'],ns['cut_dirs'],strict=True):
        assert zero(sub(n,scale(-1,ns['perp'](edge)))) and (h-dot(n,anchor)).contains(0)
        assert dot(n,n).contains(1)
    assert all(q<pivot and d<turn and q>0 and d>0 for q,d in ns['cuts'][:-1])
    tris=[(0,0),(0,1),(1,1)]
    def transversality(l,t):
        X,L,N=ns['chart_bounds'](l,t)
        c=sub(N,L)
        sq=dot(c,c)
        ch=-cross(sub(X,L),sub(X,N))
        assert 0<sq<4 and ch>0,(l,t,sq,ch)
        return sq.lower(),sq.upper(),ch.lower()
    results=[]
    for j in range(40,70):
        lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
        ranges=reach(ns,j)
        assert [list(q) for q in ranges]==area['chart']['reference_ranges'][str(j)]
        assert ns['labelled_deficits'][1][j].is_zero()
        r={'j':j,'reach':ranges}
        front_lo=mate_lo=A(4);front_hi=mate_hi=A(0)
        front_cross=mate_cross=A(4)
        bests=[A(1)]*4
        zero_bests=[A(1)]*4
        for i in range(75):
            w0,w1=lo+i*step,lo+(i+1)*step
            f,s=local_budgets(ns,w0,w1)[0]
            F0,S0=ns['two_hit_budgets'][j][0]
            f=first_budget(ns,w0,w1,min(f,F0))
            s=min(s,S0);u=s.min(f)
            segments=[ns['chart'](add(ns['z'],scale(A(w),ns['D'])))for w in (w0,w1)]
            ell,t=[x.union(y)for x,y in zip(*segments,strict=True)]
            lp=ns['coord_hull'](ns['psi'],ell)
            m=local_slope(ns,lp,ns['deficit_by_bin'][j])
            assert m>3
            xi=(-(f+u)/m).union(z)
            C=(-u).union(f)
            q=ref(ns['centered_points'](w0,w1)[2])
            assert all(x.overlaps(y)for x,y in zip(q,ns['X'](lp,-t),strict=True))
            assert zero(sub(q,ref(ref(q))))
            fl,fu,fc=transversality(ell,t+(-f).union(z))
            pl,pu,pc=transversality(lp+xi,-t+C)
            front_lo=min(front_lo,fl);front_hi=max(front_hi,fu);front_cross=min(front_cross,fc)
            mate_lo=min(mate_lo,pl);mate_hi=max(mate_hi,pu);mate_cross=min(mate_cross,pc)
            point,L,N=ns['chart_bounds'](lp+xi,-t+C)
            dx,dy=ns['derivs'](point,L,N)
            for k,(_,n,h) in enumerate(cuts):
                along,vertical=dot(n,dx)/m,dot(n,dy)
                nominal=h-dot(n,q)
                ranges_l=[along*(e+v)*y3-vertical*((e+v)*y4-v)
                        for e,v in ((z,z),(u,u),(f,u))for y3,y4 in tris]
                margin=(nominal+min(x.lower()for x in ranges_l)).lower()
                assert nominal>0 and margin>0,(j,i,k,nominal,margin)
                bests[k]=min(bests[k],margin)
                zero_bests[k]=min(zero_bests[k],nominal.lower())
        r['positivity_of_partner_cut_retention']=list(map(str,bests))
        r['ideal_partner_cut_clearance']=list(map(str,zero_bests))
        r['physical_first_partner_circles']={'separation_sq':list(map(str,(front_lo,front_hi))),'selected_det_lower':str(front_cross)}
        r['physical_second_partner_circles']={'separation_sq':list(map(str,(mate_lo,mate_hi))),'selected_det_lower':str(mate_cross)}
        r['positive_orientation_1_empty']=True
        results.append(r)
        print(j,ranges,min(bests),front_cross,mate_cross,flush=True)
    count=sum(y-x for r in results for x,y in r['reach'])
    assert count==2183
    out=dict(geometry_sha256=true_graph,physical_subcells=count,closed_transversal_tubes=75*len(results),
        triangles=tris,checked_physical_partners_per_box=2,all_rows=results,
        input_sha256={p.name:digest(p)for p in (ph,HERE/'area-0125.json',HERE/'sharp_first_hit.py')},
        verifier_sha256=digest(Path(__file__)))
    a.out.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('comp',type=Path)
    p.add_argument('out',type=Path)
    run(p.parse_args())

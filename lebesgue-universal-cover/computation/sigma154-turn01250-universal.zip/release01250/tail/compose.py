"""Validate the full AH .01250 tail and bind the cut, reach and EH sources."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from flint import arb,ctx

HERE=Path(__file__).resolve().parent
RANGES=((40,46),(47,53),(54,61),(62,69))
GEOM='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
NAMES=('root_margin_lower','placement_margin_lower')
POSES={f'{t},{s}'for t in range(0,360,60)for s in (-1,1)}

def read(p):
    return json.loads(p.read_bytes())

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def main(a):
    ctx.prec=128
    geom=a.work.resolve()
    physical=read(HERE/'physical-0125.json')
    area=read(HERE/'area-0125.json')
    assert area['chart']['geometry_sha256']==GEOM and area['parameters']==physical
    cases=[q for q in area['geometry']['cases'] if q['label']=='eleven']
    assert len(cases)==1
    area11=cases[0]
    p=a.main_comp/'sigma154-ah429-eh-chain997-composition.json'
    assert sha(p)==area['geometry']['EH_first'][p.name]
    cost=F(read(p)['transfer_cost']['exact'][1])
    assert cost==F(area11['transfer_cost_upper'])
    retreat=F('.00000009488')
    assert 0<cost<retreat
    names=('audit-triangle-01250.json','partner-all-01250.json')
    x,y=[read(geom/n) for n in names]
    assert x['geometry_sha256']==y['geometry_sha256']==GEOM
    assert x['verifier_sha256']==sha(HERE/'audit_triangle.py')
    assert y['verifier_sha256']==sha(HERE/'certify_zero_ordered_budget.py')
    assert x['closed_transversal_tubes']==2250 and x['checked_physical_partners_per_box']==2
    assert x['physical_subcells']==2183
    assert x['triangles']==[[0,0],[0,1],[1,1]]
    assert y['complete'] and y['all_second_positive_deficits_impossible'] and y['physical_parameters']==physical
    assert [(q['j'],q['i'])for q in y['cases']]==[(j,i)for j in range(40,70)for i in range(75)]
    assert all(q['positive'] and len(q['all_AH_slacks'])==4 for q in y['cases'])
    min_partner_cut=min(arb(v).lower()for q in y['cases']for v in q['all_AH_slacks'])
    assert min_partner_cut>arb('0.0000020957469209865')
    face_min=min(arb(v).lower()for q in x['all_rows']for v in q['positivity_of_partner_cut_retention'])
    zero_cut_min=min(arb(v).lower()for q in x['all_rows']for v in q['ideal_partner_cut_clearance'])
    assert face_min>0 and zero_cut_min>0
    assert [row['j']for row in x['all_rows']]==list(range(40,70))
    graph_specs=('physical_first_partner_circles','physical_second_partner_circles')
    pair_stats={}
    for key in graph_specs:
        lo=min(arb(row[key]['separation_sq'][0]).lower()for row in x['all_rows'])
        hi=max(arb(row[key]['separation_sq'][1]).upper()for row in x['all_rows'])
        det=min(arb(row[key]['selected_det_lower']).lower()for row in x['all_rows'])
        assert 0<lo<=hi<4 and det>0
        pair_stats[key]=dict(circles_squared_distance=[str(lo),str(hi)],selected_det_lower=str(det))
    source={}
    per_bin=[]
    tested={'zero':[],'all_e':[]}
    ks=set()
    for start,stop in RANGES:
        f=geom/f'tail-{start}-{stop}.json'
        raw=read(f)
        assert raw['geometry_sha256']==GEOM and raw['params']==physical
        assert raw['all_zero'] and raw['all_depths']
        assert F(raw['EH_retreat'])==retreat and F(raw['EH_cost_upper'])==cost
        assert raw['EH_source_sha256']==sha(p)
        assert [z['j']for z in raw['coverage']]==list(range(start,stop+1))
        ks.add(raw['zero_partner_kernel_sha256'])
        for n,h in raw['source_sha256'].items():
            loc=geom if n=='partner-all-01250.json' else HERE
            assert sha(loc/n)==h,(f,n)
        source[f.name]=sha(f)
        for j in raw['coverage']:
            index=j['j']
            n=8 if index==69 else 75
            assert j['reach']==[[0,n]]==area['chart']['reference_ranges'][str(index)]
            assert x['all_rows'][index-40]['positive_orientation_1_empty']
            assert j['cells']==n
            coverage=[]
            for row in j['rows']:
                lo,hi=row['block']
                assert row['partner_retained'] and row['zero_pass'] and row['all_e_pass']
                assert 0<=lo<hi<=n
                coverage.extend(range(lo,hi))
                for name,pool in tested.items():
                    v=row[name]
                    assert v['physical_block']==[lo,hi] and v['subcells']==[lo,lo+1]
                    assert v['reference_bin']==index
                    assert all(arb(v[k])>0 for k in NAMES)
                    assert set(v['verified_dihedral_pose_counts'])<=POSES
                    assert 0<v['placed_leaves']==sum(v['verified_dihedral_pose_counts'].values())
                    assert v['placed_leaves']+v['root_free_leaves']==12
                    pool.append(v)
            assert coverage==list(range(n))
            per_bin.append(dict(j=index,reachable=j['reach'],cells=n,blocks=len(j['rows'])))
    assert len(ks)==1
    assert [r['j']for r in per_bin]==list(range(40,70))
    assert sum(r['cells']for r in per_bin)==2183
    assert sum(r['blocks']for r in per_bin)==437
    bounds={}
    for k,rows in tested.items():
        bounds[k]=dict(root_lower=str(min(arb(q[NAMES[0]]).lower()for q in rows)),
            placement_lower=str(min(arb(q[NAMES[1]]).lower()for q in rows)),
            placed_leaves=sum(q['placed_leaves']for q in rows),root_free_leaves=sum(q['root_free_leaves']for q in rows))
    out=dict(complete_tail=True,only_bins=list(range(40,70)),physical=physical,geometry_sha256=GEOM,
        physical_subcells=2183,blocks=437,positive_orientation_1_empty=True,positive_second_partner_empty=True,
        independent_zero_root_and_pose=True,all_depths_root_and_pose=True,coverage=per_bin,branches=bounds,
        ordered_partner_margin=str(min_partner_cut),independent_triangle_margin=str(face_min),ideal_partner_margin=str(zero_cut_min),
        circles=pair_stats,EH_area_case=area11['area'],EH_retreat=str(retreat),EH_cost_upper=str(cost),
        sources={**source,**{n:sha(geom/n)for n in names},'area-0125.json':sha(HERE/'area-0125.json'),
            'physical-0125.json':sha(HERE/'physical-0125.json'),p.name:sha(p)})
    a.out.write_text(json.dumps(out,indent=2)+'\n')
    print('tail',out['physical_subcells'],out['blocks'],bounds,'partner',min_partner_cut,face_min,zero_cut_min,flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for n in ('main_comp','work','out'):
        p.add_argument(n,type=Path)
    main(p.parse_args())

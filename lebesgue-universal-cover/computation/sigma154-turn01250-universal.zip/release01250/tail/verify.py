"""Rebuild all triangular, root and EH-transfer receipts in an isolated folder."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
RANGES=((40,46),(47,53),(54,61),(62,69))

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def main(a):
    graph,main,out=(p.resolve()for p in (a.graph,a.main,a.out))
    assert out!=HERE and not graph==out
    out.mkdir(exist_ok=True)
    names=json.loads((HERE/'graph-inputs.json').read_bytes())
    for name,want in names.items():
        assert digest(graph/name)==want,name
    environ=dict(os.environ,OPENBLAS_NUM_THREADS='1')
    def run(script,*args):
        child=subprocess.run([sys.executable,'-I','-B',str(HERE/script),*map(str,args)],check=True,
            cwd=HERE,env=environ,text=True,capture_output=True)
        print(child.stdout,end='',flush=True)
    partner=out/'partner-all-01250.json'
    audit=out/'audit-triangle-01250.json'
    with ThreadPoolExecutor(max_workers=4) as pool:
        p=pool.submit(run,'certify_zero_ordered_budget.py',graph,HERE/'physical-0125.json',partner,*range(40,70))
        q=pool.submit(run,'audit_triangle.py',graph,audit)
        p.result()
        tail=[out/f'tail-{s}-{t}.json' for s,t in RANGES]
        runs=[pool.submit(run,'certify_tail.py',graph,main,partner,f,s,t)
              for f,(s,t) in zip(tail,RANGES,strict=True)]
        q.result()
        for p in runs:
            p.result()
    summary=out/'tail-summary.json'
    run('compose.py',main,out,summary)
    for check in [partner,audit,*tail,summary]:
        assert check.read_bytes()==(HERE/check.name).read_bytes(),check.name
    print('fresh true-partner and complete tail receipts verified',flush=True)

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for n in ('graph','main','out'):
        parser.add_argument(n,type=Path)
    main(parser.parse_args())

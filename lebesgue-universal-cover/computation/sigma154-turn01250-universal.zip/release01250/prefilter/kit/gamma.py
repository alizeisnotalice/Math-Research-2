from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json, sys
root=Path(__file__).resolve().parent;comp=root/'comp012'
sys.path.insert(0,str(comp))
from certify_sigma_extended_graph import geometry
from flint import arb
tag=sys.argv[1];p=json.loads((root/f'physical-{tag}.json').read_bytes())
n,src,_=geometry(comp,[tuple(map(Q,p['line']))],sigma=p['sigma_degrees'],**dict(zip(('far','negative','eps'),map(Q,p['physical_parameters']))))
cross=n['cross'];sub=n['sub'];A=n['A']
direc=n['cut_dirs'][-1];hinge=n['pivot_set'][-1]
at_zero=cross(direc,sub(n['z'],hinge));at_far=cross(direc,sub(n['q'](n['wf']),hinge))
labels=n['arc_signs'];m=min(v for _,v in n['_contact_chain_slopes'])
assert at_zero<0 and at_far>0 and m>3 and len(labels)==5 and all(arb(v)>0 for v in labels.values())
res=dict(physical=p,geometry_sha256=sha256(src.encode()).hexdigest(),verifier_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),paired_curve_origin_inside_cut=str((-at_zero).lower()),paired_curve_far_retained=str(at_far.lower()),paired_graph_decreasing_slope_magnitude_lower=str(m),retained_sprague_arc_endpoint_signs=labels)
(root/f'gamma-{tag}.json').write_text(json.dumps(res,indent=2)+'\n')

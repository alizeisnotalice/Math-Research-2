"""Verify chart, true area, topology, and the same-physical-block contact partitions used in the screening study."""
import argparse,hashlib,json
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx
ctx.prec=128
p=argparse.ArgumentParser()
p.add_argument('out',type=Path)
a=p.parse_args();base=Path(__file__).resolve().parent
def read(name):return json.loads((base/name).read_bytes())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
out={}
for tag in ['0122','0125']:
    physical=read(f'physical-{tag}.json');geom=read(f'area-{tag}.json');gamma=read(f'gamma-{tag}.json');screen=read(f'screen-{tag}.json')
    assert geom['parameters']==gamma['physical']==screen['physical']==physical
    assert geom['config_sha256']==sha(base/f'physical-{tag}.json') and geom['source_sha256']==sha(base/'comp012/certify_sigma154_deeper_composition.py')
    chart=geom['chart'];finger=chart['geometry_sha256']
    assert finger==gamma['geometry_sha256']==screen['geometry_sha256']
    assert geom['placement'] is None and chart['reference_subcells']==5183 and len(chart['reference_ranges'])==70
    assert Q(chart['reference_endpoint'])==Q(43,100) and Q(chart['physical_graph_endpoint'])==Q(13,25)
    def lower(box):return Q(box['exact'][0])
    for name in ['reference_gap','negative_projection_room','first_hit_y_above_518','first_hit_squared_distance_to_C_above_1']:
        assert lower(chart[name])>0
    assert len(gamma['retained_sprague_arc_endpoint_signs'])==5 and all(arb(v)>0 for v in gamma['retained_sprague_arc_endpoint_signs'].values())
    assert arb(gamma['paired_graph_decreasing_slope_magnitude_lower'])>3 and arb(gamma['paired_curve_origin_inside_cut'])>0 and arb(gamma['paired_curve_far_retained'])>0
    assert Q(geom['geometry']['AH_crossing_derivative_lower'])>0
    lo,hi=map(Q,geom['geometry']['AH_curve_crossing']['exact']);assert 0<lo<hi<Q(physical['physical_parameters'][0])
    eh=next(x for x in geom['geometry']['cases'] if x['label']=='eleven')
    assert lower(eh['AH_EH_clearance'])>0 and Q(eh['transfer_cost_upper'])<Q('.00000009488')
    b0,b1=map(Q,geom['geometry']['base']['exact']);c0,c1=map(Q,geom['geometry']['AH_cut']['exact']);d0,d1=map(Q,eh['EH_cut']['exact'])
    assert list(map(Q,eh['area']['exact']))==[b0-c1-d1,b1-c0-d0]
    bins={}
    for j in [26,31]:
        d=read(f'full-{tag}-{j}.json');assert d['complete'] and d['physical_parameters']==physical and d['geometry_sha256']==finger
        assert d['parameters']==read(f'config-{tag}-{j}.json') and Q(d['parameters']['cut'])==-Q(3,250) and d['EH_tightening']==dict(label='U1-Te-0',retreat='593/6250000000')
        for f,h in d['source_hashes'].items():
            source=base/f
            if not source.is_file():source=base/'comp012'/f
            assert sha(source)==h,f
        assert d['reachable']=={str(j):[[0,75]]} and d['synchronized'] and d['tighten_first']
        grouped={};rm=pm=arb(1);nm=nf=ne=bad=0
        for t in d['rows']:
            ori=t['orientation'];side=t['initial_derivative_sign'];r=t['row'];assert t['bin']==r['reference_bin']==j
            assert r['anchor_degrees']=='0' and r['anchor_comparison_sign']==side and Q(r['anchor_threshold'])==Q(3,250)
            assert r['placed_leaves']==sum(r['pose_counts'].values())
            assert t['positive']==bool(arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0)
            rm=min(rm,arb(r['root_margin_lower']).lower());pm=min(pm,arb(r['placement_margin_lower']).lower())
            nm+=r['placed_leaves'];nf+=r['root_free_leaves'];ne+=r['empty_conditional_subcells'];bad+=not t['positive']
            key=tuple(t['counts']),tuple(map(Q,t.get('e_class',[0,1])))
            grouped.setdefault((ori,side),{}).setdefault(key,[]).append(r['subcells'])
        for ori in [0,1]:
            for side in [-1,1]:
                g=grouped[ori,side]
                plan={((k,5-k),(Q(0),Q(1))) for k in range(6)}
                if tag=='0125' and j==31 and ori==0 and side==-1:
                    plan.remove(((5,0),(Q(0),Q(1))))
                    plan.update(((5,0),(Q(k,4),Q(k+1,4))) for k in range(3))
                    plan.update(((k,5-k,0,0),(Q(3,4),Q(1))) for k in range(6))
                assert set(g)==plan
                parts=d['partitions'][f'{j},{ori},{side}'];assert [i for l,r in parts for i in range(l,r)]==list(range(75))
                assert all(l<r for l,r in parts) and all(v==parts for v in g.values())
        assert d['all_passed']==(bad==0)
        bins[str(j)]=dict(rows=len(d['rows']),failed_rows=bad,root_lower=str(rm),placement_lower=str(pm),placed_leaves=nm,root_free_leaves=nf,empty_conditional_rows=ne,sha256=sha(base/f'full-{tag}-{j}.json'))
    out[tag]=dict(geometry_sha256=finger,reference_cells=chart['reference_subcells'],area=eh['area']['decimal'],
                  screened=sum(t['positive'] for t in screen['rows']),screen_count=len(screen['rows']),bins=bins)
    if tag=='0125':
        tail={}
        for fname,source in [('zero-0125-boundary.json','certify_zero_ordered_budget.py'),('zero-0125-tail-singles.json','certify_zero_second_budget.py')]:
            z=read('tail-scout/'+fname)
            assert z['complete'] and z['geometry_sha256']==finger and z['physical_parameters']==physical and z['verifier_sha256']==sha(base/'tail-scout'/source)
            assert z['scope']['orientation']==0 and z['scope']['max_y']=='1' and len(z['cut_rows'])==4
            cells={}
            for b in z['scope']['bins']:
                group=[r for r in z['cases'] if r['j']==b]
                assert [r['i'] for r in group]==list(range(75))
                assert all(len(r['all_AH_slacks'])==4 and r['positive']==all(arb(v)>0 for v in r['all_AH_slacks']) for r in group)
                cells[str(b)]={'positive':sum(r['positive'] for r in group),'total':len(group),'margin':str(min(arb(v).lower() for r in group for v in r['all_AH_slacks']))}
            tail[source]=cells
        out[tag]['partner_retention']=tail
a.out.write_text(json.dumps(out,indent=2)+'\n')

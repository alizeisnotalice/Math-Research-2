"""Replay area and selected placement checks into a scratch directory."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,shutil
p=argparse.ArgumentParser()
p.add_argument('scratch',type=Path)
p.add_argument('--full',action='store_true')
a=p.parse_args();here=Path(__file__).resolve().parent
out=a.scratch.resolve();out.mkdir(exist_ok=True,parents=True);comp=here/'comp012'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def run(argv,log=None):
    if log is None:subprocess.run([sys.executable,'-I','-B',*map(str,argv)],cwd=here,check=True)
    else:
        with log.open('w') as h:subprocess.run([sys.executable,'-I','-B',*map(str,argv)],cwd=here,stdout=h,check=True)
def equal(got,want):
    result=json.loads(got.read_bytes());expected=json.loads(want.read_bytes())
    if isinstance(result,dict) and 'python' in result:result['python']=expected['python']
    assert result==expected,want
for f,h in json.loads((here/'manifest.json').read_bytes()).items():assert sha(here/f)==h,f
if a.full:
    for name in ['screen.py','screen-rows.json','gamma.py','ordered_state.py','ordered_derivative.py','sharp_first_hit.py','physical-0122.json','physical-0125.json']:
        shutil.copyfile(here/name,out/name)
    shutil.copytree(comp,out/'comp012',dirs_exist_ok=True)
    for tag in ['0122','0125']:
        for module in ['screen','gamma']:
            run([out/(module+'.py'),tag],out/(module+'-'+tag+'.log'))
            equal(out/f'{module}-{tag}.json',here/f'{module}-{tag}.json')

        area=f'area-{tag}.json'
        run([comp/'certify_sigma154_deeper_composition.py',comp,here/f'physical-{tag}.json','--eh',comp],out/area)
        equal(out/area,here/area)
        for j in [26,31]:
            name=f'full-{tag}-{j}.json'
            kernel='certify_refined31.py' if tag=='0125' and j==31 else 'certify_j31_sharp.py'
            run([here/kernel,comp,here/f'config-{tag}-{j}.json',out/name],out/f'log-{tag}-{j}.txt')
            equal(out/name,here/name)
    tail=here/'tail-scout'
    for kernel,file,bins in [('certify_zero_ordered_budget.py','zero-0125-boundary.json',[39,40,41]),('certify_zero_second_budget.py','zero-0125-tail-singles.json',[40,46,49,50,68])]:
        run([tail/kernel,comp,here/'physical-0125.json',out/file,*bins])
        equal(out/file,tail/file)
run([here/'audit.py',out/'audit.json'])
equal(out/'audit.json',here/'audit.json')
print('Verified geometry, true areas, and selected contact partitions.')

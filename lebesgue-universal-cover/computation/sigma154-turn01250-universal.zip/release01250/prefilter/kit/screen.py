"""Replay complete angular brackets on cells that minimized root or placement at depth .01200."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json,sys
root=Path(__file__).resolve().parent; comp=(root/'comp012').resolve()
sys.path[:0]=[str(root),str(comp)]
from flint import arb
from ordered_derivative import validate
from certify_sigma_extended_graph import geometry
def sha(f):return sha256(f.read_bytes()).hexdigest()
tag=sys.argv[1]
cfg=json.loads((root/f'physical-{tag}.json').read_bytes());p,d=map(F,cfg['line'])
n,src,_=geometry(comp,[(p,d)],sigma=cfg['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,cfg['physical_parameters']))))
n['_sharpen_jets']=True;n['_tighten_first']=True
index,=[k for k,(l,_,_) in enumerate(n['rows']) if l.startswith('U1-Te')]
label,u,h=n['rows'][index]
assert F(n['eh_depth'])==F('.000555')
n['rows'][index]=label,u,h-n['A'](F('.00000009488'))
tests=json.loads((root/'screen-rows.json').read_bytes())
out=[]
for key,grp in tests.items():
 j=int(key)
 for ori,side,counts,(a,b),bracket in grp['selected']:
  n['_first_orientation']=ori;n['_class_counts']=tuple(counts);n['_end_index']=b
  trial=[]
  for l,r in [bracket]+([['.5','6.4'],['.5','6.6'],['.5','7']] if side<0 else [['6.4','18'],['6','18'],['6.25','19']]):
   k,s=(0,1) if side<0 else (120,-1)
   row=validate(n,j,F(l),F(r),k,s,side,cut=F('-.012'),side=side,begin=a,end=a+1,angular=12,depth=4)
   row['subcells']=[a,b]; rm,pm=(arb(row[x]) for x in ['root_margin_lower','placement_margin_lower'])
   positive=bool(rm>0 and pm>0);trial.append(row)
   if positive:break
  out.append(dict(j=j,ori=ori,side=side,counts=counts,physical=[a,b],positive=positive,trials=trial))
  print(j,ori,side,counts,a,b,positive,str(rm),str(pm),flush=True)
result=dict(complete=True,all_selected_pass=all(x['positive'] for x in out),physical=cfg,geometry_sha256=sha256(src.encode()).hexdigest(),sources={f:sha(root/f) for f in ['screen.py','screen-rows.json','ordered_state.py','ordered_derivative.py','sharp_first_hit.py']},rows=out)
(root/f'screen-{tag}.json').write_text(json.dumps(result,indent=2)+'\n')

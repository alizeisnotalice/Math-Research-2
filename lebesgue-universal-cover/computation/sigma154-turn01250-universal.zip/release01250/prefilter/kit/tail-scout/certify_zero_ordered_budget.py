"""Check the entire physical partner support tube against every added AH cut."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from argparse import ArgumentParser
import json,sys,inspect
HERE=Path(__file__).resolve().parent

def run(comp,phys,bins,output):
    sys.path[:0]=[str(HERE),str(comp)]
    from certify_sigma_extended_graph import geometry
    from certify_ah_local_physical_support import local_budgets
    from certify_ah_single_contact_chain import local_slope
    from sharp_first_hit import first_budget
    from flint import arb
    par=json.loads(phys.read_bytes());pv,turn=map(F,par['line']);far,neg,eps=map(F,par['physical_parameters'])
    ns,src,_=geometry(comp,[(pv,turn)],sigma=par['sigma_degrees'],far=far,negative=neg,eps=eps)
    A,sub,add,mul,dot,ref,box=(ns[k] for k in ('A','sub','add','mul','dot','reflection','box'))
    cuts=[r for r in ns['rows'] if r[0].startswith('AH-line:')]
    assert len(cuts)==len(ns['cuts']) and len(cuts)==4
    assert all(ns['norm'](sub(n,mul(-1,ns['perp'](d)))).contains(0) and (off-dot(n,p)).contains(0) for (_,n,off),p,d in zip(cuts,ns['pivot_set'],ns['cut_dirs'],strict=True))
    rows=[]
    for j in bins:
        lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
        for i in range(75):
            a=lo+i*step;b=a+step;mid=(a+b)/2
            f,s=local_budgets(ns,a,b)[0]
            f0,s0=ns['two_hit_budgets'][j][0]
            f=first_budget(ns,a,b,min(f,f0));s=min(s,s0)
            v0=ns['centered_points'](a,b);q=ref(v0[2])
            ell,t=tuple(z.union(zz) for z,zz in zip(*[ns['chart'](add(ns['z'],mul(A(x),ns['D']))) for x in (a,b)],strict=True))
            lp=ns['coord_hull'](ns['psi'],ell)
            m=local_slope(ns,lp,ns['deficit_by_bin'][j])
            u=s.min(f)
            C=(-u).union(f)
            xi=(-(f+u)/m).union(A(0))
            # Every positive-deficit hit lies in the closure of a new AH halfplane cap.
            xx,L,N=ns['chart_bounds'](lp+xi.union(A(0)),-t+C.union(A(0)))
            xl,xt=ns['derivs'](xx,L,N)
            margins=[]
            for name,n,h in cuts:
                # The two first-order terms use a mean-value derivative enclosure
                # along the full segment between the ideal and the actual partner.
                along=dot(n,xl)/m
                vertical=dot(n,xt)
                corners=[A(0),vertical*u,-vertical*f,-vertical*u,(2*along-vertical)*u,(along-vertical)*f+along*u]
                margins.append((h-dot(n,q)+min(c.lower() for c in corners)).lower())
            rows.append(dict(j=j,i=i,w=[str(a),str(b)],first=str(f),second=str(s),m=str(m),
                C=str(C),all_AH_slacks=[str(d) for d in margins],positive=bool(min(margins)>0)))
    yes=sum(x['positive'] for x in rows)
    result=dict(complete=True,all_second_positive_deficits_impossible=yes==len(rows),cases=rows,cut_rows=[x[0] for x in cuts],
        scope=dict(bins=bins,orientation=0,max_y='1',e_low='0',e_high='1'),
        physical_parameters=par,geometry_sha256=sha256(src.encode()).hexdigest(),verifier_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
    output.write_text(json.dumps(result,indent=1)+'\n')
    print('passed',yes,len(rows),'min retained',min(arb(z).lower() for x in rows for z in x['all_AH_slacks']))
if __name__=='__main__':
    p=ArgumentParser()
    for n in ['comp','phys','out']:p.add_argument(n,type=Path)
    p.add_argument('bins',type=int,nargs='+')
    a=p.parse_args();run(a.comp.resolve(),a.phys.resolve(),a.bins,a.out)

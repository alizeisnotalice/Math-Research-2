from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import importlib.util,json,sys
from flint import ctx
D=Path(__file__).resolve().parent.parent;C=D/'prefilter/kit/comp012';sys.path.insert(0,str(C))
from certify_sigma_extended_graph import geometry
from certify_ah_local_physical_support import local_budgets

def mod(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=mod(D/'partner-scout/sharp_first_hit.py','old');new=mod(D/'j32-33/sharp_first_hit.py','new');q=json.loads((D/'partner-scout/physical-0125.json').read_bytes());ns,src,_=geometry(C,[tuple(map(F,q['line']))],sigma=q['sigma_degrees'],**dict(zip(('far','negative','eps'),map(F,q['physical_parameters']))));ns['_first_orientation']=0
assert sha256(src.encode()).hexdigest()=='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
rows=[]
for j in range(35,40):
 lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
 for i in (0,37,74):
  a,b=lo+i*step,lo+(i+1)*step;f=local_budgets(ns,a,b)[0][0];f=min(f,ns['two_hit_budgets'][j][0][0]);ns.pop('_first_budget_cache',None);x=old.first_budget(ns,a,b,f);ns.pop('_first_budget_cache',None);y=new.first_budget(ns,a,b,f);assert x==y,(j,i,x,y);rows.append({'bin':j,'index':i,'budget':str(x)})
(D/'partner-scout/compare-sharp.json').write_text(json.dumps(rows,indent=2)+'\n');print('same orientation-0 budget',len(rows),'closed cells')

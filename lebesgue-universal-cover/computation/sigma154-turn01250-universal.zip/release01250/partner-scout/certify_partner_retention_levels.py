"""Check several ordered positive-partner exclusions per closed reference cell."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys


def replay(comp, phys, bins, out):
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from certify_sigma_extended_graph import geometry
    from certify_ah_local_physical_support import local_budgets
    from certify_ah_single_contact_chain import local_slope
    from sharp_first_hit import first_budget

    par=json.loads(phys.read_bytes())
    pivot,turn=map(F,par['line'])
    far,negative,eps=map(F,par['physical_parameters'])
    ns,source,_=geometry(comp,[(pivot,turn)],sigma=par['sigma_degrees'],far=far,negative=negative,eps=eps)
    A,add,mul,dot,box,X=(ns[k] for k in ('A','add','mul','dot','box','X'))
    D,z=ns['D'],ns['z']
    cuts=[row for row in ns['rows'] if row[0].startswith('AH-line:')]
    assert [row[0] for row in cuts]==[f'AH-line:{k}' for k in range(4)]

    def first_coordinates(w):
        return ns['chart'](add(z,mul(A(w),D)))

    def baseline(w,n,h):
        ell,t=first_coordinates(w)
        return h-dot(n,X(ns['psi'](ell),-t))

    rows=[]
    levels=[(F(1,8),F(0)), (F(1,4),F(0)), (F(1,4),F(1,2)), (F(3,8),F(0))]
    for j in bins:
        lo,hi=ns['knots'][j:j+2]
        step=(hi-lo)/75
        for i in range(75):
            a,b=lo+i*step,lo+(i+1)*step
            mid=(a+b)/2
            first,second=local_budgets(ns,a,b)[0]
            f0,s0=ns['two_hit_budgets'][j][0]
            f=first_budget(ns,a,b,min(first,f0))
            s=min(second,s0)
            assert s>f and f>0
            ell,t=(u.union(v) for u,v in zip(first_coordinates(a),first_coordinates(b),strict=True))
            lp=ns['coord_hull'](ns['psi'],ell)
            m=local_slope(ns,lp,ns['deficit_by_bin'][j])
            _,grad_l,grad_t=ns['points'](box(a,b))
            l_w,t_w=dot(grad_l,D),dot(grad_t,D)
            psi_l=ns['psi_prime'](add(ns['l0'],mul(ell,ns['el'])))
            xl0,xt0=ns['derivs'](*ns['chart_bounds'](lp,-t))
            baselines=[]
            for _,n,h in cuts:
                dw=dot(n,xt0)*t_w-dot(n,xl0)*psi_l*l_w
                if dw>0:
                    margin=baseline(a,n,h)
                elif dw<0:
                    margin=baseline(b,n,h)
                else:
                    margin=baseline(mid,n,h)+box(a-mid,b-mid)*dw
                baselines.append(margin)
            classifications=[]
            for frac,elo in levels:
                assert 0<=elo<=1 and 0<frac<F(1,2)
                r=A(frac)
                # v=e gives C/e=2*y4-1<0. The partner deficit is positive.
                # Mean-value derivatives cover the entire segment back to the ideal point.
                max_xi=-2*f*r/m
                xl,xt=ns['derivs'](*ns['chart_bounds'](lp+max_xi.union(A(0)),-t+(-f).union(A(0))))
                margins=[]
                for (_,n,_),base in zip(cuts,baselines,strict=True):
                    B=dot(n,xt)
                    L=dot(n,xl)/m
                    coeff=(B,(1-2*r)*B,2*r*L+(1-2*r)*B)
                    drift=min((v*f*e).lower() for v in coeff for e in (A(elo),A(1)))
                    margins.append((base+drift).lower())
                classifications.append(dict(y4_max=str(frac),e_over_sharp_F_min=str(elo),
                                              positive=all(x>0 for x in margins),margins=list(map(str,margins))))
            rows.append(dict(bin=j,index=i,closed_w=[str(a),str(b)],F_sharp=str(f),S_old=str(s),
                             original_F=str(min(first,f0)),m=str(m),baseline=[str(b.lower()) for b in baselines],
                             levels=classifications))
    src={p.name:sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('sharp_first_hit.py'))}
    result=dict(complete=True,physical_parameters=par,geometry_sha256=sha256(source.encode()).hexdigest(),
                sources=src,orientation=0,only_positive_deficit=True,rows=rows)
    out.write_text(json.dumps(result,indent=1)+'\n')
    for j in bins:
        print(j,[sum(x['levels'][k]['positive'] for x in rows if x['bin']==j) for k in range(len(levels))],flush=True)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for key in ('comp','physical','out'):
        p.add_argument(key,type=Path)
    p.add_argument('bins',type=int,nargs='+')
    a=p.parse_args()
    replay(a.comp.resolve(),a.physical.resolve(),a.bins,a.out)

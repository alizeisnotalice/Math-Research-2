# .01250 actual partner exclusion, bins 35–39

This packet proves a necessary-condition exclusion, not an entire angular bin. It is used only when the same K and Q_A K have actual hits in the two new AH ears. Reflect the partner hit into K, use the true paired chart and the original support normalization, and retain all four AH inequalities. For e>0, the closed condition y4≤3/8 is incompatible with a second actual hit: every one of the 375 single cells has strictly positive retention clearance at all four new AH lines. The weakest such clearance is >4.56362476118e-5. At e=0 no such exclusion is claimed.

`result.json` contains the interval calculation. `audit.json` separately reconstructs the actual old support-bound closure on every single cell; it checks its m, S and original F against the raw rows, S>Fsharp>0, the four strict line margins, and the two-circle transversality and selected branch. In particular, a hypothetical partner violating a new retained-side inequality cannot be substituted by a merely pruned search state. The physical data are `.429,.01250,.327,.372,.0165` at 1.54 degrees, graph SHA 0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9.

For a larger parent block, the actual physical cells' nesting and S≥F must first be checked. Then v=min(e,S)=e for the same K both before and after subdivision; y4 and y5 retain their physical meaning. A parent e≥3Fsharp_parent/4 is positive, and a parent y5≤1/4 implies y4≤1/4<3/8 on each child. Adjacent closed child cells cover the parent. The e=0 case remains with its own low-deficit placement. All remaining contact counts must be verified separately.

Python 3.13, python-flint 0.9.0; `COMP` is the frozen .01250 graph source:

```
python -I -B certify_partner_retention_levels.py "$COMP" physical-0125.json NEW.json 35 36 37 38 39
cmp result.json NEW.json
python -I -B audit_partner_01250.py "$COMP" physical-0125.json NEW.json NEW-audit.json
cmp audit.json NEW-audit.json
```

The raw 375-cell run was independently recomputed and matched byte for byte. Its mathematical use depends on the already established real two-hit reduction, not on search termination.

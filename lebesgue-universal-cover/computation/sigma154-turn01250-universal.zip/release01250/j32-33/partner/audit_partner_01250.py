"""Bind the middle positive-partner rows to the original single-cell contact class."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import inspect
import json
import sys

from flint import arb


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def validate(comp, phys, raw):
    here=Path(__file__).resolve().parent
    sys.path[:0]=[str(here),str(comp)]
    from certify_sigma_extended_graph import geometry
    from certify_ah_local_physical_support import local_budgets
    from certify_ah_single_contact_chain import local_slope
    from certify_sigma_pinned_fan import support_bound

    par=json.loads(phys.read_bytes())
    pivot,turn=map(F,par['line'])
    far,negative,eps=map(F,par['physical_parameters'])
    ns,source,_=geometry(comp,[(pivot,turn)],sigma=par['sigma_degrees'],far=far,negative=negative,eps=eps)
    data=json.loads(raw.read_bytes())
    graph=sha256(source.encode()).hexdigest()
    assert data['complete'] and data['orientation']==0 and data['only_positive_deficit']
    assert data['physical_parameters']==par and data['geometry_sha256']==graph
    assert graph=='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
    assert all(digest(here/file)==h for file,h in data['sources'].items())
    assert ns['cuts'][-1]==(pivot,turn) and all(0<p<pivot and 0<t<turn for p,t in ns['cuts'][:-1])
    original={(row['bin'],row['index']):row for row in data['rows']}
    assert len(original)==len(data['rows'])==375
    assert set(original)=={(j,i) for j in range(35,40) for i in range(75)}
    A,add,sub,mul,dot,cross=(ns[k] for k in ('A','add','sub','mul','dot','cross'))
    summary=[]
    for j in range(35,40):
        lo,hi=ns['knots'][j:j+2];step=(hi-lo)/75
        retained=arb(1);crossing=arb(1);separation2lo=arb(1);separation2hi=arb(0)
        for i in range(75):
            a,b=lo+i*step,lo+(i+1)*step
            row=original[j,i]
            assert list(map(F,row['closed_w']))==[a,b]
            ns['_first_orientation']=0
            # The closure of the original support function contains the exact normalizing budget and slope.
            E,_,_,bound,_=support_bound(ns,j,a,b)
            outer=inspect.getclosurevars(bound).nonlocals
            inner=inspect.getclosurevars(outer['event']).nonlocals
            m=inner['local_m'][0]
            first,second=inner['ns']['two_hit_budgets'][j][0]
            f=arb(row['F_sharp']);fb,sb=local_budgets(ns,a,b)[0]
            f0,s0=ns['two_hit_budgets'][j][0]
            assert first==min(fb,f0) and second==min(sb,s0)
            assert str(m)==row['m'] and str(first)==row['original_F'] and str(second)==row['S_old']
            assert str(E)==str(ns['deficit_by_bin'][j])
            assert second>f>0 and (first>=f or str(first)==row['F_sharp'])
            level=[x for x in row['levels'] if F(x['y4_max'])==F(3,8) and F(x['e_over_sharp_F_min'])==0]
            level,=level
            assert level['positive'] and len(level['margins'])==4
            margin=min(arb(x).lower() for x in level['margins']);assert margin>0
            retained=min(retained,margin)
            ell,t=(x.union(y) for x,y in zip(*(ns['chart'](add(ns['z'],mul(A(w),ns['D']))) for w in (a,b)),strict=True))
            lp=ns['coord_hull'](ns['psi'],ell)
            assert str(local_slope(ns,lp,ns['deficit_by_bin'][j]))==str(m)
            xi=(-A(F(3,4))*f/m).union(A(0))
            x,L,N=ns['chart_bounds'](lp+xi,-t+(-f).union(A(0)))
            normal=sub(N,L)
            squared=dot(normal,normal)
            branch=-cross(sub(x,L),sub(x,N))
            assert 0<squared<A(4) and branch>0
            separation2lo=min(separation2lo,squared.lower())
            separation2hi=max(separation2hi,squared.upper())
            crossing=min(crossing,branch.lower())
        summary.append(dict(bin=j,closed_cells=75,old_contact_pattern=[5,0,0,0],old_deficit_class=['1/2','1'],
                            proven_y4_upper='3/8',AH_retaining_lower=str(retained),
                            squared_circle_center_separation=[str(separation2lo),str(separation2hi)],
                            negative_cross_lower=str(crossing)))
    return dict(complete=True,parameters=par,geometry_sha256=graph,orientation=0,
                physical_subcells=375,cases=summary,raw_sha256=digest(raw),auditor_sha256=digest(Path(__file__)))


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','physical','retention_receipt','out'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    d=validate(a.comp.resolve(),a.physical.resolve(),a.retention_receipt.resolve())
    a.out.write_text(json.dumps(d,indent=2)+'\n')
    print('verified',d['physical_subcells'],'closed cells',flush=True)

import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as Q
from flint import arb,ctx
ctx.prec=128
D=Path(__file__).resolve().parent;j=int(sys.argv[1]);d=json.loads((D/f'full-j{j}.json').read_text());phys=json.loads((D/'physical-0125.json').read_text());cfg=json.loads((D/f'config-j{j}.json').read_text())
assert d['complete'] and d['parameters']==cfg and d['physical_parameters']==phys and d['geometry_sha256']=='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
for name,h in d['source_hashes'].items():
 p=D/name
 if not p.is_file():p=D/'comp012'/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
assert d['reachable']=={str(j):[[0,75]]} and d['synchronized'] and d['tighten_first']
groups={};bad=0; rm=pm=arb(1);leaves=0
for t in d['rows']:
 o=t['orientation'];side=t['initial_derivative_sign'];r=t['row'];assert t['bin']==r['reference_bin']==j
 assert r['anchor_degrees']=='0' and r['anchor_comparison_sign']==side and Q(r['anchor_threshold'])==Q(3,250)
 assert r['placed_leaves']==sum(r['pose_counts'].values())
 valid=bool(arb(r['root_margin_lower'])>0 and arb(r['placement_margin_lower'])>0);assert t['positive']==valid
 bad+=not valid;rm=min(rm,arb(r['root_margin_lower']).lower());pm=min(pm,arb(r['placement_margin_lower']).lower());leaves+=r['placed_leaves']
 groups.setdefault((o,side),{}).setdefault((tuple(t['counts']),tuple(map(Q,t['e_class']))),[]).append(r['subcells'])
for o in (0,1):
 for side in (-1,1):
  plan={((k,5-k),(Q(0),Q(1))) for k in range(6)}
  if o==0 and side==-1:
   plan.remove(((5,0),(Q(0),Q(1))))
   plan.update(((5,0),(Q(k,4),Q(k+1,4))) for k in range(3))
   plan.update(((k,5-k,0,0),(Q(3,4),Q(1))) for k in range(6))
  g=groups[o,side];assert set(g)==plan
  parts=d['partitions'][f'{j},{o},{side}'];assert [i for l,r in parts for i in range(l,r)]==list(range(75)) and all(l<r for l,r in parts) and all(v==parts for v in g.values())
assert d['all_passed']==(bad==0)
out={'j':j,'all_passed':d['all_passed'],'rows':len(d['rows']),'failed':bad,'root_lower':str(rm),'pose_lower':str(pm),'placed_leaves':leaves,'output_sha256':hashlib.sha256((D/f'full-j{j}.json').read_bytes()).hexdigest(),'method':'independent structural audit; not numerical replay'}
(Path(sys.argv[2]) if len(sys.argv)>2 else D/f'audit-j{j}.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

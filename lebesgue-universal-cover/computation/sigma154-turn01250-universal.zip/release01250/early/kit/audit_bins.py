"""Audit the synchronized closed partitions and simultaneous root placements in each bin."""
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
from collections import defaultdict
import argparse,json
from flint import arb,ctx

ROOT=Path(__file__).resolve().parent
REFERENCE='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def audit(j,partial=False):
    file=ROOT/f'output-{j}.json'
    if not file.exists():return None
    d=read(file)
    if not d.get('complete'):return None
    cfg=d['parameters'];assert cfg['bins']==[j] and cfg['physical']=='physical-0125.json'
    assert d['physical_parameters']==read(ROOT/cfg['physical']) and d['geometry_sha256']==REFERENCE
    assert d['reachable']=={str(j):[[0,75]]} and d['EH_tightening']==dict(label='U1-Te-0',retreat='593/6250000000')
    for name,expected in d['source_hashes'].items():
        source=ROOT/name if (ROOT/name).exists() else ROOT/'comp012'/name
        assert digest(source)==expected,name
    cfgfile=next(name for name in d['source_hashes'] if name.startswith('config-') and name.endswith('.json'))
    assert read(ROOT/cfgfile)==cfg
    if j<15:assert Q(cfg['threshold'])==Q(1,50000) and Q(cfg['anchor'])==23
    elif j>15:assert Q(cfg['cut'])==-Q(3,250)
    rows=list(d['rows'])
    supfile=ROOT/f'supplement-{j}.json'
    added_digest=None
    if supfile.exists():
        sup=read(supfile)
        assert sup['complete'] and sup['all_passed'] and sup['geometry_sha256']==d['geometry_sha256'] and sup['physical_parameters']==d['physical_parameters']
        assert sup['parameters']['physical']==cfg['physical'] and sup['reachable']==d['reachable'] and sup['EH_tightening']==d['EH_tightening']
        assert sup['parameters']['cut']==cfg['cut'] and sup['synchronized'] and sup['tighten_first']
        assert sup['parameters']==read(ROOT/f'config-supp-{j}.json')
        for name,expected in sup['source_hashes'].items():
            src=ROOT/name if (ROOT/name).exists() else ROOT/'comp012'/name
            assert digest(src)==expected
        original=[r for r in rows if r['orientation']==0 and r['initial_derivative_sign']==-1 and r['counts']==[5,0]]
        assert sup['partitions'][f'{j},0,-1']==[r['row']['subcells'] for r in original]
        assert all(t['orientation']==0 and t['initial_derivative_sign']==-1 for t in sup['rows'])
        rows=[r for r in rows if r not in original]+sup['rows']
        added_digest=digest(supfile)
    parts=defaultdict(lambda:defaultdict(list));mins=[arb(1),arb(1)];bad=[];placed=free=empty=0
    for t in rows:
        ori=t['orientation'];side=t.get('angle_class',t.get('initial_derivative_sign',0));r=t['row'];assert r['reference_bin']==t['bin']==j
        assert ori in [0,1] and (side in [-1,1] if j!=15 else side==0)
        if side:
            assert Q(r['anchor_degrees'])==(23 if j<15 else 0)
            assert r['anchor_comparison_sign']==side and Q(r['anchor_threshold'])==(-Q(1,50000) if j<15 else Q(3,250))
        else:assert t['tighten_first'] is True
        counts=tuple(t['counts']);e=tuple(map(Q,t.get('e_class',['0','1'])))
        a,b=r['subcells'];assert 0<=a<b<=75
        bounds=[arb(r[n]).lower() for n in ['root_margin_lower','placement_margin_lower']]
        positive=all(v>0 for v in bounds);assert t.get('positive',positive)==positive
        if not positive:bad.append([ori,side,list(counts),[str(x) for x in e],[a,b],*[str(v) for v in bounds]])
        mins=[min(x,y) for x,y in zip(mins,bounds)]
        assert r['placed_leaves']==sum(r.get('pose_counts',r.get('verified_dihedral_pose_counts',{})).values())
        placed+=r['placed_leaves'];free+=r['root_free_leaves'];empty+=r.get('empty_conditional_subcells',0)
        parts[ori,side][counts,e].append([a,b])
    for ori in range(2):
        for side in ([-1,1] if j!=15 else [0]):
            g=parts[ori,side];plan={((k,5-k),(Q(0),Q(1))) for k in range(6)}
            if (added_digest or 'certify_refined31.py' in d['source_hashes']) and ori==0 and side==-1:
                plan.remove(((5,0),(Q(0),Q(1))))
                plan.update(((5,0),(Q(k,4),Q(k+1,4))) for k in range(3))
                plan.update(((k,5-k,0,0),(Q(3,4),Q(1))) for k in range(6))
            assert set(g)==plan,(j,ori,side)
            first=next(iter(g.values()))
            assert [i for a,b in first for i in range(a,b)]==list(range(75))
            assert all(seq==first for seq in g.values())
            if side:assert first==d['partitions'][f'{j},{ori},{side}']
    assert bool(d['all_passed'])==all(arb(t['row']['root_margin_lower'])>0 and arb(t['row']['placement_margin_lower'])>0 for t in d['rows'])
    return dict(sha256=digest(file),supplement_sha256=added_digest,physical_cells=75,rows=len(rows),root_lower=str(mins[0]),placement_lower=str(mins[1]),placed_leaves=placed,root_free_leaves=free,empty_conditionals=empty,bad=bad)
def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--partial',action='store_true');a=p.parse_args()
    ctx.prec=128
    geom=read(ROOT/'geometry-area.json');gamma=read(ROOT/'geometry-gamma.json')
    assert geom['parameters']==gamma['physical']==read(ROOT/'physical-0125.json')
    assert geom['chart']['geometry_sha256']==gamma['geometry_sha256']==REFERENCE
    assert len(geom['chart']['reference_ranges'])==70 and geom['chart']['reference_subcells']==5183
    assert len(gamma['retained_sprague_arc_endpoint_signs'])==5 and all(arb(v)>0 for v in gamma['retained_sprague_arc_endpoint_signs'].values())
    assert Q(geom['chart']['reference_endpoint'])==Q(43,100) and Q(geom['chart']['physical_graph_endpoint'])==Q(13,25)
    eh=next(c for c in geom['geometry']['cases'] if c['label']=='eleven')
    assert Q(eh['transfer_cost_upper'])<Q(593,6250000000)
    bins={}
    for j in range(32):
        v=audit(j,a.partial)
        if v is not None:bins[str(j)]=v
    missing=[j for j in range(32) if str(j) not in bins]
    all_positive=not missing and all(not v['bad'] for v in bins.values())
    if not a.partial:assert all_positive
    a.out.write_text(json.dumps(dict(geometry_sha256=REFERENCE,all_requested=all_positive,missing=missing,bins=bins),indent=2)+'\n')
if __name__=='__main__':main()

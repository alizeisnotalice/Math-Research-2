"""Use one physical partition for all six normalized contact classes within each intrinsic branch."""
import argparse,sys,json,inspect
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256

def run(comp,config,target):
    sys.path[:0]=[str(Path(__file__).resolve().parent),str(comp)]
    from flint import arb
    from certify_sigma_extended_graph import geometry
    from certify_ah_affine_root_class import validate
    from certify_sigma_reachable_roots import reach
    from ordered_state import support_bound
    cfg=json.loads(config.read_bytes());physical_path=config.parent/cfg['physical'];pcfg=json.loads(physical_path.read_bytes())
    p,d=map(F,pcfg['line']);physical=dict(zip(('far','negative','eps'),map(F,pcfg['physical_parameters'])))
    n,source,_=geometry(comp,[(p,d)],sigma=pcfg['sigma_degrees'],**physical);n['_sharpen_jets']=True;n['_tighten_first']=True
    index,=[i for i,(label,_,_) in enumerate(n['rows']) if label.startswith('U1-Te')]
    label,normal,offset=n['rows'][index];retreat=F(cfg['retreat']);assert retreat>=0 and F(n['eh_depth'])==F('.000555')
    n['rows'][index]=label,normal,offset-n['A'](retreat)
    src=inspect.getsource(validate);old='a=r0+i*step;b=a+step';assert src.count(old)==1
    env={**validate.__globals__,'support_bound':support_bound};exec(compile(src.replace(old,'a=r0+i*step;b=r0+ns["_end_index"]*step'),'synchronized_closed_blocks','exec'),env)
    reachable={str(j):reach(n,j) for j in cfg['bins']}
    def visit(j,ori,side,a,b):
        n['_end_index']=b;n['_first_orientation']=ori;block=[]
        anchor=F(cfg['anchor']);threshold=F(cfg['threshold']);assert threshold>0
        for k in range(6):
            n['_class_counts']=(k,5-k)
            for l,r,t in (cfg['low_brackets'] if side==-1 else cfg['high_brackets']):
                assert F(l)<F(r) and (side==1 or F(r)==anchor)
                row=env['validate'](n,j,F(l),F(r),t,1,1,begin=a,end=a+1,angular=12,depth=cfg['depth'],anchor=anchor,threshold=threshold,condition_sign=side)
                ok=all(arb(row[x])>0 for x in ('root_margin_lower','placement_margin_lower'))
                if ok:break
            if not ok and b-a>1 and cfg.get('adaptive',True):
                mid=(a+b)//2
                return visit(j,ori,side,a,mid)+visit(j,ori,side,mid,b)
            row['subcells']=[a,b]
            block.append({'bin':j,'orientation':ori,'counts':[k,5-k],'angle_class':side,'row':row})
        return block
    rows=[];partitions={}
    for j in cfg['bins']:
        for ori in cfg.get('orientations',(0,1)):
            for side in cfg.get('sides',(-1,1)):
                tag=f'{j},{ori},{side}'
                bounds=cfg['breaks'][tag]
                target_indices=[i for xx,yy in reachable[str(j)] for i in range(xx,yy)]
                assert [i for a,b in bounds for i in range(a,b)]==target_indices
                part=[]
                for a,b in bounds:
                    part+=visit(j,ori,side,a,b)
                    print('block',j,ori,side,a,b,'fails',sum(not all(arb(t['row'][x])>0 for x in ('root_margin_lower','placement_margin_lower')) for t in part[-6:]),flush=True)
                aa=[t['row']['subcells'] for t in part if t['counts'][0]==0]
                for k in range(6):assert [t['row']['subcells'] for t in part if t['counts'][0]==k]==aa
                assert [i for a,b in aa for i in range(a,b)]==target_indices
                partitions[tag]=aa;rows+=part
                print(tag,len(part),min(float(arb(t['row']['placement_margin_lower'])) for t in part),flush=True)
                target.write_text(json.dumps({'complete':False,'rows':rows})+'\n')
    def digest(p):return sha256(p.read_bytes()).hexdigest()
    paths=[Path(__file__),Path(__file__).with_name('ordered_state.py'),Path(__file__).with_name('sharp_first_hit.py'),config,physical_path]+[comp/k for k in ('certify_sigma_pinned_fan.py','certify_ah_affine_root_class.py','certify_sigma_extended_graph.py')]
    root,pose=[min(arb(t['row'][x]).lower() for t in rows) for x in ('root_margin_lower','placement_margin_lower')]
    target.write_text(json.dumps({'complete':True,'all_passed':bool(min(root,pose)>0),'synchronized':True,'parameters':cfg,'physical_parameters':pcfg,'reachable':reachable,'EH_tightening':{'label':label,'retreat':str(retreat)},'root_min':str(root),'pose_min':str(pose),'geometry_sha256':sha256(source.encode()).hexdigest(),'source_hashes':{p.name:digest(p) for p in paths},'flint':n['flint_version'],'python':sys.version,'partitions':partitions,'rows':rows},indent=1)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for x in ('comp','config','target'):p.add_argument(x,type=Path)
    a=p.parse_args();run(a.comp.resolve(),a.config,a.target)

"""From-frozen-source interval recomputation of all selected .01250 receipts."""
from pathlib import Path
import json,subprocess,sys
D=Path(__file__).resolve().parent;W=Path(sys.argv[1]).resolve();W.mkdir(parents=True,exist_ok=True);P=sys.executable

def run(script,*args):
 print('REPLAY',script.relative_to(D),flush=True)
 subprocess.run([P,'-I','-B',str(script),*map(str,args)],cwd=D,check=True,stdout=subprocess.DEVNULL)

def compare(a,b):
 x=json.loads(a.read_bytes());y=json.loads(b.read_bytes())
 if 'python' in y:x['python']=y['python']
 assert x==y,(a,b)
# The original first-EH and physical-chart calculations are already rerun by the parent verifier.
run(D/'early/kit/replay.py',W/'early','--full','--workers',4)
M=D/'j32-33';C=M/'comp012'
for j in (32,33):
 out=W/f'j{j}.json';run(M/'certify_refined31.py',C,M/f'config-j{j}.json',out);compare(out,M/f'full-j{j}.json')
out=W/'j34.json';run(M/'certify_refined_oct.py',C,M/'config-j34.json',out);compare(out,M/'oct-j34.json')
S=D/'partner-scout';out=W/'partner-raw.json';run(S/'certify_partner_retention_levels.py',D/'prefilter/kit/comp012',S/'physical-0125.json',out,35,36,37,38,39);compare(out,S/'result.json')
for j in range(35,40):
 out=W/f'j{j}.json';run(M/'certify_partner_join.py',C,M/f'config-j{j}.json',out);compare(out,M/f'join-j{j}.json')
run(D/'tail/verify.py',D/'prefilter/kit/comp012',D/'main',W/'tail')
print('All selected .01250 interval computations reran and matched.',flush=True)

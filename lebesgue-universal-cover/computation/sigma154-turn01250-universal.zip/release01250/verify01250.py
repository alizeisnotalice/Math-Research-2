"""Recompute the physical construction and verify all 70 .01250 bins."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,subprocess,sys
assert len(sys.argv) in (2,3) and (len(sys.argv)==2 or sys.argv[2]=='--full')
D=Path(__file__).resolve().parent;W=Path(sys.argv[1]).resolve();W.mkdir(parents=True,exist_ok=True);P=sys.executable
G='0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9'
def load(p):return json.loads(p.read_bytes())
def run(p,*args):subprocess.run([P,'-I','-B',str(p),*map(str,args)],check=True,cwd=D)
run(D/'prefilter/kit/replay.py',W/'prefilter');run(D/'early/kit/replay.py',W/'early')
area=load(D/'prefilter/kit/area-0125.json');early=load(W/'early/audit.json');assert area['chart']['geometry_sha256']==early['geometry_sha256']==G and area['chart']['reference_subcells']==5183
assert area['parameters']=={'sigma_degrees':'1.54','line':['.429','.01250'],'physical_parameters':['.327','.372','.0165']}
assert set(area['geometry']['EH_first'])=={'sigma154-ah429-eh550-composition.json','sigma154-ah429-eh-chain997-composition.json'}
for name,h in area['geometry']['EH_first'].items():assert sha256((D/'main'/name).read_bytes()).hexdigest()==h
if True:
 e=D/'firstEH/comp';ew=W/'firstEH';ew.mkdir(exist_ok=True);single=W/'firstEH-single.json';chain=W/'firstEH-chain.json'
 with single.open('w') as out:subprocess.run([P,'-I','-B',str(e/'certify_sigma154_eh_transfer.py'),str(e),str(e/'eh-sigma-154-single550-weights.json'),str(e/'sigma-154-ah-reachable-full-certificate.json'),str(e/'sigma-154-ah-reachable-full-parameters.json'),str(ew)],stdout=out,check=True,cwd=D)
 assert single.read_bytes()==(D/'main/sigma154-ah429-eh550-composition.json').read_bytes()
 with chain.open('w') as out:subprocess.run([P,'-I','-B',str(e/'certify_sigma154_eh_chain.py'),str(e),str(e/'eh-sigma-154-chain997-weights.json'),str(single)],stdout=out,check=True,cwd=D)
 assert chain.read_bytes()==(D/'main/sigma154-ah429-eh-chain997-composition.json').read_bytes()
 c=D/'prefilter/kit/comp012';phys=D/'prefilter/kit/physical-0125.json';rearea=W/'area.json'
 with rearea.open('w') as out:subprocess.run([P,'-I','-B',str(c/'certify_sigma154_deeper_composition.py'),str(c),str(phys),'--eh',str(c)],stdout=out,check=True,cwd=D)
 assert rearea.read_bytes()==(D/'prefilter/kit/area-0125.json').read_bytes()
 nested=W/'nested.json';run(D/'check_nested01250.py',c,nested);assert nested.read_bytes()==(D/'nested32-39.json').read_bytes()
assert early['all_requested'] and not early['missing'] and set(map(int,early['bins']))==set(range(32))
for j in (32,33):
 out=W/f'audit-j{j}.json';run(D/'j32-33/audit_direct.py',j,out);raw=load(D/f'j32-33/full-j{j}.json');a=load(out);assert raw['geometry_sha256']==G and raw['physical_parameters']==area['parameters'] and a['all_passed'] and not a['failed']
out=W/'audit-j34.json';run(D/'j32-33/audit_oct.py',34,out);raw=load(D/'j32-33/oct-j34.json');a=load(out);assert raw['geometry_sha256']==G and raw['physical_parameters']==area['parameters'] and a['all_passed'] and not a['failed']
tail=W/'tail.json';run(D/'tail/compose.py',D/'main',D/'tail',tail);t=load(tail);assert t['complete_tail'] and t['geometry_sha256']==G and t['only_bins']==list(range(40,70)) and t['physical_subcells']==2183
E=next(x for x in area['geometry']['cases'] if x['label']=='eleven');assert F(E['area']['exact'][1])<F('0.844089526737330340502339493529840182096')

# Recompute the 375 actual-partner interfaces before using their exclusions.
a=W/'partner-audit.json';run(D/'partner-scout/audit_partner_01250.py',D/'prefilter/kit/comp012',D/'partner-scout/physical-0125.json',D/'partner-scout/result.json',a)
assert a.read_bytes()==(D/'partner-scout/audit.json').read_bytes()
for j in range(35,40):
 out=W/f'join-audit-{j}.json';run(D/'audit_join01250.py',j,out); v=load(out);assert v['bin']==j and v['geometry_sha256']==G and v['physical_cells']==v['excluded_singletons']==75
assert F(E['transfer_cost_upper'])<F(593,6250000000)
O={'complete':True,'geometry_sha256':G,'bins':70,'physical_cells':5183,'area_upper':E['area']['exact'][1],'EH_transfer_upper':E['transfer_cost_upper'],'EH_retreat':'593/6250000000','scope':'70 closed bins with actual two-hit reduction','full_interval_replay':False}
if len(sys.argv)==3:
 run(D/'full_replay01250.py',W/'full-replay');O['full_interval_replay']=True
(W/'cover-result.json').write_text(json.dumps(O,indent=2)+'\n');print(json.dumps(O,indent=2))

# Universal-cover candidate at AH turn .01250

The physical construction has Gibbs angle 1.54°, AH pivot .429, AH turn .01250 radians and chart parameters (.327,.372,.0165). The actual eleven-EH area has exact rational upper endpoint in `cover-result.json`, strictly below 0.844089526737330340502339493529840182096. The chart hash is `0f3bf35fd6d1719cfb67baefe2d06d7b3bae82d19e836fdea55ffd47cb02d6d9`; it has 70 bins and 5183 reachable physical cells, including 8 in the last bin.

Use Python 3.13 and python-flint 0.9.0:

```
python -I -B verify01250.py /path/to/writable-scratch
python -I -B verify01250.py /path/to/writable-scratch --full
```

The default verifies source binding and every closed classification, and recomputes the first-EH single and .997 chain, physical geometry and area, nested budgets, and true-partner interface. `--full` additionally recomputes all selected interval receipts and can require substantial CPU time. The result records whether this mode completed. Component READMEs describe their own full-replay commands and inputs.

The earlier first-EH placement is replayed from its frozen original chart, not from the new chart. Its single and chain SHA-256 are required to agree with the two first-EH sources bound to the new area. The proof and transfer to the new AH chart are in `proofs/sigma154-ah429-eh550-composition.md`, `proofs/sigma154-deeper-composition.md`, and their linked files. The true new physical chart separately verifies the first-hit trigger boxes, original Sprague arc endpoints, AH/EH separation and the actual intersection and Green area.

For the only remaining AH case, `proofs/ah-segment-cap.md` uses one body K and its fixed reflection Q_A K, each with a real new-ear hit. Reflecting the partner hit back gives two actual points in the same K; interchanging the two labels preserves that input. In every nonempty closed branch the candidate angle root and the rigid motion are coupled: each potentially root-containing angle leaf uses one of the same root's twelve dihedral poses and checks all host rows simultaneously. The U1-Te-0 row is retreated by 593/6250000000, strictly more than the certified transfer cost to the real .997 eleven-EH chain.

Bins 35–39 split both actual first-hit labels and both closed initial-derivative sides. In the designated high-deficit deepest quarter class, `partner-scout/` proves that the actual second AH hit cannot occur: on every single cell all four AH retention margins are strictly positive. Its independent audit rechecks the same old support closure's m/S/F, strict S>Fsharp>0 and the two-circle branch. Parent and child use the same true body; parent S>Fsharp≥e and child S>Fsharp≥e imply v=e and the normalized y4,y5 retain their meanings. Thus the parent y5≤1/4 class maps into y4≤3/8 on each closed child; the e=0 seam remains in a low-deficit root class. Every other ordered count and both label/derivative sides retain their own full root and common-pose certificates. `audit_join01250.py` checks that every parent block is covered by its exact child list and recalculates its parent Fsharp/S.

Bins 40–69 are handled by the actual-partner zero-deficit reduction in `tail/README.md`: positive second deficit is excluded and the e=0 relabelling is handled separately. No conclusion is inferred from the number of pruned search states. The 0–31 and 32–34 interval classes are specified in `early/kit/README.md` and their raw source and data.

The independently audited global minimum root margin is greater than 6.82409854876e-9 (bin 34), and the minimum common-pose margin is greater than 1.50929269027e-8 (bin 32), with the EH retreat already included. The count table and conservative interval values are in `statistics.json`; regenerate them after a successful verifier run with `python -I -B statistics01250.py /path/to/writable-scratch NEW-statistics.json`.

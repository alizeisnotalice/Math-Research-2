"""Reconstruct all unique old Q11-only parent leaves from the frozen 3279-root batch."""

from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json


def selection(package):
    manifest = json.loads((package / "manifest.json").read_bytes())
    source = {}
    for file in sorted((package / "frozen").glob("m1-*.jsonl")):
        assert (
            sha256(file.read_bytes()).hexdigest()
            == manifest["package_files_sha256"][str(file.relative_to(package))]
        )
        for l in file.read_bytes().splitlines():
            d = json.loads(l)
            s = d["stats"]
            if s[0] and s[4] > 0 and s[3] == s[5] == 0:
                source[d["leaf"]] = d
    assert len(source) == 434
    return source


def write(package, dest):
    source = selection(package)
    keys = sorted(source, key=lambda s: tuple(map(int, s.split("/"))))
    dest.mkdir(exist_ok=True, parents=True)
    for j in range(0, len(keys), 32):
        (dest / f"q{j//32:02d}.json").write_text(json.dumps(keys[j : j + 32]) + "\n")


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    p.add_argument("package", type=Path)
    p.add_argument("dest", type=Path)
    a = p.parse_args()
    write(a.package, a.dest)

"""Record first winning Q11 rows only after all 384 cells of a native terminal pass."""

from argparse import ArgumentParser
import ctypes, json, runpy, subprocess, sys
from hashlib import sha256
from pathlib import Path


def run(a):
    cp = a.comp.resolve()
    sys.path.insert(0, str(cp))
    package = a.replay.resolve()
    man = json.loads((package / "manifest.json").read_bytes())
    for k, h in man["computation_dependencies_sha256"].items():
        assert sha256((cp / k).read_bytes()).hexdigest() == h
    source = package / "kernels-tangent/replay_angle_mesh.py"
    assert (
        sha256(source.read_bytes()).hexdigest()
        == man["package_files_sha256"][str(source.relative_to(package))]
    )
    old = subprocess.run
    instrumented = []

    def wrap(cmd, *args, **kw):
        if "-o" in cmd and Path(cmd[cmd.index("-o") + 1]).name == "guard.so":
            f = a.work / "angle_mesh_dynamic.hpp"
            s = f.read_text()
            h = sha256(s.encode()).hexdigest()
            assert s.count("        bool needs_collective=false;") == 1
            hdecl = 'extern "C" { long long chosen_q_rows[2258] = {}; }\n'
            s = hdecl + s.replace(
                "        bool needs_collective=false;",
                "        int qtrace[384];\n        bool needs_collective=false;",
            )
            assert s.count("ok=true;") == 6
            s = s.replace("ok=true;", "ok=true; if(n==100)qtrace[i]=int(k);")
            anchor = "        if(needs_collective)++collective_boxes;"
            assert s.count(anchor) == 1
            s = s.replace(
                anchor,
                "        if(n==100)for(int key:qtrace)++chosen_q_rows[key];\n" + anchor,
            )
            f.write_text(s)
            instrumented.extend([h, sha256(s.encode()).hexdigest()])
        return old(cmd, *args, **kw)

    subprocess.run = wrap
    sys.argv = [
        str(source),
        str(cp),
        str(a.tree.resolve()),
        str(a.table.resolve()),
        str(a.work.resolve()),
        str(a.cache.resolve()),
        "--target",
        ".83750",
        "--cases",
        a.key,
        "--modes",
        "1",
        "--budget",
        "131071",
        "--depth",
        "116",
        "--panels",
        "256",
        "--share-angles",
        "--q-mesh",
        "--edge-caps",
        "--dense",
        "--share-dense",
        "--q-trigger-divisor",
        "25000",
    ]
    runpy.run_path(str(source), run_name="__main__")
    assert len(instrumented) == 2
    lib = ctypes.CDLL(str(a.work.resolve() / "guard.so"))
    counts = list((ctypes.c_longlong * 2258).in_dll(lib, "chosen_q_rows"))
    assert sum(counts) % 384 == 0 and sum(counts) > 0
    out = dict(
        leaf=a.key,
        rows=len(counts),
        distinct=sum(x > 0 for x in counts),
        complete_q_terminals=sum(counts) // 384,
        frequencies=counts,
        header_hash=instrumented,
    )
    a.out.write_text(json.dumps(out, indent=2) + "\n")


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "replay", "tree", "table", "work", "cache", "out"]:
        p.add_argument(k, type=Path)
    p.add_argument("key")
    run(p.parse_args())

"""Rebuild a .83750 five-curve plus Q11 terminal packet with the Q11 score reserve."""

from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, runpy, sys


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def run(a):
    assert __debug__
    package = a.replay.resolve()
    man = json.loads((package / "manifest.json").read_bytes())
    for name, h in man["computation_dependencies_sha256"].items():
        assert digest(a.comp / name) == h
    for name, h in man["package_files_sha256"].items():
        if name.startswith("kernels-tangent/"):
            assert digest(package / name) == h
    assert digest(a.table) == man["table64_sha256"]
    cp = a.comp.resolve()
    sys.path.insert(0, str(cp))
    import replay_q11_with_p30 as old

    cls = old.PointProof

    class ReservedPointProof(cls):
        def __init__(self, data, error=F(0)):
            super().__init__(data, error)
            if error:
                assert len(data["points"]) == 11 and error == F(1, 10**9)
                self.triples[7::8] -= 134
            else:
                assert len(data["points"]) == 30
                self.triples[7::8] = 0

    old.PointProof = ReservedPointProof
    # With zero support score, P30 cannot satisfy any positive-margin filter.
    source = package / "kernels-tangent/replay_angle_mesh.py"
    sys.argv = [
        str(source),
        str(cp),
        str(a.tree.resolve()),
        str(a.table.resolve()),
        str(a.work.resolve()),
        str(a.cache.resolve()),
        "--target",
        ".83750",
        "--cases-from",
        str(a.packet.resolve()),
        "--modes",
        "1",
        "--budget",
        str(a.budget),
        "--depth",
        "116",
        "--panels",
        "256",
        "--share-angles",
        "--q-mesh",
        "--edge-caps",
        "--dense",
        "--share-dense",
        "--q-trigger-divisor",
        "4000",
    ]
    runpy.run_path(str(source), run_name="__main__")


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "replay", "tree", "table", "work", "cache", "packet"]:
        p.add_argument(k, type=Path)
    p.add_argument("--budget", type=int, default=131071)
    run(p.parse_args())

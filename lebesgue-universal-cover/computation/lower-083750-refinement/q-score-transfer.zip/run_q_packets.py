"""Run disjoint packets of the previously Q-dependent original roots."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess, sys, json

here = Path(__file__).resolve().parent


def main(a):
    pk = sorted((here / "qpacks").glob("q*.json"))
    if a.packets:
        pk = [p for p in pk if p.stem in a.packets]
    assert pk
    a.dest.mkdir(exist_ok=True, parents=True)

    def one(p):
        out = a.dest / (p.stem + ".jsonl")
        cmd = [
            sys.executable,
            "-I",
            "-B",
            str(here / "check_q_leaves.py"),
            str(a.comp),
            str(a.replay),
            str(a.tree),
            str(a.table),
            str(a.work / p.stem),
            str(a.cache),
            str(p),
            "--budget",
            str(a.budget),
        ]
        partial = out.with_suffix(".partial")
        with partial.open("w") as f:
            subprocess.run(cmd, stdout=f, check=True)
        data = [json.loads(x) for x in partial.read_bytes().splitlines()]
        assert [d["leaf"] for d in data] == json.loads(p.read_bytes())
        assert all(d["stats"][3] == 0 and d["goal"] == "67/80" for d in data)
        partial.rename(out)
        print(
            p.name,
            len(data),
            sum(d["stats"][0] for d in data),
            sum(d["stats"][1] for d in data),
            flush=True,
        )

    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        list(pool.map(one, pk))


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "replay", "tree", "table", "work", "cache", "dest"]:
        p.add_argument(k, type=Path)
    p.add_argument("--budget", type=int, default=131071)
    p.add_argument("--workers", type=int, default=3)
    p.add_argument("--packets", nargs="*")
    main(p.parse_args())

"""Audit complete whole-leaf receipts against the original frozen certified boxes."""

from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json, sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from make_q_packets import selection


def run(package, result, trace, qproof, out):
    old = selection(package)
    t = json.loads(trace.read_bytes())
    original = old[t["leaf"]]
    assert sum(t["frequencies"]) == 384 * original["stats"][4] and t["distinct"] == sum(
        z > 0 for z in t["frequencies"]
    )
    assert t["complete_q_terminals"] == original["stats"][4] == 2768 and original[
        "stats"
    ][1:4] == [8453, 1459, 0]
    pr = json.loads(qproof.read_bytes())
    assert (
        pr["complete"]
        and pr["exact_native_replacement_maximum_score_drop"] == 134
        and F(pr["squared_diameter"]) < F(pr["scale"]) ** 2
    )
    keys = set()
    closed = []
    total = 0
    q = 0
    five = 0
    edge = 0
    files = {}
    for f in sorted(result.glob("q*.jsonl")):
        files[f.name] = sha256(f.read_bytes()).hexdigest()
        for l in f.read_bytes().splitlines():
            d = json.loads(l)
            id = d["leaf"]
            s = d["stats"]
            assert id in old and id not in keys
            keys.add(id)
            assert d["lo"] == old[id]["lo"] and d["hi"] == old[id]["hi"]
            assert s[3] == s[5] == 0 and d["mode"] == 1 and d["goal"] == "67/80"
            assert (
                d["threshold_integer"] == 120696470013529293
                and d["edge_caps"]
                and d["q_mesh"]
            )
            assert d["q_trigger_divisor"] == 4000 and d["center_calls"] == 0
            total += s[1]
            q += s[4]
            five += s[2]
            edge += d["q_edge_stops"]
            if s[0]:
                assert d["pending"] == 0 and s[1] == 2 * (s[2] + s[4]) - 1
                closed.append(id)
    assert keys == set(old)
    a = dict(
        complete=True,
        source_roots=len(old),
        complete_roots=len(closed),
        complete_ids=closed,
        unresolved=sorted(keys - set(closed)),
        total_nodes=total,
        q11_terminals=q,
        five_terminals=five,
        long_chord_q_terminals=edge,
        original_P30_terminals=0,
        score_reserve_ticks=134,
        target="67/80",
        threshold_numerator=120696470013529293,
        selected_original_leaf=t["leaf"],
        selected_original_terminals=t["complete_q_terminals"],
        selected_original_rows=t["distinct"],
        selected_original_selections=sum(t["frequencies"]),
        packets_sha256=files,
        selected_histogram_sha256=sha256(trace.read_bytes()).hexdigest(),
        qproof_sha256=sha256(qproof.read_bytes()).hexdigest(),
    )
    out.write_text(json.dumps(a, indent=2, sort_keys=True) + "\n")
    print(
        len(keys), len(closed), total, q, five, edge, len(a["unresolved"]), flush=True
    )


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["package", "receipts", "trace", "qproof", "out"]:
        p.add_argument(k, type=Path)
    a = p.parse_args()
    run(a.package, a.receipts, a.trace, a.qproof, a.out)

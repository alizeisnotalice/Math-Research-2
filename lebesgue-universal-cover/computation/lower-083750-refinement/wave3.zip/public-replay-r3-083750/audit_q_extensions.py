"""Verify same-physical-input Q11 extensions of exact original closed roots."""
from argparse import ArgumentParser
from collections import defaultdict
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from integrate_models import exact_parent, read, sha

def main(a):
    sys.path.insert(0,str(a.r2))
    from audit_refined_scope import audit_paths
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import SourceTree,FINE
    source=SourceTree(a.tree)
    assert sha(a.bank)=='c956e535ab0ed2bdc0a289c388ce88cf7a26132a356b6adb2076b36d508ef93a'
    assert sha(a.comp/'multi-host-points.json')=='9052ca388aabacc87116ba99a05d9ef98b49dfeed564e8cfd18efb647f93f282'
    entries=read(a.packet)
    rp=list(map(json.loads,a.children.read_bytes().splitlines()))
    assert [x['label'] for x in rp]==[box['label'] for x in entries for box in x['regions']]
    assert len(rp)==len({x['label'] for x in rp})
    groups=defaultdict(list)
    for child in rp:
        assert child['mode']==1 and child['goal']=='67/80' and child['threshold_integer']==120696470013529293
        assert child['budget']==a.cap and child['q_trigger_divisor']==4000
        assert child['q_mesh'] and child['panels']==256 and child['shared_angles'] and child['shared_dense']
        assert not child['guards'] and not child['center_stops'] and not child['fan_integral']
        assert child['stats'][3]==child['stats'][5]==0
        groups[child['leaf']].append(child)
    out=[]
    log={}
    cache={}
    for entry in entries:
        key=entry['leaf']
        trace,row=exact_parent(cache,entry,source,FINE,a.r2/'refined',audit_paths)
        assert row['stats'][3]==row['stats'][5]==0 and row['stats'][4]>0
        group=groups.pop(key)
        marks=[]
        for child,region in zip(group,entry['regions'],strict=True):
            assert child['leaf']==region['leaf'] and child['label']==region['label']
            assert region['bounds']==[list(b) for b in zip(child['lo'],child['hi'],strict=True)]
            s=child['stats']
            assert 0<s[1]<=a.cap
            if s[0]:
                assert s[1]==2*(s[2]+s[4])-1 and not child['pending'] and s[7]==0
            marks.append(bool(s[0]))
        changed=sum(r['stats'][1] for r in group)
        log[key]=dict(all_closed=all(marks),subboxes=len(group),succeeded=sum(marks),nodes=changed)
        if not all(marks):
            continue
        v,t,_,q,_=row['stats'][1:6]
        tf=sum(r['stats'][2] for r in group)
        qf=sum(r['stats'][4] for r in group)
        assert v+changed==2*(t+tf+q+qf)-1
        out.append(dict(leaf=key,extra_inputs=['oldQ11'],parent=trace,whole_nodes=v+changed,
                        prefix_five=t,prefix_oldQ=q,suffix_five=tf,suffix_oldQ=qf))
    assert not groups
    a.output.write_text(json.dumps(dict(target='67/80',strict=True,proved=out,attempts=log,
        input_sha256={p.name:sha(p) for p in (a.packet,a.children,a.bank)}),indent=2)+'\n')
    print(len(out),log,flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r2','packet','children','bank','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--cap',type=int,default=32767)
    main(p.parse_args())

"""Join audited additional original-leaf witnesses without changing model labels."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

def main(a):
    out=[]
    by_source={}
    for path in a.inputs:
        data=json.loads(path.read_bytes())
        assert data['target']=='67/80' and data['strict']
        proof=data['proved']
        assert len({row['leaf'] for row in proof})==len(proof)
        name='/'.join(path.parts[-2:])
        assert name not in by_source
        by_source[name]=sha256(path.read_bytes()).hexdigest()
        for row in proof:
            out.append({**row,'audited_source':name})
    types={(r['leaf'],tuple(r['extra_inputs'])) for r in out}
    assert len(types)==len(out)
    a.output.write_text(json.dumps(dict(target='67/80',strict=True,proved=out,
                                        audit_inputs_sha256=by_source),indent=2)+'\n')
    print(len(out),flush=True)
if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    p.add_argument('inputs',type=Path,nargs='+')
    main(p.parse_args())

"""Audit matched continuation results and reconstruct each successful original tree."""
from argparse import ArgumentParser
from collections import Counter
from itertools import groupby
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from integrate_models import exact_parent, read, sha

def check_arm(path,packet,cap):
    output={}
    rows=[json.loads(l) for l in path.read_bytes().splitlines()]
    for key,group in groupby(rows,key=lambda r:f"{r['leaf'][0]}/{r['leaf'][1]}"):
        assert key not in output
        output[key]=list(group)
    assert list(output)==[group['leaf'] for group in packet]
    for case in packet:
        key=case['leaf']
        for i,(row,_) in enumerate(zip(output[key],case['regions'],strict=True)):
            assert row['leaf'][2]==i and row['target']=='67/80'
            nz,nodes,five,point,depth=row['out']
            assert nz in (0,1) and 0<nodes<=cap and depth<=110
            if nz:
                assert nodes==2*(five+point)-1 and row['front'] is None
            else:
                assert len(row['front'])==22
    return output

def run(a):
    sys.path.insert(0,str(a.r2))
    from audit_refined_scope import audit_paths
    sys.path.insert(0,str(a.comp))
    from certify_tomar_six_high import SourceTree,FINE
    source=SourceTree(a.tree)
    packet=read(a.packet)
    records=read(a.ledger)
    eligible=set(records['models']['replacement_with_both_Q']['unresolved'])
    assert len(packet)==len({r['leaf'] for r in packet}) and all(x['leaf'] in eligible for x in packet)
    trails={}
    stats={}
    closed={}
    selected={}
    for path in a.runs:
        arms=check_arm(path,packet,a.cap)
        counts=Counter()
        proofs={}
        for entry in packet:
            key=entry['leaf']
            link,parent=exact_parent(trails,entry,source,FINE,a.r2/'refined',audit_paths)
            child=arms[key]
            counts['boxes']+=len(child)
            node_visits=sum(x['out'][1] for x in child)
            counts['nodes']+=node_visits
            counts['closed_boxes']+=sum(x['out'][0] for x in child)
            if not all(x['out'][0] for x in child):
                continue
            five=sum(x['out'][2] for x in child)
            point=sum(x['out'][3] for x in child)
            v,t,p,q,mixed=parent['stats'][1:6]
            assert not mixed
            assert v+node_visits==2*(t+p+q+five+point)-1
            ids=[name for qty,name in ((p,'P30'),(q,'oldQ11'),(point,'newQ11')) if qty]
            counts['whole_roots']+=1
            data=dict(leaf=key,extra_inputs=ids,parent=link,prefix_nodes=v,spliced_boxes=len(child),
                      continued_nodes=node_visits,total_nodes=v+node_visits,suffix_five=five,suffix_newQ=point,
                      parent_five=t,parent_P30=p,parent_oldQ=q,from_run=path.name)
            proofs[key]=data
            prior=selected.get(key)
            if prior is None or (len(ids),data['total_nodes'])<(len(prior['extra_inputs']),prior['total_nodes']):
                selected[key]=data
        stats[path.stem]=counts
        closed[path.stem]=sorted(proofs)
    out=dict(target='67/80',strict=True,cap=a.cap,attempted_original_roots=len(packet),
             by_arm=stats,closed_by_arm=closed,proved=[selected[key] for key in sorted(selected)],
             input_sha256={x.name:sha(x) for x in (a.packet,*a.runs)})
    if len(a.runs)==2:
        baseline,expected=[p.stem for p in a.runs]
        b=set(closed[baseline]);e=set(closed[expected])
        out.update(sharp_only=sorted(e-b),control_only=sorted(b-e),both=sorted(e&b))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'by_arm':stats,'new_strict_whole_roots':len(selected),
                      'by_actual_inputs':dict(Counter('+'.join(p['extra_inputs']) or 'five'
                                                       for p in selected.values()))}),flush=True)
if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for x in ('comp','tree','r2','ledger','packet','output'):
        p.add_argument(x,type=Path)
    p.add_argument('--cap',type=int,required=True)
    p.add_argument('--runs',type=Path,nargs='+',required=True)
    run(p.parse_args())

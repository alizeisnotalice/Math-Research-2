# $0.83750$ 固定输入模型的整叶交差

范围为 Tomar v9 第四层留下的同一批 5,442 枚原闭叶。每个已排除的原叶具有完整树证书，面积严格大于 $67/80$。五曲体的运动、原闭根和中分面沿用 R2。三十点和十一点的各个固定点集可独立平移、旋转和反射。

| 固定形体 | 排除 | 未决 |
|---|---:|---:|
| 五曲体和原三十点 | 3,662 | 1,780 |
| 五曲体、原三十点和旧十一点 | 4,592 | 850 |
| 五曲体和替换的三十点 | 3,671 | 1,771 |
| 五曲体、原三十点和两组十一点 | 4,667 | 775 |
| 五曲体、替换的三十点和两组十一点 | 4,676 | 766 |

固定替换三十点的模型继承原三十点的所有逐角几何终端。原因是同一方向、正权、权和与闭角格上的 2,493 条原整数支撑下端均被新点集支配。由新旧十一点的点坐标 SHA 区分两个物理输入。旧十一点扩角表仍使用原物理点，逐行保留原 2,258 条整数下端，另外提供 1,536 行。另行适配的点集不进入这些固定模型。

final-ledger.json 中每个模型有完整的未决原叶号。五个主模型的未决交、方向差及叶号分割位于 unresolved_intersection_sizes、unresolved_difference_sizes 和 joint_residual_cells。分割的位顺序采用 focal_model_order，位 1 指该叶尚未通过该模型的现有证书。五个模型共同未决 766 枚。旧七输入和替换三十点六输入的未决交为 841 枚。

## 认证层次

- 独立重编并复算新增 59 枚原叶的全部 690 个闭前沿，775,324 次节点产出与冻结文件逐字节一致。其真实附加点集依赖为 9 枚纯五、1 枚原三十点、2 枚旧十一点、8 枚新十一点、2 枚原三十点加新十一点、37 枚两组十一点。两组十一点的实际证书均保留两个物理输入。
- 对该批之后的余集做 24 枚匹配试验，两个核均闭合同样 11 枚完整原叶。400 个子盒中，局部闭数 355 和 357，原核与加强核分别访问 2,356,626 和 2,330,753 个节点。另 48 枚独立原叶的 770 个前沿在 65,535 单盒预算下闭合 18 枚完整原叶。 [严格局部几何](FRONTIER-GEOMETRY.md)
- 四枚原三十点原根经完整独立回放。另四枚根由扩角旧十一点闭合，逐原根及实际终端已复核。该扩角表再续算另一批六枚原叶的 68 个前沿，关闭 1205/134100 与 1205/145821，另外四枚各剩一个闭盒。两次新十一点续算、八枚原根及两枚扩角续算共增加 39 枚原三十点加两组十一点模型的闭合。
- 上述证据都只覆盖登记的原叶。一般 $0.83750$ 下界仍需补完相应模型的余集。

## 可复算入口

R2 为经过路径净化的 public-replay-r2-083750 解压目录。其原叶索引 joined-r2-plus-five-index.json 的 SHA-256 为 65b4ab38358276aed105897686075377468b4443bd6d74556b272d28df973966。COMP 是 Math-Research-2 的 lebesgue-universal-cover/computation，TREE、TABLE64、CACHE 沿用 R2，WORK 是单独临时目录。使用 Python 3.13.18、NumPy 2.5.5、python-flint 0.9.0 和 Apple Clang 21.0.0。

完整复放独立 59 枚包。编译中使用 COMP 的 three-leaf-083750 长弦帽头文件，之后逐字节比较 690 条实际输出。

~~~sh
mkdir -p "$WORK"
clang++ -O3 -std=c++17 -fsanitize=signed-integer-overflow \
    -fsanitize-undefined-trap-on-error -shared -fPIC \
    "-fmodules-cache-path=$CACHE" -I "$COMP/three-leaf-083750" \
    new-q-package/cap_joint.cpp -o "$WORK/donor.so"
python -B new-q-package/replay_joined.py "$COMP" "$TREE" "$TABLE64" \
    "$WORK/donor.so" "$R2" "$WORK/donor-replay" --workers 3
~~~

实际重放两臂和扩展批。可加 --arms 并指定 control、sharp 或 expanded 调度单批。

~~~sh
python -I -B replay_frontier_batches.py "$COMP" "$TREE" "$TABLE64" \
    "$WORK/frontier-replay" "$CACHE" --workers 4
~~~

实际重放原三十点四个原根、扩角旧十一点四个原根和六枚原叶的 68 个前沿。

~~~sh
python -I -B "$R2/kernels-tangent/replay_angle_mesh.py" "$COMP" "$TREE" "$TABLE64" \
    "$WORK/direct-p" "$CACHE" --target .83750 --cases-from direct-controls/p-keys.json \
    --modes 0 --budget 1048575 --depth 116 --dense --share-dense --panels 256 \
    --share-angles --edge-caps --q-trigger-divisor 4000 > "$WORK/direct-p.jsonl"

python -I -B old-q-extension/audit_expanded.py "$COMP" old-q-extension/q-original-angles.json \
    "$WORK/q-bank-check.json"

python -I -B old-q-extension/run_neighbors.py "$COMP" "$R2" "$TREE" "$TABLE64" \
    "$WORK/direct-q" "$CACHE" old-q-extension direct-controls/q-keys.json \
    --mode expanded-original --budget 1048575 > "$WORK/direct-q.jsonl"

python -I -B old-q-extension/run_neighbors.py "$COMP" "$R2" "$TREE" "$TABLE64" \
    "$WORK/q-frontier" "$CACHE" old-q-extension old-q-extension/keys.json \
    --mode expanded-original --budget 32767 --subboxes old-q-extension/subboxes.json \
    > "$WORK/q-frontier.jsonl"
~~~

只核对冻结回执的完整原根与挂接，再作模型交差。将命令中的各个冻结 .jsonl 指向新输出可另验重跑所得终端。

~~~sh
python -I -B audit_frontier_experiment.py "$COMP" "$TREE" "$R2" baseline-ledger.json \
    frontier-experiment/batch.json "$WORK/matched-audit.json" --cap 32767 \
    --runs frontier-experiment/control.jsonl frontier-experiment/sharp.jsonl
python -I -B audit_frontier_experiment.py "$COMP" "$TREE" "$R2" baseline-ledger.json \
    frontier-expanded/batch.json "$WORK/expanded-audit.json" --cap 65535 \
    --runs frontier-expanded/sharp.jsonl
python -I -B audit_direct_controls.py "$COMP" "$TREE" "$WORK/direct-audit.json" \
    --p direct-controls/p-whole.jsonl --p-replay direct-controls/p-replay.jsonl \
    --q direct-controls/q-expanded-snapshot.jsonl
python -I -B audit_q_extensions.py "$COMP" "$TREE" "$R2" \
    old-q-extension/packet.json old-q-extension/children.jsonl \
    old-q-extension/q-original-angles.json "$WORK/q-audit.json" --cap 32767
python -I -B merge_additions.py "$WORK/all-additions.json" "$WORK/matched-audit.json" \
    "$WORK/expanded-audit.json" "$WORK/direct-audit.json" "$WORK/q-audit.json"
python -I -B integrate_models.py "$COMP" "$TREE" "$R2" new-q-package \
    "$WORK/final-ledger.json" --extra "$WORK/all-additions.json"
~~~

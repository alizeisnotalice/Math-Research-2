"""Verify original leaves and account for which fixed inputs each proof needs."""
from argparse import ArgumentParser
from collections import defaultdict
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
OLD_INDEX='65b4ab38358276aed105897686075377468b4443bd6d74556b272d28df973966'
FIVE=frozenset()
P=frozenset({'P30'})
Q=frozenset({'oldQ11'})
R=frozenset({'newP30'})
S=frozenset({'newQ11'})
MODELS={
    'original_six': P,
    'original_with_old_Q': P|Q,
    'replacement_six': R,
    'original_with_both_Q': P|Q|S,
    'replacement_with_both_Q': R|Q|S,
    'original_with_new_Q': P|S,
    'replacement_with_old_Q': R|Q,
    'replacement_with_new_Q': R|S,
    'five_and_new_Q': S,
    'five_curves': FIVE,
}

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    return sha256(path.read_bytes()).hexdigest()

def digest_rows(path):
    return [json.loads(r) for r in path.read_bytes().splitlines()]

def old_proofs(index,stage):
    assert index['strict'] and index['target']==stage['target']=='67/80'
    base=set(); prior={}; tail=set()
    for part,rows in index['parts'].items():
        full=[f'{part}/{n}' for group in ('five','P30','Q11','remaining') for n in rows[group]]
        assert len(full)==len(set(full)) and base.isdisjoint(full)
        base.update(full)
        mixed=set(rows['Q11'])-set(rows['Q11_without_P30'])
        for group,inputs in (('five',FIVE),('P30',P),('Q11',Q)):
            for n in rows[group]:
                prior[f'{part}/{n}']=(P|Q if group=='Q11' and n in mixed else inputs)
        tail.update(f'{part}/{n}' for n in rows['remaining'])
    assert len(base)==index['stage4_retained']==stage['scope']==5442
    assert set(prior).isdisjoint(tail) and len(tail)==873
    assert len(prior)+len(tail)==len(base)
    return base,prior,tail

def exact_parent(parents,entry,source,fine,rd,audit_paths):
    key=entry['leaf']; path=rd/entry['source'].split('/')[0]
    raw=path.with_suffix('.jsonl')
    if raw.name not in parents:
        rr=digest_rows(raw)
        receipt=read(path.with_name(path.name+'-receipt.json'))
        assert receipt['complete'] and sha(raw)==receipt['result_sha256']
        parents[raw.name]=({x['leaf']:(i,x) for i,x in enumerate(rr,1)},receipt['result_sha256'])
    mp,digest=parents[raw.name]
    line,r=mp[key]
    assert r['leaf']==key and r['label']==key and not r['stats'][0]
    assert r['threshold_integer']==120696470013529293 and r['goal']=='67/80'
    assert r['stats'][7]==1 and not r['pending_visited'] and not r['guards'] and not r['center_stops']
    exact=source.leaf(*map(int,key.split('/')))
    assert all(a*fine==lo and b*fine==hi for (a,b),(lo,hi) in
               zip(exact,zip(r['lo'],r['hi'],strict=True),strict=True))
    frontier=rd/'frontiers'/entry['source']
    assert read(frontier)==entry['regions'] and sha(frontier)==entry['digest']
    assert audit_paths(r,entry['regions'])>0
    assert r['stats'][1]==2*sum(r['stats'][2:6])+len(entry['regions'])-1
    return dict(file=raw.name,line=line,sha256=digest,frontier=entry['source'],
                frontier_sha256=entry['digest']),r

def consume_package(a,tail,source,fine,audit_paths):
    pack=a.donor
    for line in (pack/'SHA256SUMS').read_text().splitlines():
        expected,name=line.split('  ')
        assert sha(pack/name)==expected
    wrappers=json.loads(decompress((pack/'regions.json.gz').read_bytes()))
    children=[json.loads(r) for r in decompress((pack/'children.jsonl.gz').read_bytes()).splitlines()]
    out=read(pack/'joint-manifest.json')
    assert out['strict'] and out['target']=='67/80' and out['baseline_remaining']==873
    assert [entry['leaf'] for entry in wrappers]==sorted(out['leaves'],key=lambda key:tuple(map(int,key.split('/'))))
    assert len(wrappers)==len(out['leaves'])==out['incremental']==59
    assert set(out['leaves'])<=tail
    pending=defaultdict(dict)
    for child in children:
        part,pos,i=child['leaf']; key=f'{part}/{pos}'
        assert i not in pending[key] and child['target']=='67/80'
        nz,visit,five,newq,_=child['out']
        assert nz==1 and child['front'] is None and visit==2*(five+newq)-1
        pending[key][i]=visit,five,newq
    parent_cache={}; proofs={};verified={}
    for entry in wrappers:
        key=entry['leaf']
        trace,row=exact_parent(parent_cache,entry,source,fine,a.r2/'refined',audit_paths)
        bins=pending.pop(key)
        count=len(entry['regions'])
        assert set(bins)==set(range(count))
        vc,tc,nc=map(sum,zip(*bins.values(),strict=True))
        _,nodes,t,p,q,mixed,*_=row['stats']
        assert not mixed
        assert nodes+vc==2*(t+p+q+tc+nc)-1
        needs=frozenset(x for c,x in ((p,'P30'),(q,'oldQ11'),(nc,'newQ11')) if c)
        let=out['leaves'][key]
        assert let['parent']==trace and let['frontier_boxes']==count
        assert let['prefix']==dict(visited=nodes,five=t,P30=p,oldQ11=q)
        assert let['suffix']==dict(visited=vc,five=tc,newQ11=nc)
        assert let['whole']['visited']==nodes+vc and set(let['whole']['extra_inputs'])==needs
        proofs[key]=needs
        verified[key]=let
    assert not pending
    return proofs,verified

def make_ledger(a):
    sys.path.insert(0,str(a.r2));sys.path.insert(0,str(a.r2/'kernels-new-p30'))
    from audit_refined_scope import audit_paths
    from verify_new_p30 import check_table
    cloud=a.r2/'new-p30/points.json'
    _,cert=check_table(a.comp,cloud)
    from certify_tomar_six_high import SourceTree,FINE
    source=SourceTree(a.tree)
    original=a.r2/'joined-r2-plus-five-index.json'
    assert sha(original)==OLD_INDEX
    old=read(original); new=read(a.r2/'new-p30/joined-ab.json')
    assert cert==read(a.r2/'new-p30/validated-angle-rows.json')
    assert new['point_set_sha256']==cert['points_sha256']
    assert new['by_input_provenance']==dict(transferred_original_P30=2567,five=1080,continued_new_P30=10)
    universe,orig_proofs,tail=old_proofs(old,new)
    donor,checked=consume_package(a,tail,source,FINE,audit_paths)
    local=set(new['certified_in_originally_unclosed'])
    assert len(local)==10 and local<=tail and local.isdisjoint(donor)
    raw={key:[orig_proofs[key]] if key in orig_proofs else [] for key in universe}
    for key,inputs in donor.items():
        raw[key].append(inputs)
    for key in local:
        raw[key].append(R)
    if a.extra:
        for row in read(a.extra)['proved']:
            key=row['leaf']
            assert key in universe
            tags=frozenset(row['extra_inputs'])
            assert tags<=P|Q|R|S
            raw[key].append(tags)
    results={}; open_sets={}
    for model,available in MODELS.items():
        good=set()
        for key,rows in raw.items():
            for formulas in rows:
                choices=[formulas]
                if P<=formulas:
                    choices.append((formulas-P)|R)
                if any(item<=available for item in choices):
                    good.add(key)
                    break
        gap=universe-good
        open_sets[model]=gap
        results[model]=dict(inputs=sorted(available),closed=len(good),remaining=len(gap),
                            unresolved=sorted(gap,key=lambda k:tuple(map(int,k.split('/')))))
    focal=('original_six','original_with_old_Q','replacement_six','original_with_both_Q',
           'replacement_with_both_Q')
    joint={l:{r:len(open_sets[l]&open_sets[r]) for r in focal} for l in focal}
    differences={l:{r:len(open_sets[l]-open_sets[r]) for r in focal} for l in focal}
    cells=defaultdict(list)
    for key in sorted(universe,key=lambda k:tuple(map(int,k.split('/')))):
        bit=''.join('1' if key in open_sets[model] else '0' for model in focal)
        cells[bit].append(key)
    assert sum(map(len,cells.values()))==len(universe)
    for i,label in enumerate(focal):
        assert set().union(*(set(members) for bit,members in cells.items() if bit[i]=='1'))==open_sets[label]
    data=dict(target='67/80',strict=True,scope=len(universe),donor59_checked=checked,
              models=results,unresolved_intersection_sizes=joint,
              unresolved_difference_sizes=differences,
              focal_model_order=list(focal),joint_residual_cells=dict(sorted(cells.items())),
              original_with_all_Q_excluding_new_P=sorted(open_sets['original_with_both_Q']
                                                       -open_sets['replacement_with_both_Q']),
              point_input_sha256={'newP30':cert['points_sha256'],
                                  'oldP30':cert['old_points_sha256'],
                                  'oldQ11_source':sha(a.comp/'multi-host-points.json'),
                                  'newQ11':sha(a.donor/'new-points.json')},
              input_index_sha256={'old':OLD_INDEX,'replacement':sha(a.r2/'new-p30/joined-ab.json'),
                                  'new_Q':sha(a.donor/'joint-manifest.json')})
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:r['remaining'] for k,r in results.items()}),flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','r2','donor','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--extra',type=Path)
    make_ledger(p.parse_args())

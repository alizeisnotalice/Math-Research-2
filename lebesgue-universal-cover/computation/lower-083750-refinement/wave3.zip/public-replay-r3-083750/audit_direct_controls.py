"""Verify native whole roots computed with the fixed old point inputs."""
from argparse import ArgumentParser
import json
from hashlib import sha256
from pathlib import Path
import sys

def read(p):
    return [json.loads(x) for x in p.read_bytes().splitlines()]

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def exact(a,path,family,replay):
    from certify_tomar_six_high import SourceTree,FINE
    source=SourceTree(a.tree)
    originals=read(path)
    if replay:
        other=read(replay)
        for left,right in zip(originals,other,strict=True):
            assert all(left[k]==right[k] for k in (
                'leaf','label','lo','hi','mode','budget','stats','pads','pending','goal',
                'p_edge_stops','q_edge_stops','threshold_integer'))
    seen=set()
    for number,row in enumerate(originals,1):
        name=row['leaf']
        assert name not in seen and name==row['label']
        seen.add(name)
        exact=source.leaf(*map(int,name.split('/')))
        assert all(x*FINE==u and y*FINE==v for (x,y),(u,v) in zip(
            exact,zip(row['lo'],row['hi'],strict=True),strict=True))
        assert row['goal']=='67/80' and row['threshold_integer']==120696470013529293
        assert row['mode']==(0 if family=='P30' else 1)
        assert row['budget']==1048575 and row['q_trigger_divisor']==4000
        assert row['shared_angles'] and row['shared_dense'] and row['panels']==256
        assert row['q_mesh']==(family=='oldQ11') and row['edge_caps'] and not row['fan_integral']
        stats=row['stats']
        assert stats[5]==0 and not row['guards'] and not row['center_stops']
        assert stats[4 if family=='P30' else 3]==0
        if not stats[0]:
            assert row['pending']>0
            continue
        assert stats[7]==0 and not row['pending']
        assert stats[1]==2*sum(stats[2:5])-1
        uses=stats[3 if family=='P30' else 4]
        yield dict(leaf=name,extra_inputs=[family] if uses else [],source_file=path.name,
                   source_line=number,nodes=stats[1],P30=stats[3],oldQ11=stats[4],five=stats[2])

def run(a):
    sys.path.insert(0,str(a.comp))
    proved=[]; files={}
    for source,family,replay in ((a.p,'P30',a.p_replay),(a.q,'oldQ11',a.q_replay)):
        if source:
            proved.extend(exact(a,source,family,replay))
            files[source.name]=digest(source)
            if replay:
                files[replay.name]=digest(replay)
    data=dict(target='67/80',strict=True,proved=proved,files_sha256=files,
              input_sha256={name:digest(a.comp/name) for name in (
                  'finite-point-leaf-input.json','finite-point-global-input.json',
                  'multi-host-points.json','q11-leaf-bank.json')})
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    print([(x['leaf'],x['extra_inputs'],x['nodes']) for x in proved],flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('comp','tree','output'):
        p.add_argument(name,type=Path)
    for name in ('p','q','p-replay','q-replay'):
        p.add_argument('--'+name,type=Path)
    run(p.parse_args())

"""Compile certified kernels and replay frozen frontier cohorts."""
from argparse import ArgumentParser
from gzip import decompress
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
ARMS={
    'control':('frontier-experiment','control.jsonl','normal',32767),
    'sharp':('frontier-experiment','sharp.jsonl','sharp',32767),
    'expanded':('frontier-expanded','sharp.jsonl','sharp',65535),
}

def main(a):
    a.work.mkdir(parents=True,exist_ok=False)
    source_driver=ROOT/'new-q-package/run_fronts.py'
    bank=a.work/'balanced384.json'
    bank.write_bytes(decompress((ROOT/'new-q-package/balanced384.json.gz').read_bytes()))
    libs={}
    for label in a.arms:
        folder,file,kernel,cap=ARMS[label]
        packet=ROOT/folder/'batch.json'
        scope=json.loads(packet.read_bytes())
        if kernel not in libs:
            lib=a.work/(kernel+'.so')
            src='q-curvature' if kernel=='sharp' else 'new-q-package'
            flags=['-DSHARP_FRONTIER'] if kernel=='sharp' else []
            subprocess.run(['clang++','-O3','-std=c++17','-fsanitize=signed-integer-overflow',
                            '-fsanitize-undefined-trap-on-error','-shared','-fPIC',
                            f'-fmodules-cache-path={a.cache}',*flags,
                            '-I',str(a.comp/'three-leaf-083750'),str(ROOT/src/'cap_joint.cpp'),
                            '-o',str(lib)],check=True)
            libs[kernel]=lib
        out=a.work/(label+'.jsonl')
        subprocess.run([sys.executable,'-B',str(source_driver),str(a.comp),str(a.tree),
                        str(a.table),str(libs[kernel]),str(bank),str(out),'--target','0.83750',
                        '--workers',str(a.workers),'--cap',str(cap),'--mesh','--caps',
                        '--only',','.join(row['leaf'] for row in scope),'--frontiers',str(packet)],
                       check=True)
        assert out.read_bytes()==(ROOT/folder/file).read_bytes(),label
        print(label,'verified exact rows',flush=True)

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for k in ('comp','tree','table','work','cache'):
        p.add_argument(k,type=Path)
    p.add_argument('--arms',nargs='+',choices=tuple(ARMS),default=list(ARMS))
    p.add_argument('--workers',type=int,default=4)
    main(p.parse_args())

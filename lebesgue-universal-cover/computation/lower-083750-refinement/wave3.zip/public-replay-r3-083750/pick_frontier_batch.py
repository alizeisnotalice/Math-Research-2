"""Pick a fixed cohort of hard residual leaves by the exact unclosed volume."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from math import prod
from pathlib import Path
import json

EXTERNAL={'176/41133','180/33905','180/24887','180/33990',
          '1205/151326','1201/73319','1205/154836','1201/73279'}

def read(p):
    return json.loads(p.read_bytes())

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def exact_volume(box):
    return prod(hi-lo for lo,hi in box)

def select(a):
    led=read(a.ledger)
    available=set(led['models']['replacement_with_both_Q']['unresolved'])-EXTERNAL
    for source in a.exclude_packets:
        available.difference_update(row['leaf'] for row in read(source))
    assert available<=set(led['models']['original_with_both_Q']['unresolved'])
    tentative={}
    for source in a.traces:
        for line in source.read_bytes().splitlines():
            row=json.loads(line)
            p,i,j=row['leaf']
            assert row['target']=='67/80'
            if row['out'][0]:
                tentative.setdefault(f'{p}/{i}',set()).add(j)
    groups=defaultdict(list)
    for path in sorted(a.refined.glob('refined-*.jsonl')):
        receipt=read(path.with_name(path.stem+'-receipt.json'))
        assert receipt['complete'] and receipt['result_sha256']==sha(path)
        for line in path.read_bytes().splitlines():
            r=json.loads(line)
            key=r['leaf']
            if key not in available:
                continue
            assert not r['stats'][0] and r['stats'][7]==1 and r['pending']>0
            relative=f'{path.stem}/{key.replace("/","-")}-mode{r["mode"]}-frontier.json'
            f=a.refined/'frontiers'/relative
            regions=read(f)
            assert len(regions)==r['pending']
            dom=exact_volume(zip(r['lo'],r['hi'],strict=True))
            known=tentative.get(key,set())
            assert all(0<=k<len(regions) for k in known)
            remainder=sum(exact_volume(b['bounds']) for k,b in enumerate(regions) if k not in known)
            score=Fraction(remainder,dom)
            assert 0<score<=1
            prefix=('oldQ11' if r['stats'][4] else 'P30' if r['stats'][3] else 'five')
            groups[prefix].append((score,key,dict(leaf=key,source=relative,digest=sha(f),
                 regions=regions,prior_local_successes=len(known),normalized_unclosed_volume=str(score))))
    assert sum(map(len,groups.values()))==len(available)
    chosen=[]
    for prefix,count in zip(('five','P30','oldQ11'),a.counts,strict=True):
        group=sorted(groups[prefix])
        assert len(group)>=count
        chosen.extend(row for _,_,row in group[:count])
    assert len({x['leaf'] for x in chosen})==len(chosen)
    chosen.sort(key=lambda row:tuple(map(int,row['leaf'].split('/'))))
    out=dict(goal='67/80',prefix_group_sizes={k:len(v) for k,v in groups.items()},
             selected=len(chosen),boxes=sum(len(x['regions']) for x in chosen),
             selection_used_only_tentative_previous_success=True,
             source_ledger_sha256=sha(a.ledger), scheduling_raw_sha256={p.name:sha(p) for p in a.traces})
    a.packet.write_text(json.dumps(chosen,separators=(',',':'))+'\n')
    a.packet.with_suffix('.manifest.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)

if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    for x in ('ledger','refined','packet'):
        cli.add_argument(x,type=Path)
    cli.add_argument('--traces',type=Path,nargs='+',required=True)
    cli.add_argument('--counts',type=int,nargs=3,default=(6,8,10))
    cli.add_argument('--exclude-packets',type=Path,nargs='*',default=[])
    select(cli.parse_args())

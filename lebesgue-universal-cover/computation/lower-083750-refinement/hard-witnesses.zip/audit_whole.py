"""Audit full new and original runs using the genuine original boxes, explicit point banks and terminal counts."""

from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, sys


def sha(p):
    return sha256(p.read_bytes()).hexdigest()


def js(p):
    return json.loads(p.read_bytes())


def run(a):
    assert __debug__
    sys.path.insert(0, str(a.comp.resolve()))
    from certify_tomar_six_high import SourceTree
    from build_q11_leaf_bank import reflected_average, EPS
    from replay_q11_with_p30 import PointProof
    from certify_finite_point_leaf import point_tables, Q, U
    from flint import ctx

    ctx.prec = 160
    tr = SourceTree(a.tree)
    root = Path(__file__).resolve().parent
    data = {}
    for label in ["p", "q"]:
        keys = js(a.targeted / (label + "-keys.json"))
        new = a.targeted / (label + "-input.json")
        if a.mode == "original":
            if label == "q":
                p = a.comp / "multi-host-points.json"
                cloud, D = reflected_average(js(p))
                bank = js(a.comp / "q11-leaf-bank.json")
                d = {**bank, "points": cloud, "denominator": D, "direction_scale": U}
            else:
                p = a.comp / "finite-point-leaf-input.json"
                d = {
                    **js(p),
                    "cells": js(a.comp / "finite-point-global-input.json")["cells"],
                }
        else:
            p = new
            d = js(p)
        dia, ptr, rows = point_tables(d)
        tag = PointProof(d, EPS if a.mode == "original" and label == "q" else F(0))
        assert all(rows[j::8] == tag.triples[j::8].tolist() for j in range(7))
        if a.mode == "original" and label == "q":
            assert [x - 1 for x in rows[7::8]] == tag.triples[7::8].tolist()
        else:
            assert rows[7::8] == tag.triples[7::8].tolist()
        assert len(d["points"]) == (30 if label == "p" else 11)
        assert dia <= d["denominator"] ** 2
        file = a.receipts / (label + "-whole.jsonl")
        cases = [json.loads(l) for l in file.read_bytes().splitlines()]
        assert [q["leaf"] for q in cases] == keys
        output = []
        for q in cases:
            key = q["leaf"]
            box = tr.leaf(*(int(x) for x in key.split("/")))
            assert [
                [F(l, 2**44), F(h, 2**44)] for l, h in zip(q["lo"], q["hi"])
            ] == [list(x) for x in box]
            s = q["stats"]
            assert q["label"] == key and q["mode"] == int(label == "q")
            assert q["goal"] == "67/80" and q["threshold_integer"] == 120696470013529293
            assert (
                q["guards"] == q["center_calls"] == s[5] == 0
                and s[3 if label == "q" else 4] == 0
            )
            assert (
                q["edge_caps"]
                and q["dense"]
                and q["shared_dense"]
                and q["shared_angles"]
            )
            if s[0]:
                assert q["pending"] == 0 and s[1] == 2 * (s[2] + s[3] + s[4]) - 1
            output.append(
                dict(
                    leaf=key,
                    closed=bool(s[0]),
                    nodes=s[1],
                    five=s[2],
                    finite=s[3] + s[4],
                    pending=q["pending"],
                    depth=s[6],
                    long_chord=q[label + "_edge_stops"],
                )
            )
        data[label] = dict(
            point_file_sha256=sha(p),
            points=len(d["points"]),
            bank_row_count=ptr[-1],
            directions=len(d["directions"]),
            symmetric_array_diameter_squared=str(F(dia, d["denominator"] ** 2)),
            native_triplet_table_sha256=sha256(
                tag.triples.astype("<i8").tobytes()
            ).hexdigest(),
            receipt_sha256=sha(file),
            roots=output,
        )
    result = dict(
        complete=True,
        mode=a.mode,
        root_tree_manifest_sha256=sha(a.tree / "SHA256SUMS"),
        certified_originals=sum(r["closed"] for k in data.values() for r in k["roots"]),
        already_registered_root="176/41133",
        geometry_driver_sha256=sha(root / "compare_targeted.py"),
        whole_runner_sha256=sha(root / "run_whole.py"),
        inputs=data,
    )
    a.out.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(
        result["certified_originals"],
        [(k, sum(r["nodes"] for r in row["roots"])) for k, row in data.items()],
    )


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "tree", "targeted", "receipts", "out"]:
        p.add_argument(k, type=Path)
    p.add_argument("--mode", choices=["targeted", "original"], default="targeted")
    run(p.parse_args())

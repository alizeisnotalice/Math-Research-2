"""Bind whole-root certificates with the frozen original point sets and an optional Q11 row enlargement."""

from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, sys


def sha(p):
    return sha256(p.read_bytes()).hexdigest()


def js(p):
    return json.loads(p.read_bytes())


def run(a):
    assert __debug__
    sys.path.insert(0, str(a.comp.resolve()))
    from build_q11_leaf_bank import reflected_average, EPS
    from replay_q11_with_p30 import PointProof
    from certify_tomar_six_high import SourceTree
    from certify_finite_point_leaf import U
    from flint import ctx

    ctx.prec = 160
    tree = SourceTree(a.tree)
    q = js(a.comp / "multi-host-points.json")
    p = js(a.comp / "finite-point-leaf-input.json")
    xp, xd = reflected_average(q)
    qb = js(a.targeted / "q-original-angles.json")
    P = PointProof(
        {**p, "cells": js(a.comp / "finite-point-global-input.json")["cells"]}
    )
    Q = PointProof({**qb, "points": xp, "denominator": xd, "direction_scale": U}, EPS)
    native = sha256(Q.triples.astype("<i8").tobytes()).hexdigest()
    assert (
        native == js(a.targeted / "q-original-angles-audit.json")["native_table_sha256"]
    )
    roots = {}
    receipt_hash = {}
    for label, path in [
        ("p", a.targeted / "original-whole/p-whole.jsonl"),
        ("q", a.targeted / "q-original-expanded.jsonl"),
    ]:
        receipt_hash[label] = sha(path)
        data = [json.loads(l) for l in path.read_bytes().splitlines()]
        assert [z["leaf"] for z in data] == js(a.targeted / (label + "-keys.json"))
        for d in data:
            key = d["leaf"]
            box = tree.leaf(*map(int, key.split("/")))
            assert list(zip(d["lo"], d["hi"])) == [
                (int(l * 2**44), int(r * 2**44)) for l, r in box
            ]
            assert (
                d["label"] == key and d["mode"] == (label == "q") and d["pending"] == 0
            )
            assert d["goal"] == "67/80" and d["threshold_integer"] == 120696470013529293
            s = d["stats"]
            assert (
                s[0] == 1
                and s[1] == 2 * sum(s[2:5]) - 1
                and s[5] == s[3 if label == "q" else 4] == 0
            )
            assert (
                d["center_calls"] == d["guards"] == 0
                and d["panels"] == 256
                and d["q_trigger_divisor"] == 4000
            )
            roots[key] = dict(
                material="original " + ("P30" if label == "p" else "Q11"),
                nodes=s[1],
                five=s[2],
                P30=s[3],
                Q11=s[4],
                long_chord=d[label + "_edge_stops"],
                pending=0,
            )
    summary = dict(
        complete=True,
        roots=roots,
        by_family={"original_P30": 4, "original_Q11": 4},
        total_nodes=sum(r["nodes"] for r in roots.values()),
        already_registered_root="176/41133",
        physical_P30_file_sha256=sha(a.comp / "finite-point-leaf-input.json"),
        physical_Q11_file_sha256=sha(a.comp / "multi-host-points.json"),
        expanded_Q11_bank_sha256=sha(a.targeted / "q-original-angles.json"),
        P30_table_sha256=sha256(P.triples.astype("<i8").tobytes()).hexdigest(),
        Q11_table_sha256=native,
        receipt_sha256=receipt_hash,
    )
    a.out.write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n")
    print(summary["total_nodes"], roots.keys(), flush=True)


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for key in ["comp", "tree", "targeted", "out"]:
        p.add_argument(key, type=Path)
    run(p.parse_args())

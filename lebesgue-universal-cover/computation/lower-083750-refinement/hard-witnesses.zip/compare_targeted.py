"""Match capped native terminal replays on original pending boxes with fixed pilot clouds."""

from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json, runpy, sys


def run(a):
    base = Path(__file__).resolve().parent
    home = base / "targeted"
    cp = a.comp.resolve()
    sys.path.insert(0, str(cp))
    import replay_q11_with_p30 as old

    cls = old.PointProof

    def proof(data, error=F(0)):
        if a.label == "q" and not error:
            p = cls(data)
            p.triples[7::8] = 0
            return p
        if a.label == "p" and error:
            raise AssertionError
        if a.mode == "original":
            return cls(data, error)
        if a.mode == "targeted":
            d = json.loads((home / (a.label + "-input.json")).read_bytes())
            return cls(d)
        if a.label == "p":
            d = json.loads((base / "new30.json").read_bytes())
            return cls({**d, "cells": data["cells"]})
        return cls(data, error)

    old.PointProof = proof
    source = a.replay.resolve() / "kernels-tangent/replay_angle_mesh.py"
    sys.argv = [
        str(source),
        str(cp),
        str(a.tree.resolve()),
        str(a.table.resolve()),
        str(a.work.resolve()),
        str(a.cache.resolve()),
        "--target",
        ".83750",
        "--cases-from",
        str(home / (a.label + "-keys.json")),
        "--subboxes",
        str(a.boxes or home / (a.label + "-boxes.json")),
        "--modes",
        ("1" if a.label == "q" else "0"),
        "--budget",
        str(a.budget),
        "--depth",
        "116",
        "--panels",
        "256",
        "--share-angles",
        "--edge-caps",
        "--dense",
        "--share-dense",
        "--q-trigger-divisor",
        "4000",
    ]
    if a.whole:
        off = sys.argv.index("--subboxes")
        del sys.argv[off : off + 2]
    if a.frontier:
        sys.argv += ["--frontier-out", str(a.frontier)]
    if a.label == "q":
        sys.argv.append("--q-mesh")
    runpy.run_path(str(source), run_name="__main__")


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for name in ["comp", "replay", "tree", "table", "work", "cache"]:
        p.add_argument(name, type=Path)
    p.add_argument("label", choices=["p", "q"])
    p.add_argument("mode", choices=["base", "targeted", "original"])
    p.add_argument("--boxes", type=Path)
    p.add_argument("--frontier", type=Path)
    p.add_argument("--whole", action="store_true")
    p.add_argument("--budget", type=int, default=2047)
    run(p.parse_args())

"""Compare every original Q11 native row with its retained member in the denser bank."""

from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json, sys


def run(comp, bankfile, out):
    sys.path.insert(0, str(comp.resolve()))
    from build_q11_leaf_bank import reflected_average, EPS
    from replay_q11_with_p30 import PointProof
    from certify_finite_point_leaf import U
    from flint import ctx

    ctx.prec = 192
    original = json.loads((comp / "multi-host-points.json").read_bytes())
    p, D = reflected_average(original)
    old = json.loads((comp / "q11-leaf-bank.json").read_bytes())
    new = json.loads(bankfile.read_bytes())
    native = []
    for b in [old, new]:
        pf = PointProof({**b, "points": p, "denominator": D, "direction_scale": U}, EPS)
        native.append((pf.pointers.tolist(), pf.triples.reshape(-1, 8).tolist()))
    (ip, a), (iq, b) = native
    increments = []
    bad = []
    for k, (g, h) in enumerate(zip(old["cells"], new["cells"])):
        assert len(h) == len(g) + 4
        for j, (r, s) in enumerate(zip(g, h[4:])):
            assert [old["directions"][i] for i in r[:3]] == [
                new["directions"][i] for i in s[:3]
            ]
            x, y = a[ip[k] + j], b[iq[k] + j + 4]
            assert x[3:7] == y[3:7]
            increments.append(y[7] - x[7])
            if y[7] < x[7]:
                bad.append((k, j, x[7], y[7]))
    d = dict(
        complete=True,
        original_rows=len(a),
        new_rows=len(b),
        native_min_increase=min(increments),
        native_max_increase=max(increments),
        improved=sum(t > 0 for t in increments),
        tied=sum(t == 0 for t in increments),
        lost=bad,
        new_direction_count=len(new["directions"]),
        original_cloud_sha256=sha256(
            (comp / "multi-host-points.json").read_bytes()
        ).hexdigest(),
        bank_sha256=sha256(bankfile.read_bytes()).hexdigest(),
        native_table_sha256=sha256(pf.triples.astype("<i8").tobytes()).hexdigest(),
        native_error=1,
        physically_original_shape=True,
    )
    out.write_text(json.dumps(d, sort_keys=True, indent=2) + "\n")
    print(d["native_min_increase"], d["improved"], d["tied"], len(bad))


if __name__ == "__main__":
    p = ArgumentParser()
    for k in ["comp", "bank", "out"]:
        p.add_argument(k, type=Path)
    a = p.parse_args()
    run(a.comp, a.bank, a.out)

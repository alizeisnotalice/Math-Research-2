"""Use the original eleven physical points on a richer selected fixed angular bank."""

from argparse import ArgumentParser
from pathlib import Path
import json, runpy, sys
from fractions import Fraction as F

p = ArgumentParser()
for k in ["comp", "replay", "tree", "table", "work", "cache", "targeted"]:
    p.add_argument(k, type=Path)
a = p.parse_args()
sys.path.insert(0, str(a.comp.resolve()))
import replay_q11_with_p30 as old

cls = old.PointProof


def proof(data, error=F(0)):
    if error:
        d = json.loads((a.targeted / "q-original-angles.json").read_bytes())
        return cls(
            {**d, "points": data["points"], "denominator": data["denominator"]}, error
        )
    q = cls(data)
    q.triples[7::8] = 0
    return q


old.PointProof = proof
src = a.replay.resolve() / "kernels-tangent/replay_angle_mesh.py"
sys.argv = [
    str(src),
    str(a.comp.resolve()),
    str(a.tree.resolve()),
    str(a.table.resolve()),
    str(a.work.resolve()),
    str(a.cache.resolve()),
    "--target",
    ".83750",
    "--cases-from",
    str(a.targeted.resolve() / "q-keys.json"),
    "--modes",
    "1",
    "--depth",
    "116",
    "--budget",
    "1048575",
    "--panels",
    "256",
    "--share-angles",
    "--q-mesh",
    "--edge-caps",
    "--dense",
    "--share-dense",
    "--q-trigger-divisor",
    "4000",
]
runpy.run_path(str(src), run_name="__main__")

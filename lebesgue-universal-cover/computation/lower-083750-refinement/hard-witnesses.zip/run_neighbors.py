"""Run a named Q11 or fixed adapted-Q cloud on a specified genuine original region."""

from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path
import json, runpy, sys


def run(a):
    cp = a.comp.resolve()
    sys.path.insert(0, str(cp))
    import replay_q11_with_p30 as old

    cls = old.PointProof

    def proof(d, error=F(0)):
        if not error:
            v = cls(d)
            v.triples[7::8] = 0
            return v
        if a.mode == "original":
            return cls(d, error)
        if a.mode == "expanded-original":
            bank = json.loads((a.targeted / "q-original-angles.json").read_bytes())
            return cls(
                {**bank, "points": d["points"], "denominator": d["denominator"]}, error
            )
        return cls(json.loads((a.targeted / "q-input.json").read_bytes()))

    old.PointProof = proof
    src = a.package.resolve() / "kernels-tangent/replay_angle_mesh.py"
    sys.argv = [
        str(src),
        str(cp),
        str(a.tree.resolve()),
        str(a.table.resolve()),
        str(a.work.resolve()),
        str(a.cache.resolve()),
        "--target",
        ".83750",
        "--cases-from",
        str(a.keys.resolve()),
        "--modes",
        "1",
        "--depth",
        "116",
        "--budget",
        str(a.budget),
        "--panels",
        "256",
        "--share-angles",
        "--q-mesh",
        "--edge-caps",
        "--dense",
        "--share-dense",
        "--q-trigger-divisor",
        "4000",
    ]
    if a.frontier:
        sys.argv += ["--frontier-out", str(a.frontier.resolve())]
    if a.subboxes:
        sys.argv += ["--subboxes", str(a.subboxes.resolve())]
    runpy.run_path(str(src), run_name="__main__")


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "package", "tree", "table", "work", "cache", "targeted", "keys"]:
        p.add_argument(k, type=Path)
    p.add_argument(
        "--mode",
        choices=["targeted", "original", "expanded-original"],
        default="targeted",
    )
    p.add_argument("--budget", type=int, default=262143)
    p.add_argument("--frontier", type=Path)
    p.add_argument("--subboxes", type=Path)
    run(p.parse_args())

"""Bracket the best uniform gain achievable with the original P30 material labels."""

from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from argparse import ArgumentParser
from hashlib import sha256
import json, sys
from flint import arb, ctx


def ar(x):
    q = F(x)
    return arb(q.numerator) / q.denominator


def s(p):
    return sha256(p.read_bytes()).hexdigest()


def run(comp, proposal, sharp, cert, out):
    sys.path.insert(0, str(comp.resolve()))
    from certify_finite_point_leaf import point_tables, Q, U

    ctx.prec = 192
    d = json.loads((comp / "finite-point-leaf-input.json").read_bytes())
    bank = json.loads((comp / "finite-point-global-input.json").read_bytes())["cells"]
    y = json.loads(proposal.read_bytes())
    witness = json.loads(sharp.read_bytes())
    assert (
        s(proposal)
        == "1afef7eabda436e4950853fc4623aa2b3956b625b747bdd7053732fecfe5eb58"
    )
    P = d["points"]
    V = d["directions"]
    pd = d["denominator"]
    X = witness["points"]
    xd = witness["denominator"]
    assert len(P) == len(X) == 30 and all(
        X[P.index([x, -y])] == [a, -b] for (x, y), (a, b) in zip(P, X)
    )
    sq = max((x - a) ** 2 + (y - b) ** 2 for (x, y), (a, b) in combinations(X, 2))
    assert sq < xd**2
    _, ptr, flat = point_tables({**d, "cells": bank})
    o = json.loads(cert.read_bytes())
    weights = dict(o["weighted_rows"])
    T = sum(weights.values())
    assert abs(T - o["denominator"]) <= 2
    R = [[arb(0), arb(0)] for _ in P]
    lower = None
    upper = arb(0)
    events = []
    arc = [(2 * arb.pi() * i / 384).sin_cos() for i in range(385)]
    for c, items in enumerate(bank):
        for pos, row in enumerate(items):
            k = ptr[c] + pos
            ids, p = row[:3], row[3:]
            w = flat[8 * k + 3 : 8 * k + 6]
            for end, (sn, cs) in enumerate(arc[c : c + 2]):
                eid = 2 * k + end
                val = arb(0)
                for h, i, j in zip(w, ids, p):
                    vx, vy = V[i]
                    q = ar(F(h, sum(w) * U))
                    a = q * (vx * cs + vy * sn)
                    b = q * (-vx * sn + vy * cs)
                    val += a * ar(F(X[j][0], xd) - F(P[j][0], pd)) + b * ar(
                        F(X[j][1], xd) - F(P[j][1], pd)
                    )
                    if eid in weights:
                        R[j][0] += ar(F(weights[eid], T)) * a
                        R[j][1] += ar(F(weights[eid], T)) * b
                lower = val.lower() if lower is None else min(lower, val.lower())
                if eid in weights:
                    events.append([c, pos, end, str(F(weights[eid], T))])
    assert lower > ar(".0002550355")
    for i, j, num in o["diameter_contacts"]:
        v = [y["points"][i][k] - y["points"][j][k] for k in range(2)]
        L = arb(sum(t * t for t in v)).sqrt()
        u = [t / L for t in v]
        mu = ar(F(num, T))
        upper += mu * (
            1 - sum(a * ar(F(P[i][k] - P[j][k], pd)) for k, a in enumerate(u))
        )
        for k in range(2):
            R[i][k] -= mu * u[k]
            R[j][k] += mu * u[k]
    # Translate to z_0=0, mirror pairs identified, so all free material displacements are at most 2.
    rem = arb(0)
    for i, (x, y) in enumerate(P):
        if i == 0 or y < 0:
            continue
        if y == 0:
            rem += abs(R[i][0])
            continue
        j = P.index([x, -y])
        rem += abs(R[i][0] + R[j][0]) + abs(R[i][1] - R[j][1])
    upper = (upper + 2 * rem).upper()
    assert upper < ar(".000255036")
    result = dict(
        complete=True,
        uniform_gain_upper=str(upper),
        uniform_gain_lower=str(lower),
        residual_l1=str(rem),
        lower_diameter_squared=str(F(sq, xd**2)),
        selected_endpoints=events,
        dual_sha256=s(cert),
        selected_directions_source_sha256=s(proposal),
        sharp_witness_sha256=s(sharp),
        source_cloud_sha256=s(comp / "finite-point-leaf-input.json"),
        source_bank_sha256=s(comp / "finite-point-global-input.json"),
        verifier_sha256=s(Path(__file__)),
    )
    out.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(lower, upper, rem)


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    for k in ["comp", "proposal", "sharp", "cert", "out"]:
        p.add_argument(k, type=Path)
    a = p.parse_args()
    run(a.comp, a.proposal, a.sharp, a.cert, a.out)

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json, subprocess, sys

p = ArgumentParser()
for k in [
    "comp",
    "package",
    "tree",
    "table",
    "work",
    "cache",
    "targeted",
    "packets",
    "out",
]:
    p.add_argument(k, type=Path)
p.add_argument(
    "--mode", default="targeted", choices=["targeted", "original", "expanded-original"]
)
p.add_argument("--budget", type=int, default=262143)
p.add_argument("--workers", type=int, default=3)
a = p.parse_args()
a.out.mkdir(parents=True, exist_ok=True)


def one(packet):
    key = packet.stem
    dst = a.out / (key + ".jsonl")
    cmd = [
        sys.executable,
        "-I",
        "-B",
        str(Path(__file__).with_name("run_neighbors.py")),
        str(a.comp),
        str(a.package),
        str(a.tree),
        str(a.table),
        str(a.work / key),
        str(a.cache),
        str(a.targeted),
        str(packet),
        "--mode",
        a.mode,
        "--budget",
        str(a.budget),
        "--frontier",
        str(a.out / (key + "-frontier")),
    ]
    with dst.open("w") as f:
        subprocess.run(cmd, stdout=f, check=True)
    d = [json.loads(l) for l in dst.read_bytes().splitlines()]
    print(
        key,
        len(d),
        sum(r["stats"][0] for r in d),
        sum(r["stats"][1] for r in d),
        flush=True,
    )


with ThreadPoolExecutor(max_workers=a.workers) as pool:
    list(pool.map(one, sorted(a.packets.glob("*.json"))))

"""Bind the existing native replay and its geometry dependencies to the frozen public manifest."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json

p = ArgumentParser()
for k in ["comp", "package", "table", "out"]:
    p.add_argument(k, type=Path)
a = p.parse_args()
digest = lambda path: sha256(path.read_bytes()).hexdigest()
manifest = a.package / "manifest.json"
assert (
    digest(manifest)
    == "1587b938809597a72845d4fed853a69a9e8fe9afd145a9dbf2b6f22869163116"
)
m = json.loads(manifest.read_bytes())
for k, h in m["computation_dependencies_sha256"].items():
    assert digest(a.comp / k) == h
files = {
    k: h
    for k, h in m["package_files_sha256"].items()
    if k.startswith("kernels-tangent/")
}
for k, h in files.items():
    assert digest(a.package / k) == h
assert digest(a.table) == m["table64_sha256"]
audit = dict(
    complete=True,
    manifest_sha256=digest(manifest),
    table_sha256=m["table64_sha256"],
    generated_kernel_inputs=files,
    computation_dependencies=m["computation_dependencies_sha256"],
)
a.out.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")

"""Rebuild four original roots per adapted cloud without inheriting a point prefix."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess, sys, json

p = ArgumentParser()
for k in ("comp", "replay", "tree", "table", "work", "cache", "out"):
    p.add_argument(k, type=Path)
p.add_argument("--labels", nargs="+", default=["p", "q"])
p.add_argument("--mode", choices=["targeted", "base", "original"], default="targeted")
p.add_argument("--budget", type=int, default=1048575)
a = p.parse_args()
a.out.mkdir(exist_ok=True, parents=True)


def run(label):
    file = a.out / (label + "-whole.jsonl")
    cmd = [
        sys.executable,
        "-I",
        "-B",
        str(Path(__file__).with_name("compare_targeted.py")),
        str(a.comp),
        str(a.replay),
        str(a.tree),
        str(a.table),
        str(a.work / label),
        str(a.cache),
        label,
        a.mode,
        "--whole",
        "--budget",
        str(a.budget),
        "--frontier",
        str(a.out / (label + "-frontier")),
    ]
    with file.open("w") as f:
        subprocess.run(cmd, stdout=f, check=True)
    d = [json.loads(l) for l in file.read_bytes().splitlines()]
    print(
        label,
        len(d),
        sum(x["stats"][0] for x in d),
        sum(x["stats"][1] for x in d),
        flush=True,
    )


with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run, a.labels))

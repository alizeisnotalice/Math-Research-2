"""Independent semantic replay of exactly the disjoint total54 ledger union."""
import argparse,concurrent.futures as cf,hashlib,importlib.util,itertools,json,multiprocessing,os,sys,time
from pathlib import Path
SOURCE='d68f1010c61ad1d911749742fef8c790c0a8064bf34512b402e7e65e4703e710'
VERIFIER='a557bf120c6bed03adbd8b2ce153a88bf76e678ed94c6bc8815d14dc33edbe4b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def eh(e):return hashlib.sha256(json.dumps(e,sort_keys=True).encode()).hexdigest()
def atom(p,o):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix('.partial')
 with t.open('w') as f:json.dump(o,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def worker(root,e,binding,cache):
 s=importlib.util.spec_from_file_location('aud',root/'code/audited_chunk_verifier.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
 errors=[];r=v.verify_chunk(root/'run/t54',e,6,errors);o={'status':'passed' if not errors else 'rejected','binding':binding,'event_sha256':eh(e),'errors':errors,'result':r};atom(cache,o);return o

def main():
 if not __debug__:raise RuntimeError('no -O')
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--workers',type=int,default=13);ap.add_argument('--seconds',type=int,default=14400);ap.add_argument('--limit',type=int);args=ap.parse_args();root=args.root;inp=root/'input';start=time.monotonic()
 assert sha(inp/'frozen_support.py')==SOURCE and sha(root/'code/audited_chunk_verifier.py')==VERIFIER
 plan=json.loads((inp/'plan.json').read_text());assert plan['job_total']==len(plan['jobs'])==185264 and plan['frozen_support_sha256']==SOURCE
 expected={}
 for m in range(1,28):
  i=0
  for size in range(2,min(m+1,6)+1):
   for inner in itertools.combinations(range(1,m),size-2):expected[m,i]=(0,*inner,m);i+=1
 actual={}
 for j in plan['jobs']:
  if j['total']!=54:continue
  key=j['m'],j['index'];assert key not in actual and j['n']==54-j['m'];actual[key]=tuple(j['I'])
 assert actual==expected and len(expected)==101583
 oldexit=json.loads((inp/'old-exit.json').read_text());assert oldexit['returncode']==255 and not oldexit['selected_set_complete'] and oldexit['chunks_persisted']==94465
 newexit=json.loads((inp/'new-exit.json').read_text());assert newexit['status']=='complete' and newexit['remaining']==0 and newexit['failures']==[] and newexit['persisted_chunks_total']==90799 and newexit['submitted']==newexit['finished']==90798
 oldlaunch=json.loads((inp/'old-launch.json').read_text());assert oldlaunch['plan_sha256']==sha(inp/'plan.json') and oldlaunch['payload_sha256']==sha(inp/'old-payload.py') and oldlaunch['frozen_support_sha256']==SOURCE
 events={};origin={};ct={}
 for label in ('old','new'):
  c=0
  for line in (inp/f'{label}-events.jsonl').open():
   e=json.loads(line)
   if e.get('event')!='chunk' or e.get('total')!=54:continue
   key=e['m'],e['index'];assert key not in events and tuple(e['I'])==expected[key] and e['n']==54-e['m'];events[key]=e;origin[key]=label;c+=1
  ct[label]=c
 assert events.keys()==expected.keys() and ct=={'old':10784,'new':90799}
 complement=json.loads((inp/'complement.json').read_text());assert complement['missing_total54_jobs']==90799
 missing={(j['m'],j['index']):tuple(j['I']) for j in complement['missing_jobs']};assert missing=={k:expected[k] for k in origin if origin[k]=='new'}
 bind={p.name:sha(p) for p in sorted(inp.iterdir()) if p.is_file()};bind.update({'runner':sha(Path(__file__)),'source':SOURCE,'verifier':VERIFIER,'total':54,'cap':6})
 pending=set(events);done=cached=0;fail=[];submitted=0
 def paths(k):return root/f'run/t54/m{k[0]:02}n{54-k[0]:02}/i{k[1]:06}.jsonl.gz',root/f'cache/t54/m{k[0]:02}/i{k[1]:06}.json'
 for k in sorted(pending):
  p,c=paths(k)
  if not c.is_file():continue
  try:
   x=json.loads(c.read_text());assert x['status']=='passed' and not x['errors'] and x['binding']==bind and x['event_sha256']==eh(events[k]) and x['result']['counts']==events[k]['counts'] and sha(p)==events[k]['gzip_sha256']
   pending.remove(k);done+=1;cached+=1
  except (OSError,ValueError,KeyError,AssertionError):pass
 def progress(status):
  x={'status':status,'expected':len(events),'verified':done,'cached':cached,'remaining':len(events)-done,'failures':fail,'binding':bind,'workers':args.workers,'pid':os.getpid(),'python':sys.version,'elapsed':time.monotonic()-start,'origin_chunks':ct};atom(root/'progress54.json',x);print(json.dumps({k:x[k] for k in ('status','verified','remaining','elapsed')}),flush=True)
 progress('running');last=0
 with cf.ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context('fork')) as pool:
  active={}
  while pending or active:
   expired=time.monotonic()-start>=args.seconds or (args.limit is not None and submitted>=args.limit)
   if not expired and not fail:
    for k in sorted(pending):
     if len(active)>=2*args.workers or (args.limit is not None and submitted>=args.limit):break
     p,c=paths(k)
     if not p.is_file():continue
     active[pool.submit(worker,root,events[k],bind,c)]=k;pending.remove(k);submitted+=1
   if not active:
    if expired or fail:break
    time.sleep(2)
   else:
    ready,_=cf.wait(active,timeout=2,return_when=cf.FIRST_COMPLETED)
    for fut in ready:
     k=active.pop(fut)
     try:
      x=fut.result()
      if x['status']=='passed':done+=1
      else:fail.append({'key':k,'errors':x['errors']})
     except Exception as e:fail.append({'key':k,'error':repr(e)})
   if time.monotonic()-last>=10:progress('running' if not fail else 'draining_after_failure');last=time.monotonic()
 progress('complete' if done==len(events) and not fail else 'rejected' if fail else 'partial')
 if fail:raise SystemExit(2)
if __name__=='__main__':main()
